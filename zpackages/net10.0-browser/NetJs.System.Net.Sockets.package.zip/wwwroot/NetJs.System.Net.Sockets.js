
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stee, $scsl, $snv, $sri, $sl, $stt, $sttp, $sdd, $snp, $ssc, $sspw, $sto, $snnr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Sockets", 
    {"h":55117,"f":"System.Net.Sockets","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Sockets","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Sockets","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sns.System.Net.Sockets.IPv6MulticastOption", ($self) => class IPv6MulticastOption extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.IPAddress*/ group)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ group, /*long*/ ifindex)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get InterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set InterfaceIndex(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 317261;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3070790,"g":{"r":0,"d":0,"h":17180186445,"f":1},"s":{"r":0,"d":0,"h":21475153741,"f":1},"n":"Group","d":317261,"h":12885219149,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":30065088333,"f":1},"s":{"r":0,"d":0,"h":34360055629,"f":1},"n":"InterfaceIndex","d":317261,"h":25770121037,"f":1}],"c":[{"p":[{"n":"group","p":3070790}],"n":".ctor","o":"$ctor$1","d":317261,"h":4295284557,"f":1},{"p":[{"n":"group","p":3070790},{"n":"ifindex","p":917505}],"n":".ctor","o":"$ctor$2","d":317261,"h":8590251853,"f":1}],"h":317261}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.IPv6MulticastOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.LingerOption", ($self) => class LingerOption extends $.$spc.System.Object
        {
            $ctor$1(/*bool*/ enable, /*int*/ seconds)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Enabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Enabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get LingerTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set LingerTime(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.LingerOption.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.LingerOption.GetHashCode.apply(this, arguments); }
            static $h = 382797;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885284685,"f":1},"s":{"r":0,"d":0,"h":17180251981,"f":1},"n":"Enabled","d":382797,"h":8590317389,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25770186573,"f":1},"s":{"r":0,"d":0,"h":30065153869,"f":1},"n":"LingerTime","d":382797,"h":21475219277,"f":1}],"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":382797,"h":34360121165,"f":32769},{"r":655361,"n":"GetHashCode","d":382797,"h":38655088461,"f":32769}],"c":[{"p":[{"n":"enable","p":262145},{"n":"seconds","p":655361}],"n":".ctor","o":"$ctor$1","d":382797,"h":4295350093,"f":1}],"h":382797}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.LingerOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.MulticastOption", ($self) => class MulticastOption extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.IPAddress*/ group)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ group, /*int*/ interfaceIndex)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.IPAddress*/ group, /*System.Net.IPAddress*/ mcint)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InterfaceIndex(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress? */ get LocalAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress? */ set LocalAddress(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 448333;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3070790,"g":{"r":0,"d":0,"h":21475284813,"f":1},"s":{"r":0,"d":0,"h":25770252109,"f":1},"n":"Group","d":448333,"h":17180317517,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360186701,"f":1},"s":{"r":0,"d":0,"h":38655153997,"f":1},"n":"InterfaceIndex","d":448333,"h":30065219405,"f":1},{"p":3070790,"g":{"r":0,"d":0,"h":47245088589,"f":1},"s":{"r":0,"d":0,"h":51540055885,"f":1},"n":"LocalAddress","d":448333,"h":42950121293,"f":1}],"c":[{"p":[{"n":"group","p":3070790}],"n":".ctor","o":"$ctor$1","d":448333,"h":4295415629,"f":1},{"p":[{"n":"group","p":3070790},{"n":"interfaceIndex","p":655361}],"n":".ctor","o":"$ctor$2","d":448333,"h":8590382925,"f":1},{"p":[{"n":"group","p":3070790},{"n":"mcint","p":3070790}],"n":".ctor","o":"$ctor$3","d":448333,"h":12885350221,"f":1}],"h":448333}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.MulticastOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SendPacketsElement", ($self) => class SendPacketsElement extends $.$spc.System.Object
        {
            $ctor$1(/*byte[]*/ buffer)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.FileStream*/ fileStream)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.FileStream*/ fileStream, /*long*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.FileStream*/ fileStream, /*long*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$7(/*System.ReadOnlyMemory<byte>*/ buffer)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$8(/*System.ReadOnlyMemory<byte>*/ buffer, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$9(/*string*/ filepath)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$10(/*string*/ filepath, /*int*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$11(/*string*/ filepath, /*int*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$12(/*string*/ filepath, /*long*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$13(/*string*/ filepath, /*long*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*byte[]? */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EndOfPacket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FilePath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.FileStream? */ get FileStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ReadOnlyMemory<byte>? */ get MemoryBuffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Offset()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get OffsetLong()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 841549;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":64425350989,"f":1},"n":"Buffer","d":841549,"h":60130383693,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73015285581,"f":1},"n":"Count","d":841549,"h":68720318285,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81605220173,"f":1},"n":"EndOfPacket","d":841549,"h":77310252877,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90195154765,"f":1},"n":"FilePath","d":841549,"h":85900187469,"f":1},{"p":60358657,"g":{"r":0,"d":0,"h":98785089357,"f":1},"n":"FileStream","d":841549,"h":94490122061,"f":1},{"p":$.$typeNullable($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte)).$h,"g":{"r":0,"d":0,"h":107375023949,"f":1},"n":"MemoryBuffer","d":841549,"h":103080056653,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":115964958541,"f":1},"n":"Offset","d":841549,"h":111669991245,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":124554893133,"f":1},"n":"OffsetLong","d":841549,"h":120259925837,"f":1}],"c":[{"p":[{"n":"buffer","p":0}],"n":".ctor","o":"$ctor$1","d":841549,"h":4295808845,"f":1},{"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$2","d":841549,"h":8590776141,"f":1},{"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$3","d":841549,"h":12885743437,"f":1},{"p":[{"n":"fileStream","p":60358657}],"n":".ctor","o":"$ctor$4","d":841549,"h":17180710733,"f":1},{"p":[{"n":"fileStream","p":60358657},{"n":"offset","p":917505},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$5","d":841549,"h":21475678029,"f":1},{"p":[{"n":"fileStream","p":60358657},{"n":"offset","p":917505},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$6","d":841549,"h":25770645325,"f":1},{"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h}],"n":".ctor","o":"$ctor$7","d":841549,"h":30065612621,"f":1},{"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$8","d":841549,"h":34360579917,"f":1},{"p":[{"n":"filepath","p":1310721}],"n":".ctor","o":"$ctor$9","d":841549,"h":38655547213,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$10","d":841549,"h":42950514509,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$11","d":841549,"h":47245481805,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":917505},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$12","d":841549,"h":51540449101,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":917505},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$13","d":841549,"h":55835416397,"f":1}],"h":841549}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SendPacketsElement`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SocketTaskExtensions", ($self) => class SocketTaskExtensions
        {
            static /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync(/*this System.Net.Sockets.Socket*/ socket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.Sockets.Socket?*/ acceptSocket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$4(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$6(/*this System.Net.Sockets.Socket*/ socket, /*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$7(/*this System.Net.Sockets.Socket*/ socket, /*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ ReceiveAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ ReceiveAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<int> */ SendAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendToAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1627981;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"socket","p":907085}],"n":"AcceptAsync","d":1627981,"h":4296595277,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"socket","p":907085},{"n":"acceptSocket","p":907085}],"n":"AcceptAsync","o":"@$1","d":1627981,"h":8591562573,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":133300225,"p":[{"n":"socket","p":907085},{"n":"remoteEP","p":2612038}],"n":"ConnectAsync","d":1627981,"h":12886529869,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":136118273,"p":[{"n":"socket","p":907085},{"n":"remoteEP","p":2612038},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":1627981,"h":17181497165,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":133300225,"p":[{"n":"socket","p":907085},{"n":"address","p":3070790},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":1627981,"h":21476464461,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":136118273,"p":[{"n":"socket","p":907085},{"n":"address","p":3070790},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":1627981,"h":25771431757,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":133300225,"p":[{"n":"socket","p":907085},{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$4","d":1627981,"h":30066399053,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":136118273,"p":[{"n":"socket","p":907085},{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":1627981,"h":34361366349,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":133300225,"p":[{"n":"socket","p":907085},{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$6","d":1627981,"h":38656333645,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":136118273,"p":[{"n":"socket","p":907085},{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$7","d":1627981,"h":42951300941,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":907085},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693}],"n":"ReceiveAsync","d":1627981,"h":47246268237,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":907085},{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1103693}],"n":"ReceiveAsync","o":"@$1","d":1627981,"h":51541235533,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":907085},{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$2","d":1627981,"h":55836202829,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"socket","p":907085},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"remoteEndPoint","p":2612038}],"n":"ReceiveFromAsync","d":1627981,"h":60131170125,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"socket","p":907085},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"remoteEndPoint","p":2612038}],"n":"ReceiveMessageFromAsync","d":1627981,"h":64426137421,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":907085},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693}],"n":"SendAsync","d":1627981,"h":68721104717,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":907085},{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1103693}],"n":"SendAsync","o":"@$1","d":1627981,"h":73016072013,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":907085},{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$2","d":1627981,"h":77311039309,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":907085},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"remoteEP","p":2612038}],"n":"SendToAsync","d":1627981,"h":81606006605,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}],"h":1627981,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SocketTaskExtensions`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.Socket", ($self) => class Socket extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.Sockets.AddressFamily*/ addressFamily, /*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.Sockets.SafeSocketHandle*/ handle)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.Sockets.SocketInformation*/ socketInformation)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.Sockets.AddressFamily */ get AddressFamily()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Blocking()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Blocking(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Connected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DontFragment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DontFragment(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DualMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DualMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableBroadcast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableBroadcast(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*nint */ get Handle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsBound()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ get LingerState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ set LingerState(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get MulticastLoopback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MulticastLoopback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get NoDelay()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set NoDelay(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsIPv4()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsIPv6()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsUnixDomainSockets()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.ProtocolType */ get ProtocolType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SafeSocketHandle */ get SafeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketType */ get SocketType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get SupportsIPv4()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get SupportsIPv6()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ get Ttl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ set Ttl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseOnlyOverlappedIO()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseOnlyOverlappedIO(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ Accept()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync$1(/*System.Net.Sockets.Socket?*/ acceptSocket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptAsync$2(/*System.Net.Sockets.Socket?*/ acceptSocket, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ AcceptAsync$3(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptAsync$4(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept$1(/*int*/ receiveSize, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept$2(/*System.Net.Sockets.Socket?*/ acceptSocket, /*int*/ receiveSize, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect(/*System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$1(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$3(/*string*/ host, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginDisconnect(/*bool*/ reuseSocket, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceive(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginReceive$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceive$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginReceive$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceiveFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceiveMessageFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginSend$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginSend$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendFile(/*string?*/ fileName, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendFile$1(/*string?*/ fileName, /*byte[]?*/ preBuffer, /*byte[]?*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendTo(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Bind(/*System.Net.EndPoint*/ localEP)
            {
            }
            static /*void */ CancelConnectAsync(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
            }
            /*void */ Close()
            {
            }
            /*void */ Close$1(/*int*/ timeout)
            {
            }
            /*void */ Connect(/*System.Net.EndPoint*/ remoteEP)
            {
            }
            /*void */ Connect$1(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
            }
            /*void */ Connect$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
            }
            /*void */ Connect$3(/*string*/ host, /*int*/ port)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync(/*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ConnectAsync$6(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ ConnectAsync$7(/*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType, /*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$8(/*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$9(/*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Disconnect(/*bool*/ reuseSocket)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisconnectAsync(/*bool*/ reuseSocket, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ DisconnectAsync$1(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Net.Sockets.SocketInformation */ DuplicateAndClose(/*int*/ targetProcessId)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept(/*out byte[]*/ buffer, /*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept$1(/*out byte[]*/ buffer, /*out int*/ bytesTransferred, /*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept$2(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndConnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndDisconnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndReceive(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceive$1(/*System.IAsyncResult*/ asyncResult, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceiveFrom(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.EndPoint*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceiveMessageFrom(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ endPoint, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend$1(/*System.IAsyncResult*/ asyncResult, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndSendFile(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndSendTo(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            /*int */ GetRawSocketOption(/*int*/ optionLevel, /*int*/ optionName, /*System.Span<byte>*/ optionValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ GetSocketOption(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetSocketOption$1(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*byte[]*/ optionValue)
            {
            }
            /*byte[] */ GetSocketOption$2(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*int*/ optionLength)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ IOControl(/*int*/ ioControlCode, /*byte[]?*/ optionInValue, /*byte[]?*/ optionOutValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ IOControl$1(/*System.Net.Sockets.IOControlCode*/ ioControlCode, /*byte[]?*/ optionInValue, /*byte[]?*/ optionOutValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Listen()
            {
            }
            /*void */ Listen$1(/*int*/ backlog)
            {
            }
            /*bool */ Poll(/*int*/ microSeconds, /*System.Net.Sockets.SelectMode*/ mode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Poll$1(/*System.TimeSpan*/ timeout, /*System.Net.Sockets.SelectMode*/ mode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive(/*byte[]*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$3(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$4(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$5(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$6(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$7(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$8(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$9(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$10(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync(/*System.ArraySegment<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$4(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$5(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveAsync$6(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$1(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$2(/*byte[]*/ buffer, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$4(/*System.Span<byte>*/ buffer, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$5(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$6(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ receivedAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$2(/*System.Memory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$3(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveFromAsync$4(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ receivedAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveFromAsync$5(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveMessageFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveMessageFrom$1(/*System.Span<byte>*/ buffer, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$2(/*System.Memory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$3(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveMessageFromAsync$4(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ Select(/*System.Collections.IList?*/ checkRead, /*System.Collections.IList?*/ checkWrite, /*System.Collections.IList?*/ checkError, /*int*/ microSeconds)
            {
            }
            static /*void */ Select$1(/*System.Collections.IList?*/ checkRead, /*System.Collections.IList?*/ checkWrite, /*System.Collections.IList?*/ checkError, /*System.TimeSpan*/ timeout)
            {
            }
            /*int */ Send(/*byte[]*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$3(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$4(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$5(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$6(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$7(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$8(/*System.ReadOnlySpan<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$9(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$10(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync(/*System.ArraySegment<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendAsync$4(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$5(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$6(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SendFile(/*string?*/ fileName)
            {
            }
            /*void */ SendFile$1(/*string?*/ fileName, /*byte[]?*/ preBuffer, /*byte[]?*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags)
            {
            }
            /*void */ SendFile$2(/*string?*/ fileName, /*System.ReadOnlySpan<byte>*/ preBuffer, /*System.ReadOnlySpan<byte>*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags)
            {
            }
            /*System.Threading.Tasks.ValueTask */ SendFileAsync(/*string?*/ fileName, /*System.ReadOnlyMemory<byte>*/ preBuffer, /*System.ReadOnlyMemory<byte>*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ SendFileAsync$1(/*string?*/ fileName, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendPacketsAsync(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$1(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$2(/*byte[]*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$4(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$5(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$6(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ socketAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendToAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendToAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendToAsync$2(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$3(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$4(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$5(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ socketAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetIPProtectionLevel(/*System.Net.Sockets.IPProtectionLevel*/ level)
            {
            }
            /*void */ SetRawSocketOption(/*int*/ optionLevel, /*int*/ optionName, /*System.ReadOnlySpan<byte>*/ optionValue)
            {
            }
            /*void */ SetSocketOption(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*bool*/ optionValue)
            {
            }
            /*void */ SetSocketOption$1(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*byte[]*/ optionValue)
            {
            }
            /*void */ SetSocketOption$2(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*int*/ optionValue)
            {
            }
            /*void */ SetSocketOption$3(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*object*/ optionValue)
            {
            }
            /*void */ Shutdown(/*System.Net.Sockets.SocketShutdown*/ how)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 907085;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4512582,"g":{"r":0,"d":0,"h":25770710861,"f":1},"n":"AddressFamily","d":907085,"h":21475743565,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360645453,"f":1},"n":"Available","d":907085,"h":30065678157,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950580045,"f":1},"s":{"r":0,"d":0,"h":47245547341,"f":1},"n":"Blocking","d":907085,"h":38655612749,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55835481933,"f":1},"n":"Connected","d":907085,"h":51540514637,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64425416525,"f":1},"s":{"r":0,"d":0,"h":68720383821,"f":1},"n":"DontFragment","d":907085,"h":60130449229,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77310318413,"f":1},"s":{"r":0,"d":0,"h":81605285709,"f":1},"n":"DualMode","d":907085,"h":73015351117,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":90195220301,"f":1},"s":{"r":0,"d":0,"h":94490187597,"f":1},"n":"EnableBroadcast","d":907085,"h":85900253005,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":103080122189,"f":1},"s":{"r":0,"d":0,"h":107375089485,"f":1},"n":"ExclusiveAddressUse","d":907085,"h":98785154893,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":115965024077,"f":1},"n":"Handle","d":907085,"h":111670056781,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554958669,"f":1},"n":"IsBound","d":907085,"h":120259991373,"f":1},{"p":382797,"g":{"r":0,"d":0,"h":133144893261,"f":1},"s":{"r":0,"d":0,"h":137439860557,"f":1},"n":"LingerState","d":907085,"h":128849925965,"f":1},{"p":2612038,"g":{"r":0,"d":0,"h":146029795149,"f":1},"n":"LocalEndPoint","d":907085,"h":141734827853,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":154619729741,"f":1},"s":{"r":0,"d":0,"h":158914697037,"f":1},"n":"MulticastLoopback","d":907085,"h":150324762445,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":167504631629,"f":1},"s":{"r":0,"d":0,"h":171799598925,"f":1},"n":"NoDelay","d":907085,"h":163209664333,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":180389533517,"f":33},"n":"OSSupportsIPv4","d":907085,"h":176094566221,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":188979468109,"f":33},"n":"OSSupportsIPv6","d":907085,"h":184684500813,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":197569402701,"f":33},"n":"OSSupportsUnixDomainSockets","d":907085,"h":193274435405,"f":33},{"p":644941,"g":{"r":0,"d":0,"h":206159337293,"f":1},"n":"ProtocolType","d":907085,"h":201864369997,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":214749271885,"f":1},"s":{"r":0,"d":0,"h":219044239181,"f":1},"n":"ReceiveBufferSize","d":907085,"h":210454304589,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":227634173773,"f":1},"s":{"r":0,"d":0,"h":231929141069,"f":1},"n":"ReceiveTimeout","d":907085,"h":223339206477,"f":1},{"p":2612038,"g":{"r":0,"d":0,"h":240519075661,"f":1},"n":"RemoteEndPoint","d":907085,"h":236224108365,"f":1},{"p":710477,"g":{"r":0,"d":0,"h":249109010253,"f":1},"n":"SafeHandle","d":907085,"h":244814042957,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":257698944845,"f":1},"s":{"r":0,"d":0,"h":261993912141,"f":1},"n":"SendBufferSize","d":907085,"h":253403977549,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":270583846733,"f":1},"s":{"r":0,"d":0,"h":274878814029,"f":1},"n":"SendTimeout","d":907085,"h":266288879437,"f":1},{"p":1693517,"g":{"r":0,"d":0,"h":283468748621,"f":1},"n":"SocketType","d":907085,"h":279173781325,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":292058683213,"f":33},"n":"SupportsIPv4","d":907085,"h":287763715917,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SupportsIPv4 has been deprecated. Use OSSupportsIPv4 instead.","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":300648617805,"f":33},"n":"SupportsIPv6","d":907085,"h":296353650509,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SupportsIPv6 has been deprecated. Use OSSupportsIPv6 instead.","t":1310721}]}]},{"p":524289,"g":{"r":0,"d":0,"h":309238552397,"f":1},"s":{"r":0,"d":0,"h":313533519693,"f":1},"n":"Ttl","d":907085,"h":304943585101,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":322123454285,"f":1},"s":{"r":0,"d":0,"h":326418421581,"f":1},"n":"UseOnlyOverlappedIO","d":907085,"h":317828486989,"f":1,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":70909953,"c":8660844545,"a":[{"v":"UseOnlyOverlappedIO has been deprecated and is not supported.","t":1310721}]}]}],"m":[{"r":907085,"n":"Accept","d":907085,"h":330713388877,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"n":"AcceptAsync","d":907085,"h":335008356173,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"acceptSocket","p":907085}],"n":"AcceptAsync","o":"@$1","d":907085,"h":339303323469,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"acceptSocket","p":907085},{"n":"cancellationToken","p":125960193}],"n":"AcceptAsync","o":"@$2","d":907085,"h":343598290765,"f":1},{"r":262145,"p":[{"n":"e","p":972621}],"n":"AcceptAsync","o":"@$3","d":907085,"h":347893258061,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptAsync","o":"@$4","d":907085,"h":352188225357,"f":1},{"r":57016321,"p":[{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginAccept","d":907085,"h":356483192653,"f":1},{"r":57016321,"p":[{"n":"receiveSize","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginAccept","o":"@$1","d":907085,"h":360778159949,"f":1},{"r":57016321,"p":[{"n":"acceptSocket","p":907085},{"n":"receiveSize","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginAccept","o":"@$2","d":907085,"h":365073127245,"f":1},{"r":57016321,"p":[{"n":"remoteEP","p":2612038},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginConnect","d":907085,"h":369368094541,"f":1},{"r":57016321,"p":[{"n":"address","p":3070790},{"n":"port","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$1","d":907085,"h":373663061837,"f":1},{"r":57016321,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$2","d":907085,"h":377958029133,"f":1},{"r":57016321,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$3","d":907085,"h":382252996429,"f":1},{"r":57016321,"p":[{"n":"reuseSocket","p":262145},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginDisconnect","d":907085,"h":386547963725,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1103693},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginReceive","d":907085,"h":390842931021,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1103693},{"n":"errorCode","p":4709190,"f":2},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$1","d":907085,"h":395137898317,"f":1},{"r":57016321,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1103693},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$2","d":907085,"h":399432865613,"f":1},{"r":57016321,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1103693},{"n":"errorCode","p":4709190,"f":2},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$3","d":907085,"h":403727832909,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1103693},{"n":"remoteEP","p":2612038,"f":4},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginReceiveFrom","d":907085,"h":408022800205,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1103693},{"n":"remoteEP","p":2612038,"f":4},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginReceiveMessageFrom","d":907085,"h":412317767501,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1103693},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginSend","d":907085,"h":416612734797,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1103693},{"n":"errorCode","p":4709190,"f":2},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginSend","o":"@$1","d":907085,"h":420907702093,"f":1},{"r":57016321,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1103693},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginSend","o":"@$2","d":907085,"h":425202669389,"f":1},{"r":57016321,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1103693},{"n":"errorCode","p":4709190,"f":2},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginSend","o":"@$3","d":907085,"h":429497636685,"f":1},{"r":57016321,"p":[{"n":"fileName","p":1310721},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginSendFile","d":907085,"h":433792603981,"f":1},{"r":57016321,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":0},{"n":"postBuffer","p":0},{"n":"flags","p":1890125},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginSendFile","o":"@$1","d":907085,"h":438087571277,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1103693},{"n":"remoteEP","p":2612038},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginSendTo","d":907085,"h":442382538573,"f":1},{"r":65537,"p":[{"n":"localEP","p":2612038}],"n":"Bind","d":907085,"h":446677505869,"f":1},{"r":65537,"p":[{"n":"e","p":972621}],"n":"CancelConnectAsync","d":907085,"h":450972473165,"f":33},{"r":65537,"n":"Close","d":907085,"h":455267440461,"f":1},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Close","o":"@$1","d":907085,"h":459562407757,"f":1},{"r":65537,"p":[{"n":"remoteEP","p":2612038}],"n":"Connect","d":907085,"h":463857375053,"f":1},{"r":65537,"p":[{"n":"address","p":3070790},{"n":"port","p":655361}],"n":"Connect","o":"@$1","d":907085,"h":468152342349,"f":1},{"r":65537,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"Connect","o":"@$2","d":907085,"h":472447309645,"f":1},{"r":65537,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$3","d":907085,"h":476742276941,"f":1},{"r":133300225,"p":[{"n":"remoteEP","p":2612038}],"n":"ConnectAsync","d":907085,"h":481037244237,"f":1},{"r":136118273,"p":[{"n":"remoteEP","p":2612038},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":907085,"h":485332211533,"f":1},{"r":133300225,"p":[{"n":"address","p":3070790},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":907085,"h":489627178829,"f":1},{"r":136118273,"p":[{"n":"address","p":3070790},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":907085,"h":493922146125,"f":1},{"r":133300225,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$4","d":907085,"h":498217113421,"f":1},{"r":136118273,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":907085,"h":502512080717,"f":1},{"r":262145,"p":[{"n":"e","p":972621}],"n":"ConnectAsync","o":"@$6","d":907085,"h":506807048013,"f":1},{"r":262145,"p":[{"n":"socketType","p":1693517},{"n":"protocolType","p":644941},{"n":"e","p":972621}],"n":"ConnectAsync","o":"@$7","d":907085,"h":511102015309,"f":33},{"r":133300225,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$8","d":907085,"h":515396982605,"f":1},{"r":136118273,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$9","d":907085,"h":519691949901,"f":1},{"r":65537,"p":[{"n":"reuseSocket","p":262145}],"n":"Disconnect","d":907085,"h":523986917197,"f":1},{"r":136118273,"p":[{"n":"reuseSocket","p":262145},{"n":"cancellationToken","p":125960193,"f":65}],"n":"DisconnectAsync","d":907085,"h":528281884493,"f":1},{"r":262145,"p":[{"n":"e","p":972621}],"n":"DisconnectAsync","o":"@$1","d":907085,"h":532576851789,"f":1},{"r":65537,"n":"Dispose","d":907085,"h":536871819085,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":907085,"h":541166786381,"f":132},{"r":1169229,"p":[{"n":"targetProcessId","p":655361}],"n":"DuplicateAndClose","d":907085,"h":545461753677,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":907085,"p":[{"n":"buffer","p":0,"f":2},{"n":"asyncResult","p":57016321}],"n":"EndAccept","d":907085,"h":549756720973,"f":1},{"r":907085,"p":[{"n":"buffer","p":0,"f":2},{"n":"bytesTransferred","p":655361,"f":2},{"n":"asyncResult","p":57016321}],"n":"EndAccept","o":"@$1","d":907085,"h":554051688269,"f":1},{"r":907085,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAccept","o":"@$2","d":907085,"h":558346655565,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndConnect","d":907085,"h":562641622861,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndDisconnect","d":907085,"h":566936590157,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndReceive","d":907085,"h":571231557453,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321},{"n":"errorCode","p":4709190,"f":2}],"n":"EndReceive","o":"@$1","d":907085,"h":575526524749,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321},{"n":"endPoint","p":2612038,"f":4}],"n":"EndReceiveFrom","d":907085,"h":579821492045,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321},{"n":"socketFlags","p":1103693,"f":4},{"n":"endPoint","p":2612038,"f":4},{"n":"ipPacketInformation","p":186189,"f":2}],"n":"EndReceiveMessageFrom","d":907085,"h":584116459341,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndSend","d":907085,"h":588411426637,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321},{"n":"errorCode","p":4709190,"f":2}],"n":"EndSend","o":"@$1","d":907085,"h":592706393933,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndSendFile","d":907085,"h":597001361229,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndSendTo","d":907085,"h":601296328525,"f":1},{"r":655361,"p":[{"n":"optionLevel","p":655361},{"n":"optionName","p":655361},{"n":"optionValue","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetRawSocketOption","d":907085,"h":609886263117,"f":1},{"r":131073,"p":[{"n":"optionLevel","p":1300301},{"n":"optionName","p":1365837}],"n":"GetSocketOption","d":907085,"h":614181230413,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1300301},{"n":"optionName","p":1365837},{"n":"optionValue","p":0}],"n":"GetSocketOption","o":"@$1","d":907085,"h":618476197709,"f":1},{"r":0,"p":[{"n":"optionLevel","p":1300301},{"n":"optionName","p":1365837},{"n":"optionLength","p":655361}],"n":"GetSocketOption","o":"@$2","d":907085,"h":622771165005,"f":1},{"r":655361,"p":[{"n":"ioControlCode","p":655361},{"n":"optionInValue","p":0},{"n":"optionOutValue","p":0}],"n":"IOControl","d":907085,"h":627066132301,"f":1},{"r":655361,"p":[{"n":"ioControlCode","p":120653},{"n":"optionInValue","p":0},{"n":"optionOutValue","p":0}],"n":"IOControl","o":"@$1","d":907085,"h":631361099597,"f":1},{"r":65537,"n":"Listen","d":907085,"h":635656066893,"f":1},{"r":65537,"p":[{"n":"backlog","p":655361}],"n":"Listen","o":"@$1","d":907085,"h":639951034189,"f":1},{"r":262145,"p":[{"n":"microSeconds","p":655361},{"n":"mode","p":776013}],"n":"Poll","d":907085,"h":644246001485,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793},{"n":"mode","p":776013}],"n":"Poll","o":"@$1","d":907085,"h":648540968781,"f":1},{"r":655361,"p":[{"n":"buffer","p":0}],"n":"Receive","d":907085,"h":652835936077,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1103693}],"n":"Receive","o":"@$1","d":907085,"h":657130903373,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1103693},{"n":"errorCode","p":4709190,"f":2}],"n":"Receive","o":"@$2","d":907085,"h":661425870669,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1103693}],"n":"Receive","o":"@$3","d":907085,"h":665720837965,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1103693}],"n":"Receive","o":"@$4","d":907085,"h":670015805261,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"Receive","o":"@$5","d":907085,"h":674310772557,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1103693}],"n":"Receive","o":"@$6","d":907085,"h":678605739853,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1103693},{"n":"errorCode","p":4709190,"f":2}],"n":"Receive","o":"@$7","d":907085,"h":682900707149,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Receive","o":"@$8","d":907085,"h":687195674445,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693}],"n":"Receive","o":"@$9","d":907085,"h":691490641741,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"errorCode","p":4709190,"f":2}],"n":"Receive","o":"@$10","d":907085,"h":695785609037,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h}],"n":"ReceiveAsync","d":907085,"h":700080576333,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693}],"n":"ReceiveAsync","o":"@$1","d":907085,"h":704375543629,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"ReceiveAsync","o":"@$2","d":907085,"h":708670510925,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1103693}],"n":"ReceiveAsync","o":"@$3","d":907085,"h":712965478221,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$4","d":907085,"h":717260445517,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$5","d":907085,"h":721555412813,"f":1},{"r":262145,"p":[{"n":"e","p":972621}],"n":"ReceiveAsync","o":"@$6","d":907085,"h":725850380109,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1103693},{"n":"remoteEP","p":2612038,"f":4}],"n":"ReceiveFrom","d":907085,"h":730145347405,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1103693},{"n":"remoteEP","p":2612038,"f":4}],"n":"ReceiveFrom","o":"@$1","d":907085,"h":734440314701,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"remoteEP","p":2612038,"f":4}],"n":"ReceiveFrom","o":"@$2","d":907085,"h":738735281997,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1103693},{"n":"remoteEP","p":2612038,"f":4}],"n":"ReceiveFrom","o":"@$3","d":907085,"h":743030249293,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2612038,"f":4}],"n":"ReceiveFrom","o":"@$4","d":907085,"h":747325216589,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"remoteEP","p":2612038,"f":4}],"n":"ReceiveFrom","o":"@$5","d":907085,"h":751620183885,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"receivedAddress","p":4381510}],"n":"ReceiveFrom","o":"@$6","d":907085,"h":755915151181,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2612038}],"n":"ReceiveFromAsync","d":907085,"h":760210118477,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"remoteEndPoint","p":2612038}],"n":"ReceiveFromAsync","o":"@$1","d":907085,"h":764505085773,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2612038},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$2","d":907085,"h":768800053069,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"remoteEndPoint","p":2612038},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$3","d":907085,"h":773095020365,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"receivedAddress","p":4381510},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$4","d":907085,"h":777389987661,"f":1},{"r":262145,"p":[{"n":"e","p":972621}],"n":"ReceiveFromAsync","o":"@$5","d":907085,"h":781684954957,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1103693,"f":4},{"n":"remoteEP","p":2612038,"f":4},{"n":"ipPacketInformation","p":186189,"f":2}],"n":"ReceiveMessageFrom","d":907085,"h":785979922253,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693,"f":4},{"n":"remoteEP","p":2612038,"f":4},{"n":"ipPacketInformation","p":186189,"f":2}],"n":"ReceiveMessageFrom","o":"@$1","d":907085,"h":790274889549,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2612038}],"n":"ReceiveMessageFromAsync","d":907085,"h":794569856845,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"remoteEndPoint","p":2612038}],"n":"ReceiveMessageFromAsync","o":"@$1","d":907085,"h":798864824141,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2612038},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveMessageFromAsync","o":"@$2","d":907085,"h":803159791437,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"remoteEndPoint","p":2612038},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveMessageFromAsync","o":"@$3","d":907085,"h":807454758733,"f":1},{"r":262145,"p":[{"n":"e","p":972621}],"n":"ReceiveMessageFromAsync","o":"@$4","d":907085,"h":811749726029,"f":1},{"r":65537,"p":[{"n":"checkRead","p":31981569},{"n":"checkWrite","p":31981569},{"n":"checkError","p":31981569},{"n":"microSeconds","p":655361}],"n":"Select","d":907085,"h":816044693325,"f":33},{"r":65537,"p":[{"n":"checkRead","p":31981569},{"n":"checkWrite","p":31981569},{"n":"checkError","p":31981569},{"n":"timeout","p":140705793}],"n":"Select","o":"@$1","d":907085,"h":820339660621,"f":33},{"r":655361,"p":[{"n":"buffer","p":0}],"n":"Send","d":907085,"h":824634627917,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1103693}],"n":"Send","o":"@$1","d":907085,"h":828929595213,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1103693},{"n":"errorCode","p":4709190,"f":2}],"n":"Send","o":"@$2","d":907085,"h":833224562509,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1103693}],"n":"Send","o":"@$3","d":907085,"h":837519529805,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1103693}],"n":"Send","o":"@$4","d":907085,"h":841814497101,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"Send","o":"@$5","d":907085,"h":846109464397,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1103693}],"n":"Send","o":"@$6","d":907085,"h":850404431693,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1103693},{"n":"errorCode","p":4709190,"f":2}],"n":"Send","o":"@$7","d":907085,"h":854699398989,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Send","o":"@$8","d":907085,"h":858994366285,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693}],"n":"Send","o":"@$9","d":907085,"h":863289333581,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"errorCode","p":4709190,"f":2}],"n":"Send","o":"@$10","d":907085,"h":867584300877,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h}],"n":"SendAsync","d":907085,"h":871879268173,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693}],"n":"SendAsync","o":"@$1","d":907085,"h":876174235469,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"SendAsync","o":"@$2","d":907085,"h":880469202765,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1103693}],"n":"SendAsync","o":"@$3","d":907085,"h":884764170061,"f":1},{"r":262145,"p":[{"n":"e","p":972621}],"n":"SendAsync","o":"@$4","d":907085,"h":889059137357,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$5","d":907085,"h":893354104653,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$6","d":907085,"h":897649071949,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"SendFile","d":907085,"h":901944039245,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":0},{"n":"postBuffer","p":0},{"n":"flags","p":1890125}],"n":"SendFile","o":"@$1","d":907085,"h":906239006541,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"postBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"flags","p":1890125}],"n":"SendFile","o":"@$2","d":907085,"h":910533973837,"f":1},{"r":136118273,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"postBuffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"flags","p":1890125},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendFileAsync","d":907085,"h":914828941133,"f":1},{"r":136118273,"p":[{"n":"fileName","p":1310721},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendFileAsync","o":"@$1","d":907085,"h":919123908429,"f":1},{"r":262145,"p":[{"n":"e","p":972621}],"n":"SendPacketsAsync","d":907085,"h":923418875725,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1103693},{"n":"remoteEP","p":2612038}],"n":"SendTo","d":907085,"h":927713843021,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1103693},{"n":"remoteEP","p":2612038}],"n":"SendTo","o":"@$1","d":907085,"h":932008810317,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"remoteEP","p":2612038}],"n":"SendTo","o":"@$2","d":907085,"h":936303777613,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1103693},{"n":"remoteEP","p":2612038}],"n":"SendTo","o":"@$3","d":907085,"h":940598744909,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2612038}],"n":"SendTo","o":"@$4","d":907085,"h":944893712205,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"remoteEP","p":2612038}],"n":"SendTo","o":"@$5","d":907085,"h":949188679501,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"socketAddress","p":4381510}],"n":"SendTo","o":"@$6","d":907085,"h":953483646797,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2612038}],"n":"SendToAsync","d":907085,"h":957778614093,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"remoteEP","p":2612038}],"n":"SendToAsync","o":"@$1","d":907085,"h":962073581389,"f":1},{"r":262145,"p":[{"n":"e","p":972621}],"n":"SendToAsync","o":"@$2","d":907085,"h":966368548685,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2612038},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$3","d":907085,"h":970663515981,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"remoteEP","p":2612038},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$4","d":907085,"h":974958483277,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1103693},{"n":"socketAddress","p":4381510},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$5","d":907085,"h":979253450573,"f":1},{"r":65537,"p":[{"n":"level","p":251725}],"n":"SetIPProtectionLevel","d":907085,"h":983548417869,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"optionLevel","p":655361},{"n":"optionName","p":655361},{"n":"optionValue","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"SetRawSocketOption","d":907085,"h":987843385165,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1300301},{"n":"optionName","p":1365837},{"n":"optionValue","p":262145}],"n":"SetSocketOption","d":907085,"h":992138352461,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1300301},{"n":"optionName","p":1365837},{"n":"optionValue","p":0}],"n":"SetSocketOption","o":"@$1","d":907085,"h":996433319757,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1300301},{"n":"optionName","p":1365837},{"n":"optionValue","p":655361}],"n":"SetSocketOption","o":"@$2","d":907085,"h":1000728287053,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1300301},{"n":"optionName","p":1365837},{"n":"optionValue","p":131073}],"n":"SetSocketOption","o":"@$3","d":907085,"h":1005023254349,"f":1},{"r":65537,"p":[{"n":"how","p":1562445}],"n":"Shutdown","d":907085,"h":1009318221645,"f":1}],"c":[{"p":[{"n":"addressFamily","p":4512582},{"n":"socketType","p":1693517},{"n":"protocolType","p":644941}],"n":".ctor","o":"$ctor$1","d":907085,"h":4295874381,"f":1},{"p":[{"n":"handle","p":710477}],"n":".ctor","o":"$ctor$2","d":907085,"h":8590841677,"f":1},{"p":[{"n":"socketInformation","p":1169229}],"n":".ctor","o":"$ctor$3","d":907085,"h":12885808973,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":[{"n":"socketType","p":1693517},{"n":"protocolType","p":644941}],"n":".ctor","o":"$ctor$4","d":907085,"h":17180776269,"f":1}],"i":[57540609],"h":907085}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.Socket`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.TcpClient", ($self) => class TcpClient extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ hostname, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Active(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Client()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ set Client(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Connected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ get LingerState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ set LingerState(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get NoDelay()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set NoDelay(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$1(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$2(/*string*/ host, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close()
            {
            }
            /*void */ Connect(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
            }
            /*void */ Connect$1(/*System.Net.IPAddress[]*/ ipAddresses, /*int*/ port)
            {
            }
            /*void */ Connect$2(/*System.Net.IPEndPoint*/ remoteEP)
            {
            }
            /*void */ Connect$3(/*string*/ hostname, /*int*/ port)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Net.IPEndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*System.Net.IPEndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$6(/*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$7(/*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ EndConnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*System.Net.Sockets.NetworkStream */ GetStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1759053;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25771562829,"f":4},"s":{"r":0,"d":0,"h":30066530125,"f":4},"n":"Active","d":1759053,"h":21476595533,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":38656464717,"f":1},"n":"Available","d":1759053,"h":34361497421,"f":1},{"p":907085,"g":{"r":0,"d":0,"h":47246399309,"f":1},"s":{"r":0,"d":0,"h":51541366605,"f":1},"n":"Client","d":1759053,"h":42951432013,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131301197,"f":1},"n":"Connected","d":1759053,"h":55836333901,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721235789,"f":1},"s":{"r":0,"d":0,"h":73016203085,"f":1},"n":"ExclusiveAddressUse","d":1759053,"h":64426268493,"f":1},{"p":382797,"g":{"r":0,"d":0,"h":81606137677,"f":1},"s":{"r":0,"d":0,"h":85901104973,"f":1},"n":"LingerState","d":1759053,"h":77311170381,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94491039565,"f":1},"s":{"r":0,"d":0,"h":98786006861,"f":1},"n":"NoDelay","d":1759053,"h":90196072269,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":107375941453,"f":1},"s":{"r":0,"d":0,"h":111670908749,"f":1},"n":"ReceiveBufferSize","d":1759053,"h":103080974157,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":120260843341,"f":1},"s":{"r":0,"d":0,"h":124555810637,"f":1},"n":"ReceiveTimeout","d":1759053,"h":115965876045,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":133145745229,"f":1},"s":{"r":0,"d":0,"h":137440712525,"f":1},"n":"SendBufferSize","d":1759053,"h":128850777933,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":146030647117,"f":1},"s":{"r":0,"d":0,"h":150325614413,"f":1},"n":"SendTimeout","d":1759053,"h":141735679821,"f":1}],"m":[{"r":57016321,"p":[{"n":"address","p":3070790},{"n":"port","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginConnect","d":1759053,"h":154620581709,"f":1},{"r":57016321,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$1","d":1759053,"h":158915549005,"f":1},{"r":57016321,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$2","d":1759053,"h":163210516301,"f":1},{"r":65537,"n":"Close","d":1759053,"h":167505483597,"f":1},{"r":65537,"p":[{"n":"address","p":3070790},{"n":"port","p":655361}],"n":"Connect","d":1759053,"h":171800450893,"f":1},{"r":65537,"p":[{"n":"ipAddresses","p":0},{"n":"port","p":655361}],"n":"Connect","o":"@$1","d":1759053,"h":176095418189,"f":1},{"r":65537,"p":[{"n":"remoteEP","p":3332934}],"n":"Connect","o":"@$2","d":1759053,"h":180390385485,"f":1},{"r":65537,"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$3","d":1759053,"h":184685352781,"f":1},{"r":133300225,"p":[{"n":"address","p":3070790},{"n":"port","p":655361}],"n":"ConnectAsync","d":1759053,"h":188980320077,"f":1},{"r":136118273,"p":[{"n":"address","p":3070790},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":1759053,"h":193275287373,"f":1},{"r":133300225,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":1759053,"h":197570254669,"f":1},{"r":136118273,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":1759053,"h":201865221965,"f":1},{"r":133300225,"p":[{"n":"remoteEP","p":3332934}],"n":"ConnectAsync","o":"@$4","d":1759053,"h":206160189261,"f":1},{"r":136118273,"p":[{"n":"remoteEP","p":3332934},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":1759053,"h":210455156557,"f":1},{"r":133300225,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$6","d":1759053,"h":214750123853,"f":1},{"r":136118273,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$7","d":1759053,"h":219045091149,"f":1},{"r":65537,"n":"Dispose","d":1759053,"h":223340058445,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1759053,"h":227635025741,"f":132},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndConnect","d":1759053,"h":231929993037,"f":1},{"r":513869,"n":"GetStream","d":1759053,"h":240519927629,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1759053,"h":4296726349,"f":1},{"p":[{"n":"localEP","p":3332934}],"n":".ctor","o":"$ctor$2","d":1759053,"h":8591693645,"f":1},{"p":[{"n":"family","p":4512582}],"n":".ctor","o":"$ctor$3","d":1759053,"h":12886660941,"f":1},{"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$4","d":1759053,"h":17181628237,"f":1}],"i":[57540609],"h":1759053}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.TcpClient`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.TcpListener", ($self) => class TcpListener extends $.$spc.System.Object
        {
            $ctor$1(/*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ localaddr, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ get LocalEndpoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Server()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ AcceptSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptSocketAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptSocketAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TcpClient */ AcceptTcpClient()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.TcpClient> */ AcceptTcpClientAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.TcpClient> */ AcceptTcpClientAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AllowNatTraversal(/*bool*/ allowed)
            {
            }
            /*System.IAsyncResult */ BeginAcceptSocket(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAcceptTcpClient(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Sockets.TcpListener */ Create(/*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*System.Net.Sockets.Socket */ EndAcceptSocket(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TcpClient */ EndAcceptTcpClient(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Pending()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Start()
            {
            }
            /*void */ Start$1(/*int*/ backlog)
            {
            }
            /*void */ Stop()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1824589;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476661069,"f":4},"n":"Active","d":1824589,"h":17181693773,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":30066595661,"f":1},"s":{"r":0,"d":0,"h":34361562957,"f":1},"n":"ExclusiveAddressUse","d":1824589,"h":25771628365,"f":1},{"p":2612038,"g":{"r":0,"d":0,"h":42951497549,"f":1},"n":"LocalEndpoint","d":1824589,"h":38656530253,"f":1},{"p":907085,"g":{"r":0,"d":0,"h":51541432141,"f":1},"n":"Server","d":1824589,"h":47246464845,"f":1}],"m":[{"r":907085,"n":"AcceptSocket","d":1824589,"h":55836399437,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"n":"AcceptSocketAsync","d":1824589,"h":60131366733,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptSocketAsync","o":"@$1","d":1824589,"h":64426334029,"f":1},{"r":1759053,"n":"AcceptTcpClient","d":1824589,"h":68721301325,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.TcpClient).$h,"n":"AcceptTcpClientAsync","d":1824589,"h":73016268621,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.TcpClient).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptTcpClientAsync","o":"@$1","d":1824589,"h":77311235917,"f":1},{"r":65537,"p":[{"n":"allowed","p":262145}],"n":"AllowNatTraversal","d":1824589,"h":81606203213,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":57016321,"p":[{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginAcceptSocket","d":1824589,"h":85901170509,"f":1},{"r":57016321,"p":[{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginAcceptTcpClient","d":1824589,"h":90196137805,"f":1},{"r":1824589,"p":[{"n":"port","p":655361}],"n":"Create","d":1824589,"h":94491105101,"f":33},{"r":65537,"n":"Dispose","d":1824589,"h":98786072397,"f":1},{"r":907085,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAcceptSocket","d":1824589,"h":103081039693,"f":1},{"r":1759053,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAcceptTcpClient","d":1824589,"h":107376006989,"f":1},{"r":262145,"n":"Pending","d":1824589,"h":111670974285,"f":1},{"r":65537,"n":"Start","d":1824589,"h":115965941581,"f":1},{"r":65537,"p":[{"n":"backlog","p":655361}],"n":"Start","o":"@$1","d":1824589,"h":120260908877,"f":1},{"r":65537,"n":"Stop","d":1824589,"h":124555876173,"f":1}],"c":[{"p":[{"n":"port","p":655361}],"n":".ctor","o":"$ctor$1","d":1824589,"h":4296791885,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor has been deprecated. Use TcpListener(IPAddress localaddr, int port) instead.","t":1310721}]}]},{"p":[{"n":"localaddr","p":3070790},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":1824589,"h":8591759181,"f":1},{"p":[{"n":"localEP","p":3332934}],"n":".ctor","o":"$ctor$3","d":1824589,"h":12886726477,"f":1}],"i":[57540609],"h":1824589}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.TcpListener`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.UdpClient", ($self) => class UdpClient extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*int*/ port, /*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$6(/*string*/ hostname, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Active(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Client()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ set Client(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DontFragment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DontFragment(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableBroadcast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableBroadcast(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get MulticastLoopback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MulticastLoopback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ get Ttl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ set Ttl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AllowNatTraversal(/*bool*/ allowed)
            {
            }
            /*System.IAsyncResult */ BeginReceive(/*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend(/*byte[]*/ datagram, /*int*/ bytes, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$1(/*byte[]*/ datagram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$2(/*byte[]*/ datagram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close()
            {
            }
            /*void */ Connect(/*System.Net.IPAddress*/ addr, /*int*/ port)
            {
            }
            /*void */ Connect$1(/*System.Net.IPEndPoint*/ endPoint)
            {
            }
            /*void */ Connect$2(/*string*/ hostname, /*int*/ port)
            {
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ DropMulticastGroup(/*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ DropMulticastGroup$1(/*System.Net.IPAddress*/ multicastAddr, /*int*/ ifindex)
            {
            }
            /*byte[] */ EndReceive(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.IPEndPoint?*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ JoinMulticastGroup(/*int*/ ifindex, /*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ JoinMulticastGroup$1(/*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ JoinMulticastGroup$2(/*System.Net.IPAddress*/ multicastAddr, /*int*/ timeToLive)
            {
            }
            /*void */ JoinMulticastGroup$3(/*System.Net.IPAddress*/ multicastAddr, /*System.Net.IPAddress*/ localAddress)
            {
            }
            /*byte[] */ Receive(/*ref System.Net.IPEndPoint?*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.UdpReceiveResult> */ ReceiveAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.UdpReceiveResult> */ ReceiveAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send(/*byte[]*/ dgram, /*int*/ bytes)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$1(/*byte[]*/ dgram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$2(/*byte[]*/ dgram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$3(/*System.ReadOnlySpan<byte>*/ datagram)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$4(/*System.ReadOnlySpan<byte>*/ datagram, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$5(/*System.ReadOnlySpan<byte>*/ datagram, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync(/*byte[]*/ datagram, /*int*/ bytes)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*byte[]*/ datagram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$2(/*byte[]*/ datagram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$3(/*System.ReadOnlyMemory<byte>*/ datagram, /*System.Net.IPEndPoint?*/ endPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$4(/*System.ReadOnlyMemory<byte>*/ datagram, /*string?*/ hostname, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$5(/*System.ReadOnlyMemory<byte>*/ datagram, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1955661;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34361694029,"f":4},"s":{"r":0,"d":0,"h":38656661325,"f":4},"n":"Active","d":1955661,"h":30066726733,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":47246595917,"f":1},"n":"Available","d":1955661,"h":42951628621,"f":1},{"p":907085,"g":{"r":0,"d":0,"h":55836530509,"f":1},"s":{"r":0,"d":0,"h":60131497805,"f":1},"n":"Client","d":1955661,"h":51541563213,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721432397,"f":1},"s":{"r":0,"d":0,"h":73016399693,"f":1},"n":"DontFragment","d":1955661,"h":64426465101,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81606334285,"f":1},"s":{"r":0,"d":0,"h":85901301581,"f":1},"n":"EnableBroadcast","d":1955661,"h":77311366989,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94491236173,"f":1},"s":{"r":0,"d":0,"h":98786203469,"f":1},"n":"ExclusiveAddressUse","d":1955661,"h":90196268877,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":107376138061,"f":1},"s":{"r":0,"d":0,"h":111671105357,"f":1},"n":"MulticastLoopback","d":1955661,"h":103081170765,"f":1},{"p":524289,"g":{"r":0,"d":0,"h":120261039949,"f":1},"s":{"r":0,"d":0,"h":124556007245,"f":1},"n":"Ttl","d":1955661,"h":115966072653,"f":1}],"m":[{"r":65537,"p":[{"n":"allowed","p":262145}],"n":"AllowNatTraversal","d":1955661,"h":128850974541,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":57016321,"p":[{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginReceive","d":1955661,"h":133145941837,"f":1},{"r":57016321,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginSend","d":1955661,"h":137440909133,"f":1},{"r":57016321,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3332934},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginSend","o":"@$1","d":1955661,"h":141735876429,"f":1},{"r":57016321,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginSend","o":"@$2","d":1955661,"h":146030843725,"f":1},{"r":65537,"n":"Close","d":1955661,"h":150325811021,"f":1},{"r":65537,"p":[{"n":"addr","p":3070790},{"n":"port","p":655361}],"n":"Connect","d":1955661,"h":154620778317,"f":1},{"r":65537,"p":[{"n":"endPoint","p":3332934}],"n":"Connect","o":"@$1","d":1955661,"h":158915745613,"f":1},{"r":65537,"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$2","d":1955661,"h":163210712909,"f":1},{"r":65537,"n":"Dispose","d":1955661,"h":167505680205,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1955661,"h":171800647501,"f":132},{"r":65537,"p":[{"n":"multicastAddr","p":3070790}],"n":"DropMulticastGroup","d":1955661,"h":176095614797,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3070790},{"n":"ifindex","p":655361}],"n":"DropMulticastGroup","o":"@$1","d":1955661,"h":180390582093,"f":1},{"r":0,"p":[{"n":"asyncResult","p":57016321},{"n":"remoteEP","p":3332934,"f":4}],"n":"EndReceive","d":1955661,"h":184685549389,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndSend","d":1955661,"h":188980516685,"f":1},{"r":65537,"p":[{"n":"ifindex","p":655361},{"n":"multicastAddr","p":3070790}],"n":"JoinMulticastGroup","d":1955661,"h":193275483981,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3070790}],"n":"JoinMulticastGroup","o":"@$1","d":1955661,"h":197570451277,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3070790},{"n":"timeToLive","p":655361}],"n":"JoinMulticastGroup","o":"@$2","d":1955661,"h":201865418573,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3070790},{"n":"localAddress","p":3070790}],"n":"JoinMulticastGroup","o":"@$3","d":1955661,"h":206160385869,"f":1},{"r":0,"p":[{"n":"remoteEP","p":3332934,"f":4}],"n":"Receive","d":1955661,"h":210455353165,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h,"n":"ReceiveAsync","d":1955661,"h":214750320461,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReceiveAsync","o":"@$1","d":1955661,"h":219045287757,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361}],"n":"Send","d":1955661,"h":223340255053,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3332934}],"n":"Send","o":"@$1","d":1955661,"h":227635222349,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Send","o":"@$2","d":1955661,"h":231930189645,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Send","o":"@$3","d":1955661,"h":236225156941,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"endPoint","p":3332934}],"n":"Send","o":"@$4","d":1955661,"h":240520124237,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Send","o":"@$5","d":1955661,"h":244815091533,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361}],"n":"SendAsync","d":1955661,"h":249110058829,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3332934}],"n":"SendAsync","o":"@$1","d":1955661,"h":253405026125,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"SendAsync","o":"@$2","d":1955661,"h":257699993421,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"endPoint","p":3332934},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$3","d":1955661,"h":261994960717,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"hostname","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$4","d":1955661,"h":266289928013,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$5","d":1955661,"h":270584895309,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1955661,"h":4296922957,"f":1},{"p":[{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":1955661,"h":8591890253,"f":1},{"p":[{"n":"port","p":655361},{"n":"family","p":4512582}],"n":".ctor","o":"$ctor$3","d":1955661,"h":12886857549,"f":1},{"p":[{"n":"localEP","p":3332934}],"n":".ctor","o":"$ctor$4","d":1955661,"h":17181824845,"f":1},{"p":[{"n":"family","p":4512582}],"n":".ctor","o":"$ctor$5","d":1955661,"h":21476792141,"f":1},{"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$6","d":1955661,"h":25771759437,"f":1}],"i":[57540609],"h":1955661}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.UdpClient`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketInformation", ($self) => class SocketInformation extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.Sockets.SocketInformationOptions */ get Options()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketInformationOptions */ set Options(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ get ProtocolInformation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ set ProtocolInformation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 1169229;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1234765,"g":{"r":0,"d":0,"h":17181038413,"f":1},"s":{"r":0,"d":0,"h":21476005709,"f":1},"n":"Options","d":1169229,"h":12886071117,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30065940301,"f":1},"s":{"r":0,"d":0,"h":34360907597,"f":1},"n":"ProtocolInformation","d":1169229,"h":25770973005,"f":1}],"l":[{"t":131073,"n":"_dummy","d":1169229,"h":4296136525,"f":2},{"t":655361,"n":"_dummyPrimitive","d":1169229,"h":8591103821,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1169229,"h":38655874893,"f":1}],"h":1169229}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketInformation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketReceiveFromResult", ($self) => class SocketReceiveFromResult extends $.$spc.System.ValueType
        {
            /*int*/  get ReceivedBytes() { return this.$getField(0, 4); }
            /*int*/  set ReceivedBytes(value) { this.$setField(0, 4, value); }
            /*System.Net.EndPoint*/  get RemoteEndPoint() { return this.$getField(4, 4); }
            /*System.Net.EndPoint*/  set RemoteEndPoint(value) { this.$setField(4, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ReceivedBytes = this.ReceivedBytes;
                copy.RemoteEndPoint = this.RemoteEndPoint;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ReceivedBytes = 0;
                this.RemoteEndPoint = null;
            }
            static $h = 1431373;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"ReceivedBytes","d":1431373,"h":4296398669,"f":1},{"t":2612038,"n":"RemoteEndPoint","d":1431373,"h":8591365965,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1431373,"h":12886333261,"f":1}],"h":1431373}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketReceiveFromResult`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketReceiveMessageFromResult", ($self) => class SocketReceiveMessageFromResult extends $.$spc.System.ValueType
        {
            /*System.Net.Sockets.IPPacketInformation*/  get PacketInformation() { return this.$getField(0, 8); }
            /*System.Net.Sockets.IPPacketInformation*/  set PacketInformation(value) { this.$setField(0, 8, value); }
            /*int*/  get ReceivedBytes() { return this.$getField(8, 4); }
            /*int*/  set ReceivedBytes(value) { this.$setField(8, 4, value); }
            /*System.Net.EndPoint*/  get RemoteEndPoint() { return this.$getField(12, 4); }
            /*System.Net.EndPoint*/  set RemoteEndPoint(value) { this.$setField(12, 4, value); }
            /*System.Net.Sockets.SocketFlags*/  get SocketFlags() { return this.$getField(16, 4); }
            /*System.Net.Sockets.SocketFlags*/  set SocketFlags(value) { this.$setField(16, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.PacketInformation = this.PacketInformation.Clone();
                copy.ReceivedBytes = this.ReceivedBytes;
                copy.RemoteEndPoint = this.RemoteEndPoint;
                copy.SocketFlags = this.SocketFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.PacketInformation = $.$default($.$sns.System.Net.Sockets.IPPacketInformation);
                this.ReceivedBytes = 0;
                this.RemoteEndPoint = null;
                this.SocketFlags = 0;
            }
            static $h = 1496909;
            static $z = 20;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":186189,"n":"PacketInformation","d":1496909,"h":4296464205,"f":1},{"t":655361,"n":"ReceivedBytes","d":1496909,"h":8591431501,"f":1},{"t":2612038,"n":"RemoteEndPoint","d":1496909,"h":12886398797,"f":1},{"t":1103693,"n":"SocketFlags","d":1496909,"h":17181366093,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1496909,"h":21476333389,"f":1}],"h":1496909}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketReceiveMessageFromResult`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.UnixDomainSocketEndPoint", ($self) => class UnixDomainSocketEndPoint extends $.$snp.System.Net.EndPoint
        {
            $ctor$2(/*string*/ path)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Sockets.AddressFamily */ get AddressFamily()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ Create(/*System.Net.SocketAddress*/ socketAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.GetHashCode.apply(this, arguments); }
            /*System.Net.SocketAddress */ Serialize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.ToString.apply(this, arguments); }
            static $h = 2086733;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2612038,"p":[{"p":4512582,"g":{"r":0,"d":0,"h":12886988621,"f":32769},"n":"AddressFamily","d":2086733,"h":8592021325,"f":32769}],"m":[{"r":2612038,"p":[{"n":"socketAddress","p":4381510}],"n":"Create","d":2086733,"h":17181955917,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2086733,"h":21476923213,"f":32769},{"r":655361,"n":"GetHashCode","d":2086733,"h":25771890509,"f":32769},{"r":4381510,"n":"Serialize","d":2086733,"h":30066857805,"f":32769},{"r":1310721,"n":"ToString","d":2086733,"h":34361825101,"f":32769}],"c":[{"p":[{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$2","d":2086733,"h":4297054029,"f":1}],"h":2086733}; }
            static get $b() { return $.$snp.System.Net.EndPoint; }
            static get $fullName() { return `System.Net.Sockets.UnixDomainSocketEndPoint`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IPPacketInformation", ($self) => class IPPacketInformation extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.IPAddress */ get Address()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Interface()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Sockets.IPPacketInformation*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.IPPacketInformation.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.IPPacketInformation.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Sockets.IPPacketInformation*/ packetInformation1, /*System.Net.Sockets.IPPacketInformation*/ packetInformation2)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Sockets.IPPacketInformation*/ packetInformation1, /*System.Net.Sockets.IPPacketInformation*/ packetInformation2)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IEquatable<System.Net.Sockets.IPPacketInformation>.Equals(System.Net.Sockets.IPPacketInformation)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 186189;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":3070790,"g":{"r":0,"d":0,"h":17180055373,"f":1},"n":"Address","d":186189,"h":12885088077,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25769989965,"f":1},"n":"Interface","d":186189,"h":21475022669,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":186189}],"n":"Equals","o":"@$2","d":186189,"h":30064957261,"f":1},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":186189,"h":34359924557,"f":32769},{"r":655361,"n":"GetHashCode","d":186189,"h":38654891853,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":186189,"h":4295153485,"f":2},{"t":655361,"n":"_dummyPrimitive","d":186189,"h":8590120781,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":186189,"h":51539793741,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.IPPacketInformation).$h],"h":186189}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.IPPacketInformation) ]; }
            static get $fullName() { return `System.Net.Sockets.IPPacketInformation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.UdpReceiveResult", ($self) => class UdpReceiveResult extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$2(/*byte[]*/ buffer, /*System.Net.IPEndPoint*/ remoteEndPoint)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*byte[] */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Sockets.UdpReceiveResult*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.UdpReceiveResult.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.UdpReceiveResult.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Sockets.UdpReceiveResult*/ left, /*System.Net.Sockets.UdpReceiveResult*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Sockets.UdpReceiveResult*/ left, /*System.Net.Sockets.UdpReceiveResult*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IEquatable<System.Net.Sockets.UdpReceiveResult>.Equals(System.Net.Sockets.UdpReceiveResult)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 2021197;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":0,"g":{"r":0,"d":0,"h":21476857677,"f":1},"n":"Buffer","d":2021197,"h":17181890381,"f":1},{"p":3332934,"g":{"r":0,"d":0,"h":30066792269,"f":1},"n":"RemoteEndPoint","d":2021197,"h":25771824973,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":2021197}],"n":"Equals","o":"@$2","d":2021197,"h":34361759565,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2021197,"h":38656726861,"f":32769},{"r":655361,"n":"GetHashCode","d":2021197,"h":42951694157,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":2021197,"h":4296988493,"f":2},{"t":655361,"n":"_dummyPrimitive","d":2021197,"h":8591955789,"f":2}],"c":[{"p":[{"n":"buffer","p":0},{"n":"remoteEndPoint","p":3332934}],"n":".ctor","o":"$ctor$2","d":2021197,"h":12886923085,"f":1},{"n":".ctor","o":"$ctor$3","d":2021197,"h":55836596045,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h],"h":2021197}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.UdpReceiveResult) ]; }
            static get $fullName() { return `System.Net.Sockets.UdpReceiveResult`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.NetworkStream", ($self) => class NetworkStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.Net.Sockets.Socket*/ socket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.Sockets.Socket*/ socket, /*bool*/ ownsSocket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*System.Net.Sockets.Socket*/ socket, /*System.IO.FileAccess*/ access)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$6(/*System.Net.Sockets.Socket*/ socket, /*System.IO.FileAccess*/ access, /*bool*/ ownsSocket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DataAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Readable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Readable(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Socket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Writeable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Writeable(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close$1(/*int*/ timeout)
            {
            }
            /*void */ Close$2(/*System.TimeSpan*/ timeout)
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 513869;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770317645,"f":32769},"n":"CanRead","d":513869,"h":21475350349,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360252237,"f":32769},"n":"CanSeek","d":513869,"h":30065284941,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950186829,"f":32769},"n":"CanTimeout","d":513869,"h":38655219533,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51540121421,"f":32769},"n":"CanWrite","d":513869,"h":47245154125,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60130056013,"f":129},"n":"DataAvailable","d":513869,"h":55835088717,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":68719990605,"f":32769},"n":"Length","d":513869,"h":64425023309,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":77309925197,"f":32769},"s":{"r":0,"d":0,"h":81604892493,"f":32769},"n":"Position","d":513869,"h":73014957901,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":90194827085,"f":4},"s":{"r":0,"d":0,"h":94489794381,"f":4},"n":"Readable","d":513869,"h":85899859789,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":103079728973,"f":32769},"s":{"r":0,"d":0,"h":107374696269,"f":32769},"n":"ReadTimeout","d":513869,"h":98784761677,"f":32769},{"p":907085,"g":{"r":0,"d":0,"h":115964630861,"f":1},"n":"Socket","d":513869,"h":111669663565,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554565453,"f":4},"s":{"r":0,"d":0,"h":128849532749,"f":4},"n":"Writeable","d":513869,"h":120259598157,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":137439467341,"f":32769},"s":{"r":0,"d":0,"h":141734434637,"f":32769},"n":"WriteTimeout","d":513869,"h":133144500045,"f":32769}],"m":[{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginRead","d":513869,"h":146029401933,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginWrite","d":513869,"h":150324369229,"f":32769},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Close","o":"@$1","d":513869,"h":154619336525,"f":1},{"r":65537,"p":[{"n":"timeout","p":140705793}],"n":"Close","o":"@$2","d":513869,"h":158914303821,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":513869,"h":163209271117,"f":32772},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":513869,"h":167504238413,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":513869,"h":171799205709,"f":32769},{"r":65537,"n":"Flush","d":513869,"h":180389140301,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":513869,"h":184684107597,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":513869,"h":188979074893,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":513869,"h":193274042189,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":513869,"h":197569009485,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":513869,"h":201863976781,"f":32769},{"r":655361,"n":"ReadByte","d":513869,"h":206158944077,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":513869,"h":210453911373,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":513869,"h":214748878669,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":513869,"h":219043845965,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":513869,"h":223338813261,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":513869,"h":227633780557,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":513869,"h":231928747853,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":513869,"h":236223715149,"f":32769}],"c":[{"p":[{"n":"socket","p":907085}],"n":".ctor","o":"$ctor$3","d":513869,"h":4295481165,"f":1},{"p":[{"n":"socket","p":907085},{"n":"ownsSocket","p":262145}],"n":".ctor","o":"$ctor$4","d":513869,"h":8590448461,"f":1},{"p":[{"n":"socket","p":907085},{"n":"access","p":59768833}],"n":".ctor","o":"$ctor$5","d":513869,"h":12885415757,"f":1},{"p":[{"n":"socket","p":907085},{"n":"access","p":59768833},{"n":"ownsSocket","p":262145}],"n":".ctor","o":"$ctor$6","d":513869,"h":17180383053,"f":1}],"i":[57540609,56950785],"h":513869}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.NetworkStream`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IOControlCode", ($self) => class IOControlCode extends $.$spc.System.Enum
        {
            static EnableCircularQueuing = 671088642n;
            static Flush = 671088644n;
            static AddressListChange = 671088663n;
            static DataToRead = 1074030207n;
            static OobDataRead = 1074033415n;
            static GetBroadcastAddress = 1207959557n;
            static AddressListQuery = 1207959574n;
            static QueryTargetPnpHandle = 1207959576n;
            static AsyncIO = 2147772029n;
            static NonBlockingIO = 2147772030n;
            static AssociateHandle = 2281701377n;
            static MultipointLoopback = 2281701385n;
            static MulticastScope = 2281701386n;
            static SetQos = 2281701387n;
            static SetGroupQos = 2281701388n;
            static RoutingInterfaceChange = 2281701397n;
            static NamespaceChange = 2281701401n;
            static ReceiveAll = 2550136833n;
            static ReceiveAllMulticast = 2550136834n;
            static ReceiveAllIgmpMulticast = 2550136835n;
            static KeepAliveValues = 2550136836n;
            static AbsorbRouterAlert = 2550136837n;
            static UnicastInterface = 2550136838n;
            static LimitBroadcasts = 2550136839n;
            static BindToInterface = 2550136840n;
            static MulticastInterface = 2550136841n;
            static AddMulticastGroupOnInterface = 2550136842n;
            static DeleteMulticastGroupFromInterface = 2550136843n;
            static GetExtensionFunctionPointer = 3355443206n;
            static GetQos = 3355443207n;
            static GetGroupQos = 3355443208n;
            static TranslateHandle = 3355443213n;
            static RoutingInterfaceQuery = 3355443220n;
            static AddressListSort = 3355443225n;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "EnableCircularQueuing": 671088642n,
                    "Flush": 671088644n,
                    "AddressListChange": 671088663n,
                    "DataToRead": 1074030207n,
                    "OobDataRead": 1074033415n,
                    "GetBroadcastAddress": 1207959557n,
                    "AddressListQuery": 1207959574n,
                    "QueryTargetPnpHandle": 1207959576n,
                    "AsyncIO": 2147772029n,
                    "NonBlockingIO": 2147772030n,
                    "AssociateHandle": 2281701377n,
                    "MultipointLoopback": 2281701385n,
                    "MulticastScope": 2281701386n,
                    "SetQos": 2281701387n,
                    "SetGroupQos": 2281701388n,
                    "RoutingInterfaceChange": 2281701397n,
                    "NamespaceChange": 2281701401n,
                    "ReceiveAll": 2550136833n,
                    "ReceiveAllMulticast": 2550136834n,
                    "ReceiveAllIgmpMulticast": 2550136835n,
                    "KeepAliveValues": 2550136836n,
                    "AbsorbRouterAlert": 2550136837n,
                    "UnicastInterface": 2550136838n,
                    "LimitBroadcasts": 2550136839n,
                    "BindToInterface": 2550136840n,
                    "MulticastInterface": 2550136841n,
                    "AddMulticastGroupOnInterface": 2550136842n,
                    "DeleteMulticastGroupFromInterface": 2550136843n,
                    "GetExtensionFunctionPointer": 3355443206n,
                    "GetQos": 3355443207n,
                    "GetGroupQos": 3355443208n,
                    "TranslateHandle": 3355443213n,
                    "RoutingInterfaceQuery": 3355443220n,
                    "AddressListSort": 3355443225n
                };
            }
            static $h = 120653;
            static $z = 8;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int64; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":917505,"l":[{"t":120653,"n":"EnableCircularQueuing","d":120653,"h":4295087949,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"Flush","d":120653,"h":8590055245,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"AddressListChange","d":120653,"h":12885022541,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"DataToRead","d":120653,"h":17179989837,"f":33},{"t":120653,"n":"OobDataRead","d":120653,"h":21474957133,"f":33},{"t":120653,"n":"GetBroadcastAddress","d":120653,"h":25769924429,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"AddressListQuery","d":120653,"h":30064891725,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"QueryTargetPnpHandle","d":120653,"h":34359859021,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"AsyncIO","d":120653,"h":38654826317,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"NonBlockingIO","d":120653,"h":42949793613,"f":33},{"t":120653,"n":"AssociateHandle","d":120653,"h":47244760909,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"MultipointLoopback","d":120653,"h":51539728205,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"MulticastScope","d":120653,"h":55834695501,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"SetQos","d":120653,"h":60129662797,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"SetGroupQos","d":120653,"h":64424630093,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"RoutingInterfaceChange","d":120653,"h":68719597389,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"NamespaceChange","d":120653,"h":73014564685,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"ReceiveAll","d":120653,"h":77309531981,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"ReceiveAllMulticast","d":120653,"h":81604499277,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"ReceiveAllIgmpMulticast","d":120653,"h":85899466573,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"KeepAliveValues","d":120653,"h":90194433869,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"AbsorbRouterAlert","d":120653,"h":94489401165,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"UnicastInterface","d":120653,"h":98784368461,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"LimitBroadcasts","d":120653,"h":103079335757,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"BindToInterface","d":120653,"h":107374303053,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"MulticastInterface","d":120653,"h":111669270349,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"AddMulticastGroupOnInterface","d":120653,"h":115964237645,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"DeleteMulticastGroupFromInterface","d":120653,"h":120259204941,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"GetExtensionFunctionPointer","d":120653,"h":124554172237,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"GetQos","d":120653,"h":128849139533,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"GetGroupQos","d":120653,"h":133144106829,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"TranslateHandle","d":120653,"h":137439074125,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"RoutingInterfaceQuery","d":120653,"h":141734041421,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":120653,"n":"AddressListSort","d":120653,"h":146029008717,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":120653,"h":150323976013,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":120653}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.IOControlCode`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IPProtectionLevel", ($self) => class IPProtectionLevel extends $.$spc.System.Enum
        {
            static Unspecified = -1;
            static Unrestricted = 10;
            static EdgeRestricted = 20;
            static Restricted = 30;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unspecified": -1n,
                    "Unrestricted": 10n,
                    "EdgeRestricted": 20n,
                    "Restricted": 30n
                };
            }
            static $h = 251725;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":251725,"n":"Unspecified","d":251725,"h":4295219021,"f":33},{"t":251725,"n":"Unrestricted","d":251725,"h":8590186317,"f":33},{"t":251725,"n":"EdgeRestricted","d":251725,"h":12885153613,"f":33},{"t":251725,"n":"Restricted","d":251725,"h":17180120909,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":251725,"h":21475088205,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":251725}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.IPProtectionLevel`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.ProtocolFamily", ($self) => class ProtocolFamily extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static Unspecified = 0;
            static Unix = 1;
            static InterNetwork = 2;
            static ImpLink = 3;
            static Pup = 4;
            static Chaos = 5;
            static Ipx = 6;
            static NS = 6;
            static Iso = 7;
            static Osi = 7;
            static Ecma = 8;
            static DataKit = 9;
            static Ccitt = 10;
            static Sna = 11;
            static DecNet = 12;
            static DataLink = 13;
            static Lat = 14;
            static HyperChannel = 15;
            static AppleTalk = 16;
            static NetBios = 17;
            static VoiceView = 18;
            static FireFox = 19;
            static Banyan = 21;
            static Atm = 22;
            static InterNetworkV6 = 23;
            static Cluster = 24;
            static Ieee12844 = 25;
            static Irda = 26;
            static NetworkDesigners = 28;
            static Max = 29;
            static Packet = 65536;
            static ControllerAreaNetwork = 65537;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Unspecified": 0n,
                    "Unix": 1n,
                    "InterNetwork": 2n,
                    "ImpLink": 3n,
                    "Pup": 4n,
                    "Chaos": 5n,
                    "Ipx": 6n,
                    "NS": 6n,
                    "Iso": 7n,
                    "Osi": 7n,
                    "Ecma": 8n,
                    "DataKit": 9n,
                    "Ccitt": 10n,
                    "Sna": 11n,
                    "DecNet": 12n,
                    "DataLink": 13n,
                    "Lat": 14n,
                    "HyperChannel": 15n,
                    "AppleTalk": 16n,
                    "NetBios": 17n,
                    "VoiceView": 18n,
                    "FireFox": 19n,
                    "Banyan": 21n,
                    "Atm": 22n,
                    "InterNetworkV6": 23n,
                    "Cluster": 24n,
                    "Ieee12844": 25n,
                    "Irda": 26n,
                    "NetworkDesigners": 28n,
                    "Max": 29n,
                    "Packet": 65536n,
                    "ControllerAreaNetwork": 65537n
                };
            }
            static $h = 579405;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":579405,"n":"Unknown","d":579405,"h":4295546701,"f":33},{"t":579405,"n":"Unspecified","d":579405,"h":8590513997,"f":33},{"t":579405,"n":"Unix","d":579405,"h":12885481293,"f":33},{"t":579405,"n":"InterNetwork","d":579405,"h":17180448589,"f":33},{"t":579405,"n":"ImpLink","d":579405,"h":21475415885,"f":33},{"t":579405,"n":"Pup","d":579405,"h":25770383181,"f":33},{"t":579405,"n":"Chaos","d":579405,"h":30065350477,"f":33},{"t":579405,"n":"Ipx","d":579405,"h":34360317773,"f":33},{"t":579405,"n":"NS","d":579405,"h":38655285069,"f":33},{"t":579405,"n":"Iso","d":579405,"h":42950252365,"f":33},{"t":579405,"n":"Osi","d":579405,"h":47245219661,"f":33},{"t":579405,"n":"Ecma","d":579405,"h":51540186957,"f":33},{"t":579405,"n":"DataKit","d":579405,"h":55835154253,"f":33},{"t":579405,"n":"Ccitt","d":579405,"h":60130121549,"f":33},{"t":579405,"n":"Sna","d":579405,"h":64425088845,"f":33},{"t":579405,"n":"DecNet","d":579405,"h":68720056141,"f":33},{"t":579405,"n":"DataLink","d":579405,"h":73015023437,"f":33},{"t":579405,"n":"Lat","d":579405,"h":77309990733,"f":33},{"t":579405,"n":"HyperChannel","d":579405,"h":81604958029,"f":33},{"t":579405,"n":"AppleTalk","d":579405,"h":85899925325,"f":33},{"t":579405,"n":"NetBios","d":579405,"h":90194892621,"f":33},{"t":579405,"n":"VoiceView","d":579405,"h":94489859917,"f":33},{"t":579405,"n":"FireFox","d":579405,"h":98784827213,"f":33},{"t":579405,"n":"Banyan","d":579405,"h":103079794509,"f":33},{"t":579405,"n":"Atm","d":579405,"h":107374761805,"f":33},{"t":579405,"n":"InterNetworkV6","d":579405,"h":111669729101,"f":33},{"t":579405,"n":"Cluster","d":579405,"h":115964696397,"f":33},{"t":579405,"n":"Ieee12844","d":579405,"h":120259663693,"f":33},{"t":579405,"n":"Irda","d":579405,"h":124554630989,"f":33},{"t":579405,"n":"NetworkDesigners","d":579405,"h":128849598285,"f":33},{"t":579405,"n":"Max","d":579405,"h":133144565581,"f":33},{"t":579405,"n":"Packet","d":579405,"h":137439532877,"f":33},{"t":579405,"n":"ControllerAreaNetwork","d":579405,"h":141734500173,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":579405,"h":146029467469,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":579405}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.ProtocolFamily`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.ProtocolType", ($self) => class ProtocolType extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static IP = 0;
            static IPv6HopByHopOptions = 0;
            static Unspecified = 0;
            static Icmp = 1;
            static Igmp = 2;
            static Ggp = 3;
            static IPv4 = 4;
            static Tcp = 6;
            static Pup = 12;
            static Udp = 17;
            static Idp = 22;
            static IPv6 = 41;
            static IPv6RoutingHeader = 43;
            static IPv6FragmentHeader = 44;
            static IPSecEncapsulatingSecurityPayload = 50;
            static IPSecAuthenticationHeader = 51;
            static IcmpV6 = 58;
            static IPv6NoNextHeader = 59;
            static IPv6DestinationOptions = 60;
            static ND = 77;
            static Raw = 255;
            static Ipx = 1000;
            static Spx = 1256;
            static SpxII = 1257;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "IP": 0n,
                    "IPv6HopByHopOptions": 0n,
                    "Unspecified": 0n,
                    "Icmp": 1n,
                    "Igmp": 2n,
                    "Ggp": 3n,
                    "IPv4": 4n,
                    "Tcp": 6n,
                    "Pup": 12n,
                    "Udp": 17n,
                    "Idp": 22n,
                    "IPv6": 41n,
                    "IPv6RoutingHeader": 43n,
                    "IPv6FragmentHeader": 44n,
                    "IPSecEncapsulatingSecurityPayload": 50n,
                    "IPSecAuthenticationHeader": 51n,
                    "IcmpV6": 58n,
                    "IPv6NoNextHeader": 59n,
                    "IPv6DestinationOptions": 60n,
                    "ND": 77n,
                    "Raw": 255n,
                    "Ipx": 1000n,
                    "Spx": 1256n,
                    "SpxII": 1257n
                };
            }
            static $h = 644941;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":644941,"n":"Unknown","d":644941,"h":4295612237,"f":33},{"t":644941,"n":"IP","d":644941,"h":8590579533,"f":33},{"t":644941,"n":"IPv6HopByHopOptions","d":644941,"h":12885546829,"f":33},{"t":644941,"n":"Unspecified","d":644941,"h":17180514125,"f":33},{"t":644941,"n":"Icmp","d":644941,"h":21475481421,"f":33},{"t":644941,"n":"Igmp","d":644941,"h":25770448717,"f":33},{"t":644941,"n":"Ggp","d":644941,"h":30065416013,"f":33},{"t":644941,"n":"IPv4","d":644941,"h":34360383309,"f":33},{"t":644941,"n":"Tcp","d":644941,"h":38655350605,"f":33},{"t":644941,"n":"Pup","d":644941,"h":42950317901,"f":33},{"t":644941,"n":"Udp","d":644941,"h":47245285197,"f":33},{"t":644941,"n":"Idp","d":644941,"h":51540252493,"f":33},{"t":644941,"n":"IPv6","d":644941,"h":55835219789,"f":33},{"t":644941,"n":"IPv6RoutingHeader","d":644941,"h":60130187085,"f":33},{"t":644941,"n":"IPv6FragmentHeader","d":644941,"h":64425154381,"f":33},{"t":644941,"n":"IPSecEncapsulatingSecurityPayload","d":644941,"h":68720121677,"f":33},{"t":644941,"n":"IPSecAuthenticationHeader","d":644941,"h":73015088973,"f":33},{"t":644941,"n":"IcmpV6","d":644941,"h":77310056269,"f":33},{"t":644941,"n":"IPv6NoNextHeader","d":644941,"h":81605023565,"f":33},{"t":644941,"n":"IPv6DestinationOptions","d":644941,"h":85899990861,"f":33},{"t":644941,"n":"ND","d":644941,"h":90194958157,"f":33},{"t":644941,"n":"Raw","d":644941,"h":94489925453,"f":33},{"t":644941,"n":"Ipx","d":644941,"h":98784892749,"f":33},{"t":644941,"n":"Spx","d":644941,"h":103079860045,"f":33},{"t":644941,"n":"SpxII","d":644941,"h":107374827341,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":644941,"h":111669794637,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":644941}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.ProtocolType`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SelectMode", ($self) => class SelectMode extends $.$spc.System.Enum
        {
            static SelectRead = 0;
            static SelectWrite = 1;
            static SelectError = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "SelectRead": 0n,
                    "SelectWrite": 1n,
                    "SelectError": 2n
                };
            }
            static $h = 776013;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":776013,"n":"SelectRead","d":776013,"h":4295743309,"f":33},{"t":776013,"n":"SelectWrite","d":776013,"h":8590710605,"f":33},{"t":776013,"n":"SelectError","d":776013,"h":12885677901,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":776013,"h":17180645197,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":776013}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SelectMode`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketAsyncOperation", ($self) => class SocketAsyncOperation extends $.$spc.System.Enum
        {
            static None = 0;
            static Accept = 1;
            static Connect = 2;
            static Disconnect = 3;
            static Receive = 4;
            static ReceiveFrom = 5;
            static ReceiveMessageFrom = 6;
            static Send = 7;
            static SendPackets = 8;
            static SendTo = 9;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Accept": 1n,
                    "Connect": 2n,
                    "Disconnect": 3n,
                    "Receive": 4n,
                    "ReceiveFrom": 5n,
                    "ReceiveMessageFrom": 6n,
                    "Send": 7n,
                    "SendPackets": 8n,
                    "SendTo": 9n
                };
            }
            static $h = 1038157;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1038157,"n":"None","d":1038157,"h":4296005453,"f":33},{"t":1038157,"n":"Accept","d":1038157,"h":8590972749,"f":33},{"t":1038157,"n":"Connect","d":1038157,"h":12885940045,"f":33},{"t":1038157,"n":"Disconnect","d":1038157,"h":17180907341,"f":33},{"t":1038157,"n":"Receive","d":1038157,"h":21475874637,"f":33},{"t":1038157,"n":"ReceiveFrom","d":1038157,"h":25770841933,"f":33},{"t":1038157,"n":"ReceiveMessageFrom","d":1038157,"h":30065809229,"f":33},{"t":1038157,"n":"Send","d":1038157,"h":34360776525,"f":33},{"t":1038157,"n":"SendPackets","d":1038157,"h":38655743821,"f":33},{"t":1038157,"n":"SendTo","d":1038157,"h":42950711117,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1038157,"h":47245678413,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1038157}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketAsyncOperation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketFlags", ($self) => class SocketFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static OutOfBand = 1;
            static Peek = 2;
            static DontRoute = 4;
            static Truncated = 256;
            static ControlDataTruncated = 512;
            static Broadcast = 1024;
            static Multicast = 2048;
            static Partial = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OutOfBand": 1n,
                    "Peek": 2n,
                    "DontRoute": 4n,
                    "Truncated": 256n,
                    "ControlDataTruncated": 512n,
                    "Broadcast": 1024n,
                    "Multicast": 2048n,
                    "Partial": 32768n
                };
            }
            static $h = 1103693;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1103693,"n":"None","d":1103693,"h":4296070989,"f":33},{"t":1103693,"n":"OutOfBand","d":1103693,"h":8591038285,"f":33},{"t":1103693,"n":"Peek","d":1103693,"h":12886005581,"f":33},{"t":1103693,"n":"DontRoute","d":1103693,"h":17180972877,"f":33},{"t":1103693,"n":"Truncated","d":1103693,"h":21475940173,"f":33},{"t":1103693,"n":"ControlDataTruncated","d":1103693,"h":25770907469,"f":33},{"t":1103693,"n":"Broadcast","d":1103693,"h":30065874765,"f":33},{"t":1103693,"n":"Multicast","d":1103693,"h":34360842061,"f":33},{"t":1103693,"n":"Partial","d":1103693,"h":38655809357,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1103693,"h":42950776653,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1103693,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketFlags`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketInformationOptions", ($self) => class SocketInformationOptions extends $.$spc.System.Enum
        {
            static NonBlocking = 1;
            static Connected = 2;
            static Listening = 4;
            static UseOnlyOverlappedIO = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NonBlocking": 1n,
                    "Connected": 2n,
                    "Listening": 4n,
                    "UseOnlyOverlappedIO": 8n
                };
            }
            static $h = 1234765;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1234765,"n":"NonBlocking","d":1234765,"h":4296202061,"f":33},{"t":1234765,"n":"Connected","d":1234765,"h":8591169357,"f":33},{"t":1234765,"n":"Listening","d":1234765,"h":12886136653,"f":33},{"t":1234765,"n":"UseOnlyOverlappedIO","d":1234765,"h":17181103949,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":70909953,"c":8660844545,"a":[{"v":"SocketInformationOptions.UseOnlyOverlappedIO has been deprecated and is not supported.","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":1234765,"h":21476071245,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1234765,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketInformationOptions`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketOptionLevel", ($self) => class SocketOptionLevel extends $.$spc.System.Enum
        {
            static IP = 0;
            static Tcp = 6;
            static Udp = 17;
            static IPv6 = 41;
            static Socket = 65535;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "IP": 0n,
                    "Tcp": 6n,
                    "Udp": 17n,
                    "IPv6": 41n,
                    "Socket": 65535n
                };
            }
            static $h = 1300301;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1300301,"n":"IP","d":1300301,"h":4296267597,"f":33},{"t":1300301,"n":"Tcp","d":1300301,"h":8591234893,"f":33},{"t":1300301,"n":"Udp","d":1300301,"h":12886202189,"f":33},{"t":1300301,"n":"IPv6","d":1300301,"h":17181169485,"f":33},{"t":1300301,"n":"Socket","d":1300301,"h":21476136781,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1300301,"h":25771104077,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1300301}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketOptionLevel`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketOptionName", ($self) => class SocketOptionName extends $.$spc.System.Enum
        {
            static DontLinger = -129;
            static ExclusiveAddressUse = -5;
            static Debug = 1;
            static IPOptions = 1;
            static NoChecksum = 1;
            static NoDelay = 1;
            static AcceptConnection = 2;
            static BsdUrgent = 2;
            static Expedited = 2;
            static HeaderIncluded = 2;
            static TcpKeepAliveTime = 3;
            static TypeOfService = 3;
            static IpTimeToLive = 4;
            static ReuseAddress = 4;
            static KeepAlive = 8;
            static MulticastInterface = 9;
            static MulticastTimeToLive = 10;
            static MulticastLoopback = 11;
            static AddMembership = 12;
            static DropMembership = 13;
            static DontFragment = 14;
            static AddSourceMembership = 15;
            static FastOpen = 15;
            static DontRoute = 16;
            static DropSourceMembership = 16;
            static TcpKeepAliveRetryCount = 16;
            static BlockSource = 17;
            static TcpKeepAliveInterval = 17;
            static UnblockSource = 18;
            static PacketInformation = 19;
            static ChecksumCoverage = 20;
            static HopLimit = 21;
            static IPProtectionLevel = 23;
            static IPv6Only = 27;
            static Broadcast = 32;
            static UseLoopback = 64;
            static Linger = 128;
            static OutOfBandInline = 256;
            static SendBuffer = 4097;
            static ReceiveBuffer = 4098;
            static SendLowWater = 4099;
            static ReceiveLowWater = 4100;
            static SendTimeout = 4101;
            static ReceiveTimeout = 4102;
            static Error = 4103;
            static Type = 4104;
            static ReuseUnicastPort = 12295;
            static UpdateAcceptContext = 28683;
            static UpdateConnectContext = 28688;
            static MaxConnections = 2147483647;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "DontLinger": -129n,
                    "ExclusiveAddressUse": -5n,
                    "Debug": 1n,
                    "IPOptions": 1n,
                    "NoChecksum": 1n,
                    "NoDelay": 1n,
                    "AcceptConnection": 2n,
                    "BsdUrgent": 2n,
                    "Expedited": 2n,
                    "HeaderIncluded": 2n,
                    "TcpKeepAliveTime": 3n,
                    "TypeOfService": 3n,
                    "IpTimeToLive": 4n,
                    "ReuseAddress": 4n,
                    "KeepAlive": 8n,
                    "MulticastInterface": 9n,
                    "MulticastTimeToLive": 10n,
                    "MulticastLoopback": 11n,
                    "AddMembership": 12n,
                    "DropMembership": 13n,
                    "DontFragment": 14n,
                    "AddSourceMembership": 15n,
                    "FastOpen": 15n,
                    "DontRoute": 16n,
                    "DropSourceMembership": 16n,
                    "TcpKeepAliveRetryCount": 16n,
                    "BlockSource": 17n,
                    "TcpKeepAliveInterval": 17n,
                    "UnblockSource": 18n,
                    "PacketInformation": 19n,
                    "ChecksumCoverage": 20n,
                    "HopLimit": 21n,
                    "IPProtectionLevel": 23n,
                    "IPv6Only": 27n,
                    "Broadcast": 32n,
                    "UseLoopback": 64n,
                    "Linger": 128n,
                    "OutOfBandInline": 256n,
                    "SendBuffer": 4097n,
                    "ReceiveBuffer": 4098n,
                    "SendLowWater": 4099n,
                    "ReceiveLowWater": 4100n,
                    "SendTimeout": 4101n,
                    "ReceiveTimeout": 4102n,
                    "Error": 4103n,
                    "Type": 4104n,
                    "ReuseUnicastPort": 12295n,
                    "UpdateAcceptContext": 28683n,
                    "UpdateConnectContext": 28688n,
                    "MaxConnections": 2147483647n
                };
            }
            static $h = 1365837;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1365837,"n":"DontLinger","d":1365837,"h":4296333133,"f":33},{"t":1365837,"n":"ExclusiveAddressUse","d":1365837,"h":8591300429,"f":33},{"t":1365837,"n":"Debug","d":1365837,"h":12886267725,"f":33},{"t":1365837,"n":"IPOptions","d":1365837,"h":17181235021,"f":33},{"t":1365837,"n":"NoChecksum","d":1365837,"h":21476202317,"f":33},{"t":1365837,"n":"NoDelay","d":1365837,"h":25771169613,"f":33},{"t":1365837,"n":"AcceptConnection","d":1365837,"h":30066136909,"f":33},{"t":1365837,"n":"BsdUrgent","d":1365837,"h":34361104205,"f":33},{"t":1365837,"n":"Expedited","d":1365837,"h":38656071501,"f":33},{"t":1365837,"n":"HeaderIncluded","d":1365837,"h":42951038797,"f":33},{"t":1365837,"n":"TcpKeepAliveTime","d":1365837,"h":47246006093,"f":33},{"t":1365837,"n":"TypeOfService","d":1365837,"h":51540973389,"f":33},{"t":1365837,"n":"IpTimeToLive","d":1365837,"h":55835940685,"f":33},{"t":1365837,"n":"ReuseAddress","d":1365837,"h":60130907981,"f":33},{"t":1365837,"n":"KeepAlive","d":1365837,"h":64425875277,"f":33},{"t":1365837,"n":"MulticastInterface","d":1365837,"h":68720842573,"f":33},{"t":1365837,"n":"MulticastTimeToLive","d":1365837,"h":73015809869,"f":33},{"t":1365837,"n":"MulticastLoopback","d":1365837,"h":77310777165,"f":33},{"t":1365837,"n":"AddMembership","d":1365837,"h":81605744461,"f":33},{"t":1365837,"n":"DropMembership","d":1365837,"h":85900711757,"f":33},{"t":1365837,"n":"DontFragment","d":1365837,"h":90195679053,"f":33},{"t":1365837,"n":"AddSourceMembership","d":1365837,"h":94490646349,"f":33},{"t":1365837,"n":"FastOpen","d":1365837,"h":98785613645,"f":33},{"t":1365837,"n":"DontRoute","d":1365837,"h":103080580941,"f":33},{"t":1365837,"n":"DropSourceMembership","d":1365837,"h":107375548237,"f":33},{"t":1365837,"n":"TcpKeepAliveRetryCount","d":1365837,"h":111670515533,"f":33},{"t":1365837,"n":"BlockSource","d":1365837,"h":115965482829,"f":33},{"t":1365837,"n":"TcpKeepAliveInterval","d":1365837,"h":120260450125,"f":33},{"t":1365837,"n":"UnblockSource","d":1365837,"h":124555417421,"f":33},{"t":1365837,"n":"PacketInformation","d":1365837,"h":128850384717,"f":33},{"t":1365837,"n":"ChecksumCoverage","d":1365837,"h":133145352013,"f":33},{"t":1365837,"n":"HopLimit","d":1365837,"h":137440319309,"f":33},{"t":1365837,"n":"IPProtectionLevel","d":1365837,"h":141735286605,"f":33},{"t":1365837,"n":"IPv6Only","d":1365837,"h":146030253901,"f":33},{"t":1365837,"n":"Broadcast","d":1365837,"h":150325221197,"f":33},{"t":1365837,"n":"UseLoopback","d":1365837,"h":154620188493,"f":33},{"t":1365837,"n":"Linger","d":1365837,"h":158915155789,"f":33},{"t":1365837,"n":"OutOfBandInline","d":1365837,"h":163210123085,"f":33},{"t":1365837,"n":"SendBuffer","d":1365837,"h":167505090381,"f":33},{"t":1365837,"n":"ReceiveBuffer","d":1365837,"h":171800057677,"f":33},{"t":1365837,"n":"SendLowWater","d":1365837,"h":176095024973,"f":33},{"t":1365837,"n":"ReceiveLowWater","d":1365837,"h":180389992269,"f":33},{"t":1365837,"n":"SendTimeout","d":1365837,"h":184684959565,"f":33},{"t":1365837,"n":"ReceiveTimeout","d":1365837,"h":188979926861,"f":33},{"t":1365837,"n":"Error","d":1365837,"h":193274894157,"f":33},{"t":1365837,"n":"Type","d":1365837,"h":197569861453,"f":33},{"t":1365837,"n":"ReuseUnicastPort","d":1365837,"h":201864828749,"f":33},{"t":1365837,"n":"UpdateAcceptContext","d":1365837,"h":206159796045,"f":33},{"t":1365837,"n":"UpdateConnectContext","d":1365837,"h":210454763341,"f":33},{"t":1365837,"n":"MaxConnections","d":1365837,"h":214749730637,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1365837,"h":219044697933,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1365837}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketOptionName`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketShutdown", ($self) => class SocketShutdown extends $.$spc.System.Enum
        {
            static Receive = 0;
            static Send = 1;
            static Both = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Receive": 0n,
                    "Send": 1n,
                    "Both": 2n
                };
            }
            static $h = 1562445;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1562445,"n":"Receive","d":1562445,"h":4296529741,"f":33},{"t":1562445,"n":"Send","d":1562445,"h":8591497037,"f":33},{"t":1562445,"n":"Both","d":1562445,"h":12886464333,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1562445,"h":17181431629,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1562445}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketShutdown`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketType", ($self) => class SocketType extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static Stream = 1;
            static Dgram = 2;
            static Raw = 3;
            static Rdm = 4;
            static Seqpacket = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Stream": 1n,
                    "Dgram": 2n,
                    "Raw": 3n,
                    "Rdm": 4n,
                    "Seqpacket": 5n
                };
            }
            static $h = 1693517;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1693517,"n":"Unknown","d":1693517,"h":4296660813,"f":33},{"t":1693517,"n":"Stream","d":1693517,"h":8591628109,"f":33},{"t":1693517,"n":"Dgram","d":1693517,"h":12886595405,"f":33},{"t":1693517,"n":"Raw","d":1693517,"h":17181562701,"f":33},{"t":1693517,"n":"Rdm","d":1693517,"h":21476529997,"f":33},{"t":1693517,"n":"Seqpacket","d":1693517,"h":25771497293,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1693517,"h":30066464589,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1693517}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketType`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.TransmitFileOptions", ($self) => class TransmitFileOptions extends $.$spc.System.Enum
        {
            static UseDefaultWorkerThread = 0;
            static Disconnect = 1;
            static ReuseSocket = 2;
            static WriteBehind = 4;
            static UseSystemThread = 16;
            static UseKernelApc = 32;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "UseDefaultWorkerThread": 0n,
                    "Disconnect": 1n,
                    "ReuseSocket": 2n,
                    "WriteBehind": 4n,
                    "UseSystemThread": 16n,
                    "UseKernelApc": 32n
                };
            }
            static $h = 1890125;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1890125,"n":"UseDefaultWorkerThread","d":1890125,"h":4296857421,"f":33},{"t":1890125,"n":"Disconnect","d":1890125,"h":8591824717,"f":33},{"t":1890125,"n":"ReuseSocket","d":1890125,"h":12886792013,"f":33},{"t":1890125,"n":"WriteBehind","d":1890125,"h":17181759309,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":1890125,"n":"UseSystemThread","d":1890125,"h":21476726605,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":1890125,"n":"UseKernelApc","d":1890125,"h":25771693901,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":1890125,"h":30066661197,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1890125,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.TransmitFileOptions`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SafeSocketHandle", ($self) => class SafeSocketHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*nint*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 710477;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7405569,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180579661,"f":32769},"n":"IsInvalid","d":710477,"h":12885612365,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":710477,"h":21475546957,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":710477,"h":4295677773,"f":1},{"p":[{"n":"preexistingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":710477,"h":8590645069,"f":1}],"i":[57540609],"h":710477}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.SafeSocketHandle`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SocketAsyncEventArgs", ($self) => class SocketAsyncEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ unsafeSuppressExecutionContextFlow)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Sockets.Socket? */ get AcceptSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket? */ set AcceptSocket(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[]? */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IList<System.ArraySegment<byte>>? */ get BufferList()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IList<System.ArraySegment<byte>>? */ set BufferList(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get BytesTransferred()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Exception? */ get ConnectByNameError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket? */ get ConnectSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DisconnectReuseSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DisconnectReuseSocket(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketAsyncOperation */ get LastOperation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Memory<byte> */ get MemoryBuffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Offset()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.IPPacketInformation */ get ReceiveMessageFromPacketInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ set RemoteEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SendPacketsElement[]? */ get SendPacketsElements()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SendPacketsElement[]? */ set SendPacketsElements(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TransmitFileOptions */ get SendPacketsFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TransmitFileOptions */ set SendPacketsFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendPacketsSendSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendPacketsSendSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketError */ get SocketError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketError */ set SocketError(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketFlags */ get SocketFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketFlags */ set SocketFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ get UserToken()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ set UserToken(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.EventHandler<System.Net.Sockets.SocketAsyncEventArgs>?*/ add_Completed(value)
            {
            }
            /*System.EventHandler<System.Net.Sockets.SocketAsyncEventArgs>?*/ remove_Completed(value)
            {
            }
            /*void */ Dispose()
            {
            }
            $dtor()
            {
            }
            /*void */ OnCompleted(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
            }
            /*void */ SetBuffer(/*byte[]?*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ SetBuffer$1(/*int*/ offset, /*int*/ count)
            {
            }
            /*void */ SetBuffer$2(/*System.Memory<byte>*/ buffer)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 972621;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":907085,"g":{"r":0,"d":0,"h":17180841805,"f":1},"s":{"r":0,"d":0,"h":21475809101,"f":1},"n":"AcceptSocket","d":972621,"h":12885874509,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30065743693,"f":1},"n":"Buffer","d":972621,"h":25770776397,"f":1},{"p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h,"g":{"r":0,"d":0,"h":38655678285,"f":1},"s":{"r":0,"d":0,"h":42950645581,"f":1},"n":"BufferList","d":972621,"h":34360710989,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51540580173,"f":1},"n":"BytesTransferred","d":972621,"h":47245612877,"f":1},{"p":47251457,"g":{"r":0,"d":0,"h":60130514765,"f":1},"n":"ConnectByNameError","d":972621,"h":55835547469,"f":1},{"p":907085,"g":{"r":0,"d":0,"h":68720449357,"f":1},"n":"ConnectSocket","d":972621,"h":64425482061,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":77310383949,"f":1},"n":"Count","d":972621,"h":73015416653,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85900318541,"f":1},"s":{"r":0,"d":0,"h":90195285837,"f":1},"n":"DisconnectReuseSocket","d":972621,"h":81605351245,"f":1},{"p":1038157,"g":{"r":0,"d":0,"h":98785220429,"f":1},"n":"LastOperation","d":972621,"h":94490253133,"f":1},{"p":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":107375155021,"f":1},"n":"MemoryBuffer","d":972621,"h":103080187725,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":115965089613,"f":1},"n":"Offset","d":972621,"h":111670122317,"f":1},{"p":186189,"g":{"r":0,"d":0,"h":124555024205,"f":1},"n":"ReceiveMessageFromPacketInfo","d":972621,"h":120260056909,"f":1},{"p":2612038,"g":{"r":0,"d":0,"h":133144958797,"f":1},"s":{"r":0,"d":0,"h":137439926093,"f":1},"n":"RemoteEndPoint","d":972621,"h":128849991501,"f":1},{"p":0,"g":{"r":0,"d":0,"h":146029860685,"f":1},"s":{"r":0,"d":0,"h":150324827981,"f":1},"n":"SendPacketsElements","d":972621,"h":141734893389,"f":1},{"p":1890125,"g":{"r":0,"d":0,"h":158914762573,"f":1},"s":{"r":0,"d":0,"h":163209729869,"f":1},"n":"SendPacketsFlags","d":972621,"h":154619795277,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":171799664461,"f":1},"s":{"r":0,"d":0,"h":176094631757,"f":1},"n":"SendPacketsSendSize","d":972621,"h":167504697165,"f":1},{"p":4709190,"g":{"r":0,"d":0,"h":184684566349,"f":1},"s":{"r":0,"d":0,"h":188979533645,"f":1},"n":"SocketError","d":972621,"h":180389599053,"f":1},{"p":1103693,"g":{"r":0,"d":0,"h":197569468237,"f":1},"s":{"r":0,"d":0,"h":201864435533,"f":1},"n":"SocketFlags","d":972621,"h":193274500941,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":210454370125,"f":1},"s":{"r":0,"d":0,"h":214749337421,"f":1},"n":"UserToken","d":972621,"h":206159402829,"f":1}],"m":[{"r":65537,"n":"Dispose","d":972621,"h":231929206605,"f":1},{"r":65537,"p":[{"n":"e","p":972621}],"n":"OnCompleted","d":972621,"h":240519141197,"f":132},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"SetBuffer","d":972621,"h":244814108493,"f":1},{"r":65537,"p":[{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"SetBuffer","o":"@$1","d":972621,"h":249109075789,"f":1},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h}],"n":"SetBuffer","o":"@$2","d":972621,"h":253404043085,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":972621,"h":4295939917,"f":1},{"p":[{"n":"unsafeSuppressExecutionContextFlow","p":262145}],"n":".ctor","o":"$ctor$3","d":972621,"h":8590907213,"f":1}],"e":[{"e":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h}],"n":"add_Completed","d":972621,"h":223339272013,"f":1},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h}],"n":"remove_Completed","d":972621,"h":227634239309,"f":1},"n":"Completed","d":972621,"h":219044304717,"f":1}],"i":[57540609],"h":972621}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.SocketAsyncEventArgs`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution"))