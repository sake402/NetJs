
//--TRIMMABLE-BOUNDARY-START(48)
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stee, $scsl, $snv, $sri, $sl, $stt, $sttp, $sdd, $snp, $ssc, $sspw, $sto, $snnr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Sockets", 
    {
  "h": 48,
  "f": "System.Net.Sockets",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Net.Sockets",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Net.Sockets",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(262192)
        $asm.$cls("$sns.System.Net.Sockets.IPv6MulticastOption", ($self) => class IPv6MulticastOption extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590196784)
            $ctor$2(/*System.Net.IPAddress*/ group)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590196784);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196784)
            
            //--TRIMMABLE-BOUNDARY-START(4295229488)
            $ctor$1(/*System.Net.IPAddress*/ group, /*long*/ ifindex)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229488);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229488)
            
            //--TRIMMABLE-BOUNDARY-START(30065033264)
            /*System.Net.IPAddress */ get Group()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress */ set Group(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949935152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065033264)
            
            //--TRIMMABLE-BOUNDARY-START(34360000560)
            /*long */ get InterfaceIndex()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770065968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set InterfaceIndex(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539869744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360000560)
            
            static $h = 262192;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065033264),
    {
      "p": 3014703,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180131376,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42949935152,
        "f": 83886081
      },
      "n": "Group",
      "d": 262192,
      "h": 30065033264,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065033264),
//--TRIMMABLE-BOUNDARY-START(34360000560),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770065968,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51539869744,
        "f": 83886081
      },
      "n": "InterfaceIndex",
      "d": 262192,
      "h": 34360000560,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360000560)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590196784),
    {
      "p": [
        {
          "n": "group",
          "p": 3014703
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262192,
      "h": 8590196784,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590196784),
//--TRIMMABLE-BOUNDARY-START(4295229488),
    {
      "p": [
        {
          "n": "group",
          "p": 3014703
        },
        {
          "n": "ifindex",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262192,
      "h": 4295229488,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229488)
  ],
  "h": 262192
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Sockets.IPv6MulticastOption`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262192)
        
        
        //--TRIMMABLE-BOUNDARY-START(327728)
        $asm.$cls("$sns.System.Net.Sockets.LingerOption", ($self) => class LingerOption extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295295024)
            $ctor$1(/*bool*/ enable, /*int*/ seconds)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295024);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295024)
            
            //--TRIMMABLE-BOUNDARY-START(8590262320)
            /*bool */ get Enabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Enabled(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244967984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590262320)
            
            //--TRIMMABLE-BOUNDARY-START(38655033392)
            /*int */ get LingerTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065098800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set LingerTime(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834902576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655033392)
            
            //--TRIMMABLE-BOUNDARY-START(12885229616)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ comparand)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sns.System.Net.Sockets.LingerOption.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(12885229616)
            
            //--TRIMMABLE-BOUNDARY-START(34360066096)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.LingerOption.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(34360066096)
            
            static $h = 327728;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590262320),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475164208,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244967984,
        "f": 83886081
      },
      "n": "Enabled",
      "d": 327728,
      "h": 8590262320,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590262320),
//--TRIMMABLE-BOUNDARY-START(38655033392),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065098800,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834902576,
        "f": 83886081
      },
      "n": "LingerTime",
      "d": 327728,
      "h": 38655033392,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655033392)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885229616),
    {
      "r": 262145,
      "p": [
        {
          "n": "comparand",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 327728,
      "h": 12885229616,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885229616),
//--TRIMMABLE-BOUNDARY-START(34360066096),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 327728,
      "h": 34360066096,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360066096)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295024),
    {
      "p": [
        {
          "n": "enable",
          "p": 262145
        },
        {
          "n": "seconds",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327728,
      "h": 4295295024,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295024)
  ],
  "h": 327728
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Sockets.LingerOption`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327728)
        
        
        //--TRIMMABLE-BOUNDARY-START(393264)
        $asm.$cls("$sns.System.Net.Sockets.MulticastOption", ($self) => class MulticastOption extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885295152)
            $ctor$3(/*System.Net.IPAddress*/ group)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295152);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885295152)
            
            //--TRIMMABLE-BOUNDARY-START(4295360560)
            $ctor$1(/*System.Net.IPAddress*/ group, /*int*/ interfaceIndex)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360560);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360560)
            
            //--TRIMMABLE-BOUNDARY-START(8590327856)
            $ctor$2(/*System.Net.IPAddress*/ group, /*System.Net.IPAddress*/ mcint)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327856);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327856)
            
            //--TRIMMABLE-BOUNDARY-START(42950066224)
            /*System.Net.IPAddress */ get Group()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress */ set Group(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129935408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950066224)
            
            //--TRIMMABLE-BOUNDARY-START(47245033520)
            /*int */ get InterfaceIndex()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InterfaceIndex(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719870000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245033520)
            
            //--TRIMMABLE-BOUNDARY-START(51540000816)
            /*System.Net.IPAddress? */ get LocalAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655098928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress? */ set LocalAddress(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309804592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540000816)
            
            static $h = 393264;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950066224),
    {
      "p": 3014703,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475229744,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60129935408,
        "f": 83886081
      },
      "n": "Group",
      "d": 393264,
      "h": 42950066224,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950066224),
//--TRIMMABLE-BOUNDARY-START(47245033520),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065164336,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719870000,
        "f": 83886081
      },
      "n": "InterfaceIndex",
      "d": 393264,
      "h": 47245033520,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245033520),
//--TRIMMABLE-BOUNDARY-START(51540000816),
    {
      "p": 3014703,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655098928,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309804592,
        "f": 83886081
      },
      "n": "LocalAddress",
      "d": 393264,
      "h": 51540000816,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540000816)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885295152),
    {
      "p": [
        {
          "n": "group",
          "p": 3014703
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393264,
      "h": 12885295152,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885295152),
//--TRIMMABLE-BOUNDARY-START(4295360560),
    {
      "p": [
        {
          "n": "group",
          "p": 3014703
        },
        {
          "n": "interfaceIndex",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393264,
      "h": 4295360560,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360560),
//--TRIMMABLE-BOUNDARY-START(8590327856),
    {
      "p": [
        {
          "n": "group",
          "p": 3014703
        },
        {
          "n": "mcint",
          "p": 3014703
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393264,
      "h": 8590327856,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327856)
  ],
  "h": 393264
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Sockets.MulticastOption`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393264)
        
        
        //--TRIMMABLE-BOUNDARY-START(786480)
        $asm.$cls("$sns.System.Net.Sockets.SendPacketsElement", ($self) => class SendPacketsElement extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885688368)
            $ctor$3(/*byte[]*/ buffer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885688368);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885688368)
            
            //--TRIMMABLE-BOUNDARY-START(8590721072)
            $ctor$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590721072);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721072)
            
            //--TRIMMABLE-BOUNDARY-START(4295753776)
            $ctor$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295753776);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295753776)
            
            //--TRIMMABLE-BOUNDARY-START(25770590256)
            $ctor$6(/*System.IO.FileStream*/ fileStream)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770590256);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590256)
            
            //--TRIMMABLE-BOUNDARY-START(21475622960)
            $ctor$5(/*System.IO.FileStream*/ fileStream, /*long*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475622960);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475622960)
            
            //--TRIMMABLE-BOUNDARY-START(17180655664)
            $ctor$4(/*System.IO.FileStream*/ fileStream, /*long*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180655664);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180655664)
            
            //--TRIMMABLE-BOUNDARY-START(34360524848)
            $ctor$8(/*System.ReadOnlyMemory<byte>*/ buffer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360524848);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360524848)
            
            //--TRIMMABLE-BOUNDARY-START(30065557552)
            $ctor$7(/*System.ReadOnlyMemory<byte>*/ buffer, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065557552);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065557552)
            
            //--TRIMMABLE-BOUNDARY-START(55835361328)
            $ctor$13(/*string*/ filepath)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835361328);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835361328)
            
            //--TRIMMABLE-BOUNDARY-START(42950459440)
            $ctor$10(/*string*/ filepath, /*int*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950459440);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950459440)
            
            //--TRIMMABLE-BOUNDARY-START(38655492144)
            $ctor$9(/*string*/ filepath, /*int*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655492144);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655492144)
            
            //--TRIMMABLE-BOUNDARY-START(51540394032)
            $ctor$12(/*string*/ filepath, /*long*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540394032);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540394032)
            
            //--TRIMMABLE-BOUNDARY-START(47245426736)
            $ctor$11(/*string*/ filepath, /*long*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245426736);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245426736)
            
            //--TRIMMABLE-BOUNDARY-START(60130328624)
            /*byte[]? */ get Buffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900132400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60130328624)
            
            //--TRIMMABLE-BOUNDARY-START(64425295920)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490066992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64425295920)
            
            //--TRIMMABLE-BOUNDARY-START(68720263216)
            /*bool */ get EndOfPacket()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080001584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68720263216)
            
            //--TRIMMABLE-BOUNDARY-START(73015230512)
            /*string? */ get FilePath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669936176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73015230512)
            
            //--TRIMMABLE-BOUNDARY-START(77310197808)
            /*System.IO.FileStream? */ get FileStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259870768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77310197808)
            
            //--TRIMMABLE-BOUNDARY-START(150324641840)
            /*System.ReadOnlyMemory<byte>? */ get MemoryBuffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849805360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(150324641840)
            
            //--TRIMMABLE-BOUNDARY-START(154619609136)
            /*int */ get Offset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439739952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(154619609136)
            
            //--TRIMMABLE-BOUNDARY-START(158914576432)
            /*long */ get OffsetLong()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029674544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(158914576432)
            
            static $h = 786480;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130328624),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900132400,
        "f": 50331649
      },
      "n": "Buffer",
      "d": 786480,
      "h": 60130328624,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130328624),
//--TRIMMABLE-BOUNDARY-START(64425295920),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490066992,
        "f": 50331649
      },
      "n": "Count",
      "d": 786480,
      "h": 64425295920,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425295920),
//--TRIMMABLE-BOUNDARY-START(68720263216),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080001584,
        "f": 50331649
      },
      "n": "EndOfPacket",
      "d": 786480,
      "h": 68720263216,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720263216),
//--TRIMMABLE-BOUNDARY-START(73015230512),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669936176,
        "f": 50331649
      },
      "n": "FilePath",
      "d": 786480,
      "h": 73015230512,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015230512),
//--TRIMMABLE-BOUNDARY-START(77310197808),
    {
      "p": 93126657,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259870768,
        "f": 50331649
      },
      "n": "FileStream",
      "d": 786480,
      "h": 77310197808,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310197808),
//--TRIMMABLE-BOUNDARY-START(150324641840),
    {
      "p": $.$typeNullable($.$$.System.ReadOnlyMemory$$($.$$.System.Byte)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849805360,
        "f": 50331649
      },
      "n": "MemoryBuffer",
      "d": 786480,
      "h": 150324641840,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150324641840),
//--TRIMMABLE-BOUNDARY-START(154619609136),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439739952,
        "f": 50331649
      },
      "n": "Offset",
      "d": 786480,
      "h": 154619609136,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619609136),
//--TRIMMABLE-BOUNDARY-START(158914576432),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029674544,
        "f": 50331649
      },
      "n": "OffsetLong",
      "d": 786480,
      "h": 158914576432,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914576432)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885688368),
    {
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786480,
      "h": 12885688368,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688368),
//--TRIMMABLE-BOUNDARY-START(8590721072),
    {
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786480,
      "h": 8590721072,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590721072),
//--TRIMMABLE-BOUNDARY-START(4295753776),
    {
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "endOfPacket",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786480,
      "h": 4295753776,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753776),
//--TRIMMABLE-BOUNDARY-START(25770590256),
    {
      "p": [
        {
          "n": "fileStream",
          "p": 93126657
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 786480,
      "h": 25770590256,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590256),
//--TRIMMABLE-BOUNDARY-START(21475622960),
    {
      "p": [
        {
          "n": "fileStream",
          "p": 93126657
        },
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 786480,
      "h": 21475622960,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475622960),
//--TRIMMABLE-BOUNDARY-START(17180655664),
    {
      "p": [
        {
          "n": "fileStream",
          "p": 93126657
        },
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "endOfPacket",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 786480,
      "h": 17180655664,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180655664),
//--TRIMMABLE-BOUNDARY-START(34360524848),
    {
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 786480,
      "h": 34360524848,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360524848),
//--TRIMMABLE-BOUNDARY-START(30065557552),
    {
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "endOfPacket",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 786480,
      "h": 30065557552,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065557552),
//--TRIMMABLE-BOUNDARY-START(55835361328),
    {
      "p": [
        {
          "n": "filepath",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$13",
      "d": 786480,
      "h": 55835361328,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835361328),
//--TRIMMABLE-BOUNDARY-START(42950459440),
    {
      "p": [
        {
          "n": "filepath",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 786480,
      "h": 42950459440,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950459440),
//--TRIMMABLE-BOUNDARY-START(38655492144),
    {
      "p": [
        {
          "n": "filepath",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "endOfPacket",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 786480,
      "h": 38655492144,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655492144),
//--TRIMMABLE-BOUNDARY-START(51540394032),
    {
      "p": [
        {
          "n": "filepath",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$12",
      "d": 786480,
      "h": 51540394032,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540394032),
//--TRIMMABLE-BOUNDARY-START(47245426736),
    {
      "p": [
        {
          "n": "filepath",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "endOfPacket",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 786480,
      "h": 47245426736,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245426736)
  ],
  "h": 786480
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SendPacketsElement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786480)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572912)
        $asm.$cls("$sns.System.Net.Sockets.SocketTaskExtensions", ($self) => class SocketTaskExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8591507504)
            static /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync$1(/*this System.Net.Sockets.Socket*/ socket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591507504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8591507504)
            
            //--TRIMMABLE-BOUNDARY-START(4296540208)
            static /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.Sockets.Socket?*/ acceptSocket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(4296540208)
            
            //--TRIMMABLE-BOUNDARY-START(25771376688)
            static /*System.Threading.Tasks.Task */ ConnectAsync$3(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771376688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25771376688)
            
            //--TRIMMABLE-BOUNDARY-START(21476409392)
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476409392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21476409392)
            
            //--TRIMMABLE-BOUNDARY-START(34361311280)
            static /*System.Threading.Tasks.Task */ ConnectAsync$5(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress*/ address, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361311280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34361311280)
            
            //--TRIMMABLE-BOUNDARY-START(30066343984)
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$4(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066343984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30066343984)
            
            //--TRIMMABLE-BOUNDARY-START(42951245872)
            static /*System.Threading.Tasks.Task */ ConnectAsync$7(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951245872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42951245872)
            
            //--TRIMMABLE-BOUNDARY-START(38656278576)
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$6(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656278576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38656278576)
            
            //--TRIMMABLE-BOUNDARY-START(17181442096)
            static /*System.Threading.Tasks.Task */ ConnectAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*string*/ host, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181442096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17181442096)
            
            //--TRIMMABLE-BOUNDARY-START(12886474800)
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync(/*this System.Net.Sockets.Socket*/ socket, /*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886474800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12886474800)
            
            //--TRIMMABLE-BOUNDARY-START(47246213168)
            static /*System.Threading.Tasks.Task<int> */ ReceiveAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246213168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47246213168)
            
            //--TRIMMABLE-BOUNDARY-START(51541180464)
            static /*System.Threading.Tasks.Task<int> */ ReceiveAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541180464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51541180464)
            
            //--TRIMMABLE-BOUNDARY-START(55836147760)
            static /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836147760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55836147760)
            
            //--TRIMMABLE-BOUNDARY-START(60131115056)
            static /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131115056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60131115056)
            
            //--TRIMMABLE-BOUNDARY-START(64426082352)
            static /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426082352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64426082352)
            
            //--TRIMMABLE-BOUNDARY-START(68721049648)
            static /*System.Threading.Tasks.Task<int> */ SendAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721049648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68721049648)
            
            //--TRIMMABLE-BOUNDARY-START(73016016944)
            static /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016016944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73016016944)
            
            //--TRIMMABLE-BOUNDARY-START(77310984240)
            static /*System.Threading.Tasks.ValueTask<int> */ SendAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310984240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77310984240)
            
            //--TRIMMABLE-BOUNDARY-START(81605951536)
            static /*System.Threading.Tasks.Task<int> */ SendToAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605951536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81605951536)
            
            static $h = 1572912;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591507504),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,
      "p": [
        {
          "n": "socket",
          "p": 852016
        }
      ],
      "n": "AcceptAsync",
      "o": "@$1",
      "d": 1572912,
      "h": 8591507504,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591507504),
//--TRIMMABLE-BOUNDARY-START(4296540208),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "acceptSocket",
          "p": 852016
        }
      ],
      "n": "AcceptAsync",
      "d": 1572912,
      "h": 4296540208,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4296540208),
//--TRIMMABLE-BOUNDARY-START(25771376688),
    {
      "r": 177668097,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "remoteEP",
          "p": 2555951
        }
      ],
      "n": "ConnectAsync",
      "o": "@$3",
      "d": 1572912,
      "h": 25771376688,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771376688),
//--TRIMMABLE-BOUNDARY-START(21476409392),
    {
      "r": 180551681,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "remoteEP",
          "p": 2555951
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ConnectAsync",
      "o": "@$2",
      "d": 1572912,
      "h": 21476409392,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476409392),
//--TRIMMABLE-BOUNDARY-START(34361311280),
    {
      "r": 177668097,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "address",
          "p": 3014703
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "ConnectAsync",
      "o": "@$5",
      "d": 1572912,
      "h": 34361311280,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361311280),
//--TRIMMABLE-BOUNDARY-START(30066343984),
    {
      "r": 180551681,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "address",
          "p": 3014703
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ConnectAsync",
      "o": "@$4",
      "d": 1572912,
      "h": 30066343984,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066343984),
//--TRIMMABLE-BOUNDARY-START(42951245872),
    {
      "r": 177668097,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "addresses",
          "p": $.$typeArray($.$snp.System.Net.IPAddress).$h
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "ConnectAsync",
      "o": "@$7",
      "d": 1572912,
      "h": 42951245872,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42951245872),
//--TRIMMABLE-BOUNDARY-START(38656278576),
    {
      "r": 180551681,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "addresses",
          "p": $.$typeArray($.$snp.System.Net.IPAddress).$h
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ConnectAsync",
      "o": "@$6",
      "d": 1572912,
      "h": 38656278576,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656278576),
//--TRIMMABLE-BOUNDARY-START(17181442096),
    {
      "r": 177668097,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "host",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "ConnectAsync",
      "o": "@$1",
      "d": 1572912,
      "h": 17181442096,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181442096),
//--TRIMMABLE-BOUNDARY-START(12886474800),
    {
      "r": 180551681,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "host",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ConnectAsync",
      "d": 1572912,
      "h": 12886474800,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886474800),
//--TRIMMABLE-BOUNDARY-START(47246213168),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "ReceiveAsync",
      "d": 1572912,
      "h": 47246213168,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246213168),
//--TRIMMABLE-BOUNDARY-START(51541180464),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "ReceiveAsync",
      "o": "@$1",
      "d": 1572912,
      "h": 51541180464,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541180464),
//--TRIMMABLE-BOUNDARY-START(55836147760),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReceiveAsync",
      "o": "@$2",
      "d": 1572912,
      "h": 55836147760,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836147760),
//--TRIMMABLE-BOUNDARY-START(60131115056),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEndPoint",
          "p": 2555951
        }
      ],
      "n": "ReceiveFromAsync",
      "d": 1572912,
      "h": 60131115056,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60131115056),
//--TRIMMABLE-BOUNDARY-START(64426082352),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEndPoint",
          "p": 2555951
        }
      ],
      "n": "ReceiveMessageFromAsync",
      "d": 1572912,
      "h": 64426082352,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64426082352),
//--TRIMMABLE-BOUNDARY-START(68721049648),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "SendAsync",
      "d": 1572912,
      "h": 68721049648,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68721049648),
//--TRIMMABLE-BOUNDARY-START(73016016944),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "SendAsync",
      "o": "@$1",
      "d": 1572912,
      "h": 73016016944,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73016016944),
//--TRIMMABLE-BOUNDARY-START(77310984240),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "SendAsync",
      "o": "@$2",
      "d": 1572912,
      "h": 77310984240,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310984240),
//--TRIMMABLE-BOUNDARY-START(81605951536),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEP",
          "p": 2555951
        }
      ],
      "n": "SendToAsync",
      "d": 1572912,
      "h": 81605951536,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605951536)
  ],
  "h": 1572912,
  "a": [
    {
      "t": 64290817,
      "c": 12949192705,
      "a": [
        {
          "v": 1,
          "t": 64356353
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SocketTaskExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572912)
        
        
        //--TRIMMABLE-BOUNDARY-START(852016)
        $asm.$cls("$sns.System.Net.Sockets.Socket", ($self) => class Socket extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295819312)
            $ctor$1(/*System.Net.Sockets.AddressFamily*/ addressFamily, /*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295819312);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295819312)
            
            //--TRIMMABLE-BOUNDARY-START(8590786608)
            $ctor$2(/*System.Net.Sockets.SafeSocketHandle*/ handle)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590786608);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590786608)
            
            //--TRIMMABLE-BOUNDARY-START(12885753904)
            $ctor$3(/*System.Net.Sockets.SocketInformation*/ socketInformation)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885753904);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885753904)
            
            //--TRIMMABLE-BOUNDARY-START(17180721200)
            $ctor$4(/*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180721200);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180721200)
            
            //--TRIMMABLE-BOUNDARY-START(47245492272)
            /*System.Net.Sockets.AddressFamily */ get AddressFamily()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303268400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245492272)
            
            //--TRIMMABLE-BOUNDARY-START(51540459568)
            /*int */ get Available()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893202992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540459568)
            
            //--TRIMMABLE-BOUNDARY-START(150324707376)
            /*bool */ get Blocking()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483137584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Blocking(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1030793003056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(150324707376)
            
            //--TRIMMABLE-BOUNDARY-START(227634118704)
            /*bool */ get Connected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365073072176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(227634118704)
            
            //--TRIMMABLE-BOUNDARY-START(253403922480)
            /*bool */ get DontFragment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373663006768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DontFragment(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1039382937648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(253403922480)
            
            //--TRIMMABLE-BOUNDARY-START(257698889776)
            /*bool */ get DualMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252941360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DualMode(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1047972872240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(257698889776)
            
            //--TRIMMABLE-BOUNDARY-START(266288824368)
            /*bool */ get EnableBroadcast()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842875952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableBroadcast(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1056562806832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(266288824368)
            
            //--TRIMMABLE-BOUNDARY-START(326418366512)
            /*bool */ get ExclusiveAddressUse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432810544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1065152741424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(326418366512)
            
            //--TRIMMABLE-BOUNDARY-START(601296273456)
            /*nint */ get Handle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022745136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(601296273456)
            
            //--TRIMMABLE-BOUNDARY-START(614181175344)
            /*bool */ get IsBound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612679728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(614181175344)
            
            //--TRIMMABLE-BOUNDARY-START(618476142640)
            /*System.Net.Sockets.LingerOption? */ get LingerState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202614320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ set LingerState(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1073742676016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(618476142640)
            
            //--TRIMMABLE-BOUNDARY-START(631361044528)
            /*System.Net.EndPoint? */ get LocalEndPoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792548912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(631361044528)
            
            //--TRIMMABLE-BOUNDARY-START(635656011824)
            /*bool */ get MulticastLoopback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442382483504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MulticastLoopback(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1082332610608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(635656011824)
            
            //--TRIMMABLE-BOUNDARY-START(639950979120)
            /*bool */ get NoDelay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450972418096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set NoDelay(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1090922545200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(639950979120)
            
            //--TRIMMABLE-BOUNDARY-START(644245946416)
            static /*bool */ get OSSupportsIPv4()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459562352688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(644245946416)
            
            //--TRIMMABLE-BOUNDARY-START(648540913712)
            static /*bool */ get OSSupportsIPv6()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468152287280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(648540913712)
            
            //--TRIMMABLE-BOUNDARY-START(652835881008)
            static /*bool */ get OSSupportsUnixDomainSockets()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476742221872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(652835881008)
            
            //--TRIMMABLE-BOUNDARY-START(665720782896)
            /*System.Net.Sockets.ProtocolType */ get ProtocolType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485332156464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(665720782896)
            
            //--TRIMMABLE-BOUNDARY-START(747325161520)
            /*int */ get ReceiveBufferSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493922091056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1099512479792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(747325161520)
            
            //--TRIMMABLE-BOUNDARY-START(837519474736)
            /*int */ get ReceiveTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502512025648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1108102414384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(837519474736)
            
            //--TRIMMABLE-BOUNDARY-START(841814442032)
            /*System.Net.EndPoint? */ get RemoteEndPoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511101960240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(841814442032)
            
            //--TRIMMABLE-BOUNDARY-START(846109409328)
            /*System.Net.Sockets.SafeSocketHandle */ get SafeHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519691894832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(846109409328)
            
            //--TRIMMABLE-BOUNDARY-START(936303722544)
            /*int */ get SendBufferSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528281829424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendBufferSize(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1116692348976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(936303722544)
            
            //--TRIMMABLE-BOUNDARY-START(966368493616)
            /*int */ get SendTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536871764016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1125282283568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(966368493616)
            
            //--TRIMMABLE-BOUNDARY-START(1176821891120)
            /*System.Net.Sockets.SocketType */ get SocketType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545461698608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(1176821891120)
            
            //--TRIMMABLE-BOUNDARY-START(1181116858416)
            static /*bool */ get SupportsIPv4()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554051633200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(1181116858416)
            
            //--TRIMMABLE-BOUNDARY-START(1185411825712)
            static /*bool */ get SupportsIPv6()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(562641567792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(1185411825712)
            
            //--TRIMMABLE-BOUNDARY-START(1189706793008)
            /*short */ get Ttl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(571231502384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ set Ttl(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1133872218160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(1189706793008)
            
            //--TRIMMABLE-BOUNDARY-START(1194001760304)
            /*bool */ get UseOnlyOverlappedIO()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(579821436976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseOnlyOverlappedIO(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1142462152752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(1194001760304)
            
            //--TRIMMABLE-BOUNDARY-START(21475688496)
            /*System.Net.Sockets.Socket */ Accept()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475688496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475688496)
            
            //--TRIMMABLE-BOUNDARY-START(25770655792)
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770655792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770655792)
            
            //--TRIMMABLE-BOUNDARY-START(38655557680)
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync$3(/*System.Net.Sockets.Socket?*/ acceptSocket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655557680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655557680)
            
            //--TRIMMABLE-BOUNDARY-START(34360590384)
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptAsync$2(/*System.Net.Sockets.Socket?*/ acceptSocket, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360590384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360590384)
            
            //--TRIMMABLE-BOUNDARY-START(42950524976)
            /*bool */ AcceptAsync$4(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950524976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950524976)
            
            //--TRIMMABLE-BOUNDARY-START(30065623088)
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065623088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065623088)
            
            //--TRIMMABLE-BOUNDARY-START(55835426864)
            /*System.IAsyncResult */ BeginAccept(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835426864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835426864)
            
            //--TRIMMABLE-BOUNDARY-START(60130394160)
            /*System.IAsyncResult */ BeginAccept$1(/*int*/ receiveSize, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130394160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60130394160)
            
            //--TRIMMABLE-BOUNDARY-START(64425361456)
            /*System.IAsyncResult */ BeginAccept$2(/*System.Net.Sockets.Socket?*/ acceptSocket, /*int*/ receiveSize, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425361456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64425361456)
            
            //--TRIMMABLE-BOUNDARY-START(73015296048)
            /*System.IAsyncResult */ BeginConnect$1(/*System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015296048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73015296048)
            
            //--TRIMMABLE-BOUNDARY-START(77310263344)
            /*System.IAsyncResult */ BeginConnect$2(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77310263344)
            
            //--TRIMMABLE-BOUNDARY-START(81605230640)
            /*System.IAsyncResult */ BeginConnect$3(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605230640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81605230640)
            
            //--TRIMMABLE-BOUNDARY-START(68720328752)
            /*System.IAsyncResult */ BeginConnect(/*string*/ host, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720328752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68720328752)
            
            //--TRIMMABLE-BOUNDARY-START(85900197936)
            /*System.IAsyncResult */ BeginDisconnect(/*bool*/ reuseSocket, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900197936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85900197936)
            
            //--TRIMMABLE-BOUNDARY-START(90195165232)
            /*System.IAsyncResult */ BeginReceive(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195165232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90195165232)
            
            //--TRIMMABLE-BOUNDARY-START(94490132528)
            /*System.IAsyncResult? */ BeginReceive$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490132528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(94490132528)
            
            //--TRIMMABLE-BOUNDARY-START(98785099824)
            /*System.IAsyncResult */ BeginReceive$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785099824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(98785099824)
            
            //--TRIMMABLE-BOUNDARY-START(103080067120)
            /*System.IAsyncResult? */ BeginReceive$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080067120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103080067120)
            
            //--TRIMMABLE-BOUNDARY-START(107375034416)
            /*System.IAsyncResult */ BeginReceiveFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375034416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(107375034416)
            
            //--TRIMMABLE-BOUNDARY-START(111670001712)
            /*System.IAsyncResult */ BeginReceiveMessageFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670001712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111670001712)
            
            //--TRIMMABLE-BOUNDARY-START(115964969008)
            /*System.IAsyncResult */ BeginSend(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964969008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115964969008)
            
            //--TRIMMABLE-BOUNDARY-START(120259936304)
            /*System.IAsyncResult? */ BeginSend$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259936304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120259936304)
            
            //--TRIMMABLE-BOUNDARY-START(124554903600)
            /*System.IAsyncResult */ BeginSend$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554903600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(124554903600)
            
            //--TRIMMABLE-BOUNDARY-START(128849870896)
            /*System.IAsyncResult? */ BeginSend$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849870896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(128849870896)
            
            //--TRIMMABLE-BOUNDARY-START(133144838192)
            /*System.IAsyncResult */ BeginSendFile(/*string?*/ fileName, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144838192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(133144838192)
            
            //--TRIMMABLE-BOUNDARY-START(137439805488)
            /*System.IAsyncResult */ BeginSendFile$1(/*string?*/ fileName, /*byte[]?*/ preBuffer, /*byte[]?*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439805488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(137439805488)
            
            //--TRIMMABLE-BOUNDARY-START(141734772784)
            /*System.IAsyncResult */ BeginSendTo(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734772784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(141734772784)
            
            //--TRIMMABLE-BOUNDARY-START(146029740080)
            /*void */ Bind(/*System.Net.EndPoint*/ localEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029740080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(146029740080)
            
            //--TRIMMABLE-BOUNDARY-START(154619674672)
            static /*void */ CancelConnectAsync(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619674672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(154619674672)
            
            //--TRIMMABLE-BOUNDARY-START(158914641968)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914641968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(158914641968)
            
            //--TRIMMABLE-BOUNDARY-START(163209609264)
            /*void */ Close$1(/*int*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209609264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(163209609264)
            
            //--TRIMMABLE-BOUNDARY-START(171799543856)
            /*void */ Connect$1(/*System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799543856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(171799543856)
            
            //--TRIMMABLE-BOUNDARY-START(176094511152)
            /*void */ Connect$2(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094511152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(176094511152)
            
            //--TRIMMABLE-BOUNDARY-START(180389478448)
            /*void */ Connect$3(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389478448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(180389478448)
            
            //--TRIMMABLE-BOUNDARY-START(167504576560)
            /*void */ Connect(/*string*/ host, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504576560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(167504576560)
            
            //--TRIMMABLE-BOUNDARY-START(197569347632)
            /*System.Threading.Tasks.Task */ ConnectAsync$3(/*System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569347632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(197569347632)
            
            //--TRIMMABLE-BOUNDARY-START(193274380336)
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$2(/*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274380336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(193274380336)
            
            //--TRIMMABLE-BOUNDARY-START(206159282224)
            /*System.Threading.Tasks.Task */ ConnectAsync$5(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159282224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(206159282224)
            
            //--TRIMMABLE-BOUNDARY-START(201864314928)
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$4(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864314928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(201864314928)
            
            //--TRIMMABLE-BOUNDARY-START(214749216816)
            /*System.Threading.Tasks.Task */ ConnectAsync$7(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749216816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(214749216816)
            
            //--TRIMMABLE-BOUNDARY-START(210454249520)
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$6(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454249520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(210454249520)
            
            //--TRIMMABLE-BOUNDARY-START(219044184112)
            /*bool */ ConnectAsync$8(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044184112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(219044184112)
            
            //--TRIMMABLE-BOUNDARY-START(223339151408)
            static /*bool */ ConnectAsync$9(/*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType, /*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339151408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(223339151408)
            
            //--TRIMMABLE-BOUNDARY-START(188979413040)
            /*System.Threading.Tasks.Task */ ConnectAsync$1(/*string*/ host, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979413040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(188979413040)
            
            //--TRIMMABLE-BOUNDARY-START(184684445744)
            /*System.Threading.Tasks.ValueTask */ ConnectAsync(/*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684445744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(184684445744)
            
            //--TRIMMABLE-BOUNDARY-START(231929086000)
            /*void */ Disconnect(/*bool*/ reuseSocket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929086000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(231929086000)
            
            //--TRIMMABLE-BOUNDARY-START(236224053296)
            /*System.Threading.Tasks.ValueTask */ DisconnectAsync(/*bool*/ reuseSocket, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224053296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(236224053296)
            
            //--TRIMMABLE-BOUNDARY-START(240519020592)
            /*bool */ DisconnectAsync$1(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519020592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(240519020592)
            
            //--TRIMMABLE-BOUNDARY-START(244813987888)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813987888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(244813987888)
            
            //--TRIMMABLE-BOUNDARY-START(249108955184)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108955184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(249108955184)
            
            //--TRIMMABLE-BOUNDARY-START(261993857072)
            /*System.Net.Sockets.SocketInformation */ DuplicateAndClose(/*int*/ targetProcessId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993857072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(261993857072)
            
            //--TRIMMABLE-BOUNDARY-START(274878758960)
            /*System.Net.Sockets.Socket */ EndAccept$1(/*out byte[]*/ buffer, /*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878758960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(274878758960)
            
            //--TRIMMABLE-BOUNDARY-START(279173726256)
            /*System.Net.Sockets.Socket */ EndAccept$2(/*out byte[]*/ buffer, /*out int*/ bytesTransferred, /*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173726256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(279173726256)
            
            //--TRIMMABLE-BOUNDARY-START(270583791664)
            /*System.Net.Sockets.Socket */ EndAccept(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583791664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(270583791664)
            
            //--TRIMMABLE-BOUNDARY-START(283468693552)
            /*void */ EndConnect(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468693552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(283468693552)
            
            //--TRIMMABLE-BOUNDARY-START(287763660848)
            /*void */ EndDisconnect(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763660848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(287763660848)
            
            //--TRIMMABLE-BOUNDARY-START(296353595440)
            /*int */ EndReceive$1(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353595440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(296353595440)
            
            //--TRIMMABLE-BOUNDARY-START(292058628144)
            /*int */ EndReceive(/*System.IAsyncResult*/ asyncResult, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058628144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(292058628144)
            
            //--TRIMMABLE-BOUNDARY-START(300648562736)
            /*int */ EndReceiveFrom(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.EndPoint*/ endPoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648562736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(300648562736)
            
            //--TRIMMABLE-BOUNDARY-START(304943530032)
            /*int */ EndReceiveMessageFrom(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ endPoint, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943530032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(304943530032)
            
            //--TRIMMABLE-BOUNDARY-START(313533464624)
            /*int */ EndSend$1(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533464624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(313533464624)
            
            //--TRIMMABLE-BOUNDARY-START(309238497328)
            /*int */ EndSend(/*System.IAsyncResult*/ asyncResult, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238497328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(309238497328)
            
            //--TRIMMABLE-BOUNDARY-START(317828431920)
            /*void */ EndSendFile(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828431920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(317828431920)
            
            //--TRIMMABLE-BOUNDARY-START(322123399216)
            /*int */ EndSendTo(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123399216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(322123399216)
            
            $dtor()
            {
            }
            //--TRIMMABLE-BOUNDARY-START(584116404272)
            /*int */ GetRawSocketOption(/*int*/ optionLevel, /*int*/ optionName, /*System.Span<byte>*/ optionValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584116404272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(584116404272)
            
            //--TRIMMABLE-BOUNDARY-START(597001306160)
            /*object? */ GetSocketOption$2(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(597001306160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(597001306160)
            
            //--TRIMMABLE-BOUNDARY-START(588411371568)
            /*void */ GetSocketOption(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*byte[]*/ optionValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(588411371568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(588411371568)
            
            //--TRIMMABLE-BOUNDARY-START(592706338864)
            /*byte[] */ GetSocketOption$1(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*int*/ optionLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592706338864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(592706338864)
            
            //--TRIMMABLE-BOUNDARY-START(605591240752)
            /*int */ IOControl(/*int*/ ioControlCode, /*byte[]?*/ optionInValue, /*byte[]?*/ optionOutValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(605591240752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(605591240752)
            
            //--TRIMMABLE-BOUNDARY-START(609886208048)
            /*int */ IOControl$1(/*System.Net.Sockets.IOControlCode*/ ioControlCode, /*byte[]?*/ optionInValue, /*byte[]?*/ optionOutValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(609886208048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(609886208048)
            
            //--TRIMMABLE-BOUNDARY-START(622771109936)
            /*void */ Listen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(622771109936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(622771109936)
            
            //--TRIMMABLE-BOUNDARY-START(627066077232)
            /*void */ Listen$1(/*int*/ backlog)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(627066077232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(627066077232)
            
            //--TRIMMABLE-BOUNDARY-START(657130848304)
            /*bool */ Poll(/*int*/ microSeconds, /*System.Net.Sockets.SelectMode*/ mode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(657130848304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(657130848304)
            
            //--TRIMMABLE-BOUNDARY-START(661425815600)
            /*bool */ Poll$1(/*System.TimeSpan*/ timeout, /*System.Net.Sockets.SelectMode*/ mode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(661425815600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(661425815600)
            
            //--TRIMMABLE-BOUNDARY-START(687195619376)
            /*int */ Receive$4(/*byte[]*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(687195619376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(687195619376)
            
            //--TRIMMABLE-BOUNDARY-START(674310717488)
            /*int */ Receive$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(674310717488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(674310717488)
            
            //--TRIMMABLE-BOUNDARY-START(670015750192)
            /*int */ Receive(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(670015750192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(670015750192)
            
            //--TRIMMABLE-BOUNDARY-START(678605684784)
            /*int */ Receive$2(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(678605684784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(678605684784)
            
            //--TRIMMABLE-BOUNDARY-START(682900652080)
            /*int */ Receive$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(682900652080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(682900652080)
            
            //--TRIMMABLE-BOUNDARY-START(700080521264)
            /*int */ Receive$7(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(700080521264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(700080521264)
            
            //--TRIMMABLE-BOUNDARY-START(695785553968)
            /*int */ Receive$6(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(695785553968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(695785553968)
            
            //--TRIMMABLE-BOUNDARY-START(691490586672)
            /*int */ Receive$5(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(691490586672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(691490586672)
            
            //--TRIMMABLE-BOUNDARY-START(712965423152)
            /*int */ Receive$10(/*System.Span<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(712965423152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(712965423152)
            
            //--TRIMMABLE-BOUNDARY-START(708670455856)
            /*int */ Receive$9(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(708670455856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(708670455856)
            
            //--TRIMMABLE-BOUNDARY-START(704375488560)
            /*int */ Receive$8(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(704375488560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(704375488560)
            
            //--TRIMMABLE-BOUNDARY-START(721555357744)
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$1(/*System.ArraySegment<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(721555357744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(721555357744)
            
            //--TRIMMABLE-BOUNDARY-START(717260390448)
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(717260390448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(717260390448)
            
            //--TRIMMABLE-BOUNDARY-START(730145292336)
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(730145292336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(730145292336)
            
            //--TRIMMABLE-BOUNDARY-START(725850325040)
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(725850325040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(725850325040)
            
            //--TRIMMABLE-BOUNDARY-START(738735226928)
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$5(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(738735226928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(738735226928)
            
            //--TRIMMABLE-BOUNDARY-START(734440259632)
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$4(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(734440259632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(734440259632)
            
            //--TRIMMABLE-BOUNDARY-START(743030194224)
            /*bool */ ReceiveAsync$6(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(743030194224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(743030194224)
            
            //--TRIMMABLE-BOUNDARY-START(751620128816)
            /*int */ ReceiveFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(751620128816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(751620128816)
            
            //--TRIMMABLE-BOUNDARY-START(755915096112)
            /*int */ ReceiveFrom$1(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(755915096112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(755915096112)
            
            //--TRIMMABLE-BOUNDARY-START(764505030704)
            /*int */ ReceiveFrom$3(/*byte[]*/ buffer, /*ref System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(764505030704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(764505030704)
            
            //--TRIMMABLE-BOUNDARY-START(760210063408)
            /*int */ ReceiveFrom$2(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(760210063408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(760210063408)
            
            //--TRIMMABLE-BOUNDARY-START(777389932592)
            /*int */ ReceiveFrom$6(/*System.Span<byte>*/ buffer, /*ref System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(777389932592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(777389932592)
            
            //--TRIMMABLE-BOUNDARY-START(773094965296)
            /*int */ ReceiveFrom$5(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(773094965296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(773094965296)
            
            //--TRIMMABLE-BOUNDARY-START(768799998000)
            /*int */ ReceiveFrom$4(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ receivedAddress)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(768799998000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(768799998000)
            
            //--TRIMMABLE-BOUNDARY-START(781684899888)
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(781684899888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(781684899888)
            
            //--TRIMMABLE-BOUNDARY-START(785979867184)
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(785979867184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(785979867184)
            
            //--TRIMMABLE-BOUNDARY-START(790274834480)
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$2(/*System.Memory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(790274834480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(790274834480)
            
            //--TRIMMABLE-BOUNDARY-START(794569801776)
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$3(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(794569801776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(794569801776)
            
            //--TRIMMABLE-BOUNDARY-START(798864769072)
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveFromAsync$4(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ receivedAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(798864769072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(798864769072)
            
            //--TRIMMABLE-BOUNDARY-START(803159736368)
            /*bool */ ReceiveFromAsync$5(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(803159736368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(803159736368)
            
            //--TRIMMABLE-BOUNDARY-START(807454703664)
            /*int */ ReceiveMessageFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(807454703664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(807454703664)
            
            //--TRIMMABLE-BOUNDARY-START(811749670960)
            /*int */ ReceiveMessageFrom$1(/*System.Span<byte>*/ buffer, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(811749670960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(811749670960)
            
            //--TRIMMABLE-BOUNDARY-START(816044638256)
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(816044638256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(816044638256)
            
            //--TRIMMABLE-BOUNDARY-START(820339605552)
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(820339605552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(820339605552)
            
            //--TRIMMABLE-BOUNDARY-START(824634572848)
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$2(/*System.Memory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(824634572848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(824634572848)
            
            //--TRIMMABLE-BOUNDARY-START(828929540144)
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$3(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(828929540144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(828929540144)
            
            //--TRIMMABLE-BOUNDARY-START(833224507440)
            /*bool */ ReceiveMessageFromAsync$4(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(833224507440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(833224507440)
            
            //--TRIMMABLE-BOUNDARY-START(850404376624)
            static /*void */ Select(/*System.Collections.IList?*/ checkRead, /*System.Collections.IList?*/ checkWrite, /*System.Collections.IList?*/ checkError, /*int*/ microSeconds)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(850404376624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(850404376624)
            
            //--TRIMMABLE-BOUNDARY-START(854699343920)
            static /*void */ Select$1(/*System.Collections.IList?*/ checkRead, /*System.Collections.IList?*/ checkWrite, /*System.Collections.IList?*/ checkError, /*System.TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(854699343920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(854699343920)
            
            //--TRIMMABLE-BOUNDARY-START(876174180400)
            /*int */ Send$4(/*byte[]*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(876174180400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(876174180400)
            
            //--TRIMMABLE-BOUNDARY-START(863289278512)
            /*int */ Send$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(863289278512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(863289278512)
            
            //--TRIMMABLE-BOUNDARY-START(858994311216)
            /*int */ Send(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(858994311216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(858994311216)
            
            //--TRIMMABLE-BOUNDARY-START(867584245808)
            /*int */ Send$2(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(867584245808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(867584245808)
            
            //--TRIMMABLE-BOUNDARY-START(871879213104)
            /*int */ Send$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(871879213104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(871879213104)
            
            //--TRIMMABLE-BOUNDARY-START(889059082288)
            /*int */ Send$7(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(889059082288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(889059082288)
            
            //--TRIMMABLE-BOUNDARY-START(884764114992)
            /*int */ Send$6(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(884764114992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(884764114992)
            
            //--TRIMMABLE-BOUNDARY-START(880469147696)
            /*int */ Send$5(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(880469147696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(880469147696)
            
            //--TRIMMABLE-BOUNDARY-START(901943984176)
            /*int */ Send$10(/*System.ReadOnlySpan<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(901943984176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(901943984176)
            
            //--TRIMMABLE-BOUNDARY-START(897649016880)
            /*int */ Send$9(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(897649016880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(897649016880)
            
            //--TRIMMABLE-BOUNDARY-START(893354049584)
            /*int */ Send$8(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(893354049584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(893354049584)
            
            //--TRIMMABLE-BOUNDARY-START(910533918768)
            /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*System.ArraySegment<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(910533918768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(910533918768)
            
            //--TRIMMABLE-BOUNDARY-START(906238951472)
            /*System.Threading.Tasks.Task<int> */ SendAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(906238951472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(906238951472)
            
            //--TRIMMABLE-BOUNDARY-START(919123853360)
            /*System.Threading.Tasks.Task<int> */ SendAsync$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(919123853360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(919123853360)
            
            //--TRIMMABLE-BOUNDARY-START(914828886064)
            /*System.Threading.Tasks.Task<int> */ SendAsync$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(914828886064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(914828886064)
            
            //--TRIMMABLE-BOUNDARY-START(932008755248)
            /*bool */ SendAsync$6(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(932008755248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(932008755248)
            
            //--TRIMMABLE-BOUNDARY-START(927713787952)
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$5(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(927713787952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(927713787952)
            
            //--TRIMMABLE-BOUNDARY-START(923418820656)
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$4(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(923418820656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(923418820656)
            
            //--TRIMMABLE-BOUNDARY-START(949188624432)
            /*void */ SendFile$2(/*string?*/ fileName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(949188624432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(949188624432)
            
            //--TRIMMABLE-BOUNDARY-START(940598689840)
            /*void */ SendFile(/*string?*/ fileName, /*byte[]?*/ preBuffer, /*byte[]?*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(940598689840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(940598689840)
            
            //--TRIMMABLE-BOUNDARY-START(944893657136)
            /*void */ SendFile$1(/*string?*/ fileName, /*System.ReadOnlySpan<byte>*/ preBuffer, /*System.ReadOnlySpan<byte>*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(944893657136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(944893657136)
            
            //--TRIMMABLE-BOUNDARY-START(953483591728)
            /*System.Threading.Tasks.ValueTask */ SendFileAsync(/*string?*/ fileName, /*System.ReadOnlyMemory<byte>*/ preBuffer, /*System.ReadOnlyMemory<byte>*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(953483591728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(953483591728)
            
            //--TRIMMABLE-BOUNDARY-START(957778559024)
            /*System.Threading.Tasks.ValueTask */ SendFileAsync$1(/*string?*/ fileName, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(957778559024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(957778559024)
            
            //--TRIMMABLE-BOUNDARY-START(962073526320)
            /*bool */ SendPacketsAsync(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(962073526320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(962073526320)
            
            //--TRIMMABLE-BOUNDARY-START(970663460912)
            /*int */ SendTo(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(970663460912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(970663460912)
            
            //--TRIMMABLE-BOUNDARY-START(974958428208)
            /*int */ SendTo$1(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(974958428208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(974958428208)
            
            //--TRIMMABLE-BOUNDARY-START(979253395504)
            /*int */ SendTo$2(/*byte[]*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(979253395504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(979253395504)
            
            //--TRIMMABLE-BOUNDARY-START(983548362800)
            /*int */ SendTo$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(983548362800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(983548362800)
            
            //--TRIMMABLE-BOUNDARY-START(987843330096)
            /*int */ SendTo$4(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(987843330096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(987843330096)
            
            //--TRIMMABLE-BOUNDARY-START(992138297392)
            /*int */ SendTo$5(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(992138297392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(992138297392)
            
            //--TRIMMABLE-BOUNDARY-START(996433264688)
            /*int */ SendTo$6(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ socketAddress)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(996433264688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(996433264688)
            
            //--TRIMMABLE-BOUNDARY-START(1000728231984)
            /*System.Threading.Tasks.Task<int> */ SendToAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1000728231984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(1000728231984)
            
            //--TRIMMABLE-BOUNDARY-START(1005023199280)
            /*System.Threading.Tasks.Task<int> */ SendToAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1005023199280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(1005023199280)
            
            //--TRIMMABLE-BOUNDARY-START(1022203068464)
            /*bool */ SendToAsync$5(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1022203068464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(1022203068464)
            
            //--TRIMMABLE-BOUNDARY-START(1009318166576)
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1009318166576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(1009318166576)
            
            //--TRIMMABLE-BOUNDARY-START(1013613133872)
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$3(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1013613133872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(1013613133872)
            
            //--TRIMMABLE-BOUNDARY-START(1017908101168)
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$4(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ socketAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1017908101168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(1017908101168)
            
            //--TRIMMABLE-BOUNDARY-START(1146757120048)
            /*void */ SetIPProtectionLevel(/*System.Net.Sockets.IPProtectionLevel*/ level)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1146757120048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(1146757120048)
            
            //--TRIMMABLE-BOUNDARY-START(1151052087344)
            /*void */ SetRawSocketOption(/*int*/ optionLevel, /*int*/ optionName, /*System.ReadOnlySpan<byte>*/ optionValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1151052087344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(1151052087344)
            
            //--TRIMMABLE-BOUNDARY-START(1155347054640)
            /*void */ SetSocketOption(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*bool*/ optionValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1155347054640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(1155347054640)
            
            //--TRIMMABLE-BOUNDARY-START(1159642021936)
            /*void */ SetSocketOption$1(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*byte[]*/ optionValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1159642021936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(1159642021936)
            
            //--TRIMMABLE-BOUNDARY-START(1163936989232)
            /*void */ SetSocketOption$2(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*int*/ optionValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1163936989232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(1163936989232)
            
            //--TRIMMABLE-BOUNDARY-START(1168231956528)
            /*void */ SetSocketOption$3(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*object*/ optionValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1168231956528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(1168231956528)
            
            //--TRIMMABLE-BOUNDARY-START(1172526923824)
            /*void */ Shutdown(/*System.Net.Sockets.SocketShutdown*/ how)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1172526923824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(1172526923824)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 852016;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245492272),
    {
      "p": 4456495,
      "g": {
        "r": 0,
        "d": 0,
        "h": 339303268400,
        "f": 50331649
      },
      "n": "AddressFamily",
      "d": 852016,
      "h": 47245492272,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245492272),
//--TRIMMABLE-BOUNDARY-START(51540459568),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 347893202992,
        "f": 50331649
      },
      "n": "Available",
      "d": 852016,
      "h": 51540459568,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540459568),
//--TRIMMABLE-BOUNDARY-START(150324707376),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 356483137584,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1030793003056,
        "f": 83886081
      },
      "n": "Blocking",
      "d": 852016,
      "h": 150324707376,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150324707376),
//--TRIMMABLE-BOUNDARY-START(227634118704),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 365073072176,
        "f": 50331649
      },
      "n": "Connected",
      "d": 852016,
      "h": 227634118704,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227634118704),
//--TRIMMABLE-BOUNDARY-START(253403922480),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 373663006768,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1039382937648,
        "f": 83886081
      },
      "n": "DontFragment",
      "d": 852016,
      "h": 253403922480,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253403922480),
//--TRIMMABLE-BOUNDARY-START(257698889776),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 382252941360,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1047972872240,
        "f": 83886081
      },
      "n": "DualMode",
      "d": 852016,
      "h": 257698889776,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257698889776),
//--TRIMMABLE-BOUNDARY-START(266288824368),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 390842875952,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1056562806832,
        "f": 83886081
      },
      "n": "EnableBroadcast",
      "d": 852016,
      "h": 266288824368,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(266288824368),
//--TRIMMABLE-BOUNDARY-START(326418366512),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 399432810544,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1065152741424,
        "f": 83886081
      },
      "n": "ExclusiveAddressUse",
      "d": 852016,
      "h": 326418366512,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(326418366512),
//--TRIMMABLE-BOUNDARY-START(601296273456),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 408022745136,
        "f": 50331649
      },
      "n": "Handle",
      "d": 852016,
      "h": 601296273456,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(601296273456),
//--TRIMMABLE-BOUNDARY-START(614181175344),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 416612679728,
        "f": 50331649
      },
      "n": "IsBound",
      "d": 852016,
      "h": 614181175344,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(614181175344),
//--TRIMMABLE-BOUNDARY-START(618476142640),
    {
      "p": 327728,
      "g": {
        "r": 0,
        "d": 0,
        "h": 425202614320,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1073742676016,
        "f": 83886081
      },
      "n": "LingerState",
      "d": 852016,
      "h": 618476142640,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(618476142640),
//--TRIMMABLE-BOUNDARY-START(631361044528),
    {
      "p": 2555951,
      "g": {
        "r": 0,
        "d": 0,
        "h": 433792548912,
        "f": 50331649
      },
      "n": "LocalEndPoint",
      "d": 852016,
      "h": 631361044528,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(631361044528),
//--TRIMMABLE-BOUNDARY-START(635656011824),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 442382483504,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1082332610608,
        "f": 83886081
      },
      "n": "MulticastLoopback",
      "d": 852016,
      "h": 635656011824,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(635656011824),
//--TRIMMABLE-BOUNDARY-START(639950979120),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 450972418096,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1090922545200,
        "f": 83886081
      },
      "n": "NoDelay",
      "d": 852016,
      "h": 639950979120,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(639950979120),
//--TRIMMABLE-BOUNDARY-START(644245946416),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 459562352688,
        "f": 50331681
      },
      "n": "OSSupportsIPv4",
      "d": 852016,
      "h": 644245946416,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(644245946416),
//--TRIMMABLE-BOUNDARY-START(648540913712),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 468152287280,
        "f": 50331681
      },
      "n": "OSSupportsIPv6",
      "d": 852016,
      "h": 648540913712,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(648540913712),
//--TRIMMABLE-BOUNDARY-START(652835881008),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 476742221872,
        "f": 50331681
      },
      "n": "OSSupportsUnixDomainSockets",
      "d": 852016,
      "h": 652835881008,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(652835881008),
//--TRIMMABLE-BOUNDARY-START(665720782896),
    {
      "p": 589872,
      "g": {
        "r": 0,
        "d": 0,
        "h": 485332156464,
        "f": 50331649
      },
      "n": "ProtocolType",
      "d": 852016,
      "h": 665720782896,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(665720782896),
//--TRIMMABLE-BOUNDARY-START(747325161520),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 493922091056,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1099512479792,
        "f": 83886081
      },
      "n": "ReceiveBufferSize",
      "d": 852016,
      "h": 747325161520,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(747325161520),
//--TRIMMABLE-BOUNDARY-START(837519474736),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 502512025648,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1108102414384,
        "f": 83886081
      },
      "n": "ReceiveTimeout",
      "d": 852016,
      "h": 837519474736,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(837519474736),
//--TRIMMABLE-BOUNDARY-START(841814442032),
    {
      "p": 2555951,
      "g": {
        "r": 0,
        "d": 0,
        "h": 511101960240,
        "f": 50331649
      },
      "n": "RemoteEndPoint",
      "d": 852016,
      "h": 841814442032,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(841814442032),
//--TRIMMABLE-BOUNDARY-START(846109409328),
    {
      "p": 655408,
      "g": {
        "r": 0,
        "d": 0,
        "h": 519691894832,
        "f": 50331649
      },
      "n": "SafeHandle",
      "d": 852016,
      "h": 846109409328,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(846109409328),
//--TRIMMABLE-BOUNDARY-START(936303722544),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 528281829424,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1116692348976,
        "f": 83886081
      },
      "n": "SendBufferSize",
      "d": 852016,
      "h": 936303722544,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(936303722544),
//--TRIMMABLE-BOUNDARY-START(966368493616),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 536871764016,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1125282283568,
        "f": 83886081
      },
      "n": "SendTimeout",
      "d": 852016,
      "h": 966368493616,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(966368493616),
//--TRIMMABLE-BOUNDARY-START(1176821891120),
    {
      "p": 1638448,
      "g": {
        "r": 0,
        "d": 0,
        "h": 545461698608,
        "f": 50331649
      },
      "n": "SocketType",
      "d": 852016,
      "h": 1176821891120,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1176821891120),
//--TRIMMABLE-BOUNDARY-START(1181116858416),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 554051633200,
        "f": 50331681
      },
      "n": "SupportsIPv4",
      "d": 852016,
      "h": 1181116858416,
      "f": 2097185,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "SupportsIPv4 has been deprecated. Use OSSupportsIPv4 instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(1181116858416),
//--TRIMMABLE-BOUNDARY-START(1185411825712),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 562641567792,
        "f": 50331681
      },
      "n": "SupportsIPv6",
      "d": 852016,
      "h": 1185411825712,
      "f": 2097185,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "SupportsIPv6 has been deprecated. Use OSSupportsIPv6 instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(1185411825712),
//--TRIMMABLE-BOUNDARY-START(1189706793008),
    {
      "p": 524289,
      "g": {
        "r": 0,
        "d": 0,
        "h": 571231502384,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1133872218160,
        "f": 83886081
      },
      "n": "Ttl",
      "d": 852016,
      "h": 1189706793008,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1189706793008),
//--TRIMMABLE-BOUNDARY-START(1194001760304),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 579821436976,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 1142462152752,
        "f": 83886081
      },
      "n": "UseOnlyOverlappedIO",
      "d": 852016,
      "h": 1194001760304,
      "f": 2097153,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        },
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "UseOnlyOverlappedIO has been deprecated and is not supported.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(1194001760304)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475688496),
    {
      "r": 852016,
      "n": "Accept",
      "d": 852016,
      "h": 21475688496,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475688496),
//--TRIMMABLE-BOUNDARY-START(25770655792),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,
      "n": "AcceptAsync",
      "d": 852016,
      "h": 25770655792,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770655792),
//--TRIMMABLE-BOUNDARY-START(38655557680),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,
      "p": [
        {
          "n": "acceptSocket",
          "p": 852016
        }
      ],
      "n": "AcceptAsync",
      "o": "@$3",
      "d": 852016,
      "h": 38655557680,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655557680),
//--TRIMMABLE-BOUNDARY-START(34360590384),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,
      "p": [
        {
          "n": "acceptSocket",
          "p": 852016
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "AcceptAsync",
      "o": "@$2",
      "d": 852016,
      "h": 34360590384,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360590384),
//--TRIMMABLE-BOUNDARY-START(42950524976),
    {
      "r": 262145,
      "p": [
        {
          "n": "e",
          "p": 917552
        }
      ],
      "n": "AcceptAsync",
      "o": "@$4",
      "d": 852016,
      "h": 42950524976,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950524976),
//--TRIMMABLE-BOUNDARY-START(30065623088),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "AcceptAsync",
      "o": "@$1",
      "d": 852016,
      "h": 30065623088,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065623088),
//--TRIMMABLE-BOUNDARY-START(55835426864),
    {
      "r": 89784321,
      "p": [
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginAccept",
      "d": 852016,
      "h": 55835426864,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835426864),
//--TRIMMABLE-BOUNDARY-START(60130394160),
    {
      "r": 89784321,
      "p": [
        {
          "n": "receiveSize",
          "p": 655361
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginAccept",
      "o": "@$1",
      "d": 852016,
      "h": 60130394160,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130394160),
//--TRIMMABLE-BOUNDARY-START(64425361456),
    {
      "r": 89784321,
      "p": [
        {
          "n": "acceptSocket",
          "p": 852016
        },
        {
          "n": "receiveSize",
          "p": 655361
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginAccept",
      "o": "@$2",
      "d": 852016,
      "h": 64425361456,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425361456),
//--TRIMMABLE-BOUNDARY-START(73015296048),
    {
      "r": 89784321,
      "p": [
        {
          "n": "remoteEP",
          "p": 2555951
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginConnect",
      "o": "@$1",
      "d": 852016,
      "h": 73015296048,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015296048),
//--TRIMMABLE-BOUNDARY-START(77310263344),
    {
      "r": 89784321,
      "p": [
        {
          "n": "address",
          "p": 3014703
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "requestCallback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginConnect",
      "o": "@$2",
      "d": 852016,
      "h": 77310263344,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310263344),
//--TRIMMABLE-BOUNDARY-START(81605230640),
    {
      "r": 89784321,
      "p": [
        {
          "n": "addresses",
          "p": $.$typeArray($.$snp.System.Net.IPAddress).$h
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "requestCallback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginConnect",
      "o": "@$3",
      "d": 852016,
      "h": 81605230640,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605230640),
//--TRIMMABLE-BOUNDARY-START(68720328752),
    {
      "r": 89784321,
      "p": [
        {
          "n": "host",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "requestCallback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginConnect",
      "d": 852016,
      "h": 68720328752,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720328752),
//--TRIMMABLE-BOUNDARY-START(85900197936),
    {
      "r": 89784321,
      "p": [
        {
          "n": "reuseSocket",
          "p": 262145
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginDisconnect",
      "d": 852016,
      "h": 85900197936,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900197936),
//--TRIMMABLE-BOUNDARY-START(90195165232),
    {
      "r": 89784321,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginReceive",
      "d": 852016,
      "h": 90195165232,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195165232),
//--TRIMMABLE-BOUNDARY-START(94490132528),
    {
      "r": 89784321,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "errorCode",
          "p": 4653103,
          "f": 2
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginReceive",
      "o": "@$1",
      "d": 852016,
      "h": 94490132528,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490132528),
//--TRIMMABLE-BOUNDARY-START(98785099824),
    {
      "r": 89784321,
      "p": [
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginReceive",
      "o": "@$2",
      "d": 852016,
      "h": 98785099824,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98785099824),
//--TRIMMABLE-BOUNDARY-START(103080067120),
    {
      "r": 89784321,
      "p": [
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "errorCode",
          "p": 4653103,
          "f": 2
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginReceive",
      "o": "@$3",
      "d": 852016,
      "h": 103080067120,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103080067120),
//--TRIMMABLE-BOUNDARY-START(107375034416),
    {
      "r": 89784321,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEP",
          "p": 2555951,
          "f": 4
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginReceiveFrom",
      "d": 852016,
      "h": 107375034416,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107375034416),
//--TRIMMABLE-BOUNDARY-START(111670001712),
    {
      "r": 89784321,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEP",
          "p": 2555951,
          "f": 4
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginReceiveMessageFrom",
      "d": 852016,
      "h": 111670001712,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670001712),
//--TRIMMABLE-BOUNDARY-START(115964969008),
    {
      "r": 89784321,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginSend",
      "d": 852016,
      "h": 115964969008,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964969008),
//--TRIMMABLE-BOUNDARY-START(120259936304),
    {
      "r": 89784321,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "errorCode",
          "p": 4653103,
          "f": 2
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginSend",
      "o": "@$1",
      "d": 852016,
      "h": 120259936304,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120259936304),
//--TRIMMABLE-BOUNDARY-START(124554903600),
    {
      "r": 89784321,
      "p": [
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginSend",
      "o": "@$2",
      "d": 852016,
      "h": 124554903600,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124554903600),
//--TRIMMABLE-BOUNDARY-START(128849870896),
    {
      "r": 89784321,
      "p": [
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "errorCode",
          "p": 4653103,
          "f": 2
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginSend",
      "o": "@$3",
      "d": 852016,
      "h": 128849870896,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128849870896),
//--TRIMMABLE-BOUNDARY-START(133144838192),
    {
      "r": 89784321,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginSendFile",
      "d": 852016,
      "h": 133144838192,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133144838192),
//--TRIMMABLE-BOUNDARY-START(137439805488),
    {
      "r": 89784321,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "preBuffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "postBuffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "flags",
          "p": 1835056
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginSendFile",
      "o": "@$1",
      "d": 852016,
      "h": 137439805488,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439805488),
//--TRIMMABLE-BOUNDARY-START(141734772784),
    {
      "r": 89784321,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEP",
          "p": 2555951
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginSendTo",
      "d": 852016,
      "h": 141734772784,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141734772784),
//--TRIMMABLE-BOUNDARY-START(146029740080),
    {
      "r": 65537,
      "p": [
        {
          "n": "localEP",
          "p": 2555951
        }
      ],
      "n": "Bind",
      "d": 852016,
      "h": 146029740080,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029740080),
//--TRIMMABLE-BOUNDARY-START(154619674672),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 917552
        }
      ],
      "n": "CancelConnectAsync",
      "d": 852016,
      "h": 154619674672,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(154619674672),
//--TRIMMABLE-BOUNDARY-START(158914641968),
    {
      "r": 65537,
      "n": "Close",
      "d": 852016,
      "h": 158914641968,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914641968),
//--TRIMMABLE-BOUNDARY-START(163209609264),
    {
      "r": 65537,
      "p": [
        {
          "n": "timeout",
          "p": 655361
        }
      ],
      "n": "Close",
      "o": "@$1",
      "d": 852016,
      "h": 163209609264,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209609264),
//--TRIMMABLE-BOUNDARY-START(171799543856),
    {
      "r": 65537,
      "p": [
        {
          "n": "remoteEP",
          "p": 2555951
        }
      ],
      "n": "Connect",
      "o": "@$1",
      "d": 852016,
      "h": 171799543856,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171799543856),
//--TRIMMABLE-BOUNDARY-START(176094511152),
    {
      "r": 65537,
      "p": [
        {
          "n": "address",
          "p": 3014703
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "Connect",
      "o": "@$2",
      "d": 852016,
      "h": 176094511152,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094511152),
//--TRIMMABLE-BOUNDARY-START(180389478448),
    {
      "r": 65537,
      "p": [
        {
          "n": "addresses",
          "p": $.$typeArray($.$snp.System.Net.IPAddress).$h
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "Connect",
      "o": "@$3",
      "d": 852016,
      "h": 180389478448,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180389478448),
//--TRIMMABLE-BOUNDARY-START(167504576560),
    {
      "r": 65537,
      "p": [
        {
          "n": "host",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "Connect",
      "d": 852016,
      "h": 167504576560,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167504576560),
//--TRIMMABLE-BOUNDARY-START(197569347632),
    {
      "r": 177668097,
      "p": [
        {
          "n": "remoteEP",
          "p": 2555951
        }
      ],
      "n": "ConnectAsync",
      "o": "@$3",
      "d": 852016,
      "h": 197569347632,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197569347632),
//--TRIMMABLE-BOUNDARY-START(193274380336),
    {
      "r": 180551681,
      "p": [
        {
          "n": "remoteEP",
          "p": 2555951
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ConnectAsync",
      "o": "@$2",
      "d": 852016,
      "h": 193274380336,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193274380336),
//--TRIMMABLE-BOUNDARY-START(206159282224),
    {
      "r": 177668097,
      "p": [
        {
          "n": "address",
          "p": 3014703
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "ConnectAsync",
      "o": "@$5",
      "d": 852016,
      "h": 206159282224,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(206159282224),
//--TRIMMABLE-BOUNDARY-START(201864314928),
    {
      "r": 180551681,
      "p": [
        {
          "n": "address",
          "p": 3014703
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ConnectAsync",
      "o": "@$4",
      "d": 852016,
      "h": 201864314928,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201864314928),
//--TRIMMABLE-BOUNDARY-START(214749216816),
    {
      "r": 177668097,
      "p": [
        {
          "n": "addresses",
          "p": $.$typeArray($.$snp.System.Net.IPAddress).$h
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "ConnectAsync",
      "o": "@$7",
      "d": 852016,
      "h": 214749216816,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214749216816),
//--TRIMMABLE-BOUNDARY-START(210454249520),
    {
      "r": 180551681,
      "p": [
        {
          "n": "addresses",
          "p": $.$typeArray($.$snp.System.Net.IPAddress).$h
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ConnectAsync",
      "o": "@$6",
      "d": 852016,
      "h": 210454249520,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210454249520),
//--TRIMMABLE-BOUNDARY-START(219044184112),
    {
      "r": 262145,
      "p": [
        {
          "n": "e",
          "p": 917552
        }
      ],
      "n": "ConnectAsync",
      "o": "@$8",
      "d": 852016,
      "h": 219044184112,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(219044184112),
//--TRIMMABLE-BOUNDARY-START(223339151408),
    {
      "r": 262145,
      "p": [
        {
          "n": "socketType",
          "p": 1638448
        },
        {
          "n": "protocolType",
          "p": 589872
        },
        {
          "n": "e",
          "p": 917552
        }
      ],
      "n": "ConnectAsync",
      "o": "@$9",
      "d": 852016,
      "h": 223339151408,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(223339151408),
//--TRIMMABLE-BOUNDARY-START(188979413040),
    {
      "r": 177668097,
      "p": [
        {
          "n": "host",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "ConnectAsync",
      "o": "@$1",
      "d": 852016,
      "h": 188979413040,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188979413040),
//--TRIMMABLE-BOUNDARY-START(184684445744),
    {
      "r": 180551681,
      "p": [
        {
          "n": "host",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ConnectAsync",
      "d": 852016,
      "h": 184684445744,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684445744),
//--TRIMMABLE-BOUNDARY-START(231929086000),
    {
      "r": 65537,
      "p": [
        {
          "n": "reuseSocket",
          "p": 262145
        }
      ],
      "n": "Disconnect",
      "d": 852016,
      "h": 231929086000,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231929086000),
//--TRIMMABLE-BOUNDARY-START(236224053296),
    {
      "r": 180551681,
      "p": [
        {
          "n": "reuseSocket",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "DisconnectAsync",
      "d": 852016,
      "h": 236224053296,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(236224053296),
//--TRIMMABLE-BOUNDARY-START(240519020592),
    {
      "r": 262145,
      "p": [
        {
          "n": "e",
          "p": 917552
        }
      ],
      "n": "DisconnectAsync",
      "o": "@$1",
      "d": 852016,
      "h": 240519020592,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(240519020592),
//--TRIMMABLE-BOUNDARY-START(244813987888),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 852016,
      "h": 244813987888,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(244813987888),
//--TRIMMABLE-BOUNDARY-START(249108955184),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 852016,
      "h": 249108955184,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(249108955184),
//--TRIMMABLE-BOUNDARY-START(261993857072),
    {
      "r": 1114160,
      "p": [
        {
          "n": "targetProcessId",
          "p": 655361
        }
      ],
      "n": "DuplicateAndClose",
      "d": 852016,
      "h": 261993857072,
      "f": 16777217,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(261993857072),
//--TRIMMABLE-BOUNDARY-START(274878758960),
    {
      "r": 852016,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h,
          "f": 2
        },
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndAccept",
      "o": "@$1",
      "d": 852016,
      "h": 274878758960,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(274878758960),
//--TRIMMABLE-BOUNDARY-START(279173726256),
    {
      "r": 852016,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h,
          "f": 2
        },
        {
          "n": "bytesTransferred",
          "p": 655361,
          "f": 2
        },
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndAccept",
      "o": "@$2",
      "d": 852016,
      "h": 279173726256,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(279173726256),
//--TRIMMABLE-BOUNDARY-START(270583791664),
    {
      "r": 852016,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndAccept",
      "d": 852016,
      "h": 270583791664,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(270583791664),
//--TRIMMABLE-BOUNDARY-START(283468693552),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndConnect",
      "d": 852016,
      "h": 283468693552,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(283468693552),
//--TRIMMABLE-BOUNDARY-START(287763660848),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndDisconnect",
      "d": 852016,
      "h": 287763660848,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(287763660848),
//--TRIMMABLE-BOUNDARY-START(296353595440),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndReceive",
      "o": "@$1",
      "d": 852016,
      "h": 296353595440,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(296353595440),
//--TRIMMABLE-BOUNDARY-START(292058628144),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        },
        {
          "n": "errorCode",
          "p": 4653103,
          "f": 2
        }
      ],
      "n": "EndReceive",
      "d": 852016,
      "h": 292058628144,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(292058628144),
//--TRIMMABLE-BOUNDARY-START(300648562736),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        },
        {
          "n": "endPoint",
          "p": 2555951,
          "f": 4
        }
      ],
      "n": "EndReceiveFrom",
      "d": 852016,
      "h": 300648562736,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(300648562736),
//--TRIMMABLE-BOUNDARY-START(304943530032),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        },
        {
          "n": "socketFlags",
          "p": 1048624,
          "f": 4
        },
        {
          "n": "endPoint",
          "p": 2555951,
          "f": 4
        },
        {
          "n": "ipPacketInformation",
          "p": 131120,
          "f": 2
        }
      ],
      "n": "EndReceiveMessageFrom",
      "d": 852016,
      "h": 304943530032,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(304943530032),
//--TRIMMABLE-BOUNDARY-START(313533464624),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndSend",
      "o": "@$1",
      "d": 852016,
      "h": 313533464624,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(313533464624),
//--TRIMMABLE-BOUNDARY-START(309238497328),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        },
        {
          "n": "errorCode",
          "p": 4653103,
          "f": 2
        }
      ],
      "n": "EndSend",
      "d": 852016,
      "h": 309238497328,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(309238497328),
//--TRIMMABLE-BOUNDARY-START(317828431920),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndSendFile",
      "d": 852016,
      "h": 317828431920,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(317828431920),
//--TRIMMABLE-BOUNDARY-START(322123399216),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndSendTo",
      "d": 852016,
      "h": 322123399216,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(322123399216),
//--TRIMMABLE-BOUNDARY-START(584116404272),
    {
      "r": 655361,
      "p": [
        {
          "n": "optionLevel",
          "p": 655361
        },
        {
          "n": "optionName",
          "p": 655361
        },
        {
          "n": "optionValue",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "GetRawSocketOption",
      "d": 852016,
      "h": 584116404272,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(584116404272),
//--TRIMMABLE-BOUNDARY-START(597001306160),
    {
      "r": 131073,
      "p": [
        {
          "n": "optionLevel",
          "p": 1245232
        },
        {
          "n": "optionName",
          "p": 1310768
        }
      ],
      "n": "GetSocketOption",
      "o": "@$2",
      "d": 852016,
      "h": 597001306160,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(597001306160),
//--TRIMMABLE-BOUNDARY-START(588411371568),
    {
      "r": 65537,
      "p": [
        {
          "n": "optionLevel",
          "p": 1245232
        },
        {
          "n": "optionName",
          "p": 1310768
        },
        {
          "n": "optionValue",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "GetSocketOption",
      "d": 852016,
      "h": 588411371568,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(588411371568),
//--TRIMMABLE-BOUNDARY-START(592706338864),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "optionLevel",
          "p": 1245232
        },
        {
          "n": "optionName",
          "p": 1310768
        },
        {
          "n": "optionLength",
          "p": 655361
        }
      ],
      "n": "GetSocketOption",
      "o": "@$1",
      "d": 852016,
      "h": 592706338864,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(592706338864),
//--TRIMMABLE-BOUNDARY-START(605591240752),
    {
      "r": 655361,
      "p": [
        {
          "n": "ioControlCode",
          "p": 655361
        },
        {
          "n": "optionInValue",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "optionOutValue",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "IOControl",
      "d": 852016,
      "h": 605591240752,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(605591240752),
//--TRIMMABLE-BOUNDARY-START(609886208048),
    {
      "r": 655361,
      "p": [
        {
          "n": "ioControlCode",
          "p": 65584
        },
        {
          "n": "optionInValue",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "optionOutValue",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "IOControl",
      "o": "@$1",
      "d": 852016,
      "h": 609886208048,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(609886208048),
//--TRIMMABLE-BOUNDARY-START(622771109936),
    {
      "r": 65537,
      "n": "Listen",
      "d": 852016,
      "h": 622771109936,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(622771109936),
//--TRIMMABLE-BOUNDARY-START(627066077232),
    {
      "r": 65537,
      "p": [
        {
          "n": "backlog",
          "p": 655361
        }
      ],
      "n": "Listen",
      "o": "@$1",
      "d": 852016,
      "h": 627066077232,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(627066077232),
//--TRIMMABLE-BOUNDARY-START(657130848304),
    {
      "r": 262145,
      "p": [
        {
          "n": "microSeconds",
          "p": 655361
        },
        {
          "n": "mode",
          "p": 720944
        }
      ],
      "n": "Poll",
      "d": 852016,
      "h": 657130848304,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(657130848304),
//--TRIMMABLE-BOUNDARY-START(661425815600),
    {
      "r": 262145,
      "p": [
        {
          "n": "timeout",
          "p": 185860097
        },
        {
          "n": "mode",
          "p": 720944
        }
      ],
      "n": "Poll",
      "o": "@$1",
      "d": 852016,
      "h": 661425815600,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(661425815600),
//--TRIMMABLE-BOUNDARY-START(687195619376),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "Receive",
      "o": "@$4",
      "d": 852016,
      "h": 687195619376,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(687195619376),
//--TRIMMABLE-BOUNDARY-START(674310717488),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "Receive",
      "o": "@$1",
      "d": 852016,
      "h": 674310717488,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(674310717488),
//--TRIMMABLE-BOUNDARY-START(670015750192),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "errorCode",
          "p": 4653103,
          "f": 2
        }
      ],
      "n": "Receive",
      "d": 852016,
      "h": 670015750192,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(670015750192),
//--TRIMMABLE-BOUNDARY-START(678605684784),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "Receive",
      "o": "@$2",
      "d": 852016,
      "h": 678605684784,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(678605684784),
//--TRIMMABLE-BOUNDARY-START(682900652080),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "Receive",
      "o": "@$3",
      "d": 852016,
      "h": 682900652080,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(682900652080),
//--TRIMMABLE-BOUNDARY-START(700080521264),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        }
      ],
      "n": "Receive",
      "o": "@$7",
      "d": 852016,
      "h": 700080521264,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(700080521264),
//--TRIMMABLE-BOUNDARY-START(695785553968),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "Receive",
      "o": "@$6",
      "d": 852016,
      "h": 695785553968,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(695785553968),
//--TRIMMABLE-BOUNDARY-START(691490586672),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "errorCode",
          "p": 4653103,
          "f": 2
        }
      ],
      "n": "Receive",
      "o": "@$5",
      "d": 852016,
      "h": 691490586672,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(691490586672),
//--TRIMMABLE-BOUNDARY-START(712965423152),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "Receive",
      "o": "@$10",
      "d": 852016,
      "h": 712965423152,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(712965423152),
//--TRIMMABLE-BOUNDARY-START(708670455856),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "Receive",
      "o": "@$9",
      "d": 852016,
      "h": 708670455856,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(708670455856),
//--TRIMMABLE-BOUNDARY-START(704375488560),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "errorCode",
          "p": 4653103,
          "f": 2
        }
      ],
      "n": "Receive",
      "o": "@$8",
      "d": 852016,
      "h": 704375488560,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(704375488560),
//--TRIMMABLE-BOUNDARY-START(721555357744),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        }
      ],
      "n": "ReceiveAsync",
      "o": "@$1",
      "d": 852016,
      "h": 721555357744,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(721555357744),
//--TRIMMABLE-BOUNDARY-START(717260390448),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "ReceiveAsync",
      "d": 852016,
      "h": 717260390448,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(717260390448),
//--TRIMMABLE-BOUNDARY-START(730145292336),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        }
      ],
      "n": "ReceiveAsync",
      "o": "@$3",
      "d": 852016,
      "h": 730145292336,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(730145292336),
//--TRIMMABLE-BOUNDARY-START(725850325040),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "ReceiveAsync",
      "o": "@$2",
      "d": 852016,
      "h": 725850325040,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(725850325040),
//--TRIMMABLE-BOUNDARY-START(738735226928),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReceiveAsync",
      "o": "@$5",
      "d": 852016,
      "h": 738735226928,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(738735226928),
//--TRIMMABLE-BOUNDARY-START(734440259632),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReceiveAsync",
      "o": "@$4",
      "d": 852016,
      "h": 734440259632,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(734440259632),
//--TRIMMABLE-BOUNDARY-START(743030194224),
    {
      "r": 262145,
      "p": [
        {
          "n": "e",
          "p": 917552
        }
      ],
      "n": "ReceiveAsync",
      "o": "@$6",
      "d": 852016,
      "h": 743030194224,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(743030194224),
//--TRIMMABLE-BOUNDARY-START(751620128816),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEP",
          "p": 2555951,
          "f": 4
        }
      ],
      "n": "ReceiveFrom",
      "d": 852016,
      "h": 751620128816,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(751620128816),
//--TRIMMABLE-BOUNDARY-START(755915096112),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEP",
          "p": 2555951,
          "f": 4
        }
      ],
      "n": "ReceiveFrom",
      "o": "@$1",
      "d": 852016,
      "h": 755915096112,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(755915096112),
//--TRIMMABLE-BOUNDARY-START(764505030704),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "remoteEP",
          "p": 2555951,
          "f": 4
        }
      ],
      "n": "ReceiveFrom",
      "o": "@$3",
      "d": 852016,
      "h": 764505030704,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(764505030704),
//--TRIMMABLE-BOUNDARY-START(760210063408),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEP",
          "p": 2555951,
          "f": 4
        }
      ],
      "n": "ReceiveFrom",
      "o": "@$2",
      "d": 852016,
      "h": 760210063408,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(760210063408),
//--TRIMMABLE-BOUNDARY-START(777389932592),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "remoteEP",
          "p": 2555951,
          "f": 4
        }
      ],
      "n": "ReceiveFrom",
      "o": "@$6",
      "d": 852016,
      "h": 777389932592,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(777389932592),
//--TRIMMABLE-BOUNDARY-START(773094965296),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEP",
          "p": 2555951,
          "f": 4
        }
      ],
      "n": "ReceiveFrom",
      "o": "@$5",
      "d": 852016,
      "h": 773094965296,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(773094965296),
//--TRIMMABLE-BOUNDARY-START(768799998000),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "receivedAddress",
          "p": 4325423
        }
      ],
      "n": "ReceiveFrom",
      "o": "@$4",
      "d": 852016,
      "h": 768799998000,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(768799998000),
//--TRIMMABLE-BOUNDARY-START(781684899888),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "remoteEndPoint",
          "p": 2555951
        }
      ],
      "n": "ReceiveFromAsync",
      "d": 852016,
      "h": 781684899888,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(781684899888),
//--TRIMMABLE-BOUNDARY-START(785979867184),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEndPoint",
          "p": 2555951
        }
      ],
      "n": "ReceiveFromAsync",
      "o": "@$1",
      "d": 852016,
      "h": 785979867184,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(785979867184),
//--TRIMMABLE-BOUNDARY-START(790274834480),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "remoteEndPoint",
          "p": 2555951
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReceiveFromAsync",
      "o": "@$2",
      "d": 852016,
      "h": 790274834480,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(790274834480),
//--TRIMMABLE-BOUNDARY-START(794569801776),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEndPoint",
          "p": 2555951
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReceiveFromAsync",
      "o": "@$3",
      "d": 852016,
      "h": 794569801776,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(794569801776),
//--TRIMMABLE-BOUNDARY-START(798864769072),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "receivedAddress",
          "p": 4325423
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReceiveFromAsync",
      "o": "@$4",
      "d": 852016,
      "h": 798864769072,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(798864769072),
//--TRIMMABLE-BOUNDARY-START(803159736368),
    {
      "r": 262145,
      "p": [
        {
          "n": "e",
          "p": 917552
        }
      ],
      "n": "ReceiveFromAsync",
      "o": "@$5",
      "d": 852016,
      "h": 803159736368,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(803159736368),
//--TRIMMABLE-BOUNDARY-START(807454703664),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624,
          "f": 4
        },
        {
          "n": "remoteEP",
          "p": 2555951,
          "f": 4
        },
        {
          "n": "ipPacketInformation",
          "p": 131120,
          "f": 2
        }
      ],
      "n": "ReceiveMessageFrom",
      "d": 852016,
      "h": 807454703664,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(807454703664),
//--TRIMMABLE-BOUNDARY-START(811749670960),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624,
          "f": 4
        },
        {
          "n": "remoteEP",
          "p": 2555951,
          "f": 4
        },
        {
          "n": "ipPacketInformation",
          "p": 131120,
          "f": 2
        }
      ],
      "n": "ReceiveMessageFrom",
      "o": "@$1",
      "d": 852016,
      "h": 811749670960,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(811749670960),
//--TRIMMABLE-BOUNDARY-START(816044638256),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "remoteEndPoint",
          "p": 2555951
        }
      ],
      "n": "ReceiveMessageFromAsync",
      "d": 852016,
      "h": 816044638256,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(816044638256),
//--TRIMMABLE-BOUNDARY-START(820339605552),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEndPoint",
          "p": 2555951
        }
      ],
      "n": "ReceiveMessageFromAsync",
      "o": "@$1",
      "d": 852016,
      "h": 820339605552,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(820339605552),
//--TRIMMABLE-BOUNDARY-START(824634572848),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "remoteEndPoint",
          "p": 2555951
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReceiveMessageFromAsync",
      "o": "@$2",
      "d": 852016,
      "h": 824634572848,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(824634572848),
//--TRIMMABLE-BOUNDARY-START(828929540144),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEndPoint",
          "p": 2555951
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReceiveMessageFromAsync",
      "o": "@$3",
      "d": 852016,
      "h": 828929540144,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(828929540144),
//--TRIMMABLE-BOUNDARY-START(833224507440),
    {
      "r": 262145,
      "p": [
        {
          "n": "e",
          "p": 917552
        }
      ],
      "n": "ReceiveMessageFromAsync",
      "o": "@$4",
      "d": 852016,
      "h": 833224507440,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(833224507440),
//--TRIMMABLE-BOUNDARY-START(850404376624),
    {
      "r": 65537,
      "p": [
        {
          "n": "checkRead",
          "p": 62980097
        },
        {
          "n": "checkWrite",
          "p": 62980097
        },
        {
          "n": "checkError",
          "p": 62980097
        },
        {
          "n": "microSeconds",
          "p": 655361
        }
      ],
      "n": "Select",
      "d": 852016,
      "h": 850404376624,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(850404376624),
//--TRIMMABLE-BOUNDARY-START(854699343920),
    {
      "r": 65537,
      "p": [
        {
          "n": "checkRead",
          "p": 62980097
        },
        {
          "n": "checkWrite",
          "p": 62980097
        },
        {
          "n": "checkError",
          "p": 62980097
        },
        {
          "n": "timeout",
          "p": 185860097
        }
      ],
      "n": "Select",
      "o": "@$1",
      "d": 852016,
      "h": 854699343920,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(854699343920),
//--TRIMMABLE-BOUNDARY-START(876174180400),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "Send",
      "o": "@$4",
      "d": 852016,
      "h": 876174180400,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(876174180400),
//--TRIMMABLE-BOUNDARY-START(863289278512),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "Send",
      "o": "@$1",
      "d": 852016,
      "h": 863289278512,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(863289278512),
//--TRIMMABLE-BOUNDARY-START(858994311216),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "errorCode",
          "p": 4653103,
          "f": 2
        }
      ],
      "n": "Send",
      "d": 852016,
      "h": 858994311216,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(858994311216),
//--TRIMMABLE-BOUNDARY-START(867584245808),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "Send",
      "o": "@$2",
      "d": 852016,
      "h": 867584245808,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(867584245808),
//--TRIMMABLE-BOUNDARY-START(871879213104),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "Send",
      "o": "@$3",
      "d": 852016,
      "h": 871879213104,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(871879213104),
//--TRIMMABLE-BOUNDARY-START(889059082288),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        }
      ],
      "n": "Send",
      "o": "@$7",
      "d": 852016,
      "h": 889059082288,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(889059082288),
//--TRIMMABLE-BOUNDARY-START(884764114992),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "Send",
      "o": "@$6",
      "d": 852016,
      "h": 884764114992,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(884764114992),
//--TRIMMABLE-BOUNDARY-START(880469147696),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "errorCode",
          "p": 4653103,
          "f": 2
        }
      ],
      "n": "Send",
      "o": "@$5",
      "d": 852016,
      "h": 880469147696,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(880469147696),
//--TRIMMABLE-BOUNDARY-START(901943984176),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "Send",
      "o": "@$10",
      "d": 852016,
      "h": 901943984176,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(901943984176),
//--TRIMMABLE-BOUNDARY-START(897649016880),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "Send",
      "o": "@$9",
      "d": 852016,
      "h": 897649016880,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(897649016880),
//--TRIMMABLE-BOUNDARY-START(893354049584),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "errorCode",
          "p": 4653103,
          "f": 2
        }
      ],
      "n": "Send",
      "o": "@$8",
      "d": 852016,
      "h": 893354049584,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(893354049584),
//--TRIMMABLE-BOUNDARY-START(910533918768),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        }
      ],
      "n": "SendAsync",
      "o": "@$1",
      "d": 852016,
      "h": 910533918768,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(910533918768),
//--TRIMMABLE-BOUNDARY-START(906238951472),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "SendAsync",
      "d": 852016,
      "h": 906238951472,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(906238951472),
//--TRIMMABLE-BOUNDARY-START(919123853360),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        }
      ],
      "n": "SendAsync",
      "o": "@$3",
      "d": 852016,
      "h": 919123853360,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(919123853360),
//--TRIMMABLE-BOUNDARY-START(914828886064),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffers",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        }
      ],
      "n": "SendAsync",
      "o": "@$2",
      "d": 852016,
      "h": 914828886064,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(914828886064),
//--TRIMMABLE-BOUNDARY-START(932008755248),
    {
      "r": 262145,
      "p": [
        {
          "n": "e",
          "p": 917552
        }
      ],
      "n": "SendAsync",
      "o": "@$6",
      "d": 852016,
      "h": 932008755248,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(932008755248),
//--TRIMMABLE-BOUNDARY-START(927713787952),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "SendAsync",
      "o": "@$5",
      "d": 852016,
      "h": 927713787952,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(927713787952),
//--TRIMMABLE-BOUNDARY-START(923418820656),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "SendAsync",
      "o": "@$4",
      "d": 852016,
      "h": 923418820656,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(923418820656),
//--TRIMMABLE-BOUNDARY-START(949188624432),
    {
      "r": 65537,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        }
      ],
      "n": "SendFile",
      "o": "@$2",
      "d": 852016,
      "h": 949188624432,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(949188624432),
//--TRIMMABLE-BOUNDARY-START(940598689840),
    {
      "r": 65537,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "preBuffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "postBuffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "flags",
          "p": 1835056
        }
      ],
      "n": "SendFile",
      "d": 852016,
      "h": 940598689840,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(940598689840),
//--TRIMMABLE-BOUNDARY-START(944893657136),
    {
      "r": 65537,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "preBuffer",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "postBuffer",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "flags",
          "p": 1835056
        }
      ],
      "n": "SendFile",
      "o": "@$1",
      "d": 852016,
      "h": 944893657136,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(944893657136),
//--TRIMMABLE-BOUNDARY-START(953483591728),
    {
      "r": 180551681,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "preBuffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "postBuffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "flags",
          "p": 1835056
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "SendFileAsync",
      "d": 852016,
      "h": 953483591728,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(953483591728),
//--TRIMMABLE-BOUNDARY-START(957778559024),
    {
      "r": 180551681,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "SendFileAsync",
      "o": "@$1",
      "d": 852016,
      "h": 957778559024,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(957778559024),
//--TRIMMABLE-BOUNDARY-START(962073526320),
    {
      "r": 262145,
      "p": [
        {
          "n": "e",
          "p": 917552
        }
      ],
      "n": "SendPacketsAsync",
      "d": 852016,
      "h": 962073526320,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(962073526320),
//--TRIMMABLE-BOUNDARY-START(970663460912),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEP",
          "p": 2555951
        }
      ],
      "n": "SendTo",
      "d": 852016,
      "h": 970663460912,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(970663460912),
//--TRIMMABLE-BOUNDARY-START(974958428208),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "size",
          "p": 655361
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEP",
          "p": 2555951
        }
      ],
      "n": "SendTo",
      "o": "@$1",
      "d": 852016,
      "h": 974958428208,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(974958428208),
//--TRIMMABLE-BOUNDARY-START(979253395504),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "remoteEP",
          "p": 2555951
        }
      ],
      "n": "SendTo",
      "o": "@$2",
      "d": 852016,
      "h": 979253395504,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(979253395504),
//--TRIMMABLE-BOUNDARY-START(983548362800),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEP",
          "p": 2555951
        }
      ],
      "n": "SendTo",
      "o": "@$3",
      "d": 852016,
      "h": 983548362800,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(983548362800),
//--TRIMMABLE-BOUNDARY-START(987843330096),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "remoteEP",
          "p": 2555951
        }
      ],
      "n": "SendTo",
      "o": "@$4",
      "d": 852016,
      "h": 987843330096,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(987843330096),
//--TRIMMABLE-BOUNDARY-START(992138297392),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEP",
          "p": 2555951
        }
      ],
      "n": "SendTo",
      "o": "@$5",
      "d": 852016,
      "h": 992138297392,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(992138297392),
//--TRIMMABLE-BOUNDARY-START(996433264688),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "socketAddress",
          "p": 4325423
        }
      ],
      "n": "SendTo",
      "o": "@$6",
      "d": 852016,
      "h": 996433264688,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(996433264688),
//--TRIMMABLE-BOUNDARY-START(1000728231984),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "remoteEP",
          "p": 2555951
        }
      ],
      "n": "SendToAsync",
      "d": 852016,
      "h": 1000728231984,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1000728231984),
//--TRIMMABLE-BOUNDARY-START(1005023199280),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEP",
          "p": 2555951
        }
      ],
      "n": "SendToAsync",
      "o": "@$1",
      "d": 852016,
      "h": 1005023199280,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1005023199280),
//--TRIMMABLE-BOUNDARY-START(1022203068464),
    {
      "r": 262145,
      "p": [
        {
          "n": "e",
          "p": 917552
        }
      ],
      "n": "SendToAsync",
      "o": "@$5",
      "d": 852016,
      "h": 1022203068464,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1022203068464),
//--TRIMMABLE-BOUNDARY-START(1009318166576),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "remoteEP",
          "p": 2555951
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "SendToAsync",
      "o": "@$2",
      "d": 852016,
      "h": 1009318166576,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1009318166576),
//--TRIMMABLE-BOUNDARY-START(1013613133872),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "remoteEP",
          "p": 2555951
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "SendToAsync",
      "o": "@$3",
      "d": 852016,
      "h": 1013613133872,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1013613133872),
//--TRIMMABLE-BOUNDARY-START(1017908101168),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "socketFlags",
          "p": 1048624
        },
        {
          "n": "socketAddress",
          "p": 4325423
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "SendToAsync",
      "o": "@$4",
      "d": 852016,
      "h": 1017908101168,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1017908101168),
//--TRIMMABLE-BOUNDARY-START(1146757120048),
    {
      "r": 65537,
      "p": [
        {
          "n": "level",
          "p": 196656
        }
      ],
      "n": "SetIPProtectionLevel",
      "d": 852016,
      "h": 1146757120048,
      "f": 16777217,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(1146757120048),
//--TRIMMABLE-BOUNDARY-START(1151052087344),
    {
      "r": 65537,
      "p": [
        {
          "n": "optionLevel",
          "p": 655361
        },
        {
          "n": "optionName",
          "p": 655361
        },
        {
          "n": "optionValue",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "SetRawSocketOption",
      "d": 852016,
      "h": 1151052087344,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1151052087344),
//--TRIMMABLE-BOUNDARY-START(1155347054640),
    {
      "r": 65537,
      "p": [
        {
          "n": "optionLevel",
          "p": 1245232
        },
        {
          "n": "optionName",
          "p": 1310768
        },
        {
          "n": "optionValue",
          "p": 262145
        }
      ],
      "n": "SetSocketOption",
      "d": 852016,
      "h": 1155347054640,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1155347054640),
//--TRIMMABLE-BOUNDARY-START(1159642021936),
    {
      "r": 65537,
      "p": [
        {
          "n": "optionLevel",
          "p": 1245232
        },
        {
          "n": "optionName",
          "p": 1310768
        },
        {
          "n": "optionValue",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "SetSocketOption",
      "o": "@$1",
      "d": 852016,
      "h": 1159642021936,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1159642021936),
//--TRIMMABLE-BOUNDARY-START(1163936989232),
    {
      "r": 65537,
      "p": [
        {
          "n": "optionLevel",
          "p": 1245232
        },
        {
          "n": "optionName",
          "p": 1310768
        },
        {
          "n": "optionValue",
          "p": 655361
        }
      ],
      "n": "SetSocketOption",
      "o": "@$2",
      "d": 852016,
      "h": 1163936989232,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1163936989232),
//--TRIMMABLE-BOUNDARY-START(1168231956528),
    {
      "r": 65537,
      "p": [
        {
          "n": "optionLevel",
          "p": 1245232
        },
        {
          "n": "optionName",
          "p": 1310768
        },
        {
          "n": "optionValue",
          "p": 131073
        }
      ],
      "n": "SetSocketOption",
      "o": "@$3",
      "d": 852016,
      "h": 1168231956528,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1168231956528),
//--TRIMMABLE-BOUNDARY-START(1172526923824),
    {
      "r": 65537,
      "p": [
        {
          "n": "how",
          "p": 1507376
        }
      ],
      "n": "Shutdown",
      "d": 852016,
      "h": 1172526923824,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1172526923824)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819312),
    {
      "p": [
        {
          "n": "addressFamily",
          "p": 4456495
        },
        {
          "n": "socketType",
          "p": 1638448
        },
        {
          "n": "protocolType",
          "p": 589872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 852016,
      "h": 4295819312,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819312),
//--TRIMMABLE-BOUNDARY-START(8590786608),
    {
      "p": [
        {
          "n": "handle",
          "p": 655408
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 852016,
      "h": 8590786608,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590786608),
//--TRIMMABLE-BOUNDARY-START(12885753904),
    {
      "p": [
        {
          "n": "socketInformation",
          "p": 1114160
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 852016,
      "h": 12885753904,
      "f": 16777217,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885753904),
//--TRIMMABLE-BOUNDARY-START(17180721200),
    {
      "p": [
        {
          "n": "socketType",
          "p": 1638448
        },
        {
          "n": "protocolType",
          "p": 589872
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 852016,
      "h": 17180721200,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180721200)
  ],
  "i": [90308609
  ],
  "h": 852016
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.Socket`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852016)
        
        
        //--TRIMMABLE-BOUNDARY-START(1703984)
        $asm.$cls("$sns.System.Net.Sockets.TcpClient", ($self) => class TcpClient extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296671280)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296671280);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296671280)
            
            //--TRIMMABLE-BOUNDARY-START(12886605872)
            $ctor$3(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886605872);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886605872)
            
            //--TRIMMABLE-BOUNDARY-START(17181573168)
            $ctor$4(/*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181573168);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181573168)
            
            //--TRIMMABLE-BOUNDARY-START(8591638576)
            $ctor$2(/*string*/ hostname, /*int*/ port)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591638576);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591638576)
            
            //--TRIMMABLE-BOUNDARY-START(21476540464)
            /*bool */ get Active()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145690160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Active(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699741744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21476540464)
            
            //--TRIMMABLE-BOUNDARY-START(25771507760)
            /*int */ get Available()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735624752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25771507760)
            
            //--TRIMMABLE-BOUNDARY-START(42951376944)
            /*System.Net.Sockets.Socket */ get Client()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325559344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ set Client(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289676336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42951376944)
            
            //--TRIMMABLE-BOUNDARY-START(103080919088)
            /*bool */ get Connected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915493936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103080919088)
            
            //--TRIMMABLE-BOUNDARY-START(120260788272)
            /*bool */ get ExclusiveAddressUse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505428528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879610928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120260788272)
            
            //--TRIMMABLE-BOUNDARY-START(227634970672)
            /*System.Net.Sockets.LingerOption? */ get LingerState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095363120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ set LingerState(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469545520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(227634970672)
            
            //--TRIMMABLE-BOUNDARY-START(231929937968)
            /*bool */ get NoDelay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685297712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set NoDelay(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292059480112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(231929937968)
            
            //--TRIMMABLE-BOUNDARY-START(236224905264)
            /*int */ get ReceiveBufferSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275232304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300649414704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(236224905264)
            
            //--TRIMMABLE-BOUNDARY-START(240519872560)
            /*int */ get ReceiveTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865166896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309239349296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(240519872560)
            
            //--TRIMMABLE-BOUNDARY-START(244814839856)
            /*int */ get SendBufferSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455101488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendBufferSize(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317829283888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(244814839856)
            
            //--TRIMMABLE-BOUNDARY-START(249109807152)
            /*int */ get SendTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045036080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326419218480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(249109807152)
            
            //--TRIMMABLE-BOUNDARY-START(34361442352)
            /*System.IAsyncResult */ BeginConnect$1(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361442352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34361442352)
            
            //--TRIMMABLE-BOUNDARY-START(38656409648)
            /*System.IAsyncResult */ BeginConnect$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656409648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38656409648)
            
            //--TRIMMABLE-BOUNDARY-START(30066475056)
            /*System.IAsyncResult */ BeginConnect(/*string*/ host, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066475056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30066475056)
            
            //--TRIMMABLE-BOUNDARY-START(47246344240)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246344240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47246344240)
            
            //--TRIMMABLE-BOUNDARY-START(55836278832)
            /*void */ Connect$1(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836278832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(55836278832)
            
            //--TRIMMABLE-BOUNDARY-START(60131246128)
            /*void */ Connect$2(/*System.Net.IPAddress[]*/ ipAddresses, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131246128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60131246128)
            
            //--TRIMMABLE-BOUNDARY-START(64426213424)
            /*void */ Connect$3(/*System.Net.IPEndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426213424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64426213424)
            
            //--TRIMMABLE-BOUNDARY-START(51541311536)
            /*void */ Connect(/*string*/ hostname, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541311536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51541311536)
            
            //--TRIMMABLE-BOUNDARY-START(81606082608)
            /*System.Threading.Tasks.Task */ ConnectAsync$3(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606082608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81606082608)
            
            //--TRIMMABLE-BOUNDARY-START(77311115312)
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$2(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311115312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77311115312)
            
            //--TRIMMABLE-BOUNDARY-START(90196017200)
            /*System.Threading.Tasks.Task */ ConnectAsync$5(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196017200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90196017200)
            
            //--TRIMMABLE-BOUNDARY-START(85901049904)
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$4(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901049904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85901049904)
            
            //--TRIMMABLE-BOUNDARY-START(98785951792)
            /*System.Threading.Tasks.Task */ ConnectAsync$7(/*System.Net.IPEndPoint*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785951792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(98785951792)
            
            //--TRIMMABLE-BOUNDARY-START(94490984496)
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$6(/*System.Net.IPEndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490984496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(94490984496)
            
            //--TRIMMABLE-BOUNDARY-START(73016148016)
            /*System.Threading.Tasks.Task */ ConnectAsync$1(/*string*/ host, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016148016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73016148016)
            
            //--TRIMMABLE-BOUNDARY-START(68721180720)
            /*System.Threading.Tasks.ValueTask */ ConnectAsync(/*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721180720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68721180720)
            
            //--TRIMMABLE-BOUNDARY-START(107375886384)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375886384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(107375886384)
            
            //--TRIMMABLE-BOUNDARY-START(111670853680)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670853680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(111670853680)
            
            //--TRIMMABLE-BOUNDARY-START(115965820976)
            /*void */ EndConnect(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965820976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(115965820976)
            
            $dtor()
            {
            }
            //--TRIMMABLE-BOUNDARY-START(223340003376)
            /*System.Net.Sockets.NetworkStream */ GetStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340003376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(223340003376)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1703984;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476540464),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145690160,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257699741744,
        "f": 83886084
      },
      "n": "Active",
      "d": 1703984,
      "h": 21476540464,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(21476540464),
//--TRIMMABLE-BOUNDARY-START(25771507760),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735624752,
        "f": 50331649
      },
      "n": "Available",
      "d": 1703984,
      "h": 25771507760,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771507760),
//--TRIMMABLE-BOUNDARY-START(42951376944),
    {
      "p": 852016,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325559344,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266289676336,
        "f": 83886081
      },
      "n": "Client",
      "d": 1703984,
      "h": 42951376944,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951376944),
//--TRIMMABLE-BOUNDARY-START(103080919088),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915493936,
        "f": 50331649
      },
      "n": "Connected",
      "d": 1703984,
      "h": 103080919088,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080919088),
//--TRIMMABLE-BOUNDARY-START(120260788272),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505428528,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274879610928,
        "f": 83886081
      },
      "n": "ExclusiveAddressUse",
      "d": 1703984,
      "h": 120260788272,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260788272),
//--TRIMMABLE-BOUNDARY-START(227634970672),
    {
      "p": 327728,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176095363120,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283469545520,
        "f": 83886081
      },
      "n": "LingerState",
      "d": 1703984,
      "h": 227634970672,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227634970672),
//--TRIMMABLE-BOUNDARY-START(231929937968),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184685297712,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292059480112,
        "f": 83886081
      },
      "n": "NoDelay",
      "d": 1703984,
      "h": 231929937968,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(231929937968),
//--TRIMMABLE-BOUNDARY-START(236224905264),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193275232304,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300649414704,
        "f": 83886081
      },
      "n": "ReceiveBufferSize",
      "d": 1703984,
      "h": 236224905264,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236224905264),
//--TRIMMABLE-BOUNDARY-START(240519872560),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201865166896,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309239349296,
        "f": 83886081
      },
      "n": "ReceiveTimeout",
      "d": 1703984,
      "h": 240519872560,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240519872560),
//--TRIMMABLE-BOUNDARY-START(244814839856),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210455101488,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317829283888,
        "f": 83886081
      },
      "n": "SendBufferSize",
      "d": 1703984,
      "h": 244814839856,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244814839856),
//--TRIMMABLE-BOUNDARY-START(249109807152),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219045036080,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326419218480,
        "f": 83886081
      },
      "n": "SendTimeout",
      "d": 1703984,
      "h": 249109807152,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(249109807152)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361442352),
    {
      "r": 89784321,
      "p": [
        {
          "n": "address",
          "p": 3014703
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "requestCallback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginConnect",
      "o": "@$1",
      "d": 1703984,
      "h": 34361442352,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361442352),
//--TRIMMABLE-BOUNDARY-START(38656409648),
    {
      "r": 89784321,
      "p": [
        {
          "n": "addresses",
          "p": $.$typeArray($.$snp.System.Net.IPAddress).$h
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "requestCallback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginConnect",
      "o": "@$2",
      "d": 1703984,
      "h": 38656409648,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656409648),
//--TRIMMABLE-BOUNDARY-START(30066475056),
    {
      "r": 89784321,
      "p": [
        {
          "n": "host",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "requestCallback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginConnect",
      "d": 1703984,
      "h": 30066475056,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066475056),
//--TRIMMABLE-BOUNDARY-START(47246344240),
    {
      "r": 65537,
      "n": "Close",
      "d": 1703984,
      "h": 47246344240,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246344240),
//--TRIMMABLE-BOUNDARY-START(55836278832),
    {
      "r": 65537,
      "p": [
        {
          "n": "address",
          "p": 3014703
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "Connect",
      "o": "@$1",
      "d": 1703984,
      "h": 55836278832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836278832),
//--TRIMMABLE-BOUNDARY-START(60131246128),
    {
      "r": 65537,
      "p": [
        {
          "n": "ipAddresses",
          "p": $.$typeArray($.$snp.System.Net.IPAddress).$h
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "Connect",
      "o": "@$2",
      "d": 1703984,
      "h": 60131246128,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131246128),
//--TRIMMABLE-BOUNDARY-START(64426213424),
    {
      "r": 65537,
      "p": [
        {
          "n": "remoteEP",
          "p": 3276847
        }
      ],
      "n": "Connect",
      "o": "@$3",
      "d": 1703984,
      "h": 64426213424,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426213424),
//--TRIMMABLE-BOUNDARY-START(51541311536),
    {
      "r": 65537,
      "p": [
        {
          "n": "hostname",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "Connect",
      "d": 1703984,
      "h": 51541311536,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541311536),
//--TRIMMABLE-BOUNDARY-START(81606082608),
    {
      "r": 177668097,
      "p": [
        {
          "n": "address",
          "p": 3014703
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "ConnectAsync",
      "o": "@$3",
      "d": 1703984,
      "h": 81606082608,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81606082608),
//--TRIMMABLE-BOUNDARY-START(77311115312),
    {
      "r": 180551681,
      "p": [
        {
          "n": "address",
          "p": 3014703
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ConnectAsync",
      "o": "@$2",
      "d": 1703984,
      "h": 77311115312,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311115312),
//--TRIMMABLE-BOUNDARY-START(90196017200),
    {
      "r": 177668097,
      "p": [
        {
          "n": "addresses",
          "p": $.$typeArray($.$snp.System.Net.IPAddress).$h
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "ConnectAsync",
      "o": "@$5",
      "d": 1703984,
      "h": 90196017200,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90196017200),
//--TRIMMABLE-BOUNDARY-START(85901049904),
    {
      "r": 180551681,
      "p": [
        {
          "n": "addresses",
          "p": $.$typeArray($.$snp.System.Net.IPAddress).$h
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ConnectAsync",
      "o": "@$4",
      "d": 1703984,
      "h": 85901049904,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85901049904),
//--TRIMMABLE-BOUNDARY-START(98785951792),
    {
      "r": 177668097,
      "p": [
        {
          "n": "remoteEP",
          "p": 3276847
        }
      ],
      "n": "ConnectAsync",
      "o": "@$7",
      "d": 1703984,
      "h": 98785951792,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98785951792),
//--TRIMMABLE-BOUNDARY-START(94490984496),
    {
      "r": 180551681,
      "p": [
        {
          "n": "remoteEP",
          "p": 3276847
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ConnectAsync",
      "o": "@$6",
      "d": 1703984,
      "h": 94490984496,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490984496),
//--TRIMMABLE-BOUNDARY-START(73016148016),
    {
      "r": 177668097,
      "p": [
        {
          "n": "host",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "ConnectAsync",
      "o": "@$1",
      "d": 1703984,
      "h": 73016148016,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016148016),
//--TRIMMABLE-BOUNDARY-START(68721180720),
    {
      "r": 180551681,
      "p": [
        {
          "n": "host",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ConnectAsync",
      "d": 1703984,
      "h": 68721180720,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721180720),
//--TRIMMABLE-BOUNDARY-START(107375886384),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1703984,
      "h": 107375886384,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107375886384),
//--TRIMMABLE-BOUNDARY-START(111670853680),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 1703984,
      "h": 111670853680,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(111670853680),
//--TRIMMABLE-BOUNDARY-START(115965820976),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndConnect",
      "d": 1703984,
      "h": 115965820976,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115965820976),
//--TRIMMABLE-BOUNDARY-START(223340003376),
    {
      "r": 458800,
      "n": "GetStream",
      "d": 1703984,
      "h": 223340003376,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223340003376)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671280),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1703984,
      "h": 4296671280,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296671280),
//--TRIMMABLE-BOUNDARY-START(12886605872),
    {
      "p": [
        {
          "n": "localEP",
          "p": 3276847
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1703984,
      "h": 12886605872,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886605872),
//--TRIMMABLE-BOUNDARY-START(17181573168),
    {
      "p": [
        {
          "n": "family",
          "p": 4456495
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1703984,
      "h": 17181573168,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181573168),
//--TRIMMABLE-BOUNDARY-START(8591638576),
    {
      "p": [
        {
          "n": "hostname",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1703984,
      "h": 8591638576,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591638576)
  ],
  "i": [90308609
  ],
  "h": 1703984
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.TcpClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703984)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769520)
        $asm.$cls("$sns.System.Net.Sockets.TcpListener", ($self) => class TcpListener extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296736816)
            $ctor$1(/*int*/ port)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296736816);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296736816)
            
            //--TRIMMABLE-BOUNDARY-START(8591704112)
            $ctor$2(/*System.Net.IPAddress*/ localaddr, /*int*/ port)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591704112);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591704112)
            
            //--TRIMMABLE-BOUNDARY-START(12886671408)
            $ctor$3(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886671408);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886671408)
            
            //--TRIMMABLE-BOUNDARY-START(42951442480)
            /*bool */ get Active()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901115440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42951442480)
            
            //--TRIMMABLE-BOUNDARY-START(77311180848)
            /*bool */ get ExclusiveAddressUse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491050032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145755696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77311180848)
            
            //--TRIMMABLE-BOUNDARY-START(115965886512)
            /*System.Net.EndPoint */ get LocalEndpoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080984624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115965886512)
            
            //--TRIMMABLE-BOUNDARY-START(124555821104)
            /*System.Net.Sockets.Socket */ get Server()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670919216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(124555821104)
            
            //--TRIMMABLE-BOUNDARY-START(17181638704)
            /*System.Net.Sockets.Socket */ AcceptSocket()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181638704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17181638704)
            
            //--TRIMMABLE-BOUNDARY-START(21476606000)
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptSocketAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476606000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21476606000)
            
            //--TRIMMABLE-BOUNDARY-START(25771573296)
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptSocketAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771573296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25771573296)
            
            //--TRIMMABLE-BOUNDARY-START(30066540592)
            /*System.Net.Sockets.TcpClient */ AcceptTcpClient()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066540592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30066540592)
            
            //--TRIMMABLE-BOUNDARY-START(34361507888)
            /*System.Threading.Tasks.Task<System.Net.Sockets.TcpClient> */ AcceptTcpClientAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361507888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34361507888)
            
            //--TRIMMABLE-BOUNDARY-START(38656475184)
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.TcpClient> */ AcceptTcpClientAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656475184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38656475184)
            
            //--TRIMMABLE-BOUNDARY-START(47246409776)
            /*void */ AllowNatTraversal(/*bool*/ allowed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246409776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47246409776)
            
            //--TRIMMABLE-BOUNDARY-START(51541377072)
            /*System.IAsyncResult */ BeginAcceptSocket(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541377072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51541377072)
            
            //--TRIMMABLE-BOUNDARY-START(55836344368)
            /*System.IAsyncResult */ BeginAcceptTcpClient(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836344368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55836344368)
            
            //--TRIMMABLE-BOUNDARY-START(60131311664)
            static /*System.Net.Sockets.TcpListener */ Create(/*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131311664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60131311664)
            
            //--TRIMMABLE-BOUNDARY-START(64426278960)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426278960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64426278960)
            
            //--TRIMMABLE-BOUNDARY-START(68721246256)
            /*System.Net.Sockets.Socket */ EndAcceptSocket(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721246256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68721246256)
            
            //--TRIMMABLE-BOUNDARY-START(73016213552)
            /*System.Net.Sockets.TcpClient */ EndAcceptTcpClient(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016213552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73016213552)
            
            //--TRIMMABLE-BOUNDARY-START(120260853808)
            /*bool */ Pending()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260853808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120260853808)
            
            //--TRIMMABLE-BOUNDARY-START(137440722992)
            /*void */ Start()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440722992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(137440722992)
            
            //--TRIMMABLE-BOUNDARY-START(141735690288)
            /*void */ Start$1(/*int*/ backlog)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735690288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(141735690288)
            
            //--TRIMMABLE-BOUNDARY-START(146030657584)
            /*void */ Stop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030657584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(146030657584)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            static $h = 1769520;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951442480),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901115440,
        "f": 50331652
      },
      "n": "Active",
      "d": 1769520,
      "h": 42951442480,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(42951442480),
//--TRIMMABLE-BOUNDARY-START(77311180848),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491050032,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145755696,
        "f": 83886081
      },
      "n": "ExclusiveAddressUse",
      "d": 1769520,
      "h": 77311180848,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311180848),
//--TRIMMABLE-BOUNDARY-START(115965886512),
    {
      "p": 2555951,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080984624,
        "f": 50331649
      },
      "n": "LocalEndpoint",
      "d": 1769520,
      "h": 115965886512,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965886512),
//--TRIMMABLE-BOUNDARY-START(124555821104),
    {
      "p": 852016,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670919216,
        "f": 50331649
      },
      "n": "Server",
      "d": 1769520,
      "h": 124555821104,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124555821104)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181638704),
    {
      "r": 852016,
      "n": "AcceptSocket",
      "d": 1769520,
      "h": 17181638704,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181638704),
//--TRIMMABLE-BOUNDARY-START(21476606000),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,
      "n": "AcceptSocketAsync",
      "d": 1769520,
      "h": 21476606000,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476606000),
//--TRIMMABLE-BOUNDARY-START(25771573296),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "AcceptSocketAsync",
      "o": "@$1",
      "d": 1769520,
      "h": 25771573296,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771573296),
//--TRIMMABLE-BOUNDARY-START(30066540592),
    {
      "r": 1703984,
      "n": "AcceptTcpClient",
      "d": 1769520,
      "h": 30066540592,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066540592),
//--TRIMMABLE-BOUNDARY-START(34361507888),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.TcpClient).$h,
      "n": "AcceptTcpClientAsync",
      "d": 1769520,
      "h": 34361507888,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361507888),
//--TRIMMABLE-BOUNDARY-START(38656475184),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.TcpClient).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "AcceptTcpClientAsync",
      "o": "@$1",
      "d": 1769520,
      "h": 38656475184,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656475184),
//--TRIMMABLE-BOUNDARY-START(47246409776),
    {
      "r": 65537,
      "p": [
        {
          "n": "allowed",
          "p": 262145
        }
      ],
      "n": "AllowNatTraversal",
      "d": 1769520,
      "h": 47246409776,
      "f": 16777217,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246409776),
//--TRIMMABLE-BOUNDARY-START(51541377072),
    {
      "r": 89784321,
      "p": [
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginAcceptSocket",
      "d": 1769520,
      "h": 51541377072,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541377072),
//--TRIMMABLE-BOUNDARY-START(55836344368),
    {
      "r": 89784321,
      "p": [
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginAcceptTcpClient",
      "d": 1769520,
      "h": 55836344368,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836344368),
//--TRIMMABLE-BOUNDARY-START(60131311664),
    {
      "r": 1769520,
      "p": [
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "Create",
      "d": 1769520,
      "h": 60131311664,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60131311664),
//--TRIMMABLE-BOUNDARY-START(64426278960),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1769520,
      "h": 64426278960,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426278960),
//--TRIMMABLE-BOUNDARY-START(68721246256),
    {
      "r": 852016,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndAcceptSocket",
      "d": 1769520,
      "h": 68721246256,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721246256),
//--TRIMMABLE-BOUNDARY-START(73016213552),
    {
      "r": 1703984,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndAcceptTcpClient",
      "d": 1769520,
      "h": 73016213552,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016213552),
//--TRIMMABLE-BOUNDARY-START(120260853808),
    {
      "r": 262145,
      "n": "Pending",
      "d": 1769520,
      "h": 120260853808,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120260853808),
//--TRIMMABLE-BOUNDARY-START(137440722992),
    {
      "r": 65537,
      "n": "Start",
      "d": 1769520,
      "h": 137440722992,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137440722992),
//--TRIMMABLE-BOUNDARY-START(141735690288),
    {
      "r": 65537,
      "p": [
        {
          "n": "backlog",
          "p": 655361
        }
      ],
      "n": "Start",
      "o": "@$1",
      "d": 1769520,
      "h": 141735690288,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141735690288),
//--TRIMMABLE-BOUNDARY-START(146030657584),
    {
      "r": 65537,
      "n": "Stop",
      "d": 1769520,
      "h": 146030657584,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146030657584)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296736816),
    {
      "p": [
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1769520,
      "h": 4296736816,
      "f": 16777217,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "This constructor has been deprecated. Use TcpListener(IPAddress localaddr, int port) instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4296736816),
//--TRIMMABLE-BOUNDARY-START(8591704112),
    {
      "p": [
        {
          "n": "localaddr",
          "p": 3014703
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1769520,
      "h": 8591704112,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591704112),
//--TRIMMABLE-BOUNDARY-START(12886671408),
    {
      "p": [
        {
          "n": "localEP",
          "p": 3276847
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1769520,
      "h": 12886671408,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886671408)
  ],
  "i": [90308609
  ],
  "h": 1769520
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.TcpListener`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769520)
        
        
        //--TRIMMABLE-BOUNDARY-START(1900592)
        $asm.$cls("$sns.System.Net.Sockets.UdpClient", ($self) => class UdpClient extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296867888)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296867888);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296867888)
            
            //--TRIMMABLE-BOUNDARY-START(12886802480)
            $ctor$3(/*int*/ port)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886802480);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886802480)
            
            //--TRIMMABLE-BOUNDARY-START(8591835184)
            $ctor$2(/*int*/ port, /*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591835184);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591835184)
            
            //--TRIMMABLE-BOUNDARY-START(21476737072)
            $ctor$5(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476737072);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476737072)
            
            //--TRIMMABLE-BOUNDARY-START(25771704368)
            $ctor$6(/*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771704368);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771704368)
            
            //--TRIMMABLE-BOUNDARY-START(17181769776)
            $ctor$4(/*string*/ hostname, /*int*/ port)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181769776);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181769776)
            
            //--TRIMMABLE-BOUNDARY-START(30066671664)
            /*bool */ get Active()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555952176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Active(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174774832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30066671664)
            
            //--TRIMMABLE-BOUNDARY-START(38656606256)
            /*int */ get Available()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145886768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38656606256)
            
            //--TRIMMABLE-BOUNDARY-START(60131442736)
            /*System.Net.Sockets.Socket */ get Client()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735821360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ set Client(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764709424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60131442736)
            
            //--TRIMMABLE-BOUNDARY-START(90196213808)
            /*bool */ get DontFragment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325755952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DontFragment(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354644016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90196213808)
            
            //--TRIMMABLE-BOUNDARY-START(103081115696)
            /*bool */ get EnableBroadcast()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915690544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableBroadcast(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304944578608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103081115696)
            
            //--TRIMMABLE-BOUNDARY-START(115966017584)
            /*bool */ get ExclusiveAddressUse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505625136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313534513200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115966017584)
            
            //--TRIMMABLE-BOUNDARY-START(206160330800)
            /*bool */ get MulticastLoopback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095559728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MulticastLoopback(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322124447792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(206160330800)
            
            //--TRIMMABLE-BOUNDARY-START(335009349680)
            /*short */ get Ttl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685494320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ set Ttl(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714382384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(335009349680)
            
            //--TRIMMABLE-BOUNDARY-START(34361638960)
            /*void */ AllowNatTraversal(/*bool*/ allowed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361638960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(34361638960)
            
            //--TRIMMABLE-BOUNDARY-START(42951573552)
            /*System.IAsyncResult */ BeginReceive(/*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951573552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42951573552)
            
            //--TRIMMABLE-BOUNDARY-START(47246540848)
            /*System.IAsyncResult */ BeginSend(/*byte[]*/ datagram, /*int*/ bytes, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246540848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47246540848)
            
            //--TRIMMABLE-BOUNDARY-START(55836475440)
            /*System.IAsyncResult */ BeginSend$2(/*byte[]*/ datagram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836475440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55836475440)
            
            //--TRIMMABLE-BOUNDARY-START(51541508144)
            /*System.IAsyncResult */ BeginSend$1(/*byte[]*/ datagram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541508144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51541508144)
            
            //--TRIMMABLE-BOUNDARY-START(64426410032)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426410032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64426410032)
            
            //--TRIMMABLE-BOUNDARY-START(73016344624)
            /*void */ Connect$1(/*System.Net.IPAddress*/ addr, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016344624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(73016344624)
            
            //--TRIMMABLE-BOUNDARY-START(77311311920)
            /*void */ Connect$2(/*System.Net.IPEndPoint*/ endPoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311311920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(77311311920)
            
            //--TRIMMABLE-BOUNDARY-START(68721377328)
            /*void */ Connect(/*string*/ hostname, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721377328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(68721377328)
            
            //--TRIMMABLE-BOUNDARY-START(81606279216)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606279216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(81606279216)
            
            //--TRIMMABLE-BOUNDARY-START(85901246512)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901246512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(85901246512)
            
            //--TRIMMABLE-BOUNDARY-START(98786148400)
            /*void */ DropMulticastGroup$1(/*System.Net.IPAddress*/ multicastAddr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786148400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(98786148400)
            
            //--TRIMMABLE-BOUNDARY-START(94491181104)
            /*void */ DropMulticastGroup(/*System.Net.IPAddress*/ multicastAddr, /*int*/ ifindex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491181104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(94491181104)
            
            //--TRIMMABLE-BOUNDARY-START(107376082992)
            /*byte[] */ EndReceive(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.IPEndPoint?*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376082992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(107376082992)
            
            //--TRIMMABLE-BOUNDARY-START(111671050288)
            /*int */ EndSend(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671050288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111671050288)
            
            //--TRIMMABLE-BOUNDARY-START(188980461616)
            /*void */ JoinMulticastGroup(/*int*/ ifindex, /*System.Net.IPAddress*/ multicastAddr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980461616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(188980461616)
            
            //--TRIMMABLE-BOUNDARY-START(201865363504)
            /*void */ JoinMulticastGroup$3(/*System.Net.IPAddress*/ multicastAddr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865363504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(201865363504)
            
            //--TRIMMABLE-BOUNDARY-START(193275428912)
            /*void */ JoinMulticastGroup$1(/*System.Net.IPAddress*/ multicastAddr, /*int*/ timeToLive)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275428912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(193275428912)
            
            //--TRIMMABLE-BOUNDARY-START(197570396208)
            /*void */ JoinMulticastGroup$2(/*System.Net.IPAddress*/ multicastAddr, /*System.Net.IPAddress*/ localAddress)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570396208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(197570396208)
            
            //--TRIMMABLE-BOUNDARY-START(210455298096)
            /*byte[] */ Receive(/*ref System.Net.IPEndPoint?*/ remoteEP)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455298096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(210455298096)
            
            //--TRIMMABLE-BOUNDARY-START(214750265392)
            /*System.Threading.Tasks.Task<System.Net.Sockets.UdpReceiveResult> */ ReceiveAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750265392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(214750265392)
            
            //--TRIMMABLE-BOUNDARY-START(219045232688)
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.UdpReceiveResult> */ ReceiveAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045232688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(219045232688)
            
            //--TRIMMABLE-BOUNDARY-START(231930134576)
            /*int */ Send$2(/*byte[]*/ dgram, /*int*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930134576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(231930134576)
            
            //--TRIMMABLE-BOUNDARY-START(227635167280)
            /*int */ Send$1(/*byte[]*/ dgram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635167280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(227635167280)
            
            //--TRIMMABLE-BOUNDARY-START(223340199984)
            /*int */ Send(/*byte[]*/ dgram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340199984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(223340199984)
            
            //--TRIMMABLE-BOUNDARY-START(244815036464)
            /*int */ Send$5(/*System.ReadOnlySpan<byte>*/ datagram)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815036464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(244815036464)
            
            //--TRIMMABLE-BOUNDARY-START(240520069168)
            /*int */ Send$4(/*System.ReadOnlySpan<byte>*/ datagram, /*System.Net.IPEndPoint?*/ endPoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240520069168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(240520069168)
            
            //--TRIMMABLE-BOUNDARY-START(236225101872)
            /*int */ Send$3(/*System.ReadOnlySpan<byte>*/ datagram, /*string?*/ hostname, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225101872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(236225101872)
            
            //--TRIMMABLE-BOUNDARY-START(257699938352)
            /*System.Threading.Tasks.Task<int> */ SendAsync$2(/*byte[]*/ datagram, /*int*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699938352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(257699938352)
            
            //--TRIMMABLE-BOUNDARY-START(253404971056)
            /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*byte[]*/ datagram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404971056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(253404971056)
            
            //--TRIMMABLE-BOUNDARY-START(249110003760)
            /*System.Threading.Tasks.Task<int> */ SendAsync(/*byte[]*/ datagram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249110003760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(249110003760)
            
            //--TRIMMABLE-BOUNDARY-START(270584840240)
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$5(/*System.ReadOnlyMemory<byte>*/ datagram, /*System.Net.IPEndPoint?*/ endPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584840240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(270584840240)
            
            //--TRIMMABLE-BOUNDARY-START(261994905648)
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$3(/*System.ReadOnlyMemory<byte>*/ datagram, /*string?*/ hostname, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994905648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(261994905648)
            
            //--TRIMMABLE-BOUNDARY-START(266289872944)
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$4(/*System.ReadOnlyMemory<byte>*/ datagram, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289872944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(266289872944)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            static $h = 1900592;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066671664),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555952176,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279174774832,
        "f": 83886084
      },
      "n": "Active",
      "d": 1900592,
      "h": 30066671664,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(30066671664),
//--TRIMMABLE-BOUNDARY-START(38656606256),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145886768,
        "f": 50331649
      },
      "n": "Available",
      "d": 1900592,
      "h": 38656606256,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656606256),
//--TRIMMABLE-BOUNDARY-START(60131442736),
    {
      "p": 852016,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735821360,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287764709424,
        "f": 83886081
      },
      "n": "Client",
      "d": 1900592,
      "h": 60131442736,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131442736),
//--TRIMMABLE-BOUNDARY-START(90196213808),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325755952,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296354644016,
        "f": 83886081
      },
      "n": "DontFragment",
      "d": 1900592,
      "h": 90196213808,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196213808),
//--TRIMMABLE-BOUNDARY-START(103081115696),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915690544,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304944578608,
        "f": 83886081
      },
      "n": "EnableBroadcast",
      "d": 1900592,
      "h": 103081115696,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103081115696),
//--TRIMMABLE-BOUNDARY-START(115966017584),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505625136,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313534513200,
        "f": 83886081
      },
      "n": "ExclusiveAddressUse",
      "d": 1900592,
      "h": 115966017584,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115966017584),
//--TRIMMABLE-BOUNDARY-START(206160330800),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176095559728,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322124447792,
        "f": 83886081
      },
      "n": "MulticastLoopback",
      "d": 1900592,
      "h": 206160330800,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206160330800),
//--TRIMMABLE-BOUNDARY-START(335009349680),
    {
      "p": 524289,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184685494320,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330714382384,
        "f": 83886081
      },
      "n": "Ttl",
      "d": 1900592,
      "h": 335009349680,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(335009349680)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361638960),
    {
      "r": 65537,
      "p": [
        {
          "n": "allowed",
          "p": 262145
        }
      ],
      "n": "AllowNatTraversal",
      "d": 1900592,
      "h": 34361638960,
      "f": 16777217,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361638960),
//--TRIMMABLE-BOUNDARY-START(42951573552),
    {
      "r": 89784321,
      "p": [
        {
          "n": "requestCallback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginReceive",
      "d": 1900592,
      "h": 42951573552,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951573552),
//--TRIMMABLE-BOUNDARY-START(47246540848),
    {
      "r": 89784321,
      "p": [
        {
          "n": "datagram",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "bytes",
          "p": 655361
        },
        {
          "n": "requestCallback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginSend",
      "d": 1900592,
      "h": 47246540848,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246540848),
//--TRIMMABLE-BOUNDARY-START(55836475440),
    {
      "r": 89784321,
      "p": [
        {
          "n": "datagram",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "bytes",
          "p": 655361
        },
        {
          "n": "endPoint",
          "p": 3276847
        },
        {
          "n": "requestCallback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginSend",
      "o": "@$2",
      "d": 1900592,
      "h": 55836475440,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836475440),
//--TRIMMABLE-BOUNDARY-START(51541508144),
    {
      "r": 89784321,
      "p": [
        {
          "n": "datagram",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "bytes",
          "p": 655361
        },
        {
          "n": "hostname",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "requestCallback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginSend",
      "o": "@$1",
      "d": 1900592,
      "h": 51541508144,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541508144),
//--TRIMMABLE-BOUNDARY-START(64426410032),
    {
      "r": 65537,
      "n": "Close",
      "d": 1900592,
      "h": 64426410032,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426410032),
//--TRIMMABLE-BOUNDARY-START(73016344624),
    {
      "r": 65537,
      "p": [
        {
          "n": "addr",
          "p": 3014703
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "Connect",
      "o": "@$1",
      "d": 1900592,
      "h": 73016344624,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016344624),
//--TRIMMABLE-BOUNDARY-START(77311311920),
    {
      "r": 65537,
      "p": [
        {
          "n": "endPoint",
          "p": 3276847
        }
      ],
      "n": "Connect",
      "o": "@$2",
      "d": 1900592,
      "h": 77311311920,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311311920),
//--TRIMMABLE-BOUNDARY-START(68721377328),
    {
      "r": 65537,
      "p": [
        {
          "n": "hostname",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "Connect",
      "d": 1900592,
      "h": 68721377328,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721377328),
//--TRIMMABLE-BOUNDARY-START(81606279216),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1900592,
      "h": 81606279216,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81606279216),
//--TRIMMABLE-BOUNDARY-START(85901246512),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 1900592,
      "h": 85901246512,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(85901246512),
//--TRIMMABLE-BOUNDARY-START(98786148400),
    {
      "r": 65537,
      "p": [
        {
          "n": "multicastAddr",
          "p": 3014703
        }
      ],
      "n": "DropMulticastGroup",
      "o": "@$1",
      "d": 1900592,
      "h": 98786148400,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98786148400),
//--TRIMMABLE-BOUNDARY-START(94491181104),
    {
      "r": 65537,
      "p": [
        {
          "n": "multicastAddr",
          "p": 3014703
        },
        {
          "n": "ifindex",
          "p": 655361
        }
      ],
      "n": "DropMulticastGroup",
      "d": 1900592,
      "h": 94491181104,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94491181104),
//--TRIMMABLE-BOUNDARY-START(107376082992),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        },
        {
          "n": "remoteEP",
          "p": 3276847,
          "f": 4
        }
      ],
      "n": "EndReceive",
      "d": 1900592,
      "h": 107376082992,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107376082992),
//--TRIMMABLE-BOUNDARY-START(111671050288),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndSend",
      "d": 1900592,
      "h": 111671050288,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111671050288),
//--TRIMMABLE-BOUNDARY-START(188980461616),
    {
      "r": 65537,
      "p": [
        {
          "n": "ifindex",
          "p": 655361
        },
        {
          "n": "multicastAddr",
          "p": 3014703
        }
      ],
      "n": "JoinMulticastGroup",
      "d": 1900592,
      "h": 188980461616,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188980461616),
//--TRIMMABLE-BOUNDARY-START(201865363504),
    {
      "r": 65537,
      "p": [
        {
          "n": "multicastAddr",
          "p": 3014703
        }
      ],
      "n": "JoinMulticastGroup",
      "o": "@$3",
      "d": 1900592,
      "h": 201865363504,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201865363504),
//--TRIMMABLE-BOUNDARY-START(193275428912),
    {
      "r": 65537,
      "p": [
        {
          "n": "multicastAddr",
          "p": 3014703
        },
        {
          "n": "timeToLive",
          "p": 655361
        }
      ],
      "n": "JoinMulticastGroup",
      "o": "@$1",
      "d": 1900592,
      "h": 193275428912,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193275428912),
//--TRIMMABLE-BOUNDARY-START(197570396208),
    {
      "r": 65537,
      "p": [
        {
          "n": "multicastAddr",
          "p": 3014703
        },
        {
          "n": "localAddress",
          "p": 3014703
        }
      ],
      "n": "JoinMulticastGroup",
      "o": "@$2",
      "d": 1900592,
      "h": 197570396208,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197570396208),
//--TRIMMABLE-BOUNDARY-START(210455298096),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "remoteEP",
          "p": 3276847,
          "f": 4
        }
      ],
      "n": "Receive",
      "d": 1900592,
      "h": 210455298096,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210455298096),
//--TRIMMABLE-BOUNDARY-START(214750265392),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h,
      "n": "ReceiveAsync",
      "d": 1900592,
      "h": 214750265392,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214750265392),
//--TRIMMABLE-BOUNDARY-START(219045232688),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReceiveAsync",
      "o": "@$1",
      "d": 1900592,
      "h": 219045232688,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(219045232688),
//--TRIMMABLE-BOUNDARY-START(231930134576),
    {
      "r": 655361,
      "p": [
        {
          "n": "dgram",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "bytes",
          "p": 655361
        }
      ],
      "n": "Send",
      "o": "@$2",
      "d": 1900592,
      "h": 231930134576,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231930134576),
//--TRIMMABLE-BOUNDARY-START(227635167280),
    {
      "r": 655361,
      "p": [
        {
          "n": "dgram",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "bytes",
          "p": 655361
        },
        {
          "n": "endPoint",
          "p": 3276847
        }
      ],
      "n": "Send",
      "o": "@$1",
      "d": 1900592,
      "h": 227635167280,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(227635167280),
//--TRIMMABLE-BOUNDARY-START(223340199984),
    {
      "r": 655361,
      "p": [
        {
          "n": "dgram",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "bytes",
          "p": 655361
        },
        {
          "n": "hostname",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "Send",
      "d": 1900592,
      "h": 223340199984,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223340199984),
//--TRIMMABLE-BOUNDARY-START(244815036464),
    {
      "r": 655361,
      "p": [
        {
          "n": "datagram",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "Send",
      "o": "@$5",
      "d": 1900592,
      "h": 244815036464,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(244815036464),
//--TRIMMABLE-BOUNDARY-START(240520069168),
    {
      "r": 655361,
      "p": [
        {
          "n": "datagram",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "endPoint",
          "p": 3276847
        }
      ],
      "n": "Send",
      "o": "@$4",
      "d": 1900592,
      "h": 240520069168,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(240520069168),
//--TRIMMABLE-BOUNDARY-START(236225101872),
    {
      "r": 655361,
      "p": [
        {
          "n": "datagram",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "hostname",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "Send",
      "o": "@$3",
      "d": 1900592,
      "h": 236225101872,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(236225101872),
//--TRIMMABLE-BOUNDARY-START(257699938352),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "datagram",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "bytes",
          "p": 655361
        }
      ],
      "n": "SendAsync",
      "o": "@$2",
      "d": 1900592,
      "h": 257699938352,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(257699938352),
//--TRIMMABLE-BOUNDARY-START(253404971056),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "datagram",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "bytes",
          "p": 655361
        },
        {
          "n": "endPoint",
          "p": 3276847
        }
      ],
      "n": "SendAsync",
      "o": "@$1",
      "d": 1900592,
      "h": 253404971056,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(253404971056),
//--TRIMMABLE-BOUNDARY-START(249110003760),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "datagram",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "bytes",
          "p": 655361
        },
        {
          "n": "hostname",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": "SendAsync",
      "d": 1900592,
      "h": 249110003760,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(249110003760),
//--TRIMMABLE-BOUNDARY-START(270584840240),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "datagram",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "endPoint",
          "p": 3276847
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "SendAsync",
      "o": "@$5",
      "d": 1900592,
      "h": 270584840240,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(270584840240),
//--TRIMMABLE-BOUNDARY-START(261994905648),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "datagram",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "hostname",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "SendAsync",
      "o": "@$3",
      "d": 1900592,
      "h": 261994905648,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(261994905648),
//--TRIMMABLE-BOUNDARY-START(266289872944),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "datagram",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "SendAsync",
      "o": "@$4",
      "d": 1900592,
      "h": 266289872944,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(266289872944)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296867888),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1900592,
      "h": 4296867888,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296867888),
//--TRIMMABLE-BOUNDARY-START(12886802480),
    {
      "p": [
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1900592,
      "h": 12886802480,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886802480),
//--TRIMMABLE-BOUNDARY-START(8591835184),
    {
      "p": [
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "family",
          "p": 4456495
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1900592,
      "h": 8591835184,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591835184),
//--TRIMMABLE-BOUNDARY-START(21476737072),
    {
      "p": [
        {
          "n": "localEP",
          "p": 3276847
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1900592,
      "h": 21476737072,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476737072),
//--TRIMMABLE-BOUNDARY-START(25771704368),
    {
      "p": [
        {
          "n": "family",
          "p": 4456495
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1900592,
      "h": 25771704368,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771704368),
//--TRIMMABLE-BOUNDARY-START(17181769776),
    {
      "p": [
        {
          "n": "hostname",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1900592,
      "h": 17181769776,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181769776)
  ],
  "i": [90308609
  ],
  "h": 1900592
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.UdpClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900592)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114160)
        $asm.$str("$sns.System.Net.Sockets.SocketInformation", ($self) => class SocketInformation extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296081456)
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4296081456)
            
            //--TRIMMABLE-BOUNDARY-START(8591048752)
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8591048752)
            
            //--TRIMMABLE-BOUNDARY-START(34360852528)
            /*System.Net.Sockets.SocketInformationOptions */ get Options()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475950640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketInformationOptions */ set Options(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245754416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360852528)
            
            //--TRIMMABLE-BOUNDARY-START(38655819824)
            /*byte[] */ get ProtocolInformation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065885232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ set ProtocolInformation(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835689008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655819824)
            
            //--TRIMMABLE-BOUNDARY-START(12886016048)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886016048)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296081456)
                this._dummy = null;
                //--TRIMMABLE-BOUNDARY-END(4296081456)
                
                //--TRIMMABLE-BOUNDARY-START(8591048752)
                this._dummyPrimitive = 0;
                //--TRIMMABLE-BOUNDARY-END(8591048752)
                
            }
            static $h = 1114160;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360852528),
    {
      "p": 1179696,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475950640,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245754416,
        "f": 83886081
      },
      "n": "Options",
      "d": 1114160,
      "h": 34360852528,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360852528),
//--TRIMMABLE-BOUNDARY-START(38655819824),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065885232,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835689008,
        "f": 83886081
      },
      "n": "ProtocolInformation",
      "d": 1114160,
      "h": 38655819824,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655819824)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296081456),
    {
      "t": 131073,
      "n": "_dummy",
      "d": 1114160,
      "h": 4296081456,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081456),
//--TRIMMABLE-BOUNDARY-START(8591048752),
    {
      "t": 655361,
      "n": "_dummyPrimitive",
      "d": 1114160,
      "h": 8591048752,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591048752)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886016048),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114160,
      "h": 12886016048,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886016048)
  ],
  "h": 1114160
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketInformation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114160)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376304)
        $asm.$str("$sns.System.Net.Sockets.SocketReceiveFromResult", ($self) => class SocketReceiveFromResult extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8591310896)
            /*int*/  get ReceivedBytes() { return this.$getField(0, 4); }
            /*int*/  set ReceivedBytes(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8591310896)
            
            //--TRIMMABLE-BOUNDARY-START(12886278192)
            /*System.Net.EndPoint*/  get RemoteEndPoint() { return this.$getField(4, 4); }
            /*System.Net.EndPoint*/  set RemoteEndPoint(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12886278192)
            
            //--TRIMMABLE-BOUNDARY-START(4296343600)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296343600)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ReceivedBytes = this.ReceivedBytes;
                copy.RemoteEndPoint = this.RemoteEndPoint;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591310896)
                this.ReceivedBytes = 0;
                //--TRIMMABLE-BOUNDARY-END(8591310896)
                
                //--TRIMMABLE-BOUNDARY-START(12886278192)
                this.RemoteEndPoint = null;
                //--TRIMMABLE-BOUNDARY-END(12886278192)
                
            }
            static $h = 1376304;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591310896),
    {
      "t": 655361,
      "n": "ReceivedBytes",
      "d": 1376304,
      "h": 8591310896,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8591310896),
//--TRIMMABLE-BOUNDARY-START(12886278192),
    {
      "t": 2555951,
      "n": "RemoteEndPoint",
      "d": 1376304,
      "h": 12886278192,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12886278192)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343600),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1376304,
      "h": 4296343600,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343600)
  ],
  "h": 1376304
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketReceiveFromResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376304)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441840)
        $asm.$str("$sns.System.Net.Sockets.SocketReceiveMessageFromResult", ($self) => class SocketReceiveMessageFromResult extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8591376432)
            /*System.Net.Sockets.IPPacketInformation*/  get PacketInformation() { return this.$getField(0, 8); }
            /*System.Net.Sockets.IPPacketInformation*/  set PacketInformation(value) { this.$setField(0, 8, value); }
            //--TRIMMABLE-BOUNDARY-END(8591376432)
            
            //--TRIMMABLE-BOUNDARY-START(12886343728)
            /*int*/  get ReceivedBytes() { return this.$getField(8, 4); }
            /*int*/  set ReceivedBytes(value) { this.$setField(8, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12886343728)
            
            //--TRIMMABLE-BOUNDARY-START(17181311024)
            /*System.Net.EndPoint*/  get RemoteEndPoint() { return this.$getField(12, 4); }
            /*System.Net.EndPoint*/  set RemoteEndPoint(value) { this.$setField(12, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(17181311024)
            
            //--TRIMMABLE-BOUNDARY-START(21476278320)
            /*System.Net.Sockets.SocketFlags*/  get SocketFlags() { return this.$getField(16, 4); }
            /*System.Net.Sockets.SocketFlags*/  set SocketFlags(value) { this.$setField(16, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(21476278320)
            
            //--TRIMMABLE-BOUNDARY-START(4296409136)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296409136)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.PacketInformation = this.PacketInformation.Clone();
                copy.ReceivedBytes = this.ReceivedBytes;
                copy.RemoteEndPoint = this.RemoteEndPoint;
                copy.SocketFlags = this.SocketFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591376432)
                this.PacketInformation = $.$default($.$sns.System.Net.Sockets.IPPacketInformation);
                //--TRIMMABLE-BOUNDARY-END(8591376432)
                
                //--TRIMMABLE-BOUNDARY-START(12886343728)
                this.ReceivedBytes = 0;
                //--TRIMMABLE-BOUNDARY-END(12886343728)
                
                //--TRIMMABLE-BOUNDARY-START(17181311024)
                this.RemoteEndPoint = null;
                //--TRIMMABLE-BOUNDARY-END(17181311024)
                
                //--TRIMMABLE-BOUNDARY-START(21476278320)
                this.SocketFlags = 0;
                //--TRIMMABLE-BOUNDARY-END(21476278320)
                
            }
            static $h = 1441840;
            static $z = 20;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591376432),
    {
      "t": 131120,
      "n": "PacketInformation",
      "d": 1441840,
      "h": 8591376432,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8591376432),
//--TRIMMABLE-BOUNDARY-START(12886343728),
    {
      "t": 655361,
      "n": "ReceivedBytes",
      "d": 1441840,
      "h": 12886343728,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12886343728),
//--TRIMMABLE-BOUNDARY-START(17181311024),
    {
      "t": 2555951,
      "n": "RemoteEndPoint",
      "d": 1441840,
      "h": 17181311024,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17181311024),
//--TRIMMABLE-BOUNDARY-START(21476278320),
    {
      "t": 1048624,
      "n": "SocketFlags",
      "d": 1441840,
      "h": 21476278320,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(21476278320)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409136),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1441840,
      "h": 4296409136,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296409136)
  ],
  "h": 1441840
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketReceiveMessageFromResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441840)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031664)
        $asm.$cls("$sns.System.Net.Sockets.UnixDomainSocketEndPoint", ($self) => class UnixDomainSocketEndPoint extends $.$snp.System.Net.EndPoint
        {
            //--TRIMMABLE-BOUNDARY-START(4296998960)
            $ctor$2(/*string*/ path)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296998960);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296998960)
            
            //--TRIMMABLE-BOUNDARY-START(8591966256)
            /*System.Net.Sockets.AddressFamily */ get AddressFamily()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771835440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8591966256)
            
            //--TRIMMABLE-BOUNDARY-START(12886933552)
            /*System.Net.EndPoint */ Create(/*System.Net.SocketAddress*/ socketAddress)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886933552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12886933552)
            
            //--TRIMMABLE-BOUNDARY-START(17181900848)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181900848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(17181900848)
            
            //--TRIMMABLE-BOUNDARY-START(30066802736)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066802736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(30066802736)
            
            //--TRIMMABLE-BOUNDARY-START(34361770032)
            /*System.Net.SocketAddress */ Serialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361770032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34361770032)
            
            //--TRIMMABLE-BOUNDARY-START(38656737328)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656737328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(38656737328)
            
            static $h = 2031664;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2555951,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591966256),
    {
      "p": 4456495,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771835440,
        "f": 50364417
      },
      "n": "AddressFamily",
      "d": 2031664,
      "h": 8591966256,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591966256)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886933552),
    {
      "r": 2555951,
      "p": [
        {
          "n": "socketAddress",
          "p": 4325423
        }
      ],
      "n": "Create",
      "d": 2031664,
      "h": 12886933552,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886933552),
//--TRIMMABLE-BOUNDARY-START(17181900848),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2031664,
      "h": 17181900848,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181900848),
//--TRIMMABLE-BOUNDARY-START(30066802736),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2031664,
      "h": 30066802736,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066802736),
//--TRIMMABLE-BOUNDARY-START(34361770032),
    {
      "r": 4325423,
      "n": "Serialize",
      "d": 2031664,
      "h": 34361770032,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361770032),
//--TRIMMABLE-BOUNDARY-START(38656737328),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2031664,
      "h": 38656737328,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656737328)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296998960),
    {
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2031664,
      "h": 4296998960,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296998960)
  ],
  "h": 2031664
}; }
            static get $b() { return $.$snp.System.Net.EndPoint; }
            static get $fullName() { return `System.Net.Sockets.UnixDomainSocketEndPoint`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031664)
        
        
        //--TRIMMABLE-BOUNDARY-START(131120)
        $asm.$str("$sns.System.Net.Sockets.IPPacketInformation", ($self) => class IPPacketInformation extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295098416)
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4295098416)
            
            //--TRIMMABLE-BOUNDARY-START(8590065712)
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8590065712)
            
            //--TRIMMABLE-BOUNDARY-START(17180000304)
            /*System.Net.IPAddress */ get Address()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180000304)
            
            //--TRIMMABLE-BOUNDARY-START(51539738672)
            /*int */ get Interface()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51539738672)
            
            //--TRIMMABLE-BOUNDARY-START(25769934896)
            /*bool */ Equals$2(/*System.Net.Sockets.IPPacketInformation*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25769934896)
            
            //--TRIMMABLE-BOUNDARY-START(21474967600)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ comparand)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sns.System.Net.Sockets.IPPacketInformation.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(21474967600)
            
            //--TRIMMABLE-BOUNDARY-START(47244771376)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244771376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.IPPacketInformation.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(47244771376)
            
            //--TRIMMABLE-BOUNDARY-START(55834705968)
            static /*bool */ op_Equality(/*System.Net.Sockets.IPPacketInformation*/ packetInformation1, /*System.Net.Sockets.IPPacketInformation*/ packetInformation2)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55834705968)
            
            //--TRIMMABLE-BOUNDARY-START(60129673264)
            static /*bool */ op_Inequality(/*System.Net.Sockets.IPPacketInformation*/ packetInformation1, /*System.Net.Sockets.IPPacketInformation*/ packetInformation2)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60129673264)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<System.Net.Sockets.IPPacketInformation>.Equals(System.Net.Sockets.IPPacketInformation)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //--TRIMMABLE-BOUNDARY-START(12885033008)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033008)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295098416)
                this._dummy = null;
                //--TRIMMABLE-BOUNDARY-END(4295098416)
                
                //--TRIMMABLE-BOUNDARY-START(8590065712)
                this._dummyPrimitive = 0;
                //--TRIMMABLE-BOUNDARY-END(8590065712)
                
            }
            static $h = 131120;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180000304),
    {
      "p": 3014703,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359869488,
        "f": 50331649
      },
      "n": "Address",
      "d": 131120,
      "h": 17180000304,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180000304),
//--TRIMMABLE-BOUNDARY-START(51539738672),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949804080,
        "f": 50331649
      },
      "n": "Interface",
      "d": 131120,
      "h": 51539738672,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539738672)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769934896),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 131120
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 131120,
      "h": 25769934896,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769934896),
//--TRIMMABLE-BOUNDARY-START(21474967600),
    {
      "r": 262145,
      "p": [
        {
          "n": "comparand",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 131120,
      "h": 21474967600,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21474967600),
//--TRIMMABLE-BOUNDARY-START(47244771376),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 131120,
      "h": 47244771376,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47244771376)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098416),
    {
      "t": 131073,
      "n": "_dummy",
      "d": 131120,
      "h": 4295098416,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098416),
//--TRIMMABLE-BOUNDARY-START(8590065712),
    {
      "t": 655361,
      "n": "_dummyPrimitive",
      "d": 131120,
      "h": 8590065712,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065712)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885033008),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131120,
      "h": 12885033008,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885033008)
  ],
  "i": [$.$$.System.IEquatable$$($.$sns.System.Net.Sockets.IPPacketInformation).$h
  ],
  "h": 131120
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sns.System.Net.Sockets.IPPacketInformation) ]; }
            static get $fullName() { return `System.Net.Sockets.IPPacketInformation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131120)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966128)
        $asm.$str("$sns.System.Net.Sockets.UdpReceiveResult", ($self) => class UdpReceiveResult extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296933424)
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4296933424)
            
            //--TRIMMABLE-BOUNDARY-START(8591900720)
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8591900720)
            
            //--TRIMMABLE-BOUNDARY-START(17181835312)
            $ctor$3(/*byte[]*/ buffer, /*System.Net.IPEndPoint*/ remoteEndPoint)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181835312);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181835312)
            
            //--TRIMMABLE-BOUNDARY-START(21476802608)
            /*byte[] */ get Buffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656671792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21476802608)
            
            //--TRIMMABLE-BOUNDARY-START(64426475568)
            /*System.Net.IPEndPoint */ get RemoteEndPoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246606384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64426475568)
            
            //--TRIMMABLE-BOUNDARY-START(30066737200)
            /*bool */ Equals$2(/*System.Net.Sockets.UdpReceiveResult*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066737200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30066737200)
            
            //--TRIMMABLE-BOUNDARY-START(25771769904)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771769904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sns.System.Net.Sockets.UdpReceiveResult.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25771769904)
            
            //--TRIMMABLE-BOUNDARY-START(51541573680)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541573680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.UdpReceiveResult.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(51541573680)
            
            //--TRIMMABLE-BOUNDARY-START(55836540976)
            static /*bool */ op_Equality(/*System.Net.Sockets.UdpReceiveResult*/ left, /*System.Net.Sockets.UdpReceiveResult*/ right)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55836540976)
            
            //--TRIMMABLE-BOUNDARY-START(60131508272)
            static /*bool */ op_Inequality(/*System.Net.Sockets.UdpReceiveResult*/ left, /*System.Net.Sockets.UdpReceiveResult*/ right)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60131508272)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<System.Net.Sockets.UdpReceiveResult>.Equals(System.Net.Sockets.UdpReceiveResult)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //--TRIMMABLE-BOUNDARY-START(12886868016)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886868016)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296933424)
                this._dummy = null;
                //--TRIMMABLE-BOUNDARY-END(4296933424)
                
                //--TRIMMABLE-BOUNDARY-START(8591900720)
                this._dummyPrimitive = 0;
                //--TRIMMABLE-BOUNDARY-END(8591900720)
                
            }
            static $h = 1966128;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476802608),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656671792,
        "f": 50331649
      },
      "n": "Buffer",
      "d": 1966128,
      "h": 21476802608,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476802608),
//--TRIMMABLE-BOUNDARY-START(64426475568),
    {
      "p": 3276847,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246606384,
        "f": 50331649
      },
      "n": "RemoteEndPoint",
      "d": 1966128,
      "h": 64426475568,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426475568)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066737200),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1966128
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1966128,
      "h": 30066737200,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066737200),
//--TRIMMABLE-BOUNDARY-START(25771769904),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1966128,
      "h": 25771769904,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771769904),
//--TRIMMABLE-BOUNDARY-START(51541573680),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1966128,
      "h": 51541573680,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541573680)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296933424),
    {
      "t": 131073,
      "n": "_dummy",
      "d": 1966128,
      "h": 4296933424,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296933424),
//--TRIMMABLE-BOUNDARY-START(8591900720),
    {
      "t": 655361,
      "n": "_dummyPrimitive",
      "d": 1966128,
      "h": 8591900720,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591900720)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181835312),
    {
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "remoteEndPoint",
          "p": 3276847
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1966128,
      "h": 17181835312,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181835312),
//--TRIMMABLE-BOUNDARY-START(12886868016),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1966128,
      "h": 12886868016,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886868016)
  ],
  "i": [$.$$.System.IEquatable$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h
  ],
  "h": 1966128
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sns.System.Net.Sockets.UdpReceiveResult) ]; }
            static get $fullName() { return `System.Net.Sockets.UdpReceiveResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966128)
        
        
        //--TRIMMABLE-BOUNDARY-START(458800)
        $asm.$cls("$sns.System.Net.Sockets.NetworkStream", ($self) => class NetworkStream extends $.$$.System.IO.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(17180327984)
            $ctor$6(/*System.Net.Sockets.Socket*/ socket)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180327984);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180327984)
            
            //--TRIMMABLE-BOUNDARY-START(4295426096)
            $ctor$3(/*System.Net.Sockets.Socket*/ socket, /*bool*/ ownsSocket)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426096);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426096)
            
            //--TRIMMABLE-BOUNDARY-START(12885360688)
            $ctor$5(/*System.Net.Sockets.Socket*/ socket, /*System.IO.FileAccess*/ access)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885360688);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360688)
            
            //--TRIMMABLE-BOUNDARY-START(8590393392)
            $ctor$4(/*System.Net.Sockets.Socket*/ socket, /*System.IO.FileAccess*/ access, /*bool*/ ownsSocket)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590393392);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393392)
            
            //--TRIMMABLE-BOUNDARY-START(30065229872)
            /*bool */ get CanRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194772016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065229872)
            
            //--TRIMMABLE-BOUNDARY-START(34360197168)
            /*bool */ get CanSeek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784706608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360197168)
            
            //--TRIMMABLE-BOUNDARY-START(38655164464)
            /*bool */ get CanTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374641200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655164464)
            
            //--TRIMMABLE-BOUNDARY-START(42950131760)
            /*bool */ get CanWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964575792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950131760)
            
            //--TRIMMABLE-BOUNDARY-START(55835033648)
            /*bool */ get DataAvailable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554510384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835033648)
            
            //--TRIMMABLE-BOUNDARY-START(188979019824)
            /*long */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144444976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(188979019824)
            
            //--TRIMMABLE-BOUNDARY-START(193273987120)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734379568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223660080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(193273987120)
            
            //--TRIMMABLE-BOUNDARY-START(206158889008)
            /*bool */ get Readable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324314160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Readable(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813594672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(206158889008)
            
            //--TRIMMABLE-BOUNDARY-START(223338758192)
            /*int */ get ReadTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914248752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403529264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(223338758192)
            
            //--TRIMMABLE-BOUNDARY-START(279173333040)
            /*System.Net.Sockets.Socket */ get Socket()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504183344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(279173333040)
            
            //--TRIMMABLE-BOUNDARY-START(292058234928)
            /*bool */ get Writeable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094117936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Writeable(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993463856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(292058234928)
            
            //--TRIMMABLE-BOUNDARY-START(309238104112)
            /*int */ get WriteTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684052528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583398448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(309238104112)
            
            //--TRIMMABLE-BOUNDARY-START(21475295280)
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475295280)
            
            //--TRIMMABLE-BOUNDARY-START(25770262576)
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770262576)
            
            //--TRIMMABLE-BOUNDARY-START(47245099056)
            /*void */ Close$1(/*int*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47245099056)
            
            //--TRIMMABLE-BOUNDARY-START(51540066352)
            /*void */ Close$2(/*System.TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51540066352)
            
            //--TRIMMABLE-BOUNDARY-START(60130000944)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130000944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60130000944)
            
            //--TRIMMABLE-BOUNDARY-START(64424968240)
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64424968240)
            
            //--TRIMMABLE-BOUNDARY-START(68719935536)
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(68719935536)
            
            $dtor()
            {
            }
            //--TRIMMABLE-BOUNDARY-START(77309870128)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(77309870128)
            
            //--TRIMMABLE-BOUNDARY-START(81604837424)
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604837424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81604837424)
            
            //--TRIMMABLE-BOUNDARY-START(197568954416)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568954416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(197568954416)
            
            //--TRIMMABLE-BOUNDARY-START(201863921712)
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863921712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(201863921712)
            
            //--TRIMMABLE-BOUNDARY-START(210453856304)
            /*System.Threading.Tasks.Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453856304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(210453856304)
            
            //--TRIMMABLE-BOUNDARY-START(214748823600)
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748823600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(214748823600)
            
            //--TRIMMABLE-BOUNDARY-START(219043790896)
            /*int */ ReadByte()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043790896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(219043790896)
            
            //--TRIMMABLE-BOUNDARY-START(227633725488)
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633725488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(227633725488)
            
            //--TRIMMABLE-BOUNDARY-START(274878365744)
            /*void */ SetLength(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878365744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(274878365744)
            
            //--TRIMMABLE-BOUNDARY-START(283468300336)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468300336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(283468300336)
            
            //--TRIMMABLE-BOUNDARY-START(287763267632)
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763267632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(287763267632)
            
            //--TRIMMABLE-BOUNDARY-START(296353202224)
            /*System.Threading.Tasks.Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353202224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(296353202224)
            
            //--TRIMMABLE-BOUNDARY-START(300648169520)
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648169520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(300648169520)
            
            //--TRIMMABLE-BOUNDARY-START(304943136816)
            /*void */ WriteByte(/*byte*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943136816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(304943136816)
            
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 458800;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 94961665,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065229872),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194772016,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 458800,
      "h": 30065229872,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065229872),
//--TRIMMABLE-BOUNDARY-START(34360197168),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784706608,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 458800,
      "h": 34360197168,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360197168),
//--TRIMMABLE-BOUNDARY-START(38655164464),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374641200,
        "f": 50364417
      },
      "n": "CanTimeout",
      "d": 458800,
      "h": 38655164464,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655164464),
//--TRIMMABLE-BOUNDARY-START(42950131760),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964575792,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 458800,
      "h": 42950131760,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950131760),
//--TRIMMABLE-BOUNDARY-START(55835033648),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554510384,
        "f": 50331777
      },
      "n": "DataAvailable",
      "d": 458800,
      "h": 55835033648,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(55835033648),
//--TRIMMABLE-BOUNDARY-START(188979019824),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144444976,
        "f": 50364417
      },
      "n": "Length",
      "d": 458800,
      "h": 188979019824,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(188979019824),
//--TRIMMABLE-BOUNDARY-START(193273987120),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734379568,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236223660080,
        "f": 83918849
      },
      "n": "Position",
      "d": 458800,
      "h": 193273987120,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(193273987120),
//--TRIMMABLE-BOUNDARY-START(206158889008),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324314160,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244813594672,
        "f": 83886084
      },
      "n": "Readable",
      "d": 458800,
      "h": 206158889008,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(206158889008),
//--TRIMMABLE-BOUNDARY-START(223338758192),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914248752,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253403529264,
        "f": 83918849
      },
      "n": "ReadTimeout",
      "d": 458800,
      "h": 223338758192,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(223338758192),
//--TRIMMABLE-BOUNDARY-START(279173333040),
    {
      "p": 852016,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504183344,
        "f": 50331649
      },
      "n": "Socket",
      "d": 458800,
      "h": 279173333040,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279173333040),
//--TRIMMABLE-BOUNDARY-START(292058234928),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094117936,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261993463856,
        "f": 83886084
      },
      "n": "Writeable",
      "d": 458800,
      "h": 292058234928,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(292058234928),
//--TRIMMABLE-BOUNDARY-START(309238104112),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684052528,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270583398448,
        "f": 83918849
      },
      "n": "WriteTimeout",
      "d": 458800,
      "h": 309238104112,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(309238104112)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475295280),
    {
      "r": 89784321,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginRead",
      "d": 458800,
      "h": 21475295280,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475295280),
//--TRIMMABLE-BOUNDARY-START(25770262576),
    {
      "r": 89784321,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginWrite",
      "d": 458800,
      "h": 25770262576,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770262576),
//--TRIMMABLE-BOUNDARY-START(47245099056),
    {
      "r": 65537,
      "p": [
        {
          "n": "timeout",
          "p": 655361
        }
      ],
      "n": "Close",
      "o": "@$1",
      "d": 458800,
      "h": 47245099056,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245099056),
//--TRIMMABLE-BOUNDARY-START(51540066352),
    {
      "r": 65537,
      "p": [
        {
          "n": "timeout",
          "p": 185860097
        }
      ],
      "n": "Close",
      "o": "@$2",
      "d": 458800,
      "h": 51540066352,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540066352),
//--TRIMMABLE-BOUNDARY-START(60130000944),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 458800,
      "h": 60130000944,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(60130000944),
//--TRIMMABLE-BOUNDARY-START(64424968240),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndRead",
      "d": 458800,
      "h": 64424968240,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64424968240),
//--TRIMMABLE-BOUNDARY-START(68719935536),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndWrite",
      "d": 458800,
      "h": 68719935536,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68719935536),
//--TRIMMABLE-BOUNDARY-START(77309870128),
    {
      "r": 65537,
      "n": "Flush",
      "d": 458800,
      "h": 77309870128,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77309870128),
//--TRIMMABLE-BOUNDARY-START(81604837424),
    {
      "r": 177668097,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 458800,
      "h": 81604837424,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81604837424),
//--TRIMMABLE-BOUNDARY-START(197568954416),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 458800,
      "h": 197568954416,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(197568954416),
//--TRIMMABLE-BOUNDARY-START(201863921712),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 458800,
      "h": 201863921712,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(201863921712),
//--TRIMMABLE-BOUNDARY-START(210453856304),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadAsync",
      "d": 458800,
      "h": 210453856304,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(210453856304),
//--TRIMMABLE-BOUNDARY-START(214748823600),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 458800,
      "h": 214748823600,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(214748823600),
//--TRIMMABLE-BOUNDARY-START(219043790896),
    {
      "r": 655361,
      "n": "ReadByte",
      "d": 458800,
      "h": 219043790896,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(219043790896),
//--TRIMMABLE-BOUNDARY-START(227633725488),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 94502913
        }
      ],
      "n": "Seek",
      "d": 458800,
      "h": 227633725488,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(227633725488),
//--TRIMMABLE-BOUNDARY-START(274878365744),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 458800,
      "h": 274878365744,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(274878365744),
//--TRIMMABLE-BOUNDARY-START(283468300336),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 458800,
      "h": 283468300336,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(283468300336),
//--TRIMMABLE-BOUNDARY-START(287763267632),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 458800,
      "h": 287763267632,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(287763267632),
//--TRIMMABLE-BOUNDARY-START(296353202224),
    {
      "r": 177668097,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteAsync",
      "d": 458800,
      "h": 296353202224,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(296353202224),
//--TRIMMABLE-BOUNDARY-START(300648169520),
    {
      "r": 180551681,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 458800,
      "h": 300648169520,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(300648169520),
//--TRIMMABLE-BOUNDARY-START(304943136816),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        }
      ],
      "n": "WriteByte",
      "d": 458800,
      "h": 304943136816,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(304943136816)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180327984),
    {
      "p": [
        {
          "n": "socket",
          "p": 852016
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 458800,
      "h": 17180327984,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180327984),
//--TRIMMABLE-BOUNDARY-START(4295426096),
    {
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "ownsSocket",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458800,
      "h": 4295426096,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426096),
//--TRIMMABLE-BOUNDARY-START(12885360688),
    {
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "access",
          "p": 92536833
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 458800,
      "h": 12885360688,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885360688),
//--TRIMMABLE-BOUNDARY-START(8590393392),
    {
      "p": [
        {
          "n": "socket",
          "p": 852016
        },
        {
          "n": "access",
          "p": 92536833
        },
        {
          "n": "ownsSocket",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 458800,
      "h": 8590393392,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393392)
  ],
  "i": [90308609,89718785
  ],
  "h": 458800
}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.NetworkStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458800)
        
        
        //--TRIMMABLE-BOUNDARY-START(65584)
        $asm.$str("$sns.System.Net.Sockets.IOControlCode", ($self) => class IOControlCode extends $.$$.System.Enum
        {
            static EnableCircularQueuing = 671088642n;
            static Flush = 671088644n;
            static AddressListChange = 671088663n;
            static DataToRead = 1074030207n;
            static OobDataRead = 1074033415n;
            static GetBroadcastAddress = 1207959557n;
            static AddressListQuery = 1207959574n;
            static QueryTargetPnpHandle = 1207959576n;
            static AsyncIO = 2147772029n;
            static NonBlockingIO = 2147772030n;
            static AssociateHandle = 2281701377n;
            static MultipointLoopback = 2281701385n;
            static MulticastScope = 2281701386n;
            static SetQos = 2281701387n;
            static SetGroupQos = 2281701388n;
            static RoutingInterfaceChange = 2281701397n;
            static NamespaceChange = 2281701401n;
            static ReceiveAll = 2550136833n;
            static ReceiveAllMulticast = 2550136834n;
            static ReceiveAllIgmpMulticast = 2550136835n;
            static KeepAliveValues = 2550136836n;
            static AbsorbRouterAlert = 2550136837n;
            static UnicastInterface = 2550136838n;
            static LimitBroadcasts = 2550136839n;
            static BindToInterface = 2550136840n;
            static MulticastInterface = 2550136841n;
            static AddMulticastGroupOnInterface = 2550136842n;
            static DeleteMulticastGroupFromInterface = 2550136843n;
            static GetExtensionFunctionPointer = 3355443206n;
            static GetQos = 3355443207n;
            static GetGroupQos = 3355443208n;
            static TranslateHandle = 3355443213n;
            static RoutingInterfaceQuery = 3355443220n;
            static AddressListSort = 3355443225n;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(65584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "EnableCircularQueuing": 671088642n,
                    "Flush": 671088644n,
                    "AddressListChange": 671088663n,
                    "DataToRead": 1074030207n,
                    "OobDataRead": 1074033415n,
                    "GetBroadcastAddress": 1207959557n,
                    "AddressListQuery": 1207959574n,
                    "QueryTargetPnpHandle": 1207959576n,
                    "AsyncIO": 2147772029n,
                    "NonBlockingIO": 2147772030n,
                    "AssociateHandle": 2281701377n,
                    "MultipointLoopback": 2281701385n,
                    "MulticastScope": 2281701386n,
                    "SetQos": 2281701387n,
                    "SetGroupQos": 2281701388n,
                    "RoutingInterfaceChange": 2281701397n,
                    "NamespaceChange": 2281701401n,
                    "ReceiveAll": 2550136833n,
                    "ReceiveAllMulticast": 2550136834n,
                    "ReceiveAllIgmpMulticast": 2550136835n,
                    "KeepAliveValues": 2550136836n,
                    "AbsorbRouterAlert": 2550136837n,
                    "UnicastInterface": 2550136838n,
                    "LimitBroadcasts": 2550136839n,
                    "BindToInterface": 2550136840n,
                    "MulticastInterface": 2550136841n,
                    "AddMulticastGroupOnInterface": 2550136842n,
                    "DeleteMulticastGroupFromInterface": 2550136843n,
                    "GetExtensionFunctionPointer": 3355443206n,
                    "GetQos": 3355443207n,
                    "GetGroupQos": 3355443208n,
                    "TranslateHandle": 3355443213n,
                    "RoutingInterfaceQuery": 3355443220n,
                    "AddressListSort": 3355443225n
                };
            }
            static $h = 65584;
            static $z = 8;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int64; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 917505,
  "l": [
//--TRIMMABLE-BOUNDARY-START(51539673136),
    {
      "t": 65584,
      "n": "EnableCircularQueuing",
      "d": 65584,
      "h": 51539673136,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51539673136),
//--TRIMMABLE-BOUNDARY-START(55834640432),
    {
      "t": 65584,
      "n": "Flush",
      "d": 65584,
      "h": 55834640432,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834640432),
//--TRIMMABLE-BOUNDARY-START(17179934768),
    {
      "t": 65584,
      "n": "AddressListChange",
      "d": 65584,
      "h": 17179934768,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17179934768),
//--TRIMMABLE-BOUNDARY-START(42949738544),
    {
      "t": 65584,
      "n": "DataToRead",
      "d": 65584,
      "h": 42949738544,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949738544),
//--TRIMMABLE-BOUNDARY-START(107374247984),
    {
      "t": 65584,
      "n": "OobDataRead",
      "d": 65584,
      "h": 107374247984,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374247984),
//--TRIMMABLE-BOUNDARY-START(60129607728),
    {
      "t": 65584,
      "n": "GetBroadcastAddress",
      "d": 65584,
      "h": 60129607728,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60129607728),
//--TRIMMABLE-BOUNDARY-START(21474902064),
    {
      "t": 65584,
      "n": "AddressListQuery",
      "d": 65584,
      "h": 21474902064,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21474902064),
//--TRIMMABLE-BOUNDARY-START(111669215280),
    {
      "t": 65584,
      "n": "QueryTargetPnpHandle",
      "d": 65584,
      "h": 111669215280,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669215280),
//--TRIMMABLE-BOUNDARY-START(34359803952),
    {
      "t": 65584,
      "n": "AsyncIO",
      "d": 65584,
      "h": 34359803952,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34359803952),
//--TRIMMABLE-BOUNDARY-START(103079280688),
    {
      "t": 65584,
      "n": "NonBlockingIO",
      "d": 65584,
      "h": 103079280688,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079280688),
//--TRIMMABLE-BOUNDARY-START(30064836656),
    {
      "t": 65584,
      "n": "AssociateHandle",
      "d": 65584,
      "h": 30064836656,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30064836656),
//--TRIMMABLE-BOUNDARY-START(94489346096),
    {
      "t": 65584,
      "n": "MultipointLoopback",
      "d": 65584,
      "h": 94489346096,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94489346096),
//--TRIMMABLE-BOUNDARY-START(90194378800),
    {
      "t": 65584,
      "n": "MulticastScope",
      "d": 65584,
      "h": 90194378800,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90194378800),
//--TRIMMABLE-BOUNDARY-START(141733986352),
    {
      "t": 65584,
      "n": "SetQos",
      "d": 65584,
      "h": 141733986352,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141733986352),
//--TRIMMABLE-BOUNDARY-START(137439019056),
    {
      "t": 65584,
      "n": "SetGroupQos",
      "d": 65584,
      "h": 137439019056,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137439019056),
//--TRIMMABLE-BOUNDARY-START(128849084464),
    {
      "t": 65584,
      "n": "RoutingInterfaceChange",
      "d": 65584,
      "h": 128849084464,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128849084464),
//--TRIMMABLE-BOUNDARY-START(98784313392),
    {
      "t": 65584,
      "n": "NamespaceChange",
      "d": 65584,
      "h": 98784313392,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98784313392),
//--TRIMMABLE-BOUNDARY-START(115964182576),
    {
      "t": 65584,
      "n": "ReceiveAll",
      "d": 65584,
      "h": 115964182576,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115964182576),
//--TRIMMABLE-BOUNDARY-START(124554117168),
    {
      "t": 65584,
      "n": "ReceiveAllMulticast",
      "d": 65584,
      "h": 124554117168,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124554117168),
//--TRIMMABLE-BOUNDARY-START(120259149872),
    {
      "t": 65584,
      "n": "ReceiveAllIgmpMulticast",
      "d": 65584,
      "h": 120259149872,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120259149872),
//--TRIMMABLE-BOUNDARY-START(77309476912),
    {
      "t": 65584,
      "n": "KeepAliveValues",
      "d": 65584,
      "h": 77309476912,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77309476912),
//--TRIMMABLE-BOUNDARY-START(8590000176),
    {
      "t": 65584,
      "n": "AbsorbRouterAlert",
      "d": 65584,
      "h": 8590000176,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590000176),
//--TRIMMABLE-BOUNDARY-START(150323920944),
    {
      "t": 65584,
      "n": "UnicastInterface",
      "d": 65584,
      "h": 150323920944,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150323920944),
//--TRIMMABLE-BOUNDARY-START(81604444208),
    {
      "t": 65584,
      "n": "LimitBroadcasts",
      "d": 65584,
      "h": 81604444208,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81604444208),
//--TRIMMABLE-BOUNDARY-START(38654771248),
    {
      "t": 65584,
      "n": "BindToInterface",
      "d": 65584,
      "h": 38654771248,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38654771248),
//--TRIMMABLE-BOUNDARY-START(85899411504),
    {
      "t": 65584,
      "n": "MulticastInterface",
      "d": 65584,
      "h": 85899411504,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85899411504),
//--TRIMMABLE-BOUNDARY-START(12884967472),
    {
      "t": 65584,
      "n": "AddMulticastGroupOnInterface",
      "d": 65584,
      "h": 12884967472,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12884967472),
//--TRIMMABLE-BOUNDARY-START(47244705840),
    {
      "t": 65584,
      "n": "DeleteMulticastGroupFromInterface",
      "d": 65584,
      "h": 47244705840,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47244705840),
//--TRIMMABLE-BOUNDARY-START(64424575024),
    {
      "t": 65584,
      "n": "GetExtensionFunctionPointer",
      "d": 65584,
      "h": 64424575024,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64424575024),
//--TRIMMABLE-BOUNDARY-START(73014509616),
    {
      "t": 65584,
      "n": "GetQos",
      "d": 65584,
      "h": 73014509616,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73014509616),
//--TRIMMABLE-BOUNDARY-START(68719542320),
    {
      "t": 65584,
      "n": "GetGroupQos",
      "d": 65584,
      "h": 68719542320,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719542320),
//--TRIMMABLE-BOUNDARY-START(146028953648),
    {
      "t": 65584,
      "n": "TranslateHandle",
      "d": 65584,
      "h": 146028953648,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146028953648),
//--TRIMMABLE-BOUNDARY-START(133144051760),
    {
      "t": 65584,
      "n": "RoutingInterfaceQuery",
      "d": 65584,
      "h": 133144051760,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133144051760),
//--TRIMMABLE-BOUNDARY-START(25769869360),
    {
      "t": 65584,
      "n": "AddressListSort",
      "d": 65584,
      "h": 25769869360,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25769869360)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032880),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65584,
      "h": 4295032880,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032880)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 65584
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.IOControlCode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65584)
        
        
        //--TRIMMABLE-BOUNDARY-START(196656)
        $asm.$str("$sns.System.Net.Sockets.IPProtectionLevel", ($self) => class IPProtectionLevel extends $.$$.System.Enum
        {
            static Unspecified = -1;
            static Unrestricted = 10;
            static EdgeRestricted = 20;
            static Restricted = 30;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unspecified": -1n,
                    "Unrestricted": 10n,
                    "EdgeRestricted": 20n,
                    "Restricted": 30n
                };
            }
            static $h = 196656;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475033136),
    {
      "t": 196656,
      "n": "Unspecified",
      "d": 196656,
      "h": 21475033136,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475033136),
//--TRIMMABLE-BOUNDARY-START(17180065840),
    {
      "t": 196656,
      "n": "Unrestricted",
      "d": 196656,
      "h": 17180065840,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180065840),
//--TRIMMABLE-BOUNDARY-START(8590131248),
    {
      "t": 196656,
      "n": "EdgeRestricted",
      "d": 196656,
      "h": 8590131248,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590131248),
//--TRIMMABLE-BOUNDARY-START(12885098544),
    {
      "t": 196656,
      "n": "Restricted",
      "d": 196656,
      "h": 12885098544,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885098544)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163952),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196656,
      "h": 4295163952,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163952)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 196656
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.IPProtectionLevel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196656)
        
        
        //--TRIMMABLE-BOUNDARY-START(524336)
        $asm.$str("$sns.System.Net.Sockets.ProtocolFamily", ($self) => class ProtocolFamily extends $.$$.System.Enum
        {
            static Unknown = -1;
            static Unspecified = 0;
            static Unix = 1;
            static InterNetwork = 2;
            static ImpLink = 3;
            static Pup = 4;
            static Chaos = 5;
            static Ipx = 6;
            static NS = 6;
            static Iso = 7;
            static Osi = 7;
            static Ecma = 8;
            static DataKit = 9;
            static Ccitt = 10;
            static Sna = 11;
            static DecNet = 12;
            static DataLink = 13;
            static Lat = 14;
            static HyperChannel = 15;
            static AppleTalk = 16;
            static NetBios = 17;
            static VoiceView = 18;
            static FireFox = 19;
            static Banyan = 21;
            static Atm = 22;
            static InterNetworkV6 = 23;
            static Cluster = 24;
            static Ieee12844 = 25;
            static Irda = 26;
            static NetworkDesigners = 28;
            static Max = 29;
            static Packet = 65536;
            static ControllerAreaNetwork = 65537;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Unspecified": 0n,
                    "Unix": 1n,
                    "InterNetwork": 2n,
                    "ImpLink": 3n,
                    "Pup": 4n,
                    "Chaos": 5n,
                    "Ipx": 6n,
                    "NS": 6n,
                    "Iso": 7n,
                    "Osi": 7n,
                    "Ecma": 8n,
                    "DataKit": 9n,
                    "Ccitt": 10n,
                    "Sna": 11n,
                    "DecNet": 12n,
                    "DataLink": 13n,
                    "Lat": 14n,
                    "HyperChannel": 15n,
                    "AppleTalk": 16n,
                    "NetBios": 17n,
                    "VoiceView": 18n,
                    "FireFox": 19n,
                    "Banyan": 21n,
                    "Atm": 22n,
                    "InterNetworkV6": 23n,
                    "Cluster": 24n,
                    "Ieee12844": 25n,
                    "Irda": 26n,
                    "NetworkDesigners": 28n,
                    "Max": 29n,
                    "Packet": 65536n,
                    "ControllerAreaNetwork": 65537n
                };
            }
            static $h = 524336;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(137439477808),
    {
      "t": 524336,
      "n": "Unknown",
      "d": 524336,
      "h": 137439477808,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439477808),
//--TRIMMABLE-BOUNDARY-START(141734445104),
    {
      "t": 524336,
      "n": "Unspecified",
      "d": 524336,
      "h": 141734445104,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734445104),
//--TRIMMABLE-BOUNDARY-START(133144510512),
    {
      "t": 524336,
      "n": "Unix",
      "d": 524336,
      "h": 133144510512,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144510512),
//--TRIMMABLE-BOUNDARY-START(73014968368),
    {
      "t": 524336,
      "n": "InterNetwork",
      "d": 524336,
      "h": 73014968368,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73014968368),
//--TRIMMABLE-BOUNDARY-START(68720001072),
    {
      "t": 524336,
      "n": "ImpLink",
      "d": 524336,
      "h": 68720001072,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720001072),
//--TRIMMABLE-BOUNDARY-START(124554575920),
    {
      "t": 524336,
      "n": "Pup",
      "d": 524336,
      "h": 124554575920,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554575920),
//--TRIMMABLE-BOUNDARY-START(25770328112),
    {
      "t": 524336,
      "n": "Chaos",
      "d": 524336,
      "h": 25770328112,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328112),
//--TRIMMABLE-BOUNDARY-START(81604902960),
    {
      "t": 524336,
      "n": "Ipx",
      "d": 524336,
      "h": 81604902960,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604902960),
//--TRIMMABLE-BOUNDARY-START(111669674032),
    {
      "t": 524336,
      "n": "NS",
      "d": 524336,
      "h": 111669674032,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669674032),
//--TRIMMABLE-BOUNDARY-START(90194837552),
    {
      "t": 524336,
      "n": "Iso",
      "d": 524336,
      "h": 90194837552,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90194837552),
//--TRIMMABLE-BOUNDARY-START(115964641328),
    {
      "t": 524336,
      "n": "Osi",
      "d": 524336,
      "h": 115964641328,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964641328),
//--TRIMMABLE-BOUNDARY-START(51540131888),
    {
      "t": 524336,
      "n": "Ecma",
      "d": 524336,
      "h": 51540131888,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540131888),
//--TRIMMABLE-BOUNDARY-START(38655230000),
    {
      "t": 524336,
      "n": "DataKit",
      "d": 524336,
      "h": 38655230000,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655230000),
//--TRIMMABLE-BOUNDARY-START(21475360816),
    {
      "t": 524336,
      "n": "Ccitt",
      "d": 524336,
      "h": 21475360816,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475360816),
//--TRIMMABLE-BOUNDARY-START(128849543216),
    {
      "t": 524336,
      "n": "Sna",
      "d": 524336,
      "h": 128849543216,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849543216),
//--TRIMMABLE-BOUNDARY-START(47245164592),
    {
      "t": 524336,
      "n": "DecNet",
      "d": 524336,
      "h": 47245164592,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245164592),
//--TRIMMABLE-BOUNDARY-START(42950197296),
    {
      "t": 524336,
      "n": "DataLink",
      "d": 524336,
      "h": 42950197296,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950197296),
//--TRIMMABLE-BOUNDARY-START(94489804848),
    {
      "t": 524336,
      "n": "Lat",
      "d": 524336,
      "h": 94489804848,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489804848),
//--TRIMMABLE-BOUNDARY-START(60130066480),
    {
      "t": 524336,
      "n": "HyperChannel",
      "d": 524336,
      "h": 60130066480,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130066480),
//--TRIMMABLE-BOUNDARY-START(8590458928),
    {
      "t": 524336,
      "n": "AppleTalk",
      "d": 524336,
      "h": 8590458928,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590458928),
//--TRIMMABLE-BOUNDARY-START(103079739440),
    {
      "t": 524336,
      "n": "NetBios",
      "d": 524336,
      "h": 103079739440,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079739440),
//--TRIMMABLE-BOUNDARY-START(146029412400),
    {
      "t": 524336,
      "n": "VoiceView",
      "d": 524336,
      "h": 146029412400,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029412400),
//--TRIMMABLE-BOUNDARY-START(55835099184),
    {
      "t": 524336,
      "n": "FireFox",
      "d": 524336,
      "h": 55835099184,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835099184),
//--TRIMMABLE-BOUNDARY-START(17180393520),
    {
      "t": 524336,
      "n": "Banyan",
      "d": 524336,
      "h": 17180393520,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393520),
//--TRIMMABLE-BOUNDARY-START(12885426224),
    {
      "t": 524336,
      "n": "Atm",
      "d": 524336,
      "h": 12885426224,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426224),
//--TRIMMABLE-BOUNDARY-START(77309935664),
    {
      "t": 524336,
      "n": "InterNetworkV6",
      "d": 524336,
      "h": 77309935664,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77309935664),
//--TRIMMABLE-BOUNDARY-START(30065295408),
    {
      "t": 524336,
      "n": "Cluster",
      "d": 524336,
      "h": 30065295408,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065295408),
//--TRIMMABLE-BOUNDARY-START(64425033776),
    {
      "t": 524336,
      "n": "Ieee12844",
      "d": 524336,
      "h": 64425033776,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425033776),
//--TRIMMABLE-BOUNDARY-START(85899870256),
    {
      "t": 524336,
      "n": "Irda",
      "d": 524336,
      "h": 85899870256,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899870256),
//--TRIMMABLE-BOUNDARY-START(107374706736),
    {
      "t": 524336,
      "n": "NetworkDesigners",
      "d": 524336,
      "h": 107374706736,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374706736),
//--TRIMMABLE-BOUNDARY-START(98784772144),
    {
      "t": 524336,
      "n": "Max",
      "d": 524336,
      "h": 98784772144,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784772144),
//--TRIMMABLE-BOUNDARY-START(120259608624),
    {
      "t": 524336,
      "n": "Packet",
      "d": 524336,
      "h": 120259608624,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259608624),
//--TRIMMABLE-BOUNDARY-START(34360262704),
    {
      "t": 524336,
      "n": "ControllerAreaNetwork",
      "d": 524336,
      "h": 34360262704,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360262704)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491632),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524336,
      "h": 4295491632,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491632)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 524336
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.ProtocolFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524336)
        
        
        //--TRIMMABLE-BOUNDARY-START(589872)
        $asm.$str("$sns.System.Net.Sockets.ProtocolType", ($self) => class ProtocolType extends $.$$.System.Enum
        {
            static Unknown = -1;
            static IP = 0;
            static IPv6HopByHopOptions = 0;
            static Unspecified = 0;
            static Icmp = 1;
            static Igmp = 2;
            static Ggp = 3;
            static IPv4 = 4;
            static Tcp = 6;
            static Pup = 12;
            static Udp = 17;
            static Idp = 22;
            static IPv6 = 41;
            static IPv6RoutingHeader = 43;
            static IPv6FragmentHeader = 44;
            static IPSecEncapsulatingSecurityPayload = 50;
            static IPSecAuthenticationHeader = 51;
            static IcmpV6 = 58;
            static IPv6NoNextHeader = 59;
            static IPv6DestinationOptions = 60;
            static ND = 77;
            static Raw = 255;
            static Ipx = 1000;
            static Spx = 1256;
            static SpxII = 1257;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(589872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "IP": 0n,
                    "IPv6HopByHopOptions": 0n,
                    "Unspecified": 0n,
                    "Icmp": 1n,
                    "Igmp": 2n,
                    "Ggp": 3n,
                    "IPv4": 4n,
                    "Tcp": 6n,
                    "Pup": 12n,
                    "Udp": 17n,
                    "Idp": 22n,
                    "IPv6": 41n,
                    "IPv6RoutingHeader": 43n,
                    "IPv6FragmentHeader": 44n,
                    "IPSecEncapsulatingSecurityPayload": 50n,
                    "IPSecAuthenticationHeader": 51n,
                    "IcmpV6": 58n,
                    "IPv6NoNextHeader": 59n,
                    "IPv6DestinationOptions": 60n,
                    "ND": 77n,
                    "Raw": 255n,
                    "Ipx": 1000n,
                    "Spx": 1256n,
                    "SpxII": 1257n
                };
            }
            static $h = 589872;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(107374772272),
    {
      "t": 589872,
      "n": "Unknown",
      "d": 589872,
      "h": 107374772272,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374772272),
//--TRIMMABLE-BOUNDARY-START(30065360944),
    {
      "t": 589872,
      "n": "IP",
      "d": 589872,
      "h": 30065360944,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065360944),
//--TRIMMABLE-BOUNDARY-START(60130132016),
    {
      "t": 589872,
      "n": "IPv6HopByHopOptions",
      "d": 589872,
      "h": 60130132016,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130132016),
//--TRIMMABLE-BOUNDARY-START(111669739568),
    {
      "t": 589872,
      "n": "Unspecified",
      "d": 589872,
      "h": 111669739568,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669739568),
//--TRIMMABLE-BOUNDARY-START(12885491760),
    {
      "t": 589872,
      "n": "Icmp",
      "d": 589872,
      "h": 12885491760,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885491760),
//--TRIMMABLE-BOUNDARY-START(25770393648),
    {
      "t": 589872,
      "n": "Igmp",
      "d": 589872,
      "h": 25770393648,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770393648),
//--TRIMMABLE-BOUNDARY-START(8590524464),
    {
      "t": 589872,
      "n": "Ggp",
      "d": 589872,
      "h": 8590524464,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590524464),
//--TRIMMABLE-BOUNDARY-START(42950262832),
    {
      "t": 589872,
      "n": "IPv4",
      "d": 589872,
      "h": 42950262832,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950262832),
//--TRIMMABLE-BOUNDARY-START(98784837680),
    {
      "t": 589872,
      "n": "Tcp",
      "d": 589872,
      "h": 98784837680,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784837680),
//--TRIMMABLE-BOUNDARY-START(81604968496),
    {
      "t": 589872,
      "n": "Pup",
      "d": 589872,
      "h": 81604968496,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604968496),
//--TRIMMABLE-BOUNDARY-START(103079804976),
    {
      "t": 589872,
      "n": "Udp",
      "d": 589872,
      "h": 103079804976,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079804976),
//--TRIMMABLE-BOUNDARY-START(21475426352),
    {
      "t": 589872,
      "n": "Idp",
      "d": 589872,
      "h": 21475426352,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475426352),
//--TRIMMABLE-BOUNDARY-START(47245230128),
    {
      "t": 589872,
      "n": "IPv6",
      "d": 589872,
      "h": 47245230128,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245230128),
//--TRIMMABLE-BOUNDARY-START(68720066608),
    {
      "t": 589872,
      "n": "IPv6RoutingHeader",
      "d": 589872,
      "h": 68720066608,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720066608),
//--TRIMMABLE-BOUNDARY-START(55835164720),
    {
      "t": 589872,
      "n": "IPv6FragmentHeader",
      "d": 589872,
      "h": 55835164720,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835164720),
//--TRIMMABLE-BOUNDARY-START(38655295536),
    {
      "t": 589872,
      "n": "IPSecEncapsulatingSecurityPayload",
      "d": 589872,
      "h": 38655295536,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655295536),
//--TRIMMABLE-BOUNDARY-START(34360328240),
    {
      "t": 589872,
      "n": "IPSecAuthenticationHeader",
      "d": 589872,
      "h": 34360328240,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360328240),
//--TRIMMABLE-BOUNDARY-START(17180459056),
    {
      "t": 589872,
      "n": "IcmpV6",
      "d": 589872,
      "h": 17180459056,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180459056),
//--TRIMMABLE-BOUNDARY-START(64425099312),
    {
      "t": 589872,
      "n": "IPv6NoNextHeader",
      "d": 589872,
      "h": 64425099312,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425099312),
//--TRIMMABLE-BOUNDARY-START(51540197424),
    {
      "t": 589872,
      "n": "IPv6DestinationOptions",
      "d": 589872,
      "h": 51540197424,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540197424),
//--TRIMMABLE-BOUNDARY-START(77310001200),
    {
      "t": 589872,
      "n": "ND",
      "d": 589872,
      "h": 77310001200,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310001200),
//--TRIMMABLE-BOUNDARY-START(85899935792),
    {
      "t": 589872,
      "n": "Raw",
      "d": 589872,
      "h": 85899935792,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899935792),
//--TRIMMABLE-BOUNDARY-START(73015033904),
    {
      "t": 589872,
      "n": "Ipx",
      "d": 589872,
      "h": 73015033904,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015033904),
//--TRIMMABLE-BOUNDARY-START(90194903088),
    {
      "t": 589872,
      "n": "Spx",
      "d": 589872,
      "h": 90194903088,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90194903088),
//--TRIMMABLE-BOUNDARY-START(94489870384),
    {
      "t": 589872,
      "n": "SpxII",
      "d": 589872,
      "h": 94489870384,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489870384)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557168),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589872,
      "h": 4295557168,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557168)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 589872
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.ProtocolType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589872)
        
        
        //--TRIMMABLE-BOUNDARY-START(720944)
        $asm.$str("$sns.System.Net.Sockets.SelectMode", ($self) => class SelectMode extends $.$$.System.Enum
        {
            static SelectRead = 0;
            static SelectWrite = 1;
            static SelectError = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(720944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "SelectRead": 0n,
                    "SelectWrite": 1n,
                    "SelectError": 2n
                };
            }
            static $h = 720944;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885622832),
    {
      "t": 720944,
      "n": "SelectRead",
      "d": 720944,
      "h": 12885622832,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885622832),
//--TRIMMABLE-BOUNDARY-START(17180590128),
    {
      "t": 720944,
      "n": "SelectWrite",
      "d": 720944,
      "h": 17180590128,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590128),
//--TRIMMABLE-BOUNDARY-START(8590655536),
    {
      "t": 720944,
      "n": "SelectError",
      "d": 720944,
      "h": 8590655536,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590655536)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688240),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720944,
      "h": 4295688240,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688240)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 720944
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SelectMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720944)
        
        
        //--TRIMMABLE-BOUNDARY-START(983088)
        $asm.$str("$sns.System.Net.Sockets.SocketAsyncOperation", ($self) => class SocketAsyncOperation extends $.$$.System.Enum
        {
            static None = 0;
            static Accept = 1;
            static Connect = 2;
            static Disconnect = 3;
            static Receive = 4;
            static ReceiveFrom = 5;
            static ReceiveMessageFrom = 6;
            static Send = 7;
            static SendPackets = 8;
            static SendTo = 9;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(983088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Accept": 1n,
                    "Connect": 2n,
                    "Disconnect": 3n,
                    "Receive": 4n,
                    "ReceiveFrom": 5n,
                    "ReceiveMessageFrom": 6n,
                    "Send": 7n,
                    "SendPackets": 8n,
                    "SendTo": 9n
                };
            }
            static $h = 983088;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475819568),
    {
      "t": 983088,
      "n": "None",
      "d": 983088,
      "h": 21475819568,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475819568),
//--TRIMMABLE-BOUNDARY-START(8590917680),
    {
      "t": 983088,
      "n": "Accept",
      "d": 983088,
      "h": 8590917680,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590917680),
//--TRIMMABLE-BOUNDARY-START(12885884976),
    {
      "t": 983088,
      "n": "Connect",
      "d": 983088,
      "h": 12885884976,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885884976),
//--TRIMMABLE-BOUNDARY-START(17180852272),
    {
      "t": 983088,
      "n": "Disconnect",
      "d": 983088,
      "h": 17180852272,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180852272),
//--TRIMMABLE-BOUNDARY-START(25770786864),
    {
      "t": 983088,
      "n": "Receive",
      "d": 983088,
      "h": 25770786864,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770786864),
//--TRIMMABLE-BOUNDARY-START(30065754160),
    {
      "t": 983088,
      "n": "ReceiveFrom",
      "d": 983088,
      "h": 30065754160,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065754160),
//--TRIMMABLE-BOUNDARY-START(34360721456),
    {
      "t": 983088,
      "n": "ReceiveMessageFrom",
      "d": 983088,
      "h": 34360721456,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360721456),
//--TRIMMABLE-BOUNDARY-START(38655688752),
    {
      "t": 983088,
      "n": "Send",
      "d": 983088,
      "h": 38655688752,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655688752),
//--TRIMMABLE-BOUNDARY-START(42950656048),
    {
      "t": 983088,
      "n": "SendPackets",
      "d": 983088,
      "h": 42950656048,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950656048),
//--TRIMMABLE-BOUNDARY-START(47245623344),
    {
      "t": 983088,
      "n": "SendTo",
      "d": 983088,
      "h": 47245623344,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245623344)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950384),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 983088,
      "h": 4295950384,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950384)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 983088
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketAsyncOperation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983088)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048624)
        $asm.$str("$sns.System.Net.Sockets.SocketFlags", ($self) => class SocketFlags extends $.$$.System.Enum
        {
            static None = 0;
            static OutOfBand = 1;
            static Peek = 2;
            static DontRoute = 4;
            static Truncated = 256;
            static ControlDataTruncated = 512;
            static Broadcast = 1024;
            static Multicast = 2048;
            static Partial = 32768;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1048624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "OutOfBand": 1n,
                    "Peek": 2n,
                    "DontRoute": 4n,
                    "Truncated": 256n,
                    "ControlDataTruncated": 512n,
                    "Broadcast": 1024n,
                    "Multicast": 2048n,
                    "Partial": 32768n
                };
            }
            static $h = 1048624;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770852400),
    {
      "t": 1048624,
      "n": "None",
      "d": 1048624,
      "h": 25770852400,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770852400),
//--TRIMMABLE-BOUNDARY-START(30065819696),
    {
      "t": 1048624,
      "n": "OutOfBand",
      "d": 1048624,
      "h": 30065819696,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065819696),
//--TRIMMABLE-BOUNDARY-START(38655754288),
    {
      "t": 1048624,
      "n": "Peek",
      "d": 1048624,
      "h": 38655754288,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655754288),
//--TRIMMABLE-BOUNDARY-START(17180917808),
    {
      "t": 1048624,
      "n": "DontRoute",
      "d": 1048624,
      "h": 17180917808,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180917808),
//--TRIMMABLE-BOUNDARY-START(42950721584),
    {
      "t": 1048624,
      "n": "Truncated",
      "d": 1048624,
      "h": 42950721584,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950721584),
//--TRIMMABLE-BOUNDARY-START(12885950512),
    {
      "t": 1048624,
      "n": "ControlDataTruncated",
      "d": 1048624,
      "h": 12885950512,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885950512),
//--TRIMMABLE-BOUNDARY-START(8590983216),
    {
      "t": 1048624,
      "n": "Broadcast",
      "d": 1048624,
      "h": 8590983216,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590983216),
//--TRIMMABLE-BOUNDARY-START(21475885104),
    {
      "t": 1048624,
      "n": "Multicast",
      "d": 1048624,
      "h": 21475885104,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475885104),
//--TRIMMABLE-BOUNDARY-START(34360786992),
    {
      "t": 1048624,
      "n": "Partial",
      "d": 1048624,
      "h": 34360786992,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360786992)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015920),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1048624,
      "h": 4296015920,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015920)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1048624,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048624)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179696)
        $asm.$str("$sns.System.Net.Sockets.SocketInformationOptions", ($self) => class SocketInformationOptions extends $.$$.System.Enum
        {
            static NonBlocking = 1;
            static Connected = 2;
            static Listening = 4;
            static UseOnlyOverlappedIO = 8;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1179696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "NonBlocking": 1n,
                    "Connected": 2n,
                    "Listening": 4n,
                    "UseOnlyOverlappedIO": 8n
                };
            }
            static $h = 1179696;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181048880),
    {
      "t": 1179696,
      "n": "NonBlocking",
      "d": 1179696,
      "h": 17181048880,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181048880),
//--TRIMMABLE-BOUNDARY-START(8591114288),
    {
      "t": 1179696,
      "n": "Connected",
      "d": 1179696,
      "h": 8591114288,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591114288),
//--TRIMMABLE-BOUNDARY-START(12886081584),
    {
      "t": 1179696,
      "n": "Listening",
      "d": 1179696,
      "h": 12886081584,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886081584),
//--TRIMMABLE-BOUNDARY-START(21476016176),
    {
      "t": 1179696,
      "n": "UseOnlyOverlappedIO",
      "d": 1179696,
      "h": 21476016176,
      "f": 4194337,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        },
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "SocketInformationOptions.UseOnlyOverlappedIO has been deprecated and is not supported.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476016176)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296146992),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1179696,
      "h": 4296146992,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296146992)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1179696,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketInformationOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179696)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245232)
        $asm.$str("$sns.System.Net.Sockets.SocketOptionLevel", ($self) => class SocketOptionLevel extends $.$$.System.Enum
        {
            static IP = 0;
            static Tcp = 6;
            static Udp = 17;
            static IPv6 = 41;
            static Socket = 65535;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1245232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "IP": 0n,
                    "Tcp": 6n,
                    "Udp": 17n,
                    "IPv6": 41n,
                    "Socket": 65535n
                };
            }
            static $h = 1245232;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591179824),
    {
      "t": 1245232,
      "n": "IP",
      "d": 1245232,
      "h": 8591179824,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591179824),
//--TRIMMABLE-BOUNDARY-START(21476081712),
    {
      "t": 1245232,
      "n": "Tcp",
      "d": 1245232,
      "h": 21476081712,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476081712),
//--TRIMMABLE-BOUNDARY-START(25771049008),
    {
      "t": 1245232,
      "n": "Udp",
      "d": 1245232,
      "h": 25771049008,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771049008),
//--TRIMMABLE-BOUNDARY-START(12886147120),
    {
      "t": 1245232,
      "n": "IPv6",
      "d": 1245232,
      "h": 12886147120,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886147120),
//--TRIMMABLE-BOUNDARY-START(17181114416),
    {
      "t": 1245232,
      "n": "Socket",
      "d": 1245232,
      "h": 17181114416,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181114416)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212528),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1245232,
      "h": 4296212528,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212528)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1245232
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketOptionLevel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245232)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310768)
        $asm.$str("$sns.System.Net.Sockets.SocketOptionName", ($self) => class SocketOptionName extends $.$$.System.Enum
        {
            static DontLinger = -129;
            static ExclusiveAddressUse = -5;
            static Debug = 1;
            static IPOptions = 1;
            static NoChecksum = 1;
            static NoDelay = 1;
            static AcceptConnection = 2;
            static BsdUrgent = 2;
            static Expedited = 2;
            static HeaderIncluded = 2;
            static TcpKeepAliveTime = 3;
            static TypeOfService = 3;
            static IpTimeToLive = 4;
            static ReuseAddress = 4;
            static KeepAlive = 8;
            static MulticastInterface = 9;
            static MulticastTimeToLive = 10;
            static MulticastLoopback = 11;
            static AddMembership = 12;
            static DropMembership = 13;
            static DontFragment = 14;
            static AddSourceMembership = 15;
            static FastOpen = 15;
            static DontRoute = 16;
            static DropSourceMembership = 16;
            static TcpKeepAliveRetryCount = 16;
            static BlockSource = 17;
            static TcpKeepAliveInterval = 17;
            static UnblockSource = 18;
            static PacketInformation = 19;
            static ChecksumCoverage = 20;
            static HopLimit = 21;
            static IPProtectionLevel = 23;
            static IPv6Only = 27;
            static Broadcast = 32;
            static UseLoopback = 64;
            static Linger = 128;
            static OutOfBandInline = 256;
            static SendBuffer = 4097;
            static ReceiveBuffer = 4098;
            static SendLowWater = 4099;
            static ReceiveLowWater = 4100;
            static SendTimeout = 4101;
            static ReceiveTimeout = 4102;
            static Error = 4103;
            static Type = 4104;
            static ReuseUnicastPort = 12295;
            static UpdateAcceptContext = 28683;
            static UpdateConnectContext = 28688;
            static MaxConnections = 2147483647;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1310768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "DontLinger": -129n,
                    "ExclusiveAddressUse": -5n,
                    "Debug": 1n,
                    "IPOptions": 1n,
                    "NoChecksum": 1n,
                    "NoDelay": 1n,
                    "AcceptConnection": 2n,
                    "BsdUrgent": 2n,
                    "Expedited": 2n,
                    "HeaderIncluded": 2n,
                    "TcpKeepAliveTime": 3n,
                    "TypeOfService": 3n,
                    "IpTimeToLive": 4n,
                    "ReuseAddress": 4n,
                    "KeepAlive": 8n,
                    "MulticastInterface": 9n,
                    "MulticastTimeToLive": 10n,
                    "MulticastLoopback": 11n,
                    "AddMembership": 12n,
                    "DropMembership": 13n,
                    "DontFragment": 14n,
                    "AddSourceMembership": 15n,
                    "FastOpen": 15n,
                    "DontRoute": 16n,
                    "DropSourceMembership": 16n,
                    "TcpKeepAliveRetryCount": 16n,
                    "BlockSource": 17n,
                    "TcpKeepAliveInterval": 17n,
                    "UnblockSource": 18n,
                    "PacketInformation": 19n,
                    "ChecksumCoverage": 20n,
                    "HopLimit": 21n,
                    "IPProtectionLevel": 23n,
                    "IPv6Only": 27n,
                    "Broadcast": 32n,
                    "UseLoopback": 64n,
                    "Linger": 128n,
                    "OutOfBandInline": 256n,
                    "SendBuffer": 4097n,
                    "ReceiveBuffer": 4098n,
                    "SendLowWater": 4099n,
                    "ReceiveLowWater": 4100n,
                    "SendTimeout": 4101n,
                    "ReceiveTimeout": 4102n,
                    "Error": 4103n,
                    "Type": 4104n,
                    "ReuseUnicastPort": 12295n,
                    "UpdateAcceptContext": 28683n,
                    "UpdateConnectContext": 28688n,
                    "MaxConnections": 2147483647n
                };
            }
            static $h = 1310768;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245951024),
    {
      "t": 1310768,
      "n": "DontLinger",
      "d": 1310768,
      "h": 47245951024,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245951024),
//--TRIMMABLE-BOUNDARY-START(68720787504),
    {
      "t": 1310768,
      "n": "ExclusiveAddressUse",
      "d": 1310768,
      "h": 68720787504,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720787504),
//--TRIMMABLE-BOUNDARY-START(38656016432),
    {
      "t": 1310768,
      "n": "Debug",
      "d": 1310768,
      "h": 38656016432,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656016432),
//--TRIMMABLE-BOUNDARY-START(90195623984),
    {
      "t": 1310768,
      "n": "IPOptions",
      "d": 1310768,
      "h": 90195623984,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90195623984),
//--TRIMMABLE-BOUNDARY-START(133145296944),
    {
      "t": 1310768,
      "n": "NoChecksum",
      "d": 1310768,
      "h": 133145296944,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133145296944),
//--TRIMMABLE-BOUNDARY-START(137440264240),
    {
      "t": 1310768,
      "n": "NoDelay",
      "d": 1310768,
      "h": 137440264240,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137440264240),
//--TRIMMABLE-BOUNDARY-START(8591245360),
    {
      "t": 1310768,
      "n": "AcceptConnection",
      "d": 1310768,
      "h": 8591245360,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591245360),
//--TRIMMABLE-BOUNDARY-START(30066081840),
    {
      "t": 1310768,
      "n": "BsdUrgent",
      "d": 1310768,
      "h": 30066081840,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066081840),
//--TRIMMABLE-BOUNDARY-START(73015754800),
    {
      "t": 1310768,
      "n": "Expedited",
      "d": 1310768,
      "h": 73015754800,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015754800),
//--TRIMMABLE-BOUNDARY-START(81605689392),
    {
      "t": 1310768,
      "n": "HeaderIncluded",
      "d": 1310768,
      "h": 81605689392,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81605689392),
//--TRIMMABLE-BOUNDARY-START(193274839088),
    {
      "t": 1310768,
      "n": "TcpKeepAliveTime",
      "d": 1310768,
      "h": 193274839088,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(193274839088),
//--TRIMMABLE-BOUNDARY-START(201864773680),
    {
      "t": 1310768,
      "n": "TypeOfService",
      "d": 1310768,
      "h": 201864773680,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(201864773680),
//--TRIMMABLE-BOUNDARY-START(98785558576),
    {
      "t": 1310768,
      "n": "IpTimeToLive",
      "d": 1310768,
      "h": 98785558576,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98785558576),
//--TRIMMABLE-BOUNDARY-START(163210068016),
    {
      "t": 1310768,
      "n": "ReuseAddress",
      "d": 1310768,
      "h": 163210068016,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163210068016),
//--TRIMMABLE-BOUNDARY-START(107375493168),
    {
      "t": 1310768,
      "n": "KeepAlive",
      "d": 1310768,
      "h": 107375493168,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107375493168),
//--TRIMMABLE-BOUNDARY-START(120260395056),
    {
      "t": 1310768,
      "n": "MulticastInterface",
      "d": 1310768,
      "h": 120260395056,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120260395056),
//--TRIMMABLE-BOUNDARY-START(128850329648),
    {
      "t": 1310768,
      "n": "MulticastTimeToLive",
      "d": 1310768,
      "h": 128850329648,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128850329648),
//--TRIMMABLE-BOUNDARY-START(124555362352),
    {
      "t": 1310768,
      "n": "MulticastLoopback",
      "d": 1310768,
      "h": 124555362352,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124555362352),
//--TRIMMABLE-BOUNDARY-START(12886212656),
    {
      "t": 1310768,
      "n": "AddMembership",
      "d": 1310768,
      "h": 12886212656,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886212656),
//--TRIMMABLE-BOUNDARY-START(55835885616),
    {
      "t": 1310768,
      "n": "DropMembership",
      "d": 1310768,
      "h": 55835885616,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835885616),
//--TRIMMABLE-BOUNDARY-START(42950983728),
    {
      "t": 1310768,
      "n": "DontFragment",
      "d": 1310768,
      "h": 42950983728,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950983728),
//--TRIMMABLE-BOUNDARY-START(17181179952),
    {
      "t": 1310768,
      "n": "AddSourceMembership",
      "d": 1310768,
      "h": 17181179952,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181179952),
//--TRIMMABLE-BOUNDARY-START(77310722096),
    {
      "t": 1310768,
      "n": "FastOpen",
      "d": 1310768,
      "h": 77310722096,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310722096),
//--TRIMMABLE-BOUNDARY-START(51540918320),
    {
      "t": 1310768,
      "n": "DontRoute",
      "d": 1310768,
      "h": 51540918320,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540918320),
//--TRIMMABLE-BOUNDARY-START(60130852912),
    {
      "t": 1310768,
      "n": "DropSourceMembership",
      "d": 1310768,
      "h": 60130852912,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130852912),
//--TRIMMABLE-BOUNDARY-START(188979871792),
    {
      "t": 1310768,
      "n": "TcpKeepAliveRetryCount",
      "d": 1310768,
      "h": 188979871792,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(188979871792),
//--TRIMMABLE-BOUNDARY-START(21476147248),
    {
      "t": 1310768,
      "n": "BlockSource",
      "d": 1310768,
      "h": 21476147248,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476147248),
//--TRIMMABLE-BOUNDARY-START(184684904496),
    {
      "t": 1310768,
      "n": "TcpKeepAliveInterval",
      "d": 1310768,
      "h": 184684904496,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(184684904496),
//--TRIMMABLE-BOUNDARY-START(206159740976),
    {
      "t": 1310768,
      "n": "UnblockSource",
      "d": 1310768,
      "h": 206159740976,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(206159740976),
//--TRIMMABLE-BOUNDARY-START(146030198832),
    {
      "t": 1310768,
      "n": "PacketInformation",
      "d": 1310768,
      "h": 146030198832,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146030198832),
//--TRIMMABLE-BOUNDARY-START(34361049136),
    {
      "t": 1310768,
      "n": "ChecksumCoverage",
      "d": 1310768,
      "h": 34361049136,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361049136),
//--TRIMMABLE-BOUNDARY-START(85900656688),
    {
      "t": 1310768,
      "n": "HopLimit",
      "d": 1310768,
      "h": 85900656688,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900656688),
//--TRIMMABLE-BOUNDARY-START(94490591280),
    {
      "t": 1310768,
      "n": "IPProtectionLevel",
      "d": 1310768,
      "h": 94490591280,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94490591280),
//--TRIMMABLE-BOUNDARY-START(103080525872),
    {
      "t": 1310768,
      "n": "IPv6Only",
      "d": 1310768,
      "h": 103080525872,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103080525872),
//--TRIMMABLE-BOUNDARY-START(25771114544),
    {
      "t": 1310768,
      "n": "Broadcast",
      "d": 1310768,
      "h": 25771114544,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771114544),
//--TRIMMABLE-BOUNDARY-START(219044642864),
    {
      "t": 1310768,
      "n": "UseLoopback",
      "d": 1310768,
      "h": 219044642864,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(219044642864),
//--TRIMMABLE-BOUNDARY-START(111670460464),
    {
      "t": 1310768,
      "n": "Linger",
      "d": 1310768,
      "h": 111670460464,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111670460464),
//--TRIMMABLE-BOUNDARY-START(141735231536),
    {
      "t": 1310768,
      "n": "OutOfBandInline",
      "d": 1310768,
      "h": 141735231536,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141735231536),
//--TRIMMABLE-BOUNDARY-START(171800002608),
    {
      "t": 1310768,
      "n": "SendBuffer",
      "d": 1310768,
      "h": 171800002608,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171800002608),
//--TRIMMABLE-BOUNDARY-START(150325166128),
    {
      "t": 1310768,
      "n": "ReceiveBuffer",
      "d": 1310768,
      "h": 150325166128,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150325166128),
//--TRIMMABLE-BOUNDARY-START(176094969904),
    {
      "t": 1310768,
      "n": "SendLowWater",
      "d": 1310768,
      "h": 176094969904,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176094969904),
//--TRIMMABLE-BOUNDARY-START(154620133424),
    {
      "t": 1310768,
      "n": "ReceiveLowWater",
      "d": 1310768,
      "h": 154620133424,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154620133424),
//--TRIMMABLE-BOUNDARY-START(180389937200),
    {
      "t": 1310768,
      "n": "SendTimeout",
      "d": 1310768,
      "h": 180389937200,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180389937200),
//--TRIMMABLE-BOUNDARY-START(158915100720),
    {
      "t": 1310768,
      "n": "ReceiveTimeout",
      "d": 1310768,
      "h": 158915100720,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158915100720),
//--TRIMMABLE-BOUNDARY-START(64425820208),
    {
      "t": 1310768,
      "n": "Error",
      "d": 1310768,
      "h": 64425820208,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425820208),
//--TRIMMABLE-BOUNDARY-START(197569806384),
    {
      "t": 1310768,
      "n": "Type",
      "d": 1310768,
      "h": 197569806384,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(197569806384),
//--TRIMMABLE-BOUNDARY-START(167505035312),
    {
      "t": 1310768,
      "n": "ReuseUnicastPort",
      "d": 1310768,
      "h": 167505035312,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167505035312),
//--TRIMMABLE-BOUNDARY-START(210454708272),
    {
      "t": 1310768,
      "n": "UpdateAcceptContext",
      "d": 1310768,
      "h": 210454708272,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(210454708272),
//--TRIMMABLE-BOUNDARY-START(214749675568),
    {
      "t": 1310768,
      "n": "UpdateConnectContext",
      "d": 1310768,
      "h": 214749675568,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(214749675568),
//--TRIMMABLE-BOUNDARY-START(115965427760),
    {
      "t": 1310768,
      "n": "MaxConnections",
      "d": 1310768,
      "h": 115965427760,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115965427760)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278064),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1310768,
      "h": 4296278064,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278064)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1310768
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketOptionName`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310768)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507376)
        $asm.$str("$sns.System.Net.Sockets.SocketShutdown", ($self) => class SocketShutdown extends $.$$.System.Enum
        {
            static Receive = 0;
            static Send = 1;
            static Both = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1507376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Receive": 0n,
                    "Send": 1n,
                    "Both": 2n
                };
            }
            static $h = 1507376;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886409264),
    {
      "t": 1507376,
      "n": "Receive",
      "d": 1507376,
      "h": 12886409264,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886409264),
//--TRIMMABLE-BOUNDARY-START(17181376560),
    {
      "t": 1507376,
      "n": "Send",
      "d": 1507376,
      "h": 17181376560,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181376560),
//--TRIMMABLE-BOUNDARY-START(8591441968),
    {
      "t": 1507376,
      "n": "Both",
      "d": 1507376,
      "h": 8591441968,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591441968)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296474672),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1507376,
      "h": 4296474672,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296474672)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1507376
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketShutdown`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507376)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638448)
        $asm.$str("$sns.System.Net.Sockets.SocketType", ($self) => class SocketType extends $.$$.System.Enum
        {
            static Unknown = -1;
            static Stream = 1;
            static Dgram = 2;
            static Raw = 3;
            static Rdm = 4;
            static Seqpacket = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1638448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Stream": 1n,
                    "Dgram": 2n,
                    "Raw": 3n,
                    "Rdm": 4n,
                    "Seqpacket": 5n
                };
            }
            static $h = 1638448;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(30066409520),
    {
      "t": 1638448,
      "n": "Unknown",
      "d": 1638448,
      "h": 30066409520,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066409520),
//--TRIMMABLE-BOUNDARY-START(25771442224),
    {
      "t": 1638448,
      "n": "Stream",
      "d": 1638448,
      "h": 25771442224,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771442224),
//--TRIMMABLE-BOUNDARY-START(8591573040),
    {
      "t": 1638448,
      "n": "Dgram",
      "d": 1638448,
      "h": 8591573040,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591573040),
//--TRIMMABLE-BOUNDARY-START(12886540336),
    {
      "t": 1638448,
      "n": "Raw",
      "d": 1638448,
      "h": 12886540336,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886540336),
//--TRIMMABLE-BOUNDARY-START(17181507632),
    {
      "t": 1638448,
      "n": "Rdm",
      "d": 1638448,
      "h": 17181507632,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181507632),
//--TRIMMABLE-BOUNDARY-START(21476474928),
    {
      "t": 1638448,
      "n": "Seqpacket",
      "d": 1638448,
      "h": 21476474928,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476474928)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605744),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638448,
      "h": 4296605744,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605744)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1638448
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638448)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835056)
        $asm.$str("$sns.System.Net.Sockets.TransmitFileOptions", ($self) => class TransmitFileOptions extends $.$$.System.Enum
        {
            static UseDefaultWorkerThread = 0;
            static Disconnect = 1;
            static ReuseSocket = 2;
            static WriteBehind = 4;
            static UseSystemThread = 16;
            static UseKernelApc = 32;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1835056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "UseDefaultWorkerThread": 0n,
                    "Disconnect": 1n,
                    "ReuseSocket": 2n,
                    "WriteBehind": 4n,
                    "UseSystemThread": 16n,
                    "UseKernelApc": 32n
                };
            }
            static $h = 1835056;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181704240),
    {
      "t": 1835056,
      "n": "UseDefaultWorkerThread",
      "d": 1835056,
      "h": 17181704240,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181704240),
//--TRIMMABLE-BOUNDARY-START(8591769648),
    {
      "t": 1835056,
      "n": "Disconnect",
      "d": 1835056,
      "h": 8591769648,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591769648),
//--TRIMMABLE-BOUNDARY-START(12886736944),
    {
      "t": 1835056,
      "n": "ReuseSocket",
      "d": 1835056,
      "h": 12886736944,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886736944),
//--TRIMMABLE-BOUNDARY-START(30066606128),
    {
      "t": 1835056,
      "n": "WriteBehind",
      "d": 1835056,
      "h": 30066606128,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066606128),
//--TRIMMABLE-BOUNDARY-START(25771638832),
    {
      "t": 1835056,
      "n": "UseSystemThread",
      "d": 1835056,
      "h": 25771638832,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771638832),
//--TRIMMABLE-BOUNDARY-START(21476671536),
    {
      "t": 1835056,
      "n": "UseKernelApc",
      "d": 1835056,
      "h": 21476671536,
      "f": 4194337,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476671536)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802352),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1835056,
      "h": 4296802352,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296802352)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1835056,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.TransmitFileOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835056)
        
        
        //--TRIMMABLE-BOUNDARY-START(655408)
        $asm.$cls("$sns.System.Net.Sockets.SafeSocketHandle", ($self) => class SafeSocketHandle extends $.$$.Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid
        {
            //--TRIMMABLE-BOUNDARY-START(4295622704)
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295622704);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622704)
            
            //--TRIMMABLE-BOUNDARY-START(8590590000)
            $ctor$5(/*nint*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590590000);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590590000)
            
            //--TRIMMABLE-BOUNDARY-START(21475491888)
            /*bool */ get IsInvalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180524592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475491888)
            
            //--TRIMMABLE-BOUNDARY-START(25770459184)
            /*bool */ ReleaseHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770459184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770459184)
            
            static $h = 655408;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 7995393,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475491888),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180524592,
        "f": 50364417
      },
      "n": "IsInvalid",
      "d": 655408,
      "h": 21475491888,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475491888)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770459184),
    {
      "r": 262145,
      "n": "ReleaseHandle",
      "d": 655408,
      "h": 25770459184,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770459184)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622704),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 655408,
      "h": 4295622704,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622704),
//--TRIMMABLE-BOUNDARY-START(8590590000),
    {
      "p": [
        {
          "n": "preexistingHandle",
          "p": 786433
        },
        {
          "n": "ownsHandle",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 655408,
      "h": 8590590000,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590590000)
  ],
  "i": [90308609
  ],
  "h": 655408
}; }
            static get $b() { return $.$$.Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.SafeSocketHandle`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655408)
        
        
        //--TRIMMABLE-BOUNDARY-START(917552)
        $asm.$cls("$sns.System.Net.Sockets.SocketAsyncEventArgs", ($self) => class SocketAsyncEventArgs extends $.$$.System.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(4295884848)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295884848);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295884848)
            
            //--TRIMMABLE-BOUNDARY-START(8590852144)
            $ctor$3(/*bool*/ unsafeSuppressExecutionContextFlow)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590852144);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590852144)
            
            //--TRIMMABLE-BOUNDARY-START(12885819440)
            /*System.Net.Sockets.Socket? */ get AcceptSocket()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015361584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket? */ set AcceptSocket(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468759088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885819440)
            
            //--TRIMMABLE-BOUNDARY-START(25770721328)
            /*byte[]? */ get Buffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605296176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770721328)
            
            //--TRIMMABLE-BOUNDARY-START(30065688624)
            /*System.Collections.Generic.IList<System.ArraySegment<byte>>? */ get BufferList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195230768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IList<System.ArraySegment<byte>>? */ set BufferList(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058693680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065688624)
            
            //--TRIMMABLE-BOUNDARY-START(34360655920)
            /*int */ get BytesTransferred()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785165360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360655920)
            
            //--TRIMMABLE-BOUNDARY-START(42950590512)
            /*System.Exception? */ get ConnectByNameError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375099952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950590512)
            
            //--TRIMMABLE-BOUNDARY-START(47245557808)
            /*System.Net.Sockets.Socket? */ get ConnectSocket()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965034544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245557808)
            
            //--TRIMMABLE-BOUNDARY-START(51540525104)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554969136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540525104)
            
            //--TRIMMABLE-BOUNDARY-START(55835492400)
            /*bool */ get DisconnectReuseSocket()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144903728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DisconnectReuseSocket(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648628272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835492400)
            
            //--TRIMMABLE-BOUNDARY-START(231929151536)
            /*System.Net.Sockets.SocketAsyncOperation */ get LastOperation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734838320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(231929151536)
            
            //--TRIMMABLE-BOUNDARY-START(236224118832)
            /*System.Memory<byte> */ get MemoryBuffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324772912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(236224118832)
            
            //--TRIMMABLE-BOUNDARY-START(240519086128)
            /*int */ get Offset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914707504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(240519086128)
            
            //--TRIMMABLE-BOUNDARY-START(249109020720)
            /*System.Net.Sockets.IPPacketInformation */ get ReceiveMessageFromPacketInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504642096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(249109020720)
            
            //--TRIMMABLE-BOUNDARY-START(253403988016)
            /*System.Net.EndPoint? */ get RemoteEndPoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094576688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ set RemoteEndPoint(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238562864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(253403988016)
            
            //--TRIMMABLE-BOUNDARY-START(266288889904)
            /*System.Net.Sockets.SendPacketsElement[]? */ get SendPacketsElements()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684511280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SendPacketsElement[]? */ set SendPacketsElements(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828497456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(266288889904)
            
            //--TRIMMABLE-BOUNDARY-START(270583857200)
            /*System.Net.Sockets.TransmitFileOptions */ get SendPacketsFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274445872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TransmitFileOptions */ set SendPacketsFlags(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418432048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(270583857200)
            
            //--TRIMMABLE-BOUNDARY-START(274878824496)
            /*int */ get SendPacketsSendSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864380464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendPacketsSendSize(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335008366640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(274878824496)
            
            //--TRIMMABLE-BOUNDARY-START(377958039600)
            /*System.Net.Sockets.SocketError */ get SocketError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454315056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketError */ set SocketError(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343598301232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(377958039600)
            
            //--TRIMMABLE-BOUNDARY-START(382253006896)
            /*System.Net.Sockets.SocketFlags */ get SocketFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044249648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketFlags */ set SocketFlags(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352188235824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(382253006896)
            
            //--TRIMMABLE-BOUNDARY-START(386547974192)
            /*object? */ get UserToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634184240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ set UserToken(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778170416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(386547974192)
            
            //--TRIMMABLE-BOUNDARY-START(38655623216)
            /*System.EventHandler<System.Net.Sockets.SocketAsyncEventArgs>?*/ add_Completed(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475754032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            /*System.EventHandler<System.Net.Sockets.SocketAsyncEventArgs>?*/ remove_Completed(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993922608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38655623216)
            
            //--TRIMMABLE-BOUNDARY-START(60130459696)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130459696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60130459696)
            
            $dtor()
            {
            }
            //--TRIMMABLE-BOUNDARY-START(244814053424)
            /*void */ OnCompleted(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814053424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(244814053424)
            
            //--TRIMMABLE-BOUNDARY-START(365073137712)
            /*void */ SetBuffer(/*byte[]?*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365073137712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(365073137712)
            
            //--TRIMMABLE-BOUNDARY-START(369368105008)
            /*void */ SetBuffer$1(/*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369368105008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(369368105008)
            
            //--TRIMMABLE-BOUNDARY-START(373663072304)
            /*void */ SetBuffer$2(/*System.Memory<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373663072304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(373663072304)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 917552;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79757313,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885819440),
    {
      "p": 852016,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015361584,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283468759088,
        "f": 83886081
      },
      "n": "AcceptSocket",
      "d": 917552,
      "h": 12885819440,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885819440),
//--TRIMMABLE-BOUNDARY-START(25770721328),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605296176,
        "f": 50331649
      },
      "n": "Buffer",
      "d": 917552,
      "h": 25770721328,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770721328),
//--TRIMMABLE-BOUNDARY-START(30065688624),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195230768,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292058693680,
        "f": 83886081
      },
      "n": "BufferList",
      "d": 917552,
      "h": 30065688624,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065688624),
//--TRIMMABLE-BOUNDARY-START(34360655920),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785165360,
        "f": 50331649
      },
      "n": "BytesTransferred",
      "d": 917552,
      "h": 34360655920,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360655920),
//--TRIMMABLE-BOUNDARY-START(42950590512),
    {
      "p": 80019457,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375099952,
        "f": 50331649
      },
      "n": "ConnectByNameError",
      "d": 917552,
      "h": 42950590512,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950590512),
//--TRIMMABLE-BOUNDARY-START(47245557808),
    {
      "p": 852016,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965034544,
        "f": 50331649
      },
      "n": "ConnectSocket",
      "d": 917552,
      "h": 47245557808,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245557808),
//--TRIMMABLE-BOUNDARY-START(51540525104),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554969136,
        "f": 50331649
      },
      "n": "Count",
      "d": 917552,
      "h": 51540525104,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540525104),
//--TRIMMABLE-BOUNDARY-START(55835492400),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144903728,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300648628272,
        "f": 83886081
      },
      "n": "DisconnectReuseSocket",
      "d": 917552,
      "h": 55835492400,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835492400),
//--TRIMMABLE-BOUNDARY-START(231929151536),
    {
      "p": 983088,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734838320,
        "f": 50331649
      },
      "n": "LastOperation",
      "d": 917552,
      "h": 231929151536,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(231929151536),
//--TRIMMABLE-BOUNDARY-START(236224118832),
    {
      "p": $.$$.System.Memory$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324772912,
        "f": 50331649
      },
      "n": "MemoryBuffer",
      "d": 917552,
      "h": 236224118832,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236224118832),
//--TRIMMABLE-BOUNDARY-START(240519086128),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914707504,
        "f": 50331649
      },
      "n": "Offset",
      "d": 917552,
      "h": 240519086128,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240519086128),
//--TRIMMABLE-BOUNDARY-START(249109020720),
    {
      "p": 131120,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504642096,
        "f": 50331649
      },
      "n": "ReceiveMessageFromPacketInfo",
      "d": 917552,
      "h": 249109020720,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(249109020720),
//--TRIMMABLE-BOUNDARY-START(253403988016),
    {
      "p": 2555951,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094576688,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309238562864,
        "f": 83886081
      },
      "n": "RemoteEndPoint",
      "d": 917552,
      "h": 253403988016,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253403988016),
//--TRIMMABLE-BOUNDARY-START(266288889904),
    {
      "p": $.$typeArray($.$sns.System.Net.Sockets.SendPacketsElement).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684511280,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317828497456,
        "f": 83886081
      },
      "n": "SendPacketsElements",
      "d": 917552,
      "h": 266288889904,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(266288889904),
//--TRIMMABLE-BOUNDARY-START(270583857200),
    {
      "p": 1835056,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274445872,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326418432048,
        "f": 83886081
      },
      "n": "SendPacketsFlags",
      "d": 917552,
      "h": 270583857200,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270583857200),
//--TRIMMABLE-BOUNDARY-START(274878824496),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201864380464,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 335008366640,
        "f": 83886081
      },
      "n": "SendPacketsSendSize",
      "d": 917552,
      "h": 274878824496,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(274878824496),
//--TRIMMABLE-BOUNDARY-START(377958039600),
    {
      "p": 4653103,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210454315056,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 343598301232,
        "f": 83886081
      },
      "n": "SocketError",
      "d": 917552,
      "h": 377958039600,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(377958039600),
//--TRIMMABLE-BOUNDARY-START(382253006896),
    {
      "p": 1048624,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219044249648,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 352188235824,
        "f": 83886081
      },
      "n": "SocketFlags",
      "d": 917552,
      "h": 382253006896,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(382253006896),
//--TRIMMABLE-BOUNDARY-START(386547974192),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227634184240,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 360778170416,
        "f": 83886081
      },
      "n": "UserToken",
      "d": 917552,
      "h": 386547974192,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(386547974192)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130459696),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 917552,
      "h": 60130459696,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130459696),
//--TRIMMABLE-BOUNDARY-START(244814053424),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 917552
        }
      ],
      "n": "OnCompleted",
      "d": 917552,
      "h": 244814053424,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(244814053424),
//--TRIMMABLE-BOUNDARY-START(365073137712),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "SetBuffer",
      "d": 917552,
      "h": 365073137712,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(365073137712),
//--TRIMMABLE-BOUNDARY-START(369368105008),
    {
      "r": 65537,
      "p": [
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "SetBuffer",
      "o": "@$1",
      "d": 917552,
      "h": 369368105008,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(369368105008),
//--TRIMMABLE-BOUNDARY-START(373663072304),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        }
      ],
      "n": "SetBuffer",
      "o": "@$2",
      "d": 917552,
      "h": 373663072304,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(373663072304)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884848),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917552,
      "h": 4295884848,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295884848),
//--TRIMMABLE-BOUNDARY-START(8590852144),
    {
      "p": [
        {
          "n": "unsafeSuppressExecutionContextFlow",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917552,
      "h": 8590852144,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590852144)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(38655623216),
    {
      "e": $.$$.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h
          }
        ],
        "n": "add_Completed",
        "d": 917552,
        "h": 21475754032,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h
          }
        ],
        "n": "remove_Completed",
        "d": 917552,
        "h": 261993922608,
        "f": 285212673
      },
      "n": "Completed",
      "d": 917552,
      "h": 38655623216,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(38655623216)
  ],
  "i": [90308609
  ],
  "h": 917552
}; }
            static get $b() { return $.$$.System.EventArgs; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.SocketAsyncEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917552)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution"))
//--TRIMMABLE-BOUNDARY-END(48)
