
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $ssc, $sris, $scsl, $sl, $snp, $sspw, $sdd, $snnr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Sockets", 
    {"h":42679,"f":"System.Net.Sockets","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Sockets","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Sockets","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sns.System.Net.Sockets.IPv6MulticastOption", ($self) => class IPv6MulticastOption extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.IPAddress*/ group)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ group, /*long*/ ifindex)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get InterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set InterfaceIndex(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 304823;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3076570,"g":{"r":0,"d":0,"h":17180174007,"f":1},"s":{"r":0,"d":0,"h":21475141303,"f":1},"n":"Group","d":304823,"h":12885206711,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":30065075895,"f":1},"s":{"r":0,"d":0,"h":34360043191,"f":1},"n":"InterfaceIndex","d":304823,"h":25770108599,"f":1}],"c":[{"p":[{"n":"group","p":3076570}],"n":".ctor","o":"$ctor$1","d":304823,"h":4295272119,"f":1},{"p":[{"n":"group","p":3076570},{"n":"ifindex","p":917505}],"n":".ctor","o":"$ctor$2","d":304823,"h":8590239415,"f":1}],"h":304823}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.IPv6MulticastOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.LingerOption", ($self) => class LingerOption extends $.$spc.System.Object
        {
            $ctor$1(/*bool*/ enable, /*int*/ seconds)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Enabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Enabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get LingerTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set LingerTime(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.LingerOption.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.LingerOption.GetHashCode.apply(this, arguments); }
            static $h = 370359;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885272247,"f":1},"s":{"r":0,"d":0,"h":17180239543,"f":1},"n":"Enabled","d":370359,"h":8590304951,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25770174135,"f":1},"s":{"r":0,"d":0,"h":30065141431,"f":1},"n":"LingerTime","d":370359,"h":21475206839,"f":1}],"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":370359,"h":34360108727,"f":32769},{"r":655361,"n":"GetHashCode","d":370359,"h":38655076023,"f":32769}],"c":[{"p":[{"n":"enable","p":262145},{"n":"seconds","p":655361}],"n":".ctor","o":"$ctor$1","d":370359,"h":4295337655,"f":1}],"h":370359}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.LingerOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.MulticastOption", ($self) => class MulticastOption extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.IPAddress*/ group)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ group, /*int*/ interfaceIndex)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.IPAddress*/ group, /*System.Net.IPAddress*/ mcint)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InterfaceIndex(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress? */ get LocalAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress? */ set LocalAddress(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 435895;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3076570,"g":{"r":0,"d":0,"h":21475272375,"f":1},"s":{"r":0,"d":0,"h":25770239671,"f":1},"n":"Group","d":435895,"h":17180305079,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360174263,"f":1},"s":{"r":0,"d":0,"h":38655141559,"f":1},"n":"InterfaceIndex","d":435895,"h":30065206967,"f":1},{"p":3076570,"g":{"r":0,"d":0,"h":47245076151,"f":1},"s":{"r":0,"d":0,"h":51540043447,"f":1},"n":"LocalAddress","d":435895,"h":42950108855,"f":1}],"c":[{"p":[{"n":"group","p":3076570}],"n":".ctor","o":"$ctor$1","d":435895,"h":4295403191,"f":1},{"p":[{"n":"group","p":3076570},{"n":"interfaceIndex","p":655361}],"n":".ctor","o":"$ctor$2","d":435895,"h":8590370487,"f":1},{"p":[{"n":"group","p":3076570},{"n":"mcint","p":3076570}],"n":".ctor","o":"$ctor$3","d":435895,"h":12885337783,"f":1}],"h":435895}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.MulticastOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SendPacketsElement", ($self) => class SendPacketsElement extends $.$spc.System.Object
        {
            $ctor$1(/*byte[]*/ buffer)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.FileStream*/ fileStream)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.FileStream*/ fileStream, /*long*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.FileStream*/ fileStream, /*long*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$7(/*System.ReadOnlyMemory<byte>*/ buffer)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$8(/*System.ReadOnlyMemory<byte>*/ buffer, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$9(/*string*/ filepath)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$10(/*string*/ filepath, /*int*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$11(/*string*/ filepath, /*int*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$12(/*string*/ filepath, /*long*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$13(/*string*/ filepath, /*long*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*byte[]? */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EndOfPacket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FilePath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.FileStream? */ get FileStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ReadOnlyMemory<byte>? */ get MemoryBuffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Offset()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get OffsetLong()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 829111;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":64425338551,"f":1},"n":"Buffer","d":829111,"h":60130371255,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73015273143,"f":1},"n":"Count","d":829111,"h":68720305847,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81605207735,"f":1},"n":"EndOfPacket","d":829111,"h":77310240439,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90195142327,"f":1},"n":"FilePath","d":829111,"h":85900175031,"f":1},{"p":60293121,"g":{"r":0,"d":0,"h":98785076919,"f":1},"n":"FileStream","d":829111,"h":94490109623,"f":1},{"p":$.$typeNullable($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte)).$h,"g":{"r":0,"d":0,"h":107375011511,"f":1},"n":"MemoryBuffer","d":829111,"h":103080044215,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":115964946103,"f":1},"n":"Offset","d":829111,"h":111669978807,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":124554880695,"f":1},"n":"OffsetLong","d":829111,"h":120259913399,"f":1}],"c":[{"p":[{"n":"buffer","p":0}],"n":".ctor","o":"$ctor$1","d":829111,"h":4295796407,"f":1},{"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$2","d":829111,"h":8590763703,"f":1},{"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$3","d":829111,"h":12885730999,"f":1},{"p":[{"n":"fileStream","p":60293121}],"n":".ctor","o":"$ctor$4","d":829111,"h":17180698295,"f":1},{"p":[{"n":"fileStream","p":60293121},{"n":"offset","p":917505},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$5","d":829111,"h":21475665591,"f":1},{"p":[{"n":"fileStream","p":60293121},{"n":"offset","p":917505},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$6","d":829111,"h":25770632887,"f":1},{"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h}],"n":".ctor","o":"$ctor$7","d":829111,"h":30065600183,"f":1},{"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$8","d":829111,"h":34360567479,"f":1},{"p":[{"n":"filepath","p":1310721}],"n":".ctor","o":"$ctor$9","d":829111,"h":38655534775,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$10","d":829111,"h":42950502071,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$11","d":829111,"h":47245469367,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":917505},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$12","d":829111,"h":51540436663,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":917505},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$13","d":829111,"h":55835403959,"f":1}],"h":829111}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SendPacketsElement`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SocketTaskExtensions", ($self) => class SocketTaskExtensions
        {
            static /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync(/*this System.Net.Sockets.Socket*/ socket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.Sockets.Socket?*/ acceptSocket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$4(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$6(/*this System.Net.Sockets.Socket*/ socket, /*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$7(/*this System.Net.Sockets.Socket*/ socket, /*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ ReceiveAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ ReceiveAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<int> */ SendAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendToAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1615543;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"socket","p":894647}],"n":"AcceptAsync","d":1615543,"h":4296582839,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"socket","p":894647},{"n":"acceptSocket","p":894647}],"n":"AcceptAsync","o":"@$1","d":1615543,"h":8591550135,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":133300225,"p":[{"n":"socket","p":894647},{"n":"remoteEP","p":2617818}],"n":"ConnectAsync","d":1615543,"h":12886517431,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":136118273,"p":[{"n":"socket","p":894647},{"n":"remoteEP","p":2617818},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":1615543,"h":17181484727,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":133300225,"p":[{"n":"socket","p":894647},{"n":"address","p":3076570},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":1615543,"h":21476452023,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":136118273,"p":[{"n":"socket","p":894647},{"n":"address","p":3076570},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":1615543,"h":25771419319,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":133300225,"p":[{"n":"socket","p":894647},{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$4","d":1615543,"h":30066386615,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":136118273,"p":[{"n":"socket","p":894647},{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":1615543,"h":34361353911,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":133300225,"p":[{"n":"socket","p":894647},{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$6","d":1615543,"h":38656321207,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":136118273,"p":[{"n":"socket","p":894647},{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$7","d":1615543,"h":42951288503,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":894647},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255}],"n":"ReceiveAsync","d":1615543,"h":47246255799,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":894647},{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1091255}],"n":"ReceiveAsync","o":"@$1","d":1615543,"h":51541223095,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":894647},{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$2","d":1615543,"h":55836190391,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"socket","p":894647},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"remoteEndPoint","p":2617818}],"n":"ReceiveFromAsync","d":1615543,"h":60131157687,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"socket","p":894647},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"remoteEndPoint","p":2617818}],"n":"ReceiveMessageFromAsync","d":1615543,"h":64426124983,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":894647},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255}],"n":"SendAsync","d":1615543,"h":68721092279,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":894647},{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1091255}],"n":"SendAsync","o":"@$1","d":1615543,"h":73016059575,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":894647},{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$2","d":1615543,"h":77311026871,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":894647},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"remoteEP","p":2617818}],"n":"SendToAsync","d":1615543,"h":81605994167,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}],"h":1615543,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SocketTaskExtensions`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.Socket", ($self) => class Socket extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.Sockets.AddressFamily*/ addressFamily, /*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.Sockets.SafeSocketHandle*/ handle)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.Sockets.SocketInformation*/ socketInformation)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.Sockets.AddressFamily */ get AddressFamily()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Blocking()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Blocking(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Connected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DontFragment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DontFragment(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DualMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DualMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableBroadcast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableBroadcast(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*nint */ get Handle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsBound()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ get LingerState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ set LingerState(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get MulticastLoopback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MulticastLoopback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get NoDelay()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set NoDelay(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsIPv4()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsIPv6()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsUnixDomainSockets()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.ProtocolType */ get ProtocolType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SafeSocketHandle */ get SafeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketType */ get SocketType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get SupportsIPv4()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get SupportsIPv6()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ get Ttl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ set Ttl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseOnlyOverlappedIO()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseOnlyOverlappedIO(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ Accept()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync$1(/*System.Net.Sockets.Socket?*/ acceptSocket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptAsync$2(/*System.Net.Sockets.Socket?*/ acceptSocket, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ AcceptAsync$3(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptAsync$4(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept$1(/*int*/ receiveSize, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept$2(/*System.Net.Sockets.Socket?*/ acceptSocket, /*int*/ receiveSize, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect(/*System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$1(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$3(/*string*/ host, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginDisconnect(/*bool*/ reuseSocket, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceive(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginReceive$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceive$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginReceive$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceiveFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceiveMessageFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginSend$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginSend$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendFile(/*string?*/ fileName, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendFile$1(/*string?*/ fileName, /*byte[]?*/ preBuffer, /*byte[]?*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendTo(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Bind(/*System.Net.EndPoint*/ localEP)
            {
            }
            static /*void */ CancelConnectAsync(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
            }
            /*void */ Close()
            {
            }
            /*void */ Close$1(/*int*/ timeout)
            {
            }
            /*void */ Connect(/*System.Net.EndPoint*/ remoteEP)
            {
            }
            /*void */ Connect$1(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
            }
            /*void */ Connect$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
            }
            /*void */ Connect$3(/*string*/ host, /*int*/ port)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync(/*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ConnectAsync$6(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ ConnectAsync$7(/*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType, /*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$8(/*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$9(/*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Disconnect(/*bool*/ reuseSocket)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisconnectAsync(/*bool*/ reuseSocket, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ DisconnectAsync$1(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Net.Sockets.SocketInformation */ DuplicateAndClose(/*int*/ targetProcessId)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept(/*out byte[]*/ buffer, /*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept$1(/*out byte[]*/ buffer, /*out int*/ bytesTransferred, /*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept$2(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndConnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndDisconnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndReceive(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceive$1(/*System.IAsyncResult*/ asyncResult, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceiveFrom(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.EndPoint*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceiveMessageFrom(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ endPoint, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend$1(/*System.IAsyncResult*/ asyncResult, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndSendFile(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndSendTo(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            /*int */ GetRawSocketOption(/*int*/ optionLevel, /*int*/ optionName, /*System.Span<byte>*/ optionValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ GetSocketOption(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetSocketOption$1(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*byte[]*/ optionValue)
            {
            }
            /*byte[] */ GetSocketOption$2(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*int*/ optionLength)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ IOControl(/*int*/ ioControlCode, /*byte[]?*/ optionInValue, /*byte[]?*/ optionOutValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ IOControl$1(/*System.Net.Sockets.IOControlCode*/ ioControlCode, /*byte[]?*/ optionInValue, /*byte[]?*/ optionOutValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Listen()
            {
            }
            /*void */ Listen$1(/*int*/ backlog)
            {
            }
            /*bool */ Poll(/*int*/ microSeconds, /*System.Net.Sockets.SelectMode*/ mode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Poll$1(/*System.TimeSpan*/ timeout, /*System.Net.Sockets.SelectMode*/ mode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive(/*byte[]*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$3(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$4(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$5(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$6(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$7(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$8(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$9(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$10(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync(/*System.ArraySegment<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$4(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$5(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveAsync$6(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$1(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$2(/*byte[]*/ buffer, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$4(/*System.Span<byte>*/ buffer, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$5(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$6(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ receivedAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$2(/*System.Memory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$3(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveFromAsync$4(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ receivedAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveFromAsync$5(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveMessageFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveMessageFrom$1(/*System.Span<byte>*/ buffer, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$2(/*System.Memory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$3(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveMessageFromAsync$4(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ Select(/*System.Collections.IList?*/ checkRead, /*System.Collections.IList?*/ checkWrite, /*System.Collections.IList?*/ checkError, /*int*/ microSeconds)
            {
            }
            static /*void */ Select$1(/*System.Collections.IList?*/ checkRead, /*System.Collections.IList?*/ checkWrite, /*System.Collections.IList?*/ checkError, /*System.TimeSpan*/ timeout)
            {
            }
            /*int */ Send(/*byte[]*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$3(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$4(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$5(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$6(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$7(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$8(/*System.ReadOnlySpan<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$9(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$10(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync(/*System.ArraySegment<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendAsync$4(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$5(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$6(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SendFile(/*string?*/ fileName)
            {
            }
            /*void */ SendFile$1(/*string?*/ fileName, /*byte[]?*/ preBuffer, /*byte[]?*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags)
            {
            }
            /*void */ SendFile$2(/*string?*/ fileName, /*System.ReadOnlySpan<byte>*/ preBuffer, /*System.ReadOnlySpan<byte>*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags)
            {
            }
            /*System.Threading.Tasks.ValueTask */ SendFileAsync(/*string?*/ fileName, /*System.ReadOnlyMemory<byte>*/ preBuffer, /*System.ReadOnlyMemory<byte>*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ SendFileAsync$1(/*string?*/ fileName, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendPacketsAsync(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$1(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$2(/*byte[]*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$4(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$5(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$6(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ socketAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendToAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendToAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendToAsync$2(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$3(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$4(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$5(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ socketAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetIPProtectionLevel(/*System.Net.Sockets.IPProtectionLevel*/ level)
            {
            }
            /*void */ SetRawSocketOption(/*int*/ optionLevel, /*int*/ optionName, /*System.ReadOnlySpan<byte>*/ optionValue)
            {
            }
            /*void */ SetSocketOption(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*bool*/ optionValue)
            {
            }
            /*void */ SetSocketOption$1(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*byte[]*/ optionValue)
            {
            }
            /*void */ SetSocketOption$2(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*int*/ optionValue)
            {
            }
            /*void */ SetSocketOption$3(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*object*/ optionValue)
            {
            }
            /*void */ Shutdown(/*System.Net.Sockets.SocketShutdown*/ how)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 894647;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4518362,"g":{"r":0,"d":0,"h":25770698423,"f":1},"n":"AddressFamily","d":894647,"h":21475731127,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360633015,"f":1},"n":"Available","d":894647,"h":30065665719,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950567607,"f":1},"s":{"r":0,"d":0,"h":47245534903,"f":1},"n":"Blocking","d":894647,"h":38655600311,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55835469495,"f":1},"n":"Connected","d":894647,"h":51540502199,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64425404087,"f":1},"s":{"r":0,"d":0,"h":68720371383,"f":1},"n":"DontFragment","d":894647,"h":60130436791,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77310305975,"f":1},"s":{"r":0,"d":0,"h":81605273271,"f":1},"n":"DualMode","d":894647,"h":73015338679,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":90195207863,"f":1},"s":{"r":0,"d":0,"h":94490175159,"f":1},"n":"EnableBroadcast","d":894647,"h":85900240567,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":103080109751,"f":1},"s":{"r":0,"d":0,"h":107375077047,"f":1},"n":"ExclusiveAddressUse","d":894647,"h":98785142455,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":115965011639,"f":1},"n":"Handle","d":894647,"h":111670044343,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554946231,"f":1},"n":"IsBound","d":894647,"h":120259978935,"f":1},{"p":370359,"g":{"r":0,"d":0,"h":133144880823,"f":1},"s":{"r":0,"d":0,"h":137439848119,"f":1},"n":"LingerState","d":894647,"h":128849913527,"f":1},{"p":2617818,"g":{"r":0,"d":0,"h":146029782711,"f":1},"n":"LocalEndPoint","d":894647,"h":141734815415,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":154619717303,"f":1},"s":{"r":0,"d":0,"h":158914684599,"f":1},"n":"MulticastLoopback","d":894647,"h":150324750007,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":167504619191,"f":1},"s":{"r":0,"d":0,"h":171799586487,"f":1},"n":"NoDelay","d":894647,"h":163209651895,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":180389521079,"f":33},"n":"OSSupportsIPv4","d":894647,"h":176094553783,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":188979455671,"f":33},"n":"OSSupportsIPv6","d":894647,"h":184684488375,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":197569390263,"f":33},"n":"OSSupportsUnixDomainSockets","d":894647,"h":193274422967,"f":33},{"p":632503,"g":{"r":0,"d":0,"h":206159324855,"f":1},"n":"ProtocolType","d":894647,"h":201864357559,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":214749259447,"f":1},"s":{"r":0,"d":0,"h":219044226743,"f":1},"n":"ReceiveBufferSize","d":894647,"h":210454292151,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":227634161335,"f":1},"s":{"r":0,"d":0,"h":231929128631,"f":1},"n":"ReceiveTimeout","d":894647,"h":223339194039,"f":1},{"p":2617818,"g":{"r":0,"d":0,"h":240519063223,"f":1},"n":"RemoteEndPoint","d":894647,"h":236224095927,"f":1},{"p":698039,"g":{"r":0,"d":0,"h":249108997815,"f":1},"n":"SafeHandle","d":894647,"h":244814030519,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":257698932407,"f":1},"s":{"r":0,"d":0,"h":261993899703,"f":1},"n":"SendBufferSize","d":894647,"h":253403965111,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":270583834295,"f":1},"s":{"r":0,"d":0,"h":274878801591,"f":1},"n":"SendTimeout","d":894647,"h":266288866999,"f":1},{"p":1681079,"g":{"r":0,"d":0,"h":283468736183,"f":1},"n":"SocketType","d":894647,"h":279173768887,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":292058670775,"f":33},"n":"SupportsIPv4","d":894647,"h":287763703479,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SupportsIPv4 has been deprecated. Use OSSupportsIPv4 instead.","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":300648605367,"f":33},"n":"SupportsIPv6","d":894647,"h":296353638071,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SupportsIPv6 has been deprecated. Use OSSupportsIPv6 instead.","t":1310721}]}]},{"p":524289,"g":{"r":0,"d":0,"h":309238539959,"f":1},"s":{"r":0,"d":0,"h":313533507255,"f":1},"n":"Ttl","d":894647,"h":304943572663,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":322123441847,"f":1},"s":{"r":0,"d":0,"h":326418409143,"f":1},"n":"UseOnlyOverlappedIO","d":894647,"h":317828474551,"f":1,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":8660844545,"a":[{"v":"UseOnlyOverlappedIO has been deprecated and is not supported.","t":1310721}]}]}],"m":[{"r":894647,"n":"Accept","d":894647,"h":330713376439,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"n":"AcceptAsync","d":894647,"h":335008343735,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"acceptSocket","p":894647}],"n":"AcceptAsync","o":"@$1","d":894647,"h":339303311031,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"acceptSocket","p":894647},{"n":"cancellationToken","p":125960193}],"n":"AcceptAsync","o":"@$2","d":894647,"h":343598278327,"f":1},{"r":262145,"p":[{"n":"e","p":960183}],"n":"AcceptAsync","o":"@$3","d":894647,"h":347893245623,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptAsync","o":"@$4","d":894647,"h":352188212919,"f":1},{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAccept","d":894647,"h":356483180215,"f":1},{"r":56950785,"p":[{"n":"receiveSize","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAccept","o":"@$1","d":894647,"h":360778147511,"f":1},{"r":56950785,"p":[{"n":"acceptSocket","p":894647},{"n":"receiveSize","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAccept","o":"@$2","d":894647,"h":365073114807,"f":1},{"r":56950785,"p":[{"n":"remoteEP","p":2617818},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","d":894647,"h":369368082103,"f":1},{"r":56950785,"p":[{"n":"address","p":3076570},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$1","d":894647,"h":373663049399,"f":1},{"r":56950785,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$2","d":894647,"h":377958016695,"f":1},{"r":56950785,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$3","d":894647,"h":382252983991,"f":1},{"r":56950785,"p":[{"n":"reuseSocket","p":262145},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginDisconnect","d":894647,"h":386547951287,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1091255},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","d":894647,"h":390842918583,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1091255},{"n":"errorCode","p":4714970,"f":2},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$1","d":894647,"h":395137885879,"f":1},{"r":56950785,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1091255},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$2","d":894647,"h":399432853175,"f":1},{"r":56950785,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1091255},{"n":"errorCode","p":4714970,"f":2},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$3","d":894647,"h":403727820471,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1091255},{"n":"remoteEP","p":2617818,"f":4},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceiveFrom","d":894647,"h":408022787767,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1091255},{"n":"remoteEP","p":2617818,"f":4},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceiveMessageFrom","d":894647,"h":412317755063,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1091255},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","d":894647,"h":416612722359,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1091255},{"n":"errorCode","p":4714970,"f":2},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$1","d":894647,"h":420907689655,"f":1},{"r":56950785,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1091255},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$2","d":894647,"h":425202656951,"f":1},{"r":56950785,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1091255},{"n":"errorCode","p":4714970,"f":2},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$3","d":894647,"h":429497624247,"f":1},{"r":56950785,"p":[{"n":"fileName","p":1310721},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSendFile","d":894647,"h":433792591543,"f":1},{"r":56950785,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":0},{"n":"postBuffer","p":0},{"n":"flags","p":1877687},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSendFile","o":"@$1","d":894647,"h":438087558839,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1091255},{"n":"remoteEP","p":2617818},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSendTo","d":894647,"h":442382526135,"f":1},{"r":65537,"p":[{"n":"localEP","p":2617818}],"n":"Bind","d":894647,"h":446677493431,"f":1},{"r":65537,"p":[{"n":"e","p":960183}],"n":"CancelConnectAsync","d":894647,"h":450972460727,"f":33},{"r":65537,"n":"Close","d":894647,"h":455267428023,"f":1},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Close","o":"@$1","d":894647,"h":459562395319,"f":1},{"r":65537,"p":[{"n":"remoteEP","p":2617818}],"n":"Connect","d":894647,"h":463857362615,"f":1},{"r":65537,"p":[{"n":"address","p":3076570},{"n":"port","p":655361}],"n":"Connect","o":"@$1","d":894647,"h":468152329911,"f":1},{"r":65537,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"Connect","o":"@$2","d":894647,"h":472447297207,"f":1},{"r":65537,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$3","d":894647,"h":476742264503,"f":1},{"r":133300225,"p":[{"n":"remoteEP","p":2617818}],"n":"ConnectAsync","d":894647,"h":481037231799,"f":1},{"r":136118273,"p":[{"n":"remoteEP","p":2617818},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":894647,"h":485332199095,"f":1},{"r":133300225,"p":[{"n":"address","p":3076570},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":894647,"h":489627166391,"f":1},{"r":136118273,"p":[{"n":"address","p":3076570},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":894647,"h":493922133687,"f":1},{"r":133300225,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$4","d":894647,"h":498217100983,"f":1},{"r":136118273,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":894647,"h":502512068279,"f":1},{"r":262145,"p":[{"n":"e","p":960183}],"n":"ConnectAsync","o":"@$6","d":894647,"h":506807035575,"f":1},{"r":262145,"p":[{"n":"socketType","p":1681079},{"n":"protocolType","p":632503},{"n":"e","p":960183}],"n":"ConnectAsync","o":"@$7","d":894647,"h":511102002871,"f":33},{"r":133300225,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$8","d":894647,"h":515396970167,"f":1},{"r":136118273,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$9","d":894647,"h":519691937463,"f":1},{"r":65537,"p":[{"n":"reuseSocket","p":262145}],"n":"Disconnect","d":894647,"h":523986904759,"f":1},{"r":136118273,"p":[{"n":"reuseSocket","p":262145},{"n":"cancellationToken","p":125960193,"f":65}],"n":"DisconnectAsync","d":894647,"h":528281872055,"f":1},{"r":262145,"p":[{"n":"e","p":960183}],"n":"DisconnectAsync","o":"@$1","d":894647,"h":532576839351,"f":1},{"r":65537,"n":"Dispose","d":894647,"h":536871806647,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":894647,"h":541166773943,"f":132},{"r":1156791,"p":[{"n":"targetProcessId","p":655361}],"n":"DuplicateAndClose","d":894647,"h":545461741239,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":894647,"p":[{"n":"buffer","p":0,"f":2},{"n":"asyncResult","p":56950785}],"n":"EndAccept","d":894647,"h":549756708535,"f":1},{"r":894647,"p":[{"n":"buffer","p":0,"f":2},{"n":"bytesTransferred","p":655361,"f":2},{"n":"asyncResult","p":56950785}],"n":"EndAccept","o":"@$1","d":894647,"h":554051675831,"f":1},{"r":894647,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAccept","o":"@$2","d":894647,"h":558346643127,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndConnect","d":894647,"h":562641610423,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndDisconnect","d":894647,"h":566936577719,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndReceive","d":894647,"h":571231545015,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785},{"n":"errorCode","p":4714970,"f":2}],"n":"EndReceive","o":"@$1","d":894647,"h":575526512311,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785},{"n":"endPoint","p":2617818,"f":4}],"n":"EndReceiveFrom","d":894647,"h":579821479607,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785},{"n":"socketFlags","p":1091255,"f":4},{"n":"endPoint","p":2617818,"f":4},{"n":"ipPacketInformation","p":173751,"f":2}],"n":"EndReceiveMessageFrom","d":894647,"h":584116446903,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndSend","d":894647,"h":588411414199,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785},{"n":"errorCode","p":4714970,"f":2}],"n":"EndSend","o":"@$1","d":894647,"h":592706381495,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndSendFile","d":894647,"h":597001348791,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndSendTo","d":894647,"h":601296316087,"f":1},{"r":655361,"p":[{"n":"optionLevel","p":655361},{"n":"optionName","p":655361},{"n":"optionValue","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetRawSocketOption","d":894647,"h":609886250679,"f":1},{"r":131073,"p":[{"n":"optionLevel","p":1287863},{"n":"optionName","p":1353399}],"n":"GetSocketOption","d":894647,"h":614181217975,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1287863},{"n":"optionName","p":1353399},{"n":"optionValue","p":0}],"n":"GetSocketOption","o":"@$1","d":894647,"h":618476185271,"f":1},{"r":0,"p":[{"n":"optionLevel","p":1287863},{"n":"optionName","p":1353399},{"n":"optionLength","p":655361}],"n":"GetSocketOption","o":"@$2","d":894647,"h":622771152567,"f":1},{"r":655361,"p":[{"n":"ioControlCode","p":655361},{"n":"optionInValue","p":0},{"n":"optionOutValue","p":0}],"n":"IOControl","d":894647,"h":627066119863,"f":1},{"r":655361,"p":[{"n":"ioControlCode","p":108215},{"n":"optionInValue","p":0},{"n":"optionOutValue","p":0}],"n":"IOControl","o":"@$1","d":894647,"h":631361087159,"f":1},{"r":65537,"n":"Listen","d":894647,"h":635656054455,"f":1},{"r":65537,"p":[{"n":"backlog","p":655361}],"n":"Listen","o":"@$1","d":894647,"h":639951021751,"f":1},{"r":262145,"p":[{"n":"microSeconds","p":655361},{"n":"mode","p":763575}],"n":"Poll","d":894647,"h":644245989047,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793},{"n":"mode","p":763575}],"n":"Poll","o":"@$1","d":894647,"h":648540956343,"f":1},{"r":655361,"p":[{"n":"buffer","p":0}],"n":"Receive","d":894647,"h":652835923639,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1091255}],"n":"Receive","o":"@$1","d":894647,"h":657130890935,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1091255},{"n":"errorCode","p":4714970,"f":2}],"n":"Receive","o":"@$2","d":894647,"h":661425858231,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1091255}],"n":"Receive","o":"@$3","d":894647,"h":665720825527,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1091255}],"n":"Receive","o":"@$4","d":894647,"h":670015792823,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"Receive","o":"@$5","d":894647,"h":674310760119,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1091255}],"n":"Receive","o":"@$6","d":894647,"h":678605727415,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1091255},{"n":"errorCode","p":4714970,"f":2}],"n":"Receive","o":"@$7","d":894647,"h":682900694711,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Receive","o":"@$8","d":894647,"h":687195662007,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255}],"n":"Receive","o":"@$9","d":894647,"h":691490629303,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"errorCode","p":4714970,"f":2}],"n":"Receive","o":"@$10","d":894647,"h":695785596599,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h}],"n":"ReceiveAsync","d":894647,"h":700080563895,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255}],"n":"ReceiveAsync","o":"@$1","d":894647,"h":704375531191,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"ReceiveAsync","o":"@$2","d":894647,"h":708670498487,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1091255}],"n":"ReceiveAsync","o":"@$3","d":894647,"h":712965465783,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$4","d":894647,"h":717260433079,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$5","d":894647,"h":721555400375,"f":1},{"r":262145,"p":[{"n":"e","p":960183}],"n":"ReceiveAsync","o":"@$6","d":894647,"h":725850367671,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1091255},{"n":"remoteEP","p":2617818,"f":4}],"n":"ReceiveFrom","d":894647,"h":730145334967,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1091255},{"n":"remoteEP","p":2617818,"f":4}],"n":"ReceiveFrom","o":"@$1","d":894647,"h":734440302263,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"remoteEP","p":2617818,"f":4}],"n":"ReceiveFrom","o":"@$2","d":894647,"h":738735269559,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1091255},{"n":"remoteEP","p":2617818,"f":4}],"n":"ReceiveFrom","o":"@$3","d":894647,"h":743030236855,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2617818,"f":4}],"n":"ReceiveFrom","o":"@$4","d":894647,"h":747325204151,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"remoteEP","p":2617818,"f":4}],"n":"ReceiveFrom","o":"@$5","d":894647,"h":751620171447,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"receivedAddress","p":4387290}],"n":"ReceiveFrom","o":"@$6","d":894647,"h":755915138743,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2617818}],"n":"ReceiveFromAsync","d":894647,"h":760210106039,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"remoteEndPoint","p":2617818}],"n":"ReceiveFromAsync","o":"@$1","d":894647,"h":764505073335,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2617818},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$2","d":894647,"h":768800040631,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"remoteEndPoint","p":2617818},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$3","d":894647,"h":773095007927,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"receivedAddress","p":4387290},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$4","d":894647,"h":777389975223,"f":1},{"r":262145,"p":[{"n":"e","p":960183}],"n":"ReceiveFromAsync","o":"@$5","d":894647,"h":781684942519,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1091255,"f":4},{"n":"remoteEP","p":2617818,"f":4},{"n":"ipPacketInformation","p":173751,"f":2}],"n":"ReceiveMessageFrom","d":894647,"h":785979909815,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255,"f":4},{"n":"remoteEP","p":2617818,"f":4},{"n":"ipPacketInformation","p":173751,"f":2}],"n":"ReceiveMessageFrom","o":"@$1","d":894647,"h":790274877111,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2617818}],"n":"ReceiveMessageFromAsync","d":894647,"h":794569844407,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"remoteEndPoint","p":2617818}],"n":"ReceiveMessageFromAsync","o":"@$1","d":894647,"h":798864811703,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2617818},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveMessageFromAsync","o":"@$2","d":894647,"h":803159778999,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"remoteEndPoint","p":2617818},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveMessageFromAsync","o":"@$3","d":894647,"h":807454746295,"f":1},{"r":262145,"p":[{"n":"e","p":960183}],"n":"ReceiveMessageFromAsync","o":"@$4","d":894647,"h":811749713591,"f":1},{"r":65537,"p":[{"n":"checkRead","p":31916033},{"n":"checkWrite","p":31916033},{"n":"checkError","p":31916033},{"n":"microSeconds","p":655361}],"n":"Select","d":894647,"h":816044680887,"f":33},{"r":65537,"p":[{"n":"checkRead","p":31916033},{"n":"checkWrite","p":31916033},{"n":"checkError","p":31916033},{"n":"timeout","p":140705793}],"n":"Select","o":"@$1","d":894647,"h":820339648183,"f":33},{"r":655361,"p":[{"n":"buffer","p":0}],"n":"Send","d":894647,"h":824634615479,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1091255}],"n":"Send","o":"@$1","d":894647,"h":828929582775,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1091255},{"n":"errorCode","p":4714970,"f":2}],"n":"Send","o":"@$2","d":894647,"h":833224550071,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1091255}],"n":"Send","o":"@$3","d":894647,"h":837519517367,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1091255}],"n":"Send","o":"@$4","d":894647,"h":841814484663,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"Send","o":"@$5","d":894647,"h":846109451959,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1091255}],"n":"Send","o":"@$6","d":894647,"h":850404419255,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1091255},{"n":"errorCode","p":4714970,"f":2}],"n":"Send","o":"@$7","d":894647,"h":854699386551,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Send","o":"@$8","d":894647,"h":858994353847,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255}],"n":"Send","o":"@$9","d":894647,"h":863289321143,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"errorCode","p":4714970,"f":2}],"n":"Send","o":"@$10","d":894647,"h":867584288439,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h}],"n":"SendAsync","d":894647,"h":871879255735,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255}],"n":"SendAsync","o":"@$1","d":894647,"h":876174223031,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"SendAsync","o":"@$2","d":894647,"h":880469190327,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1091255}],"n":"SendAsync","o":"@$3","d":894647,"h":884764157623,"f":1},{"r":262145,"p":[{"n":"e","p":960183}],"n":"SendAsync","o":"@$4","d":894647,"h":889059124919,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$5","d":894647,"h":893354092215,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$6","d":894647,"h":897649059511,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"SendFile","d":894647,"h":901944026807,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":0},{"n":"postBuffer","p":0},{"n":"flags","p":1877687}],"n":"SendFile","o":"@$1","d":894647,"h":906238994103,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"postBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"flags","p":1877687}],"n":"SendFile","o":"@$2","d":894647,"h":910533961399,"f":1},{"r":136118273,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"postBuffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"flags","p":1877687},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendFileAsync","d":894647,"h":914828928695,"f":1},{"r":136118273,"p":[{"n":"fileName","p":1310721},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendFileAsync","o":"@$1","d":894647,"h":919123895991,"f":1},{"r":262145,"p":[{"n":"e","p":960183}],"n":"SendPacketsAsync","d":894647,"h":923418863287,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1091255},{"n":"remoteEP","p":2617818}],"n":"SendTo","d":894647,"h":927713830583,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1091255},{"n":"remoteEP","p":2617818}],"n":"SendTo","o":"@$1","d":894647,"h":932008797879,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"remoteEP","p":2617818}],"n":"SendTo","o":"@$2","d":894647,"h":936303765175,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1091255},{"n":"remoteEP","p":2617818}],"n":"SendTo","o":"@$3","d":894647,"h":940598732471,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2617818}],"n":"SendTo","o":"@$4","d":894647,"h":944893699767,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"remoteEP","p":2617818}],"n":"SendTo","o":"@$5","d":894647,"h":949188667063,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"socketAddress","p":4387290}],"n":"SendTo","o":"@$6","d":894647,"h":953483634359,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2617818}],"n":"SendToAsync","d":894647,"h":957778601655,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"remoteEP","p":2617818}],"n":"SendToAsync","o":"@$1","d":894647,"h":962073568951,"f":1},{"r":262145,"p":[{"n":"e","p":960183}],"n":"SendToAsync","o":"@$2","d":894647,"h":966368536247,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2617818},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$3","d":894647,"h":970663503543,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"remoteEP","p":2617818},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$4","d":894647,"h":974958470839,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1091255},{"n":"socketAddress","p":4387290},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$5","d":894647,"h":979253438135,"f":1},{"r":65537,"p":[{"n":"level","p":239287}],"n":"SetIPProtectionLevel","d":894647,"h":983548405431,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"optionLevel","p":655361},{"n":"optionName","p":655361},{"n":"optionValue","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"SetRawSocketOption","d":894647,"h":987843372727,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1287863},{"n":"optionName","p":1353399},{"n":"optionValue","p":262145}],"n":"SetSocketOption","d":894647,"h":992138340023,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1287863},{"n":"optionName","p":1353399},{"n":"optionValue","p":0}],"n":"SetSocketOption","o":"@$1","d":894647,"h":996433307319,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1287863},{"n":"optionName","p":1353399},{"n":"optionValue","p":655361}],"n":"SetSocketOption","o":"@$2","d":894647,"h":1000728274615,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1287863},{"n":"optionName","p":1353399},{"n":"optionValue","p":131073}],"n":"SetSocketOption","o":"@$3","d":894647,"h":1005023241911,"f":1},{"r":65537,"p":[{"n":"how","p":1550007}],"n":"Shutdown","d":894647,"h":1009318209207,"f":1}],"c":[{"p":[{"n":"addressFamily","p":4518362},{"n":"socketType","p":1681079},{"n":"protocolType","p":632503}],"n":".ctor","o":"$ctor$1","d":894647,"h":4295861943,"f":1},{"p":[{"n":"handle","p":698039}],"n":".ctor","o":"$ctor$2","d":894647,"h":8590829239,"f":1},{"p":[{"n":"socketInformation","p":1156791}],"n":".ctor","o":"$ctor$3","d":894647,"h":12885796535,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":[{"n":"socketType","p":1681079},{"n":"protocolType","p":632503}],"n":".ctor","o":"$ctor$4","d":894647,"h":17180763831,"f":1}],"i":[57475073],"h":894647}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.Socket`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.TcpClient", ($self) => class TcpClient extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ hostname, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Active(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Client()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ set Client(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Connected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ get LingerState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ set LingerState(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get NoDelay()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set NoDelay(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$1(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$2(/*string*/ host, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close()
            {
            }
            /*void */ Connect(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
            }
            /*void */ Connect$1(/*System.Net.IPAddress[]*/ ipAddresses, /*int*/ port)
            {
            }
            /*void */ Connect$2(/*System.Net.IPEndPoint*/ remoteEP)
            {
            }
            /*void */ Connect$3(/*string*/ hostname, /*int*/ port)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Net.IPEndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*System.Net.IPEndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$6(/*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$7(/*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ EndConnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*System.Net.Sockets.NetworkStream */ GetStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1746615;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25771550391,"f":4},"s":{"r":0,"d":0,"h":30066517687,"f":4},"n":"Active","d":1746615,"h":21476583095,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":38656452279,"f":1},"n":"Available","d":1746615,"h":34361484983,"f":1},{"p":894647,"g":{"r":0,"d":0,"h":47246386871,"f":1},"s":{"r":0,"d":0,"h":51541354167,"f":1},"n":"Client","d":1746615,"h":42951419575,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131288759,"f":1},"n":"Connected","d":1746615,"h":55836321463,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721223351,"f":1},"s":{"r":0,"d":0,"h":73016190647,"f":1},"n":"ExclusiveAddressUse","d":1746615,"h":64426256055,"f":1},{"p":370359,"g":{"r":0,"d":0,"h":81606125239,"f":1},"s":{"r":0,"d":0,"h":85901092535,"f":1},"n":"LingerState","d":1746615,"h":77311157943,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94491027127,"f":1},"s":{"r":0,"d":0,"h":98785994423,"f":1},"n":"NoDelay","d":1746615,"h":90196059831,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":107375929015,"f":1},"s":{"r":0,"d":0,"h":111670896311,"f":1},"n":"ReceiveBufferSize","d":1746615,"h":103080961719,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":120260830903,"f":1},"s":{"r":0,"d":0,"h":124555798199,"f":1},"n":"ReceiveTimeout","d":1746615,"h":115965863607,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":133145732791,"f":1},"s":{"r":0,"d":0,"h":137440700087,"f":1},"n":"SendBufferSize","d":1746615,"h":128850765495,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":146030634679,"f":1},"s":{"r":0,"d":0,"h":150325601975,"f":1},"n":"SendTimeout","d":1746615,"h":141735667383,"f":1}],"m":[{"r":56950785,"p":[{"n":"address","p":3076570},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","d":1746615,"h":154620569271,"f":1},{"r":56950785,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$1","d":1746615,"h":158915536567,"f":1},{"r":56950785,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$2","d":1746615,"h":163210503863,"f":1},{"r":65537,"n":"Close","d":1746615,"h":167505471159,"f":1},{"r":65537,"p":[{"n":"address","p":3076570},{"n":"port","p":655361}],"n":"Connect","d":1746615,"h":171800438455,"f":1},{"r":65537,"p":[{"n":"ipAddresses","p":0},{"n":"port","p":655361}],"n":"Connect","o":"@$1","d":1746615,"h":176095405751,"f":1},{"r":65537,"p":[{"n":"remoteEP","p":3338714}],"n":"Connect","o":"@$2","d":1746615,"h":180390373047,"f":1},{"r":65537,"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$3","d":1746615,"h":184685340343,"f":1},{"r":133300225,"p":[{"n":"address","p":3076570},{"n":"port","p":655361}],"n":"ConnectAsync","d":1746615,"h":188980307639,"f":1},{"r":136118273,"p":[{"n":"address","p":3076570},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":1746615,"h":193275274935,"f":1},{"r":133300225,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":1746615,"h":197570242231,"f":1},{"r":136118273,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":1746615,"h":201865209527,"f":1},{"r":133300225,"p":[{"n":"remoteEP","p":3338714}],"n":"ConnectAsync","o":"@$4","d":1746615,"h":206160176823,"f":1},{"r":136118273,"p":[{"n":"remoteEP","p":3338714},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":1746615,"h":210455144119,"f":1},{"r":133300225,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$6","d":1746615,"h":214750111415,"f":1},{"r":136118273,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$7","d":1746615,"h":219045078711,"f":1},{"r":65537,"n":"Dispose","d":1746615,"h":223340046007,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1746615,"h":227635013303,"f":132},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndConnect","d":1746615,"h":231929980599,"f":1},{"r":501431,"n":"GetStream","d":1746615,"h":240519915191,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1746615,"h":4296713911,"f":1},{"p":[{"n":"localEP","p":3338714}],"n":".ctor","o":"$ctor$2","d":1746615,"h":8591681207,"f":1},{"p":[{"n":"family","p":4518362}],"n":".ctor","o":"$ctor$3","d":1746615,"h":12886648503,"f":1},{"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$4","d":1746615,"h":17181615799,"f":1}],"i":[57475073],"h":1746615}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.TcpClient`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.TcpListener", ($self) => class TcpListener extends $.$spc.System.Object
        {
            $ctor$1(/*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ localaddr, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ get LocalEndpoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Server()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ AcceptSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptSocketAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptSocketAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TcpClient */ AcceptTcpClient()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.TcpClient> */ AcceptTcpClientAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.TcpClient> */ AcceptTcpClientAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AllowNatTraversal(/*bool*/ allowed)
            {
            }
            /*System.IAsyncResult */ BeginAcceptSocket(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAcceptTcpClient(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Sockets.TcpListener */ Create(/*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*System.Net.Sockets.Socket */ EndAcceptSocket(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TcpClient */ EndAcceptTcpClient(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Pending()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Start()
            {
            }
            /*void */ Start$1(/*int*/ backlog)
            {
            }
            /*void */ Stop()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1812151;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476648631,"f":4},"n":"Active","d":1812151,"h":17181681335,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":30066583223,"f":1},"s":{"r":0,"d":0,"h":34361550519,"f":1},"n":"ExclusiveAddressUse","d":1812151,"h":25771615927,"f":1},{"p":2617818,"g":{"r":0,"d":0,"h":42951485111,"f":1},"n":"LocalEndpoint","d":1812151,"h":38656517815,"f":1},{"p":894647,"g":{"r":0,"d":0,"h":51541419703,"f":1},"n":"Server","d":1812151,"h":47246452407,"f":1}],"m":[{"r":894647,"n":"AcceptSocket","d":1812151,"h":55836386999,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"n":"AcceptSocketAsync","d":1812151,"h":60131354295,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptSocketAsync","o":"@$1","d":1812151,"h":64426321591,"f":1},{"r":1746615,"n":"AcceptTcpClient","d":1812151,"h":68721288887,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.TcpClient).$h,"n":"AcceptTcpClientAsync","d":1812151,"h":73016256183,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.TcpClient).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptTcpClientAsync","o":"@$1","d":1812151,"h":77311223479,"f":1},{"r":65537,"p":[{"n":"allowed","p":262145}],"n":"AllowNatTraversal","d":1812151,"h":81606190775,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAcceptSocket","d":1812151,"h":85901158071,"f":1},{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAcceptTcpClient","d":1812151,"h":90196125367,"f":1},{"r":1812151,"p":[{"n":"port","p":655361}],"n":"Create","d":1812151,"h":94491092663,"f":33},{"r":65537,"n":"Dispose","d":1812151,"h":98786059959,"f":1},{"r":894647,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAcceptSocket","d":1812151,"h":103081027255,"f":1},{"r":1746615,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAcceptTcpClient","d":1812151,"h":107375994551,"f":1},{"r":262145,"n":"Pending","d":1812151,"h":111670961847,"f":1},{"r":65537,"n":"Start","d":1812151,"h":115965929143,"f":1},{"r":65537,"p":[{"n":"backlog","p":655361}],"n":"Start","o":"@$1","d":1812151,"h":120260896439,"f":1},{"r":65537,"n":"Stop","d":1812151,"h":124555863735,"f":1}],"c":[{"p":[{"n":"port","p":655361}],"n":".ctor","o":"$ctor$1","d":1812151,"h":4296779447,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor has been deprecated. Use TcpListener(IPAddress localaddr, int port) instead.","t":1310721}]}]},{"p":[{"n":"localaddr","p":3076570},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":1812151,"h":8591746743,"f":1},{"p":[{"n":"localEP","p":3338714}],"n":".ctor","o":"$ctor$3","d":1812151,"h":12886714039,"f":1}],"i":[57475073],"h":1812151}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.TcpListener`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.UdpClient", ($self) => class UdpClient extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*int*/ port, /*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$6(/*string*/ hostname, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Active(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Client()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ set Client(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DontFragment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DontFragment(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableBroadcast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableBroadcast(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get MulticastLoopback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MulticastLoopback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ get Ttl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ set Ttl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AllowNatTraversal(/*bool*/ allowed)
            {
            }
            /*System.IAsyncResult */ BeginReceive(/*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend(/*byte[]*/ datagram, /*int*/ bytes, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$1(/*byte[]*/ datagram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$2(/*byte[]*/ datagram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close()
            {
            }
            /*void */ Connect(/*System.Net.IPAddress*/ addr, /*int*/ port)
            {
            }
            /*void */ Connect$1(/*System.Net.IPEndPoint*/ endPoint)
            {
            }
            /*void */ Connect$2(/*string*/ hostname, /*int*/ port)
            {
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ DropMulticastGroup(/*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ DropMulticastGroup$1(/*System.Net.IPAddress*/ multicastAddr, /*int*/ ifindex)
            {
            }
            /*byte[] */ EndReceive(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.IPEndPoint?*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ JoinMulticastGroup(/*int*/ ifindex, /*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ JoinMulticastGroup$1(/*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ JoinMulticastGroup$2(/*System.Net.IPAddress*/ multicastAddr, /*int*/ timeToLive)
            {
            }
            /*void */ JoinMulticastGroup$3(/*System.Net.IPAddress*/ multicastAddr, /*System.Net.IPAddress*/ localAddress)
            {
            }
            /*byte[] */ Receive(/*ref System.Net.IPEndPoint?*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.UdpReceiveResult> */ ReceiveAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.UdpReceiveResult> */ ReceiveAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send(/*byte[]*/ dgram, /*int*/ bytes)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$1(/*byte[]*/ dgram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$2(/*byte[]*/ dgram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$3(/*System.ReadOnlySpan<byte>*/ datagram)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$4(/*System.ReadOnlySpan<byte>*/ datagram, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$5(/*System.ReadOnlySpan<byte>*/ datagram, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync(/*byte[]*/ datagram, /*int*/ bytes)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*byte[]*/ datagram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$2(/*byte[]*/ datagram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$3(/*System.ReadOnlyMemory<byte>*/ datagram, /*System.Net.IPEndPoint?*/ endPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$4(/*System.ReadOnlyMemory<byte>*/ datagram, /*string?*/ hostname, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$5(/*System.ReadOnlyMemory<byte>*/ datagram, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1943223;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34361681591,"f":4},"s":{"r":0,"d":0,"h":38656648887,"f":4},"n":"Active","d":1943223,"h":30066714295,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":47246583479,"f":1},"n":"Available","d":1943223,"h":42951616183,"f":1},{"p":894647,"g":{"r":0,"d":0,"h":55836518071,"f":1},"s":{"r":0,"d":0,"h":60131485367,"f":1},"n":"Client","d":1943223,"h":51541550775,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721419959,"f":1},"s":{"r":0,"d":0,"h":73016387255,"f":1},"n":"DontFragment","d":1943223,"h":64426452663,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81606321847,"f":1},"s":{"r":0,"d":0,"h":85901289143,"f":1},"n":"EnableBroadcast","d":1943223,"h":77311354551,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94491223735,"f":1},"s":{"r":0,"d":0,"h":98786191031,"f":1},"n":"ExclusiveAddressUse","d":1943223,"h":90196256439,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":107376125623,"f":1},"s":{"r":0,"d":0,"h":111671092919,"f":1},"n":"MulticastLoopback","d":1943223,"h":103081158327,"f":1},{"p":524289,"g":{"r":0,"d":0,"h":120261027511,"f":1},"s":{"r":0,"d":0,"h":124555994807,"f":1},"n":"Ttl","d":1943223,"h":115966060215,"f":1}],"m":[{"r":65537,"p":[{"n":"allowed","p":262145}],"n":"AllowNatTraversal","d":1943223,"h":128850962103,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":56950785,"p":[{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","d":1943223,"h":133145929399,"f":1},{"r":56950785,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","d":1943223,"h":137440896695,"f":1},{"r":56950785,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3338714},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$1","d":1943223,"h":141735863991,"f":1},{"r":56950785,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$2","d":1943223,"h":146030831287,"f":1},{"r":65537,"n":"Close","d":1943223,"h":150325798583,"f":1},{"r":65537,"p":[{"n":"addr","p":3076570},{"n":"port","p":655361}],"n":"Connect","d":1943223,"h":154620765879,"f":1},{"r":65537,"p":[{"n":"endPoint","p":3338714}],"n":"Connect","o":"@$1","d":1943223,"h":158915733175,"f":1},{"r":65537,"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$2","d":1943223,"h":163210700471,"f":1},{"r":65537,"n":"Dispose","d":1943223,"h":167505667767,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1943223,"h":171800635063,"f":132},{"r":65537,"p":[{"n":"multicastAddr","p":3076570}],"n":"DropMulticastGroup","d":1943223,"h":176095602359,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3076570},{"n":"ifindex","p":655361}],"n":"DropMulticastGroup","o":"@$1","d":1943223,"h":180390569655,"f":1},{"r":0,"p":[{"n":"asyncResult","p":56950785},{"n":"remoteEP","p":3338714,"f":4}],"n":"EndReceive","d":1943223,"h":184685536951,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndSend","d":1943223,"h":188980504247,"f":1},{"r":65537,"p":[{"n":"ifindex","p":655361},{"n":"multicastAddr","p":3076570}],"n":"JoinMulticastGroup","d":1943223,"h":193275471543,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3076570}],"n":"JoinMulticastGroup","o":"@$1","d":1943223,"h":197570438839,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3076570},{"n":"timeToLive","p":655361}],"n":"JoinMulticastGroup","o":"@$2","d":1943223,"h":201865406135,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3076570},{"n":"localAddress","p":3076570}],"n":"JoinMulticastGroup","o":"@$3","d":1943223,"h":206160373431,"f":1},{"r":0,"p":[{"n":"remoteEP","p":3338714,"f":4}],"n":"Receive","d":1943223,"h":210455340727,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h,"n":"ReceiveAsync","d":1943223,"h":214750308023,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReceiveAsync","o":"@$1","d":1943223,"h":219045275319,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361}],"n":"Send","d":1943223,"h":223340242615,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3338714}],"n":"Send","o":"@$1","d":1943223,"h":227635209911,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Send","o":"@$2","d":1943223,"h":231930177207,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Send","o":"@$3","d":1943223,"h":236225144503,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"endPoint","p":3338714}],"n":"Send","o":"@$4","d":1943223,"h":240520111799,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Send","o":"@$5","d":1943223,"h":244815079095,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361}],"n":"SendAsync","d":1943223,"h":249110046391,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3338714}],"n":"SendAsync","o":"@$1","d":1943223,"h":253405013687,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"SendAsync","o":"@$2","d":1943223,"h":257699980983,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"endPoint","p":3338714},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$3","d":1943223,"h":261994948279,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"hostname","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$4","d":1943223,"h":266289915575,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$5","d":1943223,"h":270584882871,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1943223,"h":4296910519,"f":1},{"p":[{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":1943223,"h":8591877815,"f":1},{"p":[{"n":"port","p":655361},{"n":"family","p":4518362}],"n":".ctor","o":"$ctor$3","d":1943223,"h":12886845111,"f":1},{"p":[{"n":"localEP","p":3338714}],"n":".ctor","o":"$ctor$4","d":1943223,"h":17181812407,"f":1},{"p":[{"n":"family","p":4518362}],"n":".ctor","o":"$ctor$5","d":1943223,"h":21476779703,"f":1},{"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$6","d":1943223,"h":25771746999,"f":1}],"i":[57475073],"h":1943223}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.UdpClient`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketInformation", ($self) => class SocketInformation extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.Sockets.SocketInformationOptions */ get Options()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketInformationOptions */ set Options(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ get ProtocolInformation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ set ProtocolInformation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 1156791;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1222327,"g":{"r":0,"d":0,"h":17181025975,"f":1},"s":{"r":0,"d":0,"h":21475993271,"f":1},"n":"Options","d":1156791,"h":12886058679,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30065927863,"f":1},"s":{"r":0,"d":0,"h":34360895159,"f":1},"n":"ProtocolInformation","d":1156791,"h":25770960567,"f":1}],"l":[{"t":131073,"n":"_dummy","d":1156791,"h":4296124087,"f":2},{"t":655361,"n":"_dummyPrimitive","d":1156791,"h":8591091383,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1156791,"h":38655862455,"f":1}],"h":1156791}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketInformation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketReceiveFromResult", ($self) => class SocketReceiveFromResult extends $.$spc.System.ValueType
        {
            /*int*/  get ReceivedBytes() { return this.$getField(0, 4); }
            /*int*/  set ReceivedBytes(value) { this.$setField(0, 4, value); }
            /*System.Net.EndPoint*/  get RemoteEndPoint() { return this.$getField(4, 4); }
            /*System.Net.EndPoint*/  set RemoteEndPoint(value) { this.$setField(4, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ReceivedBytes = this.ReceivedBytes;
                copy.RemoteEndPoint = this.RemoteEndPoint;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ReceivedBytes = 0;
                this.RemoteEndPoint = null;
            }
            static $h = 1418935;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"ReceivedBytes","d":1418935,"h":4296386231,"f":1},{"t":2617818,"n":"RemoteEndPoint","d":1418935,"h":8591353527,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1418935,"h":12886320823,"f":1}],"h":1418935}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketReceiveFromResult`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketReceiveMessageFromResult", ($self) => class SocketReceiveMessageFromResult extends $.$spc.System.ValueType
        {
            /*System.Net.Sockets.IPPacketInformation*/  get PacketInformation() { return this.$getField(0, 8); }
            /*System.Net.Sockets.IPPacketInformation*/  set PacketInformation(value) { this.$setField(0, 8, value); }
            /*int*/  get ReceivedBytes() { return this.$getField(8, 4); }
            /*int*/  set ReceivedBytes(value) { this.$setField(8, 4, value); }
            /*System.Net.EndPoint*/  get RemoteEndPoint() { return this.$getField(12, 4); }
            /*System.Net.EndPoint*/  set RemoteEndPoint(value) { this.$setField(12, 4, value); }
            /*System.Net.Sockets.SocketFlags*/  get SocketFlags() { return this.$getField(16, 4); }
            /*System.Net.Sockets.SocketFlags*/  set SocketFlags(value) { this.$setField(16, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.PacketInformation = this.PacketInformation.Clone();
                copy.ReceivedBytes = this.ReceivedBytes;
                copy.RemoteEndPoint = this.RemoteEndPoint;
                copy.SocketFlags = this.SocketFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.PacketInformation = $.$default($.$sns.System.Net.Sockets.IPPacketInformation);
                this.ReceivedBytes = 0;
                this.RemoteEndPoint = null;
                this.SocketFlags = 0;
            }
            static $h = 1484471;
            static $z = 20;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":173751,"n":"PacketInformation","d":1484471,"h":4296451767,"f":1},{"t":655361,"n":"ReceivedBytes","d":1484471,"h":8591419063,"f":1},{"t":2617818,"n":"RemoteEndPoint","d":1484471,"h":12886386359,"f":1},{"t":1091255,"n":"SocketFlags","d":1484471,"h":17181353655,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1484471,"h":21476320951,"f":1}],"h":1484471}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketReceiveMessageFromResult`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.UnixDomainSocketEndPoint", ($self) => class UnixDomainSocketEndPoint extends $.$snp.System.Net.EndPoint
        {
            $ctor$2(/*string*/ path)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Sockets.AddressFamily */ get AddressFamily()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ Create(/*System.Net.SocketAddress*/ socketAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.GetHashCode.apply(this, arguments); }
            /*System.Net.SocketAddress */ Serialize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.ToString.apply(this, arguments); }
            static $h = 2074295;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2617818,"p":[{"p":4518362,"g":{"r":0,"d":0,"h":12886976183,"f":32769},"n":"AddressFamily","d":2074295,"h":8592008887,"f":32769}],"m":[{"r":2617818,"p":[{"n":"socketAddress","p":4387290}],"n":"Create","d":2074295,"h":17181943479,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2074295,"h":21476910775,"f":32769},{"r":655361,"n":"GetHashCode","d":2074295,"h":25771878071,"f":32769},{"r":4387290,"n":"Serialize","d":2074295,"h":30066845367,"f":32769},{"r":1310721,"n":"ToString","d":2074295,"h":34361812663,"f":32769}],"c":[{"p":[{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$2","d":2074295,"h":4297041591,"f":1}],"h":2074295}; }
            static get $b() { return $.$snp.System.Net.EndPoint; }
            static get $fullName() { return `System.Net.Sockets.UnixDomainSocketEndPoint`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IPPacketInformation", ($self) => class IPPacketInformation extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.IPAddress */ get Address()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Interface()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Sockets.IPPacketInformation*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.IPPacketInformation.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.IPPacketInformation.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Sockets.IPPacketInformation*/ packetInformation1, /*System.Net.Sockets.IPPacketInformation*/ packetInformation2)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Sockets.IPPacketInformation*/ packetInformation1, /*System.Net.Sockets.IPPacketInformation*/ packetInformation2)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IEquatable<System.Net.Sockets.IPPacketInformation>.Equals(System.Net.Sockets.IPPacketInformation)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 173751;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":3076570,"g":{"r":0,"d":0,"h":17180042935,"f":1},"n":"Address","d":173751,"h":12885075639,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25769977527,"f":1},"n":"Interface","d":173751,"h":21475010231,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":173751}],"n":"Equals","o":"@$2","d":173751,"h":30064944823,"f":1},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":173751,"h":34359912119,"f":32769},{"r":655361,"n":"GetHashCode","d":173751,"h":38654879415,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":173751,"h":4295141047,"f":2},{"t":655361,"n":"_dummyPrimitive","d":173751,"h":8590108343,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":173751,"h":51539781303,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.IPPacketInformation).$h],"h":173751}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.IPPacketInformation) ]; }
            static get $fullName() { return `System.Net.Sockets.IPPacketInformation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.UdpReceiveResult", ($self) => class UdpReceiveResult extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$2(/*byte[]*/ buffer, /*System.Net.IPEndPoint*/ remoteEndPoint)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*byte[] */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Sockets.UdpReceiveResult*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.UdpReceiveResult.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.UdpReceiveResult.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Sockets.UdpReceiveResult*/ left, /*System.Net.Sockets.UdpReceiveResult*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Sockets.UdpReceiveResult*/ left, /*System.Net.Sockets.UdpReceiveResult*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IEquatable<System.Net.Sockets.UdpReceiveResult>.Equals(System.Net.Sockets.UdpReceiveResult)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 2008759;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":0,"g":{"r":0,"d":0,"h":21476845239,"f":1},"n":"Buffer","d":2008759,"h":17181877943,"f":1},{"p":3338714,"g":{"r":0,"d":0,"h":30066779831,"f":1},"n":"RemoteEndPoint","d":2008759,"h":25771812535,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":2008759}],"n":"Equals","o":"@$2","d":2008759,"h":34361747127,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2008759,"h":38656714423,"f":32769},{"r":655361,"n":"GetHashCode","d":2008759,"h":42951681719,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":2008759,"h":4296976055,"f":2},{"t":655361,"n":"_dummyPrimitive","d":2008759,"h":8591943351,"f":2}],"c":[{"p":[{"n":"buffer","p":0},{"n":"remoteEndPoint","p":3338714}],"n":".ctor","o":"$ctor$2","d":2008759,"h":12886910647,"f":1},{"n":".ctor","o":"$ctor$3","d":2008759,"h":55836583607,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h],"h":2008759}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.UdpReceiveResult) ]; }
            static get $fullName() { return `System.Net.Sockets.UdpReceiveResult`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.NetworkStream", ($self) => class NetworkStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.Net.Sockets.Socket*/ socket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.Sockets.Socket*/ socket, /*bool*/ ownsSocket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*System.Net.Sockets.Socket*/ socket, /*System.IO.FileAccess*/ access)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$6(/*System.Net.Sockets.Socket*/ socket, /*System.IO.FileAccess*/ access, /*bool*/ ownsSocket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DataAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Readable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Readable(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Socket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Writeable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Writeable(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close$1(/*int*/ timeout)
            {
            }
            /*void */ Close$2(/*System.TimeSpan*/ timeout)
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 501431;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770305207,"f":32769},"n":"CanRead","d":501431,"h":21475337911,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360239799,"f":32769},"n":"CanSeek","d":501431,"h":30065272503,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950174391,"f":32769},"n":"CanTimeout","d":501431,"h":38655207095,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51540108983,"f":32769},"n":"CanWrite","d":501431,"h":47245141687,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60130043575,"f":129},"n":"DataAvailable","d":501431,"h":55835076279,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":68719978167,"f":32769},"n":"Length","d":501431,"h":64425010871,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":77309912759,"f":32769},"s":{"r":0,"d":0,"h":81604880055,"f":32769},"n":"Position","d":501431,"h":73014945463,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":90194814647,"f":4},"s":{"r":0,"d":0,"h":94489781943,"f":4},"n":"Readable","d":501431,"h":85899847351,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":103079716535,"f":32769},"s":{"r":0,"d":0,"h":107374683831,"f":32769},"n":"ReadTimeout","d":501431,"h":98784749239,"f":32769},{"p":894647,"g":{"r":0,"d":0,"h":115964618423,"f":1},"n":"Socket","d":501431,"h":111669651127,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554553015,"f":4},"s":{"r":0,"d":0,"h":128849520311,"f":4},"n":"Writeable","d":501431,"h":120259585719,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":137439454903,"f":32769},"s":{"r":0,"d":0,"h":141734422199,"f":32769},"n":"WriteTimeout","d":501431,"h":133144487607,"f":32769}],"m":[{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginRead","d":501431,"h":146029389495,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWrite","d":501431,"h":150324356791,"f":32769},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Close","o":"@$1","d":501431,"h":154619324087,"f":1},{"r":65537,"p":[{"n":"timeout","p":140705793}],"n":"Close","o":"@$2","d":501431,"h":158914291383,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":501431,"h":163209258679,"f":32772},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":501431,"h":167504225975,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":501431,"h":171799193271,"f":32769},{"r":65537,"n":"Flush","d":501431,"h":180389127863,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":501431,"h":184684095159,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":501431,"h":188979062455,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":501431,"h":193274029751,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":501431,"h":197568997047,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":501431,"h":201863964343,"f":32769},{"r":655361,"n":"ReadByte","d":501431,"h":206158931639,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":501431,"h":210453898935,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":501431,"h":214748866231,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":501431,"h":219043833527,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":501431,"h":223338800823,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":501431,"h":227633768119,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":501431,"h":231928735415,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":501431,"h":236223702711,"f":32769}],"c":[{"p":[{"n":"socket","p":894647}],"n":".ctor","o":"$ctor$3","d":501431,"h":4295468727,"f":1},{"p":[{"n":"socket","p":894647},{"n":"ownsSocket","p":262145}],"n":".ctor","o":"$ctor$4","d":501431,"h":8590436023,"f":1},{"p":[{"n":"socket","p":894647},{"n":"access","p":59703297}],"n":".ctor","o":"$ctor$5","d":501431,"h":12885403319,"f":1},{"p":[{"n":"socket","p":894647},{"n":"access","p":59703297},{"n":"ownsSocket","p":262145}],"n":".ctor","o":"$ctor$6","d":501431,"h":17180370615,"f":1}],"i":[57475073,56885249],"h":501431}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.NetworkStream`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IOControlCode", ($self) => class IOControlCode extends $.$spc.System.Enum
        {
            static EnableCircularQueuing = 671088642n;
            static Flush = 671088644n;
            static AddressListChange = 671088663n;
            static DataToRead = 1074030207n;
            static OobDataRead = 1074033415n;
            static GetBroadcastAddress = 1207959557n;
            static AddressListQuery = 1207959574n;
            static QueryTargetPnpHandle = 1207959576n;
            static AsyncIO = 2147772029n;
            static NonBlockingIO = 2147772030n;
            static AssociateHandle = 2281701377n;
            static MultipointLoopback = 2281701385n;
            static MulticastScope = 2281701386n;
            static SetQos = 2281701387n;
            static SetGroupQos = 2281701388n;
            static RoutingInterfaceChange = 2281701397n;
            static NamespaceChange = 2281701401n;
            static ReceiveAll = 2550136833n;
            static ReceiveAllMulticast = 2550136834n;
            static ReceiveAllIgmpMulticast = 2550136835n;
            static KeepAliveValues = 2550136836n;
            static AbsorbRouterAlert = 2550136837n;
            static UnicastInterface = 2550136838n;
            static LimitBroadcasts = 2550136839n;
            static BindToInterface = 2550136840n;
            static MulticastInterface = 2550136841n;
            static AddMulticastGroupOnInterface = 2550136842n;
            static DeleteMulticastGroupFromInterface = 2550136843n;
            static GetExtensionFunctionPointer = 3355443206n;
            static GetQos = 3355443207n;
            static GetGroupQos = 3355443208n;
            static TranslateHandle = 3355443213n;
            static RoutingInterfaceQuery = 3355443220n;
            static AddressListSort = 3355443225n;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "EnableCircularQueuing": 671088642n,
                    "Flush": 671088644n,
                    "AddressListChange": 671088663n,
                    "DataToRead": 1074030207n,
                    "OobDataRead": 1074033415n,
                    "GetBroadcastAddress": 1207959557n,
                    "AddressListQuery": 1207959574n,
                    "QueryTargetPnpHandle": 1207959576n,
                    "AsyncIO": 2147772029n,
                    "NonBlockingIO": 2147772030n,
                    "AssociateHandle": 2281701377n,
                    "MultipointLoopback": 2281701385n,
                    "MulticastScope": 2281701386n,
                    "SetQos": 2281701387n,
                    "SetGroupQos": 2281701388n,
                    "RoutingInterfaceChange": 2281701397n,
                    "NamespaceChange": 2281701401n,
                    "ReceiveAll": 2550136833n,
                    "ReceiveAllMulticast": 2550136834n,
                    "ReceiveAllIgmpMulticast": 2550136835n,
                    "KeepAliveValues": 2550136836n,
                    "AbsorbRouterAlert": 2550136837n,
                    "UnicastInterface": 2550136838n,
                    "LimitBroadcasts": 2550136839n,
                    "BindToInterface": 2550136840n,
                    "MulticastInterface": 2550136841n,
                    "AddMulticastGroupOnInterface": 2550136842n,
                    "DeleteMulticastGroupFromInterface": 2550136843n,
                    "GetExtensionFunctionPointer": 3355443206n,
                    "GetQos": 3355443207n,
                    "GetGroupQos": 3355443208n,
                    "TranslateHandle": 3355443213n,
                    "RoutingInterfaceQuery": 3355443220n,
                    "AddressListSort": 3355443225n
                };
            }
            static $h = 108215;
            static $z = 8;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int64; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":917505,"l":[{"t":108215,"n":"EnableCircularQueuing","d":108215,"h":4295075511,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"Flush","d":108215,"h":8590042807,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"AddressListChange","d":108215,"h":12885010103,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"DataToRead","d":108215,"h":17179977399,"f":33},{"t":108215,"n":"OobDataRead","d":108215,"h":21474944695,"f":33},{"t":108215,"n":"GetBroadcastAddress","d":108215,"h":25769911991,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"AddressListQuery","d":108215,"h":30064879287,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"QueryTargetPnpHandle","d":108215,"h":34359846583,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"AsyncIO","d":108215,"h":38654813879,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"NonBlockingIO","d":108215,"h":42949781175,"f":33},{"t":108215,"n":"AssociateHandle","d":108215,"h":47244748471,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"MultipointLoopback","d":108215,"h":51539715767,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"MulticastScope","d":108215,"h":55834683063,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"SetQos","d":108215,"h":60129650359,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"SetGroupQos","d":108215,"h":64424617655,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"RoutingInterfaceChange","d":108215,"h":68719584951,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"NamespaceChange","d":108215,"h":73014552247,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"ReceiveAll","d":108215,"h":77309519543,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"ReceiveAllMulticast","d":108215,"h":81604486839,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"ReceiveAllIgmpMulticast","d":108215,"h":85899454135,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"KeepAliveValues","d":108215,"h":90194421431,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"AbsorbRouterAlert","d":108215,"h":94489388727,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"UnicastInterface","d":108215,"h":98784356023,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"LimitBroadcasts","d":108215,"h":103079323319,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"BindToInterface","d":108215,"h":107374290615,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"MulticastInterface","d":108215,"h":111669257911,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"AddMulticastGroupOnInterface","d":108215,"h":115964225207,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"DeleteMulticastGroupFromInterface","d":108215,"h":120259192503,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"GetExtensionFunctionPointer","d":108215,"h":124554159799,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"GetQos","d":108215,"h":128849127095,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"GetGroupQos","d":108215,"h":133144094391,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"TranslateHandle","d":108215,"h":137439061687,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"RoutingInterfaceQuery","d":108215,"h":141734028983,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":108215,"n":"AddressListSort","d":108215,"h":146028996279,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":108215,"h":150323963575,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":108215}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.IOControlCode`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IPProtectionLevel", ($self) => class IPProtectionLevel extends $.$spc.System.Enum
        {
            static Unspecified = -1;
            static Unrestricted = 10;
            static EdgeRestricted = 20;
            static Restricted = 30;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unspecified": -1n,
                    "Unrestricted": 10n,
                    "EdgeRestricted": 20n,
                    "Restricted": 30n
                };
            }
            static $h = 239287;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":239287,"n":"Unspecified","d":239287,"h":4295206583,"f":33},{"t":239287,"n":"Unrestricted","d":239287,"h":8590173879,"f":33},{"t":239287,"n":"EdgeRestricted","d":239287,"h":12885141175,"f":33},{"t":239287,"n":"Restricted","d":239287,"h":17180108471,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":239287,"h":21475075767,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":239287}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.IPProtectionLevel`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.ProtocolFamily", ($self) => class ProtocolFamily extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static Unspecified = 0;
            static Unix = 1;
            static InterNetwork = 2;
            static ImpLink = 3;
            static Pup = 4;
            static Chaos = 5;
            static Ipx = 6;
            static NS = 6;
            static Iso = 7;
            static Osi = 7;
            static Ecma = 8;
            static DataKit = 9;
            static Ccitt = 10;
            static Sna = 11;
            static DecNet = 12;
            static DataLink = 13;
            static Lat = 14;
            static HyperChannel = 15;
            static AppleTalk = 16;
            static NetBios = 17;
            static VoiceView = 18;
            static FireFox = 19;
            static Banyan = 21;
            static Atm = 22;
            static InterNetworkV6 = 23;
            static Cluster = 24;
            static Ieee12844 = 25;
            static Irda = 26;
            static NetworkDesigners = 28;
            static Max = 29;
            static Packet = 65536;
            static ControllerAreaNetwork = 65537;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Unspecified": 0n,
                    "Unix": 1n,
                    "InterNetwork": 2n,
                    "ImpLink": 3n,
                    "Pup": 4n,
                    "Chaos": 5n,
                    "Ipx": 6n,
                    "NS": 6n,
                    "Iso": 7n,
                    "Osi": 7n,
                    "Ecma": 8n,
                    "DataKit": 9n,
                    "Ccitt": 10n,
                    "Sna": 11n,
                    "DecNet": 12n,
                    "DataLink": 13n,
                    "Lat": 14n,
                    "HyperChannel": 15n,
                    "AppleTalk": 16n,
                    "NetBios": 17n,
                    "VoiceView": 18n,
                    "FireFox": 19n,
                    "Banyan": 21n,
                    "Atm": 22n,
                    "InterNetworkV6": 23n,
                    "Cluster": 24n,
                    "Ieee12844": 25n,
                    "Irda": 26n,
                    "NetworkDesigners": 28n,
                    "Max": 29n,
                    "Packet": 65536n,
                    "ControllerAreaNetwork": 65537n
                };
            }
            static $h = 566967;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":566967,"n":"Unknown","d":566967,"h":4295534263,"f":33},{"t":566967,"n":"Unspecified","d":566967,"h":8590501559,"f":33},{"t":566967,"n":"Unix","d":566967,"h":12885468855,"f":33},{"t":566967,"n":"InterNetwork","d":566967,"h":17180436151,"f":33},{"t":566967,"n":"ImpLink","d":566967,"h":21475403447,"f":33},{"t":566967,"n":"Pup","d":566967,"h":25770370743,"f":33},{"t":566967,"n":"Chaos","d":566967,"h":30065338039,"f":33},{"t":566967,"n":"Ipx","d":566967,"h":34360305335,"f":33},{"t":566967,"n":"NS","d":566967,"h":38655272631,"f":33},{"t":566967,"n":"Iso","d":566967,"h":42950239927,"f":33},{"t":566967,"n":"Osi","d":566967,"h":47245207223,"f":33},{"t":566967,"n":"Ecma","d":566967,"h":51540174519,"f":33},{"t":566967,"n":"DataKit","d":566967,"h":55835141815,"f":33},{"t":566967,"n":"Ccitt","d":566967,"h":60130109111,"f":33},{"t":566967,"n":"Sna","d":566967,"h":64425076407,"f":33},{"t":566967,"n":"DecNet","d":566967,"h":68720043703,"f":33},{"t":566967,"n":"DataLink","d":566967,"h":73015010999,"f":33},{"t":566967,"n":"Lat","d":566967,"h":77309978295,"f":33},{"t":566967,"n":"HyperChannel","d":566967,"h":81604945591,"f":33},{"t":566967,"n":"AppleTalk","d":566967,"h":85899912887,"f":33},{"t":566967,"n":"NetBios","d":566967,"h":90194880183,"f":33},{"t":566967,"n":"VoiceView","d":566967,"h":94489847479,"f":33},{"t":566967,"n":"FireFox","d":566967,"h":98784814775,"f":33},{"t":566967,"n":"Banyan","d":566967,"h":103079782071,"f":33},{"t":566967,"n":"Atm","d":566967,"h":107374749367,"f":33},{"t":566967,"n":"InterNetworkV6","d":566967,"h":111669716663,"f":33},{"t":566967,"n":"Cluster","d":566967,"h":115964683959,"f":33},{"t":566967,"n":"Ieee12844","d":566967,"h":120259651255,"f":33},{"t":566967,"n":"Irda","d":566967,"h":124554618551,"f":33},{"t":566967,"n":"NetworkDesigners","d":566967,"h":128849585847,"f":33},{"t":566967,"n":"Max","d":566967,"h":133144553143,"f":33},{"t":566967,"n":"Packet","d":566967,"h":137439520439,"f":33},{"t":566967,"n":"ControllerAreaNetwork","d":566967,"h":141734487735,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":566967,"h":146029455031,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":566967}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.ProtocolFamily`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.ProtocolType", ($self) => class ProtocolType extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static IP = 0;
            static IPv6HopByHopOptions = 0;
            static Unspecified = 0;
            static Icmp = 1;
            static Igmp = 2;
            static Ggp = 3;
            static IPv4 = 4;
            static Tcp = 6;
            static Pup = 12;
            static Udp = 17;
            static Idp = 22;
            static IPv6 = 41;
            static IPv6RoutingHeader = 43;
            static IPv6FragmentHeader = 44;
            static IPSecEncapsulatingSecurityPayload = 50;
            static IPSecAuthenticationHeader = 51;
            static IcmpV6 = 58;
            static IPv6NoNextHeader = 59;
            static IPv6DestinationOptions = 60;
            static ND = 77;
            static Raw = 255;
            static Ipx = 1000;
            static Spx = 1256;
            static SpxII = 1257;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "IP": 0n,
                    "IPv6HopByHopOptions": 0n,
                    "Unspecified": 0n,
                    "Icmp": 1n,
                    "Igmp": 2n,
                    "Ggp": 3n,
                    "IPv4": 4n,
                    "Tcp": 6n,
                    "Pup": 12n,
                    "Udp": 17n,
                    "Idp": 22n,
                    "IPv6": 41n,
                    "IPv6RoutingHeader": 43n,
                    "IPv6FragmentHeader": 44n,
                    "IPSecEncapsulatingSecurityPayload": 50n,
                    "IPSecAuthenticationHeader": 51n,
                    "IcmpV6": 58n,
                    "IPv6NoNextHeader": 59n,
                    "IPv6DestinationOptions": 60n,
                    "ND": 77n,
                    "Raw": 255n,
                    "Ipx": 1000n,
                    "Spx": 1256n,
                    "SpxII": 1257n
                };
            }
            static $h = 632503;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":632503,"n":"Unknown","d":632503,"h":4295599799,"f":33},{"t":632503,"n":"IP","d":632503,"h":8590567095,"f":33},{"t":632503,"n":"IPv6HopByHopOptions","d":632503,"h":12885534391,"f":33},{"t":632503,"n":"Unspecified","d":632503,"h":17180501687,"f":33},{"t":632503,"n":"Icmp","d":632503,"h":21475468983,"f":33},{"t":632503,"n":"Igmp","d":632503,"h":25770436279,"f":33},{"t":632503,"n":"Ggp","d":632503,"h":30065403575,"f":33},{"t":632503,"n":"IPv4","d":632503,"h":34360370871,"f":33},{"t":632503,"n":"Tcp","d":632503,"h":38655338167,"f":33},{"t":632503,"n":"Pup","d":632503,"h":42950305463,"f":33},{"t":632503,"n":"Udp","d":632503,"h":47245272759,"f":33},{"t":632503,"n":"Idp","d":632503,"h":51540240055,"f":33},{"t":632503,"n":"IPv6","d":632503,"h":55835207351,"f":33},{"t":632503,"n":"IPv6RoutingHeader","d":632503,"h":60130174647,"f":33},{"t":632503,"n":"IPv6FragmentHeader","d":632503,"h":64425141943,"f":33},{"t":632503,"n":"IPSecEncapsulatingSecurityPayload","d":632503,"h":68720109239,"f":33},{"t":632503,"n":"IPSecAuthenticationHeader","d":632503,"h":73015076535,"f":33},{"t":632503,"n":"IcmpV6","d":632503,"h":77310043831,"f":33},{"t":632503,"n":"IPv6NoNextHeader","d":632503,"h":81605011127,"f":33},{"t":632503,"n":"IPv6DestinationOptions","d":632503,"h":85899978423,"f":33},{"t":632503,"n":"ND","d":632503,"h":90194945719,"f":33},{"t":632503,"n":"Raw","d":632503,"h":94489913015,"f":33},{"t":632503,"n":"Ipx","d":632503,"h":98784880311,"f":33},{"t":632503,"n":"Spx","d":632503,"h":103079847607,"f":33},{"t":632503,"n":"SpxII","d":632503,"h":107374814903,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":632503,"h":111669782199,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":632503}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.ProtocolType`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SelectMode", ($self) => class SelectMode extends $.$spc.System.Enum
        {
            static SelectRead = 0;
            static SelectWrite = 1;
            static SelectError = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "SelectRead": 0n,
                    "SelectWrite": 1n,
                    "SelectError": 2n
                };
            }
            static $h = 763575;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":763575,"n":"SelectRead","d":763575,"h":4295730871,"f":33},{"t":763575,"n":"SelectWrite","d":763575,"h":8590698167,"f":33},{"t":763575,"n":"SelectError","d":763575,"h":12885665463,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":763575,"h":17180632759,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":763575}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SelectMode`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketAsyncOperation", ($self) => class SocketAsyncOperation extends $.$spc.System.Enum
        {
            static None = 0;
            static Accept = 1;
            static Connect = 2;
            static Disconnect = 3;
            static Receive = 4;
            static ReceiveFrom = 5;
            static ReceiveMessageFrom = 6;
            static Send = 7;
            static SendPackets = 8;
            static SendTo = 9;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Accept": 1n,
                    "Connect": 2n,
                    "Disconnect": 3n,
                    "Receive": 4n,
                    "ReceiveFrom": 5n,
                    "ReceiveMessageFrom": 6n,
                    "Send": 7n,
                    "SendPackets": 8n,
                    "SendTo": 9n
                };
            }
            static $h = 1025719;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1025719,"n":"None","d":1025719,"h":4295993015,"f":33},{"t":1025719,"n":"Accept","d":1025719,"h":8590960311,"f":33},{"t":1025719,"n":"Connect","d":1025719,"h":12885927607,"f":33},{"t":1025719,"n":"Disconnect","d":1025719,"h":17180894903,"f":33},{"t":1025719,"n":"Receive","d":1025719,"h":21475862199,"f":33},{"t":1025719,"n":"ReceiveFrom","d":1025719,"h":25770829495,"f":33},{"t":1025719,"n":"ReceiveMessageFrom","d":1025719,"h":30065796791,"f":33},{"t":1025719,"n":"Send","d":1025719,"h":34360764087,"f":33},{"t":1025719,"n":"SendPackets","d":1025719,"h":38655731383,"f":33},{"t":1025719,"n":"SendTo","d":1025719,"h":42950698679,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1025719,"h":47245665975,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1025719}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketAsyncOperation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketFlags", ($self) => class SocketFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static OutOfBand = 1;
            static Peek = 2;
            static DontRoute = 4;
            static Truncated = 256;
            static ControlDataTruncated = 512;
            static Broadcast = 1024;
            static Multicast = 2048;
            static Partial = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OutOfBand": 1n,
                    "Peek": 2n,
                    "DontRoute": 4n,
                    "Truncated": 256n,
                    "ControlDataTruncated": 512n,
                    "Broadcast": 1024n,
                    "Multicast": 2048n,
                    "Partial": 32768n
                };
            }
            static $h = 1091255;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1091255,"n":"None","d":1091255,"h":4296058551,"f":33},{"t":1091255,"n":"OutOfBand","d":1091255,"h":8591025847,"f":33},{"t":1091255,"n":"Peek","d":1091255,"h":12885993143,"f":33},{"t":1091255,"n":"DontRoute","d":1091255,"h":17180960439,"f":33},{"t":1091255,"n":"Truncated","d":1091255,"h":21475927735,"f":33},{"t":1091255,"n":"ControlDataTruncated","d":1091255,"h":25770895031,"f":33},{"t":1091255,"n":"Broadcast","d":1091255,"h":30065862327,"f":33},{"t":1091255,"n":"Multicast","d":1091255,"h":34360829623,"f":33},{"t":1091255,"n":"Partial","d":1091255,"h":38655796919,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1091255,"h":42950764215,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1091255,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketFlags`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketInformationOptions", ($self) => class SocketInformationOptions extends $.$spc.System.Enum
        {
            static NonBlocking = 1;
            static Connected = 2;
            static Listening = 4;
            static UseOnlyOverlappedIO = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NonBlocking": 1n,
                    "Connected": 2n,
                    "Listening": 4n,
                    "UseOnlyOverlappedIO": 8n
                };
            }
            static $h = 1222327;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1222327,"n":"NonBlocking","d":1222327,"h":4296189623,"f":33},{"t":1222327,"n":"Connected","d":1222327,"h":8591156919,"f":33},{"t":1222327,"n":"Listening","d":1222327,"h":12886124215,"f":33},{"t":1222327,"n":"UseOnlyOverlappedIO","d":1222327,"h":17181091511,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":8660844545,"a":[{"v":"SocketInformationOptions.UseOnlyOverlappedIO has been deprecated and is not supported.","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":1222327,"h":21476058807,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1222327,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketInformationOptions`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketOptionLevel", ($self) => class SocketOptionLevel extends $.$spc.System.Enum
        {
            static IP = 0;
            static Tcp = 6;
            static Udp = 17;
            static IPv6 = 41;
            static Socket = 65535;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "IP": 0n,
                    "Tcp": 6n,
                    "Udp": 17n,
                    "IPv6": 41n,
                    "Socket": 65535n
                };
            }
            static $h = 1287863;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1287863,"n":"IP","d":1287863,"h":4296255159,"f":33},{"t":1287863,"n":"Tcp","d":1287863,"h":8591222455,"f":33},{"t":1287863,"n":"Udp","d":1287863,"h":12886189751,"f":33},{"t":1287863,"n":"IPv6","d":1287863,"h":17181157047,"f":33},{"t":1287863,"n":"Socket","d":1287863,"h":21476124343,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1287863,"h":25771091639,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1287863}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketOptionLevel`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketOptionName", ($self) => class SocketOptionName extends $.$spc.System.Enum
        {
            static DontLinger = -129;
            static ExclusiveAddressUse = -5;
            static Debug = 1;
            static IPOptions = 1;
            static NoChecksum = 1;
            static NoDelay = 1;
            static AcceptConnection = 2;
            static BsdUrgent = 2;
            static Expedited = 2;
            static HeaderIncluded = 2;
            static TcpKeepAliveTime = 3;
            static TypeOfService = 3;
            static IpTimeToLive = 4;
            static ReuseAddress = 4;
            static KeepAlive = 8;
            static MulticastInterface = 9;
            static MulticastTimeToLive = 10;
            static MulticastLoopback = 11;
            static AddMembership = 12;
            static DropMembership = 13;
            static DontFragment = 14;
            static AddSourceMembership = 15;
            static FastOpen = 15;
            static DontRoute = 16;
            static DropSourceMembership = 16;
            static TcpKeepAliveRetryCount = 16;
            static BlockSource = 17;
            static TcpKeepAliveInterval = 17;
            static UnblockSource = 18;
            static PacketInformation = 19;
            static ChecksumCoverage = 20;
            static HopLimit = 21;
            static IPProtectionLevel = 23;
            static IPv6Only = 27;
            static Broadcast = 32;
            static UseLoopback = 64;
            static Linger = 128;
            static OutOfBandInline = 256;
            static SendBuffer = 4097;
            static ReceiveBuffer = 4098;
            static SendLowWater = 4099;
            static ReceiveLowWater = 4100;
            static SendTimeout = 4101;
            static ReceiveTimeout = 4102;
            static Error = 4103;
            static Type = 4104;
            static ReuseUnicastPort = 12295;
            static UpdateAcceptContext = 28683;
            static UpdateConnectContext = 28688;
            static MaxConnections = 2147483647;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "DontLinger": -129n,
                    "ExclusiveAddressUse": -5n,
                    "Debug": 1n,
                    "IPOptions": 1n,
                    "NoChecksum": 1n,
                    "NoDelay": 1n,
                    "AcceptConnection": 2n,
                    "BsdUrgent": 2n,
                    "Expedited": 2n,
                    "HeaderIncluded": 2n,
                    "TcpKeepAliveTime": 3n,
                    "TypeOfService": 3n,
                    "IpTimeToLive": 4n,
                    "ReuseAddress": 4n,
                    "KeepAlive": 8n,
                    "MulticastInterface": 9n,
                    "MulticastTimeToLive": 10n,
                    "MulticastLoopback": 11n,
                    "AddMembership": 12n,
                    "DropMembership": 13n,
                    "DontFragment": 14n,
                    "AddSourceMembership": 15n,
                    "FastOpen": 15n,
                    "DontRoute": 16n,
                    "DropSourceMembership": 16n,
                    "TcpKeepAliveRetryCount": 16n,
                    "BlockSource": 17n,
                    "TcpKeepAliveInterval": 17n,
                    "UnblockSource": 18n,
                    "PacketInformation": 19n,
                    "ChecksumCoverage": 20n,
                    "HopLimit": 21n,
                    "IPProtectionLevel": 23n,
                    "IPv6Only": 27n,
                    "Broadcast": 32n,
                    "UseLoopback": 64n,
                    "Linger": 128n,
                    "OutOfBandInline": 256n,
                    "SendBuffer": 4097n,
                    "ReceiveBuffer": 4098n,
                    "SendLowWater": 4099n,
                    "ReceiveLowWater": 4100n,
                    "SendTimeout": 4101n,
                    "ReceiveTimeout": 4102n,
                    "Error": 4103n,
                    "Type": 4104n,
                    "ReuseUnicastPort": 12295n,
                    "UpdateAcceptContext": 28683n,
                    "UpdateConnectContext": 28688n,
                    "MaxConnections": 2147483647n
                };
            }
            static $h = 1353399;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1353399,"n":"DontLinger","d":1353399,"h":4296320695,"f":33},{"t":1353399,"n":"ExclusiveAddressUse","d":1353399,"h":8591287991,"f":33},{"t":1353399,"n":"Debug","d":1353399,"h":12886255287,"f":33},{"t":1353399,"n":"IPOptions","d":1353399,"h":17181222583,"f":33},{"t":1353399,"n":"NoChecksum","d":1353399,"h":21476189879,"f":33},{"t":1353399,"n":"NoDelay","d":1353399,"h":25771157175,"f":33},{"t":1353399,"n":"AcceptConnection","d":1353399,"h":30066124471,"f":33},{"t":1353399,"n":"BsdUrgent","d":1353399,"h":34361091767,"f":33},{"t":1353399,"n":"Expedited","d":1353399,"h":38656059063,"f":33},{"t":1353399,"n":"HeaderIncluded","d":1353399,"h":42951026359,"f":33},{"t":1353399,"n":"TcpKeepAliveTime","d":1353399,"h":47245993655,"f":33},{"t":1353399,"n":"TypeOfService","d":1353399,"h":51540960951,"f":33},{"t":1353399,"n":"IpTimeToLive","d":1353399,"h":55835928247,"f":33},{"t":1353399,"n":"ReuseAddress","d":1353399,"h":60130895543,"f":33},{"t":1353399,"n":"KeepAlive","d":1353399,"h":64425862839,"f":33},{"t":1353399,"n":"MulticastInterface","d":1353399,"h":68720830135,"f":33},{"t":1353399,"n":"MulticastTimeToLive","d":1353399,"h":73015797431,"f":33},{"t":1353399,"n":"MulticastLoopback","d":1353399,"h":77310764727,"f":33},{"t":1353399,"n":"AddMembership","d":1353399,"h":81605732023,"f":33},{"t":1353399,"n":"DropMembership","d":1353399,"h":85900699319,"f":33},{"t":1353399,"n":"DontFragment","d":1353399,"h":90195666615,"f":33},{"t":1353399,"n":"AddSourceMembership","d":1353399,"h":94490633911,"f":33},{"t":1353399,"n":"FastOpen","d":1353399,"h":98785601207,"f":33},{"t":1353399,"n":"DontRoute","d":1353399,"h":103080568503,"f":33},{"t":1353399,"n":"DropSourceMembership","d":1353399,"h":107375535799,"f":33},{"t":1353399,"n":"TcpKeepAliveRetryCount","d":1353399,"h":111670503095,"f":33},{"t":1353399,"n":"BlockSource","d":1353399,"h":115965470391,"f":33},{"t":1353399,"n":"TcpKeepAliveInterval","d":1353399,"h":120260437687,"f":33},{"t":1353399,"n":"UnblockSource","d":1353399,"h":124555404983,"f":33},{"t":1353399,"n":"PacketInformation","d":1353399,"h":128850372279,"f":33},{"t":1353399,"n":"ChecksumCoverage","d":1353399,"h":133145339575,"f":33},{"t":1353399,"n":"HopLimit","d":1353399,"h":137440306871,"f":33},{"t":1353399,"n":"IPProtectionLevel","d":1353399,"h":141735274167,"f":33},{"t":1353399,"n":"IPv6Only","d":1353399,"h":146030241463,"f":33},{"t":1353399,"n":"Broadcast","d":1353399,"h":150325208759,"f":33},{"t":1353399,"n":"UseLoopback","d":1353399,"h":154620176055,"f":33},{"t":1353399,"n":"Linger","d":1353399,"h":158915143351,"f":33},{"t":1353399,"n":"OutOfBandInline","d":1353399,"h":163210110647,"f":33},{"t":1353399,"n":"SendBuffer","d":1353399,"h":167505077943,"f":33},{"t":1353399,"n":"ReceiveBuffer","d":1353399,"h":171800045239,"f":33},{"t":1353399,"n":"SendLowWater","d":1353399,"h":176095012535,"f":33},{"t":1353399,"n":"ReceiveLowWater","d":1353399,"h":180389979831,"f":33},{"t":1353399,"n":"SendTimeout","d":1353399,"h":184684947127,"f":33},{"t":1353399,"n":"ReceiveTimeout","d":1353399,"h":188979914423,"f":33},{"t":1353399,"n":"Error","d":1353399,"h":193274881719,"f":33},{"t":1353399,"n":"Type","d":1353399,"h":197569849015,"f":33},{"t":1353399,"n":"ReuseUnicastPort","d":1353399,"h":201864816311,"f":33},{"t":1353399,"n":"UpdateAcceptContext","d":1353399,"h":206159783607,"f":33},{"t":1353399,"n":"UpdateConnectContext","d":1353399,"h":210454750903,"f":33},{"t":1353399,"n":"MaxConnections","d":1353399,"h":214749718199,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1353399,"h":219044685495,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1353399}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketOptionName`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketShutdown", ($self) => class SocketShutdown extends $.$spc.System.Enum
        {
            static Receive = 0;
            static Send = 1;
            static Both = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Receive": 0n,
                    "Send": 1n,
                    "Both": 2n
                };
            }
            static $h = 1550007;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1550007,"n":"Receive","d":1550007,"h":4296517303,"f":33},{"t":1550007,"n":"Send","d":1550007,"h":8591484599,"f":33},{"t":1550007,"n":"Both","d":1550007,"h":12886451895,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1550007,"h":17181419191,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1550007}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketShutdown`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketType", ($self) => class SocketType extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static Stream = 1;
            static Dgram = 2;
            static Raw = 3;
            static Rdm = 4;
            static Seqpacket = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Stream": 1n,
                    "Dgram": 2n,
                    "Raw": 3n,
                    "Rdm": 4n,
                    "Seqpacket": 5n
                };
            }
            static $h = 1681079;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1681079,"n":"Unknown","d":1681079,"h":4296648375,"f":33},{"t":1681079,"n":"Stream","d":1681079,"h":8591615671,"f":33},{"t":1681079,"n":"Dgram","d":1681079,"h":12886582967,"f":33},{"t":1681079,"n":"Raw","d":1681079,"h":17181550263,"f":33},{"t":1681079,"n":"Rdm","d":1681079,"h":21476517559,"f":33},{"t":1681079,"n":"Seqpacket","d":1681079,"h":25771484855,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1681079,"h":30066452151,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1681079}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketType`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.TransmitFileOptions", ($self) => class TransmitFileOptions extends $.$spc.System.Enum
        {
            static UseDefaultWorkerThread = 0;
            static Disconnect = 1;
            static ReuseSocket = 2;
            static WriteBehind = 4;
            static UseSystemThread = 16;
            static UseKernelApc = 32;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "UseDefaultWorkerThread": 0n,
                    "Disconnect": 1n,
                    "ReuseSocket": 2n,
                    "WriteBehind": 4n,
                    "UseSystemThread": 16n,
                    "UseKernelApc": 32n
                };
            }
            static $h = 1877687;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1877687,"n":"UseDefaultWorkerThread","d":1877687,"h":4296844983,"f":33},{"t":1877687,"n":"Disconnect","d":1877687,"h":8591812279,"f":33},{"t":1877687,"n":"ReuseSocket","d":1877687,"h":12886779575,"f":33},{"t":1877687,"n":"WriteBehind","d":1877687,"h":17181746871,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":1877687,"n":"UseSystemThread","d":1877687,"h":21476714167,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":1877687,"n":"UseKernelApc","d":1877687,"h":25771681463,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":1877687,"h":30066648759,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1877687,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.TransmitFileOptions`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SafeSocketHandle", ($self) => class SafeSocketHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*nint*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 698039;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7405569,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180567223,"f":32769},"n":"IsInvalid","d":698039,"h":12885599927,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":698039,"h":21475534519,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":698039,"h":4295665335,"f":1},{"p":[{"n":"preexistingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":698039,"h":8590632631,"f":1}],"i":[57475073],"h":698039}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.SafeSocketHandle`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SocketAsyncEventArgs", ($self) => class SocketAsyncEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ unsafeSuppressExecutionContextFlow)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Sockets.Socket? */ get AcceptSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket? */ set AcceptSocket(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[]? */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IList<System.ArraySegment<byte>>? */ get BufferList()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IList<System.ArraySegment<byte>>? */ set BufferList(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get BytesTransferred()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Exception? */ get ConnectByNameError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket? */ get ConnectSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DisconnectReuseSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DisconnectReuseSocket(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketAsyncOperation */ get LastOperation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Memory<byte> */ get MemoryBuffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Offset()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.IPPacketInformation */ get ReceiveMessageFromPacketInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ set RemoteEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SendPacketsElement[]? */ get SendPacketsElements()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SendPacketsElement[]? */ set SendPacketsElements(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TransmitFileOptions */ get SendPacketsFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TransmitFileOptions */ set SendPacketsFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendPacketsSendSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendPacketsSendSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketError */ get SocketError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketError */ set SocketError(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketFlags */ get SocketFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketFlags */ set SocketFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ get UserToken()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ set UserToken(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.EventHandler<System.Net.Sockets.SocketAsyncEventArgs>?*/ add_Completed(value)
            {
            }
            /*System.EventHandler<System.Net.Sockets.SocketAsyncEventArgs>?*/ remove_Completed(value)
            {
            }
            /*void */ Dispose()
            {
            }
            $dtor()
            {
            }
            /*void */ OnCompleted(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
            }
            /*void */ SetBuffer(/*byte[]?*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ SetBuffer$1(/*int*/ offset, /*int*/ count)
            {
            }
            /*void */ SetBuffer$2(/*System.Memory<byte>*/ buffer)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 960183;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":894647,"g":{"r":0,"d":0,"h":17180829367,"f":1},"s":{"r":0,"d":0,"h":21475796663,"f":1},"n":"AcceptSocket","d":960183,"h":12885862071,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30065731255,"f":1},"n":"Buffer","d":960183,"h":25770763959,"f":1},{"p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h,"g":{"r":0,"d":0,"h":38655665847,"f":1},"s":{"r":0,"d":0,"h":42950633143,"f":1},"n":"BufferList","d":960183,"h":34360698551,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51540567735,"f":1},"n":"BytesTransferred","d":960183,"h":47245600439,"f":1},{"p":47185921,"g":{"r":0,"d":0,"h":60130502327,"f":1},"n":"ConnectByNameError","d":960183,"h":55835535031,"f":1},{"p":894647,"g":{"r":0,"d":0,"h":68720436919,"f":1},"n":"ConnectSocket","d":960183,"h":64425469623,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":77310371511,"f":1},"n":"Count","d":960183,"h":73015404215,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85900306103,"f":1},"s":{"r":0,"d":0,"h":90195273399,"f":1},"n":"DisconnectReuseSocket","d":960183,"h":81605338807,"f":1},{"p":1025719,"g":{"r":0,"d":0,"h":98785207991,"f":1},"n":"LastOperation","d":960183,"h":94490240695,"f":1},{"p":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":107375142583,"f":1},"n":"MemoryBuffer","d":960183,"h":103080175287,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":115965077175,"f":1},"n":"Offset","d":960183,"h":111670109879,"f":1},{"p":173751,"g":{"r":0,"d":0,"h":124555011767,"f":1},"n":"ReceiveMessageFromPacketInfo","d":960183,"h":120260044471,"f":1},{"p":2617818,"g":{"r":0,"d":0,"h":133144946359,"f":1},"s":{"r":0,"d":0,"h":137439913655,"f":1},"n":"RemoteEndPoint","d":960183,"h":128849979063,"f":1},{"p":0,"g":{"r":0,"d":0,"h":146029848247,"f":1},"s":{"r":0,"d":0,"h":150324815543,"f":1},"n":"SendPacketsElements","d":960183,"h":141734880951,"f":1},{"p":1877687,"g":{"r":0,"d":0,"h":158914750135,"f":1},"s":{"r":0,"d":0,"h":163209717431,"f":1},"n":"SendPacketsFlags","d":960183,"h":154619782839,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":171799652023,"f":1},"s":{"r":0,"d":0,"h":176094619319,"f":1},"n":"SendPacketsSendSize","d":960183,"h":167504684727,"f":1},{"p":4714970,"g":{"r":0,"d":0,"h":184684553911,"f":1},"s":{"r":0,"d":0,"h":188979521207,"f":1},"n":"SocketError","d":960183,"h":180389586615,"f":1},{"p":1091255,"g":{"r":0,"d":0,"h":197569455799,"f":1},"s":{"r":0,"d":0,"h":201864423095,"f":1},"n":"SocketFlags","d":960183,"h":193274488503,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":210454357687,"f":1},"s":{"r":0,"d":0,"h":214749324983,"f":1},"n":"UserToken","d":960183,"h":206159390391,"f":1}],"m":[{"r":65537,"n":"Dispose","d":960183,"h":231929194167,"f":1},{"r":65537,"p":[{"n":"e","p":960183}],"n":"OnCompleted","d":960183,"h":240519128759,"f":132},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"SetBuffer","d":960183,"h":244814096055,"f":1},{"r":65537,"p":[{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"SetBuffer","o":"@$1","d":960183,"h":249109063351,"f":1},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h}],"n":"SetBuffer","o":"@$2","d":960183,"h":253404030647,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":960183,"h":4295927479,"f":1},{"p":[{"n":"unsafeSuppressExecutionContextFlow","p":262145}],"n":".ctor","o":"$ctor$3","d":960183,"h":8590894775,"f":1}],"e":[{"e":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h}],"n":"add_Completed","d":960183,"h":223339259575,"f":1},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h}],"n":"remove_Completed","d":960183,"h":227634226871,"f":1},"n":"Completed","d":960183,"h":219044292279,"f":1}],"i":[57475073],"h":960183}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.SocketAsyncEventArgs`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Console", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.NameResolution"))