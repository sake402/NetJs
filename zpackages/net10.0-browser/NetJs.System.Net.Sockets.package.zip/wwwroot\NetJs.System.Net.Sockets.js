
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $ssc, $sris, $scsl, $sl, $snp, $sspw, $sdd, $snnr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Sockets", 
    {"h":34214,"f":"System.Net.Sockets","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Sockets","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Sockets","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sns.System.Net.Sockets.IPv6MulticastOption", ($self) => class IPv6MulticastOption extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.IPAddress*/ group)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ group, /*long*/ ifindex)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get InterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set InterfaceIndex(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 296358;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3055579,"g":{"r":0,"d":0,"h":17180165542,"f":1},"s":{"r":0,"d":0,"h":21475132838,"f":1},"n":"Group","d":296358,"h":12885198246,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":30065067430,"f":1},"s":{"r":0,"d":0,"h":34360034726,"f":1},"n":"InterfaceIndex","d":296358,"h":25770100134,"f":1}],"c":[{"p":[{"n":"group","p":3055579}],"n":".ctor","o":"$ctor$1","d":296358,"h":4295263654,"f":1},{"p":[{"n":"group","p":3055579},{"n":"ifindex","p":917505}],"n":".ctor","o":"$ctor$2","d":296358,"h":8590230950,"f":1}],"h":296358}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.IPv6MulticastOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.LingerOption", ($self) => class LingerOption extends $.$spc.System.Object
        {
            $ctor$1(/*bool*/ enable, /*int*/ seconds)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Enabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Enabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get LingerTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set LingerTime(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.LingerOption.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.LingerOption.GetHashCode.apply(this, arguments); }
            static $h = 361894;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885263782,"f":1},"s":{"r":0,"d":0,"h":17180231078,"f":1},"n":"Enabled","d":361894,"h":8590296486,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25770165670,"f":1},"s":{"r":0,"d":0,"h":30065132966,"f":1},"n":"LingerTime","d":361894,"h":21475198374,"f":1}],"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":361894,"h":34360100262,"f":32769},{"r":655361,"n":"GetHashCode","d":361894,"h":38655067558,"f":32769}],"c":[{"p":[{"n":"enable","p":262145},{"n":"seconds","p":655361}],"n":".ctor","o":"$ctor$1","d":361894,"h":4295329190,"f":1}],"h":361894}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.LingerOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.MulticastOption", ($self) => class MulticastOption extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.IPAddress*/ group)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ group, /*int*/ interfaceIndex)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.IPAddress*/ group, /*System.Net.IPAddress*/ mcint)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InterfaceIndex(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress? */ get LocalAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress? */ set LocalAddress(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 427430;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3055579,"g":{"r":0,"d":0,"h":21475263910,"f":1},"s":{"r":0,"d":0,"h":25770231206,"f":1},"n":"Group","d":427430,"h":17180296614,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360165798,"f":1},"s":{"r":0,"d":0,"h":38655133094,"f":1},"n":"InterfaceIndex","d":427430,"h":30065198502,"f":1},{"p":3055579,"g":{"r":0,"d":0,"h":47245067686,"f":1},"s":{"r":0,"d":0,"h":51540034982,"f":1},"n":"LocalAddress","d":427430,"h":42950100390,"f":1}],"c":[{"p":[{"n":"group","p":3055579}],"n":".ctor","o":"$ctor$1","d":427430,"h":4295394726,"f":1},{"p":[{"n":"group","p":3055579},{"n":"interfaceIndex","p":655361}],"n":".ctor","o":"$ctor$2","d":427430,"h":8590362022,"f":1},{"p":[{"n":"group","p":3055579},{"n":"mcint","p":3055579}],"n":".ctor","o":"$ctor$3","d":427430,"h":12885329318,"f":1}],"h":427430}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.MulticastOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SendPacketsElement", ($self) => class SendPacketsElement extends $.$spc.System.Object
        {
            $ctor$1(/*byte[]*/ buffer)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.FileStream*/ fileStream)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.FileStream*/ fileStream, /*long*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.FileStream*/ fileStream, /*long*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$7(/*System.ReadOnlyMemory<byte>*/ buffer)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$8(/*System.ReadOnlyMemory<byte>*/ buffer, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$9(/*string*/ filepath)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$10(/*string*/ filepath, /*int*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$11(/*string*/ filepath, /*int*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$12(/*string*/ filepath, /*long*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$13(/*string*/ filepath, /*long*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*byte[]? */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EndOfPacket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FilePath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.FileStream? */ get FileStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ReadOnlyMemory<byte>? */ get MemoryBuffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Offset()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get OffsetLong()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 820646;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":64425330086,"f":1},"n":"Buffer","d":820646,"h":60130362790,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73015264678,"f":1},"n":"Count","d":820646,"h":68720297382,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81605199270,"f":1},"n":"EndOfPacket","d":820646,"h":77310231974,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90195133862,"f":1},"n":"FilePath","d":820646,"h":85900166566,"f":1},{"p":60293121,"g":{"r":0,"d":0,"h":98785068454,"f":1},"n":"FileStream","d":820646,"h":94490101158,"f":1},{"p":$.$typeNullable($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte)).$h,"g":{"r":0,"d":0,"h":107375003046,"f":1},"n":"MemoryBuffer","d":820646,"h":103080035750,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":115964937638,"f":1},"n":"Offset","d":820646,"h":111669970342,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":124554872230,"f":1},"n":"OffsetLong","d":820646,"h":120259904934,"f":1}],"c":[{"p":[{"n":"buffer","p":0}],"n":".ctor","o":"$ctor$1","d":820646,"h":4295787942,"f":1},{"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$2","d":820646,"h":8590755238,"f":1},{"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$3","d":820646,"h":12885722534,"f":1},{"p":[{"n":"fileStream","p":60293121}],"n":".ctor","o":"$ctor$4","d":820646,"h":17180689830,"f":1},{"p":[{"n":"fileStream","p":60293121},{"n":"offset","p":917505},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$5","d":820646,"h":21475657126,"f":1},{"p":[{"n":"fileStream","p":60293121},{"n":"offset","p":917505},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$6","d":820646,"h":25770624422,"f":1},{"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h}],"n":".ctor","o":"$ctor$7","d":820646,"h":30065591718,"f":1},{"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$8","d":820646,"h":34360559014,"f":1},{"p":[{"n":"filepath","p":1310721}],"n":".ctor","o":"$ctor$9","d":820646,"h":38655526310,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$10","d":820646,"h":42950493606,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$11","d":820646,"h":47245460902,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":917505},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$12","d":820646,"h":51540428198,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":917505},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$13","d":820646,"h":55835395494,"f":1}],"h":820646}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SendPacketsElement`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SocketTaskExtensions", ($self) => class SocketTaskExtensions
        {
            static /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync(/*this System.Net.Sockets.Socket*/ socket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.Sockets.Socket?*/ acceptSocket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$4(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$6(/*this System.Net.Sockets.Socket*/ socket, /*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$7(/*this System.Net.Sockets.Socket*/ socket, /*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ ReceiveAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ ReceiveAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<int> */ SendAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendToAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1607078;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"socket","p":886182}],"n":"AcceptAsync","d":1607078,"h":4296574374,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"socket","p":886182},{"n":"acceptSocket","p":886182}],"n":"AcceptAsync","o":"@$1","d":1607078,"h":8591541670,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":133300225,"p":[{"n":"socket","p":886182},{"n":"remoteEP","p":2596827}],"n":"ConnectAsync","d":1607078,"h":12886508966,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":136118273,"p":[{"n":"socket","p":886182},{"n":"remoteEP","p":2596827},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":1607078,"h":17181476262,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":133300225,"p":[{"n":"socket","p":886182},{"n":"address","p":3055579},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":1607078,"h":21476443558,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":136118273,"p":[{"n":"socket","p":886182},{"n":"address","p":3055579},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":1607078,"h":25771410854,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":133300225,"p":[{"n":"socket","p":886182},{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$4","d":1607078,"h":30066378150,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":136118273,"p":[{"n":"socket","p":886182},{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":1607078,"h":34361345446,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":133300225,"p":[{"n":"socket","p":886182},{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$6","d":1607078,"h":38656312742,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":136118273,"p":[{"n":"socket","p":886182},{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$7","d":1607078,"h":42951280038,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":886182},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790}],"n":"ReceiveAsync","d":1607078,"h":47246247334,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":886182},{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1082790}],"n":"ReceiveAsync","o":"@$1","d":1607078,"h":51541214630,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":886182},{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$2","d":1607078,"h":55836181926,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"socket","p":886182},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"remoteEndPoint","p":2596827}],"n":"ReceiveFromAsync","d":1607078,"h":60131149222,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"socket","p":886182},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"remoteEndPoint","p":2596827}],"n":"ReceiveMessageFromAsync","d":1607078,"h":64426116518,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":886182},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790}],"n":"SendAsync","d":1607078,"h":68721083814,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":886182},{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1082790}],"n":"SendAsync","o":"@$1","d":1607078,"h":73016051110,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":886182},{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$2","d":1607078,"h":77311018406,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":886182},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"remoteEP","p":2596827}],"n":"SendToAsync","d":1607078,"h":81605985702,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}],"h":1607078,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SocketTaskExtensions`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.Socket", ($self) => class Socket extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.Sockets.AddressFamily*/ addressFamily, /*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.Sockets.SafeSocketHandle*/ handle)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.Sockets.SocketInformation*/ socketInformation)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.Sockets.AddressFamily */ get AddressFamily()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Blocking()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Blocking(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Connected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DontFragment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DontFragment(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DualMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DualMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableBroadcast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableBroadcast(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*nint */ get Handle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsBound()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ get LingerState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ set LingerState(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get MulticastLoopback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MulticastLoopback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get NoDelay()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set NoDelay(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsIPv4()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsIPv6()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsUnixDomainSockets()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.ProtocolType */ get ProtocolType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SafeSocketHandle */ get SafeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketType */ get SocketType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get SupportsIPv4()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get SupportsIPv6()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ get Ttl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ set Ttl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseOnlyOverlappedIO()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseOnlyOverlappedIO(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ Accept()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync$1(/*System.Net.Sockets.Socket?*/ acceptSocket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptAsync$2(/*System.Net.Sockets.Socket?*/ acceptSocket, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ AcceptAsync$3(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptAsync$4(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept$1(/*int*/ receiveSize, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept$2(/*System.Net.Sockets.Socket?*/ acceptSocket, /*int*/ receiveSize, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect(/*System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$1(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$3(/*string*/ host, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginDisconnect(/*bool*/ reuseSocket, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceive(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginReceive$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceive$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginReceive$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceiveFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceiveMessageFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginSend$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginSend$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendFile(/*string?*/ fileName, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendFile$1(/*string?*/ fileName, /*byte[]?*/ preBuffer, /*byte[]?*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendTo(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Bind(/*System.Net.EndPoint*/ localEP)
            {
            }
            static /*void */ CancelConnectAsync(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
            }
            /*void */ Close()
            {
            }
            /*void */ Close$1(/*int*/ timeout)
            {
            }
            /*void */ Connect(/*System.Net.EndPoint*/ remoteEP)
            {
            }
            /*void */ Connect$1(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
            }
            /*void */ Connect$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
            }
            /*void */ Connect$3(/*string*/ host, /*int*/ port)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync(/*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ConnectAsync$6(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ ConnectAsync$7(/*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType, /*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$8(/*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$9(/*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Disconnect(/*bool*/ reuseSocket)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisconnectAsync(/*bool*/ reuseSocket, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ DisconnectAsync$1(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Net.Sockets.SocketInformation */ DuplicateAndClose(/*int*/ targetProcessId)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept(/*out byte[]*/ buffer, /*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept$1(/*out byte[]*/ buffer, /*out int*/ bytesTransferred, /*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept$2(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndConnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndDisconnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndReceive(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceive$1(/*System.IAsyncResult*/ asyncResult, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceiveFrom(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.EndPoint*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceiveMessageFrom(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ endPoint, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend$1(/*System.IAsyncResult*/ asyncResult, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndSendFile(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndSendTo(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            /*int */ GetRawSocketOption(/*int*/ optionLevel, /*int*/ optionName, /*System.Span<byte>*/ optionValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ GetSocketOption(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetSocketOption$1(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*byte[]*/ optionValue)
            {
            }
            /*byte[] */ GetSocketOption$2(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*int*/ optionLength)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ IOControl(/*int*/ ioControlCode, /*byte[]?*/ optionInValue, /*byte[]?*/ optionOutValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ IOControl$1(/*System.Net.Sockets.IOControlCode*/ ioControlCode, /*byte[]?*/ optionInValue, /*byte[]?*/ optionOutValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Listen()
            {
            }
            /*void */ Listen$1(/*int*/ backlog)
            {
            }
            /*bool */ Poll(/*int*/ microSeconds, /*System.Net.Sockets.SelectMode*/ mode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Poll$1(/*System.TimeSpan*/ timeout, /*System.Net.Sockets.SelectMode*/ mode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive(/*byte[]*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$3(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$4(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$5(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$6(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$7(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$8(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$9(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$10(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync(/*System.ArraySegment<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$4(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$5(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveAsync$6(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$1(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$2(/*byte[]*/ buffer, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$4(/*System.Span<byte>*/ buffer, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$5(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$6(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ receivedAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$2(/*System.Memory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$3(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveFromAsync$4(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ receivedAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveFromAsync$5(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveMessageFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveMessageFrom$1(/*System.Span<byte>*/ buffer, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$2(/*System.Memory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$3(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveMessageFromAsync$4(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ Select(/*System.Collections.IList?*/ checkRead, /*System.Collections.IList?*/ checkWrite, /*System.Collections.IList?*/ checkError, /*int*/ microSeconds)
            {
            }
            static /*void */ Select$1(/*System.Collections.IList?*/ checkRead, /*System.Collections.IList?*/ checkWrite, /*System.Collections.IList?*/ checkError, /*System.TimeSpan*/ timeout)
            {
            }
            /*int */ Send(/*byte[]*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$3(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$4(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$5(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$6(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$7(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$8(/*System.ReadOnlySpan<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$9(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$10(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync(/*System.ArraySegment<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendAsync$4(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$5(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$6(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SendFile(/*string?*/ fileName)
            {
            }
            /*void */ SendFile$1(/*string?*/ fileName, /*byte[]?*/ preBuffer, /*byte[]?*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags)
            {
            }
            /*void */ SendFile$2(/*string?*/ fileName, /*System.ReadOnlySpan<byte>*/ preBuffer, /*System.ReadOnlySpan<byte>*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags)
            {
            }
            /*System.Threading.Tasks.ValueTask */ SendFileAsync(/*string?*/ fileName, /*System.ReadOnlyMemory<byte>*/ preBuffer, /*System.ReadOnlyMemory<byte>*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ SendFileAsync$1(/*string?*/ fileName, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendPacketsAsync(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$1(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$2(/*byte[]*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$4(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$5(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$6(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ socketAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendToAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendToAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendToAsync$2(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$3(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$4(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$5(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ socketAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetIPProtectionLevel(/*System.Net.Sockets.IPProtectionLevel*/ level)
            {
            }
            /*void */ SetRawSocketOption(/*int*/ optionLevel, /*int*/ optionName, /*System.ReadOnlySpan<byte>*/ optionValue)
            {
            }
            /*void */ SetSocketOption(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*bool*/ optionValue)
            {
            }
            /*void */ SetSocketOption$1(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*byte[]*/ optionValue)
            {
            }
            /*void */ SetSocketOption$2(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*int*/ optionValue)
            {
            }
            /*void */ SetSocketOption$3(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*object*/ optionValue)
            {
            }
            /*void */ Shutdown(/*System.Net.Sockets.SocketShutdown*/ how)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 886182;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4497371,"g":{"r":0,"d":0,"h":25770689958,"f":1},"n":"AddressFamily","d":886182,"h":21475722662,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360624550,"f":1},"n":"Available","d":886182,"h":30065657254,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950559142,"f":1},"s":{"r":0,"d":0,"h":47245526438,"f":1},"n":"Blocking","d":886182,"h":38655591846,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55835461030,"f":1},"n":"Connected","d":886182,"h":51540493734,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64425395622,"f":1},"s":{"r":0,"d":0,"h":68720362918,"f":1},"n":"DontFragment","d":886182,"h":60130428326,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77310297510,"f":1},"s":{"r":0,"d":0,"h":81605264806,"f":1},"n":"DualMode","d":886182,"h":73015330214,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":90195199398,"f":1},"s":{"r":0,"d":0,"h":94490166694,"f":1},"n":"EnableBroadcast","d":886182,"h":85900232102,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":103080101286,"f":1},"s":{"r":0,"d":0,"h":107375068582,"f":1},"n":"ExclusiveAddressUse","d":886182,"h":98785133990,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":115965003174,"f":1},"n":"Handle","d":886182,"h":111670035878,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554937766,"f":1},"n":"IsBound","d":886182,"h":120259970470,"f":1},{"p":361894,"g":{"r":0,"d":0,"h":133144872358,"f":1},"s":{"r":0,"d":0,"h":137439839654,"f":1},"n":"LingerState","d":886182,"h":128849905062,"f":1},{"p":2596827,"g":{"r":0,"d":0,"h":146029774246,"f":1},"n":"LocalEndPoint","d":886182,"h":141734806950,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":154619708838,"f":1},"s":{"r":0,"d":0,"h":158914676134,"f":1},"n":"MulticastLoopback","d":886182,"h":150324741542,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":167504610726,"f":1},"s":{"r":0,"d":0,"h":171799578022,"f":1},"n":"NoDelay","d":886182,"h":163209643430,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":180389512614,"f":33},"n":"OSSupportsIPv4","d":886182,"h":176094545318,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":188979447206,"f":33},"n":"OSSupportsIPv6","d":886182,"h":184684479910,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":197569381798,"f":33},"n":"OSSupportsUnixDomainSockets","d":886182,"h":193274414502,"f":33},{"p":624038,"g":{"r":0,"d":0,"h":206159316390,"f":1},"n":"ProtocolType","d":886182,"h":201864349094,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":214749250982,"f":1},"s":{"r":0,"d":0,"h":219044218278,"f":1},"n":"ReceiveBufferSize","d":886182,"h":210454283686,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":227634152870,"f":1},"s":{"r":0,"d":0,"h":231929120166,"f":1},"n":"ReceiveTimeout","d":886182,"h":223339185574,"f":1},{"p":2596827,"g":{"r":0,"d":0,"h":240519054758,"f":1},"n":"RemoteEndPoint","d":886182,"h":236224087462,"f":1},{"p":689574,"g":{"r":0,"d":0,"h":249108989350,"f":1},"n":"SafeHandle","d":886182,"h":244814022054,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":257698923942,"f":1},"s":{"r":0,"d":0,"h":261993891238,"f":1},"n":"SendBufferSize","d":886182,"h":253403956646,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":270583825830,"f":1},"s":{"r":0,"d":0,"h":274878793126,"f":1},"n":"SendTimeout","d":886182,"h":266288858534,"f":1},{"p":1672614,"g":{"r":0,"d":0,"h":283468727718,"f":1},"n":"SocketType","d":886182,"h":279173760422,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":292058662310,"f":33},"n":"SupportsIPv4","d":886182,"h":287763695014,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SupportsIPv4 has been deprecated. Use OSSupportsIPv4 instead.","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":300648596902,"f":33},"n":"SupportsIPv6","d":886182,"h":296353629606,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SupportsIPv6 has been deprecated. Use OSSupportsIPv6 instead.","t":1310721}]}]},{"p":524289,"g":{"r":0,"d":0,"h":309238531494,"f":1},"s":{"r":0,"d":0,"h":313533498790,"f":1},"n":"Ttl","d":886182,"h":304943564198,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":322123433382,"f":1},"s":{"r":0,"d":0,"h":326418400678,"f":1},"n":"UseOnlyOverlappedIO","d":886182,"h":317828466086,"f":1,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":8660844545,"a":[{"v":"UseOnlyOverlappedIO has been deprecated and is not supported.","t":1310721}]}]}],"m":[{"r":886182,"n":"Accept","d":886182,"h":330713367974,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"n":"AcceptAsync","d":886182,"h":335008335270,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"acceptSocket","p":886182}],"n":"AcceptAsync","o":"@$1","d":886182,"h":339303302566,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"acceptSocket","p":886182},{"n":"cancellationToken","p":125960193}],"n":"AcceptAsync","o":"@$2","d":886182,"h":343598269862,"f":1},{"r":262145,"p":[{"n":"e","p":951718}],"n":"AcceptAsync","o":"@$3","d":886182,"h":347893237158,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptAsync","o":"@$4","d":886182,"h":352188204454,"f":1},{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAccept","d":886182,"h":356483171750,"f":1},{"r":56950785,"p":[{"n":"receiveSize","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAccept","o":"@$1","d":886182,"h":360778139046,"f":1},{"r":56950785,"p":[{"n":"acceptSocket","p":886182},{"n":"receiveSize","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAccept","o":"@$2","d":886182,"h":365073106342,"f":1},{"r":56950785,"p":[{"n":"remoteEP","p":2596827},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","d":886182,"h":369368073638,"f":1},{"r":56950785,"p":[{"n":"address","p":3055579},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$1","d":886182,"h":373663040934,"f":1},{"r":56950785,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$2","d":886182,"h":377958008230,"f":1},{"r":56950785,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$3","d":886182,"h":382252975526,"f":1},{"r":56950785,"p":[{"n":"reuseSocket","p":262145},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginDisconnect","d":886182,"h":386547942822,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1082790},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","d":886182,"h":390842910118,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1082790},{"n":"errorCode","p":4693979,"f":2},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$1","d":886182,"h":395137877414,"f":1},{"r":56950785,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1082790},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$2","d":886182,"h":399432844710,"f":1},{"r":56950785,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1082790},{"n":"errorCode","p":4693979,"f":2},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$3","d":886182,"h":403727812006,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1082790},{"n":"remoteEP","p":2596827,"f":4},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceiveFrom","d":886182,"h":408022779302,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1082790},{"n":"remoteEP","p":2596827,"f":4},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceiveMessageFrom","d":886182,"h":412317746598,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1082790},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","d":886182,"h":416612713894,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1082790},{"n":"errorCode","p":4693979,"f":2},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$1","d":886182,"h":420907681190,"f":1},{"r":56950785,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1082790},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$2","d":886182,"h":425202648486,"f":1},{"r":56950785,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1082790},{"n":"errorCode","p":4693979,"f":2},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$3","d":886182,"h":429497615782,"f":1},{"r":56950785,"p":[{"n":"fileName","p":1310721},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSendFile","d":886182,"h":433792583078,"f":1},{"r":56950785,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":0},{"n":"postBuffer","p":0},{"n":"flags","p":1869222},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSendFile","o":"@$1","d":886182,"h":438087550374,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1082790},{"n":"remoteEP","p":2596827},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSendTo","d":886182,"h":442382517670,"f":1},{"r":65537,"p":[{"n":"localEP","p":2596827}],"n":"Bind","d":886182,"h":446677484966,"f":1},{"r":65537,"p":[{"n":"e","p":951718}],"n":"CancelConnectAsync","d":886182,"h":450972452262,"f":33},{"r":65537,"n":"Close","d":886182,"h":455267419558,"f":1},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Close","o":"@$1","d":886182,"h":459562386854,"f":1},{"r":65537,"p":[{"n":"remoteEP","p":2596827}],"n":"Connect","d":886182,"h":463857354150,"f":1},{"r":65537,"p":[{"n":"address","p":3055579},{"n":"port","p":655361}],"n":"Connect","o":"@$1","d":886182,"h":468152321446,"f":1},{"r":65537,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"Connect","o":"@$2","d":886182,"h":472447288742,"f":1},{"r":65537,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$3","d":886182,"h":476742256038,"f":1},{"r":133300225,"p":[{"n":"remoteEP","p":2596827}],"n":"ConnectAsync","d":886182,"h":481037223334,"f":1},{"r":136118273,"p":[{"n":"remoteEP","p":2596827},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":886182,"h":485332190630,"f":1},{"r":133300225,"p":[{"n":"address","p":3055579},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":886182,"h":489627157926,"f":1},{"r":136118273,"p":[{"n":"address","p":3055579},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":886182,"h":493922125222,"f":1},{"r":133300225,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$4","d":886182,"h":498217092518,"f":1},{"r":136118273,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":886182,"h":502512059814,"f":1},{"r":262145,"p":[{"n":"e","p":951718}],"n":"ConnectAsync","o":"@$6","d":886182,"h":506807027110,"f":1},{"r":262145,"p":[{"n":"socketType","p":1672614},{"n":"protocolType","p":624038},{"n":"e","p":951718}],"n":"ConnectAsync","o":"@$7","d":886182,"h":511101994406,"f":33},{"r":133300225,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$8","d":886182,"h":515396961702,"f":1},{"r":136118273,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$9","d":886182,"h":519691928998,"f":1},{"r":65537,"p":[{"n":"reuseSocket","p":262145}],"n":"Disconnect","d":886182,"h":523986896294,"f":1},{"r":136118273,"p":[{"n":"reuseSocket","p":262145},{"n":"cancellationToken","p":125960193,"f":65}],"n":"DisconnectAsync","d":886182,"h":528281863590,"f":1},{"r":262145,"p":[{"n":"e","p":951718}],"n":"DisconnectAsync","o":"@$1","d":886182,"h":532576830886,"f":1},{"r":65537,"n":"Dispose","d":886182,"h":536871798182,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":886182,"h":541166765478,"f":132},{"r":1148326,"p":[{"n":"targetProcessId","p":655361}],"n":"DuplicateAndClose","d":886182,"h":545461732774,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":886182,"p":[{"n":"buffer","p":0,"f":2},{"n":"asyncResult","p":56950785}],"n":"EndAccept","d":886182,"h":549756700070,"f":1},{"r":886182,"p":[{"n":"buffer","p":0,"f":2},{"n":"bytesTransferred","p":655361,"f":2},{"n":"asyncResult","p":56950785}],"n":"EndAccept","o":"@$1","d":886182,"h":554051667366,"f":1},{"r":886182,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAccept","o":"@$2","d":886182,"h":558346634662,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndConnect","d":886182,"h":562641601958,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndDisconnect","d":886182,"h":566936569254,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndReceive","d":886182,"h":571231536550,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785},{"n":"errorCode","p":4693979,"f":2}],"n":"EndReceive","o":"@$1","d":886182,"h":575526503846,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785},{"n":"endPoint","p":2596827,"f":4}],"n":"EndReceiveFrom","d":886182,"h":579821471142,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785},{"n":"socketFlags","p":1082790,"f":4},{"n":"endPoint","p":2596827,"f":4},{"n":"ipPacketInformation","p":165286,"f":2}],"n":"EndReceiveMessageFrom","d":886182,"h":584116438438,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndSend","d":886182,"h":588411405734,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785},{"n":"errorCode","p":4693979,"f":2}],"n":"EndSend","o":"@$1","d":886182,"h":592706373030,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndSendFile","d":886182,"h":597001340326,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndSendTo","d":886182,"h":601296307622,"f":1},{"r":655361,"p":[{"n":"optionLevel","p":655361},{"n":"optionName","p":655361},{"n":"optionValue","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetRawSocketOption","d":886182,"h":609886242214,"f":1},{"r":131073,"p":[{"n":"optionLevel","p":1279398},{"n":"optionName","p":1344934}],"n":"GetSocketOption","d":886182,"h":614181209510,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1279398},{"n":"optionName","p":1344934},{"n":"optionValue","p":0}],"n":"GetSocketOption","o":"@$1","d":886182,"h":618476176806,"f":1},{"r":0,"p":[{"n":"optionLevel","p":1279398},{"n":"optionName","p":1344934},{"n":"optionLength","p":655361}],"n":"GetSocketOption","o":"@$2","d":886182,"h":622771144102,"f":1},{"r":655361,"p":[{"n":"ioControlCode","p":655361},{"n":"optionInValue","p":0},{"n":"optionOutValue","p":0}],"n":"IOControl","d":886182,"h":627066111398,"f":1},{"r":655361,"p":[{"n":"ioControlCode","p":99750},{"n":"optionInValue","p":0},{"n":"optionOutValue","p":0}],"n":"IOControl","o":"@$1","d":886182,"h":631361078694,"f":1},{"r":65537,"n":"Listen","d":886182,"h":635656045990,"f":1},{"r":65537,"p":[{"n":"backlog","p":655361}],"n":"Listen","o":"@$1","d":886182,"h":639951013286,"f":1},{"r":262145,"p":[{"n":"microSeconds","p":655361},{"n":"mode","p":755110}],"n":"Poll","d":886182,"h":644245980582,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793},{"n":"mode","p":755110}],"n":"Poll","o":"@$1","d":886182,"h":648540947878,"f":1},{"r":655361,"p":[{"n":"buffer","p":0}],"n":"Receive","d":886182,"h":652835915174,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1082790}],"n":"Receive","o":"@$1","d":886182,"h":657130882470,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1082790},{"n":"errorCode","p":4693979,"f":2}],"n":"Receive","o":"@$2","d":886182,"h":661425849766,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1082790}],"n":"Receive","o":"@$3","d":886182,"h":665720817062,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1082790}],"n":"Receive","o":"@$4","d":886182,"h":670015784358,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"Receive","o":"@$5","d":886182,"h":674310751654,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1082790}],"n":"Receive","o":"@$6","d":886182,"h":678605718950,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1082790},{"n":"errorCode","p":4693979,"f":2}],"n":"Receive","o":"@$7","d":886182,"h":682900686246,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Receive","o":"@$8","d":886182,"h":687195653542,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790}],"n":"Receive","o":"@$9","d":886182,"h":691490620838,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"errorCode","p":4693979,"f":2}],"n":"Receive","o":"@$10","d":886182,"h":695785588134,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h}],"n":"ReceiveAsync","d":886182,"h":700080555430,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790}],"n":"ReceiveAsync","o":"@$1","d":886182,"h":704375522726,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"ReceiveAsync","o":"@$2","d":886182,"h":708670490022,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1082790}],"n":"ReceiveAsync","o":"@$3","d":886182,"h":712965457318,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$4","d":886182,"h":717260424614,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$5","d":886182,"h":721555391910,"f":1},{"r":262145,"p":[{"n":"e","p":951718}],"n":"ReceiveAsync","o":"@$6","d":886182,"h":725850359206,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1082790},{"n":"remoteEP","p":2596827,"f":4}],"n":"ReceiveFrom","d":886182,"h":730145326502,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1082790},{"n":"remoteEP","p":2596827,"f":4}],"n":"ReceiveFrom","o":"@$1","d":886182,"h":734440293798,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"remoteEP","p":2596827,"f":4}],"n":"ReceiveFrom","o":"@$2","d":886182,"h":738735261094,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1082790},{"n":"remoteEP","p":2596827,"f":4}],"n":"ReceiveFrom","o":"@$3","d":886182,"h":743030228390,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2596827,"f":4}],"n":"ReceiveFrom","o":"@$4","d":886182,"h":747325195686,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"remoteEP","p":2596827,"f":4}],"n":"ReceiveFrom","o":"@$5","d":886182,"h":751620162982,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"receivedAddress","p":4366299}],"n":"ReceiveFrom","o":"@$6","d":886182,"h":755915130278,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2596827}],"n":"ReceiveFromAsync","d":886182,"h":760210097574,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"remoteEndPoint","p":2596827}],"n":"ReceiveFromAsync","o":"@$1","d":886182,"h":764505064870,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2596827},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$2","d":886182,"h":768800032166,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"remoteEndPoint","p":2596827},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$3","d":886182,"h":773094999462,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"receivedAddress","p":4366299},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$4","d":886182,"h":777389966758,"f":1},{"r":262145,"p":[{"n":"e","p":951718}],"n":"ReceiveFromAsync","o":"@$5","d":886182,"h":781684934054,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1082790,"f":4},{"n":"remoteEP","p":2596827,"f":4},{"n":"ipPacketInformation","p":165286,"f":2}],"n":"ReceiveMessageFrom","d":886182,"h":785979901350,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790,"f":4},{"n":"remoteEP","p":2596827,"f":4},{"n":"ipPacketInformation","p":165286,"f":2}],"n":"ReceiveMessageFrom","o":"@$1","d":886182,"h":790274868646,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2596827}],"n":"ReceiveMessageFromAsync","d":886182,"h":794569835942,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"remoteEndPoint","p":2596827}],"n":"ReceiveMessageFromAsync","o":"@$1","d":886182,"h":798864803238,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2596827},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveMessageFromAsync","o":"@$2","d":886182,"h":803159770534,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"remoteEndPoint","p":2596827},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveMessageFromAsync","o":"@$3","d":886182,"h":807454737830,"f":1},{"r":262145,"p":[{"n":"e","p":951718}],"n":"ReceiveMessageFromAsync","o":"@$4","d":886182,"h":811749705126,"f":1},{"r":65537,"p":[{"n":"checkRead","p":31916033},{"n":"checkWrite","p":31916033},{"n":"checkError","p":31916033},{"n":"microSeconds","p":655361}],"n":"Select","d":886182,"h":816044672422,"f":33},{"r":65537,"p":[{"n":"checkRead","p":31916033},{"n":"checkWrite","p":31916033},{"n":"checkError","p":31916033},{"n":"timeout","p":140705793}],"n":"Select","o":"@$1","d":886182,"h":820339639718,"f":33},{"r":655361,"p":[{"n":"buffer","p":0}],"n":"Send","d":886182,"h":824634607014,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1082790}],"n":"Send","o":"@$1","d":886182,"h":828929574310,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1082790},{"n":"errorCode","p":4693979,"f":2}],"n":"Send","o":"@$2","d":886182,"h":833224541606,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1082790}],"n":"Send","o":"@$3","d":886182,"h":837519508902,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1082790}],"n":"Send","o":"@$4","d":886182,"h":841814476198,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"Send","o":"@$5","d":886182,"h":846109443494,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1082790}],"n":"Send","o":"@$6","d":886182,"h":850404410790,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1082790},{"n":"errorCode","p":4693979,"f":2}],"n":"Send","o":"@$7","d":886182,"h":854699378086,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Send","o":"@$8","d":886182,"h":858994345382,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790}],"n":"Send","o":"@$9","d":886182,"h":863289312678,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"errorCode","p":4693979,"f":2}],"n":"Send","o":"@$10","d":886182,"h":867584279974,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h}],"n":"SendAsync","d":886182,"h":871879247270,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790}],"n":"SendAsync","o":"@$1","d":886182,"h":876174214566,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"SendAsync","o":"@$2","d":886182,"h":880469181862,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1082790}],"n":"SendAsync","o":"@$3","d":886182,"h":884764149158,"f":1},{"r":262145,"p":[{"n":"e","p":951718}],"n":"SendAsync","o":"@$4","d":886182,"h":889059116454,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$5","d":886182,"h":893354083750,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$6","d":886182,"h":897649051046,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"SendFile","d":886182,"h":901944018342,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":0},{"n":"postBuffer","p":0},{"n":"flags","p":1869222}],"n":"SendFile","o":"@$1","d":886182,"h":906238985638,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"postBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"flags","p":1869222}],"n":"SendFile","o":"@$2","d":886182,"h":910533952934,"f":1},{"r":136118273,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"postBuffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"flags","p":1869222},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendFileAsync","d":886182,"h":914828920230,"f":1},{"r":136118273,"p":[{"n":"fileName","p":1310721},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendFileAsync","o":"@$1","d":886182,"h":919123887526,"f":1},{"r":262145,"p":[{"n":"e","p":951718}],"n":"SendPacketsAsync","d":886182,"h":923418854822,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1082790},{"n":"remoteEP","p":2596827}],"n":"SendTo","d":886182,"h":927713822118,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1082790},{"n":"remoteEP","p":2596827}],"n":"SendTo","o":"@$1","d":886182,"h":932008789414,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"remoteEP","p":2596827}],"n":"SendTo","o":"@$2","d":886182,"h":936303756710,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1082790},{"n":"remoteEP","p":2596827}],"n":"SendTo","o":"@$3","d":886182,"h":940598724006,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2596827}],"n":"SendTo","o":"@$4","d":886182,"h":944893691302,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"remoteEP","p":2596827}],"n":"SendTo","o":"@$5","d":886182,"h":949188658598,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"socketAddress","p":4366299}],"n":"SendTo","o":"@$6","d":886182,"h":953483625894,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2596827}],"n":"SendToAsync","d":886182,"h":957778593190,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"remoteEP","p":2596827}],"n":"SendToAsync","o":"@$1","d":886182,"h":962073560486,"f":1},{"r":262145,"p":[{"n":"e","p":951718}],"n":"SendToAsync","o":"@$2","d":886182,"h":966368527782,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2596827},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$3","d":886182,"h":970663495078,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"remoteEP","p":2596827},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$4","d":886182,"h":974958462374,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1082790},{"n":"socketAddress","p":4366299},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$5","d":886182,"h":979253429670,"f":1},{"r":65537,"p":[{"n":"level","p":230822}],"n":"SetIPProtectionLevel","d":886182,"h":983548396966,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"optionLevel","p":655361},{"n":"optionName","p":655361},{"n":"optionValue","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"SetRawSocketOption","d":886182,"h":987843364262,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1279398},{"n":"optionName","p":1344934},{"n":"optionValue","p":262145}],"n":"SetSocketOption","d":886182,"h":992138331558,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1279398},{"n":"optionName","p":1344934},{"n":"optionValue","p":0}],"n":"SetSocketOption","o":"@$1","d":886182,"h":996433298854,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1279398},{"n":"optionName","p":1344934},{"n":"optionValue","p":655361}],"n":"SetSocketOption","o":"@$2","d":886182,"h":1000728266150,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1279398},{"n":"optionName","p":1344934},{"n":"optionValue","p":131073}],"n":"SetSocketOption","o":"@$3","d":886182,"h":1005023233446,"f":1},{"r":65537,"p":[{"n":"how","p":1541542}],"n":"Shutdown","d":886182,"h":1009318200742,"f":1}],"c":[{"p":[{"n":"addressFamily","p":4497371},{"n":"socketType","p":1672614},{"n":"protocolType","p":624038}],"n":".ctor","o":"$ctor$1","d":886182,"h":4295853478,"f":1},{"p":[{"n":"handle","p":689574}],"n":".ctor","o":"$ctor$2","d":886182,"h":8590820774,"f":1},{"p":[{"n":"socketInformation","p":1148326}],"n":".ctor","o":"$ctor$3","d":886182,"h":12885788070,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":[{"n":"socketType","p":1672614},{"n":"protocolType","p":624038}],"n":".ctor","o":"$ctor$4","d":886182,"h":17180755366,"f":1}],"i":[57475073],"h":886182}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.Socket`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.TcpClient", ($self) => class TcpClient extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ hostname, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Active(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Client()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ set Client(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Connected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ get LingerState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ set LingerState(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get NoDelay()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set NoDelay(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$1(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$2(/*string*/ host, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close()
            {
            }
            /*void */ Connect(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
            }
            /*void */ Connect$1(/*System.Net.IPAddress[]*/ ipAddresses, /*int*/ port)
            {
            }
            /*void */ Connect$2(/*System.Net.IPEndPoint*/ remoteEP)
            {
            }
            /*void */ Connect$3(/*string*/ hostname, /*int*/ port)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Net.IPEndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*System.Net.IPEndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$6(/*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$7(/*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ EndConnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*System.Net.Sockets.NetworkStream */ GetStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1738150;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25771541926,"f":4},"s":{"r":0,"d":0,"h":30066509222,"f":4},"n":"Active","d":1738150,"h":21476574630,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":38656443814,"f":1},"n":"Available","d":1738150,"h":34361476518,"f":1},{"p":886182,"g":{"r":0,"d":0,"h":47246378406,"f":1},"s":{"r":0,"d":0,"h":51541345702,"f":1},"n":"Client","d":1738150,"h":42951411110,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131280294,"f":1},"n":"Connected","d":1738150,"h":55836312998,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721214886,"f":1},"s":{"r":0,"d":0,"h":73016182182,"f":1},"n":"ExclusiveAddressUse","d":1738150,"h":64426247590,"f":1},{"p":361894,"g":{"r":0,"d":0,"h":81606116774,"f":1},"s":{"r":0,"d":0,"h":85901084070,"f":1},"n":"LingerState","d":1738150,"h":77311149478,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94491018662,"f":1},"s":{"r":0,"d":0,"h":98785985958,"f":1},"n":"NoDelay","d":1738150,"h":90196051366,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":107375920550,"f":1},"s":{"r":0,"d":0,"h":111670887846,"f":1},"n":"ReceiveBufferSize","d":1738150,"h":103080953254,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":120260822438,"f":1},"s":{"r":0,"d":0,"h":124555789734,"f":1},"n":"ReceiveTimeout","d":1738150,"h":115965855142,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":133145724326,"f":1},"s":{"r":0,"d":0,"h":137440691622,"f":1},"n":"SendBufferSize","d":1738150,"h":128850757030,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":146030626214,"f":1},"s":{"r":0,"d":0,"h":150325593510,"f":1},"n":"SendTimeout","d":1738150,"h":141735658918,"f":1}],"m":[{"r":56950785,"p":[{"n":"address","p":3055579},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","d":1738150,"h":154620560806,"f":1},{"r":56950785,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$1","d":1738150,"h":158915528102,"f":1},{"r":56950785,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$2","d":1738150,"h":163210495398,"f":1},{"r":65537,"n":"Close","d":1738150,"h":167505462694,"f":1},{"r":65537,"p":[{"n":"address","p":3055579},{"n":"port","p":655361}],"n":"Connect","d":1738150,"h":171800429990,"f":1},{"r":65537,"p":[{"n":"ipAddresses","p":0},{"n":"port","p":655361}],"n":"Connect","o":"@$1","d":1738150,"h":176095397286,"f":1},{"r":65537,"p":[{"n":"remoteEP","p":3317723}],"n":"Connect","o":"@$2","d":1738150,"h":180390364582,"f":1},{"r":65537,"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$3","d":1738150,"h":184685331878,"f":1},{"r":133300225,"p":[{"n":"address","p":3055579},{"n":"port","p":655361}],"n":"ConnectAsync","d":1738150,"h":188980299174,"f":1},{"r":136118273,"p":[{"n":"address","p":3055579},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":1738150,"h":193275266470,"f":1},{"r":133300225,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":1738150,"h":197570233766,"f":1},{"r":136118273,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":1738150,"h":201865201062,"f":1},{"r":133300225,"p":[{"n":"remoteEP","p":3317723}],"n":"ConnectAsync","o":"@$4","d":1738150,"h":206160168358,"f":1},{"r":136118273,"p":[{"n":"remoteEP","p":3317723},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":1738150,"h":210455135654,"f":1},{"r":133300225,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$6","d":1738150,"h":214750102950,"f":1},{"r":136118273,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$7","d":1738150,"h":219045070246,"f":1},{"r":65537,"n":"Dispose","d":1738150,"h":223340037542,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1738150,"h":227635004838,"f":132},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndConnect","d":1738150,"h":231929972134,"f":1},{"r":492966,"n":"GetStream","d":1738150,"h":240519906726,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1738150,"h":4296705446,"f":1},{"p":[{"n":"localEP","p":3317723}],"n":".ctor","o":"$ctor$2","d":1738150,"h":8591672742,"f":1},{"p":[{"n":"family","p":4497371}],"n":".ctor","o":"$ctor$3","d":1738150,"h":12886640038,"f":1},{"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$4","d":1738150,"h":17181607334,"f":1}],"i":[57475073],"h":1738150}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.TcpClient`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.TcpListener", ($self) => class TcpListener extends $.$spc.System.Object
        {
            $ctor$1(/*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ localaddr, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ get LocalEndpoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Server()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ AcceptSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptSocketAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptSocketAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TcpClient */ AcceptTcpClient()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.TcpClient> */ AcceptTcpClientAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.TcpClient> */ AcceptTcpClientAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AllowNatTraversal(/*bool*/ allowed)
            {
            }
            /*System.IAsyncResult */ BeginAcceptSocket(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAcceptTcpClient(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Sockets.TcpListener */ Create(/*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*System.Net.Sockets.Socket */ EndAcceptSocket(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TcpClient */ EndAcceptTcpClient(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Pending()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Start()
            {
            }
            /*void */ Start$1(/*int*/ backlog)
            {
            }
            /*void */ Stop()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1803686;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476640166,"f":4},"n":"Active","d":1803686,"h":17181672870,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":30066574758,"f":1},"s":{"r":0,"d":0,"h":34361542054,"f":1},"n":"ExclusiveAddressUse","d":1803686,"h":25771607462,"f":1},{"p":2596827,"g":{"r":0,"d":0,"h":42951476646,"f":1},"n":"LocalEndpoint","d":1803686,"h":38656509350,"f":1},{"p":886182,"g":{"r":0,"d":0,"h":51541411238,"f":1},"n":"Server","d":1803686,"h":47246443942,"f":1}],"m":[{"r":886182,"n":"AcceptSocket","d":1803686,"h":55836378534,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"n":"AcceptSocketAsync","d":1803686,"h":60131345830,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptSocketAsync","o":"@$1","d":1803686,"h":64426313126,"f":1},{"r":1738150,"n":"AcceptTcpClient","d":1803686,"h":68721280422,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.TcpClient).$h,"n":"AcceptTcpClientAsync","d":1803686,"h":73016247718,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.TcpClient).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptTcpClientAsync","o":"@$1","d":1803686,"h":77311215014,"f":1},{"r":65537,"p":[{"n":"allowed","p":262145}],"n":"AllowNatTraversal","d":1803686,"h":81606182310,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAcceptSocket","d":1803686,"h":85901149606,"f":1},{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAcceptTcpClient","d":1803686,"h":90196116902,"f":1},{"r":1803686,"p":[{"n":"port","p":655361}],"n":"Create","d":1803686,"h":94491084198,"f":33},{"r":65537,"n":"Dispose","d":1803686,"h":98786051494,"f":1},{"r":886182,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAcceptSocket","d":1803686,"h":103081018790,"f":1},{"r":1738150,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAcceptTcpClient","d":1803686,"h":107375986086,"f":1},{"r":262145,"n":"Pending","d":1803686,"h":111670953382,"f":1},{"r":65537,"n":"Start","d":1803686,"h":115965920678,"f":1},{"r":65537,"p":[{"n":"backlog","p":655361}],"n":"Start","o":"@$1","d":1803686,"h":120260887974,"f":1},{"r":65537,"n":"Stop","d":1803686,"h":124555855270,"f":1}],"c":[{"p":[{"n":"port","p":655361}],"n":".ctor","o":"$ctor$1","d":1803686,"h":4296770982,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor has been deprecated. Use TcpListener(IPAddress localaddr, int port) instead.","t":1310721}]}]},{"p":[{"n":"localaddr","p":3055579},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":1803686,"h":8591738278,"f":1},{"p":[{"n":"localEP","p":3317723}],"n":".ctor","o":"$ctor$3","d":1803686,"h":12886705574,"f":1}],"i":[57475073],"h":1803686}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.TcpListener`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.UdpClient", ($self) => class UdpClient extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*int*/ port, /*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$6(/*string*/ hostname, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Active(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Client()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ set Client(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DontFragment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DontFragment(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableBroadcast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableBroadcast(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get MulticastLoopback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MulticastLoopback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ get Ttl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ set Ttl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AllowNatTraversal(/*bool*/ allowed)
            {
            }
            /*System.IAsyncResult */ BeginReceive(/*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend(/*byte[]*/ datagram, /*int*/ bytes, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$1(/*byte[]*/ datagram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$2(/*byte[]*/ datagram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close()
            {
            }
            /*void */ Connect(/*System.Net.IPAddress*/ addr, /*int*/ port)
            {
            }
            /*void */ Connect$1(/*System.Net.IPEndPoint*/ endPoint)
            {
            }
            /*void */ Connect$2(/*string*/ hostname, /*int*/ port)
            {
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ DropMulticastGroup(/*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ DropMulticastGroup$1(/*System.Net.IPAddress*/ multicastAddr, /*int*/ ifindex)
            {
            }
            /*byte[] */ EndReceive(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.IPEndPoint?*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ JoinMulticastGroup(/*int*/ ifindex, /*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ JoinMulticastGroup$1(/*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ JoinMulticastGroup$2(/*System.Net.IPAddress*/ multicastAddr, /*int*/ timeToLive)
            {
            }
            /*void */ JoinMulticastGroup$3(/*System.Net.IPAddress*/ multicastAddr, /*System.Net.IPAddress*/ localAddress)
            {
            }
            /*byte[] */ Receive(/*ref System.Net.IPEndPoint?*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.UdpReceiveResult> */ ReceiveAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.UdpReceiveResult> */ ReceiveAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send(/*byte[]*/ dgram, /*int*/ bytes)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$1(/*byte[]*/ dgram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$2(/*byte[]*/ dgram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$3(/*System.ReadOnlySpan<byte>*/ datagram)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$4(/*System.ReadOnlySpan<byte>*/ datagram, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$5(/*System.ReadOnlySpan<byte>*/ datagram, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync(/*byte[]*/ datagram, /*int*/ bytes)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*byte[]*/ datagram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$2(/*byte[]*/ datagram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$3(/*System.ReadOnlyMemory<byte>*/ datagram, /*System.Net.IPEndPoint?*/ endPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$4(/*System.ReadOnlyMemory<byte>*/ datagram, /*string?*/ hostname, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$5(/*System.ReadOnlyMemory<byte>*/ datagram, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1934758;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34361673126,"f":4},"s":{"r":0,"d":0,"h":38656640422,"f":4},"n":"Active","d":1934758,"h":30066705830,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":47246575014,"f":1},"n":"Available","d":1934758,"h":42951607718,"f":1},{"p":886182,"g":{"r":0,"d":0,"h":55836509606,"f":1},"s":{"r":0,"d":0,"h":60131476902,"f":1},"n":"Client","d":1934758,"h":51541542310,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721411494,"f":1},"s":{"r":0,"d":0,"h":73016378790,"f":1},"n":"DontFragment","d":1934758,"h":64426444198,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81606313382,"f":1},"s":{"r":0,"d":0,"h":85901280678,"f":1},"n":"EnableBroadcast","d":1934758,"h":77311346086,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94491215270,"f":1},"s":{"r":0,"d":0,"h":98786182566,"f":1},"n":"ExclusiveAddressUse","d":1934758,"h":90196247974,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":107376117158,"f":1},"s":{"r":0,"d":0,"h":111671084454,"f":1},"n":"MulticastLoopback","d":1934758,"h":103081149862,"f":1},{"p":524289,"g":{"r":0,"d":0,"h":120261019046,"f":1},"s":{"r":0,"d":0,"h":124555986342,"f":1},"n":"Ttl","d":1934758,"h":115966051750,"f":1}],"m":[{"r":65537,"p":[{"n":"allowed","p":262145}],"n":"AllowNatTraversal","d":1934758,"h":128850953638,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":56950785,"p":[{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","d":1934758,"h":133145920934,"f":1},{"r":56950785,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","d":1934758,"h":137440888230,"f":1},{"r":56950785,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3317723},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$1","d":1934758,"h":141735855526,"f":1},{"r":56950785,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$2","d":1934758,"h":146030822822,"f":1},{"r":65537,"n":"Close","d":1934758,"h":150325790118,"f":1},{"r":65537,"p":[{"n":"addr","p":3055579},{"n":"port","p":655361}],"n":"Connect","d":1934758,"h":154620757414,"f":1},{"r":65537,"p":[{"n":"endPoint","p":3317723}],"n":"Connect","o":"@$1","d":1934758,"h":158915724710,"f":1},{"r":65537,"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$2","d":1934758,"h":163210692006,"f":1},{"r":65537,"n":"Dispose","d":1934758,"h":167505659302,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1934758,"h":171800626598,"f":132},{"r":65537,"p":[{"n":"multicastAddr","p":3055579}],"n":"DropMulticastGroup","d":1934758,"h":176095593894,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3055579},{"n":"ifindex","p":655361}],"n":"DropMulticastGroup","o":"@$1","d":1934758,"h":180390561190,"f":1},{"r":0,"p":[{"n":"asyncResult","p":56950785},{"n":"remoteEP","p":3317723,"f":4}],"n":"EndReceive","d":1934758,"h":184685528486,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndSend","d":1934758,"h":188980495782,"f":1},{"r":65537,"p":[{"n":"ifindex","p":655361},{"n":"multicastAddr","p":3055579}],"n":"JoinMulticastGroup","d":1934758,"h":193275463078,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3055579}],"n":"JoinMulticastGroup","o":"@$1","d":1934758,"h":197570430374,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3055579},{"n":"timeToLive","p":655361}],"n":"JoinMulticastGroup","o":"@$2","d":1934758,"h":201865397670,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3055579},{"n":"localAddress","p":3055579}],"n":"JoinMulticastGroup","o":"@$3","d":1934758,"h":206160364966,"f":1},{"r":0,"p":[{"n":"remoteEP","p":3317723,"f":4}],"n":"Receive","d":1934758,"h":210455332262,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h,"n":"ReceiveAsync","d":1934758,"h":214750299558,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReceiveAsync","o":"@$1","d":1934758,"h":219045266854,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361}],"n":"Send","d":1934758,"h":223340234150,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3317723}],"n":"Send","o":"@$1","d":1934758,"h":227635201446,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Send","o":"@$2","d":1934758,"h":231930168742,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Send","o":"@$3","d":1934758,"h":236225136038,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"endPoint","p":3317723}],"n":"Send","o":"@$4","d":1934758,"h":240520103334,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Send","o":"@$5","d":1934758,"h":244815070630,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361}],"n":"SendAsync","d":1934758,"h":249110037926,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3317723}],"n":"SendAsync","o":"@$1","d":1934758,"h":253405005222,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"SendAsync","o":"@$2","d":1934758,"h":257699972518,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"endPoint","p":3317723},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$3","d":1934758,"h":261994939814,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"hostname","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$4","d":1934758,"h":266289907110,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$5","d":1934758,"h":270584874406,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1934758,"h":4296902054,"f":1},{"p":[{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":1934758,"h":8591869350,"f":1},{"p":[{"n":"port","p":655361},{"n":"family","p":4497371}],"n":".ctor","o":"$ctor$3","d":1934758,"h":12886836646,"f":1},{"p":[{"n":"localEP","p":3317723}],"n":".ctor","o":"$ctor$4","d":1934758,"h":17181803942,"f":1},{"p":[{"n":"family","p":4497371}],"n":".ctor","o":"$ctor$5","d":1934758,"h":21476771238,"f":1},{"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$6","d":1934758,"h":25771738534,"f":1}],"i":[57475073],"h":1934758}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.UdpClient`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketInformation", ($self) => class SocketInformation extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.Sockets.SocketInformationOptions */ get Options()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketInformationOptions */ set Options(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ get ProtocolInformation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ set ProtocolInformation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 1148326;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1213862,"g":{"r":0,"d":0,"h":17181017510,"f":1},"s":{"r":0,"d":0,"h":21475984806,"f":1},"n":"Options","d":1148326,"h":12886050214,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30065919398,"f":1},"s":{"r":0,"d":0,"h":34360886694,"f":1},"n":"ProtocolInformation","d":1148326,"h":25770952102,"f":1}],"l":[{"t":131073,"n":"_dummy","d":1148326,"h":4296115622,"f":2},{"t":655361,"n":"_dummyPrimitive","d":1148326,"h":8591082918,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1148326,"h":38655853990,"f":1}],"h":1148326}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketInformation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketReceiveFromResult", ($self) => class SocketReceiveFromResult extends $.$spc.System.ValueType
        {
            /*int*/  get ReceivedBytes() { return this.$getField(0, 4); }
            /*int*/  set ReceivedBytes(value) { this.$setField(0, 4, value); }
            /*System.Net.EndPoint*/  get RemoteEndPoint() { return this.$getField(4, 4); }
            /*System.Net.EndPoint*/  set RemoteEndPoint(value) { this.$setField(4, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ReceivedBytes = this.ReceivedBytes;
                copy.RemoteEndPoint = this.RemoteEndPoint;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ReceivedBytes = 0;
                this.RemoteEndPoint = null;
            }
            static $h = 1410470;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"ReceivedBytes","d":1410470,"h":4296377766,"f":1},{"t":2596827,"n":"RemoteEndPoint","d":1410470,"h":8591345062,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1410470,"h":12886312358,"f":1}],"h":1410470}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketReceiveFromResult`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketReceiveMessageFromResult", ($self) => class SocketReceiveMessageFromResult extends $.$spc.System.ValueType
        {
            /*System.Net.Sockets.IPPacketInformation*/  get PacketInformation() { return this.$getField(0, 8); }
            /*System.Net.Sockets.IPPacketInformation*/  set PacketInformation(value) { this.$setField(0, 8, value); }
            /*int*/  get ReceivedBytes() { return this.$getField(8, 4); }
            /*int*/  set ReceivedBytes(value) { this.$setField(8, 4, value); }
            /*System.Net.EndPoint*/  get RemoteEndPoint() { return this.$getField(12, 4); }
            /*System.Net.EndPoint*/  set RemoteEndPoint(value) { this.$setField(12, 4, value); }
            /*System.Net.Sockets.SocketFlags*/  get SocketFlags() { return this.$getField(16, 4); }
            /*System.Net.Sockets.SocketFlags*/  set SocketFlags(value) { this.$setField(16, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.PacketInformation = this.PacketInformation.Clone();
                copy.ReceivedBytes = this.ReceivedBytes;
                copy.RemoteEndPoint = this.RemoteEndPoint;
                copy.SocketFlags = this.SocketFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.PacketInformation = $.$default($.$sns.System.Net.Sockets.IPPacketInformation);
                this.ReceivedBytes = 0;
                this.RemoteEndPoint = null;
                this.SocketFlags = 0;
            }
            static $h = 1476006;
            static $z = 20;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":165286,"n":"PacketInformation","d":1476006,"h":4296443302,"f":1},{"t":655361,"n":"ReceivedBytes","d":1476006,"h":8591410598,"f":1},{"t":2596827,"n":"RemoteEndPoint","d":1476006,"h":12886377894,"f":1},{"t":1082790,"n":"SocketFlags","d":1476006,"h":17181345190,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1476006,"h":21476312486,"f":1}],"h":1476006}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketReceiveMessageFromResult`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.UnixDomainSocketEndPoint", ($self) => class UnixDomainSocketEndPoint extends $.$snp.System.Net.EndPoint
        {
            $ctor$2(/*string*/ path)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Sockets.AddressFamily */ get AddressFamily()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ Create(/*System.Net.SocketAddress*/ socketAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.GetHashCode.apply(this, arguments); }
            /*System.Net.SocketAddress */ Serialize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.ToString.apply(this, arguments); }
            static $h = 2065830;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2596827,"p":[{"p":4497371,"g":{"r":0,"d":0,"h":12886967718,"f":32769},"n":"AddressFamily","d":2065830,"h":8592000422,"f":32769}],"m":[{"r":2596827,"p":[{"n":"socketAddress","p":4366299}],"n":"Create","d":2065830,"h":17181935014,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2065830,"h":21476902310,"f":32769},{"r":655361,"n":"GetHashCode","d":2065830,"h":25771869606,"f":32769},{"r":4366299,"n":"Serialize","d":2065830,"h":30066836902,"f":32769},{"r":1310721,"n":"ToString","d":2065830,"h":34361804198,"f":32769}],"c":[{"p":[{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$2","d":2065830,"h":4297033126,"f":1}],"h":2065830}; }
            static get $b() { return $.$snp.System.Net.EndPoint; }
            static get $fullName() { return `System.Net.Sockets.UnixDomainSocketEndPoint`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IPPacketInformation", ($self) => class IPPacketInformation extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.IPAddress */ get Address()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Interface()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Sockets.IPPacketInformation*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.IPPacketInformation.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.IPPacketInformation.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Sockets.IPPacketInformation*/ packetInformation1, /*System.Net.Sockets.IPPacketInformation*/ packetInformation2)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Sockets.IPPacketInformation*/ packetInformation1, /*System.Net.Sockets.IPPacketInformation*/ packetInformation2)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IEquatable<System.Net.Sockets.IPPacketInformation>.Equals(System.Net.Sockets.IPPacketInformation)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 165286;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":3055579,"g":{"r":0,"d":0,"h":17180034470,"f":1},"n":"Address","d":165286,"h":12885067174,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25769969062,"f":1},"n":"Interface","d":165286,"h":21475001766,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":165286}],"n":"Equals","o":"@$2","d":165286,"h":30064936358,"f":1},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":165286,"h":34359903654,"f":32769},{"r":655361,"n":"GetHashCode","d":165286,"h":38654870950,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":165286,"h":4295132582,"f":2},{"t":655361,"n":"_dummyPrimitive","d":165286,"h":8590099878,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":165286,"h":51539772838,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.IPPacketInformation).$h],"h":165286}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.IPPacketInformation) ]; }
            static get $fullName() { return `System.Net.Sockets.IPPacketInformation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.UdpReceiveResult", ($self) => class UdpReceiveResult extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$2(/*byte[]*/ buffer, /*System.Net.IPEndPoint*/ remoteEndPoint)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*byte[] */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Sockets.UdpReceiveResult*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.UdpReceiveResult.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.UdpReceiveResult.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Sockets.UdpReceiveResult*/ left, /*System.Net.Sockets.UdpReceiveResult*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Sockets.UdpReceiveResult*/ left, /*System.Net.Sockets.UdpReceiveResult*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IEquatable<System.Net.Sockets.UdpReceiveResult>.Equals(System.Net.Sockets.UdpReceiveResult)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 2000294;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":0,"g":{"r":0,"d":0,"h":21476836774,"f":1},"n":"Buffer","d":2000294,"h":17181869478,"f":1},{"p":3317723,"g":{"r":0,"d":0,"h":30066771366,"f":1},"n":"RemoteEndPoint","d":2000294,"h":25771804070,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":2000294}],"n":"Equals","o":"@$2","d":2000294,"h":34361738662,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2000294,"h":38656705958,"f":32769},{"r":655361,"n":"GetHashCode","d":2000294,"h":42951673254,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":2000294,"h":4296967590,"f":2},{"t":655361,"n":"_dummyPrimitive","d":2000294,"h":8591934886,"f":2}],"c":[{"p":[{"n":"buffer","p":0},{"n":"remoteEndPoint","p":3317723}],"n":".ctor","o":"$ctor$2","d":2000294,"h":12886902182,"f":1},{"n":".ctor","o":"$ctor$3","d":2000294,"h":55836575142,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h],"h":2000294}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.UdpReceiveResult) ]; }
            static get $fullName() { return `System.Net.Sockets.UdpReceiveResult`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.NetworkStream", ($self) => class NetworkStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.Net.Sockets.Socket*/ socket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.Sockets.Socket*/ socket, /*bool*/ ownsSocket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*System.Net.Sockets.Socket*/ socket, /*System.IO.FileAccess*/ access)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$6(/*System.Net.Sockets.Socket*/ socket, /*System.IO.FileAccess*/ access, /*bool*/ ownsSocket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DataAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Readable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Readable(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Socket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Writeable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Writeable(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close$1(/*int*/ timeout)
            {
            }
            /*void */ Close$2(/*System.TimeSpan*/ timeout)
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 492966;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770296742,"f":32769},"n":"CanRead","d":492966,"h":21475329446,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360231334,"f":32769},"n":"CanSeek","d":492966,"h":30065264038,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950165926,"f":32769},"n":"CanTimeout","d":492966,"h":38655198630,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51540100518,"f":32769},"n":"CanWrite","d":492966,"h":47245133222,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60130035110,"f":129},"n":"DataAvailable","d":492966,"h":55835067814,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":68719969702,"f":32769},"n":"Length","d":492966,"h":64425002406,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":77309904294,"f":32769},"s":{"r":0,"d":0,"h":81604871590,"f":32769},"n":"Position","d":492966,"h":73014936998,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":90194806182,"f":4},"s":{"r":0,"d":0,"h":94489773478,"f":4},"n":"Readable","d":492966,"h":85899838886,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":103079708070,"f":32769},"s":{"r":0,"d":0,"h":107374675366,"f":32769},"n":"ReadTimeout","d":492966,"h":98784740774,"f":32769},{"p":886182,"g":{"r":0,"d":0,"h":115964609958,"f":1},"n":"Socket","d":492966,"h":111669642662,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554544550,"f":4},"s":{"r":0,"d":0,"h":128849511846,"f":4},"n":"Writeable","d":492966,"h":120259577254,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":137439446438,"f":32769},"s":{"r":0,"d":0,"h":141734413734,"f":32769},"n":"WriteTimeout","d":492966,"h":133144479142,"f":32769}],"m":[{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginRead","d":492966,"h":146029381030,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWrite","d":492966,"h":150324348326,"f":32769},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Close","o":"@$1","d":492966,"h":154619315622,"f":1},{"r":65537,"p":[{"n":"timeout","p":140705793}],"n":"Close","o":"@$2","d":492966,"h":158914282918,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":492966,"h":163209250214,"f":32772},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":492966,"h":167504217510,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":492966,"h":171799184806,"f":32769},{"r":65537,"n":"Flush","d":492966,"h":180389119398,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":492966,"h":184684086694,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":492966,"h":188979053990,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":492966,"h":193274021286,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":492966,"h":197568988582,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":492966,"h":201863955878,"f":32769},{"r":655361,"n":"ReadByte","d":492966,"h":206158923174,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":492966,"h":210453890470,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":492966,"h":214748857766,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":492966,"h":219043825062,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":492966,"h":223338792358,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":492966,"h":227633759654,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":492966,"h":231928726950,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":492966,"h":236223694246,"f":32769}],"c":[{"p":[{"n":"socket","p":886182}],"n":".ctor","o":"$ctor$3","d":492966,"h":4295460262,"f":1},{"p":[{"n":"socket","p":886182},{"n":"ownsSocket","p":262145}],"n":".ctor","o":"$ctor$4","d":492966,"h":8590427558,"f":1},{"p":[{"n":"socket","p":886182},{"n":"access","p":59703297}],"n":".ctor","o":"$ctor$5","d":492966,"h":12885394854,"f":1},{"p":[{"n":"socket","p":886182},{"n":"access","p":59703297},{"n":"ownsSocket","p":262145}],"n":".ctor","o":"$ctor$6","d":492966,"h":17180362150,"f":1}],"i":[57475073,56885249],"h":492966}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.NetworkStream`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IOControlCode", ($self) => class IOControlCode extends $.$spc.System.Enum
        {
            static EnableCircularQueuing = 671088642n;
            static Flush = 671088644n;
            static AddressListChange = 671088663n;
            static DataToRead = 1074030207n;
            static OobDataRead = 1074033415n;
            static GetBroadcastAddress = 1207959557n;
            static AddressListQuery = 1207959574n;
            static QueryTargetPnpHandle = 1207959576n;
            static AsyncIO = 2147772029n;
            static NonBlockingIO = 2147772030n;
            static AssociateHandle = 2281701377n;
            static MultipointLoopback = 2281701385n;
            static MulticastScope = 2281701386n;
            static SetQos = 2281701387n;
            static SetGroupQos = 2281701388n;
            static RoutingInterfaceChange = 2281701397n;
            static NamespaceChange = 2281701401n;
            static ReceiveAll = 2550136833n;
            static ReceiveAllMulticast = 2550136834n;
            static ReceiveAllIgmpMulticast = 2550136835n;
            static KeepAliveValues = 2550136836n;
            static AbsorbRouterAlert = 2550136837n;
            static UnicastInterface = 2550136838n;
            static LimitBroadcasts = 2550136839n;
            static BindToInterface = 2550136840n;
            static MulticastInterface = 2550136841n;
            static AddMulticastGroupOnInterface = 2550136842n;
            static DeleteMulticastGroupFromInterface = 2550136843n;
            static GetExtensionFunctionPointer = 3355443206n;
            static GetQos = 3355443207n;
            static GetGroupQos = 3355443208n;
            static TranslateHandle = 3355443213n;
            static RoutingInterfaceQuery = 3355443220n;
            static AddressListSort = 3355443225n;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "EnableCircularQueuing": 671088642n,
                    "Flush": 671088644n,
                    "AddressListChange": 671088663n,
                    "DataToRead": 1074030207n,
                    "OobDataRead": 1074033415n,
                    "GetBroadcastAddress": 1207959557n,
                    "AddressListQuery": 1207959574n,
                    "QueryTargetPnpHandle": 1207959576n,
                    "AsyncIO": 2147772029n,
                    "NonBlockingIO": 2147772030n,
                    "AssociateHandle": 2281701377n,
                    "MultipointLoopback": 2281701385n,
                    "MulticastScope": 2281701386n,
                    "SetQos": 2281701387n,
                    "SetGroupQos": 2281701388n,
                    "RoutingInterfaceChange": 2281701397n,
                    "NamespaceChange": 2281701401n,
                    "ReceiveAll": 2550136833n,
                    "ReceiveAllMulticast": 2550136834n,
                    "ReceiveAllIgmpMulticast": 2550136835n,
                    "KeepAliveValues": 2550136836n,
                    "AbsorbRouterAlert": 2550136837n,
                    "UnicastInterface": 2550136838n,
                    "LimitBroadcasts": 2550136839n,
                    "BindToInterface": 2550136840n,
                    "MulticastInterface": 2550136841n,
                    "AddMulticastGroupOnInterface": 2550136842n,
                    "DeleteMulticastGroupFromInterface": 2550136843n,
                    "GetExtensionFunctionPointer": 3355443206n,
                    "GetQos": 3355443207n,
                    "GetGroupQos": 3355443208n,
                    "TranslateHandle": 3355443213n,
                    "RoutingInterfaceQuery": 3355443220n,
                    "AddressListSort": 3355443225n
                };
            }
            static $h = 99750;
            static $z = 8;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int64; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":917505,"l":[{"t":99750,"n":"EnableCircularQueuing","d":99750,"h":4295067046,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"Flush","d":99750,"h":8590034342,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"AddressListChange","d":99750,"h":12885001638,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"DataToRead","d":99750,"h":17179968934,"f":33},{"t":99750,"n":"OobDataRead","d":99750,"h":21474936230,"f":33},{"t":99750,"n":"GetBroadcastAddress","d":99750,"h":25769903526,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"AddressListQuery","d":99750,"h":30064870822,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"QueryTargetPnpHandle","d":99750,"h":34359838118,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"AsyncIO","d":99750,"h":38654805414,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"NonBlockingIO","d":99750,"h":42949772710,"f":33},{"t":99750,"n":"AssociateHandle","d":99750,"h":47244740006,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"MultipointLoopback","d":99750,"h":51539707302,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"MulticastScope","d":99750,"h":55834674598,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"SetQos","d":99750,"h":60129641894,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"SetGroupQos","d":99750,"h":64424609190,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"RoutingInterfaceChange","d":99750,"h":68719576486,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"NamespaceChange","d":99750,"h":73014543782,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"ReceiveAll","d":99750,"h":77309511078,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"ReceiveAllMulticast","d":99750,"h":81604478374,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"ReceiveAllIgmpMulticast","d":99750,"h":85899445670,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"KeepAliveValues","d":99750,"h":90194412966,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"AbsorbRouterAlert","d":99750,"h":94489380262,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"UnicastInterface","d":99750,"h":98784347558,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"LimitBroadcasts","d":99750,"h":103079314854,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"BindToInterface","d":99750,"h":107374282150,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"MulticastInterface","d":99750,"h":111669249446,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"AddMulticastGroupOnInterface","d":99750,"h":115964216742,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"DeleteMulticastGroupFromInterface","d":99750,"h":120259184038,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"GetExtensionFunctionPointer","d":99750,"h":124554151334,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"GetQos","d":99750,"h":128849118630,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"GetGroupQos","d":99750,"h":133144085926,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"TranslateHandle","d":99750,"h":137439053222,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"RoutingInterfaceQuery","d":99750,"h":141734020518,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":99750,"n":"AddressListSort","d":99750,"h":146028987814,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":99750,"h":150323955110,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":99750}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.IOControlCode`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IPProtectionLevel", ($self) => class IPProtectionLevel extends $.$spc.System.Enum
        {
            static Unspecified = -1;
            static Unrestricted = 10;
            static EdgeRestricted = 20;
            static Restricted = 30;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unspecified": -1n,
                    "Unrestricted": 10n,
                    "EdgeRestricted": 20n,
                    "Restricted": 30n
                };
            }
            static $h = 230822;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":230822,"n":"Unspecified","d":230822,"h":4295198118,"f":33},{"t":230822,"n":"Unrestricted","d":230822,"h":8590165414,"f":33},{"t":230822,"n":"EdgeRestricted","d":230822,"h":12885132710,"f":33},{"t":230822,"n":"Restricted","d":230822,"h":17180100006,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":230822,"h":21475067302,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":230822}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.IPProtectionLevel`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.ProtocolFamily", ($self) => class ProtocolFamily extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static Unspecified = 0;
            static Unix = 1;
            static InterNetwork = 2;
            static ImpLink = 3;
            static Pup = 4;
            static Chaos = 5;
            static Ipx = 6;
            static NS = 6;
            static Iso = 7;
            static Osi = 7;
            static Ecma = 8;
            static DataKit = 9;
            static Ccitt = 10;
            static Sna = 11;
            static DecNet = 12;
            static DataLink = 13;
            static Lat = 14;
            static HyperChannel = 15;
            static AppleTalk = 16;
            static NetBios = 17;
            static VoiceView = 18;
            static FireFox = 19;
            static Banyan = 21;
            static Atm = 22;
            static InterNetworkV6 = 23;
            static Cluster = 24;
            static Ieee12844 = 25;
            static Irda = 26;
            static NetworkDesigners = 28;
            static Max = 29;
            static Packet = 65536;
            static ControllerAreaNetwork = 65537;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Unspecified": 0n,
                    "Unix": 1n,
                    "InterNetwork": 2n,
                    "ImpLink": 3n,
                    "Pup": 4n,
                    "Chaos": 5n,
                    "Ipx": 6n,
                    "NS": 6n,
                    "Iso": 7n,
                    "Osi": 7n,
                    "Ecma": 8n,
                    "DataKit": 9n,
                    "Ccitt": 10n,
                    "Sna": 11n,
                    "DecNet": 12n,
                    "DataLink": 13n,
                    "Lat": 14n,
                    "HyperChannel": 15n,
                    "AppleTalk": 16n,
                    "NetBios": 17n,
                    "VoiceView": 18n,
                    "FireFox": 19n,
                    "Banyan": 21n,
                    "Atm": 22n,
                    "InterNetworkV6": 23n,
                    "Cluster": 24n,
                    "Ieee12844": 25n,
                    "Irda": 26n,
                    "NetworkDesigners": 28n,
                    "Max": 29n,
                    "Packet": 65536n,
                    "ControllerAreaNetwork": 65537n
                };
            }
            static $h = 558502;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":558502,"n":"Unknown","d":558502,"h":4295525798,"f":33},{"t":558502,"n":"Unspecified","d":558502,"h":8590493094,"f":33},{"t":558502,"n":"Unix","d":558502,"h":12885460390,"f":33},{"t":558502,"n":"InterNetwork","d":558502,"h":17180427686,"f":33},{"t":558502,"n":"ImpLink","d":558502,"h":21475394982,"f":33},{"t":558502,"n":"Pup","d":558502,"h":25770362278,"f":33},{"t":558502,"n":"Chaos","d":558502,"h":30065329574,"f":33},{"t":558502,"n":"Ipx","d":558502,"h":34360296870,"f":33},{"t":558502,"n":"NS","d":558502,"h":38655264166,"f":33},{"t":558502,"n":"Iso","d":558502,"h":42950231462,"f":33},{"t":558502,"n":"Osi","d":558502,"h":47245198758,"f":33},{"t":558502,"n":"Ecma","d":558502,"h":51540166054,"f":33},{"t":558502,"n":"DataKit","d":558502,"h":55835133350,"f":33},{"t":558502,"n":"Ccitt","d":558502,"h":60130100646,"f":33},{"t":558502,"n":"Sna","d":558502,"h":64425067942,"f":33},{"t":558502,"n":"DecNet","d":558502,"h":68720035238,"f":33},{"t":558502,"n":"DataLink","d":558502,"h":73015002534,"f":33},{"t":558502,"n":"Lat","d":558502,"h":77309969830,"f":33},{"t":558502,"n":"HyperChannel","d":558502,"h":81604937126,"f":33},{"t":558502,"n":"AppleTalk","d":558502,"h":85899904422,"f":33},{"t":558502,"n":"NetBios","d":558502,"h":90194871718,"f":33},{"t":558502,"n":"VoiceView","d":558502,"h":94489839014,"f":33},{"t":558502,"n":"FireFox","d":558502,"h":98784806310,"f":33},{"t":558502,"n":"Banyan","d":558502,"h":103079773606,"f":33},{"t":558502,"n":"Atm","d":558502,"h":107374740902,"f":33},{"t":558502,"n":"InterNetworkV6","d":558502,"h":111669708198,"f":33},{"t":558502,"n":"Cluster","d":558502,"h":115964675494,"f":33},{"t":558502,"n":"Ieee12844","d":558502,"h":120259642790,"f":33},{"t":558502,"n":"Irda","d":558502,"h":124554610086,"f":33},{"t":558502,"n":"NetworkDesigners","d":558502,"h":128849577382,"f":33},{"t":558502,"n":"Max","d":558502,"h":133144544678,"f":33},{"t":558502,"n":"Packet","d":558502,"h":137439511974,"f":33},{"t":558502,"n":"ControllerAreaNetwork","d":558502,"h":141734479270,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":558502,"h":146029446566,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":558502}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.ProtocolFamily`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.ProtocolType", ($self) => class ProtocolType extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static IP = 0;
            static IPv6HopByHopOptions = 0;
            static Unspecified = 0;
            static Icmp = 1;
            static Igmp = 2;
            static Ggp = 3;
            static IPv4 = 4;
            static Tcp = 6;
            static Pup = 12;
            static Udp = 17;
            static Idp = 22;
            static IPv6 = 41;
            static IPv6RoutingHeader = 43;
            static IPv6FragmentHeader = 44;
            static IPSecEncapsulatingSecurityPayload = 50;
            static IPSecAuthenticationHeader = 51;
            static IcmpV6 = 58;
            static IPv6NoNextHeader = 59;
            static IPv6DestinationOptions = 60;
            static ND = 77;
            static Raw = 255;
            static Ipx = 1000;
            static Spx = 1256;
            static SpxII = 1257;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "IP": 0n,
                    "IPv6HopByHopOptions": 0n,
                    "Unspecified": 0n,
                    "Icmp": 1n,
                    "Igmp": 2n,
                    "Ggp": 3n,
                    "IPv4": 4n,
                    "Tcp": 6n,
                    "Pup": 12n,
                    "Udp": 17n,
                    "Idp": 22n,
                    "IPv6": 41n,
                    "IPv6RoutingHeader": 43n,
                    "IPv6FragmentHeader": 44n,
                    "IPSecEncapsulatingSecurityPayload": 50n,
                    "IPSecAuthenticationHeader": 51n,
                    "IcmpV6": 58n,
                    "IPv6NoNextHeader": 59n,
                    "IPv6DestinationOptions": 60n,
                    "ND": 77n,
                    "Raw": 255n,
                    "Ipx": 1000n,
                    "Spx": 1256n,
                    "SpxII": 1257n
                };
            }
            static $h = 624038;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":624038,"n":"Unknown","d":624038,"h":4295591334,"f":33},{"t":624038,"n":"IP","d":624038,"h":8590558630,"f":33},{"t":624038,"n":"IPv6HopByHopOptions","d":624038,"h":12885525926,"f":33},{"t":624038,"n":"Unspecified","d":624038,"h":17180493222,"f":33},{"t":624038,"n":"Icmp","d":624038,"h":21475460518,"f":33},{"t":624038,"n":"Igmp","d":624038,"h":25770427814,"f":33},{"t":624038,"n":"Ggp","d":624038,"h":30065395110,"f":33},{"t":624038,"n":"IPv4","d":624038,"h":34360362406,"f":33},{"t":624038,"n":"Tcp","d":624038,"h":38655329702,"f":33},{"t":624038,"n":"Pup","d":624038,"h":42950296998,"f":33},{"t":624038,"n":"Udp","d":624038,"h":47245264294,"f":33},{"t":624038,"n":"Idp","d":624038,"h":51540231590,"f":33},{"t":624038,"n":"IPv6","d":624038,"h":55835198886,"f":33},{"t":624038,"n":"IPv6RoutingHeader","d":624038,"h":60130166182,"f":33},{"t":624038,"n":"IPv6FragmentHeader","d":624038,"h":64425133478,"f":33},{"t":624038,"n":"IPSecEncapsulatingSecurityPayload","d":624038,"h":68720100774,"f":33},{"t":624038,"n":"IPSecAuthenticationHeader","d":624038,"h":73015068070,"f":33},{"t":624038,"n":"IcmpV6","d":624038,"h":77310035366,"f":33},{"t":624038,"n":"IPv6NoNextHeader","d":624038,"h":81605002662,"f":33},{"t":624038,"n":"IPv6DestinationOptions","d":624038,"h":85899969958,"f":33},{"t":624038,"n":"ND","d":624038,"h":90194937254,"f":33},{"t":624038,"n":"Raw","d":624038,"h":94489904550,"f":33},{"t":624038,"n":"Ipx","d":624038,"h":98784871846,"f":33},{"t":624038,"n":"Spx","d":624038,"h":103079839142,"f":33},{"t":624038,"n":"SpxII","d":624038,"h":107374806438,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":624038,"h":111669773734,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":624038}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.ProtocolType`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SelectMode", ($self) => class SelectMode extends $.$spc.System.Enum
        {
            static SelectRead = 0;
            static SelectWrite = 1;
            static SelectError = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "SelectRead": 0n,
                    "SelectWrite": 1n,
                    "SelectError": 2n
                };
            }
            static $h = 755110;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":755110,"n":"SelectRead","d":755110,"h":4295722406,"f":33},{"t":755110,"n":"SelectWrite","d":755110,"h":8590689702,"f":33},{"t":755110,"n":"SelectError","d":755110,"h":12885656998,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":755110,"h":17180624294,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":755110}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SelectMode`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketAsyncOperation", ($self) => class SocketAsyncOperation extends $.$spc.System.Enum
        {
            static None = 0;
            static Accept = 1;
            static Connect = 2;
            static Disconnect = 3;
            static Receive = 4;
            static ReceiveFrom = 5;
            static ReceiveMessageFrom = 6;
            static Send = 7;
            static SendPackets = 8;
            static SendTo = 9;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Accept": 1n,
                    "Connect": 2n,
                    "Disconnect": 3n,
                    "Receive": 4n,
                    "ReceiveFrom": 5n,
                    "ReceiveMessageFrom": 6n,
                    "Send": 7n,
                    "SendPackets": 8n,
                    "SendTo": 9n
                };
            }
            static $h = 1017254;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1017254,"n":"None","d":1017254,"h":4295984550,"f":33},{"t":1017254,"n":"Accept","d":1017254,"h":8590951846,"f":33},{"t":1017254,"n":"Connect","d":1017254,"h":12885919142,"f":33},{"t":1017254,"n":"Disconnect","d":1017254,"h":17180886438,"f":33},{"t":1017254,"n":"Receive","d":1017254,"h":21475853734,"f":33},{"t":1017254,"n":"ReceiveFrom","d":1017254,"h":25770821030,"f":33},{"t":1017254,"n":"ReceiveMessageFrom","d":1017254,"h":30065788326,"f":33},{"t":1017254,"n":"Send","d":1017254,"h":34360755622,"f":33},{"t":1017254,"n":"SendPackets","d":1017254,"h":38655722918,"f":33},{"t":1017254,"n":"SendTo","d":1017254,"h":42950690214,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1017254,"h":47245657510,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1017254}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketAsyncOperation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketFlags", ($self) => class SocketFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static OutOfBand = 1;
            static Peek = 2;
            static DontRoute = 4;
            static Truncated = 256;
            static ControlDataTruncated = 512;
            static Broadcast = 1024;
            static Multicast = 2048;
            static Partial = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OutOfBand": 1n,
                    "Peek": 2n,
                    "DontRoute": 4n,
                    "Truncated": 256n,
                    "ControlDataTruncated": 512n,
                    "Broadcast": 1024n,
                    "Multicast": 2048n,
                    "Partial": 32768n
                };
            }
            static $h = 1082790;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1082790,"n":"None","d":1082790,"h":4296050086,"f":33},{"t":1082790,"n":"OutOfBand","d":1082790,"h":8591017382,"f":33},{"t":1082790,"n":"Peek","d":1082790,"h":12885984678,"f":33},{"t":1082790,"n":"DontRoute","d":1082790,"h":17180951974,"f":33},{"t":1082790,"n":"Truncated","d":1082790,"h":21475919270,"f":33},{"t":1082790,"n":"ControlDataTruncated","d":1082790,"h":25770886566,"f":33},{"t":1082790,"n":"Broadcast","d":1082790,"h":30065853862,"f":33},{"t":1082790,"n":"Multicast","d":1082790,"h":34360821158,"f":33},{"t":1082790,"n":"Partial","d":1082790,"h":38655788454,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1082790,"h":42950755750,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1082790,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketFlags`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketInformationOptions", ($self) => class SocketInformationOptions extends $.$spc.System.Enum
        {
            static NonBlocking = 1;
            static Connected = 2;
            static Listening = 4;
            static UseOnlyOverlappedIO = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NonBlocking": 1n,
                    "Connected": 2n,
                    "Listening": 4n,
                    "UseOnlyOverlappedIO": 8n
                };
            }
            static $h = 1213862;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1213862,"n":"NonBlocking","d":1213862,"h":4296181158,"f":33},{"t":1213862,"n":"Connected","d":1213862,"h":8591148454,"f":33},{"t":1213862,"n":"Listening","d":1213862,"h":12886115750,"f":33},{"t":1213862,"n":"UseOnlyOverlappedIO","d":1213862,"h":17181083046,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":8660844545,"a":[{"v":"SocketInformationOptions.UseOnlyOverlappedIO has been deprecated and is not supported.","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":1213862,"h":21476050342,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1213862,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketInformationOptions`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketOptionLevel", ($self) => class SocketOptionLevel extends $.$spc.System.Enum
        {
            static IP = 0;
            static Tcp = 6;
            static Udp = 17;
            static IPv6 = 41;
            static Socket = 65535;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "IP": 0n,
                    "Tcp": 6n,
                    "Udp": 17n,
                    "IPv6": 41n,
                    "Socket": 65535n
                };
            }
            static $h = 1279398;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1279398,"n":"IP","d":1279398,"h":4296246694,"f":33},{"t":1279398,"n":"Tcp","d":1279398,"h":8591213990,"f":33},{"t":1279398,"n":"Udp","d":1279398,"h":12886181286,"f":33},{"t":1279398,"n":"IPv6","d":1279398,"h":17181148582,"f":33},{"t":1279398,"n":"Socket","d":1279398,"h":21476115878,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1279398,"h":25771083174,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1279398}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketOptionLevel`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketOptionName", ($self) => class SocketOptionName extends $.$spc.System.Enum
        {
            static DontLinger = -129;
            static ExclusiveAddressUse = -5;
            static Debug = 1;
            static IPOptions = 1;
            static NoChecksum = 1;
            static NoDelay = 1;
            static AcceptConnection = 2;
            static BsdUrgent = 2;
            static Expedited = 2;
            static HeaderIncluded = 2;
            static TcpKeepAliveTime = 3;
            static TypeOfService = 3;
            static IpTimeToLive = 4;
            static ReuseAddress = 4;
            static KeepAlive = 8;
            static MulticastInterface = 9;
            static MulticastTimeToLive = 10;
            static MulticastLoopback = 11;
            static AddMembership = 12;
            static DropMembership = 13;
            static DontFragment = 14;
            static AddSourceMembership = 15;
            static FastOpen = 15;
            static DontRoute = 16;
            static DropSourceMembership = 16;
            static TcpKeepAliveRetryCount = 16;
            static BlockSource = 17;
            static TcpKeepAliveInterval = 17;
            static UnblockSource = 18;
            static PacketInformation = 19;
            static ChecksumCoverage = 20;
            static HopLimit = 21;
            static IPProtectionLevel = 23;
            static IPv6Only = 27;
            static Broadcast = 32;
            static UseLoopback = 64;
            static Linger = 128;
            static OutOfBandInline = 256;
            static SendBuffer = 4097;
            static ReceiveBuffer = 4098;
            static SendLowWater = 4099;
            static ReceiveLowWater = 4100;
            static SendTimeout = 4101;
            static ReceiveTimeout = 4102;
            static Error = 4103;
            static Type = 4104;
            static ReuseUnicastPort = 12295;
            static UpdateAcceptContext = 28683;
            static UpdateConnectContext = 28688;
            static MaxConnections = 2147483647;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "DontLinger": -129n,
                    "ExclusiveAddressUse": -5n,
                    "Debug": 1n,
                    "IPOptions": 1n,
                    "NoChecksum": 1n,
                    "NoDelay": 1n,
                    "AcceptConnection": 2n,
                    "BsdUrgent": 2n,
                    "Expedited": 2n,
                    "HeaderIncluded": 2n,
                    "TcpKeepAliveTime": 3n,
                    "TypeOfService": 3n,
                    "IpTimeToLive": 4n,
                    "ReuseAddress": 4n,
                    "KeepAlive": 8n,
                    "MulticastInterface": 9n,
                    "MulticastTimeToLive": 10n,
                    "MulticastLoopback": 11n,
                    "AddMembership": 12n,
                    "DropMembership": 13n,
                    "DontFragment": 14n,
                    "AddSourceMembership": 15n,
                    "FastOpen": 15n,
                    "DontRoute": 16n,
                    "DropSourceMembership": 16n,
                    "TcpKeepAliveRetryCount": 16n,
                    "BlockSource": 17n,
                    "TcpKeepAliveInterval": 17n,
                    "UnblockSource": 18n,
                    "PacketInformation": 19n,
                    "ChecksumCoverage": 20n,
                    "HopLimit": 21n,
                    "IPProtectionLevel": 23n,
                    "IPv6Only": 27n,
                    "Broadcast": 32n,
                    "UseLoopback": 64n,
                    "Linger": 128n,
                    "OutOfBandInline": 256n,
                    "SendBuffer": 4097n,
                    "ReceiveBuffer": 4098n,
                    "SendLowWater": 4099n,
                    "ReceiveLowWater": 4100n,
                    "SendTimeout": 4101n,
                    "ReceiveTimeout": 4102n,
                    "Error": 4103n,
                    "Type": 4104n,
                    "ReuseUnicastPort": 12295n,
                    "UpdateAcceptContext": 28683n,
                    "UpdateConnectContext": 28688n,
                    "MaxConnections": 2147483647n
                };
            }
            static $h = 1344934;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1344934,"n":"DontLinger","d":1344934,"h":4296312230,"f":33},{"t":1344934,"n":"ExclusiveAddressUse","d":1344934,"h":8591279526,"f":33},{"t":1344934,"n":"Debug","d":1344934,"h":12886246822,"f":33},{"t":1344934,"n":"IPOptions","d":1344934,"h":17181214118,"f":33},{"t":1344934,"n":"NoChecksum","d":1344934,"h":21476181414,"f":33},{"t":1344934,"n":"NoDelay","d":1344934,"h":25771148710,"f":33},{"t":1344934,"n":"AcceptConnection","d":1344934,"h":30066116006,"f":33},{"t":1344934,"n":"BsdUrgent","d":1344934,"h":34361083302,"f":33},{"t":1344934,"n":"Expedited","d":1344934,"h":38656050598,"f":33},{"t":1344934,"n":"HeaderIncluded","d":1344934,"h":42951017894,"f":33},{"t":1344934,"n":"TcpKeepAliveTime","d":1344934,"h":47245985190,"f":33},{"t":1344934,"n":"TypeOfService","d":1344934,"h":51540952486,"f":33},{"t":1344934,"n":"IpTimeToLive","d":1344934,"h":55835919782,"f":33},{"t":1344934,"n":"ReuseAddress","d":1344934,"h":60130887078,"f":33},{"t":1344934,"n":"KeepAlive","d":1344934,"h":64425854374,"f":33},{"t":1344934,"n":"MulticastInterface","d":1344934,"h":68720821670,"f":33},{"t":1344934,"n":"MulticastTimeToLive","d":1344934,"h":73015788966,"f":33},{"t":1344934,"n":"MulticastLoopback","d":1344934,"h":77310756262,"f":33},{"t":1344934,"n":"AddMembership","d":1344934,"h":81605723558,"f":33},{"t":1344934,"n":"DropMembership","d":1344934,"h":85900690854,"f":33},{"t":1344934,"n":"DontFragment","d":1344934,"h":90195658150,"f":33},{"t":1344934,"n":"AddSourceMembership","d":1344934,"h":94490625446,"f":33},{"t":1344934,"n":"FastOpen","d":1344934,"h":98785592742,"f":33},{"t":1344934,"n":"DontRoute","d":1344934,"h":103080560038,"f":33},{"t":1344934,"n":"DropSourceMembership","d":1344934,"h":107375527334,"f":33},{"t":1344934,"n":"TcpKeepAliveRetryCount","d":1344934,"h":111670494630,"f":33},{"t":1344934,"n":"BlockSource","d":1344934,"h":115965461926,"f":33},{"t":1344934,"n":"TcpKeepAliveInterval","d":1344934,"h":120260429222,"f":33},{"t":1344934,"n":"UnblockSource","d":1344934,"h":124555396518,"f":33},{"t":1344934,"n":"PacketInformation","d":1344934,"h":128850363814,"f":33},{"t":1344934,"n":"ChecksumCoverage","d":1344934,"h":133145331110,"f":33},{"t":1344934,"n":"HopLimit","d":1344934,"h":137440298406,"f":33},{"t":1344934,"n":"IPProtectionLevel","d":1344934,"h":141735265702,"f":33},{"t":1344934,"n":"IPv6Only","d":1344934,"h":146030232998,"f":33},{"t":1344934,"n":"Broadcast","d":1344934,"h":150325200294,"f":33},{"t":1344934,"n":"UseLoopback","d":1344934,"h":154620167590,"f":33},{"t":1344934,"n":"Linger","d":1344934,"h":158915134886,"f":33},{"t":1344934,"n":"OutOfBandInline","d":1344934,"h":163210102182,"f":33},{"t":1344934,"n":"SendBuffer","d":1344934,"h":167505069478,"f":33},{"t":1344934,"n":"ReceiveBuffer","d":1344934,"h":171800036774,"f":33},{"t":1344934,"n":"SendLowWater","d":1344934,"h":176095004070,"f":33},{"t":1344934,"n":"ReceiveLowWater","d":1344934,"h":180389971366,"f":33},{"t":1344934,"n":"SendTimeout","d":1344934,"h":184684938662,"f":33},{"t":1344934,"n":"ReceiveTimeout","d":1344934,"h":188979905958,"f":33},{"t":1344934,"n":"Error","d":1344934,"h":193274873254,"f":33},{"t":1344934,"n":"Type","d":1344934,"h":197569840550,"f":33},{"t":1344934,"n":"ReuseUnicastPort","d":1344934,"h":201864807846,"f":33},{"t":1344934,"n":"UpdateAcceptContext","d":1344934,"h":206159775142,"f":33},{"t":1344934,"n":"UpdateConnectContext","d":1344934,"h":210454742438,"f":33},{"t":1344934,"n":"MaxConnections","d":1344934,"h":214749709734,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1344934,"h":219044677030,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1344934}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketOptionName`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketShutdown", ($self) => class SocketShutdown extends $.$spc.System.Enum
        {
            static Receive = 0;
            static Send = 1;
            static Both = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Receive": 0n,
                    "Send": 1n,
                    "Both": 2n
                };
            }
            static $h = 1541542;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1541542,"n":"Receive","d":1541542,"h":4296508838,"f":33},{"t":1541542,"n":"Send","d":1541542,"h":8591476134,"f":33},{"t":1541542,"n":"Both","d":1541542,"h":12886443430,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1541542,"h":17181410726,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1541542}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketShutdown`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketType", ($self) => class SocketType extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static Stream = 1;
            static Dgram = 2;
            static Raw = 3;
            static Rdm = 4;
            static Seqpacket = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Stream": 1n,
                    "Dgram": 2n,
                    "Raw": 3n,
                    "Rdm": 4n,
                    "Seqpacket": 5n
                };
            }
            static $h = 1672614;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1672614,"n":"Unknown","d":1672614,"h":4296639910,"f":33},{"t":1672614,"n":"Stream","d":1672614,"h":8591607206,"f":33},{"t":1672614,"n":"Dgram","d":1672614,"h":12886574502,"f":33},{"t":1672614,"n":"Raw","d":1672614,"h":17181541798,"f":33},{"t":1672614,"n":"Rdm","d":1672614,"h":21476509094,"f":33},{"t":1672614,"n":"Seqpacket","d":1672614,"h":25771476390,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1672614,"h":30066443686,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1672614}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketType`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.TransmitFileOptions", ($self) => class TransmitFileOptions extends $.$spc.System.Enum
        {
            static UseDefaultWorkerThread = 0;
            static Disconnect = 1;
            static ReuseSocket = 2;
            static WriteBehind = 4;
            static UseSystemThread = 16;
            static UseKernelApc = 32;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "UseDefaultWorkerThread": 0n,
                    "Disconnect": 1n,
                    "ReuseSocket": 2n,
                    "WriteBehind": 4n,
                    "UseSystemThread": 16n,
                    "UseKernelApc": 32n
                };
            }
            static $h = 1869222;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1869222,"n":"UseDefaultWorkerThread","d":1869222,"h":4296836518,"f":33},{"t":1869222,"n":"Disconnect","d":1869222,"h":8591803814,"f":33},{"t":1869222,"n":"ReuseSocket","d":1869222,"h":12886771110,"f":33},{"t":1869222,"n":"WriteBehind","d":1869222,"h":17181738406,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":1869222,"n":"UseSystemThread","d":1869222,"h":21476705702,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":1869222,"n":"UseKernelApc","d":1869222,"h":25771672998,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":1869222,"h":30066640294,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1869222,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.TransmitFileOptions`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SafeSocketHandle", ($self) => class SafeSocketHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*nint*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 689574;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7405569,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180558758,"f":32769},"n":"IsInvalid","d":689574,"h":12885591462,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":689574,"h":21475526054,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":689574,"h":4295656870,"f":1},{"p":[{"n":"preexistingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":689574,"h":8590624166,"f":1}],"i":[57475073],"h":689574}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.SafeSocketHandle`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SocketAsyncEventArgs", ($self) => class SocketAsyncEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ unsafeSuppressExecutionContextFlow)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Sockets.Socket? */ get AcceptSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket? */ set AcceptSocket(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[]? */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IList<System.ArraySegment<byte>>? */ get BufferList()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IList<System.ArraySegment<byte>>? */ set BufferList(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get BytesTransferred()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Exception? */ get ConnectByNameError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket? */ get ConnectSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DisconnectReuseSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DisconnectReuseSocket(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketAsyncOperation */ get LastOperation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Memory<byte> */ get MemoryBuffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Offset()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.IPPacketInformation */ get ReceiveMessageFromPacketInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ set RemoteEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SendPacketsElement[]? */ get SendPacketsElements()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SendPacketsElement[]? */ set SendPacketsElements(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TransmitFileOptions */ get SendPacketsFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TransmitFileOptions */ set SendPacketsFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendPacketsSendSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendPacketsSendSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketError */ get SocketError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketError */ set SocketError(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketFlags */ get SocketFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketFlags */ set SocketFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ get UserToken()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ set UserToken(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.EventHandler<System.Net.Sockets.SocketAsyncEventArgs>?*/ Completed$add(value)
            {
            }
            /*System.EventHandler<System.Net.Sockets.SocketAsyncEventArgs>?*/ Completed$remove(value)
            {
            }
            /*void */ Dispose()
            {
            }
            $dtor()
            {
            }
            /*void */ OnCompleted(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
            }
            /*void */ SetBuffer(/*byte[]?*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ SetBuffer$1(/*int*/ offset, /*int*/ count)
            {
            }
            /*void */ SetBuffer$2(/*System.Memory<byte>*/ buffer)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 951718;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":886182,"g":{"r":0,"d":0,"h":17180820902,"f":1},"s":{"r":0,"d":0,"h":21475788198,"f":1},"n":"AcceptSocket","d":951718,"h":12885853606,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30065722790,"f":1},"n":"Buffer","d":951718,"h":25770755494,"f":1},{"p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h,"g":{"r":0,"d":0,"h":38655657382,"f":1},"s":{"r":0,"d":0,"h":42950624678,"f":1},"n":"BufferList","d":951718,"h":34360690086,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51540559270,"f":1},"n":"BytesTransferred","d":951718,"h":47245591974,"f":1},{"p":47185921,"g":{"r":0,"d":0,"h":60130493862,"f":1},"n":"ConnectByNameError","d":951718,"h":55835526566,"f":1},{"p":886182,"g":{"r":0,"d":0,"h":68720428454,"f":1},"n":"ConnectSocket","d":951718,"h":64425461158,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":77310363046,"f":1},"n":"Count","d":951718,"h":73015395750,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85900297638,"f":1},"s":{"r":0,"d":0,"h":90195264934,"f":1},"n":"DisconnectReuseSocket","d":951718,"h":81605330342,"f":1},{"p":1017254,"g":{"r":0,"d":0,"h":98785199526,"f":1},"n":"LastOperation","d":951718,"h":94490232230,"f":1},{"p":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":107375134118,"f":1},"n":"MemoryBuffer","d":951718,"h":103080166822,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":115965068710,"f":1},"n":"Offset","d":951718,"h":111670101414,"f":1},{"p":165286,"g":{"r":0,"d":0,"h":124555003302,"f":1},"n":"ReceiveMessageFromPacketInfo","d":951718,"h":120260036006,"f":1},{"p":2596827,"g":{"r":0,"d":0,"h":133144937894,"f":1},"s":{"r":0,"d":0,"h":137439905190,"f":1},"n":"RemoteEndPoint","d":951718,"h":128849970598,"f":1},{"p":0,"g":{"r":0,"d":0,"h":146029839782,"f":1},"s":{"r":0,"d":0,"h":150324807078,"f":1},"n":"SendPacketsElements","d":951718,"h":141734872486,"f":1},{"p":1869222,"g":{"r":0,"d":0,"h":158914741670,"f":1},"s":{"r":0,"d":0,"h":163209708966,"f":1},"n":"SendPacketsFlags","d":951718,"h":154619774374,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":171799643558,"f":1},"s":{"r":0,"d":0,"h":176094610854,"f":1},"n":"SendPacketsSendSize","d":951718,"h":167504676262,"f":1},{"p":4693979,"g":{"r":0,"d":0,"h":184684545446,"f":1},"s":{"r":0,"d":0,"h":188979512742,"f":1},"n":"SocketError","d":951718,"h":180389578150,"f":1},{"p":1082790,"g":{"r":0,"d":0,"h":197569447334,"f":1},"s":{"r":0,"d":0,"h":201864414630,"f":1},"n":"SocketFlags","d":951718,"h":193274480038,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":210454349222,"f":1},"s":{"r":0,"d":0,"h":214749316518,"f":1},"n":"UserToken","d":951718,"h":206159381926,"f":1}],"m":[{"r":65537,"n":"Dispose","d":951718,"h":231929185702,"f":1},{"r":65537,"p":[{"n":"e","p":951718}],"n":"OnCompleted","d":951718,"h":240519120294,"f":132},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"SetBuffer","d":951718,"h":244814087590,"f":1},{"r":65537,"p":[{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"SetBuffer","o":"@$1","d":951718,"h":249109054886,"f":1},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h}],"n":"SetBuffer","o":"@$2","d":951718,"h":253404022182,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":951718,"h":4295919014,"f":1},{"p":[{"n":"unsafeSuppressExecutionContextFlow","p":262145}],"n":".ctor","o":"$ctor$3","d":951718,"h":8590886310,"f":1}],"e":[{"e":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h}],"n":"add_Completed","d":951718,"h":223339251110,"f":1},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h}],"n":"remove_Completed","d":951718,"h":227634218406,"f":1},"n":"Completed","d":951718,"h":219044283814,"f":1}],"i":[57475073],"h":951718}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.SocketAsyncEventArgs`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Console", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.NameResolution"))