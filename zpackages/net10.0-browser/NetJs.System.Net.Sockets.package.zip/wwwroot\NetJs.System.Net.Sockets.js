
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stee, $scsl, $snv, $sri, $sl, $stt, $sttp, $sdd, $snp, $ssc, $sspw, $sto, $snnr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Sockets", 
    {"h":41016,"f":"System.Net.Sockets","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Sockets","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Sockets","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sns.System.Net.Sockets.IPv6MulticastOption", ($self) => class IPv6MulticastOption extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.IPAddress*/ group)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ group, /*long*/ ifindex)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get InterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set InterfaceIndex(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 303160;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3056114,"g":{"r":0,"d":0,"h":17180172344,"f":1},"s":{"r":0,"d":0,"h":21475139640,"f":1},"n":"Group","d":303160,"h":12885205048,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":30065074232,"f":1},"s":{"r":0,"d":0,"h":34360041528,"f":1},"n":"InterfaceIndex","d":303160,"h":25770106936,"f":1}],"c":[{"p":[{"n":"group","p":3056114}],"n":".ctor","o":"$ctor$1","d":303160,"h":4295270456,"f":1},{"p":[{"n":"group","p":3056114},{"n":"ifindex","p":917505}],"n":".ctor","o":"$ctor$2","d":303160,"h":8590237752,"f":1}],"h":303160}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.IPv6MulticastOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.LingerOption", ($self) => class LingerOption extends $.$spc.System.Object
        {
            $ctor$1(/*bool*/ enable, /*int*/ seconds)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Enabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Enabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get LingerTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set LingerTime(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.LingerOption.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.LingerOption.GetHashCode.apply(this, arguments); }
            static $h = 368696;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885270584,"f":1},"s":{"r":0,"d":0,"h":17180237880,"f":1},"n":"Enabled","d":368696,"h":8590303288,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25770172472,"f":1},"s":{"r":0,"d":0,"h":30065139768,"f":1},"n":"LingerTime","d":368696,"h":21475205176,"f":1}],"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":368696,"h":34360107064,"f":32769},{"r":655361,"n":"GetHashCode","d":368696,"h":38655074360,"f":32769}],"c":[{"p":[{"n":"enable","p":262145},{"n":"seconds","p":655361}],"n":".ctor","o":"$ctor$1","d":368696,"h":4295335992,"f":1}],"h":368696}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.LingerOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.MulticastOption", ($self) => class MulticastOption extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.IPAddress*/ group)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ group, /*int*/ interfaceIndex)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.IPAddress*/ group, /*System.Net.IPAddress*/ mcint)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InterfaceIndex(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress? */ get LocalAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress? */ set LocalAddress(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 434232;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3056114,"g":{"r":0,"d":0,"h":21475270712,"f":1},"s":{"r":0,"d":0,"h":25770238008,"f":1},"n":"Group","d":434232,"h":17180303416,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360172600,"f":1},"s":{"r":0,"d":0,"h":38655139896,"f":1},"n":"InterfaceIndex","d":434232,"h":30065205304,"f":1},{"p":3056114,"g":{"r":0,"d":0,"h":47245074488,"f":1},"s":{"r":0,"d":0,"h":51540041784,"f":1},"n":"LocalAddress","d":434232,"h":42950107192,"f":1}],"c":[{"p":[{"n":"group","p":3056114}],"n":".ctor","o":"$ctor$1","d":434232,"h":4295401528,"f":1},{"p":[{"n":"group","p":3056114},{"n":"interfaceIndex","p":655361}],"n":".ctor","o":"$ctor$2","d":434232,"h":8590368824,"f":1},{"p":[{"n":"group","p":3056114},{"n":"mcint","p":3056114}],"n":".ctor","o":"$ctor$3","d":434232,"h":12885336120,"f":1}],"h":434232}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.MulticastOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SendPacketsElement", ($self) => class SendPacketsElement extends $.$spc.System.Object
        {
            $ctor$1(/*byte[]*/ buffer)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.FileStream*/ fileStream)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.FileStream*/ fileStream, /*long*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.FileStream*/ fileStream, /*long*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$7(/*System.ReadOnlyMemory<byte>*/ buffer)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$8(/*System.ReadOnlyMemory<byte>*/ buffer, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$9(/*string*/ filepath)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$10(/*string*/ filepath, /*int*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$11(/*string*/ filepath, /*int*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$12(/*string*/ filepath, /*long*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$13(/*string*/ filepath, /*long*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*byte[]? */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EndOfPacket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FilePath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.FileStream? */ get FileStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ReadOnlyMemory<byte>? */ get MemoryBuffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Offset()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get OffsetLong()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 827448;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":64425336888,"f":1},"n":"Buffer","d":827448,"h":60130369592,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73015271480,"f":1},"n":"Count","d":827448,"h":68720304184,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81605206072,"f":1},"n":"EndOfPacket","d":827448,"h":77310238776,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90195140664,"f":1},"n":"FilePath","d":827448,"h":85900173368,"f":1},{"p":60358657,"g":{"r":0,"d":0,"h":98785075256,"f":1},"n":"FileStream","d":827448,"h":94490107960,"f":1},{"p":$.$typeNullable($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte)).$h,"g":{"r":0,"d":0,"h":107375009848,"f":1},"n":"MemoryBuffer","d":827448,"h":103080042552,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":115964944440,"f":1},"n":"Offset","d":827448,"h":111669977144,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":124554879032,"f":1},"n":"OffsetLong","d":827448,"h":120259911736,"f":1}],"c":[{"p":[{"n":"buffer","p":0}],"n":".ctor","o":"$ctor$1","d":827448,"h":4295794744,"f":1},{"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$2","d":827448,"h":8590762040,"f":1},{"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$3","d":827448,"h":12885729336,"f":1},{"p":[{"n":"fileStream","p":60358657}],"n":".ctor","o":"$ctor$4","d":827448,"h":17180696632,"f":1},{"p":[{"n":"fileStream","p":60358657},{"n":"offset","p":917505},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$5","d":827448,"h":21475663928,"f":1},{"p":[{"n":"fileStream","p":60358657},{"n":"offset","p":917505},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$6","d":827448,"h":25770631224,"f":1},{"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h}],"n":".ctor","o":"$ctor$7","d":827448,"h":30065598520,"f":1},{"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$8","d":827448,"h":34360565816,"f":1},{"p":[{"n":"filepath","p":1310721}],"n":".ctor","o":"$ctor$9","d":827448,"h":38655533112,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$10","d":827448,"h":42950500408,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$11","d":827448,"h":47245467704,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":917505},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$12","d":827448,"h":51540435000,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":917505},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$13","d":827448,"h":55835402296,"f":1}],"h":827448}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SendPacketsElement`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SocketTaskExtensions", ($self) => class SocketTaskExtensions
        {
            static /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync(/*this System.Net.Sockets.Socket*/ socket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.Sockets.Socket?*/ acceptSocket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$4(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$6(/*this System.Net.Sockets.Socket*/ socket, /*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$7(/*this System.Net.Sockets.Socket*/ socket, /*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ ReceiveAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ ReceiveAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<int> */ SendAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendToAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1613880;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"socket","p":892984}],"n":"AcceptAsync","d":1613880,"h":4296581176,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"socket","p":892984},{"n":"acceptSocket","p":892984}],"n":"AcceptAsync","o":"@$1","d":1613880,"h":8591548472,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":133300225,"p":[{"n":"socket","p":892984},{"n":"remoteEP","p":2597362}],"n":"ConnectAsync","d":1613880,"h":12886515768,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":136118273,"p":[{"n":"socket","p":892984},{"n":"remoteEP","p":2597362},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":1613880,"h":17181483064,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":133300225,"p":[{"n":"socket","p":892984},{"n":"address","p":3056114},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":1613880,"h":21476450360,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":136118273,"p":[{"n":"socket","p":892984},{"n":"address","p":3056114},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":1613880,"h":25771417656,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":133300225,"p":[{"n":"socket","p":892984},{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$4","d":1613880,"h":30066384952,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":136118273,"p":[{"n":"socket","p":892984},{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":1613880,"h":34361352248,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":133300225,"p":[{"n":"socket","p":892984},{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$6","d":1613880,"h":38656319544,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":136118273,"p":[{"n":"socket","p":892984},{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$7","d":1613880,"h":42951286840,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":892984},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592}],"n":"ReceiveAsync","d":1613880,"h":47246254136,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":892984},{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1089592}],"n":"ReceiveAsync","o":"@$1","d":1613880,"h":51541221432,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":892984},{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$2","d":1613880,"h":55836188728,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"socket","p":892984},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"remoteEndPoint","p":2597362}],"n":"ReceiveFromAsync","d":1613880,"h":60131156024,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"socket","p":892984},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"remoteEndPoint","p":2597362}],"n":"ReceiveMessageFromAsync","d":1613880,"h":64426123320,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":892984},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592}],"n":"SendAsync","d":1613880,"h":68721090616,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":892984},{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1089592}],"n":"SendAsync","o":"@$1","d":1613880,"h":73016057912,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":892984},{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$2","d":1613880,"h":77311025208,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":892984},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"remoteEP","p":2597362}],"n":"SendToAsync","d":1613880,"h":81605992504,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}],"h":1613880,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SocketTaskExtensions`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.Socket", ($self) => class Socket extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.Sockets.AddressFamily*/ addressFamily, /*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.Sockets.SafeSocketHandle*/ handle)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.Sockets.SocketInformation*/ socketInformation)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.Sockets.AddressFamily */ get AddressFamily()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Blocking()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Blocking(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Connected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DontFragment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DontFragment(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DualMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DualMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableBroadcast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableBroadcast(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*nint */ get Handle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsBound()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ get LingerState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ set LingerState(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get MulticastLoopback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MulticastLoopback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get NoDelay()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set NoDelay(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsIPv4()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsIPv6()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsUnixDomainSockets()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.ProtocolType */ get ProtocolType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SafeSocketHandle */ get SafeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketType */ get SocketType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get SupportsIPv4()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get SupportsIPv6()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ get Ttl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ set Ttl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseOnlyOverlappedIO()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseOnlyOverlappedIO(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ Accept()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync$1(/*System.Net.Sockets.Socket?*/ acceptSocket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptAsync$2(/*System.Net.Sockets.Socket?*/ acceptSocket, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ AcceptAsync$3(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptAsync$4(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept$1(/*int*/ receiveSize, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept$2(/*System.Net.Sockets.Socket?*/ acceptSocket, /*int*/ receiveSize, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect(/*System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$1(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$3(/*string*/ host, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginDisconnect(/*bool*/ reuseSocket, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceive(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginReceive$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceive$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginReceive$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceiveFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceiveMessageFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginSend$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginSend$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendFile(/*string?*/ fileName, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendFile$1(/*string?*/ fileName, /*byte[]?*/ preBuffer, /*byte[]?*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendTo(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Bind(/*System.Net.EndPoint*/ localEP)
            {
            }
            static /*void */ CancelConnectAsync(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
            }
            /*void */ Close()
            {
            }
            /*void */ Close$1(/*int*/ timeout)
            {
            }
            /*void */ Connect(/*System.Net.EndPoint*/ remoteEP)
            {
            }
            /*void */ Connect$1(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
            }
            /*void */ Connect$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
            }
            /*void */ Connect$3(/*string*/ host, /*int*/ port)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync(/*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ConnectAsync$6(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ ConnectAsync$7(/*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType, /*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$8(/*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$9(/*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Disconnect(/*bool*/ reuseSocket)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisconnectAsync(/*bool*/ reuseSocket, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ DisconnectAsync$1(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Net.Sockets.SocketInformation */ DuplicateAndClose(/*int*/ targetProcessId)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept(/*out byte[]*/ buffer, /*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept$1(/*out byte[]*/ buffer, /*out int*/ bytesTransferred, /*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept$2(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndConnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndDisconnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndReceive(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceive$1(/*System.IAsyncResult*/ asyncResult, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceiveFrom(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.EndPoint*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceiveMessageFrom(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ endPoint, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend$1(/*System.IAsyncResult*/ asyncResult, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndSendFile(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndSendTo(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            /*int */ GetRawSocketOption(/*int*/ optionLevel, /*int*/ optionName, /*System.Span<byte>*/ optionValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ GetSocketOption(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetSocketOption$1(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*byte[]*/ optionValue)
            {
            }
            /*byte[] */ GetSocketOption$2(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*int*/ optionLength)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ IOControl(/*int*/ ioControlCode, /*byte[]?*/ optionInValue, /*byte[]?*/ optionOutValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ IOControl$1(/*System.Net.Sockets.IOControlCode*/ ioControlCode, /*byte[]?*/ optionInValue, /*byte[]?*/ optionOutValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Listen()
            {
            }
            /*void */ Listen$1(/*int*/ backlog)
            {
            }
            /*bool */ Poll(/*int*/ microSeconds, /*System.Net.Sockets.SelectMode*/ mode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Poll$1(/*System.TimeSpan*/ timeout, /*System.Net.Sockets.SelectMode*/ mode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive(/*byte[]*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$3(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$4(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$5(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$6(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$7(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$8(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$9(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$10(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync(/*System.ArraySegment<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$4(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$5(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveAsync$6(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$1(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$2(/*byte[]*/ buffer, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$4(/*System.Span<byte>*/ buffer, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$5(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$6(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ receivedAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$2(/*System.Memory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$3(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveFromAsync$4(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ receivedAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveFromAsync$5(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveMessageFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveMessageFrom$1(/*System.Span<byte>*/ buffer, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$2(/*System.Memory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$3(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveMessageFromAsync$4(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ Select(/*System.Collections.IList?*/ checkRead, /*System.Collections.IList?*/ checkWrite, /*System.Collections.IList?*/ checkError, /*int*/ microSeconds)
            {
            }
            static /*void */ Select$1(/*System.Collections.IList?*/ checkRead, /*System.Collections.IList?*/ checkWrite, /*System.Collections.IList?*/ checkError, /*System.TimeSpan*/ timeout)
            {
            }
            /*int */ Send(/*byte[]*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$3(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$4(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$5(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$6(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$7(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$8(/*System.ReadOnlySpan<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$9(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$10(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync(/*System.ArraySegment<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendAsync$4(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$5(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$6(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SendFile(/*string?*/ fileName)
            {
            }
            /*void */ SendFile$1(/*string?*/ fileName, /*byte[]?*/ preBuffer, /*byte[]?*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags)
            {
            }
            /*void */ SendFile$2(/*string?*/ fileName, /*System.ReadOnlySpan<byte>*/ preBuffer, /*System.ReadOnlySpan<byte>*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags)
            {
            }
            /*System.Threading.Tasks.ValueTask */ SendFileAsync(/*string?*/ fileName, /*System.ReadOnlyMemory<byte>*/ preBuffer, /*System.ReadOnlyMemory<byte>*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ SendFileAsync$1(/*string?*/ fileName, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendPacketsAsync(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$1(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$2(/*byte[]*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$4(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$5(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$6(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ socketAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendToAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendToAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendToAsync$2(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$3(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$4(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$5(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ socketAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetIPProtectionLevel(/*System.Net.Sockets.IPProtectionLevel*/ level)
            {
            }
            /*void */ SetRawSocketOption(/*int*/ optionLevel, /*int*/ optionName, /*System.ReadOnlySpan<byte>*/ optionValue)
            {
            }
            /*void */ SetSocketOption(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*bool*/ optionValue)
            {
            }
            /*void */ SetSocketOption$1(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*byte[]*/ optionValue)
            {
            }
            /*void */ SetSocketOption$2(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*int*/ optionValue)
            {
            }
            /*void */ SetSocketOption$3(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*object*/ optionValue)
            {
            }
            /*void */ Shutdown(/*System.Net.Sockets.SocketShutdown*/ how)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 892984;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4497906,"g":{"r":0,"d":0,"h":25770696760,"f":1},"n":"AddressFamily","d":892984,"h":21475729464,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360631352,"f":1},"n":"Available","d":892984,"h":30065664056,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950565944,"f":1},"s":{"r":0,"d":0,"h":47245533240,"f":1},"n":"Blocking","d":892984,"h":38655598648,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55835467832,"f":1},"n":"Connected","d":892984,"h":51540500536,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64425402424,"f":1},"s":{"r":0,"d":0,"h":68720369720,"f":1},"n":"DontFragment","d":892984,"h":60130435128,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77310304312,"f":1},"s":{"r":0,"d":0,"h":81605271608,"f":1},"n":"DualMode","d":892984,"h":73015337016,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":90195206200,"f":1},"s":{"r":0,"d":0,"h":94490173496,"f":1},"n":"EnableBroadcast","d":892984,"h":85900238904,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":103080108088,"f":1},"s":{"r":0,"d":0,"h":107375075384,"f":1},"n":"ExclusiveAddressUse","d":892984,"h":98785140792,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":115965009976,"f":1},"n":"Handle","d":892984,"h":111670042680,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554944568,"f":1},"n":"IsBound","d":892984,"h":120259977272,"f":1},{"p":368696,"g":{"r":0,"d":0,"h":133144879160,"f":1},"s":{"r":0,"d":0,"h":137439846456,"f":1},"n":"LingerState","d":892984,"h":128849911864,"f":1},{"p":2597362,"g":{"r":0,"d":0,"h":146029781048,"f":1},"n":"LocalEndPoint","d":892984,"h":141734813752,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":154619715640,"f":1},"s":{"r":0,"d":0,"h":158914682936,"f":1},"n":"MulticastLoopback","d":892984,"h":150324748344,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":167504617528,"f":1},"s":{"r":0,"d":0,"h":171799584824,"f":1},"n":"NoDelay","d":892984,"h":163209650232,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":180389519416,"f":33},"n":"OSSupportsIPv4","d":892984,"h":176094552120,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":188979454008,"f":33},"n":"OSSupportsIPv6","d":892984,"h":184684486712,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":197569388600,"f":33},"n":"OSSupportsUnixDomainSockets","d":892984,"h":193274421304,"f":33},{"p":630840,"g":{"r":0,"d":0,"h":206159323192,"f":1},"n":"ProtocolType","d":892984,"h":201864355896,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":214749257784,"f":1},"s":{"r":0,"d":0,"h":219044225080,"f":1},"n":"ReceiveBufferSize","d":892984,"h":210454290488,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":227634159672,"f":1},"s":{"r":0,"d":0,"h":231929126968,"f":1},"n":"ReceiveTimeout","d":892984,"h":223339192376,"f":1},{"p":2597362,"g":{"r":0,"d":0,"h":240519061560,"f":1},"n":"RemoteEndPoint","d":892984,"h":236224094264,"f":1},{"p":696376,"g":{"r":0,"d":0,"h":249108996152,"f":1},"n":"SafeHandle","d":892984,"h":244814028856,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":257698930744,"f":1},"s":{"r":0,"d":0,"h":261993898040,"f":1},"n":"SendBufferSize","d":892984,"h":253403963448,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":270583832632,"f":1},"s":{"r":0,"d":0,"h":274878799928,"f":1},"n":"SendTimeout","d":892984,"h":266288865336,"f":1},{"p":1679416,"g":{"r":0,"d":0,"h":283468734520,"f":1},"n":"SocketType","d":892984,"h":279173767224,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":292058669112,"f":33},"n":"SupportsIPv4","d":892984,"h":287763701816,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SupportsIPv4 has been deprecated. Use OSSupportsIPv4 instead.","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":300648603704,"f":33},"n":"SupportsIPv6","d":892984,"h":296353636408,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SupportsIPv6 has been deprecated. Use OSSupportsIPv6 instead.","t":1310721}]}]},{"p":524289,"g":{"r":0,"d":0,"h":309238538296,"f":1},"s":{"r":0,"d":0,"h":313533505592,"f":1},"n":"Ttl","d":892984,"h":304943571000,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":322123440184,"f":1},"s":{"r":0,"d":0,"h":326418407480,"f":1},"n":"UseOnlyOverlappedIO","d":892984,"h":317828472888,"f":1,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":70909953,"c":8660844545,"a":[{"v":"UseOnlyOverlappedIO has been deprecated and is not supported.","t":1310721}]}]}],"m":[{"r":892984,"n":"Accept","d":892984,"h":330713374776,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"n":"AcceptAsync","d":892984,"h":335008342072,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"acceptSocket","p":892984}],"n":"AcceptAsync","o":"@$1","d":892984,"h":339303309368,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"acceptSocket","p":892984},{"n":"cancellationToken","p":125960193}],"n":"AcceptAsync","o":"@$2","d":892984,"h":343598276664,"f":1},{"r":262145,"p":[{"n":"e","p":958520}],"n":"AcceptAsync","o":"@$3","d":892984,"h":347893243960,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptAsync","o":"@$4","d":892984,"h":352188211256,"f":1},{"r":57016321,"p":[{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginAccept","d":892984,"h":356483178552,"f":1},{"r":57016321,"p":[{"n":"receiveSize","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginAccept","o":"@$1","d":892984,"h":360778145848,"f":1},{"r":57016321,"p":[{"n":"acceptSocket","p":892984},{"n":"receiveSize","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginAccept","o":"@$2","d":892984,"h":365073113144,"f":1},{"r":57016321,"p":[{"n":"remoteEP","p":2597362},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginConnect","d":892984,"h":369368080440,"f":1},{"r":57016321,"p":[{"n":"address","p":3056114},{"n":"port","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$1","d":892984,"h":373663047736,"f":1},{"r":57016321,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$2","d":892984,"h":377958015032,"f":1},{"r":57016321,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$3","d":892984,"h":382252982328,"f":1},{"r":57016321,"p":[{"n":"reuseSocket","p":262145},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginDisconnect","d":892984,"h":386547949624,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1089592},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginReceive","d":892984,"h":390842916920,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1089592},{"n":"errorCode","p":4694514,"f":2},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$1","d":892984,"h":395137884216,"f":1},{"r":57016321,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1089592},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$2","d":892984,"h":399432851512,"f":1},{"r":57016321,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1089592},{"n":"errorCode","p":4694514,"f":2},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$3","d":892984,"h":403727818808,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1089592},{"n":"remoteEP","p":2597362,"f":4},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginReceiveFrom","d":892984,"h":408022786104,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1089592},{"n":"remoteEP","p":2597362,"f":4},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginReceiveMessageFrom","d":892984,"h":412317753400,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1089592},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginSend","d":892984,"h":416612720696,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1089592},{"n":"errorCode","p":4694514,"f":2},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginSend","o":"@$1","d":892984,"h":420907687992,"f":1},{"r":57016321,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1089592},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginSend","o":"@$2","d":892984,"h":425202655288,"f":1},{"r":57016321,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1089592},{"n":"errorCode","p":4694514,"f":2},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginSend","o":"@$3","d":892984,"h":429497622584,"f":1},{"r":57016321,"p":[{"n":"fileName","p":1310721},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginSendFile","d":892984,"h":433792589880,"f":1},{"r":57016321,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":0},{"n":"postBuffer","p":0},{"n":"flags","p":1876024},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginSendFile","o":"@$1","d":892984,"h":438087557176,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1089592},{"n":"remoteEP","p":2597362},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginSendTo","d":892984,"h":442382524472,"f":1},{"r":65537,"p":[{"n":"localEP","p":2597362}],"n":"Bind","d":892984,"h":446677491768,"f":1},{"r":65537,"p":[{"n":"e","p":958520}],"n":"CancelConnectAsync","d":892984,"h":450972459064,"f":33},{"r":65537,"n":"Close","d":892984,"h":455267426360,"f":1},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Close","o":"@$1","d":892984,"h":459562393656,"f":1},{"r":65537,"p":[{"n":"remoteEP","p":2597362}],"n":"Connect","d":892984,"h":463857360952,"f":1},{"r":65537,"p":[{"n":"address","p":3056114},{"n":"port","p":655361}],"n":"Connect","o":"@$1","d":892984,"h":468152328248,"f":1},{"r":65537,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"Connect","o":"@$2","d":892984,"h":472447295544,"f":1},{"r":65537,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$3","d":892984,"h":476742262840,"f":1},{"r":133300225,"p":[{"n":"remoteEP","p":2597362}],"n":"ConnectAsync","d":892984,"h":481037230136,"f":1},{"r":136118273,"p":[{"n":"remoteEP","p":2597362},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":892984,"h":485332197432,"f":1},{"r":133300225,"p":[{"n":"address","p":3056114},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":892984,"h":489627164728,"f":1},{"r":136118273,"p":[{"n":"address","p":3056114},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":892984,"h":493922132024,"f":1},{"r":133300225,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$4","d":892984,"h":498217099320,"f":1},{"r":136118273,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":892984,"h":502512066616,"f":1},{"r":262145,"p":[{"n":"e","p":958520}],"n":"ConnectAsync","o":"@$6","d":892984,"h":506807033912,"f":1},{"r":262145,"p":[{"n":"socketType","p":1679416},{"n":"protocolType","p":630840},{"n":"e","p":958520}],"n":"ConnectAsync","o":"@$7","d":892984,"h":511102001208,"f":33},{"r":133300225,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$8","d":892984,"h":515396968504,"f":1},{"r":136118273,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$9","d":892984,"h":519691935800,"f":1},{"r":65537,"p":[{"n":"reuseSocket","p":262145}],"n":"Disconnect","d":892984,"h":523986903096,"f":1},{"r":136118273,"p":[{"n":"reuseSocket","p":262145},{"n":"cancellationToken","p":125960193,"f":65}],"n":"DisconnectAsync","d":892984,"h":528281870392,"f":1},{"r":262145,"p":[{"n":"e","p":958520}],"n":"DisconnectAsync","o":"@$1","d":892984,"h":532576837688,"f":1},{"r":65537,"n":"Dispose","d":892984,"h":536871804984,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":892984,"h":541166772280,"f":132},{"r":1155128,"p":[{"n":"targetProcessId","p":655361}],"n":"DuplicateAndClose","d":892984,"h":545461739576,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":892984,"p":[{"n":"buffer","p":0,"f":2},{"n":"asyncResult","p":57016321}],"n":"EndAccept","d":892984,"h":549756706872,"f":1},{"r":892984,"p":[{"n":"buffer","p":0,"f":2},{"n":"bytesTransferred","p":655361,"f":2},{"n":"asyncResult","p":57016321}],"n":"EndAccept","o":"@$1","d":892984,"h":554051674168,"f":1},{"r":892984,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAccept","o":"@$2","d":892984,"h":558346641464,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndConnect","d":892984,"h":562641608760,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndDisconnect","d":892984,"h":566936576056,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndReceive","d":892984,"h":571231543352,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321},{"n":"errorCode","p":4694514,"f":2}],"n":"EndReceive","o":"@$1","d":892984,"h":575526510648,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321},{"n":"endPoint","p":2597362,"f":4}],"n":"EndReceiveFrom","d":892984,"h":579821477944,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321},{"n":"socketFlags","p":1089592,"f":4},{"n":"endPoint","p":2597362,"f":4},{"n":"ipPacketInformation","p":172088,"f":2}],"n":"EndReceiveMessageFrom","d":892984,"h":584116445240,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndSend","d":892984,"h":588411412536,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321},{"n":"errorCode","p":4694514,"f":2}],"n":"EndSend","o":"@$1","d":892984,"h":592706379832,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndSendFile","d":892984,"h":597001347128,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndSendTo","d":892984,"h":601296314424,"f":1},{"r":655361,"p":[{"n":"optionLevel","p":655361},{"n":"optionName","p":655361},{"n":"optionValue","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetRawSocketOption","d":892984,"h":609886249016,"f":1},{"r":131073,"p":[{"n":"optionLevel","p":1286200},{"n":"optionName","p":1351736}],"n":"GetSocketOption","d":892984,"h":614181216312,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1286200},{"n":"optionName","p":1351736},{"n":"optionValue","p":0}],"n":"GetSocketOption","o":"@$1","d":892984,"h":618476183608,"f":1},{"r":0,"p":[{"n":"optionLevel","p":1286200},{"n":"optionName","p":1351736},{"n":"optionLength","p":655361}],"n":"GetSocketOption","o":"@$2","d":892984,"h":622771150904,"f":1},{"r":655361,"p":[{"n":"ioControlCode","p":655361},{"n":"optionInValue","p":0},{"n":"optionOutValue","p":0}],"n":"IOControl","d":892984,"h":627066118200,"f":1},{"r":655361,"p":[{"n":"ioControlCode","p":106552},{"n":"optionInValue","p":0},{"n":"optionOutValue","p":0}],"n":"IOControl","o":"@$1","d":892984,"h":631361085496,"f":1},{"r":65537,"n":"Listen","d":892984,"h":635656052792,"f":1},{"r":65537,"p":[{"n":"backlog","p":655361}],"n":"Listen","o":"@$1","d":892984,"h":639951020088,"f":1},{"r":262145,"p":[{"n":"microSeconds","p":655361},{"n":"mode","p":761912}],"n":"Poll","d":892984,"h":644245987384,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793},{"n":"mode","p":761912}],"n":"Poll","o":"@$1","d":892984,"h":648540954680,"f":1},{"r":655361,"p":[{"n":"buffer","p":0}],"n":"Receive","d":892984,"h":652835921976,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1089592}],"n":"Receive","o":"@$1","d":892984,"h":657130889272,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1089592},{"n":"errorCode","p":4694514,"f":2}],"n":"Receive","o":"@$2","d":892984,"h":661425856568,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1089592}],"n":"Receive","o":"@$3","d":892984,"h":665720823864,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1089592}],"n":"Receive","o":"@$4","d":892984,"h":670015791160,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"Receive","o":"@$5","d":892984,"h":674310758456,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1089592}],"n":"Receive","o":"@$6","d":892984,"h":678605725752,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1089592},{"n":"errorCode","p":4694514,"f":2}],"n":"Receive","o":"@$7","d":892984,"h":682900693048,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Receive","o":"@$8","d":892984,"h":687195660344,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592}],"n":"Receive","o":"@$9","d":892984,"h":691490627640,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"errorCode","p":4694514,"f":2}],"n":"Receive","o":"@$10","d":892984,"h":695785594936,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h}],"n":"ReceiveAsync","d":892984,"h":700080562232,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592}],"n":"ReceiveAsync","o":"@$1","d":892984,"h":704375529528,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"ReceiveAsync","o":"@$2","d":892984,"h":708670496824,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1089592}],"n":"ReceiveAsync","o":"@$3","d":892984,"h":712965464120,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$4","d":892984,"h":717260431416,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$5","d":892984,"h":721555398712,"f":1},{"r":262145,"p":[{"n":"e","p":958520}],"n":"ReceiveAsync","o":"@$6","d":892984,"h":725850366008,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1089592},{"n":"remoteEP","p":2597362,"f":4}],"n":"ReceiveFrom","d":892984,"h":730145333304,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1089592},{"n":"remoteEP","p":2597362,"f":4}],"n":"ReceiveFrom","o":"@$1","d":892984,"h":734440300600,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"remoteEP","p":2597362,"f":4}],"n":"ReceiveFrom","o":"@$2","d":892984,"h":738735267896,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1089592},{"n":"remoteEP","p":2597362,"f":4}],"n":"ReceiveFrom","o":"@$3","d":892984,"h":743030235192,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2597362,"f":4}],"n":"ReceiveFrom","o":"@$4","d":892984,"h":747325202488,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"remoteEP","p":2597362,"f":4}],"n":"ReceiveFrom","o":"@$5","d":892984,"h":751620169784,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"receivedAddress","p":4366834}],"n":"ReceiveFrom","o":"@$6","d":892984,"h":755915137080,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2597362}],"n":"ReceiveFromAsync","d":892984,"h":760210104376,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"remoteEndPoint","p":2597362}],"n":"ReceiveFromAsync","o":"@$1","d":892984,"h":764505071672,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2597362},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$2","d":892984,"h":768800038968,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"remoteEndPoint","p":2597362},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$3","d":892984,"h":773095006264,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"receivedAddress","p":4366834},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$4","d":892984,"h":777389973560,"f":1},{"r":262145,"p":[{"n":"e","p":958520}],"n":"ReceiveFromAsync","o":"@$5","d":892984,"h":781684940856,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1089592,"f":4},{"n":"remoteEP","p":2597362,"f":4},{"n":"ipPacketInformation","p":172088,"f":2}],"n":"ReceiveMessageFrom","d":892984,"h":785979908152,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592,"f":4},{"n":"remoteEP","p":2597362,"f":4},{"n":"ipPacketInformation","p":172088,"f":2}],"n":"ReceiveMessageFrom","o":"@$1","d":892984,"h":790274875448,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2597362}],"n":"ReceiveMessageFromAsync","d":892984,"h":794569842744,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"remoteEndPoint","p":2597362}],"n":"ReceiveMessageFromAsync","o":"@$1","d":892984,"h":798864810040,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2597362},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveMessageFromAsync","o":"@$2","d":892984,"h":803159777336,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"remoteEndPoint","p":2597362},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveMessageFromAsync","o":"@$3","d":892984,"h":807454744632,"f":1},{"r":262145,"p":[{"n":"e","p":958520}],"n":"ReceiveMessageFromAsync","o":"@$4","d":892984,"h":811749711928,"f":1},{"r":65537,"p":[{"n":"checkRead","p":31981569},{"n":"checkWrite","p":31981569},{"n":"checkError","p":31981569},{"n":"microSeconds","p":655361}],"n":"Select","d":892984,"h":816044679224,"f":33},{"r":65537,"p":[{"n":"checkRead","p":31981569},{"n":"checkWrite","p":31981569},{"n":"checkError","p":31981569},{"n":"timeout","p":140705793}],"n":"Select","o":"@$1","d":892984,"h":820339646520,"f":33},{"r":655361,"p":[{"n":"buffer","p":0}],"n":"Send","d":892984,"h":824634613816,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1089592}],"n":"Send","o":"@$1","d":892984,"h":828929581112,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1089592},{"n":"errorCode","p":4694514,"f":2}],"n":"Send","o":"@$2","d":892984,"h":833224548408,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1089592}],"n":"Send","o":"@$3","d":892984,"h":837519515704,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1089592}],"n":"Send","o":"@$4","d":892984,"h":841814483000,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"Send","o":"@$5","d":892984,"h":846109450296,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1089592}],"n":"Send","o":"@$6","d":892984,"h":850404417592,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1089592},{"n":"errorCode","p":4694514,"f":2}],"n":"Send","o":"@$7","d":892984,"h":854699384888,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Send","o":"@$8","d":892984,"h":858994352184,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592}],"n":"Send","o":"@$9","d":892984,"h":863289319480,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"errorCode","p":4694514,"f":2}],"n":"Send","o":"@$10","d":892984,"h":867584286776,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h}],"n":"SendAsync","d":892984,"h":871879254072,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592}],"n":"SendAsync","o":"@$1","d":892984,"h":876174221368,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"SendAsync","o":"@$2","d":892984,"h":880469188664,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1089592}],"n":"SendAsync","o":"@$3","d":892984,"h":884764155960,"f":1},{"r":262145,"p":[{"n":"e","p":958520}],"n":"SendAsync","o":"@$4","d":892984,"h":889059123256,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$5","d":892984,"h":893354090552,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$6","d":892984,"h":897649057848,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"SendFile","d":892984,"h":901944025144,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":0},{"n":"postBuffer","p":0},{"n":"flags","p":1876024}],"n":"SendFile","o":"@$1","d":892984,"h":906238992440,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"postBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"flags","p":1876024}],"n":"SendFile","o":"@$2","d":892984,"h":910533959736,"f":1},{"r":136118273,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"postBuffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"flags","p":1876024},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendFileAsync","d":892984,"h":914828927032,"f":1},{"r":136118273,"p":[{"n":"fileName","p":1310721},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendFileAsync","o":"@$1","d":892984,"h":919123894328,"f":1},{"r":262145,"p":[{"n":"e","p":958520}],"n":"SendPacketsAsync","d":892984,"h":923418861624,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1089592},{"n":"remoteEP","p":2597362}],"n":"SendTo","d":892984,"h":927713828920,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1089592},{"n":"remoteEP","p":2597362}],"n":"SendTo","o":"@$1","d":892984,"h":932008796216,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"remoteEP","p":2597362}],"n":"SendTo","o":"@$2","d":892984,"h":936303763512,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1089592},{"n":"remoteEP","p":2597362}],"n":"SendTo","o":"@$3","d":892984,"h":940598730808,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2597362}],"n":"SendTo","o":"@$4","d":892984,"h":944893698104,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"remoteEP","p":2597362}],"n":"SendTo","o":"@$5","d":892984,"h":949188665400,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"socketAddress","p":4366834}],"n":"SendTo","o":"@$6","d":892984,"h":953483632696,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2597362}],"n":"SendToAsync","d":892984,"h":957778599992,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"remoteEP","p":2597362}],"n":"SendToAsync","o":"@$1","d":892984,"h":962073567288,"f":1},{"r":262145,"p":[{"n":"e","p":958520}],"n":"SendToAsync","o":"@$2","d":892984,"h":966368534584,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2597362},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$3","d":892984,"h":970663501880,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"remoteEP","p":2597362},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$4","d":892984,"h":974958469176,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1089592},{"n":"socketAddress","p":4366834},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$5","d":892984,"h":979253436472,"f":1},{"r":65537,"p":[{"n":"level","p":237624}],"n":"SetIPProtectionLevel","d":892984,"h":983548403768,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"optionLevel","p":655361},{"n":"optionName","p":655361},{"n":"optionValue","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"SetRawSocketOption","d":892984,"h":987843371064,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1286200},{"n":"optionName","p":1351736},{"n":"optionValue","p":262145}],"n":"SetSocketOption","d":892984,"h":992138338360,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1286200},{"n":"optionName","p":1351736},{"n":"optionValue","p":0}],"n":"SetSocketOption","o":"@$1","d":892984,"h":996433305656,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1286200},{"n":"optionName","p":1351736},{"n":"optionValue","p":655361}],"n":"SetSocketOption","o":"@$2","d":892984,"h":1000728272952,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1286200},{"n":"optionName","p":1351736},{"n":"optionValue","p":131073}],"n":"SetSocketOption","o":"@$3","d":892984,"h":1005023240248,"f":1},{"r":65537,"p":[{"n":"how","p":1548344}],"n":"Shutdown","d":892984,"h":1009318207544,"f":1}],"c":[{"p":[{"n":"addressFamily","p":4497906},{"n":"socketType","p":1679416},{"n":"protocolType","p":630840}],"n":".ctor","o":"$ctor$1","d":892984,"h":4295860280,"f":1},{"p":[{"n":"handle","p":696376}],"n":".ctor","o":"$ctor$2","d":892984,"h":8590827576,"f":1},{"p":[{"n":"socketInformation","p":1155128}],"n":".ctor","o":"$ctor$3","d":892984,"h":12885794872,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":[{"n":"socketType","p":1679416},{"n":"protocolType","p":630840}],"n":".ctor","o":"$ctor$4","d":892984,"h":17180762168,"f":1}],"i":[57540609],"h":892984}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.Socket`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.TcpClient", ($self) => class TcpClient extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ hostname, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Active(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Client()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ set Client(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Connected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ get LingerState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ set LingerState(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get NoDelay()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set NoDelay(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$1(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$2(/*string*/ host, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close()
            {
            }
            /*void */ Connect(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
            }
            /*void */ Connect$1(/*System.Net.IPAddress[]*/ ipAddresses, /*int*/ port)
            {
            }
            /*void */ Connect$2(/*System.Net.IPEndPoint*/ remoteEP)
            {
            }
            /*void */ Connect$3(/*string*/ hostname, /*int*/ port)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Net.IPEndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*System.Net.IPEndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$6(/*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$7(/*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ EndConnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*System.Net.Sockets.NetworkStream */ GetStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1744952;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25771548728,"f":4},"s":{"r":0,"d":0,"h":30066516024,"f":4},"n":"Active","d":1744952,"h":21476581432,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":38656450616,"f":1},"n":"Available","d":1744952,"h":34361483320,"f":1},{"p":892984,"g":{"r":0,"d":0,"h":47246385208,"f":1},"s":{"r":0,"d":0,"h":51541352504,"f":1},"n":"Client","d":1744952,"h":42951417912,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131287096,"f":1},"n":"Connected","d":1744952,"h":55836319800,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721221688,"f":1},"s":{"r":0,"d":0,"h":73016188984,"f":1},"n":"ExclusiveAddressUse","d":1744952,"h":64426254392,"f":1},{"p":368696,"g":{"r":0,"d":0,"h":81606123576,"f":1},"s":{"r":0,"d":0,"h":85901090872,"f":1},"n":"LingerState","d":1744952,"h":77311156280,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94491025464,"f":1},"s":{"r":0,"d":0,"h":98785992760,"f":1},"n":"NoDelay","d":1744952,"h":90196058168,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":107375927352,"f":1},"s":{"r":0,"d":0,"h":111670894648,"f":1},"n":"ReceiveBufferSize","d":1744952,"h":103080960056,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":120260829240,"f":1},"s":{"r":0,"d":0,"h":124555796536,"f":1},"n":"ReceiveTimeout","d":1744952,"h":115965861944,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":133145731128,"f":1},"s":{"r":0,"d":0,"h":137440698424,"f":1},"n":"SendBufferSize","d":1744952,"h":128850763832,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":146030633016,"f":1},"s":{"r":0,"d":0,"h":150325600312,"f":1},"n":"SendTimeout","d":1744952,"h":141735665720,"f":1}],"m":[{"r":57016321,"p":[{"n":"address","p":3056114},{"n":"port","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginConnect","d":1744952,"h":154620567608,"f":1},{"r":57016321,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$1","d":1744952,"h":158915534904,"f":1},{"r":57016321,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$2","d":1744952,"h":163210502200,"f":1},{"r":65537,"n":"Close","d":1744952,"h":167505469496,"f":1},{"r":65537,"p":[{"n":"address","p":3056114},{"n":"port","p":655361}],"n":"Connect","d":1744952,"h":171800436792,"f":1},{"r":65537,"p":[{"n":"ipAddresses","p":0},{"n":"port","p":655361}],"n":"Connect","o":"@$1","d":1744952,"h":176095404088,"f":1},{"r":65537,"p":[{"n":"remoteEP","p":3318258}],"n":"Connect","o":"@$2","d":1744952,"h":180390371384,"f":1},{"r":65537,"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$3","d":1744952,"h":184685338680,"f":1},{"r":133300225,"p":[{"n":"address","p":3056114},{"n":"port","p":655361}],"n":"ConnectAsync","d":1744952,"h":188980305976,"f":1},{"r":136118273,"p":[{"n":"address","p":3056114},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":1744952,"h":193275273272,"f":1},{"r":133300225,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":1744952,"h":197570240568,"f":1},{"r":136118273,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":1744952,"h":201865207864,"f":1},{"r":133300225,"p":[{"n":"remoteEP","p":3318258}],"n":"ConnectAsync","o":"@$4","d":1744952,"h":206160175160,"f":1},{"r":136118273,"p":[{"n":"remoteEP","p":3318258},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":1744952,"h":210455142456,"f":1},{"r":133300225,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$6","d":1744952,"h":214750109752,"f":1},{"r":136118273,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$7","d":1744952,"h":219045077048,"f":1},{"r":65537,"n":"Dispose","d":1744952,"h":223340044344,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1744952,"h":227635011640,"f":132},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndConnect","d":1744952,"h":231929978936,"f":1},{"r":499768,"n":"GetStream","d":1744952,"h":240519913528,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1744952,"h":4296712248,"f":1},{"p":[{"n":"localEP","p":3318258}],"n":".ctor","o":"$ctor$2","d":1744952,"h":8591679544,"f":1},{"p":[{"n":"family","p":4497906}],"n":".ctor","o":"$ctor$3","d":1744952,"h":12886646840,"f":1},{"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$4","d":1744952,"h":17181614136,"f":1}],"i":[57540609],"h":1744952}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.TcpClient`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.TcpListener", ($self) => class TcpListener extends $.$spc.System.Object
        {
            $ctor$1(/*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ localaddr, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ get LocalEndpoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Server()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ AcceptSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptSocketAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptSocketAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TcpClient */ AcceptTcpClient()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.TcpClient> */ AcceptTcpClientAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.TcpClient> */ AcceptTcpClientAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AllowNatTraversal(/*bool*/ allowed)
            {
            }
            /*System.IAsyncResult */ BeginAcceptSocket(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAcceptTcpClient(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Sockets.TcpListener */ Create(/*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*System.Net.Sockets.Socket */ EndAcceptSocket(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TcpClient */ EndAcceptTcpClient(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Pending()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Start()
            {
            }
            /*void */ Start$1(/*int*/ backlog)
            {
            }
            /*void */ Stop()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1810488;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476646968,"f":4},"n":"Active","d":1810488,"h":17181679672,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":30066581560,"f":1},"s":{"r":0,"d":0,"h":34361548856,"f":1},"n":"ExclusiveAddressUse","d":1810488,"h":25771614264,"f":1},{"p":2597362,"g":{"r":0,"d":0,"h":42951483448,"f":1},"n":"LocalEndpoint","d":1810488,"h":38656516152,"f":1},{"p":892984,"g":{"r":0,"d":0,"h":51541418040,"f":1},"n":"Server","d":1810488,"h":47246450744,"f":1}],"m":[{"r":892984,"n":"AcceptSocket","d":1810488,"h":55836385336,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"n":"AcceptSocketAsync","d":1810488,"h":60131352632,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptSocketAsync","o":"@$1","d":1810488,"h":64426319928,"f":1},{"r":1744952,"n":"AcceptTcpClient","d":1810488,"h":68721287224,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.TcpClient).$h,"n":"AcceptTcpClientAsync","d":1810488,"h":73016254520,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.TcpClient).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptTcpClientAsync","o":"@$1","d":1810488,"h":77311221816,"f":1},{"r":65537,"p":[{"n":"allowed","p":262145}],"n":"AllowNatTraversal","d":1810488,"h":81606189112,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":57016321,"p":[{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginAcceptSocket","d":1810488,"h":85901156408,"f":1},{"r":57016321,"p":[{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginAcceptTcpClient","d":1810488,"h":90196123704,"f":1},{"r":1810488,"p":[{"n":"port","p":655361}],"n":"Create","d":1810488,"h":94491091000,"f":33},{"r":65537,"n":"Dispose","d":1810488,"h":98786058296,"f":1},{"r":892984,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAcceptSocket","d":1810488,"h":103081025592,"f":1},{"r":1744952,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAcceptTcpClient","d":1810488,"h":107375992888,"f":1},{"r":262145,"n":"Pending","d":1810488,"h":111670960184,"f":1},{"r":65537,"n":"Start","d":1810488,"h":115965927480,"f":1},{"r":65537,"p":[{"n":"backlog","p":655361}],"n":"Start","o":"@$1","d":1810488,"h":120260894776,"f":1},{"r":65537,"n":"Stop","d":1810488,"h":124555862072,"f":1}],"c":[{"p":[{"n":"port","p":655361}],"n":".ctor","o":"$ctor$1","d":1810488,"h":4296777784,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor has been deprecated. Use TcpListener(IPAddress localaddr, int port) instead.","t":1310721}]}]},{"p":[{"n":"localaddr","p":3056114},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":1810488,"h":8591745080,"f":1},{"p":[{"n":"localEP","p":3318258}],"n":".ctor","o":"$ctor$3","d":1810488,"h":12886712376,"f":1}],"i":[57540609],"h":1810488}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.TcpListener`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.UdpClient", ($self) => class UdpClient extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*int*/ port, /*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$6(/*string*/ hostname, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Active(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Client()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ set Client(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DontFragment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DontFragment(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableBroadcast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableBroadcast(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get MulticastLoopback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MulticastLoopback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ get Ttl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ set Ttl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AllowNatTraversal(/*bool*/ allowed)
            {
            }
            /*System.IAsyncResult */ BeginReceive(/*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend(/*byte[]*/ datagram, /*int*/ bytes, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$1(/*byte[]*/ datagram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$2(/*byte[]*/ datagram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close()
            {
            }
            /*void */ Connect(/*System.Net.IPAddress*/ addr, /*int*/ port)
            {
            }
            /*void */ Connect$1(/*System.Net.IPEndPoint*/ endPoint)
            {
            }
            /*void */ Connect$2(/*string*/ hostname, /*int*/ port)
            {
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ DropMulticastGroup(/*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ DropMulticastGroup$1(/*System.Net.IPAddress*/ multicastAddr, /*int*/ ifindex)
            {
            }
            /*byte[] */ EndReceive(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.IPEndPoint?*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ JoinMulticastGroup(/*int*/ ifindex, /*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ JoinMulticastGroup$1(/*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ JoinMulticastGroup$2(/*System.Net.IPAddress*/ multicastAddr, /*int*/ timeToLive)
            {
            }
            /*void */ JoinMulticastGroup$3(/*System.Net.IPAddress*/ multicastAddr, /*System.Net.IPAddress*/ localAddress)
            {
            }
            /*byte[] */ Receive(/*ref System.Net.IPEndPoint?*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.UdpReceiveResult> */ ReceiveAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.UdpReceiveResult> */ ReceiveAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send(/*byte[]*/ dgram, /*int*/ bytes)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$1(/*byte[]*/ dgram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$2(/*byte[]*/ dgram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$3(/*System.ReadOnlySpan<byte>*/ datagram)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$4(/*System.ReadOnlySpan<byte>*/ datagram, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$5(/*System.ReadOnlySpan<byte>*/ datagram, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync(/*byte[]*/ datagram, /*int*/ bytes)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*byte[]*/ datagram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$2(/*byte[]*/ datagram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$3(/*System.ReadOnlyMemory<byte>*/ datagram, /*System.Net.IPEndPoint?*/ endPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$4(/*System.ReadOnlyMemory<byte>*/ datagram, /*string?*/ hostname, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$5(/*System.ReadOnlyMemory<byte>*/ datagram, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1941560;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34361679928,"f":4},"s":{"r":0,"d":0,"h":38656647224,"f":4},"n":"Active","d":1941560,"h":30066712632,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":47246581816,"f":1},"n":"Available","d":1941560,"h":42951614520,"f":1},{"p":892984,"g":{"r":0,"d":0,"h":55836516408,"f":1},"s":{"r":0,"d":0,"h":60131483704,"f":1},"n":"Client","d":1941560,"h":51541549112,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721418296,"f":1},"s":{"r":0,"d":0,"h":73016385592,"f":1},"n":"DontFragment","d":1941560,"h":64426451000,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81606320184,"f":1},"s":{"r":0,"d":0,"h":85901287480,"f":1},"n":"EnableBroadcast","d":1941560,"h":77311352888,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94491222072,"f":1},"s":{"r":0,"d":0,"h":98786189368,"f":1},"n":"ExclusiveAddressUse","d":1941560,"h":90196254776,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":107376123960,"f":1},"s":{"r":0,"d":0,"h":111671091256,"f":1},"n":"MulticastLoopback","d":1941560,"h":103081156664,"f":1},{"p":524289,"g":{"r":0,"d":0,"h":120261025848,"f":1},"s":{"r":0,"d":0,"h":124555993144,"f":1},"n":"Ttl","d":1941560,"h":115966058552,"f":1}],"m":[{"r":65537,"p":[{"n":"allowed","p":262145}],"n":"AllowNatTraversal","d":1941560,"h":128850960440,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":57016321,"p":[{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginReceive","d":1941560,"h":133145927736,"f":1},{"r":57016321,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginSend","d":1941560,"h":137440895032,"f":1},{"r":57016321,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3318258},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginSend","o":"@$1","d":1941560,"h":141735862328,"f":1},{"r":57016321,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14483457},{"n":"state","p":131073}],"n":"BeginSend","o":"@$2","d":1941560,"h":146030829624,"f":1},{"r":65537,"n":"Close","d":1941560,"h":150325796920,"f":1},{"r":65537,"p":[{"n":"addr","p":3056114},{"n":"port","p":655361}],"n":"Connect","d":1941560,"h":154620764216,"f":1},{"r":65537,"p":[{"n":"endPoint","p":3318258}],"n":"Connect","o":"@$1","d":1941560,"h":158915731512,"f":1},{"r":65537,"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$2","d":1941560,"h":163210698808,"f":1},{"r":65537,"n":"Dispose","d":1941560,"h":167505666104,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1941560,"h":171800633400,"f":132},{"r":65537,"p":[{"n":"multicastAddr","p":3056114}],"n":"DropMulticastGroup","d":1941560,"h":176095600696,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3056114},{"n":"ifindex","p":655361}],"n":"DropMulticastGroup","o":"@$1","d":1941560,"h":180390567992,"f":1},{"r":0,"p":[{"n":"asyncResult","p":57016321},{"n":"remoteEP","p":3318258,"f":4}],"n":"EndReceive","d":1941560,"h":184685535288,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndSend","d":1941560,"h":188980502584,"f":1},{"r":65537,"p":[{"n":"ifindex","p":655361},{"n":"multicastAddr","p":3056114}],"n":"JoinMulticastGroup","d":1941560,"h":193275469880,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3056114}],"n":"JoinMulticastGroup","o":"@$1","d":1941560,"h":197570437176,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3056114},{"n":"timeToLive","p":655361}],"n":"JoinMulticastGroup","o":"@$2","d":1941560,"h":201865404472,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3056114},{"n":"localAddress","p":3056114}],"n":"JoinMulticastGroup","o":"@$3","d":1941560,"h":206160371768,"f":1},{"r":0,"p":[{"n":"remoteEP","p":3318258,"f":4}],"n":"Receive","d":1941560,"h":210455339064,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h,"n":"ReceiveAsync","d":1941560,"h":214750306360,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReceiveAsync","o":"@$1","d":1941560,"h":219045273656,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361}],"n":"Send","d":1941560,"h":223340240952,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3318258}],"n":"Send","o":"@$1","d":1941560,"h":227635208248,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Send","o":"@$2","d":1941560,"h":231930175544,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Send","o":"@$3","d":1941560,"h":236225142840,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"endPoint","p":3318258}],"n":"Send","o":"@$4","d":1941560,"h":240520110136,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Send","o":"@$5","d":1941560,"h":244815077432,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361}],"n":"SendAsync","d":1941560,"h":249110044728,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3318258}],"n":"SendAsync","o":"@$1","d":1941560,"h":253405012024,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"SendAsync","o":"@$2","d":1941560,"h":257699979320,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"endPoint","p":3318258},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$3","d":1941560,"h":261994946616,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"hostname","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$4","d":1941560,"h":266289913912,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$5","d":1941560,"h":270584881208,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1941560,"h":4296908856,"f":1},{"p":[{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":1941560,"h":8591876152,"f":1},{"p":[{"n":"port","p":655361},{"n":"family","p":4497906}],"n":".ctor","o":"$ctor$3","d":1941560,"h":12886843448,"f":1},{"p":[{"n":"localEP","p":3318258}],"n":".ctor","o":"$ctor$4","d":1941560,"h":17181810744,"f":1},{"p":[{"n":"family","p":4497906}],"n":".ctor","o":"$ctor$5","d":1941560,"h":21476778040,"f":1},{"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$6","d":1941560,"h":25771745336,"f":1}],"i":[57540609],"h":1941560}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.UdpClient`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketInformation", ($self) => class SocketInformation extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.Sockets.SocketInformationOptions */ get Options()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketInformationOptions */ set Options(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ get ProtocolInformation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ set ProtocolInformation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 1155128;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1220664,"g":{"r":0,"d":0,"h":17181024312,"f":1},"s":{"r":0,"d":0,"h":21475991608,"f":1},"n":"Options","d":1155128,"h":12886057016,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30065926200,"f":1},"s":{"r":0,"d":0,"h":34360893496,"f":1},"n":"ProtocolInformation","d":1155128,"h":25770958904,"f":1}],"l":[{"t":131073,"n":"_dummy","d":1155128,"h":4296122424,"f":2},{"t":655361,"n":"_dummyPrimitive","d":1155128,"h":8591089720,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1155128,"h":38655860792,"f":1}],"h":1155128}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketInformation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketReceiveFromResult", ($self) => class SocketReceiveFromResult extends $.$spc.System.ValueType
        {
            /*int*/  get ReceivedBytes() { return this.$getField(0, 4); }
            /*int*/  set ReceivedBytes(value) { this.$setField(0, 4, value); }
            /*System.Net.EndPoint*/  get RemoteEndPoint() { return this.$getField(4, 4); }
            /*System.Net.EndPoint*/  set RemoteEndPoint(value) { this.$setField(4, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ReceivedBytes = this.ReceivedBytes;
                copy.RemoteEndPoint = this.RemoteEndPoint;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ReceivedBytes = 0;
                this.RemoteEndPoint = null;
            }
            static $h = 1417272;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"ReceivedBytes","d":1417272,"h":4296384568,"f":1},{"t":2597362,"n":"RemoteEndPoint","d":1417272,"h":8591351864,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1417272,"h":12886319160,"f":1}],"h":1417272}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketReceiveFromResult`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketReceiveMessageFromResult", ($self) => class SocketReceiveMessageFromResult extends $.$spc.System.ValueType
        {
            /*System.Net.Sockets.IPPacketInformation*/  get PacketInformation() { return this.$getField(0, 8); }
            /*System.Net.Sockets.IPPacketInformation*/  set PacketInformation(value) { this.$setField(0, 8, value); }
            /*int*/  get ReceivedBytes() { return this.$getField(8, 4); }
            /*int*/  set ReceivedBytes(value) { this.$setField(8, 4, value); }
            /*System.Net.EndPoint*/  get RemoteEndPoint() { return this.$getField(12, 4); }
            /*System.Net.EndPoint*/  set RemoteEndPoint(value) { this.$setField(12, 4, value); }
            /*System.Net.Sockets.SocketFlags*/  get SocketFlags() { return this.$getField(16, 4); }
            /*System.Net.Sockets.SocketFlags*/  set SocketFlags(value) { this.$setField(16, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.PacketInformation = this.PacketInformation.Clone();
                copy.ReceivedBytes = this.ReceivedBytes;
                copy.RemoteEndPoint = this.RemoteEndPoint;
                copy.SocketFlags = this.SocketFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.PacketInformation = $.$default($.$sns.System.Net.Sockets.IPPacketInformation);
                this.ReceivedBytes = 0;
                this.RemoteEndPoint = null;
                this.SocketFlags = 0;
            }
            static $h = 1482808;
            static $z = 20;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":172088,"n":"PacketInformation","d":1482808,"h":4296450104,"f":1},{"t":655361,"n":"ReceivedBytes","d":1482808,"h":8591417400,"f":1},{"t":2597362,"n":"RemoteEndPoint","d":1482808,"h":12886384696,"f":1},{"t":1089592,"n":"SocketFlags","d":1482808,"h":17181351992,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1482808,"h":21476319288,"f":1}],"h":1482808}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketReceiveMessageFromResult`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.UnixDomainSocketEndPoint", ($self) => class UnixDomainSocketEndPoint extends $.$snp.System.Net.EndPoint
        {
            $ctor$2(/*string*/ path)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Sockets.AddressFamily */ get AddressFamily()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ Create(/*System.Net.SocketAddress*/ socketAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.GetHashCode.apply(this, arguments); }
            /*System.Net.SocketAddress */ Serialize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.ToString.apply(this, arguments); }
            static $h = 2072632;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2597362,"p":[{"p":4497906,"g":{"r":0,"d":0,"h":12886974520,"f":32769},"n":"AddressFamily","d":2072632,"h":8592007224,"f":32769}],"m":[{"r":2597362,"p":[{"n":"socketAddress","p":4366834}],"n":"Create","d":2072632,"h":17181941816,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2072632,"h":21476909112,"f":32769},{"r":655361,"n":"GetHashCode","d":2072632,"h":25771876408,"f":32769},{"r":4366834,"n":"Serialize","d":2072632,"h":30066843704,"f":32769},{"r":1310721,"n":"ToString","d":2072632,"h":34361811000,"f":32769}],"c":[{"p":[{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$2","d":2072632,"h":4297039928,"f":1}],"h":2072632}; }
            static get $b() { return $.$snp.System.Net.EndPoint; }
            static get $fullName() { return `System.Net.Sockets.UnixDomainSocketEndPoint`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IPPacketInformation", ($self) => class IPPacketInformation extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.IPAddress */ get Address()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Interface()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Sockets.IPPacketInformation*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.IPPacketInformation.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.IPPacketInformation.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Sockets.IPPacketInformation*/ packetInformation1, /*System.Net.Sockets.IPPacketInformation*/ packetInformation2)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Sockets.IPPacketInformation*/ packetInformation1, /*System.Net.Sockets.IPPacketInformation*/ packetInformation2)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IEquatable<System.Net.Sockets.IPPacketInformation>.Equals(System.Net.Sockets.IPPacketInformation)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 172088;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":3056114,"g":{"r":0,"d":0,"h":17180041272,"f":1},"n":"Address","d":172088,"h":12885073976,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25769975864,"f":1},"n":"Interface","d":172088,"h":21475008568,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":172088}],"n":"Equals","o":"@$2","d":172088,"h":30064943160,"f":1},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":172088,"h":34359910456,"f":32769},{"r":655361,"n":"GetHashCode","d":172088,"h":38654877752,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":172088,"h":4295139384,"f":2},{"t":655361,"n":"_dummyPrimitive","d":172088,"h":8590106680,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":172088,"h":51539779640,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.IPPacketInformation).$h],"h":172088}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.IPPacketInformation) ]; }
            static get $fullName() { return `System.Net.Sockets.IPPacketInformation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.UdpReceiveResult", ($self) => class UdpReceiveResult extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$2(/*byte[]*/ buffer, /*System.Net.IPEndPoint*/ remoteEndPoint)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*byte[] */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Sockets.UdpReceiveResult*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.UdpReceiveResult.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.UdpReceiveResult.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Sockets.UdpReceiveResult*/ left, /*System.Net.Sockets.UdpReceiveResult*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Sockets.UdpReceiveResult*/ left, /*System.Net.Sockets.UdpReceiveResult*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IEquatable<System.Net.Sockets.UdpReceiveResult>.Equals(System.Net.Sockets.UdpReceiveResult)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 2007096;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":0,"g":{"r":0,"d":0,"h":21476843576,"f":1},"n":"Buffer","d":2007096,"h":17181876280,"f":1},{"p":3318258,"g":{"r":0,"d":0,"h":30066778168,"f":1},"n":"RemoteEndPoint","d":2007096,"h":25771810872,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":2007096}],"n":"Equals","o":"@$2","d":2007096,"h":34361745464,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2007096,"h":38656712760,"f":32769},{"r":655361,"n":"GetHashCode","d":2007096,"h":42951680056,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":2007096,"h":4296974392,"f":2},{"t":655361,"n":"_dummyPrimitive","d":2007096,"h":8591941688,"f":2}],"c":[{"p":[{"n":"buffer","p":0},{"n":"remoteEndPoint","p":3318258}],"n":".ctor","o":"$ctor$2","d":2007096,"h":12886908984,"f":1},{"n":".ctor","o":"$ctor$3","d":2007096,"h":55836581944,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h],"h":2007096}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.UdpReceiveResult) ]; }
            static get $fullName() { return `System.Net.Sockets.UdpReceiveResult`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.NetworkStream", ($self) => class NetworkStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.Net.Sockets.Socket*/ socket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.Sockets.Socket*/ socket, /*bool*/ ownsSocket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*System.Net.Sockets.Socket*/ socket, /*System.IO.FileAccess*/ access)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$6(/*System.Net.Sockets.Socket*/ socket, /*System.IO.FileAccess*/ access, /*bool*/ ownsSocket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DataAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Readable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Readable(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Socket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Writeable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Writeable(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close$1(/*int*/ timeout)
            {
            }
            /*void */ Close$2(/*System.TimeSpan*/ timeout)
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 499768;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770303544,"f":32769},"n":"CanRead","d":499768,"h":21475336248,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360238136,"f":32769},"n":"CanSeek","d":499768,"h":30065270840,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950172728,"f":32769},"n":"CanTimeout","d":499768,"h":38655205432,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51540107320,"f":32769},"n":"CanWrite","d":499768,"h":47245140024,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60130041912,"f":129},"n":"DataAvailable","d":499768,"h":55835074616,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":68719976504,"f":32769},"n":"Length","d":499768,"h":64425009208,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":77309911096,"f":32769},"s":{"r":0,"d":0,"h":81604878392,"f":32769},"n":"Position","d":499768,"h":73014943800,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":90194812984,"f":4},"s":{"r":0,"d":0,"h":94489780280,"f":4},"n":"Readable","d":499768,"h":85899845688,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":103079714872,"f":32769},"s":{"r":0,"d":0,"h":107374682168,"f":32769},"n":"ReadTimeout","d":499768,"h":98784747576,"f":32769},{"p":892984,"g":{"r":0,"d":0,"h":115964616760,"f":1},"n":"Socket","d":499768,"h":111669649464,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554551352,"f":4},"s":{"r":0,"d":0,"h":128849518648,"f":4},"n":"Writeable","d":499768,"h":120259584056,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":137439453240,"f":32769},"s":{"r":0,"d":0,"h":141734420536,"f":32769},"n":"WriteTimeout","d":499768,"h":133144485944,"f":32769}],"m":[{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginRead","d":499768,"h":146029387832,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginWrite","d":499768,"h":150324355128,"f":32769},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Close","o":"@$1","d":499768,"h":154619322424,"f":1},{"r":65537,"p":[{"n":"timeout","p":140705793}],"n":"Close","o":"@$2","d":499768,"h":158914289720,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":499768,"h":163209257016,"f":32772},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":499768,"h":167504224312,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":499768,"h":171799191608,"f":32769},{"r":65537,"n":"Flush","d":499768,"h":180389126200,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":499768,"h":184684093496,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":499768,"h":188979060792,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":499768,"h":193274028088,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":499768,"h":197568995384,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":499768,"h":201863962680,"f":32769},{"r":655361,"n":"ReadByte","d":499768,"h":206158929976,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":499768,"h":210453897272,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":499768,"h":214748864568,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":499768,"h":219043831864,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":499768,"h":223338799160,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":499768,"h":227633766456,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":499768,"h":231928733752,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":499768,"h":236223701048,"f":32769}],"c":[{"p":[{"n":"socket","p":892984}],"n":".ctor","o":"$ctor$3","d":499768,"h":4295467064,"f":1},{"p":[{"n":"socket","p":892984},{"n":"ownsSocket","p":262145}],"n":".ctor","o":"$ctor$4","d":499768,"h":8590434360,"f":1},{"p":[{"n":"socket","p":892984},{"n":"access","p":59768833}],"n":".ctor","o":"$ctor$5","d":499768,"h":12885401656,"f":1},{"p":[{"n":"socket","p":892984},{"n":"access","p":59768833},{"n":"ownsSocket","p":262145}],"n":".ctor","o":"$ctor$6","d":499768,"h":17180368952,"f":1}],"i":[57540609,56950785],"h":499768}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.NetworkStream`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IOControlCode", ($self) => class IOControlCode extends $.$spc.System.Enum
        {
            static EnableCircularQueuing = 671088642n;
            static Flush = 671088644n;
            static AddressListChange = 671088663n;
            static DataToRead = 1074030207n;
            static OobDataRead = 1074033415n;
            static GetBroadcastAddress = 1207959557n;
            static AddressListQuery = 1207959574n;
            static QueryTargetPnpHandle = 1207959576n;
            static AsyncIO = 2147772029n;
            static NonBlockingIO = 2147772030n;
            static AssociateHandle = 2281701377n;
            static MultipointLoopback = 2281701385n;
            static MulticastScope = 2281701386n;
            static SetQos = 2281701387n;
            static SetGroupQos = 2281701388n;
            static RoutingInterfaceChange = 2281701397n;
            static NamespaceChange = 2281701401n;
            static ReceiveAll = 2550136833n;
            static ReceiveAllMulticast = 2550136834n;
            static ReceiveAllIgmpMulticast = 2550136835n;
            static KeepAliveValues = 2550136836n;
            static AbsorbRouterAlert = 2550136837n;
            static UnicastInterface = 2550136838n;
            static LimitBroadcasts = 2550136839n;
            static BindToInterface = 2550136840n;
            static MulticastInterface = 2550136841n;
            static AddMulticastGroupOnInterface = 2550136842n;
            static DeleteMulticastGroupFromInterface = 2550136843n;
            static GetExtensionFunctionPointer = 3355443206n;
            static GetQos = 3355443207n;
            static GetGroupQos = 3355443208n;
            static TranslateHandle = 3355443213n;
            static RoutingInterfaceQuery = 3355443220n;
            static AddressListSort = 3355443225n;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "EnableCircularQueuing": 671088642n,
                    "Flush": 671088644n,
                    "AddressListChange": 671088663n,
                    "DataToRead": 1074030207n,
                    "OobDataRead": 1074033415n,
                    "GetBroadcastAddress": 1207959557n,
                    "AddressListQuery": 1207959574n,
                    "QueryTargetPnpHandle": 1207959576n,
                    "AsyncIO": 2147772029n,
                    "NonBlockingIO": 2147772030n,
                    "AssociateHandle": 2281701377n,
                    "MultipointLoopback": 2281701385n,
                    "MulticastScope": 2281701386n,
                    "SetQos": 2281701387n,
                    "SetGroupQos": 2281701388n,
                    "RoutingInterfaceChange": 2281701397n,
                    "NamespaceChange": 2281701401n,
                    "ReceiveAll": 2550136833n,
                    "ReceiveAllMulticast": 2550136834n,
                    "ReceiveAllIgmpMulticast": 2550136835n,
                    "KeepAliveValues": 2550136836n,
                    "AbsorbRouterAlert": 2550136837n,
                    "UnicastInterface": 2550136838n,
                    "LimitBroadcasts": 2550136839n,
                    "BindToInterface": 2550136840n,
                    "MulticastInterface": 2550136841n,
                    "AddMulticastGroupOnInterface": 2550136842n,
                    "DeleteMulticastGroupFromInterface": 2550136843n,
                    "GetExtensionFunctionPointer": 3355443206n,
                    "GetQos": 3355443207n,
                    "GetGroupQos": 3355443208n,
                    "TranslateHandle": 3355443213n,
                    "RoutingInterfaceQuery": 3355443220n,
                    "AddressListSort": 3355443225n
                };
            }
            static $h = 106552;
            static $z = 8;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int64; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":917505,"l":[{"t":106552,"n":"EnableCircularQueuing","d":106552,"h":4295073848,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"Flush","d":106552,"h":8590041144,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"AddressListChange","d":106552,"h":12885008440,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"DataToRead","d":106552,"h":17179975736,"f":33},{"t":106552,"n":"OobDataRead","d":106552,"h":21474943032,"f":33},{"t":106552,"n":"GetBroadcastAddress","d":106552,"h":25769910328,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"AddressListQuery","d":106552,"h":30064877624,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"QueryTargetPnpHandle","d":106552,"h":34359844920,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"AsyncIO","d":106552,"h":38654812216,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"NonBlockingIO","d":106552,"h":42949779512,"f":33},{"t":106552,"n":"AssociateHandle","d":106552,"h":47244746808,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"MultipointLoopback","d":106552,"h":51539714104,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"MulticastScope","d":106552,"h":55834681400,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"SetQos","d":106552,"h":60129648696,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"SetGroupQos","d":106552,"h":64424615992,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"RoutingInterfaceChange","d":106552,"h":68719583288,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"NamespaceChange","d":106552,"h":73014550584,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"ReceiveAll","d":106552,"h":77309517880,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"ReceiveAllMulticast","d":106552,"h":81604485176,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"ReceiveAllIgmpMulticast","d":106552,"h":85899452472,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"KeepAliveValues","d":106552,"h":90194419768,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"AbsorbRouterAlert","d":106552,"h":94489387064,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"UnicastInterface","d":106552,"h":98784354360,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"LimitBroadcasts","d":106552,"h":103079321656,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"BindToInterface","d":106552,"h":107374288952,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"MulticastInterface","d":106552,"h":111669256248,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"AddMulticastGroupOnInterface","d":106552,"h":115964223544,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"DeleteMulticastGroupFromInterface","d":106552,"h":120259190840,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"GetExtensionFunctionPointer","d":106552,"h":124554158136,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"GetQos","d":106552,"h":128849125432,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"GetGroupQos","d":106552,"h":133144092728,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"TranslateHandle","d":106552,"h":137439060024,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"RoutingInterfaceQuery","d":106552,"h":141734027320,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":106552,"n":"AddressListSort","d":106552,"h":146028994616,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":106552,"h":150323961912,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":106552}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.IOControlCode`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IPProtectionLevel", ($self) => class IPProtectionLevel extends $.$spc.System.Enum
        {
            static Unspecified = -1;
            static Unrestricted = 10;
            static EdgeRestricted = 20;
            static Restricted = 30;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unspecified": -1n,
                    "Unrestricted": 10n,
                    "EdgeRestricted": 20n,
                    "Restricted": 30n
                };
            }
            static $h = 237624;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":237624,"n":"Unspecified","d":237624,"h":4295204920,"f":33},{"t":237624,"n":"Unrestricted","d":237624,"h":8590172216,"f":33},{"t":237624,"n":"EdgeRestricted","d":237624,"h":12885139512,"f":33},{"t":237624,"n":"Restricted","d":237624,"h":17180106808,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":237624,"h":21475074104,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":237624}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.IPProtectionLevel`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.ProtocolFamily", ($self) => class ProtocolFamily extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static Unspecified = 0;
            static Unix = 1;
            static InterNetwork = 2;
            static ImpLink = 3;
            static Pup = 4;
            static Chaos = 5;
            static Ipx = 6;
            static NS = 6;
            static Iso = 7;
            static Osi = 7;
            static Ecma = 8;
            static DataKit = 9;
            static Ccitt = 10;
            static Sna = 11;
            static DecNet = 12;
            static DataLink = 13;
            static Lat = 14;
            static HyperChannel = 15;
            static AppleTalk = 16;
            static NetBios = 17;
            static VoiceView = 18;
            static FireFox = 19;
            static Banyan = 21;
            static Atm = 22;
            static InterNetworkV6 = 23;
            static Cluster = 24;
            static Ieee12844 = 25;
            static Irda = 26;
            static NetworkDesigners = 28;
            static Max = 29;
            static Packet = 65536;
            static ControllerAreaNetwork = 65537;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Unspecified": 0n,
                    "Unix": 1n,
                    "InterNetwork": 2n,
                    "ImpLink": 3n,
                    "Pup": 4n,
                    "Chaos": 5n,
                    "Ipx": 6n,
                    "NS": 6n,
                    "Iso": 7n,
                    "Osi": 7n,
                    "Ecma": 8n,
                    "DataKit": 9n,
                    "Ccitt": 10n,
                    "Sna": 11n,
                    "DecNet": 12n,
                    "DataLink": 13n,
                    "Lat": 14n,
                    "HyperChannel": 15n,
                    "AppleTalk": 16n,
                    "NetBios": 17n,
                    "VoiceView": 18n,
                    "FireFox": 19n,
                    "Banyan": 21n,
                    "Atm": 22n,
                    "InterNetworkV6": 23n,
                    "Cluster": 24n,
                    "Ieee12844": 25n,
                    "Irda": 26n,
                    "NetworkDesigners": 28n,
                    "Max": 29n,
                    "Packet": 65536n,
                    "ControllerAreaNetwork": 65537n
                };
            }
            static $h = 565304;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":565304,"n":"Unknown","d":565304,"h":4295532600,"f":33},{"t":565304,"n":"Unspecified","d":565304,"h":8590499896,"f":33},{"t":565304,"n":"Unix","d":565304,"h":12885467192,"f":33},{"t":565304,"n":"InterNetwork","d":565304,"h":17180434488,"f":33},{"t":565304,"n":"ImpLink","d":565304,"h":21475401784,"f":33},{"t":565304,"n":"Pup","d":565304,"h":25770369080,"f":33},{"t":565304,"n":"Chaos","d":565304,"h":30065336376,"f":33},{"t":565304,"n":"Ipx","d":565304,"h":34360303672,"f":33},{"t":565304,"n":"NS","d":565304,"h":38655270968,"f":33},{"t":565304,"n":"Iso","d":565304,"h":42950238264,"f":33},{"t":565304,"n":"Osi","d":565304,"h":47245205560,"f":33},{"t":565304,"n":"Ecma","d":565304,"h":51540172856,"f":33},{"t":565304,"n":"DataKit","d":565304,"h":55835140152,"f":33},{"t":565304,"n":"Ccitt","d":565304,"h":60130107448,"f":33},{"t":565304,"n":"Sna","d":565304,"h":64425074744,"f":33},{"t":565304,"n":"DecNet","d":565304,"h":68720042040,"f":33},{"t":565304,"n":"DataLink","d":565304,"h":73015009336,"f":33},{"t":565304,"n":"Lat","d":565304,"h":77309976632,"f":33},{"t":565304,"n":"HyperChannel","d":565304,"h":81604943928,"f":33},{"t":565304,"n":"AppleTalk","d":565304,"h":85899911224,"f":33},{"t":565304,"n":"NetBios","d":565304,"h":90194878520,"f":33},{"t":565304,"n":"VoiceView","d":565304,"h":94489845816,"f":33},{"t":565304,"n":"FireFox","d":565304,"h":98784813112,"f":33},{"t":565304,"n":"Banyan","d":565304,"h":103079780408,"f":33},{"t":565304,"n":"Atm","d":565304,"h":107374747704,"f":33},{"t":565304,"n":"InterNetworkV6","d":565304,"h":111669715000,"f":33},{"t":565304,"n":"Cluster","d":565304,"h":115964682296,"f":33},{"t":565304,"n":"Ieee12844","d":565304,"h":120259649592,"f":33},{"t":565304,"n":"Irda","d":565304,"h":124554616888,"f":33},{"t":565304,"n":"NetworkDesigners","d":565304,"h":128849584184,"f":33},{"t":565304,"n":"Max","d":565304,"h":133144551480,"f":33},{"t":565304,"n":"Packet","d":565304,"h":137439518776,"f":33},{"t":565304,"n":"ControllerAreaNetwork","d":565304,"h":141734486072,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":565304,"h":146029453368,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":565304}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.ProtocolFamily`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.ProtocolType", ($self) => class ProtocolType extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static IP = 0;
            static IPv6HopByHopOptions = 0;
            static Unspecified = 0;
            static Icmp = 1;
            static Igmp = 2;
            static Ggp = 3;
            static IPv4 = 4;
            static Tcp = 6;
            static Pup = 12;
            static Udp = 17;
            static Idp = 22;
            static IPv6 = 41;
            static IPv6RoutingHeader = 43;
            static IPv6FragmentHeader = 44;
            static IPSecEncapsulatingSecurityPayload = 50;
            static IPSecAuthenticationHeader = 51;
            static IcmpV6 = 58;
            static IPv6NoNextHeader = 59;
            static IPv6DestinationOptions = 60;
            static ND = 77;
            static Raw = 255;
            static Ipx = 1000;
            static Spx = 1256;
            static SpxII = 1257;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "IP": 0n,
                    "IPv6HopByHopOptions": 0n,
                    "Unspecified": 0n,
                    "Icmp": 1n,
                    "Igmp": 2n,
                    "Ggp": 3n,
                    "IPv4": 4n,
                    "Tcp": 6n,
                    "Pup": 12n,
                    "Udp": 17n,
                    "Idp": 22n,
                    "IPv6": 41n,
                    "IPv6RoutingHeader": 43n,
                    "IPv6FragmentHeader": 44n,
                    "IPSecEncapsulatingSecurityPayload": 50n,
                    "IPSecAuthenticationHeader": 51n,
                    "IcmpV6": 58n,
                    "IPv6NoNextHeader": 59n,
                    "IPv6DestinationOptions": 60n,
                    "ND": 77n,
                    "Raw": 255n,
                    "Ipx": 1000n,
                    "Spx": 1256n,
                    "SpxII": 1257n
                };
            }
            static $h = 630840;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":630840,"n":"Unknown","d":630840,"h":4295598136,"f":33},{"t":630840,"n":"IP","d":630840,"h":8590565432,"f":33},{"t":630840,"n":"IPv6HopByHopOptions","d":630840,"h":12885532728,"f":33},{"t":630840,"n":"Unspecified","d":630840,"h":17180500024,"f":33},{"t":630840,"n":"Icmp","d":630840,"h":21475467320,"f":33},{"t":630840,"n":"Igmp","d":630840,"h":25770434616,"f":33},{"t":630840,"n":"Ggp","d":630840,"h":30065401912,"f":33},{"t":630840,"n":"IPv4","d":630840,"h":34360369208,"f":33},{"t":630840,"n":"Tcp","d":630840,"h":38655336504,"f":33},{"t":630840,"n":"Pup","d":630840,"h":42950303800,"f":33},{"t":630840,"n":"Udp","d":630840,"h":47245271096,"f":33},{"t":630840,"n":"Idp","d":630840,"h":51540238392,"f":33},{"t":630840,"n":"IPv6","d":630840,"h":55835205688,"f":33},{"t":630840,"n":"IPv6RoutingHeader","d":630840,"h":60130172984,"f":33},{"t":630840,"n":"IPv6FragmentHeader","d":630840,"h":64425140280,"f":33},{"t":630840,"n":"IPSecEncapsulatingSecurityPayload","d":630840,"h":68720107576,"f":33},{"t":630840,"n":"IPSecAuthenticationHeader","d":630840,"h":73015074872,"f":33},{"t":630840,"n":"IcmpV6","d":630840,"h":77310042168,"f":33},{"t":630840,"n":"IPv6NoNextHeader","d":630840,"h":81605009464,"f":33},{"t":630840,"n":"IPv6DestinationOptions","d":630840,"h":85899976760,"f":33},{"t":630840,"n":"ND","d":630840,"h":90194944056,"f":33},{"t":630840,"n":"Raw","d":630840,"h":94489911352,"f":33},{"t":630840,"n":"Ipx","d":630840,"h":98784878648,"f":33},{"t":630840,"n":"Spx","d":630840,"h":103079845944,"f":33},{"t":630840,"n":"SpxII","d":630840,"h":107374813240,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":630840,"h":111669780536,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":630840}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.ProtocolType`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SelectMode", ($self) => class SelectMode extends $.$spc.System.Enum
        {
            static SelectRead = 0;
            static SelectWrite = 1;
            static SelectError = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "SelectRead": 0n,
                    "SelectWrite": 1n,
                    "SelectError": 2n
                };
            }
            static $h = 761912;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":761912,"n":"SelectRead","d":761912,"h":4295729208,"f":33},{"t":761912,"n":"SelectWrite","d":761912,"h":8590696504,"f":33},{"t":761912,"n":"SelectError","d":761912,"h":12885663800,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":761912,"h":17180631096,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":761912}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SelectMode`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketAsyncOperation", ($self) => class SocketAsyncOperation extends $.$spc.System.Enum
        {
            static None = 0;
            static Accept = 1;
            static Connect = 2;
            static Disconnect = 3;
            static Receive = 4;
            static ReceiveFrom = 5;
            static ReceiveMessageFrom = 6;
            static Send = 7;
            static SendPackets = 8;
            static SendTo = 9;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Accept": 1n,
                    "Connect": 2n,
                    "Disconnect": 3n,
                    "Receive": 4n,
                    "ReceiveFrom": 5n,
                    "ReceiveMessageFrom": 6n,
                    "Send": 7n,
                    "SendPackets": 8n,
                    "SendTo": 9n
                };
            }
            static $h = 1024056;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1024056,"n":"None","d":1024056,"h":4295991352,"f":33},{"t":1024056,"n":"Accept","d":1024056,"h":8590958648,"f":33},{"t":1024056,"n":"Connect","d":1024056,"h":12885925944,"f":33},{"t":1024056,"n":"Disconnect","d":1024056,"h":17180893240,"f":33},{"t":1024056,"n":"Receive","d":1024056,"h":21475860536,"f":33},{"t":1024056,"n":"ReceiveFrom","d":1024056,"h":25770827832,"f":33},{"t":1024056,"n":"ReceiveMessageFrom","d":1024056,"h":30065795128,"f":33},{"t":1024056,"n":"Send","d":1024056,"h":34360762424,"f":33},{"t":1024056,"n":"SendPackets","d":1024056,"h":38655729720,"f":33},{"t":1024056,"n":"SendTo","d":1024056,"h":42950697016,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1024056,"h":47245664312,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1024056}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketAsyncOperation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketFlags", ($self) => class SocketFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static OutOfBand = 1;
            static Peek = 2;
            static DontRoute = 4;
            static Truncated = 256;
            static ControlDataTruncated = 512;
            static Broadcast = 1024;
            static Multicast = 2048;
            static Partial = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OutOfBand": 1n,
                    "Peek": 2n,
                    "DontRoute": 4n,
                    "Truncated": 256n,
                    "ControlDataTruncated": 512n,
                    "Broadcast": 1024n,
                    "Multicast": 2048n,
                    "Partial": 32768n
                };
            }
            static $h = 1089592;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1089592,"n":"None","d":1089592,"h":4296056888,"f":33},{"t":1089592,"n":"OutOfBand","d":1089592,"h":8591024184,"f":33},{"t":1089592,"n":"Peek","d":1089592,"h":12885991480,"f":33},{"t":1089592,"n":"DontRoute","d":1089592,"h":17180958776,"f":33},{"t":1089592,"n":"Truncated","d":1089592,"h":21475926072,"f":33},{"t":1089592,"n":"ControlDataTruncated","d":1089592,"h":25770893368,"f":33},{"t":1089592,"n":"Broadcast","d":1089592,"h":30065860664,"f":33},{"t":1089592,"n":"Multicast","d":1089592,"h":34360827960,"f":33},{"t":1089592,"n":"Partial","d":1089592,"h":38655795256,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1089592,"h":42950762552,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1089592,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketFlags`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketInformationOptions", ($self) => class SocketInformationOptions extends $.$spc.System.Enum
        {
            static NonBlocking = 1;
            static Connected = 2;
            static Listening = 4;
            static UseOnlyOverlappedIO = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NonBlocking": 1n,
                    "Connected": 2n,
                    "Listening": 4n,
                    "UseOnlyOverlappedIO": 8n
                };
            }
            static $h = 1220664;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1220664,"n":"NonBlocking","d":1220664,"h":4296187960,"f":33},{"t":1220664,"n":"Connected","d":1220664,"h":8591155256,"f":33},{"t":1220664,"n":"Listening","d":1220664,"h":12886122552,"f":33},{"t":1220664,"n":"UseOnlyOverlappedIO","d":1220664,"h":17181089848,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":70909953,"c":8660844545,"a":[{"v":"SocketInformationOptions.UseOnlyOverlappedIO has been deprecated and is not supported.","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":1220664,"h":21476057144,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1220664,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketInformationOptions`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketOptionLevel", ($self) => class SocketOptionLevel extends $.$spc.System.Enum
        {
            static IP = 0;
            static Tcp = 6;
            static Udp = 17;
            static IPv6 = 41;
            static Socket = 65535;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "IP": 0n,
                    "Tcp": 6n,
                    "Udp": 17n,
                    "IPv6": 41n,
                    "Socket": 65535n
                };
            }
            static $h = 1286200;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1286200,"n":"IP","d":1286200,"h":4296253496,"f":33},{"t":1286200,"n":"Tcp","d":1286200,"h":8591220792,"f":33},{"t":1286200,"n":"Udp","d":1286200,"h":12886188088,"f":33},{"t":1286200,"n":"IPv6","d":1286200,"h":17181155384,"f":33},{"t":1286200,"n":"Socket","d":1286200,"h":21476122680,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1286200,"h":25771089976,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1286200}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketOptionLevel`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketOptionName", ($self) => class SocketOptionName extends $.$spc.System.Enum
        {
            static DontLinger = -129;
            static ExclusiveAddressUse = -5;
            static Debug = 1;
            static IPOptions = 1;
            static NoChecksum = 1;
            static NoDelay = 1;
            static AcceptConnection = 2;
            static BsdUrgent = 2;
            static Expedited = 2;
            static HeaderIncluded = 2;
            static TcpKeepAliveTime = 3;
            static TypeOfService = 3;
            static IpTimeToLive = 4;
            static ReuseAddress = 4;
            static KeepAlive = 8;
            static MulticastInterface = 9;
            static MulticastTimeToLive = 10;
            static MulticastLoopback = 11;
            static AddMembership = 12;
            static DropMembership = 13;
            static DontFragment = 14;
            static AddSourceMembership = 15;
            static FastOpen = 15;
            static DontRoute = 16;
            static DropSourceMembership = 16;
            static TcpKeepAliveRetryCount = 16;
            static BlockSource = 17;
            static TcpKeepAliveInterval = 17;
            static UnblockSource = 18;
            static PacketInformation = 19;
            static ChecksumCoverage = 20;
            static HopLimit = 21;
            static IPProtectionLevel = 23;
            static IPv6Only = 27;
            static Broadcast = 32;
            static UseLoopback = 64;
            static Linger = 128;
            static OutOfBandInline = 256;
            static SendBuffer = 4097;
            static ReceiveBuffer = 4098;
            static SendLowWater = 4099;
            static ReceiveLowWater = 4100;
            static SendTimeout = 4101;
            static ReceiveTimeout = 4102;
            static Error = 4103;
            static Type = 4104;
            static ReuseUnicastPort = 12295;
            static UpdateAcceptContext = 28683;
            static UpdateConnectContext = 28688;
            static MaxConnections = 2147483647;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "DontLinger": -129n,
                    "ExclusiveAddressUse": -5n,
                    "Debug": 1n,
                    "IPOptions": 1n,
                    "NoChecksum": 1n,
                    "NoDelay": 1n,
                    "AcceptConnection": 2n,
                    "BsdUrgent": 2n,
                    "Expedited": 2n,
                    "HeaderIncluded": 2n,
                    "TcpKeepAliveTime": 3n,
                    "TypeOfService": 3n,
                    "IpTimeToLive": 4n,
                    "ReuseAddress": 4n,
                    "KeepAlive": 8n,
                    "MulticastInterface": 9n,
                    "MulticastTimeToLive": 10n,
                    "MulticastLoopback": 11n,
                    "AddMembership": 12n,
                    "DropMembership": 13n,
                    "DontFragment": 14n,
                    "AddSourceMembership": 15n,
                    "FastOpen": 15n,
                    "DontRoute": 16n,
                    "DropSourceMembership": 16n,
                    "TcpKeepAliveRetryCount": 16n,
                    "BlockSource": 17n,
                    "TcpKeepAliveInterval": 17n,
                    "UnblockSource": 18n,
                    "PacketInformation": 19n,
                    "ChecksumCoverage": 20n,
                    "HopLimit": 21n,
                    "IPProtectionLevel": 23n,
                    "IPv6Only": 27n,
                    "Broadcast": 32n,
                    "UseLoopback": 64n,
                    "Linger": 128n,
                    "OutOfBandInline": 256n,
                    "SendBuffer": 4097n,
                    "ReceiveBuffer": 4098n,
                    "SendLowWater": 4099n,
                    "ReceiveLowWater": 4100n,
                    "SendTimeout": 4101n,
                    "ReceiveTimeout": 4102n,
                    "Error": 4103n,
                    "Type": 4104n,
                    "ReuseUnicastPort": 12295n,
                    "UpdateAcceptContext": 28683n,
                    "UpdateConnectContext": 28688n,
                    "MaxConnections": 2147483647n
                };
            }
            static $h = 1351736;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1351736,"n":"DontLinger","d":1351736,"h":4296319032,"f":33},{"t":1351736,"n":"ExclusiveAddressUse","d":1351736,"h":8591286328,"f":33},{"t":1351736,"n":"Debug","d":1351736,"h":12886253624,"f":33},{"t":1351736,"n":"IPOptions","d":1351736,"h":17181220920,"f":33},{"t":1351736,"n":"NoChecksum","d":1351736,"h":21476188216,"f":33},{"t":1351736,"n":"NoDelay","d":1351736,"h":25771155512,"f":33},{"t":1351736,"n":"AcceptConnection","d":1351736,"h":30066122808,"f":33},{"t":1351736,"n":"BsdUrgent","d":1351736,"h":34361090104,"f":33},{"t":1351736,"n":"Expedited","d":1351736,"h":38656057400,"f":33},{"t":1351736,"n":"HeaderIncluded","d":1351736,"h":42951024696,"f":33},{"t":1351736,"n":"TcpKeepAliveTime","d":1351736,"h":47245991992,"f":33},{"t":1351736,"n":"TypeOfService","d":1351736,"h":51540959288,"f":33},{"t":1351736,"n":"IpTimeToLive","d":1351736,"h":55835926584,"f":33},{"t":1351736,"n":"ReuseAddress","d":1351736,"h":60130893880,"f":33},{"t":1351736,"n":"KeepAlive","d":1351736,"h":64425861176,"f":33},{"t":1351736,"n":"MulticastInterface","d":1351736,"h":68720828472,"f":33},{"t":1351736,"n":"MulticastTimeToLive","d":1351736,"h":73015795768,"f":33},{"t":1351736,"n":"MulticastLoopback","d":1351736,"h":77310763064,"f":33},{"t":1351736,"n":"AddMembership","d":1351736,"h":81605730360,"f":33},{"t":1351736,"n":"DropMembership","d":1351736,"h":85900697656,"f":33},{"t":1351736,"n":"DontFragment","d":1351736,"h":90195664952,"f":33},{"t":1351736,"n":"AddSourceMembership","d":1351736,"h":94490632248,"f":33},{"t":1351736,"n":"FastOpen","d":1351736,"h":98785599544,"f":33},{"t":1351736,"n":"DontRoute","d":1351736,"h":103080566840,"f":33},{"t":1351736,"n":"DropSourceMembership","d":1351736,"h":107375534136,"f":33},{"t":1351736,"n":"TcpKeepAliveRetryCount","d":1351736,"h":111670501432,"f":33},{"t":1351736,"n":"BlockSource","d":1351736,"h":115965468728,"f":33},{"t":1351736,"n":"TcpKeepAliveInterval","d":1351736,"h":120260436024,"f":33},{"t":1351736,"n":"UnblockSource","d":1351736,"h":124555403320,"f":33},{"t":1351736,"n":"PacketInformation","d":1351736,"h":128850370616,"f":33},{"t":1351736,"n":"ChecksumCoverage","d":1351736,"h":133145337912,"f":33},{"t":1351736,"n":"HopLimit","d":1351736,"h":137440305208,"f":33},{"t":1351736,"n":"IPProtectionLevel","d":1351736,"h":141735272504,"f":33},{"t":1351736,"n":"IPv6Only","d":1351736,"h":146030239800,"f":33},{"t":1351736,"n":"Broadcast","d":1351736,"h":150325207096,"f":33},{"t":1351736,"n":"UseLoopback","d":1351736,"h":154620174392,"f":33},{"t":1351736,"n":"Linger","d":1351736,"h":158915141688,"f":33},{"t":1351736,"n":"OutOfBandInline","d":1351736,"h":163210108984,"f":33},{"t":1351736,"n":"SendBuffer","d":1351736,"h":167505076280,"f":33},{"t":1351736,"n":"ReceiveBuffer","d":1351736,"h":171800043576,"f":33},{"t":1351736,"n":"SendLowWater","d":1351736,"h":176095010872,"f":33},{"t":1351736,"n":"ReceiveLowWater","d":1351736,"h":180389978168,"f":33},{"t":1351736,"n":"SendTimeout","d":1351736,"h":184684945464,"f":33},{"t":1351736,"n":"ReceiveTimeout","d":1351736,"h":188979912760,"f":33},{"t":1351736,"n":"Error","d":1351736,"h":193274880056,"f":33},{"t":1351736,"n":"Type","d":1351736,"h":197569847352,"f":33},{"t":1351736,"n":"ReuseUnicastPort","d":1351736,"h":201864814648,"f":33},{"t":1351736,"n":"UpdateAcceptContext","d":1351736,"h":206159781944,"f":33},{"t":1351736,"n":"UpdateConnectContext","d":1351736,"h":210454749240,"f":33},{"t":1351736,"n":"MaxConnections","d":1351736,"h":214749716536,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1351736,"h":219044683832,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1351736}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketOptionName`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketShutdown", ($self) => class SocketShutdown extends $.$spc.System.Enum
        {
            static Receive = 0;
            static Send = 1;
            static Both = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Receive": 0n,
                    "Send": 1n,
                    "Both": 2n
                };
            }
            static $h = 1548344;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1548344,"n":"Receive","d":1548344,"h":4296515640,"f":33},{"t":1548344,"n":"Send","d":1548344,"h":8591482936,"f":33},{"t":1548344,"n":"Both","d":1548344,"h":12886450232,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1548344,"h":17181417528,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1548344}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketShutdown`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketType", ($self) => class SocketType extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static Stream = 1;
            static Dgram = 2;
            static Raw = 3;
            static Rdm = 4;
            static Seqpacket = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Stream": 1n,
                    "Dgram": 2n,
                    "Raw": 3n,
                    "Rdm": 4n,
                    "Seqpacket": 5n
                };
            }
            static $h = 1679416;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1679416,"n":"Unknown","d":1679416,"h":4296646712,"f":33},{"t":1679416,"n":"Stream","d":1679416,"h":8591614008,"f":33},{"t":1679416,"n":"Dgram","d":1679416,"h":12886581304,"f":33},{"t":1679416,"n":"Raw","d":1679416,"h":17181548600,"f":33},{"t":1679416,"n":"Rdm","d":1679416,"h":21476515896,"f":33},{"t":1679416,"n":"Seqpacket","d":1679416,"h":25771483192,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1679416,"h":30066450488,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1679416}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketType`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.TransmitFileOptions", ($self) => class TransmitFileOptions extends $.$spc.System.Enum
        {
            static UseDefaultWorkerThread = 0;
            static Disconnect = 1;
            static ReuseSocket = 2;
            static WriteBehind = 4;
            static UseSystemThread = 16;
            static UseKernelApc = 32;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "UseDefaultWorkerThread": 0n,
                    "Disconnect": 1n,
                    "ReuseSocket": 2n,
                    "WriteBehind": 4n,
                    "UseSystemThread": 16n,
                    "UseKernelApc": 32n
                };
            }
            static $h = 1876024;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1876024,"n":"UseDefaultWorkerThread","d":1876024,"h":4296843320,"f":33},{"t":1876024,"n":"Disconnect","d":1876024,"h":8591810616,"f":33},{"t":1876024,"n":"ReuseSocket","d":1876024,"h":12886777912,"f":33},{"t":1876024,"n":"WriteBehind","d":1876024,"h":17181745208,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":1876024,"n":"UseSystemThread","d":1876024,"h":21476712504,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":1876024,"n":"UseKernelApc","d":1876024,"h":25771679800,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":1876024,"h":30066647096,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1876024,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.TransmitFileOptions`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SafeSocketHandle", ($self) => class SafeSocketHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*nint*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 696376;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7405569,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180565560,"f":32769},"n":"IsInvalid","d":696376,"h":12885598264,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":696376,"h":21475532856,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":696376,"h":4295663672,"f":1},{"p":[{"n":"preexistingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":696376,"h":8590630968,"f":1}],"i":[57540609],"h":696376}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.SafeSocketHandle`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SocketAsyncEventArgs", ($self) => class SocketAsyncEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ unsafeSuppressExecutionContextFlow)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Sockets.Socket? */ get AcceptSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket? */ set AcceptSocket(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[]? */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IList<System.ArraySegment<byte>>? */ get BufferList()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IList<System.ArraySegment<byte>>? */ set BufferList(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get BytesTransferred()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Exception? */ get ConnectByNameError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket? */ get ConnectSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DisconnectReuseSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DisconnectReuseSocket(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketAsyncOperation */ get LastOperation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Memory<byte> */ get MemoryBuffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Offset()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.IPPacketInformation */ get ReceiveMessageFromPacketInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ set RemoteEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SendPacketsElement[]? */ get SendPacketsElements()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SendPacketsElement[]? */ set SendPacketsElements(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TransmitFileOptions */ get SendPacketsFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TransmitFileOptions */ set SendPacketsFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendPacketsSendSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendPacketsSendSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketError */ get SocketError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketError */ set SocketError(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketFlags */ get SocketFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketFlags */ set SocketFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ get UserToken()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ set UserToken(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.EventHandler<System.Net.Sockets.SocketAsyncEventArgs>?*/ add_Completed(value)
            {
            }
            /*System.EventHandler<System.Net.Sockets.SocketAsyncEventArgs>?*/ remove_Completed(value)
            {
            }
            /*void */ Dispose()
            {
            }
            $dtor()
            {
            }
            /*void */ OnCompleted(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
            }
            /*void */ SetBuffer(/*byte[]?*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ SetBuffer$1(/*int*/ offset, /*int*/ count)
            {
            }
            /*void */ SetBuffer$2(/*System.Memory<byte>*/ buffer)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 958520;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":892984,"g":{"r":0,"d":0,"h":17180827704,"f":1},"s":{"r":0,"d":0,"h":21475795000,"f":1},"n":"AcceptSocket","d":958520,"h":12885860408,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30065729592,"f":1},"n":"Buffer","d":958520,"h":25770762296,"f":1},{"p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h,"g":{"r":0,"d":0,"h":38655664184,"f":1},"s":{"r":0,"d":0,"h":42950631480,"f":1},"n":"BufferList","d":958520,"h":34360696888,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51540566072,"f":1},"n":"BytesTransferred","d":958520,"h":47245598776,"f":1},{"p":47251457,"g":{"r":0,"d":0,"h":60130500664,"f":1},"n":"ConnectByNameError","d":958520,"h":55835533368,"f":1},{"p":892984,"g":{"r":0,"d":0,"h":68720435256,"f":1},"n":"ConnectSocket","d":958520,"h":64425467960,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":77310369848,"f":1},"n":"Count","d":958520,"h":73015402552,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85900304440,"f":1},"s":{"r":0,"d":0,"h":90195271736,"f":1},"n":"DisconnectReuseSocket","d":958520,"h":81605337144,"f":1},{"p":1024056,"g":{"r":0,"d":0,"h":98785206328,"f":1},"n":"LastOperation","d":958520,"h":94490239032,"f":1},{"p":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":107375140920,"f":1},"n":"MemoryBuffer","d":958520,"h":103080173624,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":115965075512,"f":1},"n":"Offset","d":958520,"h":111670108216,"f":1},{"p":172088,"g":{"r":0,"d":0,"h":124555010104,"f":1},"n":"ReceiveMessageFromPacketInfo","d":958520,"h":120260042808,"f":1},{"p":2597362,"g":{"r":0,"d":0,"h":133144944696,"f":1},"s":{"r":0,"d":0,"h":137439911992,"f":1},"n":"RemoteEndPoint","d":958520,"h":128849977400,"f":1},{"p":0,"g":{"r":0,"d":0,"h":146029846584,"f":1},"s":{"r":0,"d":0,"h":150324813880,"f":1},"n":"SendPacketsElements","d":958520,"h":141734879288,"f":1},{"p":1876024,"g":{"r":0,"d":0,"h":158914748472,"f":1},"s":{"r":0,"d":0,"h":163209715768,"f":1},"n":"SendPacketsFlags","d":958520,"h":154619781176,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":171799650360,"f":1},"s":{"r":0,"d":0,"h":176094617656,"f":1},"n":"SendPacketsSendSize","d":958520,"h":167504683064,"f":1},{"p":4694514,"g":{"r":0,"d":0,"h":184684552248,"f":1},"s":{"r":0,"d":0,"h":188979519544,"f":1},"n":"SocketError","d":958520,"h":180389584952,"f":1},{"p":1089592,"g":{"r":0,"d":0,"h":197569454136,"f":1},"s":{"r":0,"d":0,"h":201864421432,"f":1},"n":"SocketFlags","d":958520,"h":193274486840,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":210454356024,"f":1},"s":{"r":0,"d":0,"h":214749323320,"f":1},"n":"UserToken","d":958520,"h":206159388728,"f":1}],"m":[{"r":65537,"n":"Dispose","d":958520,"h":231929192504,"f":1},{"r":65537,"p":[{"n":"e","p":958520}],"n":"OnCompleted","d":958520,"h":240519127096,"f":132},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"SetBuffer","d":958520,"h":244814094392,"f":1},{"r":65537,"p":[{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"SetBuffer","o":"@$1","d":958520,"h":249109061688,"f":1},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h}],"n":"SetBuffer","o":"@$2","d":958520,"h":253404028984,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":958520,"h":4295925816,"f":1},{"p":[{"n":"unsafeSuppressExecutionContextFlow","p":262145}],"n":".ctor","o":"$ctor$3","d":958520,"h":8590893112,"f":1}],"e":[{"e":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h}],"n":"add_Completed","d":958520,"h":223339257912,"f":1},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h}],"n":"remove_Completed","d":958520,"h":227634225208,"f":1},"n":"Completed","d":958520,"h":219044290616,"f":1}],"i":[57540609],"h":958520}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.SocketAsyncEventArgs`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution"))