
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $ssc, $sris, $scsl, $sl, $snp, $sspw, $sdd, $snnr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Sockets", 
    {"h":64095,"f":"System.Net.Sockets","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Sockets","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Sockets","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sns.System.Net.Sockets.IPv6MulticastOption", ($self) => class IPv6MulticastOption extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.IPAddress*/ group)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ group, /*long*/ ifindex)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get InterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set InterfaceIndex(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 326239;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3053002,"g":{"r":0,"d":0,"h":17180195423,"f":1},"s":{"r":0,"d":0,"h":21475162719,"f":1},"n":"Group","d":326239,"h":12885228127,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":30065097311,"f":1},"s":{"r":0,"d":0,"h":34360064607,"f":1},"n":"InterfaceIndex","d":326239,"h":25770130015,"f":1}],"c":[{"p":[{"n":"group","p":3053002}],"n":".ctor","o":"$ctor$1","d":326239,"h":4295293535,"f":1},{"p":[{"n":"group","p":3053002},{"n":"ifindex","p":917505}],"n":".ctor","o":"$ctor$2","d":326239,"h":8590260831,"f":1}],"h":326239}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.IPv6MulticastOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.LingerOption", ($self) => class LingerOption extends $.$spc.System.Object
        {
            $ctor$1(/*bool*/ enable, /*int*/ seconds)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Enabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Enabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get LingerTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set LingerTime(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.LingerOption.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.LingerOption.GetHashCode.apply(this, arguments); }
            static $h = 391775;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885293663,"f":1},"s":{"r":0,"d":0,"h":17180260959,"f":1},"n":"Enabled","d":391775,"h":8590326367,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25770195551,"f":1},"s":{"r":0,"d":0,"h":30065162847,"f":1},"n":"LingerTime","d":391775,"h":21475228255,"f":1}],"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":391775,"h":34360130143,"f":32769},{"r":655361,"n":"GetHashCode","d":391775,"h":38655097439,"f":32769}],"c":[{"p":[{"n":"enable","p":262145},{"n":"seconds","p":655361}],"n":".ctor","o":"$ctor$1","d":391775,"h":4295359071,"f":1}],"h":391775}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.LingerOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.MulticastOption", ($self) => class MulticastOption extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.IPAddress*/ group)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ group, /*int*/ interfaceIndex)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.IPAddress*/ group, /*System.Net.IPAddress*/ mcint)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress */ get Group()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress */ set Group(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InterfaceIndex(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress? */ get LocalAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress? */ set LocalAddress(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 457311;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3053002,"g":{"r":0,"d":0,"h":21475293791,"f":1},"s":{"r":0,"d":0,"h":25770261087,"f":1},"n":"Group","d":457311,"h":17180326495,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360195679,"f":1},"s":{"r":0,"d":0,"h":38655162975,"f":1},"n":"InterfaceIndex","d":457311,"h":30065228383,"f":1},{"p":3053002,"g":{"r":0,"d":0,"h":47245097567,"f":1},"s":{"r":0,"d":0,"h":51540064863,"f":1},"n":"LocalAddress","d":457311,"h":42950130271,"f":1}],"c":[{"p":[{"n":"group","p":3053002}],"n":".ctor","o":"$ctor$1","d":457311,"h":4295424607,"f":1},{"p":[{"n":"group","p":3053002},{"n":"interfaceIndex","p":655361}],"n":".ctor","o":"$ctor$2","d":457311,"h":8590391903,"f":1},{"p":[{"n":"group","p":3053002},{"n":"mcint","p":3053002}],"n":".ctor","o":"$ctor$3","d":457311,"h":12885359199,"f":1}],"h":457311}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.MulticastOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SendPacketsElement", ($self) => class SendPacketsElement extends $.$spc.System.Object
        {
            $ctor$1(/*byte[]*/ buffer)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.FileStream*/ fileStream)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.FileStream*/ fileStream, /*long*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.FileStream*/ fileStream, /*long*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$7(/*System.ReadOnlyMemory<byte>*/ buffer)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$8(/*System.ReadOnlyMemory<byte>*/ buffer, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$9(/*string*/ filepath)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$10(/*string*/ filepath, /*int*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$11(/*string*/ filepath, /*int*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$12(/*string*/ filepath, /*long*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$13(/*string*/ filepath, /*long*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*byte[]? */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EndOfPacket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FilePath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.FileStream? */ get FileStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ReadOnlyMemory<byte>? */ get MemoryBuffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Offset()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get OffsetLong()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 850527;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":64425359967,"f":1},"n":"Buffer","d":850527,"h":60130392671,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73015294559,"f":1},"n":"Count","d":850527,"h":68720327263,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81605229151,"f":1},"n":"EndOfPacket","d":850527,"h":77310261855,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90195163743,"f":1},"n":"FilePath","d":850527,"h":85900196447,"f":1},{"p":60293121,"g":{"r":0,"d":0,"h":98785098335,"f":1},"n":"FileStream","d":850527,"h":94490131039,"f":1},{"p":$.$typeNullable($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte)).$h,"g":{"r":0,"d":0,"h":107375032927,"f":1},"n":"MemoryBuffer","d":850527,"h":103080065631,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":115964967519,"f":1},"n":"Offset","d":850527,"h":111670000223,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":124554902111,"f":1},"n":"OffsetLong","d":850527,"h":120259934815,"f":1}],"c":[{"p":[{"n":"buffer","p":0}],"n":".ctor","o":"$ctor$1","d":850527,"h":4295817823,"f":1},{"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$2","d":850527,"h":8590785119,"f":1},{"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$3","d":850527,"h":12885752415,"f":1},{"p":[{"n":"fileStream","p":60293121}],"n":".ctor","o":"$ctor$4","d":850527,"h":17180719711,"f":1},{"p":[{"n":"fileStream","p":60293121},{"n":"offset","p":917505},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$5","d":850527,"h":21475687007,"f":1},{"p":[{"n":"fileStream","p":60293121},{"n":"offset","p":917505},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$6","d":850527,"h":25770654303,"f":1},{"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h}],"n":".ctor","o":"$ctor$7","d":850527,"h":30065621599,"f":1},{"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$8","d":850527,"h":34360588895,"f":1},{"p":[{"n":"filepath","p":1310721}],"n":".ctor","o":"$ctor$9","d":850527,"h":38655556191,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$10","d":850527,"h":42950523487,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$11","d":850527,"h":47245490783,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":917505},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$12","d":850527,"h":51540458079,"f":1},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":917505},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$13","d":850527,"h":55835425375,"f":1}],"h":850527}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SendPacketsElement`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SocketTaskExtensions", ($self) => class SocketTaskExtensions
        {
            static /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync(/*this System.Net.Sockets.Socket*/ socket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.Sockets.Socket?*/ acceptSocket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$4(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$6(/*this System.Net.Sockets.Socket*/ socket, /*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$7(/*this System.Net.Sockets.Socket*/ socket, /*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ ReceiveAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ ReceiveAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<int> */ SendAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendToAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1636959;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"socket","p":916063}],"n":"AcceptAsync","d":1636959,"h":4296604255,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"socket","p":916063},{"n":"acceptSocket","p":916063}],"n":"AcceptAsync","o":"@$1","d":1636959,"h":8591571551,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":133300225,"p":[{"n":"socket","p":916063},{"n":"remoteEP","p":2594250}],"n":"ConnectAsync","d":1636959,"h":12886538847,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":136118273,"p":[{"n":"socket","p":916063},{"n":"remoteEP","p":2594250},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":1636959,"h":17181506143,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":133300225,"p":[{"n":"socket","p":916063},{"n":"address","p":3053002},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":1636959,"h":21476473439,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":136118273,"p":[{"n":"socket","p":916063},{"n":"address","p":3053002},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":1636959,"h":25771440735,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":133300225,"p":[{"n":"socket","p":916063},{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$4","d":1636959,"h":30066408031,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":136118273,"p":[{"n":"socket","p":916063},{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":1636959,"h":34361375327,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":133300225,"p":[{"n":"socket","p":916063},{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$6","d":1636959,"h":38656342623,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":136118273,"p":[{"n":"socket","p":916063},{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$7","d":1636959,"h":42951309919,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":916063},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671}],"n":"ReceiveAsync","d":1636959,"h":47246277215,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":916063},{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1112671}],"n":"ReceiveAsync","o":"@$1","d":1636959,"h":51541244511,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":916063},{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$2","d":1636959,"h":55836211807,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"socket","p":916063},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"remoteEndPoint","p":2594250}],"n":"ReceiveFromAsync","d":1636959,"h":60131179103,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"socket","p":916063},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"remoteEndPoint","p":2594250}],"n":"ReceiveMessageFromAsync","d":1636959,"h":64426146399,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":916063},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671}],"n":"SendAsync","d":1636959,"h":68721113695,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":916063},{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1112671}],"n":"SendAsync","o":"@$1","d":1636959,"h":73016080991,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":916063},{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$2","d":1636959,"h":77311048287,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"socket","p":916063},{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"remoteEP","p":2594250}],"n":"SendToAsync","d":1636959,"h":81606015583,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}],"h":1636959,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SocketTaskExtensions`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.Socket", ($self) => class Socket extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.Sockets.AddressFamily*/ addressFamily, /*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.Sockets.SafeSocketHandle*/ handle)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.Sockets.SocketInformation*/ socketInformation)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.Sockets.AddressFamily */ get AddressFamily()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Blocking()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Blocking(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Connected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DontFragment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DontFragment(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DualMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DualMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableBroadcast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableBroadcast(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*nint */ get Handle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsBound()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ get LingerState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ set LingerState(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get MulticastLoopback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MulticastLoopback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get NoDelay()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set NoDelay(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsIPv4()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsIPv6()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsUnixDomainSockets()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.ProtocolType */ get ProtocolType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SafeSocketHandle */ get SafeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketType */ get SocketType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get SupportsIPv4()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get SupportsIPv6()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ get Ttl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ set Ttl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseOnlyOverlappedIO()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseOnlyOverlappedIO(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ Accept()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync$1(/*System.Net.Sockets.Socket?*/ acceptSocket)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptAsync$2(/*System.Net.Sockets.Socket?*/ acceptSocket, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ AcceptAsync$3(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptAsync$4(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept$1(/*int*/ receiveSize, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept$2(/*System.Net.Sockets.Socket?*/ acceptSocket, /*int*/ receiveSize, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect(/*System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$1(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$3(/*string*/ host, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginDisconnect(/*bool*/ reuseSocket, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceive(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginReceive$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceive$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginReceive$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceiveFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceiveMessageFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginSend$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginSend$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendFile(/*string?*/ fileName, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendFile$1(/*string?*/ fileName, /*byte[]?*/ preBuffer, /*byte[]?*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendTo(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Bind(/*System.Net.EndPoint*/ localEP)
            {
            }
            static /*void */ CancelConnectAsync(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
            }
            /*void */ Close()
            {
            }
            /*void */ Close$1(/*int*/ timeout)
            {
            }
            /*void */ Connect(/*System.Net.EndPoint*/ remoteEP)
            {
            }
            /*void */ Connect$1(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
            }
            /*void */ Connect$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
            }
            /*void */ Connect$3(/*string*/ host, /*int*/ port)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync(/*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ConnectAsync$6(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ ConnectAsync$7(/*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType, /*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$8(/*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$9(/*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Disconnect(/*bool*/ reuseSocket)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisconnectAsync(/*bool*/ reuseSocket, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ DisconnectAsync$1(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Net.Sockets.SocketInformation */ DuplicateAndClose(/*int*/ targetProcessId)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept(/*out byte[]*/ buffer, /*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept$1(/*out byte[]*/ buffer, /*out int*/ bytesTransferred, /*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept$2(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndConnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndDisconnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndReceive(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceive$1(/*System.IAsyncResult*/ asyncResult, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceiveFrom(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.EndPoint*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceiveMessageFrom(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ endPoint, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend$1(/*System.IAsyncResult*/ asyncResult, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndSendFile(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndSendTo(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            /*int */ GetRawSocketOption(/*int*/ optionLevel, /*int*/ optionName, /*System.Span<byte>*/ optionValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ GetSocketOption(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetSocketOption$1(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*byte[]*/ optionValue)
            {
            }
            /*byte[] */ GetSocketOption$2(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*int*/ optionLength)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ IOControl(/*int*/ ioControlCode, /*byte[]?*/ optionInValue, /*byte[]?*/ optionOutValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ IOControl$1(/*System.Net.Sockets.IOControlCode*/ ioControlCode, /*byte[]?*/ optionInValue, /*byte[]?*/ optionOutValue)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Listen()
            {
            }
            /*void */ Listen$1(/*int*/ backlog)
            {
            }
            /*bool */ Poll(/*int*/ microSeconds, /*System.Net.Sockets.SelectMode*/ mode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Poll$1(/*System.TimeSpan*/ timeout, /*System.Net.Sockets.SelectMode*/ mode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive(/*byte[]*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$3(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$4(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$5(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$6(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$7(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$8(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$9(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$10(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync(/*System.ArraySegment<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$4(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$5(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveAsync$6(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$1(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$2(/*byte[]*/ buffer, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$4(/*System.Span<byte>*/ buffer, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$5(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$6(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ receivedAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$2(/*System.Memory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$3(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveFromAsync$4(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ receivedAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveFromAsync$5(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveMessageFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveMessageFrom$1(/*System.Span<byte>*/ buffer, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$2(/*System.Memory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$3(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveMessageFromAsync$4(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ Select(/*System.Collections.IList?*/ checkRead, /*System.Collections.IList?*/ checkWrite, /*System.Collections.IList?*/ checkError, /*int*/ microSeconds)
            {
            }
            static /*void */ Select$1(/*System.Collections.IList?*/ checkRead, /*System.Collections.IList?*/ checkWrite, /*System.Collections.IList?*/ checkError, /*System.TimeSpan*/ timeout)
            {
            }
            /*int */ Send(/*byte[]*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$3(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$4(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$5(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$6(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$7(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$8(/*System.ReadOnlySpan<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$9(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$10(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync(/*System.ArraySegment<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendAsync$4(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$5(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$6(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SendFile(/*string?*/ fileName)
            {
            }
            /*void */ SendFile$1(/*string?*/ fileName, /*byte[]?*/ preBuffer, /*byte[]?*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags)
            {
            }
            /*void */ SendFile$2(/*string?*/ fileName, /*System.ReadOnlySpan<byte>*/ preBuffer, /*System.ReadOnlySpan<byte>*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags)
            {
            }
            /*System.Threading.Tasks.ValueTask */ SendFileAsync(/*string?*/ fileName, /*System.ReadOnlyMemory<byte>*/ preBuffer, /*System.ReadOnlyMemory<byte>*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ SendFileAsync$1(/*string?*/ fileName, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendPacketsAsync(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$1(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$2(/*byte[]*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$4(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$5(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$6(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ socketAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendToAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendToAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendToAsync$2(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$3(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$4(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$5(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ socketAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetIPProtectionLevel(/*System.Net.Sockets.IPProtectionLevel*/ level)
            {
            }
            /*void */ SetRawSocketOption(/*int*/ optionLevel, /*int*/ optionName, /*System.ReadOnlySpan<byte>*/ optionValue)
            {
            }
            /*void */ SetSocketOption(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*bool*/ optionValue)
            {
            }
            /*void */ SetSocketOption$1(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*byte[]*/ optionValue)
            {
            }
            /*void */ SetSocketOption$2(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*int*/ optionValue)
            {
            }
            /*void */ SetSocketOption$3(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*object*/ optionValue)
            {
            }
            /*void */ Shutdown(/*System.Net.Sockets.SocketShutdown*/ how)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 916063;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4494794,"g":{"r":0,"d":0,"h":25770719839,"f":1},"n":"AddressFamily","d":916063,"h":21475752543,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360654431,"f":1},"n":"Available","d":916063,"h":30065687135,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950589023,"f":1},"s":{"r":0,"d":0,"h":47245556319,"f":1},"n":"Blocking","d":916063,"h":38655621727,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55835490911,"f":1},"n":"Connected","d":916063,"h":51540523615,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64425425503,"f":1},"s":{"r":0,"d":0,"h":68720392799,"f":1},"n":"DontFragment","d":916063,"h":60130458207,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77310327391,"f":1},"s":{"r":0,"d":0,"h":81605294687,"f":1},"n":"DualMode","d":916063,"h":73015360095,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":90195229279,"f":1},"s":{"r":0,"d":0,"h":94490196575,"f":1},"n":"EnableBroadcast","d":916063,"h":85900261983,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":103080131167,"f":1},"s":{"r":0,"d":0,"h":107375098463,"f":1},"n":"ExclusiveAddressUse","d":916063,"h":98785163871,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":115965033055,"f":1},"n":"Handle","d":916063,"h":111670065759,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554967647,"f":1},"n":"IsBound","d":916063,"h":120260000351,"f":1},{"p":391775,"g":{"r":0,"d":0,"h":133144902239,"f":1},"s":{"r":0,"d":0,"h":137439869535,"f":1},"n":"LingerState","d":916063,"h":128849934943,"f":1},{"p":2594250,"g":{"r":0,"d":0,"h":146029804127,"f":1},"n":"LocalEndPoint","d":916063,"h":141734836831,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":154619738719,"f":1},"s":{"r":0,"d":0,"h":158914706015,"f":1},"n":"MulticastLoopback","d":916063,"h":150324771423,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":167504640607,"f":1},"s":{"r":0,"d":0,"h":171799607903,"f":1},"n":"NoDelay","d":916063,"h":163209673311,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":180389542495,"f":33},"n":"OSSupportsIPv4","d":916063,"h":176094575199,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":188979477087,"f":33},"n":"OSSupportsIPv6","d":916063,"h":184684509791,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":197569411679,"f":33},"n":"OSSupportsUnixDomainSockets","d":916063,"h":193274444383,"f":33},{"p":653919,"g":{"r":0,"d":0,"h":206159346271,"f":1},"n":"ProtocolType","d":916063,"h":201864378975,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":214749280863,"f":1},"s":{"r":0,"d":0,"h":219044248159,"f":1},"n":"ReceiveBufferSize","d":916063,"h":210454313567,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":227634182751,"f":1},"s":{"r":0,"d":0,"h":231929150047,"f":1},"n":"ReceiveTimeout","d":916063,"h":223339215455,"f":1},{"p":2594250,"g":{"r":0,"d":0,"h":240519084639,"f":1},"n":"RemoteEndPoint","d":916063,"h":236224117343,"f":1},{"p":719455,"g":{"r":0,"d":0,"h":249109019231,"f":1},"n":"SafeHandle","d":916063,"h":244814051935,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":257698953823,"f":1},"s":{"r":0,"d":0,"h":261993921119,"f":1},"n":"SendBufferSize","d":916063,"h":253403986527,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":270583855711,"f":1},"s":{"r":0,"d":0,"h":274878823007,"f":1},"n":"SendTimeout","d":916063,"h":266288888415,"f":1},{"p":1702495,"g":{"r":0,"d":0,"h":283468757599,"f":1},"n":"SocketType","d":916063,"h":279173790303,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":292058692191,"f":33},"n":"SupportsIPv4","d":916063,"h":287763724895,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SupportsIPv4 has been deprecated. Use OSSupportsIPv4 instead.","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":300648626783,"f":33},"n":"SupportsIPv6","d":916063,"h":296353659487,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SupportsIPv6 has been deprecated. Use OSSupportsIPv6 instead.","t":1310721}]}]},{"p":524289,"g":{"r":0,"d":0,"h":309238561375,"f":1},"s":{"r":0,"d":0,"h":313533528671,"f":1},"n":"Ttl","d":916063,"h":304943594079,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":322123463263,"f":1},"s":{"r":0,"d":0,"h":326418430559,"f":1},"n":"UseOnlyOverlappedIO","d":916063,"h":317828495967,"f":1,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":8660844545,"a":[{"v":"UseOnlyOverlappedIO has been deprecated and is not supported.","t":1310721}]}]}],"m":[{"r":916063,"n":"Accept","d":916063,"h":330713397855,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"n":"AcceptAsync","d":916063,"h":335008365151,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"acceptSocket","p":916063}],"n":"AcceptAsync","o":"@$1","d":916063,"h":339303332447,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"acceptSocket","p":916063},{"n":"cancellationToken","p":125960193}],"n":"AcceptAsync","o":"@$2","d":916063,"h":343598299743,"f":1},{"r":262145,"p":[{"n":"e","p":981599}],"n":"AcceptAsync","o":"@$3","d":916063,"h":347893267039,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptAsync","o":"@$4","d":916063,"h":352188234335,"f":1},{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAccept","d":916063,"h":356483201631,"f":1},{"r":56950785,"p":[{"n":"receiveSize","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAccept","o":"@$1","d":916063,"h":360778168927,"f":1},{"r":56950785,"p":[{"n":"acceptSocket","p":916063},{"n":"receiveSize","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAccept","o":"@$2","d":916063,"h":365073136223,"f":1},{"r":56950785,"p":[{"n":"remoteEP","p":2594250},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","d":916063,"h":369368103519,"f":1},{"r":56950785,"p":[{"n":"address","p":3053002},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$1","d":916063,"h":373663070815,"f":1},{"r":56950785,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$2","d":916063,"h":377958038111,"f":1},{"r":56950785,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$3","d":916063,"h":382253005407,"f":1},{"r":56950785,"p":[{"n":"reuseSocket","p":262145},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginDisconnect","d":916063,"h":386547972703,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1112671},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","d":916063,"h":390842939999,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1112671},{"n":"errorCode","p":4691402,"f":2},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$1","d":916063,"h":395137907295,"f":1},{"r":56950785,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1112671},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$2","d":916063,"h":399432874591,"f":1},{"r":56950785,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1112671},{"n":"errorCode","p":4691402,"f":2},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$3","d":916063,"h":403727841887,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1112671},{"n":"remoteEP","p":2594250,"f":4},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceiveFrom","d":916063,"h":408022809183,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1112671},{"n":"remoteEP","p":2594250,"f":4},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceiveMessageFrom","d":916063,"h":412317776479,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1112671},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","d":916063,"h":416612743775,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1112671},{"n":"errorCode","p":4691402,"f":2},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$1","d":916063,"h":420907711071,"f":1},{"r":56950785,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1112671},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$2","d":916063,"h":425202678367,"f":1},{"r":56950785,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1112671},{"n":"errorCode","p":4691402,"f":2},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$3","d":916063,"h":429497645663,"f":1},{"r":56950785,"p":[{"n":"fileName","p":1310721},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSendFile","d":916063,"h":433792612959,"f":1},{"r":56950785,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":0},{"n":"postBuffer","p":0},{"n":"flags","p":1899103},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSendFile","o":"@$1","d":916063,"h":438087580255,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1112671},{"n":"remoteEP","p":2594250},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginSendTo","d":916063,"h":442382547551,"f":1},{"r":65537,"p":[{"n":"localEP","p":2594250}],"n":"Bind","d":916063,"h":446677514847,"f":1},{"r":65537,"p":[{"n":"e","p":981599}],"n":"CancelConnectAsync","d":916063,"h":450972482143,"f":33},{"r":65537,"n":"Close","d":916063,"h":455267449439,"f":1},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Close","o":"@$1","d":916063,"h":459562416735,"f":1},{"r":65537,"p":[{"n":"remoteEP","p":2594250}],"n":"Connect","d":916063,"h":463857384031,"f":1},{"r":65537,"p":[{"n":"address","p":3053002},{"n":"port","p":655361}],"n":"Connect","o":"@$1","d":916063,"h":468152351327,"f":1},{"r":65537,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"Connect","o":"@$2","d":916063,"h":472447318623,"f":1},{"r":65537,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$3","d":916063,"h":476742285919,"f":1},{"r":133300225,"p":[{"n":"remoteEP","p":2594250}],"n":"ConnectAsync","d":916063,"h":481037253215,"f":1},{"r":136118273,"p":[{"n":"remoteEP","p":2594250},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":916063,"h":485332220511,"f":1},{"r":133300225,"p":[{"n":"address","p":3053002},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":916063,"h":489627187807,"f":1},{"r":136118273,"p":[{"n":"address","p":3053002},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":916063,"h":493922155103,"f":1},{"r":133300225,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$4","d":916063,"h":498217122399,"f":1},{"r":136118273,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":916063,"h":502512089695,"f":1},{"r":262145,"p":[{"n":"e","p":981599}],"n":"ConnectAsync","o":"@$6","d":916063,"h":506807056991,"f":1},{"r":262145,"p":[{"n":"socketType","p":1702495},{"n":"protocolType","p":653919},{"n":"e","p":981599}],"n":"ConnectAsync","o":"@$7","d":916063,"h":511102024287,"f":33},{"r":133300225,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$8","d":916063,"h":515396991583,"f":1},{"r":136118273,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$9","d":916063,"h":519691958879,"f":1},{"r":65537,"p":[{"n":"reuseSocket","p":262145}],"n":"Disconnect","d":916063,"h":523986926175,"f":1},{"r":136118273,"p":[{"n":"reuseSocket","p":262145},{"n":"cancellationToken","p":125960193,"f":65}],"n":"DisconnectAsync","d":916063,"h":528281893471,"f":1},{"r":262145,"p":[{"n":"e","p":981599}],"n":"DisconnectAsync","o":"@$1","d":916063,"h":532576860767,"f":1},{"r":65537,"n":"Dispose","d":916063,"h":536871828063,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":916063,"h":541166795359,"f":132},{"r":1178207,"p":[{"n":"targetProcessId","p":655361}],"n":"DuplicateAndClose","d":916063,"h":545461762655,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":916063,"p":[{"n":"buffer","p":0,"f":2},{"n":"asyncResult","p":56950785}],"n":"EndAccept","d":916063,"h":549756729951,"f":1},{"r":916063,"p":[{"n":"buffer","p":0,"f":2},{"n":"bytesTransferred","p":655361,"f":2},{"n":"asyncResult","p":56950785}],"n":"EndAccept","o":"@$1","d":916063,"h":554051697247,"f":1},{"r":916063,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAccept","o":"@$2","d":916063,"h":558346664543,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndConnect","d":916063,"h":562641631839,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndDisconnect","d":916063,"h":566936599135,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndReceive","d":916063,"h":571231566431,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785},{"n":"errorCode","p":4691402,"f":2}],"n":"EndReceive","o":"@$1","d":916063,"h":575526533727,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785},{"n":"endPoint","p":2594250,"f":4}],"n":"EndReceiveFrom","d":916063,"h":579821501023,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785},{"n":"socketFlags","p":1112671,"f":4},{"n":"endPoint","p":2594250,"f":4},{"n":"ipPacketInformation","p":195167,"f":2}],"n":"EndReceiveMessageFrom","d":916063,"h":584116468319,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndSend","d":916063,"h":588411435615,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785},{"n":"errorCode","p":4691402,"f":2}],"n":"EndSend","o":"@$1","d":916063,"h":592706402911,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndSendFile","d":916063,"h":597001370207,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndSendTo","d":916063,"h":601296337503,"f":1},{"r":655361,"p":[{"n":"optionLevel","p":655361},{"n":"optionName","p":655361},{"n":"optionValue","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetRawSocketOption","d":916063,"h":609886272095,"f":1},{"r":131073,"p":[{"n":"optionLevel","p":1309279},{"n":"optionName","p":1374815}],"n":"GetSocketOption","d":916063,"h":614181239391,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1309279},{"n":"optionName","p":1374815},{"n":"optionValue","p":0}],"n":"GetSocketOption","o":"@$1","d":916063,"h":618476206687,"f":1},{"r":0,"p":[{"n":"optionLevel","p":1309279},{"n":"optionName","p":1374815},{"n":"optionLength","p":655361}],"n":"GetSocketOption","o":"@$2","d":916063,"h":622771173983,"f":1},{"r":655361,"p":[{"n":"ioControlCode","p":655361},{"n":"optionInValue","p":0},{"n":"optionOutValue","p":0}],"n":"IOControl","d":916063,"h":627066141279,"f":1},{"r":655361,"p":[{"n":"ioControlCode","p":129631},{"n":"optionInValue","p":0},{"n":"optionOutValue","p":0}],"n":"IOControl","o":"@$1","d":916063,"h":631361108575,"f":1},{"r":65537,"n":"Listen","d":916063,"h":635656075871,"f":1},{"r":65537,"p":[{"n":"backlog","p":655361}],"n":"Listen","o":"@$1","d":916063,"h":639951043167,"f":1},{"r":262145,"p":[{"n":"microSeconds","p":655361},{"n":"mode","p":784991}],"n":"Poll","d":916063,"h":644246010463,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793},{"n":"mode","p":784991}],"n":"Poll","o":"@$1","d":916063,"h":648540977759,"f":1},{"r":655361,"p":[{"n":"buffer","p":0}],"n":"Receive","d":916063,"h":652835945055,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1112671}],"n":"Receive","o":"@$1","d":916063,"h":657130912351,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1112671},{"n":"errorCode","p":4691402,"f":2}],"n":"Receive","o":"@$2","d":916063,"h":661425879647,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1112671}],"n":"Receive","o":"@$3","d":916063,"h":665720846943,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1112671}],"n":"Receive","o":"@$4","d":916063,"h":670015814239,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"Receive","o":"@$5","d":916063,"h":674310781535,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1112671}],"n":"Receive","o":"@$6","d":916063,"h":678605748831,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1112671},{"n":"errorCode","p":4691402,"f":2}],"n":"Receive","o":"@$7","d":916063,"h":682900716127,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Receive","o":"@$8","d":916063,"h":687195683423,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671}],"n":"Receive","o":"@$9","d":916063,"h":691490650719,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"errorCode","p":4691402,"f":2}],"n":"Receive","o":"@$10","d":916063,"h":695785618015,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h}],"n":"ReceiveAsync","d":916063,"h":700080585311,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671}],"n":"ReceiveAsync","o":"@$1","d":916063,"h":704375552607,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"ReceiveAsync","o":"@$2","d":916063,"h":708670519903,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1112671}],"n":"ReceiveAsync","o":"@$3","d":916063,"h":712965487199,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$4","d":916063,"h":717260454495,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveAsync","o":"@$5","d":916063,"h":721555421791,"f":1},{"r":262145,"p":[{"n":"e","p":981599}],"n":"ReceiveAsync","o":"@$6","d":916063,"h":725850389087,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1112671},{"n":"remoteEP","p":2594250,"f":4}],"n":"ReceiveFrom","d":916063,"h":730145356383,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1112671},{"n":"remoteEP","p":2594250,"f":4}],"n":"ReceiveFrom","o":"@$1","d":916063,"h":734440323679,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"remoteEP","p":2594250,"f":4}],"n":"ReceiveFrom","o":"@$2","d":916063,"h":738735290975,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1112671},{"n":"remoteEP","p":2594250,"f":4}],"n":"ReceiveFrom","o":"@$3","d":916063,"h":743030258271,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2594250,"f":4}],"n":"ReceiveFrom","o":"@$4","d":916063,"h":747325225567,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"remoteEP","p":2594250,"f":4}],"n":"ReceiveFrom","o":"@$5","d":916063,"h":751620192863,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"receivedAddress","p":4363722}],"n":"ReceiveFrom","o":"@$6","d":916063,"h":755915160159,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2594250}],"n":"ReceiveFromAsync","d":916063,"h":760210127455,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"remoteEndPoint","p":2594250}],"n":"ReceiveFromAsync","o":"@$1","d":916063,"h":764505094751,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2594250},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$2","d":916063,"h":768800062047,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"remoteEndPoint","p":2594250},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$3","d":916063,"h":773095029343,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"receivedAddress","p":4363722},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveFromAsync","o":"@$4","d":916063,"h":777389996639,"f":1},{"r":262145,"p":[{"n":"e","p":981599}],"n":"ReceiveFromAsync","o":"@$5","d":916063,"h":781684963935,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1112671,"f":4},{"n":"remoteEP","p":2594250,"f":4},{"n":"ipPacketInformation","p":195167,"f":2}],"n":"ReceiveMessageFrom","d":916063,"h":785979931231,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671,"f":4},{"n":"remoteEP","p":2594250,"f":4},{"n":"ipPacketInformation","p":195167,"f":2}],"n":"ReceiveMessageFrom","o":"@$1","d":916063,"h":790274898527,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2594250}],"n":"ReceiveMessageFromAsync","d":916063,"h":794569865823,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"remoteEndPoint","p":2594250}],"n":"ReceiveMessageFromAsync","o":"@$1","d":916063,"h":798864833119,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"remoteEndPoint","p":2594250},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveMessageFromAsync","o":"@$2","d":916063,"h":803159800415,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"remoteEndPoint","p":2594250},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReceiveMessageFromAsync","o":"@$3","d":916063,"h":807454767711,"f":1},{"r":262145,"p":[{"n":"e","p":981599}],"n":"ReceiveMessageFromAsync","o":"@$4","d":916063,"h":811749735007,"f":1},{"r":65537,"p":[{"n":"checkRead","p":31916033},{"n":"checkWrite","p":31916033},{"n":"checkError","p":31916033},{"n":"microSeconds","p":655361}],"n":"Select","d":916063,"h":816044702303,"f":33},{"r":65537,"p":[{"n":"checkRead","p":31916033},{"n":"checkWrite","p":31916033},{"n":"checkError","p":31916033},{"n":"timeout","p":140705793}],"n":"Select","o":"@$1","d":916063,"h":820339669599,"f":33},{"r":655361,"p":[{"n":"buffer","p":0}],"n":"Send","d":916063,"h":824634636895,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1112671}],"n":"Send","o":"@$1","d":916063,"h":828929604191,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1112671},{"n":"errorCode","p":4691402,"f":2}],"n":"Send","o":"@$2","d":916063,"h":833224571487,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1112671}],"n":"Send","o":"@$3","d":916063,"h":837519538783,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1112671}],"n":"Send","o":"@$4","d":916063,"h":841814506079,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"Send","o":"@$5","d":916063,"h":846109473375,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1112671}],"n":"Send","o":"@$6","d":916063,"h":850404440671,"f":1},{"r":655361,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1112671},{"n":"errorCode","p":4691402,"f":2}],"n":"Send","o":"@$7","d":916063,"h":854699407967,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Send","o":"@$8","d":916063,"h":858994375263,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671}],"n":"Send","o":"@$9","d":916063,"h":863289342559,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"errorCode","p":4691402,"f":2}],"n":"Send","o":"@$10","d":916063,"h":867584309855,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h}],"n":"SendAsync","d":916063,"h":871879277151,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671}],"n":"SendAsync","o":"@$1","d":916063,"h":876174244447,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h}],"n":"SendAsync","o":"@$2","d":916063,"h":880469211743,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffers","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h},{"n":"socketFlags","p":1112671}],"n":"SendAsync","o":"@$3","d":916063,"h":884764179039,"f":1},{"r":262145,"p":[{"n":"e","p":981599}],"n":"SendAsync","o":"@$4","d":916063,"h":889059146335,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$5","d":916063,"h":893354113631,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$6","d":916063,"h":897649080927,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"SendFile","d":916063,"h":901944048223,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":0},{"n":"postBuffer","p":0},{"n":"flags","p":1899103}],"n":"SendFile","o":"@$1","d":916063,"h":906239015519,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"postBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"flags","p":1899103}],"n":"SendFile","o":"@$2","d":916063,"h":910533982815,"f":1},{"r":136118273,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"postBuffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"flags","p":1899103},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendFileAsync","d":916063,"h":914828950111,"f":1},{"r":136118273,"p":[{"n":"fileName","p":1310721},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendFileAsync","o":"@$1","d":916063,"h":919123917407,"f":1},{"r":262145,"p":[{"n":"e","p":981599}],"n":"SendPacketsAsync","d":916063,"h":923418884703,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1112671},{"n":"remoteEP","p":2594250}],"n":"SendTo","d":916063,"h":927713851999,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"size","p":655361},{"n":"socketFlags","p":1112671},{"n":"remoteEP","p":2594250}],"n":"SendTo","o":"@$1","d":916063,"h":932008819295,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"remoteEP","p":2594250}],"n":"SendTo","o":"@$2","d":916063,"h":936303786591,"f":1},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"socketFlags","p":1112671},{"n":"remoteEP","p":2594250}],"n":"SendTo","o":"@$3","d":916063,"h":940598753887,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2594250}],"n":"SendTo","o":"@$4","d":916063,"h":944893721183,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"remoteEP","p":2594250}],"n":"SendTo","o":"@$5","d":916063,"h":949188688479,"f":1},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"socketAddress","p":4363722}],"n":"SendTo","o":"@$6","d":916063,"h":953483655775,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2594250}],"n":"SendToAsync","d":916063,"h":957778623071,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"remoteEP","p":2594250}],"n":"SendToAsync","o":"@$1","d":916063,"h":962073590367,"f":1},{"r":262145,"p":[{"n":"e","p":981599}],"n":"SendToAsync","o":"@$2","d":916063,"h":966368557663,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"remoteEP","p":2594250},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$3","d":916063,"h":970663524959,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"remoteEP","p":2594250},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$4","d":916063,"h":974958492255,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"socketFlags","p":1112671},{"n":"socketAddress","p":4363722},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendToAsync","o":"@$5","d":916063,"h":979253459551,"f":1},{"r":65537,"p":[{"n":"level","p":260703}],"n":"SetIPProtectionLevel","d":916063,"h":983548426847,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"optionLevel","p":655361},{"n":"optionName","p":655361},{"n":"optionValue","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"SetRawSocketOption","d":916063,"h":987843394143,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1309279},{"n":"optionName","p":1374815},{"n":"optionValue","p":262145}],"n":"SetSocketOption","d":916063,"h":992138361439,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1309279},{"n":"optionName","p":1374815},{"n":"optionValue","p":0}],"n":"SetSocketOption","o":"@$1","d":916063,"h":996433328735,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1309279},{"n":"optionName","p":1374815},{"n":"optionValue","p":655361}],"n":"SetSocketOption","o":"@$2","d":916063,"h":1000728296031,"f":1},{"r":65537,"p":[{"n":"optionLevel","p":1309279},{"n":"optionName","p":1374815},{"n":"optionValue","p":131073}],"n":"SetSocketOption","o":"@$3","d":916063,"h":1005023263327,"f":1},{"r":65537,"p":[{"n":"how","p":1571423}],"n":"Shutdown","d":916063,"h":1009318230623,"f":1}],"c":[{"p":[{"n":"addressFamily","p":4494794},{"n":"socketType","p":1702495},{"n":"protocolType","p":653919}],"n":".ctor","o":"$ctor$1","d":916063,"h":4295883359,"f":1},{"p":[{"n":"handle","p":719455}],"n":".ctor","o":"$ctor$2","d":916063,"h":8590850655,"f":1},{"p":[{"n":"socketInformation","p":1178207}],"n":".ctor","o":"$ctor$3","d":916063,"h":12885817951,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":[{"n":"socketType","p":1702495},{"n":"protocolType","p":653919}],"n":".ctor","o":"$ctor$4","d":916063,"h":17180785247,"f":1}],"i":[57475073],"h":916063}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.Socket`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.TcpClient", ($self) => class TcpClient extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ hostname, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Active(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Client()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ set Client(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Connected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ get LingerState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ set LingerState(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get NoDelay()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set NoDelay(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$1(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$2(/*string*/ host, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close()
            {
            }
            /*void */ Connect(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
            }
            /*void */ Connect$1(/*System.Net.IPAddress[]*/ ipAddresses, /*int*/ port)
            {
            }
            /*void */ Connect$2(/*System.Net.IPEndPoint*/ remoteEP)
            {
            }
            /*void */ Connect$3(/*string*/ hostname, /*int*/ port)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$1(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$3(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Net.IPEndPoint*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$5(/*System.Net.IPEndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$6(/*string*/ host, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$7(/*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ EndConnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*System.Net.Sockets.NetworkStream */ GetStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1768031;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25771571807,"f":4},"s":{"r":0,"d":0,"h":30066539103,"f":4},"n":"Active","d":1768031,"h":21476604511,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":38656473695,"f":1},"n":"Available","d":1768031,"h":34361506399,"f":1},{"p":916063,"g":{"r":0,"d":0,"h":47246408287,"f":1},"s":{"r":0,"d":0,"h":51541375583,"f":1},"n":"Client","d":1768031,"h":42951440991,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131310175,"f":1},"n":"Connected","d":1768031,"h":55836342879,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721244767,"f":1},"s":{"r":0,"d":0,"h":73016212063,"f":1},"n":"ExclusiveAddressUse","d":1768031,"h":64426277471,"f":1},{"p":391775,"g":{"r":0,"d":0,"h":81606146655,"f":1},"s":{"r":0,"d":0,"h":85901113951,"f":1},"n":"LingerState","d":1768031,"h":77311179359,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94491048543,"f":1},"s":{"r":0,"d":0,"h":98786015839,"f":1},"n":"NoDelay","d":1768031,"h":90196081247,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":107375950431,"f":1},"s":{"r":0,"d":0,"h":111670917727,"f":1},"n":"ReceiveBufferSize","d":1768031,"h":103080983135,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":120260852319,"f":1},"s":{"r":0,"d":0,"h":124555819615,"f":1},"n":"ReceiveTimeout","d":1768031,"h":115965885023,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":133145754207,"f":1},"s":{"r":0,"d":0,"h":137440721503,"f":1},"n":"SendBufferSize","d":1768031,"h":128850786911,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":146030656095,"f":1},"s":{"r":0,"d":0,"h":150325623391,"f":1},"n":"SendTimeout","d":1768031,"h":141735688799,"f":1}],"m":[{"r":56950785,"p":[{"n":"address","p":3053002},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","d":1768031,"h":154620590687,"f":1},{"r":56950785,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$1","d":1768031,"h":158915557983,"f":1},{"r":56950785,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$2","d":1768031,"h":163210525279,"f":1},{"r":65537,"n":"Close","d":1768031,"h":167505492575,"f":1},{"r":65537,"p":[{"n":"address","p":3053002},{"n":"port","p":655361}],"n":"Connect","d":1768031,"h":171800459871,"f":1},{"r":65537,"p":[{"n":"ipAddresses","p":0},{"n":"port","p":655361}],"n":"Connect","o":"@$1","d":1768031,"h":176095427167,"f":1},{"r":65537,"p":[{"n":"remoteEP","p":3315146}],"n":"Connect","o":"@$2","d":1768031,"h":180390394463,"f":1},{"r":65537,"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$3","d":1768031,"h":184685361759,"f":1},{"r":133300225,"p":[{"n":"address","p":3053002},{"n":"port","p":655361}],"n":"ConnectAsync","d":1768031,"h":188980329055,"f":1},{"r":136118273,"p":[{"n":"address","p":3053002},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$1","d":1768031,"h":193275296351,"f":1},{"r":133300225,"p":[{"n":"addresses","p":0},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$2","d":1768031,"h":197570263647,"f":1},{"r":136118273,"p":[{"n":"addresses","p":0},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":1768031,"h":201865230943,"f":1},{"r":133300225,"p":[{"n":"remoteEP","p":3315146}],"n":"ConnectAsync","o":"@$4","d":1768031,"h":206160198239,"f":1},{"r":136118273,"p":[{"n":"remoteEP","p":3315146},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$5","d":1768031,"h":210455165535,"f":1},{"r":133300225,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$6","d":1768031,"h":214750132831,"f":1},{"r":136118273,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$7","d":1768031,"h":219045100127,"f":1},{"r":65537,"n":"Dispose","d":1768031,"h":223340067423,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1768031,"h":227635034719,"f":132},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndConnect","d":1768031,"h":231930002015,"f":1},{"r":522847,"n":"GetStream","d":1768031,"h":240519936607,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1768031,"h":4296735327,"f":1},{"p":[{"n":"localEP","p":3315146}],"n":".ctor","o":"$ctor$2","d":1768031,"h":8591702623,"f":1},{"p":[{"n":"family","p":4494794}],"n":".ctor","o":"$ctor$3","d":1768031,"h":12886669919,"f":1},{"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$4","d":1768031,"h":17181637215,"f":1}],"i":[57475073],"h":1768031}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.TcpClient`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.TcpListener", ($self) => class TcpListener extends $.$spc.System.Object
        {
            $ctor$1(/*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ localaddr, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ get LocalEndpoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Server()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ AcceptSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptSocketAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptSocketAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TcpClient */ AcceptTcpClient()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.TcpClient> */ AcceptTcpClientAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.TcpClient> */ AcceptTcpClientAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AllowNatTraversal(/*bool*/ allowed)
            {
            }
            /*System.IAsyncResult */ BeginAcceptSocket(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAcceptTcpClient(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Sockets.TcpListener */ Create(/*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*System.Net.Sockets.Socket */ EndAcceptSocket(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TcpClient */ EndAcceptTcpClient(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Pending()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Start()
            {
            }
            /*void */ Start$1(/*int*/ backlog)
            {
            }
            /*void */ Stop()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1833567;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476670047,"f":4},"n":"Active","d":1833567,"h":17181702751,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":30066604639,"f":1},"s":{"r":0,"d":0,"h":34361571935,"f":1},"n":"ExclusiveAddressUse","d":1833567,"h":25771637343,"f":1},{"p":2594250,"g":{"r":0,"d":0,"h":42951506527,"f":1},"n":"LocalEndpoint","d":1833567,"h":38656539231,"f":1},{"p":916063,"g":{"r":0,"d":0,"h":51541441119,"f":1},"n":"Server","d":1833567,"h":47246473823,"f":1}],"m":[{"r":916063,"n":"AcceptSocket","d":1833567,"h":55836408415,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"n":"AcceptSocketAsync","d":1833567,"h":60131375711,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptSocketAsync","o":"@$1","d":1833567,"h":64426343007,"f":1},{"r":1768031,"n":"AcceptTcpClient","d":1833567,"h":68721310303,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.TcpClient).$h,"n":"AcceptTcpClientAsync","d":1833567,"h":73016277599,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.TcpClient).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"AcceptTcpClientAsync","o":"@$1","d":1833567,"h":77311244895,"f":1},{"r":65537,"p":[{"n":"allowed","p":262145}],"n":"AllowNatTraversal","d":1833567,"h":81606212191,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAcceptSocket","d":1833567,"h":85901179487,"f":1},{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginAcceptTcpClient","d":1833567,"h":90196146783,"f":1},{"r":1833567,"p":[{"n":"port","p":655361}],"n":"Create","d":1833567,"h":94491114079,"f":33},{"r":65537,"n":"Dispose","d":1833567,"h":98786081375,"f":1},{"r":916063,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAcceptSocket","d":1833567,"h":103081048671,"f":1},{"r":1768031,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAcceptTcpClient","d":1833567,"h":107376015967,"f":1},{"r":262145,"n":"Pending","d":1833567,"h":111670983263,"f":1},{"r":65537,"n":"Start","d":1833567,"h":115965950559,"f":1},{"r":65537,"p":[{"n":"backlog","p":655361}],"n":"Start","o":"@$1","d":1833567,"h":120260917855,"f":1},{"r":65537,"n":"Stop","d":1833567,"h":124555885151,"f":1}],"c":[{"p":[{"n":"port","p":655361}],"n":".ctor","o":"$ctor$1","d":1833567,"h":4296800863,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor has been deprecated. Use TcpListener(IPAddress localaddr, int port) instead.","t":1310721}]}]},{"p":[{"n":"localaddr","p":3053002},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":1833567,"h":8591768159,"f":1},{"p":[{"n":"localEP","p":3315146}],"n":".ctor","o":"$ctor$3","d":1833567,"h":12886735455,"f":1}],"i":[57475073],"h":1833567}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.TcpListener`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.UdpClient", ($self) => class UdpClient extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*int*/ port, /*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$6(/*string*/ hostname, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Active(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Client()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ set Client(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DontFragment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DontFragment(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableBroadcast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableBroadcast(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get MulticastLoopback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MulticastLoopback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ get Ttl()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ set Ttl(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AllowNatTraversal(/*bool*/ allowed)
            {
            }
            /*System.IAsyncResult */ BeginReceive(/*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend(/*byte[]*/ datagram, /*int*/ bytes, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$1(/*byte[]*/ datagram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$2(/*byte[]*/ datagram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close()
            {
            }
            /*void */ Connect(/*System.Net.IPAddress*/ addr, /*int*/ port)
            {
            }
            /*void */ Connect$1(/*System.Net.IPEndPoint*/ endPoint)
            {
            }
            /*void */ Connect$2(/*string*/ hostname, /*int*/ port)
            {
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ DropMulticastGroup(/*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ DropMulticastGroup$1(/*System.Net.IPAddress*/ multicastAddr, /*int*/ ifindex)
            {
            }
            /*byte[] */ EndReceive(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.IPEndPoint?*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ JoinMulticastGroup(/*int*/ ifindex, /*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ JoinMulticastGroup$1(/*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ JoinMulticastGroup$2(/*System.Net.IPAddress*/ multicastAddr, /*int*/ timeToLive)
            {
            }
            /*void */ JoinMulticastGroup$3(/*System.Net.IPAddress*/ multicastAddr, /*System.Net.IPAddress*/ localAddress)
            {
            }
            /*byte[] */ Receive(/*ref System.Net.IPEndPoint?*/ remoteEP)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.UdpReceiveResult> */ ReceiveAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.UdpReceiveResult> */ ReceiveAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send(/*byte[]*/ dgram, /*int*/ bytes)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$1(/*byte[]*/ dgram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$2(/*byte[]*/ dgram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$3(/*System.ReadOnlySpan<byte>*/ datagram)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$4(/*System.ReadOnlySpan<byte>*/ datagram, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$5(/*System.ReadOnlySpan<byte>*/ datagram, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync(/*byte[]*/ datagram, /*int*/ bytes)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*byte[]*/ datagram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$2(/*byte[]*/ datagram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$3(/*System.ReadOnlyMemory<byte>*/ datagram, /*System.Net.IPEndPoint?*/ endPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$4(/*System.ReadOnlyMemory<byte>*/ datagram, /*string?*/ hostname, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$5(/*System.ReadOnlyMemory<byte>*/ datagram, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1964639;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34361703007,"f":4},"s":{"r":0,"d":0,"h":38656670303,"f":4},"n":"Active","d":1964639,"h":30066735711,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":47246604895,"f":1},"n":"Available","d":1964639,"h":42951637599,"f":1},{"p":916063,"g":{"r":0,"d":0,"h":55836539487,"f":1},"s":{"r":0,"d":0,"h":60131506783,"f":1},"n":"Client","d":1964639,"h":51541572191,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721441375,"f":1},"s":{"r":0,"d":0,"h":73016408671,"f":1},"n":"DontFragment","d":1964639,"h":64426474079,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81606343263,"f":1},"s":{"r":0,"d":0,"h":85901310559,"f":1},"n":"EnableBroadcast","d":1964639,"h":77311375967,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94491245151,"f":1},"s":{"r":0,"d":0,"h":98786212447,"f":1},"n":"ExclusiveAddressUse","d":1964639,"h":90196277855,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":107376147039,"f":1},"s":{"r":0,"d":0,"h":111671114335,"f":1},"n":"MulticastLoopback","d":1964639,"h":103081179743,"f":1},{"p":524289,"g":{"r":0,"d":0,"h":120261048927,"f":1},"s":{"r":0,"d":0,"h":124556016223,"f":1},"n":"Ttl","d":1964639,"h":115966081631,"f":1}],"m":[{"r":65537,"p":[{"n":"allowed","p":262145}],"n":"AllowNatTraversal","d":1964639,"h":128850983519,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":56950785,"p":[{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginReceive","d":1964639,"h":133145950815,"f":1},{"r":56950785,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","d":1964639,"h":137440918111,"f":1},{"r":56950785,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3315146},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$1","d":1964639,"h":141735885407,"f":1},{"r":56950785,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginSend","o":"@$2","d":1964639,"h":146030852703,"f":1},{"r":65537,"n":"Close","d":1964639,"h":150325819999,"f":1},{"r":65537,"p":[{"n":"addr","p":3053002},{"n":"port","p":655361}],"n":"Connect","d":1964639,"h":154620787295,"f":1},{"r":65537,"p":[{"n":"endPoint","p":3315146}],"n":"Connect","o":"@$1","d":1964639,"h":158915754591,"f":1},{"r":65537,"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Connect","o":"@$2","d":1964639,"h":163210721887,"f":1},{"r":65537,"n":"Dispose","d":1964639,"h":167505689183,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1964639,"h":171800656479,"f":132},{"r":65537,"p":[{"n":"multicastAddr","p":3053002}],"n":"DropMulticastGroup","d":1964639,"h":176095623775,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3053002},{"n":"ifindex","p":655361}],"n":"DropMulticastGroup","o":"@$1","d":1964639,"h":180390591071,"f":1},{"r":0,"p":[{"n":"asyncResult","p":56950785},{"n":"remoteEP","p":3315146,"f":4}],"n":"EndReceive","d":1964639,"h":184685558367,"f":1},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndSend","d":1964639,"h":188980525663,"f":1},{"r":65537,"p":[{"n":"ifindex","p":655361},{"n":"multicastAddr","p":3053002}],"n":"JoinMulticastGroup","d":1964639,"h":193275492959,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3053002}],"n":"JoinMulticastGroup","o":"@$1","d":1964639,"h":197570460255,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3053002},{"n":"timeToLive","p":655361}],"n":"JoinMulticastGroup","o":"@$2","d":1964639,"h":201865427551,"f":1},{"r":65537,"p":[{"n":"multicastAddr","p":3053002},{"n":"localAddress","p":3053002}],"n":"JoinMulticastGroup","o":"@$3","d":1964639,"h":206160394847,"f":1},{"r":0,"p":[{"n":"remoteEP","p":3315146,"f":4}],"n":"Receive","d":1964639,"h":210455362143,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h,"n":"ReceiveAsync","d":1964639,"h":214750329439,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReceiveAsync","o":"@$1","d":1964639,"h":219045296735,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361}],"n":"Send","d":1964639,"h":223340264031,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3315146}],"n":"Send","o":"@$1","d":1964639,"h":227635231327,"f":1},{"r":655361,"p":[{"n":"dgram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Send","o":"@$2","d":1964639,"h":231930198623,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Send","o":"@$3","d":1964639,"h":236225165919,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"endPoint","p":3315146}],"n":"Send","o":"@$4","d":1964639,"h":240520133215,"f":1},{"r":655361,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Send","o":"@$5","d":1964639,"h":244815100511,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361}],"n":"SendAsync","d":1964639,"h":249110067807,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"endPoint","p":3315146}],"n":"SendAsync","o":"@$1","d":1964639,"h":253405035103,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":0},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"SendAsync","o":"@$2","d":1964639,"h":257700002399,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"endPoint","p":3315146},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$3","d":1964639,"h":261994969695,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"hostname","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$4","d":1964639,"h":266289936991,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"datagram","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"SendAsync","o":"@$5","d":1964639,"h":270584904287,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1964639,"h":4296931935,"f":1},{"p":[{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":1964639,"h":8591899231,"f":1},{"p":[{"n":"port","p":655361},{"n":"family","p":4494794}],"n":".ctor","o":"$ctor$3","d":1964639,"h":12886866527,"f":1},{"p":[{"n":"localEP","p":3315146}],"n":".ctor","o":"$ctor$4","d":1964639,"h":17181833823,"f":1},{"p":[{"n":"family","p":4494794}],"n":".ctor","o":"$ctor$5","d":1964639,"h":21476801119,"f":1},{"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$6","d":1964639,"h":25771768415,"f":1}],"i":[57475073],"h":1964639}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.UdpClient`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketInformation", ($self) => class SocketInformation extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.Sockets.SocketInformationOptions */ get Options()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketInformationOptions */ set Options(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ get ProtocolInformation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ set ProtocolInformation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 1178207;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1243743,"g":{"r":0,"d":0,"h":17181047391,"f":1},"s":{"r":0,"d":0,"h":21476014687,"f":1},"n":"Options","d":1178207,"h":12886080095,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30065949279,"f":1},"s":{"r":0,"d":0,"h":34360916575,"f":1},"n":"ProtocolInformation","d":1178207,"h":25770981983,"f":1}],"l":[{"t":131073,"n":"_dummy","d":1178207,"h":4296145503,"f":2},{"t":655361,"n":"_dummyPrimitive","d":1178207,"h":8591112799,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1178207,"h":38655883871,"f":1}],"h":1178207}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketInformation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketReceiveFromResult", ($self) => class SocketReceiveFromResult extends $.$spc.System.ValueType
        {
            /*int*/  get ReceivedBytes() { return this.$getField(0, 4); }
            /*int*/  set ReceivedBytes(value) { this.$setField(0, 4, value); }
            /*System.Net.EndPoint*/  get RemoteEndPoint() { return this.$getField(4, 4); }
            /*System.Net.EndPoint*/  set RemoteEndPoint(value) { this.$setField(4, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ReceivedBytes = this.ReceivedBytes;
                copy.RemoteEndPoint = this.RemoteEndPoint;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ReceivedBytes = 0;
                this.RemoteEndPoint = null;
            }
            static $h = 1440351;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"ReceivedBytes","d":1440351,"h":4296407647,"f":1},{"t":2594250,"n":"RemoteEndPoint","d":1440351,"h":8591374943,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1440351,"h":12886342239,"f":1}],"h":1440351}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketReceiveFromResult`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketReceiveMessageFromResult", ($self) => class SocketReceiveMessageFromResult extends $.$spc.System.ValueType
        {
            /*System.Net.Sockets.IPPacketInformation*/  get PacketInformation() { return this.$getField(0, 8); }
            /*System.Net.Sockets.IPPacketInformation*/  set PacketInformation(value) { this.$setField(0, 8, value); }
            /*int*/  get ReceivedBytes() { return this.$getField(8, 4); }
            /*int*/  set ReceivedBytes(value) { this.$setField(8, 4, value); }
            /*System.Net.EndPoint*/  get RemoteEndPoint() { return this.$getField(12, 4); }
            /*System.Net.EndPoint*/  set RemoteEndPoint(value) { this.$setField(12, 4, value); }
            /*System.Net.Sockets.SocketFlags*/  get SocketFlags() { return this.$getField(16, 4); }
            /*System.Net.Sockets.SocketFlags*/  set SocketFlags(value) { this.$setField(16, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.PacketInformation = this.PacketInformation.Clone();
                copy.ReceivedBytes = this.ReceivedBytes;
                copy.RemoteEndPoint = this.RemoteEndPoint;
                copy.SocketFlags = this.SocketFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.PacketInformation = $.$default($.$sns.System.Net.Sockets.IPPacketInformation);
                this.ReceivedBytes = 0;
                this.RemoteEndPoint = null;
                this.SocketFlags = 0;
            }
            static $h = 1505887;
            static $z = 20;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":195167,"n":"PacketInformation","d":1505887,"h":4296473183,"f":1},{"t":655361,"n":"ReceivedBytes","d":1505887,"h":8591440479,"f":1},{"t":2594250,"n":"RemoteEndPoint","d":1505887,"h":12886407775,"f":1},{"t":1112671,"n":"SocketFlags","d":1505887,"h":17181375071,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1505887,"h":21476342367,"f":1}],"h":1505887}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketReceiveMessageFromResult`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.UnixDomainSocketEndPoint", ($self) => class UnixDomainSocketEndPoint extends $.$snp.System.Net.EndPoint
        {
            $ctor$2(/*string*/ path)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Sockets.AddressFamily */ get AddressFamily()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ Create(/*System.Net.SocketAddress*/ socketAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.GetHashCode.apply(this, arguments); }
            /*System.Net.SocketAddress */ Serialize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.ToString.apply(this, arguments); }
            static $h = 2095711;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2594250,"p":[{"p":4494794,"g":{"r":0,"d":0,"h":12886997599,"f":32769},"n":"AddressFamily","d":2095711,"h":8592030303,"f":32769}],"m":[{"r":2594250,"p":[{"n":"socketAddress","p":4363722}],"n":"Create","d":2095711,"h":17181964895,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2095711,"h":21476932191,"f":32769},{"r":655361,"n":"GetHashCode","d":2095711,"h":25771899487,"f":32769},{"r":4363722,"n":"Serialize","d":2095711,"h":30066866783,"f":32769},{"r":1310721,"n":"ToString","d":2095711,"h":34361834079,"f":32769}],"c":[{"p":[{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$2","d":2095711,"h":4297063007,"f":1}],"h":2095711}; }
            static get $b() { return $.$snp.System.Net.EndPoint; }
            static get $fullName() { return `System.Net.Sockets.UnixDomainSocketEndPoint`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IPPacketInformation", ($self) => class IPPacketInformation extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.IPAddress */ get Address()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Interface()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Sockets.IPPacketInformation*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.IPPacketInformation.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.IPPacketInformation.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Sockets.IPPacketInformation*/ packetInformation1, /*System.Net.Sockets.IPPacketInformation*/ packetInformation2)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Sockets.IPPacketInformation*/ packetInformation1, /*System.Net.Sockets.IPPacketInformation*/ packetInformation2)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IEquatable<System.Net.Sockets.IPPacketInformation>.Equals(System.Net.Sockets.IPPacketInformation)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 195167;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":3053002,"g":{"r":0,"d":0,"h":17180064351,"f":1},"n":"Address","d":195167,"h":12885097055,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25769998943,"f":1},"n":"Interface","d":195167,"h":21475031647,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":195167}],"n":"Equals","o":"@$2","d":195167,"h":30064966239,"f":1},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":195167,"h":34359933535,"f":32769},{"r":655361,"n":"GetHashCode","d":195167,"h":38654900831,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":195167,"h":4295162463,"f":2},{"t":655361,"n":"_dummyPrimitive","d":195167,"h":8590129759,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":195167,"h":51539802719,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.IPPacketInformation).$h],"h":195167}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.IPPacketInformation) ]; }
            static get $fullName() { return `System.Net.Sockets.IPPacketInformation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.UdpReceiveResult", ($self) => class UdpReceiveResult extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$2(/*byte[]*/ buffer, /*System.Net.IPEndPoint*/ remoteEndPoint)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*byte[] */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Sockets.UdpReceiveResult*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sns.System.Net.Sockets.UdpReceiveResult.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.UdpReceiveResult.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Sockets.UdpReceiveResult*/ left, /*System.Net.Sockets.UdpReceiveResult*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Sockets.UdpReceiveResult*/ left, /*System.Net.Sockets.UdpReceiveResult*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IEquatable<System.Net.Sockets.UdpReceiveResult>.Equals(System.Net.Sockets.UdpReceiveResult)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 2030175;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":0,"g":{"r":0,"d":0,"h":21476866655,"f":1},"n":"Buffer","d":2030175,"h":17181899359,"f":1},{"p":3315146,"g":{"r":0,"d":0,"h":30066801247,"f":1},"n":"RemoteEndPoint","d":2030175,"h":25771833951,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":2030175}],"n":"Equals","o":"@$2","d":2030175,"h":34361768543,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2030175,"h":38656735839,"f":32769},{"r":655361,"n":"GetHashCode","d":2030175,"h":42951703135,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":2030175,"h":4296997471,"f":2},{"t":655361,"n":"_dummyPrimitive","d":2030175,"h":8591964767,"f":2}],"c":[{"p":[{"n":"buffer","p":0},{"n":"remoteEndPoint","p":3315146}],"n":".ctor","o":"$ctor$2","d":2030175,"h":12886932063,"f":1},{"n":".ctor","o":"$ctor$3","d":2030175,"h":55836605023,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h],"h":2030175}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sns.System.Net.Sockets.UdpReceiveResult) ]; }
            static get $fullName() { return `System.Net.Sockets.UdpReceiveResult`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.NetworkStream", ($self) => class NetworkStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.Net.Sockets.Socket*/ socket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.Sockets.Socket*/ socket, /*bool*/ ownsSocket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*System.Net.Sockets.Socket*/ socket, /*System.IO.FileAccess*/ access)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$6(/*System.Net.Sockets.Socket*/ socket, /*System.IO.FileAccess*/ access, /*bool*/ ownsSocket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DataAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Readable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Readable(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Socket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Writeable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Writeable(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close$1(/*int*/ timeout)
            {
            }
            /*void */ Close$2(/*System.TimeSpan*/ timeout)
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 522847;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770326623,"f":32769},"n":"CanRead","d":522847,"h":21475359327,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360261215,"f":32769},"n":"CanSeek","d":522847,"h":30065293919,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950195807,"f":32769},"n":"CanTimeout","d":522847,"h":38655228511,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51540130399,"f":32769},"n":"CanWrite","d":522847,"h":47245163103,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60130064991,"f":129},"n":"DataAvailable","d":522847,"h":55835097695,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":68719999583,"f":32769},"n":"Length","d":522847,"h":64425032287,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":77309934175,"f":32769},"s":{"r":0,"d":0,"h":81604901471,"f":32769},"n":"Position","d":522847,"h":73014966879,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":90194836063,"f":4},"s":{"r":0,"d":0,"h":94489803359,"f":4},"n":"Readable","d":522847,"h":85899868767,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":103079737951,"f":32769},"s":{"r":0,"d":0,"h":107374705247,"f":32769},"n":"ReadTimeout","d":522847,"h":98784770655,"f":32769},{"p":916063,"g":{"r":0,"d":0,"h":115964639839,"f":1},"n":"Socket","d":522847,"h":111669672543,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554574431,"f":4},"s":{"r":0,"d":0,"h":128849541727,"f":4},"n":"Writeable","d":522847,"h":120259607135,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":137439476319,"f":32769},"s":{"r":0,"d":0,"h":141734443615,"f":32769},"n":"WriteTimeout","d":522847,"h":133144509023,"f":32769}],"m":[{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginRead","d":522847,"h":146029410911,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWrite","d":522847,"h":150324378207,"f":32769},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Close","o":"@$1","d":522847,"h":154619345503,"f":1},{"r":65537,"p":[{"n":"timeout","p":140705793}],"n":"Close","o":"@$2","d":522847,"h":158914312799,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":522847,"h":163209280095,"f":32772},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":522847,"h":167504247391,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":522847,"h":171799214687,"f":32769},{"r":65537,"n":"Flush","d":522847,"h":180389149279,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":522847,"h":184684116575,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":522847,"h":188979083871,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":522847,"h":193274051167,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":522847,"h":197569018463,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":522847,"h":201863985759,"f":32769},{"r":655361,"n":"ReadByte","d":522847,"h":206158953055,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":522847,"h":210453920351,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":522847,"h":214748887647,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":522847,"h":219043854943,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":522847,"h":223338822239,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":522847,"h":227633789535,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":522847,"h":231928756831,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":522847,"h":236223724127,"f":32769}],"c":[{"p":[{"n":"socket","p":916063}],"n":".ctor","o":"$ctor$3","d":522847,"h":4295490143,"f":1},{"p":[{"n":"socket","p":916063},{"n":"ownsSocket","p":262145}],"n":".ctor","o":"$ctor$4","d":522847,"h":8590457439,"f":1},{"p":[{"n":"socket","p":916063},{"n":"access","p":59703297}],"n":".ctor","o":"$ctor$5","d":522847,"h":12885424735,"f":1},{"p":[{"n":"socket","p":916063},{"n":"access","p":59703297},{"n":"ownsSocket","p":262145}],"n":".ctor","o":"$ctor$6","d":522847,"h":17180392031,"f":1}],"i":[57475073,56885249],"h":522847}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.NetworkStream`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IOControlCode", ($self) => class IOControlCode extends $.$spc.System.Enum
        {
            static EnableCircularQueuing = 671088642n;
            static Flush = 671088644n;
            static AddressListChange = 671088663n;
            static DataToRead = 1074030207n;
            static OobDataRead = 1074033415n;
            static GetBroadcastAddress = 1207959557n;
            static AddressListQuery = 1207959574n;
            static QueryTargetPnpHandle = 1207959576n;
            static AsyncIO = 2147772029n;
            static NonBlockingIO = 2147772030n;
            static AssociateHandle = 2281701377n;
            static MultipointLoopback = 2281701385n;
            static MulticastScope = 2281701386n;
            static SetQos = 2281701387n;
            static SetGroupQos = 2281701388n;
            static RoutingInterfaceChange = 2281701397n;
            static NamespaceChange = 2281701401n;
            static ReceiveAll = 2550136833n;
            static ReceiveAllMulticast = 2550136834n;
            static ReceiveAllIgmpMulticast = 2550136835n;
            static KeepAliveValues = 2550136836n;
            static AbsorbRouterAlert = 2550136837n;
            static UnicastInterface = 2550136838n;
            static LimitBroadcasts = 2550136839n;
            static BindToInterface = 2550136840n;
            static MulticastInterface = 2550136841n;
            static AddMulticastGroupOnInterface = 2550136842n;
            static DeleteMulticastGroupFromInterface = 2550136843n;
            static GetExtensionFunctionPointer = 3355443206n;
            static GetQos = 3355443207n;
            static GetGroupQos = 3355443208n;
            static TranslateHandle = 3355443213n;
            static RoutingInterfaceQuery = 3355443220n;
            static AddressListSort = 3355443225n;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "EnableCircularQueuing": 671088642n,
                    "Flush": 671088644n,
                    "AddressListChange": 671088663n,
                    "DataToRead": 1074030207n,
                    "OobDataRead": 1074033415n,
                    "GetBroadcastAddress": 1207959557n,
                    "AddressListQuery": 1207959574n,
                    "QueryTargetPnpHandle": 1207959576n,
                    "AsyncIO": 2147772029n,
                    "NonBlockingIO": 2147772030n,
                    "AssociateHandle": 2281701377n,
                    "MultipointLoopback": 2281701385n,
                    "MulticastScope": 2281701386n,
                    "SetQos": 2281701387n,
                    "SetGroupQos": 2281701388n,
                    "RoutingInterfaceChange": 2281701397n,
                    "NamespaceChange": 2281701401n,
                    "ReceiveAll": 2550136833n,
                    "ReceiveAllMulticast": 2550136834n,
                    "ReceiveAllIgmpMulticast": 2550136835n,
                    "KeepAliveValues": 2550136836n,
                    "AbsorbRouterAlert": 2550136837n,
                    "UnicastInterface": 2550136838n,
                    "LimitBroadcasts": 2550136839n,
                    "BindToInterface": 2550136840n,
                    "MulticastInterface": 2550136841n,
                    "AddMulticastGroupOnInterface": 2550136842n,
                    "DeleteMulticastGroupFromInterface": 2550136843n,
                    "GetExtensionFunctionPointer": 3355443206n,
                    "GetQos": 3355443207n,
                    "GetGroupQos": 3355443208n,
                    "TranslateHandle": 3355443213n,
                    "RoutingInterfaceQuery": 3355443220n,
                    "AddressListSort": 3355443225n
                };
            }
            static $h = 129631;
            static $z = 8;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int64; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":917505,"l":[{"t":129631,"n":"EnableCircularQueuing","d":129631,"h":4295096927,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"Flush","d":129631,"h":8590064223,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"AddressListChange","d":129631,"h":12885031519,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"DataToRead","d":129631,"h":17179998815,"f":33},{"t":129631,"n":"OobDataRead","d":129631,"h":21474966111,"f":33},{"t":129631,"n":"GetBroadcastAddress","d":129631,"h":25769933407,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"AddressListQuery","d":129631,"h":30064900703,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"QueryTargetPnpHandle","d":129631,"h":34359867999,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"AsyncIO","d":129631,"h":38654835295,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"NonBlockingIO","d":129631,"h":42949802591,"f":33},{"t":129631,"n":"AssociateHandle","d":129631,"h":47244769887,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"MultipointLoopback","d":129631,"h":51539737183,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"MulticastScope","d":129631,"h":55834704479,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"SetQos","d":129631,"h":60129671775,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"SetGroupQos","d":129631,"h":64424639071,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"RoutingInterfaceChange","d":129631,"h":68719606367,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"NamespaceChange","d":129631,"h":73014573663,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"ReceiveAll","d":129631,"h":77309540959,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"ReceiveAllMulticast","d":129631,"h":81604508255,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"ReceiveAllIgmpMulticast","d":129631,"h":85899475551,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"KeepAliveValues","d":129631,"h":90194442847,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"AbsorbRouterAlert","d":129631,"h":94489410143,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"UnicastInterface","d":129631,"h":98784377439,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"LimitBroadcasts","d":129631,"h":103079344735,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"BindToInterface","d":129631,"h":107374312031,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"MulticastInterface","d":129631,"h":111669279327,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"AddMulticastGroupOnInterface","d":129631,"h":115964246623,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"DeleteMulticastGroupFromInterface","d":129631,"h":120259213919,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"GetExtensionFunctionPointer","d":129631,"h":124554181215,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"GetQos","d":129631,"h":128849148511,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"GetGroupQos","d":129631,"h":133144115807,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"TranslateHandle","d":129631,"h":137439083103,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"RoutingInterfaceQuery","d":129631,"h":141734050399,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":129631,"n":"AddressListSort","d":129631,"h":146029017695,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":129631,"h":150323984991,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":129631}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.IOControlCode`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IPProtectionLevel", ($self) => class IPProtectionLevel extends $.$spc.System.Enum
        {
            static Unspecified = -1;
            static Unrestricted = 10;
            static EdgeRestricted = 20;
            static Restricted = 30;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unspecified": -1n,
                    "Unrestricted": 10n,
                    "EdgeRestricted": 20n,
                    "Restricted": 30n
                };
            }
            static $h = 260703;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":260703,"n":"Unspecified","d":260703,"h":4295227999,"f":33},{"t":260703,"n":"Unrestricted","d":260703,"h":8590195295,"f":33},{"t":260703,"n":"EdgeRestricted","d":260703,"h":12885162591,"f":33},{"t":260703,"n":"Restricted","d":260703,"h":17180129887,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":260703,"h":21475097183,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":260703}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.IPProtectionLevel`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.ProtocolFamily", ($self) => class ProtocolFamily extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static Unspecified = 0;
            static Unix = 1;
            static InterNetwork = 2;
            static ImpLink = 3;
            static Pup = 4;
            static Chaos = 5;
            static Ipx = 6;
            static NS = 6;
            static Iso = 7;
            static Osi = 7;
            static Ecma = 8;
            static DataKit = 9;
            static Ccitt = 10;
            static Sna = 11;
            static DecNet = 12;
            static DataLink = 13;
            static Lat = 14;
            static HyperChannel = 15;
            static AppleTalk = 16;
            static NetBios = 17;
            static VoiceView = 18;
            static FireFox = 19;
            static Banyan = 21;
            static Atm = 22;
            static InterNetworkV6 = 23;
            static Cluster = 24;
            static Ieee12844 = 25;
            static Irda = 26;
            static NetworkDesigners = 28;
            static Max = 29;
            static Packet = 65536;
            static ControllerAreaNetwork = 65537;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Unspecified": 0n,
                    "Unix": 1n,
                    "InterNetwork": 2n,
                    "ImpLink": 3n,
                    "Pup": 4n,
                    "Chaos": 5n,
                    "Ipx": 6n,
                    "NS": 6n,
                    "Iso": 7n,
                    "Osi": 7n,
                    "Ecma": 8n,
                    "DataKit": 9n,
                    "Ccitt": 10n,
                    "Sna": 11n,
                    "DecNet": 12n,
                    "DataLink": 13n,
                    "Lat": 14n,
                    "HyperChannel": 15n,
                    "AppleTalk": 16n,
                    "NetBios": 17n,
                    "VoiceView": 18n,
                    "FireFox": 19n,
                    "Banyan": 21n,
                    "Atm": 22n,
                    "InterNetworkV6": 23n,
                    "Cluster": 24n,
                    "Ieee12844": 25n,
                    "Irda": 26n,
                    "NetworkDesigners": 28n,
                    "Max": 29n,
                    "Packet": 65536n,
                    "ControllerAreaNetwork": 65537n
                };
            }
            static $h = 588383;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":588383,"n":"Unknown","d":588383,"h":4295555679,"f":33},{"t":588383,"n":"Unspecified","d":588383,"h":8590522975,"f":33},{"t":588383,"n":"Unix","d":588383,"h":12885490271,"f":33},{"t":588383,"n":"InterNetwork","d":588383,"h":17180457567,"f":33},{"t":588383,"n":"ImpLink","d":588383,"h":21475424863,"f":33},{"t":588383,"n":"Pup","d":588383,"h":25770392159,"f":33},{"t":588383,"n":"Chaos","d":588383,"h":30065359455,"f":33},{"t":588383,"n":"Ipx","d":588383,"h":34360326751,"f":33},{"t":588383,"n":"NS","d":588383,"h":38655294047,"f":33},{"t":588383,"n":"Iso","d":588383,"h":42950261343,"f":33},{"t":588383,"n":"Osi","d":588383,"h":47245228639,"f":33},{"t":588383,"n":"Ecma","d":588383,"h":51540195935,"f":33},{"t":588383,"n":"DataKit","d":588383,"h":55835163231,"f":33},{"t":588383,"n":"Ccitt","d":588383,"h":60130130527,"f":33},{"t":588383,"n":"Sna","d":588383,"h":64425097823,"f":33},{"t":588383,"n":"DecNet","d":588383,"h":68720065119,"f":33},{"t":588383,"n":"DataLink","d":588383,"h":73015032415,"f":33},{"t":588383,"n":"Lat","d":588383,"h":77309999711,"f":33},{"t":588383,"n":"HyperChannel","d":588383,"h":81604967007,"f":33},{"t":588383,"n":"AppleTalk","d":588383,"h":85899934303,"f":33},{"t":588383,"n":"NetBios","d":588383,"h":90194901599,"f":33},{"t":588383,"n":"VoiceView","d":588383,"h":94489868895,"f":33},{"t":588383,"n":"FireFox","d":588383,"h":98784836191,"f":33},{"t":588383,"n":"Banyan","d":588383,"h":103079803487,"f":33},{"t":588383,"n":"Atm","d":588383,"h":107374770783,"f":33},{"t":588383,"n":"InterNetworkV6","d":588383,"h":111669738079,"f":33},{"t":588383,"n":"Cluster","d":588383,"h":115964705375,"f":33},{"t":588383,"n":"Ieee12844","d":588383,"h":120259672671,"f":33},{"t":588383,"n":"Irda","d":588383,"h":124554639967,"f":33},{"t":588383,"n":"NetworkDesigners","d":588383,"h":128849607263,"f":33},{"t":588383,"n":"Max","d":588383,"h":133144574559,"f":33},{"t":588383,"n":"Packet","d":588383,"h":137439541855,"f":33},{"t":588383,"n":"ControllerAreaNetwork","d":588383,"h":141734509151,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":588383,"h":146029476447,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":588383}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.ProtocolFamily`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.ProtocolType", ($self) => class ProtocolType extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static IP = 0;
            static IPv6HopByHopOptions = 0;
            static Unspecified = 0;
            static Icmp = 1;
            static Igmp = 2;
            static Ggp = 3;
            static IPv4 = 4;
            static Tcp = 6;
            static Pup = 12;
            static Udp = 17;
            static Idp = 22;
            static IPv6 = 41;
            static IPv6RoutingHeader = 43;
            static IPv6FragmentHeader = 44;
            static IPSecEncapsulatingSecurityPayload = 50;
            static IPSecAuthenticationHeader = 51;
            static IcmpV6 = 58;
            static IPv6NoNextHeader = 59;
            static IPv6DestinationOptions = 60;
            static ND = 77;
            static Raw = 255;
            static Ipx = 1000;
            static Spx = 1256;
            static SpxII = 1257;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "IP": 0n,
                    "IPv6HopByHopOptions": 0n,
                    "Unspecified": 0n,
                    "Icmp": 1n,
                    "Igmp": 2n,
                    "Ggp": 3n,
                    "IPv4": 4n,
                    "Tcp": 6n,
                    "Pup": 12n,
                    "Udp": 17n,
                    "Idp": 22n,
                    "IPv6": 41n,
                    "IPv6RoutingHeader": 43n,
                    "IPv6FragmentHeader": 44n,
                    "IPSecEncapsulatingSecurityPayload": 50n,
                    "IPSecAuthenticationHeader": 51n,
                    "IcmpV6": 58n,
                    "IPv6NoNextHeader": 59n,
                    "IPv6DestinationOptions": 60n,
                    "ND": 77n,
                    "Raw": 255n,
                    "Ipx": 1000n,
                    "Spx": 1256n,
                    "SpxII": 1257n
                };
            }
            static $h = 653919;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":653919,"n":"Unknown","d":653919,"h":4295621215,"f":33},{"t":653919,"n":"IP","d":653919,"h":8590588511,"f":33},{"t":653919,"n":"IPv6HopByHopOptions","d":653919,"h":12885555807,"f":33},{"t":653919,"n":"Unspecified","d":653919,"h":17180523103,"f":33},{"t":653919,"n":"Icmp","d":653919,"h":21475490399,"f":33},{"t":653919,"n":"Igmp","d":653919,"h":25770457695,"f":33},{"t":653919,"n":"Ggp","d":653919,"h":30065424991,"f":33},{"t":653919,"n":"IPv4","d":653919,"h":34360392287,"f":33},{"t":653919,"n":"Tcp","d":653919,"h":38655359583,"f":33},{"t":653919,"n":"Pup","d":653919,"h":42950326879,"f":33},{"t":653919,"n":"Udp","d":653919,"h":47245294175,"f":33},{"t":653919,"n":"Idp","d":653919,"h":51540261471,"f":33},{"t":653919,"n":"IPv6","d":653919,"h":55835228767,"f":33},{"t":653919,"n":"IPv6RoutingHeader","d":653919,"h":60130196063,"f":33},{"t":653919,"n":"IPv6FragmentHeader","d":653919,"h":64425163359,"f":33},{"t":653919,"n":"IPSecEncapsulatingSecurityPayload","d":653919,"h":68720130655,"f":33},{"t":653919,"n":"IPSecAuthenticationHeader","d":653919,"h":73015097951,"f":33},{"t":653919,"n":"IcmpV6","d":653919,"h":77310065247,"f":33},{"t":653919,"n":"IPv6NoNextHeader","d":653919,"h":81605032543,"f":33},{"t":653919,"n":"IPv6DestinationOptions","d":653919,"h":85899999839,"f":33},{"t":653919,"n":"ND","d":653919,"h":90194967135,"f":33},{"t":653919,"n":"Raw","d":653919,"h":94489934431,"f":33},{"t":653919,"n":"Ipx","d":653919,"h":98784901727,"f":33},{"t":653919,"n":"Spx","d":653919,"h":103079869023,"f":33},{"t":653919,"n":"SpxII","d":653919,"h":107374836319,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":653919,"h":111669803615,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":653919}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.ProtocolType`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SelectMode", ($self) => class SelectMode extends $.$spc.System.Enum
        {
            static SelectRead = 0;
            static SelectWrite = 1;
            static SelectError = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "SelectRead": 0n,
                    "SelectWrite": 1n,
                    "SelectError": 2n
                };
            }
            static $h = 784991;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":784991,"n":"SelectRead","d":784991,"h":4295752287,"f":33},{"t":784991,"n":"SelectWrite","d":784991,"h":8590719583,"f":33},{"t":784991,"n":"SelectError","d":784991,"h":12885686879,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":784991,"h":17180654175,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":784991}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SelectMode`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketAsyncOperation", ($self) => class SocketAsyncOperation extends $.$spc.System.Enum
        {
            static None = 0;
            static Accept = 1;
            static Connect = 2;
            static Disconnect = 3;
            static Receive = 4;
            static ReceiveFrom = 5;
            static ReceiveMessageFrom = 6;
            static Send = 7;
            static SendPackets = 8;
            static SendTo = 9;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Accept": 1n,
                    "Connect": 2n,
                    "Disconnect": 3n,
                    "Receive": 4n,
                    "ReceiveFrom": 5n,
                    "ReceiveMessageFrom": 6n,
                    "Send": 7n,
                    "SendPackets": 8n,
                    "SendTo": 9n
                };
            }
            static $h = 1047135;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1047135,"n":"None","d":1047135,"h":4296014431,"f":33},{"t":1047135,"n":"Accept","d":1047135,"h":8590981727,"f":33},{"t":1047135,"n":"Connect","d":1047135,"h":12885949023,"f":33},{"t":1047135,"n":"Disconnect","d":1047135,"h":17180916319,"f":33},{"t":1047135,"n":"Receive","d":1047135,"h":21475883615,"f":33},{"t":1047135,"n":"ReceiveFrom","d":1047135,"h":25770850911,"f":33},{"t":1047135,"n":"ReceiveMessageFrom","d":1047135,"h":30065818207,"f":33},{"t":1047135,"n":"Send","d":1047135,"h":34360785503,"f":33},{"t":1047135,"n":"SendPackets","d":1047135,"h":38655752799,"f":33},{"t":1047135,"n":"SendTo","d":1047135,"h":42950720095,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1047135,"h":47245687391,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1047135}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketAsyncOperation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketFlags", ($self) => class SocketFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static OutOfBand = 1;
            static Peek = 2;
            static DontRoute = 4;
            static Truncated = 256;
            static ControlDataTruncated = 512;
            static Broadcast = 1024;
            static Multicast = 2048;
            static Partial = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OutOfBand": 1n,
                    "Peek": 2n,
                    "DontRoute": 4n,
                    "Truncated": 256n,
                    "ControlDataTruncated": 512n,
                    "Broadcast": 1024n,
                    "Multicast": 2048n,
                    "Partial": 32768n
                };
            }
            static $h = 1112671;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1112671,"n":"None","d":1112671,"h":4296079967,"f":33},{"t":1112671,"n":"OutOfBand","d":1112671,"h":8591047263,"f":33},{"t":1112671,"n":"Peek","d":1112671,"h":12886014559,"f":33},{"t":1112671,"n":"DontRoute","d":1112671,"h":17180981855,"f":33},{"t":1112671,"n":"Truncated","d":1112671,"h":21475949151,"f":33},{"t":1112671,"n":"ControlDataTruncated","d":1112671,"h":25770916447,"f":33},{"t":1112671,"n":"Broadcast","d":1112671,"h":30065883743,"f":33},{"t":1112671,"n":"Multicast","d":1112671,"h":34360851039,"f":33},{"t":1112671,"n":"Partial","d":1112671,"h":38655818335,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1112671,"h":42950785631,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1112671,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketFlags`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketInformationOptions", ($self) => class SocketInformationOptions extends $.$spc.System.Enum
        {
            static NonBlocking = 1;
            static Connected = 2;
            static Listening = 4;
            static UseOnlyOverlappedIO = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NonBlocking": 1n,
                    "Connected": 2n,
                    "Listening": 4n,
                    "UseOnlyOverlappedIO": 8n
                };
            }
            static $h = 1243743;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1243743,"n":"NonBlocking","d":1243743,"h":4296211039,"f":33},{"t":1243743,"n":"Connected","d":1243743,"h":8591178335,"f":33},{"t":1243743,"n":"Listening","d":1243743,"h":12886145631,"f":33},{"t":1243743,"n":"UseOnlyOverlappedIO","d":1243743,"h":17181112927,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":8660844545,"a":[{"v":"SocketInformationOptions.UseOnlyOverlappedIO has been deprecated and is not supported.","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":1243743,"h":21476080223,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1243743,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketInformationOptions`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketOptionLevel", ($self) => class SocketOptionLevel extends $.$spc.System.Enum
        {
            static IP = 0;
            static Tcp = 6;
            static Udp = 17;
            static IPv6 = 41;
            static Socket = 65535;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "IP": 0n,
                    "Tcp": 6n,
                    "Udp": 17n,
                    "IPv6": 41n,
                    "Socket": 65535n
                };
            }
            static $h = 1309279;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1309279,"n":"IP","d":1309279,"h":4296276575,"f":33},{"t":1309279,"n":"Tcp","d":1309279,"h":8591243871,"f":33},{"t":1309279,"n":"Udp","d":1309279,"h":12886211167,"f":33},{"t":1309279,"n":"IPv6","d":1309279,"h":17181178463,"f":33},{"t":1309279,"n":"Socket","d":1309279,"h":21476145759,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1309279,"h":25771113055,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1309279}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketOptionLevel`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketOptionName", ($self) => class SocketOptionName extends $.$spc.System.Enum
        {
            static DontLinger = -129;
            static ExclusiveAddressUse = -5;
            static Debug = 1;
            static IPOptions = 1;
            static NoChecksum = 1;
            static NoDelay = 1;
            static AcceptConnection = 2;
            static BsdUrgent = 2;
            static Expedited = 2;
            static HeaderIncluded = 2;
            static TcpKeepAliveTime = 3;
            static TypeOfService = 3;
            static IpTimeToLive = 4;
            static ReuseAddress = 4;
            static KeepAlive = 8;
            static MulticastInterface = 9;
            static MulticastTimeToLive = 10;
            static MulticastLoopback = 11;
            static AddMembership = 12;
            static DropMembership = 13;
            static DontFragment = 14;
            static AddSourceMembership = 15;
            static FastOpen = 15;
            static DontRoute = 16;
            static DropSourceMembership = 16;
            static TcpKeepAliveRetryCount = 16;
            static BlockSource = 17;
            static TcpKeepAliveInterval = 17;
            static UnblockSource = 18;
            static PacketInformation = 19;
            static ChecksumCoverage = 20;
            static HopLimit = 21;
            static IPProtectionLevel = 23;
            static IPv6Only = 27;
            static Broadcast = 32;
            static UseLoopback = 64;
            static Linger = 128;
            static OutOfBandInline = 256;
            static SendBuffer = 4097;
            static ReceiveBuffer = 4098;
            static SendLowWater = 4099;
            static ReceiveLowWater = 4100;
            static SendTimeout = 4101;
            static ReceiveTimeout = 4102;
            static Error = 4103;
            static Type = 4104;
            static ReuseUnicastPort = 12295;
            static UpdateAcceptContext = 28683;
            static UpdateConnectContext = 28688;
            static MaxConnections = 2147483647;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "DontLinger": -129n,
                    "ExclusiveAddressUse": -5n,
                    "Debug": 1n,
                    "IPOptions": 1n,
                    "NoChecksum": 1n,
                    "NoDelay": 1n,
                    "AcceptConnection": 2n,
                    "BsdUrgent": 2n,
                    "Expedited": 2n,
                    "HeaderIncluded": 2n,
                    "TcpKeepAliveTime": 3n,
                    "TypeOfService": 3n,
                    "IpTimeToLive": 4n,
                    "ReuseAddress": 4n,
                    "KeepAlive": 8n,
                    "MulticastInterface": 9n,
                    "MulticastTimeToLive": 10n,
                    "MulticastLoopback": 11n,
                    "AddMembership": 12n,
                    "DropMembership": 13n,
                    "DontFragment": 14n,
                    "AddSourceMembership": 15n,
                    "FastOpen": 15n,
                    "DontRoute": 16n,
                    "DropSourceMembership": 16n,
                    "TcpKeepAliveRetryCount": 16n,
                    "BlockSource": 17n,
                    "TcpKeepAliveInterval": 17n,
                    "UnblockSource": 18n,
                    "PacketInformation": 19n,
                    "ChecksumCoverage": 20n,
                    "HopLimit": 21n,
                    "IPProtectionLevel": 23n,
                    "IPv6Only": 27n,
                    "Broadcast": 32n,
                    "UseLoopback": 64n,
                    "Linger": 128n,
                    "OutOfBandInline": 256n,
                    "SendBuffer": 4097n,
                    "ReceiveBuffer": 4098n,
                    "SendLowWater": 4099n,
                    "ReceiveLowWater": 4100n,
                    "SendTimeout": 4101n,
                    "ReceiveTimeout": 4102n,
                    "Error": 4103n,
                    "Type": 4104n,
                    "ReuseUnicastPort": 12295n,
                    "UpdateAcceptContext": 28683n,
                    "UpdateConnectContext": 28688n,
                    "MaxConnections": 2147483647n
                };
            }
            static $h = 1374815;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1374815,"n":"DontLinger","d":1374815,"h":4296342111,"f":33},{"t":1374815,"n":"ExclusiveAddressUse","d":1374815,"h":8591309407,"f":33},{"t":1374815,"n":"Debug","d":1374815,"h":12886276703,"f":33},{"t":1374815,"n":"IPOptions","d":1374815,"h":17181243999,"f":33},{"t":1374815,"n":"NoChecksum","d":1374815,"h":21476211295,"f":33},{"t":1374815,"n":"NoDelay","d":1374815,"h":25771178591,"f":33},{"t":1374815,"n":"AcceptConnection","d":1374815,"h":30066145887,"f":33},{"t":1374815,"n":"BsdUrgent","d":1374815,"h":34361113183,"f":33},{"t":1374815,"n":"Expedited","d":1374815,"h":38656080479,"f":33},{"t":1374815,"n":"HeaderIncluded","d":1374815,"h":42951047775,"f":33},{"t":1374815,"n":"TcpKeepAliveTime","d":1374815,"h":47246015071,"f":33},{"t":1374815,"n":"TypeOfService","d":1374815,"h":51540982367,"f":33},{"t":1374815,"n":"IpTimeToLive","d":1374815,"h":55835949663,"f":33},{"t":1374815,"n":"ReuseAddress","d":1374815,"h":60130916959,"f":33},{"t":1374815,"n":"KeepAlive","d":1374815,"h":64425884255,"f":33},{"t":1374815,"n":"MulticastInterface","d":1374815,"h":68720851551,"f":33},{"t":1374815,"n":"MulticastTimeToLive","d":1374815,"h":73015818847,"f":33},{"t":1374815,"n":"MulticastLoopback","d":1374815,"h":77310786143,"f":33},{"t":1374815,"n":"AddMembership","d":1374815,"h":81605753439,"f":33},{"t":1374815,"n":"DropMembership","d":1374815,"h":85900720735,"f":33},{"t":1374815,"n":"DontFragment","d":1374815,"h":90195688031,"f":33},{"t":1374815,"n":"AddSourceMembership","d":1374815,"h":94490655327,"f":33},{"t":1374815,"n":"FastOpen","d":1374815,"h":98785622623,"f":33},{"t":1374815,"n":"DontRoute","d":1374815,"h":103080589919,"f":33},{"t":1374815,"n":"DropSourceMembership","d":1374815,"h":107375557215,"f":33},{"t":1374815,"n":"TcpKeepAliveRetryCount","d":1374815,"h":111670524511,"f":33},{"t":1374815,"n":"BlockSource","d":1374815,"h":115965491807,"f":33},{"t":1374815,"n":"TcpKeepAliveInterval","d":1374815,"h":120260459103,"f":33},{"t":1374815,"n":"UnblockSource","d":1374815,"h":124555426399,"f":33},{"t":1374815,"n":"PacketInformation","d":1374815,"h":128850393695,"f":33},{"t":1374815,"n":"ChecksumCoverage","d":1374815,"h":133145360991,"f":33},{"t":1374815,"n":"HopLimit","d":1374815,"h":137440328287,"f":33},{"t":1374815,"n":"IPProtectionLevel","d":1374815,"h":141735295583,"f":33},{"t":1374815,"n":"IPv6Only","d":1374815,"h":146030262879,"f":33},{"t":1374815,"n":"Broadcast","d":1374815,"h":150325230175,"f":33},{"t":1374815,"n":"UseLoopback","d":1374815,"h":154620197471,"f":33},{"t":1374815,"n":"Linger","d":1374815,"h":158915164767,"f":33},{"t":1374815,"n":"OutOfBandInline","d":1374815,"h":163210132063,"f":33},{"t":1374815,"n":"SendBuffer","d":1374815,"h":167505099359,"f":33},{"t":1374815,"n":"ReceiveBuffer","d":1374815,"h":171800066655,"f":33},{"t":1374815,"n":"SendLowWater","d":1374815,"h":176095033951,"f":33},{"t":1374815,"n":"ReceiveLowWater","d":1374815,"h":180390001247,"f":33},{"t":1374815,"n":"SendTimeout","d":1374815,"h":184684968543,"f":33},{"t":1374815,"n":"ReceiveTimeout","d":1374815,"h":188979935839,"f":33},{"t":1374815,"n":"Error","d":1374815,"h":193274903135,"f":33},{"t":1374815,"n":"Type","d":1374815,"h":197569870431,"f":33},{"t":1374815,"n":"ReuseUnicastPort","d":1374815,"h":201864837727,"f":33},{"t":1374815,"n":"UpdateAcceptContext","d":1374815,"h":206159805023,"f":33},{"t":1374815,"n":"UpdateConnectContext","d":1374815,"h":210454772319,"f":33},{"t":1374815,"n":"MaxConnections","d":1374815,"h":214749739615,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1374815,"h":219044706911,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1374815}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketOptionName`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketShutdown", ($self) => class SocketShutdown extends $.$spc.System.Enum
        {
            static Receive = 0;
            static Send = 1;
            static Both = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Receive": 0n,
                    "Send": 1n,
                    "Both": 2n
                };
            }
            static $h = 1571423;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1571423,"n":"Receive","d":1571423,"h":4296538719,"f":33},{"t":1571423,"n":"Send","d":1571423,"h":8591506015,"f":33},{"t":1571423,"n":"Both","d":1571423,"h":12886473311,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1571423,"h":17181440607,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1571423}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketShutdown`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketType", ($self) => class SocketType extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static Stream = 1;
            static Dgram = 2;
            static Raw = 3;
            static Rdm = 4;
            static Seqpacket = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Stream": 1n,
                    "Dgram": 2n,
                    "Raw": 3n,
                    "Rdm": 4n,
                    "Seqpacket": 5n
                };
            }
            static $h = 1702495;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1702495,"n":"Unknown","d":1702495,"h":4296669791,"f":33},{"t":1702495,"n":"Stream","d":1702495,"h":8591637087,"f":33},{"t":1702495,"n":"Dgram","d":1702495,"h":12886604383,"f":33},{"t":1702495,"n":"Raw","d":1702495,"h":17181571679,"f":33},{"t":1702495,"n":"Rdm","d":1702495,"h":21476538975,"f":33},{"t":1702495,"n":"Seqpacket","d":1702495,"h":25771506271,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1702495,"h":30066473567,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1702495}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketType`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.TransmitFileOptions", ($self) => class TransmitFileOptions extends $.$spc.System.Enum
        {
            static UseDefaultWorkerThread = 0;
            static Disconnect = 1;
            static ReuseSocket = 2;
            static WriteBehind = 4;
            static UseSystemThread = 16;
            static UseKernelApc = 32;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "UseDefaultWorkerThread": 0n,
                    "Disconnect": 1n,
                    "ReuseSocket": 2n,
                    "WriteBehind": 4n,
                    "UseSystemThread": 16n,
                    "UseKernelApc": 32n
                };
            }
            static $h = 1899103;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1899103,"n":"UseDefaultWorkerThread","d":1899103,"h":4296866399,"f":33},{"t":1899103,"n":"Disconnect","d":1899103,"h":8591833695,"f":33},{"t":1899103,"n":"ReuseSocket","d":1899103,"h":12886800991,"f":33},{"t":1899103,"n":"WriteBehind","d":1899103,"h":17181768287,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":1899103,"n":"UseSystemThread","d":1899103,"h":21476735583,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"t":1899103,"n":"UseKernelApc","d":1899103,"h":25771702879,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":1899103,"h":30066670175,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1899103,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.TransmitFileOptions`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SafeSocketHandle", ($self) => class SafeSocketHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*nint*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 719455;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7405569,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180588639,"f":32769},"n":"IsInvalid","d":719455,"h":12885621343,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":719455,"h":21475555935,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":719455,"h":4295686751,"f":1},{"p":[{"n":"preexistingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":719455,"h":8590654047,"f":1}],"i":[57475073],"h":719455}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.SafeSocketHandle`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SocketAsyncEventArgs", ($self) => class SocketAsyncEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ unsafeSuppressExecutionContextFlow)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Sockets.Socket? */ get AcceptSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket? */ set AcceptSocket(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[]? */ get Buffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IList<System.ArraySegment<byte>>? */ get BufferList()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IList<System.ArraySegment<byte>>? */ set BufferList(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get BytesTransferred()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Exception? */ get ConnectByNameError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket? */ get ConnectSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DisconnectReuseSocket()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DisconnectReuseSocket(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketAsyncOperation */ get LastOperation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Memory<byte> */ get MemoryBuffer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Offset()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.IPPacketInformation */ get ReceiveMessageFromPacketInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ set RemoteEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SendPacketsElement[]? */ get SendPacketsElements()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SendPacketsElement[]? */ set SendPacketsElements(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TransmitFileOptions */ get SendPacketsFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TransmitFileOptions */ set SendPacketsFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendPacketsSendSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendPacketsSendSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketError */ get SocketError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketError */ set SocketError(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketFlags */ get SocketFlags()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketFlags */ set SocketFlags(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ get UserToken()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ set UserToken(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.EventHandler<System.Net.Sockets.SocketAsyncEventArgs>?*/ Completed$add(value)
            {
            }
            /*System.EventHandler<System.Net.Sockets.SocketAsyncEventArgs>?*/ Completed$remove(value)
            {
            }
            /*void */ Dispose()
            {
            }
            $dtor()
            {
            }
            /*void */ OnCompleted(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
            }
            /*void */ SetBuffer(/*byte[]?*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ SetBuffer$1(/*int*/ offset, /*int*/ count)
            {
            }
            /*void */ SetBuffer$2(/*System.Memory<byte>*/ buffer)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 981599;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":916063,"g":{"r":0,"d":0,"h":17180850783,"f":1},"s":{"r":0,"d":0,"h":21475818079,"f":1},"n":"AcceptSocket","d":981599,"h":12885883487,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30065752671,"f":1},"n":"Buffer","d":981599,"h":25770785375,"f":1},{"p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.ArraySegment$$($.$spc.System.Byte)).$h,"g":{"r":0,"d":0,"h":38655687263,"f":1},"s":{"r":0,"d":0,"h":42950654559,"f":1},"n":"BufferList","d":981599,"h":34360719967,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51540589151,"f":1},"n":"BytesTransferred","d":981599,"h":47245621855,"f":1},{"p":47185921,"g":{"r":0,"d":0,"h":60130523743,"f":1},"n":"ConnectByNameError","d":981599,"h":55835556447,"f":1},{"p":916063,"g":{"r":0,"d":0,"h":68720458335,"f":1},"n":"ConnectSocket","d":981599,"h":64425491039,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":77310392927,"f":1},"n":"Count","d":981599,"h":73015425631,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85900327519,"f":1},"s":{"r":0,"d":0,"h":90195294815,"f":1},"n":"DisconnectReuseSocket","d":981599,"h":81605360223,"f":1},{"p":1047135,"g":{"r":0,"d":0,"h":98785229407,"f":1},"n":"LastOperation","d":981599,"h":94490262111,"f":1},{"p":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":107375163999,"f":1},"n":"MemoryBuffer","d":981599,"h":103080196703,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":115965098591,"f":1},"n":"Offset","d":981599,"h":111670131295,"f":1},{"p":195167,"g":{"r":0,"d":0,"h":124555033183,"f":1},"n":"ReceiveMessageFromPacketInfo","d":981599,"h":120260065887,"f":1},{"p":2594250,"g":{"r":0,"d":0,"h":133144967775,"f":1},"s":{"r":0,"d":0,"h":137439935071,"f":1},"n":"RemoteEndPoint","d":981599,"h":128850000479,"f":1},{"p":0,"g":{"r":0,"d":0,"h":146029869663,"f":1},"s":{"r":0,"d":0,"h":150324836959,"f":1},"n":"SendPacketsElements","d":981599,"h":141734902367,"f":1},{"p":1899103,"g":{"r":0,"d":0,"h":158914771551,"f":1},"s":{"r":0,"d":0,"h":163209738847,"f":1},"n":"SendPacketsFlags","d":981599,"h":154619804255,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":171799673439,"f":1},"s":{"r":0,"d":0,"h":176094640735,"f":1},"n":"SendPacketsSendSize","d":981599,"h":167504706143,"f":1},{"p":4691402,"g":{"r":0,"d":0,"h":184684575327,"f":1},"s":{"r":0,"d":0,"h":188979542623,"f":1},"n":"SocketError","d":981599,"h":180389608031,"f":1},{"p":1112671,"g":{"r":0,"d":0,"h":197569477215,"f":1},"s":{"r":0,"d":0,"h":201864444511,"f":1},"n":"SocketFlags","d":981599,"h":193274509919,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":210454379103,"f":1},"s":{"r":0,"d":0,"h":214749346399,"f":1},"n":"UserToken","d":981599,"h":206159411807,"f":1}],"m":[{"r":65537,"n":"Dispose","d":981599,"h":231929215583,"f":1},{"r":65537,"p":[{"n":"e","p":981599}],"n":"OnCompleted","d":981599,"h":240519150175,"f":132},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"SetBuffer","d":981599,"h":244814117471,"f":1},{"r":65537,"p":[{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"SetBuffer","o":"@$1","d":981599,"h":249109084767,"f":1},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h}],"n":"SetBuffer","o":"@$2","d":981599,"h":253404052063,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":981599,"h":4295948895,"f":1},{"p":[{"n":"unsafeSuppressExecutionContextFlow","p":262145}],"n":".ctor","o":"$ctor$3","d":981599,"h":8590916191,"f":1}],"e":[{"e":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h}],"n":"add_Completed","d":981599,"h":223339280991,"f":1},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h}],"n":"remove_Completed","d":981599,"h":227634248287,"f":1},"n":"Completed","d":981599,"h":219044313695,"f":1}],"i":[57475073],"h":981599}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.SocketAsyncEventArgs`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Console", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.NameResolution"))