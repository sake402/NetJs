
//--TRIMMABLE-BOUNDARY-START(106)
(async function () {
(function ($global, $, $$, $sc, $sm, $spu, $sr, $st, $scn, $scm, $so, $scp, $scs, $sdt) {
    "use strict";
    let _;
    let $OpVFAc;
    let $xMSbHk;
    let $UryPLe;
    
    
    
	$.$asm(
    "NetJs.System.Net.WebHeaderCollection", 
    {
  "h": 106,
  "f": "System.Net.WebHeaderCollection",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Net.WebHeaderCollection",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Net.WebHeaderCollection",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(786538)
        $asm.$cls(`$snwh.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(171799478378)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(171799478378)
            
            //--TRIMMABLE-BOUNDARY-START(128849805418)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128849805418);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849805418)
            
            //--TRIMMABLE-BOUNDARY-START(184684380266)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184684380266);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snwh.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684380266)
            
            //--TRIMMABLE-BOUNDARY-START(124554838122)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554838122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwh.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$snwh.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(124554838122)
            
            //--TRIMMABLE-BOUNDARY-START(120259870826)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259870826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$snwh.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(120259870826)
            
            //--TRIMMABLE-BOUNDARY-START(38655492202)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655492202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwh.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38655492202)
            
            //--TRIMMABLE-BOUNDARY-START(34360524906)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwh.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34360524906)
            
            //--TRIMMABLE-BOUNDARY-START(30065557610)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065557610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwh.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30065557610)
            
            //--TRIMMABLE-BOUNDARY-START(42950459498)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950459498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$snwh.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42950459498)
            
            //--TRIMMABLE-BOUNDARY-START(21475623018)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475623018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwh.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(21475623018)
            
            //--TRIMMABLE-BOUNDARY-START(17180655722)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwh.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(17180655722)
            
            //--TRIMMABLE-BOUNDARY-START(12885688426)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwh.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(12885688426)
            
            //--TRIMMABLE-BOUNDARY-START(25770590314)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$snwh.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590314)
            
            //--TRIMMABLE-BOUNDARY-START(167504511082)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(167504511082)
            
            //--TRIMMABLE-BOUNDARY-START(158914576490)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(158914576490)
            
            //--TRIMMABLE-BOUNDARY-START(163209543786)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964903530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$snwh.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.Net.WebHeaderCollection", $.$snwh.S.SR.$type.Assembly);
                    $.$snwh.S.SR.s_resourceManager = temp;
                }
                return $.$snwh.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(163209543786)
            
            //--TRIMMABLE-BOUNDARY-START(8590721130)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835361386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$snwh.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389412970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$snwh.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721130)
            
            //--TRIMMABLE-BOUNDARY-START(133144772714)
            static /*string */ get net_headers_req()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425295978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This collection holds response headers and cannot contain the specified request header.";
            }
            //--TRIMMABLE-BOUNDARY-END(133144772714)
            
            //--TRIMMABLE-BOUNDARY-START(137439740010)
            static /*string */ get net_headers_rsp()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015230570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This collection holds request headers and cannot contain the specified response header.";
            }
            //--TRIMMABLE-BOUNDARY-END(137439740010)
            
            //--TRIMMABLE-BOUNDARY-START(141734707306)
            static /*string */ get net_WebHeaderInvalidControlChars()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605165162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Specified value has invalid Control characters.";
            }
            //--TRIMMABLE-BOUNDARY-END(141734707306)
            
            //--TRIMMABLE-BOUNDARY-START(146029674602)
            static /*string */ get net_WebHeaderInvalidCRLFChars()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195099754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Specified value has invalid CRLF characters.";
            }
            //--TRIMMABLE-BOUNDARY-END(146029674602)
            
            //--TRIMMABLE-BOUNDARY-START(150324641898)
            static /*string */ get net_WebHeaderInvalidHeaderChars()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785034346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Specified value '{0}' has invalid HTTP Header characters.";
            }
            //--TRIMMABLE-BOUNDARY-END(150324641898)
            
            //--TRIMMABLE-BOUNDARY-START(47245426794)
            static /*string */ Formatnet_WebHeaderInvalidHeaderChars(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245426794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Specified value '{0}' has invalid HTTP Header characters.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(47245426794)
            
            //--TRIMMABLE-BOUNDARY-START(154619609194)
            static /*string */ get net_WebHeaderMissingColon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374968938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Specified value does not have a ':' separator.";
            }
            //--TRIMMABLE-BOUNDARY-END(154619609194)
            
            //--TRIMMABLE-BOUNDARY-START(4295753834)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295753834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(171799478378)
                    this.s_usingResourceKeys = $.$snwh.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(171799478378)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295753834)
            
            static $h = 786538;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 786538
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786538)
        
        

        //--TRIMMABLE-BOUNDARY-START(196714)
        $asm.$cls(`$snwh.SN.HttpKnownHeaderNames`, ($self) => class HttpKnownHeaderNames
        {
            //--TRIMMABLE-BOUNDARY-START(4295164010)
            /*string*/ static Accept = null;
            //--TRIMMABLE-BOUNDARY-END(4295164010)
            
            //--TRIMMABLE-BOUNDARY-START(8590131306)
            /*string*/ static AcceptCharset = null;
            //--TRIMMABLE-BOUNDARY-END(8590131306)
            
            //--TRIMMABLE-BOUNDARY-START(12885098602)
            /*string*/ static AcceptEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(12885098602)
            
            //--TRIMMABLE-BOUNDARY-START(17180065898)
            /*string*/ static AcceptLanguage = null;
            //--TRIMMABLE-BOUNDARY-END(17180065898)
            
            //--TRIMMABLE-BOUNDARY-START(21475033194)
            /*string*/ static AcceptPatch = null;
            //--TRIMMABLE-BOUNDARY-END(21475033194)
            
            //--TRIMMABLE-BOUNDARY-START(25770000490)
            /*string*/ static AcceptRanges = null;
            //--TRIMMABLE-BOUNDARY-END(25770000490)
            
            //--TRIMMABLE-BOUNDARY-START(30064967786)
            /*string*/ static AccessControlAllowCredentials = null;
            //--TRIMMABLE-BOUNDARY-END(30064967786)
            
            //--TRIMMABLE-BOUNDARY-START(34359935082)
            /*string*/ static AccessControlAllowHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(34359935082)
            
            //--TRIMMABLE-BOUNDARY-START(38654902378)
            /*string*/ static AccessControlAllowMethods = null;
            //--TRIMMABLE-BOUNDARY-END(38654902378)
            
            //--TRIMMABLE-BOUNDARY-START(42949869674)
            /*string*/ static AccessControlAllowOrigin = null;
            //--TRIMMABLE-BOUNDARY-END(42949869674)
            
            //--TRIMMABLE-BOUNDARY-START(47244836970)
            /*string*/ static AccessControlExposeHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(47244836970)
            
            //--TRIMMABLE-BOUNDARY-START(51539804266)
            /*string*/ static AccessControlMaxAge = null;
            //--TRIMMABLE-BOUNDARY-END(51539804266)
            
            //--TRIMMABLE-BOUNDARY-START(55834771562)
            /*string*/ static Age = null;
            //--TRIMMABLE-BOUNDARY-END(55834771562)
            
            //--TRIMMABLE-BOUNDARY-START(60129738858)
            /*string*/ static Allow = null;
            //--TRIMMABLE-BOUNDARY-END(60129738858)
            
            //--TRIMMABLE-BOUNDARY-START(64424706154)
            /*string*/ static AltSvc = null;
            //--TRIMMABLE-BOUNDARY-END(64424706154)
            
            //--TRIMMABLE-BOUNDARY-START(68719673450)
            /*string*/ static Authorization = null;
            //--TRIMMABLE-BOUNDARY-END(68719673450)
            
            //--TRIMMABLE-BOUNDARY-START(73014640746)
            /*string*/ static CacheControl = null;
            //--TRIMMABLE-BOUNDARY-END(73014640746)
            
            //--TRIMMABLE-BOUNDARY-START(77309608042)
            /*string*/ static Connection = null;
            //--TRIMMABLE-BOUNDARY-END(77309608042)
            
            //--TRIMMABLE-BOUNDARY-START(81604575338)
            /*string*/ static ContentDisposition = null;
            //--TRIMMABLE-BOUNDARY-END(81604575338)
            
            //--TRIMMABLE-BOUNDARY-START(85899542634)
            /*string*/ static ContentEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(85899542634)
            
            //--TRIMMABLE-BOUNDARY-START(90194509930)
            /*string*/ static ContentLanguage = null;
            //--TRIMMABLE-BOUNDARY-END(90194509930)
            
            //--TRIMMABLE-BOUNDARY-START(94489477226)
            /*string*/ static ContentLength = null;
            //--TRIMMABLE-BOUNDARY-END(94489477226)
            
            //--TRIMMABLE-BOUNDARY-START(98784444522)
            /*string*/ static ContentLocation = null;
            //--TRIMMABLE-BOUNDARY-END(98784444522)
            
            //--TRIMMABLE-BOUNDARY-START(103079411818)
            /*string*/ static ContentMD5 = null;
            //--TRIMMABLE-BOUNDARY-END(103079411818)
            
            //--TRIMMABLE-BOUNDARY-START(107374379114)
            /*string*/ static ContentRange = null;
            //--TRIMMABLE-BOUNDARY-END(107374379114)
            
            //--TRIMMABLE-BOUNDARY-START(111669346410)
            /*string*/ static ContentSecurityPolicy = null;
            //--TRIMMABLE-BOUNDARY-END(111669346410)
            
            //--TRIMMABLE-BOUNDARY-START(115964313706)
            /*string*/ static ContentType = null;
            //--TRIMMABLE-BOUNDARY-END(115964313706)
            
            //--TRIMMABLE-BOUNDARY-START(120259281002)
            /*string*/ static Cookie = null;
            //--TRIMMABLE-BOUNDARY-END(120259281002)
            
            //--TRIMMABLE-BOUNDARY-START(124554248298)
            /*string*/ static Cookie2 = null;
            //--TRIMMABLE-BOUNDARY-END(124554248298)
            
            //--TRIMMABLE-BOUNDARY-START(128849215594)
            /*string*/ static Date = null;
            //--TRIMMABLE-BOUNDARY-END(128849215594)
            
            //--TRIMMABLE-BOUNDARY-START(133144182890)
            /*string*/ static ETag = null;
            //--TRIMMABLE-BOUNDARY-END(133144182890)
            
            //--TRIMMABLE-BOUNDARY-START(137439150186)
            /*string*/ static Expect = null;
            //--TRIMMABLE-BOUNDARY-END(137439150186)
            
            //--TRIMMABLE-BOUNDARY-START(141734117482)
            /*string*/ static Expires = null;
            //--TRIMMABLE-BOUNDARY-END(141734117482)
            
            //--TRIMMABLE-BOUNDARY-START(146029084778)
            /*string*/ static From = null;
            //--TRIMMABLE-BOUNDARY-END(146029084778)
            
            //--TRIMMABLE-BOUNDARY-START(150324052074)
            /*string*/ static Host = null;
            //--TRIMMABLE-BOUNDARY-END(150324052074)
            
            //--TRIMMABLE-BOUNDARY-START(154619019370)
            /*string*/ static IfMatch = null;
            //--TRIMMABLE-BOUNDARY-END(154619019370)
            
            //--TRIMMABLE-BOUNDARY-START(158913986666)
            /*string*/ static IfModifiedSince = null;
            //--TRIMMABLE-BOUNDARY-END(158913986666)
            
            //--TRIMMABLE-BOUNDARY-START(163208953962)
            /*string*/ static IfNoneMatch = null;
            //--TRIMMABLE-BOUNDARY-END(163208953962)
            
            //--TRIMMABLE-BOUNDARY-START(167503921258)
            /*string*/ static IfRange = null;
            //--TRIMMABLE-BOUNDARY-END(167503921258)
            
            //--TRIMMABLE-BOUNDARY-START(171798888554)
            /*string*/ static IfUnmodifiedSince = null;
            //--TRIMMABLE-BOUNDARY-END(171798888554)
            
            //--TRIMMABLE-BOUNDARY-START(176093855850)
            /*string*/ static KeepAlive = null;
            //--TRIMMABLE-BOUNDARY-END(176093855850)
            
            //--TRIMMABLE-BOUNDARY-START(180388823146)
            /*string*/ static LastModified = null;
            //--TRIMMABLE-BOUNDARY-END(180388823146)
            
            //--TRIMMABLE-BOUNDARY-START(184683790442)
            /*string*/ static Link = null;
            //--TRIMMABLE-BOUNDARY-END(184683790442)
            
            //--TRIMMABLE-BOUNDARY-START(188978757738)
            /*string*/ static Location = null;
            //--TRIMMABLE-BOUNDARY-END(188978757738)
            
            //--TRIMMABLE-BOUNDARY-START(193273725034)
            /*string*/ static MaxForwards = null;
            //--TRIMMABLE-BOUNDARY-END(193273725034)
            
            //--TRIMMABLE-BOUNDARY-START(197568692330)
            /*string*/ static Origin = null;
            //--TRIMMABLE-BOUNDARY-END(197568692330)
            
            //--TRIMMABLE-BOUNDARY-START(201863659626)
            /*string*/ static P3P = null;
            //--TRIMMABLE-BOUNDARY-END(201863659626)
            
            //--TRIMMABLE-BOUNDARY-START(206158626922)
            /*string*/ static Pragma = null;
            //--TRIMMABLE-BOUNDARY-END(206158626922)
            
            //--TRIMMABLE-BOUNDARY-START(210453594218)
            /*string*/ static ProxyAuthenticate = null;
            //--TRIMMABLE-BOUNDARY-END(210453594218)
            
            //--TRIMMABLE-BOUNDARY-START(214748561514)
            /*string*/ static ProxyAuthorization = null;
            //--TRIMMABLE-BOUNDARY-END(214748561514)
            
            //--TRIMMABLE-BOUNDARY-START(219043528810)
            /*string*/ static ProxyConnection = null;
            //--TRIMMABLE-BOUNDARY-END(219043528810)
            
            //--TRIMMABLE-BOUNDARY-START(223338496106)
            /*string*/ static PublicKeyPins = null;
            //--TRIMMABLE-BOUNDARY-END(223338496106)
            
            //--TRIMMABLE-BOUNDARY-START(227633463402)
            /*string*/ static Range = null;
            //--TRIMMABLE-BOUNDARY-END(227633463402)
            
            //--TRIMMABLE-BOUNDARY-START(231928430698)
            /*string*/ static Referer = null;
            //--TRIMMABLE-BOUNDARY-END(231928430698)
            
            //--TRIMMABLE-BOUNDARY-START(236223397994)
            /*string*/ static RetryAfter = null;
            //--TRIMMABLE-BOUNDARY-END(236223397994)
            
            //--TRIMMABLE-BOUNDARY-START(240518365290)
            /*string*/ static SecWebSocketAccept = null;
            //--TRIMMABLE-BOUNDARY-END(240518365290)
            
            //--TRIMMABLE-BOUNDARY-START(244813332586)
            /*string*/ static SecWebSocketExtensions = null;
            //--TRIMMABLE-BOUNDARY-END(244813332586)
            
            //--TRIMMABLE-BOUNDARY-START(249108299882)
            /*string*/ static SecWebSocketKey = null;
            //--TRIMMABLE-BOUNDARY-END(249108299882)
            
            //--TRIMMABLE-BOUNDARY-START(253403267178)
            /*string*/ static SecWebSocketProtocol = null;
            //--TRIMMABLE-BOUNDARY-END(253403267178)
            
            //--TRIMMABLE-BOUNDARY-START(257698234474)
            /*string*/ static SecWebSocketVersion = null;
            //--TRIMMABLE-BOUNDARY-END(257698234474)
            
            //--TRIMMABLE-BOUNDARY-START(261993201770)
            /*string*/ static Server = null;
            //--TRIMMABLE-BOUNDARY-END(261993201770)
            
            //--TRIMMABLE-BOUNDARY-START(266288169066)
            /*string*/ static SetCookie = null;
            //--TRIMMABLE-BOUNDARY-END(266288169066)
            
            //--TRIMMABLE-BOUNDARY-START(270583136362)
            /*string*/ static SetCookie2 = null;
            //--TRIMMABLE-BOUNDARY-END(270583136362)
            
            //--TRIMMABLE-BOUNDARY-START(274878103658)
            /*string*/ static StrictTransportSecurity = null;
            //--TRIMMABLE-BOUNDARY-END(274878103658)
            
            //--TRIMMABLE-BOUNDARY-START(279173070954)
            /*string*/ static TE = null;
            //--TRIMMABLE-BOUNDARY-END(279173070954)
            
            //--TRIMMABLE-BOUNDARY-START(292057972842)
            /*string*/ static TSV = null;
            //--TRIMMABLE-BOUNDARY-END(292057972842)
            
            //--TRIMMABLE-BOUNDARY-START(283468038250)
            /*string*/ static Trailer = null;
            //--TRIMMABLE-BOUNDARY-END(283468038250)
            
            //--TRIMMABLE-BOUNDARY-START(287763005546)
            /*string*/ static TransferEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(287763005546)
            
            //--TRIMMABLE-BOUNDARY-START(296352940138)
            /*string*/ static Upgrade = null;
            //--TRIMMABLE-BOUNDARY-END(296352940138)
            
            //--TRIMMABLE-BOUNDARY-START(300647907434)
            /*string*/ static UpgradeInsecureRequests = null;
            //--TRIMMABLE-BOUNDARY-END(300647907434)
            
            //--TRIMMABLE-BOUNDARY-START(304942874730)
            /*string*/ static UserAgent = null;
            //--TRIMMABLE-BOUNDARY-END(304942874730)
            
            //--TRIMMABLE-BOUNDARY-START(309237842026)
            /*string*/ static Vary = null;
            //--TRIMMABLE-BOUNDARY-END(309237842026)
            
            //--TRIMMABLE-BOUNDARY-START(313532809322)
            /*string*/ static Via = null;
            //--TRIMMABLE-BOUNDARY-END(313532809322)
            
            //--TRIMMABLE-BOUNDARY-START(322122743914)
            /*string*/ static WWWAuthenticate = null;
            //--TRIMMABLE-BOUNDARY-END(322122743914)
            
            //--TRIMMABLE-BOUNDARY-START(317827776618)
            /*string*/ static Warning = null;
            //--TRIMMABLE-BOUNDARY-END(317827776618)
            
            //--TRIMMABLE-BOUNDARY-START(326417711210)
            /*string*/ static XAspNetVersion = null;
            //--TRIMMABLE-BOUNDARY-END(326417711210)
            
            //--TRIMMABLE-BOUNDARY-START(330712678506)
            /*string*/ static XContentDuration = null;
            //--TRIMMABLE-BOUNDARY-END(330712678506)
            
            //--TRIMMABLE-BOUNDARY-START(335007645802)
            /*string*/ static XContentTypeOptions = null;
            //--TRIMMABLE-BOUNDARY-END(335007645802)
            
            //--TRIMMABLE-BOUNDARY-START(339302613098)
            /*string*/ static XFrameOptions = null;
            //--TRIMMABLE-BOUNDARY-END(339302613098)
            
            //--TRIMMABLE-BOUNDARY-START(343597580394)
            /*string*/ static XMSEdgeRef = null;
            //--TRIMMABLE-BOUNDARY-END(343597580394)
            
            //--TRIMMABLE-BOUNDARY-START(347892547690)
            /*string*/ static XPoweredBy = null;
            //--TRIMMABLE-BOUNDARY-END(347892547690)
            
            //--TRIMMABLE-BOUNDARY-START(352187514986)
            /*string*/ static XRequestID = null;
            //--TRIMMABLE-BOUNDARY-END(352187514986)
            
            //--TRIMMABLE-BOUNDARY-START(356482482282)
            /*string*/ static XUACompatible = null;
            //--TRIMMABLE-BOUNDARY-END(356482482282)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295164010)
                    this.Accept = "Accept";
                    //--TRIMMABLE-BOUNDARY-END(4295164010)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590131306)
                    this.AcceptCharset = "Accept-Charset";
                    //--TRIMMABLE-BOUNDARY-END(8590131306)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885098602)
                    this.AcceptEncoding = "Accept-Encoding";
                    //--TRIMMABLE-BOUNDARY-END(12885098602)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180065898)
                    this.AcceptLanguage = "Accept-Language";
                    //--TRIMMABLE-BOUNDARY-END(17180065898)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475033194)
                    this.AcceptPatch = "Accept-Patch";
                    //--TRIMMABLE-BOUNDARY-END(21475033194)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770000490)
                    this.AcceptRanges = "Accept-Ranges";
                    //--TRIMMABLE-BOUNDARY-END(25770000490)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30064967786)
                    this.AccessControlAllowCredentials = "Access-Control-Allow-Credentials";
                    //--TRIMMABLE-BOUNDARY-END(30064967786)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359935082)
                    this.AccessControlAllowHeaders = "Access-Control-Allow-Headers";
                    //--TRIMMABLE-BOUNDARY-END(34359935082)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654902378)
                    this.AccessControlAllowMethods = "Access-Control-Allow-Methods";
                    //--TRIMMABLE-BOUNDARY-END(38654902378)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949869674)
                    this.AccessControlAllowOrigin = "Access-Control-Allow-Origin";
                    //--TRIMMABLE-BOUNDARY-END(42949869674)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244836970)
                    this.AccessControlExposeHeaders = "Access-Control-Expose-Headers";
                    //--TRIMMABLE-BOUNDARY-END(47244836970)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539804266)
                    this.AccessControlMaxAge = "Access-Control-Max-Age";
                    //--TRIMMABLE-BOUNDARY-END(51539804266)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834771562)
                    this.Age = "Age";
                    //--TRIMMABLE-BOUNDARY-END(55834771562)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60129738858)
                    this.Allow = "Allow";
                    //--TRIMMABLE-BOUNDARY-END(60129738858)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424706154)
                    this.AltSvc = "Alt-Svc";
                    //--TRIMMABLE-BOUNDARY-END(64424706154)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68719673450)
                    this.Authorization = "Authorization";
                    //--TRIMMABLE-BOUNDARY-END(68719673450)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73014640746)
                    this.CacheControl = "Cache-Control";
                    //--TRIMMABLE-BOUNDARY-END(73014640746)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77309608042)
                    this.Connection = "Connection";
                    //--TRIMMABLE-BOUNDARY-END(77309608042)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81604575338)
                    this.ContentDisposition = "Content-Disposition";
                    //--TRIMMABLE-BOUNDARY-END(81604575338)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899542634)
                    this.ContentEncoding = "Content-Encoding";
                    //--TRIMMABLE-BOUNDARY-END(85899542634)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194509930)
                    this.ContentLanguage = "Content-Language";
                    //--TRIMMABLE-BOUNDARY-END(90194509930)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489477226)
                    this.ContentLength = "Content-Length";
                    //--TRIMMABLE-BOUNDARY-END(94489477226)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784444522)
                    this.ContentLocation = "Content-Location";
                    //--TRIMMABLE-BOUNDARY-END(98784444522)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079411818)
                    this.ContentMD5 = "Content-MD5";
                    //--TRIMMABLE-BOUNDARY-END(103079411818)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374379114)
                    this.ContentRange = "Content-Range";
                    //--TRIMMABLE-BOUNDARY-END(107374379114)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669346410)
                    this.ContentSecurityPolicy = "Content-Security-Policy";
                    //--TRIMMABLE-BOUNDARY-END(111669346410)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964313706)
                    this.ContentType = "Content-Type";
                    //--TRIMMABLE-BOUNDARY-END(115964313706)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259281002)
                    this.Cookie = "Cookie";
                    //--TRIMMABLE-BOUNDARY-END(120259281002)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554248298)
                    this.Cookie2 = "Cookie2";
                    //--TRIMMABLE-BOUNDARY-END(124554248298)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849215594)
                    this.Date = "Date";
                    //--TRIMMABLE-BOUNDARY-END(128849215594)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144182890)
                    this.ETag = "ETag";
                    //--TRIMMABLE-BOUNDARY-END(133144182890)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439150186)
                    this.Expect = "Expect";
                    //--TRIMMABLE-BOUNDARY-END(137439150186)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734117482)
                    this.Expires = "Expires";
                    //--TRIMMABLE-BOUNDARY-END(141734117482)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029084778)
                    this.From = "From";
                    //--TRIMMABLE-BOUNDARY-END(146029084778)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324052074)
                    this.Host = "Host";
                    //--TRIMMABLE-BOUNDARY-END(150324052074)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619019370)
                    this.IfMatch = "If-Match";
                    //--TRIMMABLE-BOUNDARY-END(154619019370)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158913986666)
                    this.IfModifiedSince = "If-Modified-Since";
                    //--TRIMMABLE-BOUNDARY-END(158913986666)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163208953962)
                    this.IfNoneMatch = "If-None-Match";
                    //--TRIMMABLE-BOUNDARY-END(163208953962)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167503921258)
                    this.IfRange = "If-Range";
                    //--TRIMMABLE-BOUNDARY-END(167503921258)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171798888554)
                    this.IfUnmodifiedSince = "If-Unmodified-Since";
                    //--TRIMMABLE-BOUNDARY-END(171798888554)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176093855850)
                    this.KeepAlive = "Keep-Alive";
                    //--TRIMMABLE-BOUNDARY-END(176093855850)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180388823146)
                    this.LastModified = "Last-Modified";
                    //--TRIMMABLE-BOUNDARY-END(180388823146)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184683790442)
                    this.Link = "Link";
                    //--TRIMMABLE-BOUNDARY-END(184683790442)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188978757738)
                    this.Location = "Location";
                    //--TRIMMABLE-BOUNDARY-END(188978757738)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193273725034)
                    this.MaxForwards = "Max-Forwards";
                    //--TRIMMABLE-BOUNDARY-END(193273725034)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197568692330)
                    this.Origin = "Origin";
                    //--TRIMMABLE-BOUNDARY-END(197568692330)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201863659626)
                    this.P3P = "P3P";
                    //--TRIMMABLE-BOUNDARY-END(201863659626)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206158626922)
                    this.Pragma = "Pragma";
                    //--TRIMMABLE-BOUNDARY-END(206158626922)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210453594218)
                    this.ProxyAuthenticate = "Proxy-Authenticate";
                    //--TRIMMABLE-BOUNDARY-END(210453594218)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214748561514)
                    this.ProxyAuthorization = "Proxy-Authorization";
                    //--TRIMMABLE-BOUNDARY-END(214748561514)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219043528810)
                    this.ProxyConnection = "Proxy-Connection";
                    //--TRIMMABLE-BOUNDARY-END(219043528810)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223338496106)
                    this.PublicKeyPins = "Public-Key-Pins";
                    //--TRIMMABLE-BOUNDARY-END(223338496106)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227633463402)
                    this.Range = "Range";
                    //--TRIMMABLE-BOUNDARY-END(227633463402)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231928430698)
                    this.Referer = "Referer";
                    //--TRIMMABLE-BOUNDARY-END(231928430698)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223397994)
                    this.RetryAfter = "Retry-After";
                    //--TRIMMABLE-BOUNDARY-END(236223397994)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518365290)
                    this.SecWebSocketAccept = "Sec-WebSocket-Accept";
                    //--TRIMMABLE-BOUNDARY-END(240518365290)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813332586)
                    this.SecWebSocketExtensions = "Sec-WebSocket-Extensions";
                    //--TRIMMABLE-BOUNDARY-END(244813332586)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108299882)
                    this.SecWebSocketKey = "Sec-WebSocket-Key";
                    //--TRIMMABLE-BOUNDARY-END(249108299882)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253403267178)
                    this.SecWebSocketProtocol = "Sec-WebSocket-Protocol";
                    //--TRIMMABLE-BOUNDARY-END(253403267178)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257698234474)
                    this.SecWebSocketVersion = "Sec-WebSocket-Version";
                    //--TRIMMABLE-BOUNDARY-END(257698234474)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993201770)
                    this.Server = "Server";
                    //--TRIMMABLE-BOUNDARY-END(261993201770)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288169066)
                    this.SetCookie = "Set-Cookie";
                    //--TRIMMABLE-BOUNDARY-END(266288169066)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270583136362)
                    this.SetCookie2 = "Set-Cookie2";
                    //--TRIMMABLE-BOUNDARY-END(270583136362)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274878103658)
                    this.StrictTransportSecurity = "Strict-Transport-Security";
                    //--TRIMMABLE-BOUNDARY-END(274878103658)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279173070954)
                    this.TE = "TE";
                    //--TRIMMABLE-BOUNDARY-END(279173070954)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292057972842)
                    this.TSV = "TSV";
                    //--TRIMMABLE-BOUNDARY-END(292057972842)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283468038250)
                    this.Trailer = "Trailer";
                    //--TRIMMABLE-BOUNDARY-END(283468038250)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287763005546)
                    this.TransferEncoding = "Transfer-Encoding";
                    //--TRIMMABLE-BOUNDARY-END(287763005546)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296352940138)
                    this.Upgrade = "Upgrade";
                    //--TRIMMABLE-BOUNDARY-END(296352940138)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300647907434)
                    this.UpgradeInsecureRequests = "Upgrade-Insecure-Requests";
                    //--TRIMMABLE-BOUNDARY-END(300647907434)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304942874730)
                    this.UserAgent = "User-Agent";
                    //--TRIMMABLE-BOUNDARY-END(304942874730)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309237842026)
                    this.Vary = "Vary";
                    //--TRIMMABLE-BOUNDARY-END(309237842026)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313532809322)
                    this.Via = "Via";
                    //--TRIMMABLE-BOUNDARY-END(313532809322)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322122743914)
                    this.WWWAuthenticate = "WWW-Authenticate";
                    //--TRIMMABLE-BOUNDARY-END(322122743914)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317827776618)
                    this.Warning = "Warning";
                    //--TRIMMABLE-BOUNDARY-END(317827776618)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326417711210)
                    this.XAspNetVersion = "X-AspNet-Version";
                    //--TRIMMABLE-BOUNDARY-END(326417711210)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330712678506)
                    this.XContentDuration = "X-Content-Duration";
                    //--TRIMMABLE-BOUNDARY-END(330712678506)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335007645802)
                    this.XContentTypeOptions = "X-Content-Type-Options";
                    //--TRIMMABLE-BOUNDARY-END(335007645802)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339302613098)
                    this.XFrameOptions = "X-Frame-Options";
                    //--TRIMMABLE-BOUNDARY-END(339302613098)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343597580394)
                    this.XMSEdgeRef = "X-MSEdge-Ref";
                    //--TRIMMABLE-BOUNDARY-END(343597580394)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347892547690)
                    this.XPoweredBy = "X-Powered-By";
                    //--TRIMMABLE-BOUNDARY-END(347892547690)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352187514986)
                    this.XRequestID = "X-Request-ID";
                    //--TRIMMABLE-BOUNDARY-END(352187514986)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356482482282)
                    this.XUACompatible = "X-UA-Compatible";
                    //--TRIMMABLE-BOUNDARY-END(356482482282)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 196714;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295164010),
    {
      "t": 1310721,
      "n": "Accept",
      "d": 196714,
      "h": 4295164010,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295164010),
//--TRIMMABLE-BOUNDARY-START(8590131306),
    {
      "t": 1310721,
      "n": "AcceptCharset",
      "d": 196714,
      "h": 8590131306,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590131306),
//--TRIMMABLE-BOUNDARY-START(12885098602),
    {
      "t": 1310721,
      "n": "AcceptEncoding",
      "d": 196714,
      "h": 12885098602,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885098602),
//--TRIMMABLE-BOUNDARY-START(17180065898),
    {
      "t": 1310721,
      "n": "AcceptLanguage",
      "d": 196714,
      "h": 17180065898,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180065898),
//--TRIMMABLE-BOUNDARY-START(21475033194),
    {
      "t": 1310721,
      "n": "AcceptPatch",
      "d": 196714,
      "h": 21475033194,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475033194),
//--TRIMMABLE-BOUNDARY-START(25770000490),
    {
      "t": 1310721,
      "n": "AcceptRanges",
      "d": 196714,
      "h": 25770000490,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770000490),
//--TRIMMABLE-BOUNDARY-START(30064967786),
    {
      "t": 1310721,
      "n": "AccessControlAllowCredentials",
      "d": 196714,
      "h": 30064967786,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064967786),
//--TRIMMABLE-BOUNDARY-START(34359935082),
    {
      "t": 1310721,
      "n": "AccessControlAllowHeaders",
      "d": 196714,
      "h": 34359935082,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34359935082),
//--TRIMMABLE-BOUNDARY-START(38654902378),
    {
      "t": 1310721,
      "n": "AccessControlAllowMethods",
      "d": 196714,
      "h": 38654902378,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654902378),
//--TRIMMABLE-BOUNDARY-START(42949869674),
    {
      "t": 1310721,
      "n": "AccessControlAllowOrigin",
      "d": 196714,
      "h": 42949869674,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949869674),
//--TRIMMABLE-BOUNDARY-START(47244836970),
    {
      "t": 1310721,
      "n": "AccessControlExposeHeaders",
      "d": 196714,
      "h": 47244836970,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47244836970),
//--TRIMMABLE-BOUNDARY-START(51539804266),
    {
      "t": 1310721,
      "n": "AccessControlMaxAge",
      "d": 196714,
      "h": 51539804266,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539804266),
//--TRIMMABLE-BOUNDARY-START(55834771562),
    {
      "t": 1310721,
      "n": "Age",
      "d": 196714,
      "h": 55834771562,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834771562),
//--TRIMMABLE-BOUNDARY-START(60129738858),
    {
      "t": 1310721,
      "n": "Allow",
      "d": 196714,
      "h": 60129738858,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60129738858),
//--TRIMMABLE-BOUNDARY-START(64424706154),
    {
      "t": 1310721,
      "n": "AltSvc",
      "d": 196714,
      "h": 64424706154,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424706154),
//--TRIMMABLE-BOUNDARY-START(68719673450),
    {
      "t": 1310721,
      "n": "Authorization",
      "d": 196714,
      "h": 68719673450,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68719673450),
//--TRIMMABLE-BOUNDARY-START(73014640746),
    {
      "t": 1310721,
      "n": "CacheControl",
      "d": 196714,
      "h": 73014640746,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73014640746),
//--TRIMMABLE-BOUNDARY-START(77309608042),
    {
      "t": 1310721,
      "n": "Connection",
      "d": 196714,
      "h": 77309608042,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77309608042),
//--TRIMMABLE-BOUNDARY-START(81604575338),
    {
      "t": 1310721,
      "n": "ContentDisposition",
      "d": 196714,
      "h": 81604575338,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604575338),
//--TRIMMABLE-BOUNDARY-START(85899542634),
    {
      "t": 1310721,
      "n": "ContentEncoding",
      "d": 196714,
      "h": 85899542634,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899542634),
//--TRIMMABLE-BOUNDARY-START(90194509930),
    {
      "t": 1310721,
      "n": "ContentLanguage",
      "d": 196714,
      "h": 90194509930,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90194509930),
//--TRIMMABLE-BOUNDARY-START(94489477226),
    {
      "t": 1310721,
      "n": "ContentLength",
      "d": 196714,
      "h": 94489477226,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489477226),
//--TRIMMABLE-BOUNDARY-START(98784444522),
    {
      "t": 1310721,
      "n": "ContentLocation",
      "d": 196714,
      "h": 98784444522,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784444522),
//--TRIMMABLE-BOUNDARY-START(103079411818),
    {
      "t": 1310721,
      "n": "ContentMD5",
      "d": 196714,
      "h": 103079411818,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079411818),
//--TRIMMABLE-BOUNDARY-START(107374379114),
    {
      "t": 1310721,
      "n": "ContentRange",
      "d": 196714,
      "h": 107374379114,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374379114),
//--TRIMMABLE-BOUNDARY-START(111669346410),
    {
      "t": 1310721,
      "n": "ContentSecurityPolicy",
      "d": 196714,
      "h": 111669346410,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669346410),
//--TRIMMABLE-BOUNDARY-START(115964313706),
    {
      "t": 1310721,
      "n": "ContentType",
      "d": 196714,
      "h": 115964313706,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964313706),
//--TRIMMABLE-BOUNDARY-START(120259281002),
    {
      "t": 1310721,
      "n": "Cookie",
      "d": 196714,
      "h": 120259281002,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259281002),
//--TRIMMABLE-BOUNDARY-START(124554248298),
    {
      "t": 1310721,
      "n": "Cookie2",
      "d": 196714,
      "h": 124554248298,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554248298),
//--TRIMMABLE-BOUNDARY-START(128849215594),
    {
      "t": 1310721,
      "n": "Date",
      "d": 196714,
      "h": 128849215594,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849215594),
//--TRIMMABLE-BOUNDARY-START(133144182890),
    {
      "t": 1310721,
      "n": "ETag",
      "d": 196714,
      "h": 133144182890,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144182890),
//--TRIMMABLE-BOUNDARY-START(137439150186),
    {
      "t": 1310721,
      "n": "Expect",
      "d": 196714,
      "h": 137439150186,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439150186),
//--TRIMMABLE-BOUNDARY-START(141734117482),
    {
      "t": 1310721,
      "n": "Expires",
      "d": 196714,
      "h": 141734117482,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734117482),
//--TRIMMABLE-BOUNDARY-START(146029084778),
    {
      "t": 1310721,
      "n": "From",
      "d": 196714,
      "h": 146029084778,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029084778),
//--TRIMMABLE-BOUNDARY-START(150324052074),
    {
      "t": 1310721,
      "n": "Host",
      "d": 196714,
      "h": 150324052074,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324052074),
//--TRIMMABLE-BOUNDARY-START(154619019370),
    {
      "t": 1310721,
      "n": "IfMatch",
      "d": 196714,
      "h": 154619019370,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619019370),
//--TRIMMABLE-BOUNDARY-START(158913986666),
    {
      "t": 1310721,
      "n": "IfModifiedSince",
      "d": 196714,
      "h": 158913986666,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158913986666),
//--TRIMMABLE-BOUNDARY-START(163208953962),
    {
      "t": 1310721,
      "n": "IfNoneMatch",
      "d": 196714,
      "h": 163208953962,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163208953962),
//--TRIMMABLE-BOUNDARY-START(167503921258),
    {
      "t": 1310721,
      "n": "IfRange",
      "d": 196714,
      "h": 167503921258,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167503921258),
//--TRIMMABLE-BOUNDARY-START(171798888554),
    {
      "t": 1310721,
      "n": "IfUnmodifiedSince",
      "d": 196714,
      "h": 171798888554,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171798888554),
//--TRIMMABLE-BOUNDARY-START(176093855850),
    {
      "t": 1310721,
      "n": "KeepAlive",
      "d": 196714,
      "h": 176093855850,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176093855850),
//--TRIMMABLE-BOUNDARY-START(180388823146),
    {
      "t": 1310721,
      "n": "LastModified",
      "d": 196714,
      "h": 180388823146,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180388823146),
//--TRIMMABLE-BOUNDARY-START(184683790442),
    {
      "t": 1310721,
      "n": "Link",
      "d": 196714,
      "h": 184683790442,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(184683790442),
//--TRIMMABLE-BOUNDARY-START(188978757738),
    {
      "t": 1310721,
      "n": "Location",
      "d": 196714,
      "h": 188978757738,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(188978757738),
//--TRIMMABLE-BOUNDARY-START(193273725034),
    {
      "t": 1310721,
      "n": "MaxForwards",
      "d": 196714,
      "h": 193273725034,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(193273725034),
//--TRIMMABLE-BOUNDARY-START(197568692330),
    {
      "t": 1310721,
      "n": "Origin",
      "d": 196714,
      "h": 197568692330,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(197568692330),
//--TRIMMABLE-BOUNDARY-START(201863659626),
    {
      "t": 1310721,
      "n": "P3P",
      "d": 196714,
      "h": 201863659626,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(201863659626),
//--TRIMMABLE-BOUNDARY-START(206158626922),
    {
      "t": 1310721,
      "n": "Pragma",
      "d": 196714,
      "h": 206158626922,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(206158626922),
//--TRIMMABLE-BOUNDARY-START(210453594218),
    {
      "t": 1310721,
      "n": "ProxyAuthenticate",
      "d": 196714,
      "h": 210453594218,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(210453594218),
//--TRIMMABLE-BOUNDARY-START(214748561514),
    {
      "t": 1310721,
      "n": "ProxyAuthorization",
      "d": 196714,
      "h": 214748561514,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(214748561514),
//--TRIMMABLE-BOUNDARY-START(219043528810),
    {
      "t": 1310721,
      "n": "ProxyConnection",
      "d": 196714,
      "h": 219043528810,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(219043528810),
//--TRIMMABLE-BOUNDARY-START(223338496106),
    {
      "t": 1310721,
      "n": "PublicKeyPins",
      "d": 196714,
      "h": 223338496106,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(223338496106),
//--TRIMMABLE-BOUNDARY-START(227633463402),
    {
      "t": 1310721,
      "n": "Range",
      "d": 196714,
      "h": 227633463402,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(227633463402),
//--TRIMMABLE-BOUNDARY-START(231928430698),
    {
      "t": 1310721,
      "n": "Referer",
      "d": 196714,
      "h": 231928430698,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(231928430698),
//--TRIMMABLE-BOUNDARY-START(236223397994),
    {
      "t": 1310721,
      "n": "RetryAfter",
      "d": 196714,
      "h": 236223397994,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(236223397994),
//--TRIMMABLE-BOUNDARY-START(240518365290),
    {
      "t": 1310721,
      "n": "SecWebSocketAccept",
      "d": 196714,
      "h": 240518365290,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(240518365290),
//--TRIMMABLE-BOUNDARY-START(244813332586),
    {
      "t": 1310721,
      "n": "SecWebSocketExtensions",
      "d": 196714,
      "h": 244813332586,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(244813332586),
//--TRIMMABLE-BOUNDARY-START(249108299882),
    {
      "t": 1310721,
      "n": "SecWebSocketKey",
      "d": 196714,
      "h": 249108299882,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(249108299882),
//--TRIMMABLE-BOUNDARY-START(253403267178),
    {
      "t": 1310721,
      "n": "SecWebSocketProtocol",
      "d": 196714,
      "h": 253403267178,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(253403267178),
//--TRIMMABLE-BOUNDARY-START(257698234474),
    {
      "t": 1310721,
      "n": "SecWebSocketVersion",
      "d": 196714,
      "h": 257698234474,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(257698234474),
//--TRIMMABLE-BOUNDARY-START(261993201770),
    {
      "t": 1310721,
      "n": "Server",
      "d": 196714,
      "h": 261993201770,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(261993201770),
//--TRIMMABLE-BOUNDARY-START(266288169066),
    {
      "t": 1310721,
      "n": "SetCookie",
      "d": 196714,
      "h": 266288169066,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(266288169066),
//--TRIMMABLE-BOUNDARY-START(270583136362),
    {
      "t": 1310721,
      "n": "SetCookie2",
      "d": 196714,
      "h": 270583136362,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(270583136362),
//--TRIMMABLE-BOUNDARY-START(274878103658),
    {
      "t": 1310721,
      "n": "StrictTransportSecurity",
      "d": 196714,
      "h": 274878103658,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(274878103658),
//--TRIMMABLE-BOUNDARY-START(279173070954),
    {
      "t": 1310721,
      "n": "TE",
      "d": 196714,
      "h": 279173070954,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(279173070954),
//--TRIMMABLE-BOUNDARY-START(292057972842),
    {
      "t": 1310721,
      "n": "TSV",
      "d": 196714,
      "h": 292057972842,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(292057972842),
//--TRIMMABLE-BOUNDARY-START(283468038250),
    {
      "t": 1310721,
      "n": "Trailer",
      "d": 196714,
      "h": 283468038250,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(283468038250),
//--TRIMMABLE-BOUNDARY-START(287763005546),
    {
      "t": 1310721,
      "n": "TransferEncoding",
      "d": 196714,
      "h": 287763005546,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(287763005546),
//--TRIMMABLE-BOUNDARY-START(296352940138),
    {
      "t": 1310721,
      "n": "Upgrade",
      "d": 196714,
      "h": 296352940138,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(296352940138),
//--TRIMMABLE-BOUNDARY-START(300647907434),
    {
      "t": 1310721,
      "n": "UpgradeInsecureRequests",
      "d": 196714,
      "h": 300647907434,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(300647907434),
//--TRIMMABLE-BOUNDARY-START(304942874730),
    {
      "t": 1310721,
      "n": "UserAgent",
      "d": 196714,
      "h": 304942874730,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(304942874730),
//--TRIMMABLE-BOUNDARY-START(309237842026),
    {
      "t": 1310721,
      "n": "Vary",
      "d": 196714,
      "h": 309237842026,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(309237842026),
//--TRIMMABLE-BOUNDARY-START(313532809322),
    {
      "t": 1310721,
      "n": "Via",
      "d": 196714,
      "h": 313532809322,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(313532809322),
//--TRIMMABLE-BOUNDARY-START(322122743914),
    {
      "t": 1310721,
      "n": "WWWAuthenticate",
      "d": 196714,
      "h": 322122743914,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(322122743914),
//--TRIMMABLE-BOUNDARY-START(317827776618),
    {
      "t": 1310721,
      "n": "Warning",
      "d": 196714,
      "h": 317827776618,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(317827776618),
//--TRIMMABLE-BOUNDARY-START(326417711210),
    {
      "t": 1310721,
      "n": "XAspNetVersion",
      "d": 196714,
      "h": 326417711210,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(326417711210),
//--TRIMMABLE-BOUNDARY-START(330712678506),
    {
      "t": 1310721,
      "n": "XContentDuration",
      "d": 196714,
      "h": 330712678506,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(330712678506),
//--TRIMMABLE-BOUNDARY-START(335007645802),
    {
      "t": 1310721,
      "n": "XContentTypeOptions",
      "d": 196714,
      "h": 335007645802,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(335007645802),
//--TRIMMABLE-BOUNDARY-START(339302613098),
    {
      "t": 1310721,
      "n": "XFrameOptions",
      "d": 196714,
      "h": 339302613098,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(339302613098),
//--TRIMMABLE-BOUNDARY-START(343597580394),
    {
      "t": 1310721,
      "n": "XMSEdgeRef",
      "d": 196714,
      "h": 343597580394,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(343597580394),
//--TRIMMABLE-BOUNDARY-START(347892547690),
    {
      "t": 1310721,
      "n": "XPoweredBy",
      "d": 196714,
      "h": 347892547690,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(347892547690),
//--TRIMMABLE-BOUNDARY-START(352187514986),
    {
      "t": 1310721,
      "n": "XRequestID",
      "d": 196714,
      "h": 352187514986,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(352187514986),
//--TRIMMABLE-BOUNDARY-START(356482482282),
    {
      "t": 1310721,
      "n": "XUACompatible",
      "d": 196714,
      "h": 356482482282,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(356482482282)
  ],
  "h": 196714
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.HttpKnownHeaderNames`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}HttpKnownHeaderNames`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196714)
        
        

        //--TRIMMABLE-BOUNDARY-START(65642)
        $asm.$cls(`$snwh.SN.HeaderInfo`, ($self) => class HeaderInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17179934826)
            /*bool*/ IsRequestRestricted = false;
            //--TRIMMABLE-BOUNDARY-END(17179934826)
            
            //--TRIMMABLE-BOUNDARY-START(21474902122)
            /*bool*/ IsResponseRestricted = false;
            //--TRIMMABLE-BOUNDARY-END(21474902122)
            
            //--TRIMMABLE-BOUNDARY-START(25769869418)
            /*Func<string, string[]>*/ Parser = null;
            //--TRIMMABLE-BOUNDARY-END(25769869418)
            
            //--TRIMMABLE-BOUNDARY-START(12884967530)
            /*string*/ HeaderName = null;
            //--TRIMMABLE-BOUNDARY-END(12884967530)
            
            //--TRIMMABLE-BOUNDARY-START(8590000234)
            /*bool*/ AllowMultiValues = false;
            //--TRIMMABLE-BOUNDARY-END(8590000234)
            
            //--TRIMMABLE-BOUNDARY-START(4295032938)
            $ctor$1(/*string*/ name, /*bool*/ requestRestricted, /*bool*/ responseRestricted, /*bool*/ multi, /*Func<string, string[]>*/ parser)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032938);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.HeaderName = name;
                    this.IsRequestRestricted = requestRestricted;
                    this.IsResponseRestricted = responseRestricted;
                    this.Parser = parser;
                    this.AllowMultiValues = multi;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032938)
            
            static $h = 65642;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(17179934826),
    {
      "t": 262145,
      "n": "IsRequestRestricted",
      "d": 65642,
      "h": 17179934826,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17179934826),
//--TRIMMABLE-BOUNDARY-START(21474902122),
    {
      "t": 262145,
      "n": "IsResponseRestricted",
      "d": 65642,
      "h": 21474902122,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21474902122),
//--TRIMMABLE-BOUNDARY-START(25769869418),
    {
      "t": $.$$.S.Func$$$($.$$.S.String, $.$typeArray($.$$.S.String)).$h,
      "n": "Parser",
      "d": 65642,
      "h": 25769869418,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(25769869418),
//--TRIMMABLE-BOUNDARY-START(12884967530),
    {
      "t": 1310721,
      "n": "HeaderName",
      "d": 65642,
      "h": 12884967530,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12884967530),
//--TRIMMABLE-BOUNDARY-START(8590000234),
    {
      "t": 262145,
      "n": "AllowMultiValues",
      "d": 65642,
      "h": 8590000234,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590000234)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032938),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "requestRestricted",
          "p": 262145
        },
        {
          "n": "responseRestricted",
          "p": 262145
        },
        {
          "n": "multi",
          "p": 262145
        },
        {
          "n": "parser",
          "p": $.$$.S.Func$$$($.$$.S.String, $.$typeArray($.$$.S.String)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65642,
      "h": 4295032938,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295032938)
  ],
  "h": 65642
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.HeaderInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}HeaderInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65642)
        
        

        //--TRIMMABLE-BOUNDARY-START(721002)
        $asm.$cls(`$snwh.S.Obsoletions`, ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382252810346)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382252810346)
            
            //--TRIMMABLE-BOUNDARY-START(433792417898)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433792417898)
            
            //--TRIMMABLE-BOUNDARY-START(429497450602)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429497450602)
            
            //--TRIMMABLE-BOUNDARY-START(266288693354)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266288693354)
            
            //--TRIMMABLE-BOUNDARY-START(261993726058)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261993726058)
            
            //--TRIMMABLE-BOUNDARY-START(77310132330)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77310132330)
            
            //--TRIMMABLE-BOUNDARY-START(73015165034)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73015165034)
            
            //--TRIMMABLE-BOUNDARY-START(94490001514)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94490001514)
            
            //--TRIMMABLE-BOUNDARY-START(90195034218)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90195034218)
            
            //--TRIMMABLE-BOUNDARY-START(214749085802)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214749085802)
            
            //--TRIMMABLE-BOUNDARY-START(210454118506)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210454118506)
            
            //--TRIMMABLE-BOUNDARY-START(442382352490)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442382352490)
            
            //--TRIMMABLE-BOUNDARY-START(446677319786)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446677319786)
            
            //--TRIMMABLE-BOUNDARY-START(438087385194)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438087385194)
            
            //--TRIMMABLE-BOUNDARY-START(146029609066)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146029609066)
            
            //--TRIMMABLE-BOUNDARY-START(141734641770)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141734641770)
            
            //--TRIMMABLE-BOUNDARY-START(120259805290)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120259805290)
            
            //--TRIMMABLE-BOUNDARY-START(115964837994)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115964837994)
            
            //--TRIMMABLE-BOUNDARY-START(51540328554)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51540328554)
            
            //--TRIMMABLE-BOUNDARY-START(47245361258)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47245361258)
            
            //--TRIMMABLE-BOUNDARY-START(326418235498)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326418235498)
            
            //--TRIMMABLE-BOUNDARY-START(322123268202)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322123268202)
            
            //--TRIMMABLE-BOUNDARY-START(60130263146)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60130263146)
            
            //--TRIMMABLE-BOUNDARY-START(55835295850)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55835295850)
            
            //--TRIMMABLE-BOUNDARY-START(85900066922)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85900066922)
            
            //--TRIMMABLE-BOUNDARY-START(81605099626)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81605099626)
            
            //--TRIMMABLE-BOUNDARY-START(197569216618)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197569216618)
            
            //--TRIMMABLE-BOUNDARY-START(193274249322)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193274249322)
            
            //--TRIMMABLE-BOUNDARY-START(489626992746)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489626992746)
            
            //--TRIMMABLE-BOUNDARY-START(485332025450)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485332025450)
            
            //--TRIMMABLE-BOUNDARY-START(163209478250)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163209478250)
            
            //--TRIMMABLE-BOUNDARY-START(158914510954)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158914510954)
            
            //--TRIMMABLE-BOUNDARY-START(206159151210)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206159151210)
            
            //--TRIMMABLE-BOUNDARY-START(201864183914)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201864183914)
            
            //--TRIMMABLE-BOUNDARY-START(399432679530)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399432679530)
            
            //--TRIMMABLE-BOUNDARY-START(395137712234)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395137712234)
            
            //--TRIMMABLE-BOUNDARY-START(300648431722)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300648431722)
            
            //--TRIMMABLE-BOUNDARY-START(296353464426)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296353464426)
            
            //--TRIMMABLE-BOUNDARY-START(377957843050)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377957843050)
            
            //--TRIMMABLE-BOUNDARY-START(373662875754)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373662875754)
            
            //--TRIMMABLE-BOUNDARY-START(231928954986)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231928954986)
            
            //--TRIMMABLE-BOUNDARY-START(227633987690)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227633987690)
            
            //--TRIMMABLE-BOUNDARY-START(154619543658)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154619543658)
            
            //--TRIMMABLE-BOUNDARY-START(150324576362)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150324576362)
            
            //--TRIMMABLE-BOUNDARY-START(352188039274)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352188039274)
            
            //--TRIMMABLE-BOUNDARY-START(347893071978)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347893071978)
            
            //--TRIMMABLE-BOUNDARY-START(360777973866)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360777973866)
            
            //--TRIMMABLE-BOUNDARY-START(356483006570)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356483006570)
            
            //--TRIMMABLE-BOUNDARY-START(17180590186)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17180590186)
            
            //--TRIMMABLE-BOUNDARY-START(12885622890)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12885622890)
            
            //--TRIMMABLE-BOUNDARY-START(408022614122)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408022614122)
            
            //--TRIMMABLE-BOUNDARY-START(403727646826)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403727646826)
            
            //--TRIMMABLE-BOUNDARY-START(498216927338)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498216927338)
            
            //--TRIMMABLE-BOUNDARY-START(493921960042)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493921960042)
            
            //--TRIMMABLE-BOUNDARY-START(283468562538)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283468562538)
            
            //--TRIMMABLE-BOUNDARY-START(279173595242)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279173595242)
            
            //--TRIMMABLE-BOUNDARY-START(506806861930)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506806861930)
            
            //--TRIMMABLE-BOUNDARY-START(502511894634)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502511894634)
            
            //--TRIMMABLE-BOUNDARY-START(274878627946)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274878627946)
            
            //--TRIMMABLE-BOUNDARY-START(270583660650)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270583660650)
            
            //--TRIMMABLE-BOUNDARY-START(481037058154)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481037058154)
            
            //--TRIMMABLE-BOUNDARY-START(476742090858)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476742090858)
            
            //--TRIMMABLE-BOUNDARY-START(128849739882)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128849739882)
            
            //--TRIMMABLE-BOUNDARY-START(124554772586)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124554772586)
            
            //--TRIMMABLE-BOUNDARY-START(111669870698)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111669870698)
            
            //--TRIMMABLE-BOUNDARY-START(107374903402)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107374903402)
            
            //--TRIMMABLE-BOUNDARY-START(335008170090)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335008170090)
            
            //--TRIMMABLE-BOUNDARY-START(330713202794)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330713202794)
            
            //--TRIMMABLE-BOUNDARY-START(68720197738)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68720197738)
            
            //--TRIMMABLE-BOUNDARY-START(64425230442)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64425230442)
            
            //--TRIMMABLE-BOUNDARY-START(390842744938)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390842744938)
            
            //--TRIMMABLE-BOUNDARY-START(386547777642)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386547777642)
            
            //--TRIMMABLE-BOUNDARY-START(309238366314)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309238366314)
            
            //--TRIMMABLE-BOUNDARY-START(304943399018)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304943399018)
            
            //--TRIMMABLE-BOUNDARY-START(42950393962)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42950393962)
            
            //--TRIMMABLE-BOUNDARY-START(38655426666)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38655426666)
            
            //--TRIMMABLE-BOUNDARY-START(416612548714)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416612548714)
            
            //--TRIMMABLE-BOUNDARY-START(412317581418)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412317581418)
            
            //--TRIMMABLE-BOUNDARY-START(472447123562)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472447123562)
            
            //--TRIMMABLE-BOUNDARY-START(468152156266)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468152156266)
            
            //--TRIMMABLE-BOUNDARY-START(188979282026)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188979282026)
            
            //--TRIMMABLE-BOUNDARY-START(184684314730)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184684314730)
            
            //--TRIMMABLE-BOUNDARY-START(171799412842)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171799412842)
            
            //--TRIMMABLE-BOUNDARY-START(167504445546)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167504445546)
            
            //--TRIMMABLE-BOUNDARY-START(180389347434)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180389347434)
            
            //--TRIMMABLE-BOUNDARY-START(176094380138)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176094380138)
            
            //--TRIMMABLE-BOUNDARY-START(34360459370)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34360459370)
            
            //--TRIMMABLE-BOUNDARY-START(30065492074)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30065492074)
            
            //--TRIMMABLE-BOUNDARY-START(137439674474)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137439674474)
            
            //--TRIMMABLE-BOUNDARY-START(133144707178)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133144707178)
            
            //--TRIMMABLE-BOUNDARY-START(103079936106)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103079936106)
            
            //--TRIMMABLE-BOUNDARY-START(98784968810)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98784968810)
            
            //--TRIMMABLE-BOUNDARY-START(523986731114)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523986731114)
            
            //--TRIMMABLE-BOUNDARY-START(519691763818)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519691763818)
            
            //--TRIMMABLE-BOUNDARY-START(369367908458)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369367908458)
            
            //--TRIMMABLE-BOUNDARY-START(365072941162)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365072941162)
            
            //--TRIMMABLE-BOUNDARY-START(223339020394)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223339020394)
            
            //--TRIMMABLE-BOUNDARY-START(219044053098)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219044053098)
            
            //--TRIMMABLE-BOUNDARY-START(249108824170)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249108824170)
            
            //--TRIMMABLE-BOUNDARY-START(236223922282)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236223922282)
            
            //--TRIMMABLE-BOUNDARY-START(244813856874)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244813856874)
            
            //--TRIMMABLE-BOUNDARY-START(240518889578)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240518889578)
            
            //--TRIMMABLE-BOUNDARY-START(317828300906)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317828300906)
            
            //--TRIMMABLE-BOUNDARY-START(313533333610)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313533333610)
            
            //--TRIMMABLE-BOUNDARY-START(8590655594)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590655594)
            
            //--TRIMMABLE-BOUNDARY-START(4295688298)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295688298)
            
            //--TRIMMABLE-BOUNDARY-START(455267254378)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455267254378)
            
            //--TRIMMABLE-BOUNDARY-START(450972287082)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450972287082)
            
            //--TRIMMABLE-BOUNDARY-START(25770524778)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25770524778)
            
            //--TRIMMABLE-BOUNDARY-START(21475557482)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21475557482)
            
            //--TRIMMABLE-BOUNDARY-START(257698758762)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257698758762)
            
            //--TRIMMABLE-BOUNDARY-START(253403791466)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253403791466)
            
            //--TRIMMABLE-BOUNDARY-START(515396796522)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515396796522)
            
            //--TRIMMABLE-BOUNDARY-START(511101829226)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511101829226)
            
            //--TRIMMABLE-BOUNDARY-START(463857188970)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463857188970)
            
            //--TRIMMABLE-BOUNDARY-START(459562221674)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459562221674)
            
            //--TRIMMABLE-BOUNDARY-START(425202483306)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425202483306)
            
            //--TRIMMABLE-BOUNDARY-START(420907516010)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420907516010)
            
            //--TRIMMABLE-BOUNDARY-START(343598104682)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343598104682)
            
            //--TRIMMABLE-BOUNDARY-START(339303137386)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339303137386)
            
            //--TRIMMABLE-BOUNDARY-START(292058497130)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292058497130)
            
            //--TRIMMABLE-BOUNDARY-START(287763529834)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287763529834)
            
            //--TRIMMABLE-BOUNDARY-START(532576665706)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532576665706)
            
            //--TRIMMABLE-BOUNDARY-START(528281698410)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528281698410)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382252810346)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382252810346)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433792417898)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433792417898)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429497450602)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429497450602)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288693354)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266288693354)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993726058)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261993726058)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310132330)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77310132330)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015165034)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73015165034)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94490001514)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94490001514)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90195034218)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90195034218)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214749085802)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214749085802)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210454118506)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210454118506)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442382352490)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442382352490)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446677319786)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446677319786)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438087385194)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438087385194)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029609066)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146029609066)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734641770)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141734641770)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259805290)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120259805290)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964837994)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115964837994)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540328554)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51540328554)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245361258)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47245361258)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326418235498)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326418235498)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322123268202)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322123268202)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130263146)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60130263146)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835295850)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55835295850)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85900066922)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85900066922)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81605099626)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81605099626)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197569216618)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197569216618)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193274249322)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193274249322)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489626992746)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489626992746)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485332025450)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485332025450)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163209478250)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163209478250)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914510954)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158914510954)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206159151210)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206159151210)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201864183914)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201864183914)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399432679530)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399432679530)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137712234)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395137712234)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300648431722)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300648431722)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296353464426)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296353464426)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957843050)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377957843050)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373662875754)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373662875754)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231928954986)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231928954986)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227633987690)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227633987690)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619543658)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154619543658)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324576362)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150324576362)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352188039274)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352188039274)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347893071978)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347893071978)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360777973866)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360777973866)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356483006570)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356483006570)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180590186)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17180590186)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885622890)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12885622890)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408022614122)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408022614122)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403727646826)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403727646826)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498216927338)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498216927338)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493921960042)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493921960042)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283468562538)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283468562538)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279173595242)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279173595242)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506806861930)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506806861930)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502511894634)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502511894634)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274878627946)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274878627946)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270583660650)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270583660650)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481037058154)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481037058154)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476742090858)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476742090858)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849739882)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128849739882)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554772586)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124554772586)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669870698)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111669870698)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374903402)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107374903402)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335008170090)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335008170090)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330713202794)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330713202794)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720197738)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68720197738)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425230442)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64425230442)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390842744938)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390842744938)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547777642)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386547777642)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309238366314)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309238366314)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304943399018)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304943399018)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950393962)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42950393962)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655426666)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38655426666)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416612548714)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416612548714)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412317581418)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412317581418)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472447123562)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472447123562)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468152156266)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468152156266)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188979282026)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188979282026)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184684314730)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184684314730)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171799412842)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171799412842)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167504445546)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167504445546)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180389347434)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180389347434)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176094380138)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176094380138)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360459370)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34360459370)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065492074)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30065492074)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439674474)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137439674474)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144707178)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133144707178)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079936106)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103079936106)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784968810)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98784968810)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523986731114)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523986731114)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519691763818)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519691763818)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369367908458)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369367908458)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365072941162)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365072941162)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223339020394)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223339020394)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219044053098)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219044053098)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108824170)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249108824170)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223922282)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236223922282)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813856874)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244813856874)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518889578)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240518889578)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317828300906)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317828300906)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313533333610)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313533333610)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590655594)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8590655594)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295688298)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4295688298)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455267254378)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455267254378)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450972287082)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450972287082)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770524778)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25770524778)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475557482)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21475557482)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257698758762)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257698758762)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253403791466)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253403791466)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515396796522)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515396796522)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511101829226)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511101829226)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463857188970)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463857188970)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459562221674)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459562221674)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425202483306)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425202483306)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420907516010)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420907516010)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343598104682)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343598104682)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339303137386)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339303137386)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292058497130)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292058497130)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287763529834)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287763529834)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532576665706)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532576665706)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528281698410)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528281698410)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 721002;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(382252810346),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 721002,
      "h": 382252810346,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382252810346),
//--TRIMMABLE-BOUNDARY-START(433792417898),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 721002,
      "h": 433792417898,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433792417898),
//--TRIMMABLE-BOUNDARY-START(429497450602),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 721002,
      "h": 429497450602,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429497450602),
//--TRIMMABLE-BOUNDARY-START(266288693354),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 721002,
      "h": 266288693354,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266288693354),
//--TRIMMABLE-BOUNDARY-START(261993726058),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 721002,
      "h": 261993726058,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261993726058),
//--TRIMMABLE-BOUNDARY-START(77310132330),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 721002,
      "h": 77310132330,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77310132330),
//--TRIMMABLE-BOUNDARY-START(73015165034),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 721002,
      "h": 73015165034,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73015165034),
//--TRIMMABLE-BOUNDARY-START(94490001514),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 721002,
      "h": 94490001514,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94490001514),
//--TRIMMABLE-BOUNDARY-START(90195034218),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 721002,
      "h": 90195034218,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90195034218),
//--TRIMMABLE-BOUNDARY-START(214749085802),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 721002,
      "h": 214749085802,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214749085802),
//--TRIMMABLE-BOUNDARY-START(210454118506),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 721002,
      "h": 210454118506,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210454118506),
//--TRIMMABLE-BOUNDARY-START(442382352490),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 721002,
      "h": 442382352490,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442382352490),
//--TRIMMABLE-BOUNDARY-START(446677319786),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 721002,
      "h": 446677319786,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446677319786),
//--TRIMMABLE-BOUNDARY-START(438087385194),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 721002,
      "h": 438087385194,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438087385194),
//--TRIMMABLE-BOUNDARY-START(146029609066),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 721002,
      "h": 146029609066,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146029609066),
//--TRIMMABLE-BOUNDARY-START(141734641770),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 721002,
      "h": 141734641770,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141734641770),
//--TRIMMABLE-BOUNDARY-START(120259805290),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 721002,
      "h": 120259805290,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259805290),
//--TRIMMABLE-BOUNDARY-START(115964837994),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 721002,
      "h": 115964837994,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115964837994),
//--TRIMMABLE-BOUNDARY-START(51540328554),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 721002,
      "h": 51540328554,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51540328554),
//--TRIMMABLE-BOUNDARY-START(47245361258),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 721002,
      "h": 47245361258,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47245361258),
//--TRIMMABLE-BOUNDARY-START(326418235498),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 721002,
      "h": 326418235498,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326418235498),
//--TRIMMABLE-BOUNDARY-START(322123268202),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 721002,
      "h": 322123268202,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322123268202),
//--TRIMMABLE-BOUNDARY-START(60130263146),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 721002,
      "h": 60130263146,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60130263146),
//--TRIMMABLE-BOUNDARY-START(55835295850),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 721002,
      "h": 55835295850,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55835295850),
//--TRIMMABLE-BOUNDARY-START(85900066922),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 721002,
      "h": 85900066922,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85900066922),
//--TRIMMABLE-BOUNDARY-START(81605099626),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 721002,
      "h": 81605099626,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81605099626),
//--TRIMMABLE-BOUNDARY-START(197569216618),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 721002,
      "h": 197569216618,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197569216618),
//--TRIMMABLE-BOUNDARY-START(193274249322),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 721002,
      "h": 193274249322,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193274249322),
//--TRIMMABLE-BOUNDARY-START(489626992746),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 721002,
      "h": 489626992746,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489626992746),
//--TRIMMABLE-BOUNDARY-START(485332025450),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 721002,
      "h": 485332025450,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485332025450),
//--TRIMMABLE-BOUNDARY-START(163209478250),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 721002,
      "h": 163209478250,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163209478250),
//--TRIMMABLE-BOUNDARY-START(158914510954),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 721002,
      "h": 158914510954,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158914510954),
//--TRIMMABLE-BOUNDARY-START(206159151210),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 721002,
      "h": 206159151210,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206159151210),
//--TRIMMABLE-BOUNDARY-START(201864183914),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 721002,
      "h": 201864183914,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201864183914),
//--TRIMMABLE-BOUNDARY-START(399432679530),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 721002,
      "h": 399432679530,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399432679530),
//--TRIMMABLE-BOUNDARY-START(395137712234),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 721002,
      "h": 395137712234,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395137712234),
//--TRIMMABLE-BOUNDARY-START(300648431722),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 721002,
      "h": 300648431722,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300648431722),
//--TRIMMABLE-BOUNDARY-START(296353464426),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 721002,
      "h": 296353464426,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296353464426),
//--TRIMMABLE-BOUNDARY-START(377957843050),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 721002,
      "h": 377957843050,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377957843050),
//--TRIMMABLE-BOUNDARY-START(373662875754),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 721002,
      "h": 373662875754,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373662875754),
//--TRIMMABLE-BOUNDARY-START(231928954986),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 721002,
      "h": 231928954986,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231928954986),
//--TRIMMABLE-BOUNDARY-START(227633987690),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 721002,
      "h": 227633987690,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227633987690),
//--TRIMMABLE-BOUNDARY-START(154619543658),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 721002,
      "h": 154619543658,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154619543658),
//--TRIMMABLE-BOUNDARY-START(150324576362),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 721002,
      "h": 150324576362,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150324576362),
//--TRIMMABLE-BOUNDARY-START(352188039274),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 721002,
      "h": 352188039274,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352188039274),
//--TRIMMABLE-BOUNDARY-START(347893071978),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 721002,
      "h": 347893071978,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347893071978),
//--TRIMMABLE-BOUNDARY-START(360777973866),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 721002,
      "h": 360777973866,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360777973866),
//--TRIMMABLE-BOUNDARY-START(356483006570),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 721002,
      "h": 356483006570,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356483006570),
//--TRIMMABLE-BOUNDARY-START(17180590186),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 721002,
      "h": 17180590186,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180590186),
//--TRIMMABLE-BOUNDARY-START(12885622890),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 721002,
      "h": 12885622890,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885622890),
//--TRIMMABLE-BOUNDARY-START(408022614122),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 721002,
      "h": 408022614122,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408022614122),
//--TRIMMABLE-BOUNDARY-START(403727646826),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 721002,
      "h": 403727646826,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403727646826),
//--TRIMMABLE-BOUNDARY-START(498216927338),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 721002,
      "h": 498216927338,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498216927338),
//--TRIMMABLE-BOUNDARY-START(493921960042),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 721002,
      "h": 493921960042,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493921960042),
//--TRIMMABLE-BOUNDARY-START(283468562538),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 721002,
      "h": 283468562538,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283468562538),
//--TRIMMABLE-BOUNDARY-START(279173595242),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 721002,
      "h": 279173595242,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279173595242),
//--TRIMMABLE-BOUNDARY-START(506806861930),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 721002,
      "h": 506806861930,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506806861930),
//--TRIMMABLE-BOUNDARY-START(502511894634),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 721002,
      "h": 502511894634,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502511894634),
//--TRIMMABLE-BOUNDARY-START(274878627946),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 721002,
      "h": 274878627946,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274878627946),
//--TRIMMABLE-BOUNDARY-START(270583660650),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 721002,
      "h": 270583660650,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270583660650),
//--TRIMMABLE-BOUNDARY-START(481037058154),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 721002,
      "h": 481037058154,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481037058154),
//--TRIMMABLE-BOUNDARY-START(476742090858),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 721002,
      "h": 476742090858,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476742090858),
//--TRIMMABLE-BOUNDARY-START(128849739882),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 721002,
      "h": 128849739882,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849739882),
//--TRIMMABLE-BOUNDARY-START(124554772586),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 721002,
      "h": 124554772586,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554772586),
//--TRIMMABLE-BOUNDARY-START(111669870698),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 721002,
      "h": 111669870698,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111669870698),
//--TRIMMABLE-BOUNDARY-START(107374903402),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 721002,
      "h": 107374903402,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107374903402),
//--TRIMMABLE-BOUNDARY-START(335008170090),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 721002,
      "h": 335008170090,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335008170090),
//--TRIMMABLE-BOUNDARY-START(330713202794),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 721002,
      "h": 330713202794,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330713202794),
//--TRIMMABLE-BOUNDARY-START(68720197738),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 721002,
      "h": 68720197738,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68720197738),
//--TRIMMABLE-BOUNDARY-START(64425230442),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 721002,
      "h": 64425230442,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64425230442),
//--TRIMMABLE-BOUNDARY-START(390842744938),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 721002,
      "h": 390842744938,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390842744938),
//--TRIMMABLE-BOUNDARY-START(386547777642),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 721002,
      "h": 386547777642,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386547777642),
//--TRIMMABLE-BOUNDARY-START(309238366314),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 721002,
      "h": 309238366314,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309238366314),
//--TRIMMABLE-BOUNDARY-START(304943399018),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 721002,
      "h": 304943399018,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304943399018),
//--TRIMMABLE-BOUNDARY-START(42950393962),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 721002,
      "h": 42950393962,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42950393962),
//--TRIMMABLE-BOUNDARY-START(38655426666),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 721002,
      "h": 38655426666,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38655426666),
//--TRIMMABLE-BOUNDARY-START(416612548714),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 721002,
      "h": 416612548714,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416612548714),
//--TRIMMABLE-BOUNDARY-START(412317581418),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 721002,
      "h": 412317581418,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412317581418),
//--TRIMMABLE-BOUNDARY-START(472447123562),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 721002,
      "h": 472447123562,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472447123562),
//--TRIMMABLE-BOUNDARY-START(468152156266),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 721002,
      "h": 468152156266,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468152156266),
//--TRIMMABLE-BOUNDARY-START(188979282026),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 721002,
      "h": 188979282026,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188979282026),
//--TRIMMABLE-BOUNDARY-START(184684314730),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 721002,
      "h": 184684314730,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184684314730),
//--TRIMMABLE-BOUNDARY-START(171799412842),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 721002,
      "h": 171799412842,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171799412842),
//--TRIMMABLE-BOUNDARY-START(167504445546),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 721002,
      "h": 167504445546,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167504445546),
//--TRIMMABLE-BOUNDARY-START(180389347434),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 721002,
      "h": 180389347434,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180389347434),
//--TRIMMABLE-BOUNDARY-START(176094380138),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 721002,
      "h": 176094380138,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176094380138),
//--TRIMMABLE-BOUNDARY-START(34360459370),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 721002,
      "h": 34360459370,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360459370),
//--TRIMMABLE-BOUNDARY-START(30065492074),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 721002,
      "h": 30065492074,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065492074),
//--TRIMMABLE-BOUNDARY-START(137439674474),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 721002,
      "h": 137439674474,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137439674474),
//--TRIMMABLE-BOUNDARY-START(133144707178),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 721002,
      "h": 133144707178,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133144707178),
//--TRIMMABLE-BOUNDARY-START(103079936106),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 721002,
      "h": 103079936106,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103079936106),
//--TRIMMABLE-BOUNDARY-START(98784968810),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 721002,
      "h": 98784968810,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784968810),
//--TRIMMABLE-BOUNDARY-START(523986731114),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 721002,
      "h": 523986731114,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523986731114),
//--TRIMMABLE-BOUNDARY-START(519691763818),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 721002,
      "h": 519691763818,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519691763818),
//--TRIMMABLE-BOUNDARY-START(369367908458),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 721002,
      "h": 369367908458,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369367908458),
//--TRIMMABLE-BOUNDARY-START(365072941162),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 721002,
      "h": 365072941162,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365072941162),
//--TRIMMABLE-BOUNDARY-START(223339020394),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 721002,
      "h": 223339020394,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223339020394),
//--TRIMMABLE-BOUNDARY-START(219044053098),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 721002,
      "h": 219044053098,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219044053098),
//--TRIMMABLE-BOUNDARY-START(249108824170),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 721002,
      "h": 249108824170,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249108824170),
//--TRIMMABLE-BOUNDARY-START(236223922282),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 721002,
      "h": 236223922282,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236223922282),
//--TRIMMABLE-BOUNDARY-START(244813856874),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 721002,
      "h": 244813856874,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244813856874),
//--TRIMMABLE-BOUNDARY-START(240518889578),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 721002,
      "h": 240518889578,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240518889578),
//--TRIMMABLE-BOUNDARY-START(317828300906),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 721002,
      "h": 317828300906,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317828300906),
//--TRIMMABLE-BOUNDARY-START(313533333610),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 721002,
      "h": 313533333610,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313533333610),
//--TRIMMABLE-BOUNDARY-START(8590655594),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 721002,
      "h": 8590655594,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590655594),
//--TRIMMABLE-BOUNDARY-START(4295688298),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 721002,
      "h": 4295688298,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295688298),
//--TRIMMABLE-BOUNDARY-START(455267254378),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 721002,
      "h": 455267254378,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455267254378),
//--TRIMMABLE-BOUNDARY-START(450972287082),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 721002,
      "h": 450972287082,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450972287082),
//--TRIMMABLE-BOUNDARY-START(25770524778),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 721002,
      "h": 25770524778,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770524778),
//--TRIMMABLE-BOUNDARY-START(21475557482),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 721002,
      "h": 21475557482,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475557482),
//--TRIMMABLE-BOUNDARY-START(257698758762),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 721002,
      "h": 257698758762,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257698758762),
//--TRIMMABLE-BOUNDARY-START(253403791466),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 721002,
      "h": 253403791466,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253403791466),
//--TRIMMABLE-BOUNDARY-START(515396796522),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 721002,
      "h": 515396796522,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515396796522),
//--TRIMMABLE-BOUNDARY-START(511101829226),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 721002,
      "h": 511101829226,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511101829226),
//--TRIMMABLE-BOUNDARY-START(463857188970),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 721002,
      "h": 463857188970,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463857188970),
//--TRIMMABLE-BOUNDARY-START(459562221674),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 721002,
      "h": 459562221674,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459562221674),
//--TRIMMABLE-BOUNDARY-START(425202483306),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 721002,
      "h": 425202483306,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425202483306),
//--TRIMMABLE-BOUNDARY-START(420907516010),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 721002,
      "h": 420907516010,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420907516010),
//--TRIMMABLE-BOUNDARY-START(343598104682),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 721002,
      "h": 343598104682,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343598104682),
//--TRIMMABLE-BOUNDARY-START(339303137386),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 721002,
      "h": 339303137386,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339303137386),
//--TRIMMABLE-BOUNDARY-START(292058497130),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 721002,
      "h": 292058497130,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292058497130),
//--TRIMMABLE-BOUNDARY-START(287763529834),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 721002,
      "h": 287763529834,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287763529834),
//--TRIMMABLE-BOUNDARY-START(532576665706),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 721002,
      "h": 532576665706,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532576665706),
//--TRIMMABLE-BOUNDARY-START(528281698410),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 721002,
      "h": 528281698410,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528281698410)
  ],
  "h": 721002
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Obsoletions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721002)
        
        

        //--TRIMMABLE-BOUNDARY-START(131178)
        $asm.$cls(`$snwh.SN.HeaderInfoTable`, ($self) => class HeaderInfoTable extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(47244771434)
            /*Func<string, string[]>*/ static s_singleParser = null;
            //--TRIMMABLE-BOUNDARY-END(47244771434)
            
            //--TRIMMABLE-BOUNDARY-START(38654836842)
            /*Func<string, string[]>*/ static s_multiParser = null;
            //--TRIMMABLE-BOUNDARY-END(38654836842)
            
            //--TRIMMABLE-BOUNDARY-START(42949804138)
            /*Func<string, string[]>*/ static s_setCookieParser = null;
            //--TRIMMABLE-BOUNDARY-END(42949804138)
            
            //--TRIMMABLE-BOUNDARY-START(51539738730)
            /*HeaderInfo*/ static s_unknownHeaderInfo = null;
            //--TRIMMABLE-BOUNDARY-END(51539738730)
            
            //--TRIMMABLE-BOUNDARY-START(34359869546)
            /*Hashtable*/ static s_headerHashTable = null;
            //--TRIMMABLE-BOUNDARY-END(34359869546)
            
            //--TRIMMABLE-BOUNDARY-START(30064902250)
            static /*string[] */ ParseValueHelper(/*string*/ value, /*bool*/ isSetCookie)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (isSetCookie && (!value.includes("=")))
                {
                    return $.$$.S.Array.Empty($.$$.S.String);
                }
                /*var*/ let tempStringCollection = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                /*bool*/ let inquote = false;
                /*int*/ let startIndex = 0;
                /*int*/ let length = 0;
                for(/*int*/ let i = 0; i < value.length; i++)
                {
                    if ($.$$.S.String.get_Chars.call(value, i) === /*\"*/ 34)
                    {
                        inquote = !inquote;
                    }
                    else if (($.$$.S.String.get_Chars.call(value, i) === /*,*/ 44) && !inquote)
                    {
                        /*ReadOnlySpan<char>*/ let singleValue = $.$$.S.MemoryExtensions.Trim$4($.$$.S.MemoryExtensions.AsSpan$1(value, startIndex, length));
                        if (!isSetCookie || !$.$snwh.SN.HeaderInfoTable.IsDuringExpiresAttributeParsing(singleValue))
                        {
                            tempStringCollection.Add(singleValue.ToString());
                            startIndex = ((i + 1) | 0);
                            length = 0;
                            continue;
                        }
                    }
                    length++;
                }
                if (startIndex < value.length && length > 0)
                {
                    tempStringCollection.Add($.$$.S.MemoryExtensions.Trim$4($.$$.S.MemoryExtensions.AsSpan$1(value, startIndex, length)).ToString());
                }
                return tempStringCollection.ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(30064902250)
            
            //--TRIMMABLE-BOUNDARY-START(25769934954)
            static /*bool */ IsDuringExpiresAttributeParsing(/*ReadOnlySpan<char>*/ singleValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let semiPos = $.$$.S.MemoryExtensions.LastIndexOf$4($.$$.S.Char, singleValue, /*;*/ 59);
                if (semiPos >= 0)
                {
                    /*ReadOnlySpan<char>*/ let lastElement = singleValue.Slice$1(((semiPos + 1) | 0));
                    if (!$.$$.S.MemoryExtensions.Contains$2($.$$.S.Char, lastElement, /*,*/ 44))
                    {
                        /*int*/ let equalsPos = $.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, lastElement, /*=*/ 61);
                        if (equalsPos < 0)
                        {
                            equalsPos = lastElement.Length;
                        }
                        return $.$$.S.MemoryExtensions.Equals$2($.$$.S.MemoryExtensions.Trim$4(lastElement.Slice(0, equalsPos)), $.$$.S.String.op_Implicit("Expires"), 5/*StringComparison.OrdinalIgnoreCase*/);
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(25769934954)
            
            //--TRIMMABLE-BOUNDARY-START(12885033066)
            static /*Hashtable */ CreateHeaderHashtable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885033066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let Items = 52;
                /*var*/ let headers = (() =>
                {
                    //new $.$$.SC$1.Hashtable()
                    const $t1 = $.$$.SC$1.Hashtable;
                    const $i1 = new $t1();
                    $i1.$ctor$11(((Items * 2) | 0), $.$$.S.StringComparer.OrdinalIgnoreCase);
                    $i1.Add("Age"/*HttpKnownHeaderNames.Age*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Age"/*HttpKnownHeaderNames.Age*/, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Allow"/*HttpKnownHeaderNames.Allow*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Allow"/*HttpKnownHeaderNames.Allow*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Accept"/*HttpKnownHeaderNames.Accept*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Accept"/*HttpKnownHeaderNames.Accept*/, true, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Authorization"/*HttpKnownHeaderNames.Authorization*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Authorization"/*HttpKnownHeaderNames.Authorization*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Accept-Ranges"/*HttpKnownHeaderNames.AcceptRanges*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Accept-Ranges"/*HttpKnownHeaderNames.AcceptRanges*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Accept-Charset"/*HttpKnownHeaderNames.AcceptCharset*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Accept-Charset"/*HttpKnownHeaderNames.AcceptCharset*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Accept-Encoding"/*HttpKnownHeaderNames.AcceptEncoding*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Accept-Encoding"/*HttpKnownHeaderNames.AcceptEncoding*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Accept-Language"/*HttpKnownHeaderNames.AcceptLanguage*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Accept-Language"/*HttpKnownHeaderNames.AcceptLanguage*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Cookie"/*HttpKnownHeaderNames.Cookie*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Cookie"/*HttpKnownHeaderNames.Cookie*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Connection"/*HttpKnownHeaderNames.Connection*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Connection"/*HttpKnownHeaderNames.Connection*/, true, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Content-MD5"/*HttpKnownHeaderNames.ContentMD5*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Content-MD5"/*HttpKnownHeaderNames.ContentMD5*/, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Content-Type"/*HttpKnownHeaderNames.ContentType*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Content-Type"/*HttpKnownHeaderNames.ContentType*/, true, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Cache-Control"/*HttpKnownHeaderNames.CacheControl*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Cache-Control"/*HttpKnownHeaderNames.CacheControl*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Content-Range"/*HttpKnownHeaderNames.ContentRange*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Content-Range"/*HttpKnownHeaderNames.ContentRange*/, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Content-Length"/*HttpKnownHeaderNames.ContentLength*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Content-Length"/*HttpKnownHeaderNames.ContentLength*/, true, true, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Content-Encoding"/*HttpKnownHeaderNames.ContentEncoding*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Content-Encoding"/*HttpKnownHeaderNames.ContentEncoding*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Content-Language"/*HttpKnownHeaderNames.ContentLanguage*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Content-Language"/*HttpKnownHeaderNames.ContentLanguage*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Content-Location"/*HttpKnownHeaderNames.ContentLocation*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Content-Location"/*HttpKnownHeaderNames.ContentLocation*/, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Date"/*HttpKnownHeaderNames.Date*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Date"/*HttpKnownHeaderNames.Date*/, true, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("ETag"/*HttpKnownHeaderNames.ETag*/, new $.$snwh.SN.HeaderInfo().$ctor$1("ETag"/*HttpKnownHeaderNames.ETag*/, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Expect"/*HttpKnownHeaderNames.Expect*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Expect"/*HttpKnownHeaderNames.Expect*/, true, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Expires"/*HttpKnownHeaderNames.Expires*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Expires"/*HttpKnownHeaderNames.Expires*/, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("From"/*HttpKnownHeaderNames.From*/, new $.$snwh.SN.HeaderInfo().$ctor$1("From"/*HttpKnownHeaderNames.From*/, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Host"/*HttpKnownHeaderNames.Host*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Host"/*HttpKnownHeaderNames.Host*/, true, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("If-Match"/*HttpKnownHeaderNames.IfMatch*/, new $.$snwh.SN.HeaderInfo().$ctor$1("If-Match"/*HttpKnownHeaderNames.IfMatch*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("If-Range"/*HttpKnownHeaderNames.IfRange*/, new $.$snwh.SN.HeaderInfo().$ctor$1("If-Range"/*HttpKnownHeaderNames.IfRange*/, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("If-None-Match"/*HttpKnownHeaderNames.IfNoneMatch*/, new $.$snwh.SN.HeaderInfo().$ctor$1("If-None-Match"/*HttpKnownHeaderNames.IfNoneMatch*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("If-Modified-Since"/*HttpKnownHeaderNames.IfModifiedSince*/, new $.$snwh.SN.HeaderInfo().$ctor$1("If-Modified-Since"/*HttpKnownHeaderNames.IfModifiedSince*/, true, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("If-Unmodified-Since"/*HttpKnownHeaderNames.IfUnmodifiedSince*/, new $.$snwh.SN.HeaderInfo().$ctor$1("If-Unmodified-Since"/*HttpKnownHeaderNames.IfUnmodifiedSince*/, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Keep-Alive"/*HttpKnownHeaderNames.KeepAlive*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Keep-Alive"/*HttpKnownHeaderNames.KeepAlive*/, false, true, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Location"/*HttpKnownHeaderNames.Location*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Location"/*HttpKnownHeaderNames.Location*/, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Last-Modified"/*HttpKnownHeaderNames.LastModified*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Last-Modified"/*HttpKnownHeaderNames.LastModified*/, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Max-Forwards"/*HttpKnownHeaderNames.MaxForwards*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Max-Forwards"/*HttpKnownHeaderNames.MaxForwards*/, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Pragma"/*HttpKnownHeaderNames.Pragma*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Pragma"/*HttpKnownHeaderNames.Pragma*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Proxy-Authenticate"/*HttpKnownHeaderNames.ProxyAuthenticate*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Proxy-Authenticate"/*HttpKnownHeaderNames.ProxyAuthenticate*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Proxy-Authorization"/*HttpKnownHeaderNames.ProxyAuthorization*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Proxy-Authorization"/*HttpKnownHeaderNames.ProxyAuthorization*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Proxy-Connection"/*HttpKnownHeaderNames.ProxyConnection*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Proxy-Connection"/*HttpKnownHeaderNames.ProxyConnection*/, true, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Range"/*HttpKnownHeaderNames.Range*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Range"/*HttpKnownHeaderNames.Range*/, true, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Referer"/*HttpKnownHeaderNames.Referer*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Referer"/*HttpKnownHeaderNames.Referer*/, true, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Retry-After"/*HttpKnownHeaderNames.RetryAfter*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Retry-After"/*HttpKnownHeaderNames.RetryAfter*/, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Server"/*HttpKnownHeaderNames.Server*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Server"/*HttpKnownHeaderNames.Server*/, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Set-Cookie"/*HttpKnownHeaderNames.SetCookie*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Set-Cookie"/*HttpKnownHeaderNames.SetCookie*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_setCookieParser));
                    $i1.Add("Set-Cookie2"/*HttpKnownHeaderNames.SetCookie2*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Set-Cookie2"/*HttpKnownHeaderNames.SetCookie2*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_setCookieParser));
                    $i1.Add("TE"/*HttpKnownHeaderNames.TE*/, new $.$snwh.SN.HeaderInfo().$ctor$1("TE"/*HttpKnownHeaderNames.TE*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Trailer"/*HttpKnownHeaderNames.Trailer*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Trailer"/*HttpKnownHeaderNames.Trailer*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Transfer-Encoding"/*HttpKnownHeaderNames.TransferEncoding*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Transfer-Encoding"/*HttpKnownHeaderNames.TransferEncoding*/, true, true, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Upgrade"/*HttpKnownHeaderNames.Upgrade*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Upgrade"/*HttpKnownHeaderNames.Upgrade*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("User-Agent"/*HttpKnownHeaderNames.UserAgent*/, new $.$snwh.SN.HeaderInfo().$ctor$1("User-Agent"/*HttpKnownHeaderNames.UserAgent*/, true, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    $i1.Add("Via"/*HttpKnownHeaderNames.Via*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Via"/*HttpKnownHeaderNames.Via*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Vary"/*HttpKnownHeaderNames.Vary*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Vary"/*HttpKnownHeaderNames.Vary*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("Warning"/*HttpKnownHeaderNames.Warning*/, new $.$snwh.SN.HeaderInfo().$ctor$1("Warning"/*HttpKnownHeaderNames.Warning*/, false, false, true, $.$snwh.SN.HeaderInfoTable.s_multiParser));
                    $i1.Add("WWW-Authenticate"/*HttpKnownHeaderNames.WWWAuthenticate*/, new $.$snwh.SN.HeaderInfo().$ctor$1("WWW-Authenticate"/*HttpKnownHeaderNames.WWWAuthenticate*/, false, true, true, $.$snwh.SN.HeaderInfoTable.s_singleParser));
                    return $i1;
                })();
                $.$$.SD.Debug.Assert$4(headers.Count === Items, "headers.Count == Items");
                return headers;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033066)
            
            //--TRIMMABLE-BOUNDARY-START(55834706026)
            /*HeaderInfo*/ get_Item$1(/*string*/ name)
            {
                /*HeaderInfo?*/ let tempHeaderInfo = $.$cast($.$snwh.SN.HeaderInfoTable.s_headerHashTable.get_Item(name), $.$snwh.SN.HeaderInfo);
                if (tempHeaderInfo === null)
                {
                    return $.$snwh.SN.HeaderInfoTable.s_unknownHeaderInfo;
                }
                return tempHeaderInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(55834706026)
            
            //--TRIMMABLE-BOUNDARY-START(8590065770)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065770)
            
            //--TRIMMABLE-BOUNDARY-START(8590065770)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590065770)
            
            //--TRIMMABLE-BOUNDARY-START(4295098474)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(47244771434)
                    this.s_singleParser = new ($.$$.S.Func$$$($.$$.S.String, $.$typeArray($.$$.S.String)))().$ctor(this,  (/*value*/ value) =>
                    {
                        return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [value], null, null);
                    }, $OpVFAc ??= {"r":$.$typeArray($.$$.S.String).$h,"p":[{"n":"value","p":1310721}],"n":"","d":131178,"h":0,"f":17825794});
                    //--TRIMMABLE-BOUNDARY-END(47244771434)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654836842)
                    this.s_multiParser = new ($.$$.S.Func$$$($.$$.S.String, $.$typeArray($.$$.S.String)))().$ctor(this,  (/*value*/ value) =>
                    {
                        return $.$snwh.SN.HeaderInfoTable.ParseValueHelper(value, false);
                    }, $xMSbHk ??= {"r":$.$typeArray($.$$.S.String).$h,"p":[{"n":"value","p":1310721}],"n":"","d":131178,"h":0,"f":17825794});
                    //--TRIMMABLE-BOUNDARY-END(38654836842)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949804138)
                    this.s_setCookieParser = new ($.$$.S.Func$$$($.$$.S.String, $.$typeArray($.$$.S.String)))().$ctor(this,  (/*value*/ value) =>
                    {
                        return $.$snwh.SN.HeaderInfoTable.ParseValueHelper(value, true);
                    }, $UryPLe ??= {"r":$.$typeArray($.$$.S.String).$h,"p":[{"n":"value","p":1310721}],"n":"","d":131178,"h":0,"f":17825794});
                    //--TRIMMABLE-BOUNDARY-END(42949804138)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539738730)
                    this.s_unknownHeaderInfo = new $.$snwh.SN.HeaderInfo().$ctor$1($.$$.S.String.Empty, false, false, false, $.$snwh.SN.HeaderInfoTable.s_singleParser);
                    //--TRIMMABLE-BOUNDARY-END(51539738730)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359869546)
                    this.s_headerHashTable = $.$snwh.SN.HeaderInfoTable.CreateHeaderHashtable();
                    //--TRIMMABLE-BOUNDARY-END(34359869546)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295098474)
            
            static $h = 131178;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834706026),
    {
      "p": 65642,
      "i": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 21474967658,
        "f": 50331656
      },
      "n": "Item",
      "o": "@$1",
      "d": 131178,
      "h": 55834706026,
      "f": 538968072
    },
//--TRIMMABLE-BOUNDARY-END(55834706026)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064902250),
    {
      "r": $.$typeArray($.$$.S.String).$h,
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "isSetCookie",
          "p": 262145
        }
      ],
      "n": "ParseValueHelper",
      "d": 131178,
      "h": 30064902250,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30064902250),
//--TRIMMABLE-BOUNDARY-START(25769934954),
    {
      "r": 262145,
      "p": [
        {
          "n": "singleValue",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "IsDuringExpiresAttributeParsing",
      "d": 131178,
      "h": 25769934954,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25769934954),
//--TRIMMABLE-BOUNDARY-START(12885033066),
    {
      "r": 62652417,
      "n": "CreateHeaderHashtable",
      "d": 131178,
      "h": 12885033066,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885033066)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47244771434),
    {
      "t": $.$$.S.Func$$$($.$$.S.String, $.$typeArray($.$$.S.String)).$h,
      "n": "s_singleParser",
      "d": 131178,
      "h": 47244771434,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47244771434),
//--TRIMMABLE-BOUNDARY-START(38654836842),
    {
      "t": $.$$.S.Func$$$($.$$.S.String, $.$typeArray($.$$.S.String)).$h,
      "n": "s_multiParser",
      "d": 131178,
      "h": 38654836842,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38654836842),
//--TRIMMABLE-BOUNDARY-START(42949804138),
    {
      "t": $.$$.S.Func$$$($.$$.S.String, $.$typeArray($.$$.S.String)).$h,
      "n": "s_setCookieParser",
      "d": 131178,
      "h": 42949804138,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42949804138),
//--TRIMMABLE-BOUNDARY-START(51539738730),
    {
      "t": 65642,
      "n": "s_unknownHeaderInfo",
      "d": 131178,
      "h": 51539738730,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51539738730),
//--TRIMMABLE-BOUNDARY-START(34359869546),
    {
      "t": 62652417,
      "n": "s_headerHashTable",
      "d": 131178,
      "h": 34359869546,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34359869546)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065770),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131178,
      "h": 8590065770,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065770)
  ],
  "h": 131178
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.HeaderInfoTable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}HeaderInfoTable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131178)
        
        

        //--TRIMMABLE-BOUNDARY-START(524394)
        $asm.$cls(`$snwh.SN.HttpValidationHelpers`, ($self) => class HttpValidationHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(8590458986)
            static /*string */ CheckBadHeaderNameChars(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590458986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwh.SN.HttpValidationHelpers.IsInvalidMethodOrHeaderString(name))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snwh.S.SR.Format$6($.$snwh.S.SR.net_WebHeaderInvalidHeaderChars, name), "name");
                }
                if ($.$snwh.SN.HttpValidationHelpers.ContainsNonAsciiChars(name))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snwh.S.SR.Format$6($.$snwh.S.SR.net_WebHeaderInvalidHeaderChars, name), "name");
                }
                return name;
            }
            //--TRIMMABLE-BOUNDARY-END(8590458986)
            
            //--TRIMMABLE-BOUNDARY-START(17180393578)
            static /*bool */ ContainsNonAsciiChars(/*string*/ token)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180393578);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.MemoryExtensions.ContainsAnyExceptInRange($.$$.S.Char, $.$$.S.MemoryExtensions.AsSpan$4(token), 32, 126);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180393578)
            
            //--TRIMMABLE-BOUNDARY-START(25770328170)
            static /*bool */ IsValidToken(/*string*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770328170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (token.length > 0) && !$.$snwh.SN.HttpValidationHelpers.IsInvalidMethodOrHeaderString(token) && !$.$snwh.SN.HttpValidationHelpers.ContainsNonAsciiChars(token);
            }
            //--TRIMMABLE-BOUNDARY-END(25770328170)
            
            //--TRIMMABLE-BOUNDARY-START(30065295466)
            /*char[]*/ static s_httpTrimCharacters = null;
            //--TRIMMABLE-BOUNDARY-END(30065295466)
            
            //--TRIMMABLE-BOUNDARY-START(12885426282)
            static /*string */ CheckBadHeaderValueChars(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885426282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(value))
                {
                    return $.$$.S.String.Empty;
                }
                value = $.$$.S.String.Trim$2.call(value, $.$snwh.SN.HttpValidationHelpers.s_httpTrimCharacters);
                /*int*/ let crlf = 0;
                for(/*int*/ let i = 0; i < value.length; ++i)
                {
                    /*char*/ let c = (((255 & $.$$.S.String.get_Chars.call(value, i)) & 0xFFFF) >>> 0);
                    switch(crlf)
                    {
                        case 0:
                        if (c === /*\r*/ 13)
                        {
                            crlf = 1;
                        }
                        else if (c === /*\n*/ 10)
                        {
                            crlf = 2;
                        }
                        else if (c === 127 || (c < /* */ 32 && c !== /*\t*/ 9))
                        {
                            throw new $.$$.S.ArgumentException().$ctor$13($.$snwh.S.SR.net_WebHeaderInvalidControlChars, "value");
                        }
                        break;
                        case 1:
                        if (c === /*\n*/ 10)
                        {
                            crlf = 2;
                            break;
                        }
                        throw new $.$$.S.ArgumentException().$ctor$13($.$snwh.S.SR.net_WebHeaderInvalidCRLFChars, "value");
                        case 2:
                        if (c === /* */ 32 || c === /*\t*/ 9)
                        {
                            crlf = 0;
                            break;
                        }
                        throw new $.$$.S.ArgumentException().$ctor$13($.$snwh.S.SR.net_WebHeaderInvalidControlChars, "value");
                    }
                }
                if (crlf !== 0)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snwh.S.SR.net_WebHeaderInvalidCRLFChars, "value");
                }
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426282)
            
            //--TRIMMABLE-BOUNDARY-START(21475360874)
            static /*bool */ IsInvalidMethodOrHeaderString(/*string*/ stringValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let i = 0; i < stringValue.length; i++)
                {
                    let $switch2 = $.$$.S.String.get_Chars.call(stringValue, i);
                    switch($switch2)
                    {
                        case /*(*/ 40:
                        case /*)*/ 41:
                        case /*<*/ 60:
                        case /*>*/ 62:
                        case /*@*/ 64:
                        case /*,*/ 44:
                        case /*;*/ 59:
                        case /*:*/ 58:
                        case /*\\*/ 92:
                        case /*\"*/ 34:
                        case /*'*/ 39:
                        case /*/*/ 47:
                        case /*[*/ 91:
                        case /*]*/ 93:
                        case /*?*/ 63:
                        case /*=*/ 61:
                        case /*{*/ 123:
                        case /*}*/ 125:
                        case /* */ 32:
                        case /*\t*/ 9:
                        case /*\r*/ 13:
                        case /*\n*/ 10:
                        return true;
                        default:
                        break;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(21475360874)
            
            //--TRIMMABLE-BOUNDARY-START(4295491690)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(30065295466)
                    this.s_httpTrimCharacters = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [9, 10, 11, 12, 13, 32], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(30065295466)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295491690)
            
            static $h = 524394;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590458986),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "CheckBadHeaderNameChars",
      "d": 524394,
      "h": 8590458986,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590458986),
//--TRIMMABLE-BOUNDARY-START(17180393578),
    {
      "r": 262145,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "ContainsNonAsciiChars",
      "d": 524394,
      "h": 17180393578,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180393578),
//--TRIMMABLE-BOUNDARY-START(25770328170),
    {
      "r": 262145,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "IsValidToken",
      "d": 524394,
      "h": 25770328170,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770328170),
//--TRIMMABLE-BOUNDARY-START(12885426282),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "CheckBadHeaderValueChars",
      "d": 524394,
      "h": 12885426282,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885426282),
//--TRIMMABLE-BOUNDARY-START(21475360874),
    {
      "r": 262145,
      "p": [
        {
          "n": "stringValue",
          "p": 1310721
        }
      ],
      "n": "IsInvalidMethodOrHeaderString",
      "d": 524394,
      "h": 21475360874,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475360874)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065295466),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "s_httpTrimCharacters",
      "d": 524394,
      "h": 30065295466,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30065295466)
  ],
  "h": 524394
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.HttpValidationHelpers`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}HttpValidationHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524394)
        
        

        //--TRIMMABLE-BOUNDARY-START(327786)
        $asm.$cls(`$snwh.SN.HttpRequestHeaderExtensions`, ($self) => class HttpRequestHeaderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(12885229674)
            /*string[]*/ static s_names = null;
            //--TRIMMABLE-BOUNDARY-END(12885229674)
            
            //--TRIMMABLE-BOUNDARY-START(8590262378)
            static /*string */ GetName(/*this HttpRequestHeader*/ header)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Array.$ReadT1.call($.$snwh.SN.HttpRequestHeaderExtensions.s_names, header);
            }
            //--TRIMMABLE-BOUNDARY-END(8590262378)
            
            //--TRIMMABLE-BOUNDARY-START(4295295082)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885229674)
                    this.s_names = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Cache-Control", "Connection", "Date", "Keep-Alive", "Pragma", "Trailer", "Transfer-Encoding", "Upgrade", "Via", "Warning", "Allow", "Content-Length", "Content-Type", "Content-Encoding", "Content-Language", "Content-Location", "Content-MD5", "Content-Range", "Expires", "Last-Modified", "Accept", "Accept-Charset", "Accept-Encoding", "Accept-Language", "Authorization", "Cookie", "Expect", "From", "Host", "If-Match", "If-Modified-Since", "If-None-Match", "If-Range", "If-Unmodified-Since", "Max-Forwards", "Proxy-Authorization", "Referer", "Range", "Te", "Translate", "User-Agent"], null, null);
                    //--TRIMMABLE-BOUNDARY-END(12885229674)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295295082)
            
            static $h = 327786;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590262378),
    {
      "r": 1310721,
      "p": [
        {
          "n": "header",
          "p": 262250
        }
      ],
      "n": "GetName",
      "d": 327786,
      "h": 8590262378,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590262378)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885229674),
    {
      "t": $.$typeArray($.$$.S.String).$h,
      "n": "s_names",
      "d": 327786,
      "h": 12885229674,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885229674)
  ],
  "h": 327786
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.HttpRequestHeaderExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}HttpRequestHeaderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327786)
        
        

        //--TRIMMABLE-BOUNDARY-START(458858)
        $asm.$cls(`$snwh.SN.HttpResponseHeaderExtensions`, ($self) => class HttpResponseHeaderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(12885360746)
            /*string[]*/ static s_names = null;
            //--TRIMMABLE-BOUNDARY-END(12885360746)
            
            //--TRIMMABLE-BOUNDARY-START(8590393450)
            static /*string */ GetName(/*this HttpResponseHeader*/ header)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Array.$ReadT1.call($.$snwh.SN.HttpResponseHeaderExtensions.s_names, header);
            }
            //--TRIMMABLE-BOUNDARY-END(8590393450)
            
            //--TRIMMABLE-BOUNDARY-START(4295426154)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885360746)
                    this.s_names = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Cache-Control", "Connection", "Date", "Keep-Alive", "Pragma", "Trailer", "Transfer-Encoding", "Upgrade", "Via", "Warning", "Allow", "Content-Length", "Content-Type", "Content-Encoding", "Content-Language", "Content-Location", "Content-MD5", "Content-Range", "Expires", "Last-Modified", "Accept-Ranges", "Age", "ETag", "Location", "Proxy-Authenticate", "Retry-After", "Server", "Set-Cookie", "Vary", "WWW-Authenticate"], null, null);
                    //--TRIMMABLE-BOUNDARY-END(12885360746)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295426154)
            
            static $h = 458858;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590393450),
    {
      "r": 1310721,
      "p": [
        {
          "n": "header",
          "p": 393322
        }
      ],
      "n": "GetName",
      "d": 458858,
      "h": 8590393450,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590393450)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885360746),
    {
      "t": $.$typeArray($.$$.S.String).$h,
      "n": "s_names",
      "d": 458858,
      "h": 12885360746,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885360746)
  ],
  "h": 458858
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.HttpResponseHeaderExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}HttpResponseHeaderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458858)
        
        

        //--TRIMMABLE-BOUNDARY-START(262250)
        $asm.$str(`$snwh.SN.HttpRequestHeader`, ($self) => class HttpRequestHeader extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static CacheControl = 0;
            static Connection = 1;
            static Date = 2;
            static KeepAlive = 3;
            static Pragma = 4;
            static Trailer = 5;
            static TransferEncoding = 6;
            static Upgrade = 7;
            static Via = 8;
            static Warning = 9;
            static Allow = 10;
            static ContentLength = 11;
            static ContentType = 12;
            static ContentEncoding = 13;
            static ContentLanguage = 14;
            static ContentLocation = 15;
            static ContentMd5 = 16;
            static ContentRange = 17;
            static Expires = 18;
            static LastModified = 19;
            static Accept = 20;
            static AcceptCharset = 21;
            static AcceptEncoding = 22;
            static AcceptLanguage = 23;
            static Authorization = 24;
            static Cookie = 25;
            static Expect = 26;
            static From = 27;
            static Host = 28;
            static IfMatch = 29;
            static IfModifiedSince = 30;
            static IfNoneMatch = 31;
            static IfRange = 32;
            static IfUnmodifiedSince = 33;
            static MaxForwards = 34;
            static ProxyAuthorization = 35;
            static Referer = 36;
            static Range = 37;
            static Te = 38;
            static Translate = 39;
            static UserAgent = 40;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(262250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "CacheControl": 0n,
                    "Connection": 1n,
                    "Date": 2n,
                    "KeepAlive": 3n,
                    "Pragma": 4n,
                    "Trailer": 5n,
                    "TransferEncoding": 6n,
                    "Upgrade": 7n,
                    "Via": 8n,
                    "Warning": 9n,
                    "Allow": 10n,
                    "ContentLength": 11n,
                    "ContentType": 12n,
                    "ContentEncoding": 13n,
                    "ContentLanguage": 14n,
                    "ContentLocation": 15n,
                    "ContentMd5": 16n,
                    "ContentRange": 17n,
                    "Expires": 18n,
                    "LastModified": 19n,
                    "Accept": 20n,
                    "AcceptCharset": 21n,
                    "AcceptEncoding": 22n,
                    "AcceptLanguage": 23n,
                    "Authorization": 24n,
                    "Cookie": 25n,
                    "Expect": 26n,
                    "From": 27n,
                    "Host": 28n,
                    "IfMatch": 29n,
                    "IfModifiedSince": 30n,
                    "IfNoneMatch": 31n,
                    "IfRange": 32n,
                    "IfUnmodifiedSince": 33n,
                    "MaxForwards": 34n,
                    "ProxyAuthorization": 35n,
                    "Referer": 36n,
                    "Range": 37n,
                    "Te": 38n,
                    "Translate": 39n,
                    "UserAgent": 40n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295229546)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229546)
            
            //--TRIMMABLE-BOUNDARY-START(4295229546)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295229546)
            
            static $h = 262250;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360000618),
    {
      "t": 262250,
      "n": "CacheControl",
      "d": 262250,
      "h": 34360000618,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360000618),
//--TRIMMABLE-BOUNDARY-START(38654967914),
    {
      "t": 262250,
      "n": "Connection",
      "d": 262250,
      "h": 38654967914,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654967914),
//--TRIMMABLE-BOUNDARY-START(77309673578),
    {
      "t": 262250,
      "n": "Date",
      "d": 262250,
      "h": 77309673578,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77309673578),
//--TRIMMABLE-BOUNDARY-START(120259346538),
    {
      "t": 262250,
      "n": "KeepAlive",
      "d": 262250,
      "h": 120259346538,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259346538),
//--TRIMMABLE-BOUNDARY-START(133144248426),
    {
      "t": 262250,
      "n": "Pragma",
      "d": 262250,
      "h": 133144248426,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144248426),
//--TRIMMABLE-BOUNDARY-START(154619084906),
    {
      "t": 262250,
      "n": "Trailer",
      "d": 262250,
      "h": 154619084906,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619084906),
//--TRIMMABLE-BOUNDARY-START(158914052202),
    {
      "t": 262250,
      "n": "TransferEncoding",
      "d": 262250,
      "h": 158914052202,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914052202),
//--TRIMMABLE-BOUNDARY-START(167503986794),
    {
      "t": 262250,
      "n": "Upgrade",
      "d": 262250,
      "h": 167503986794,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167503986794),
//--TRIMMABLE-BOUNDARY-START(176093921386),
    {
      "t": 262250,
      "n": "Via",
      "d": 262250,
      "h": 176093921386,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176093921386),
//--TRIMMABLE-BOUNDARY-START(180388888682),
    {
      "t": 262250,
      "n": "Warning",
      "d": 262250,
      "h": 180388888682,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180388888682),
//--TRIMMABLE-BOUNDARY-START(25770066026),
    {
      "t": 262250,
      "n": "Allow",
      "d": 262250,
      "h": 25770066026,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770066026),
//--TRIMMABLE-BOUNDARY-START(51539869802),
    {
      "t": 262250,
      "n": "ContentLength",
      "d": 262250,
      "h": 51539869802,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539869802),
//--TRIMMABLE-BOUNDARY-START(68719738986),
    {
      "t": 262250,
      "n": "ContentType",
      "d": 262250,
      "h": 68719738986,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68719738986),
//--TRIMMABLE-BOUNDARY-START(42949935210),
    {
      "t": 262250,
      "n": "ContentEncoding",
      "d": 262250,
      "h": 42949935210,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949935210),
//--TRIMMABLE-BOUNDARY-START(47244902506),
    {
      "t": 262250,
      "n": "ContentLanguage",
      "d": 262250,
      "h": 47244902506,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47244902506),
//--TRIMMABLE-BOUNDARY-START(55834837098),
    {
      "t": 262250,
      "n": "ContentLocation",
      "d": 262250,
      "h": 55834837098,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834837098),
//--TRIMMABLE-BOUNDARY-START(60129804394),
    {
      "t": 262250,
      "n": "ContentMd5",
      "d": 262250,
      "h": 60129804394,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60129804394),
//--TRIMMABLE-BOUNDARY-START(64424771690),
    {
      "t": 262250,
      "n": "ContentRange",
      "d": 262250,
      "h": 64424771690,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424771690),
//--TRIMMABLE-BOUNDARY-START(85899608170),
    {
      "t": 262250,
      "n": "Expires",
      "d": 262250,
      "h": 85899608170,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899608170),
//--TRIMMABLE-BOUNDARY-START(124554313834),
    {
      "t": 262250,
      "n": "LastModified",
      "d": 262250,
      "h": 124554313834,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554313834),
//--TRIMMABLE-BOUNDARY-START(8590196842),
    {
      "t": 262250,
      "n": "Accept",
      "d": 262250,
      "h": 8590196842,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590196842),
//--TRIMMABLE-BOUNDARY-START(12885164138),
    {
      "t": 262250,
      "n": "AcceptCharset",
      "d": 262250,
      "h": 12885164138,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885164138),
//--TRIMMABLE-BOUNDARY-START(17180131434),
    {
      "t": 262250,
      "n": "AcceptEncoding",
      "d": 262250,
      "h": 17180131434,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180131434),
//--TRIMMABLE-BOUNDARY-START(21475098730),
    {
      "t": 262250,
      "n": "AcceptLanguage",
      "d": 262250,
      "h": 21475098730,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475098730),
//--TRIMMABLE-BOUNDARY-START(30065033322),
    {
      "t": 262250,
      "n": "Authorization",
      "d": 262250,
      "h": 30065033322,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065033322),
//--TRIMMABLE-BOUNDARY-START(73014706282),
    {
      "t": 262250,
      "n": "Cookie",
      "d": 262250,
      "h": 73014706282,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73014706282),
//--TRIMMABLE-BOUNDARY-START(81604640874),
    {
      "t": 262250,
      "n": "Expect",
      "d": 262250,
      "h": 81604640874,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604640874),
//--TRIMMABLE-BOUNDARY-START(90194575466),
    {
      "t": 262250,
      "n": "From",
      "d": 262250,
      "h": 90194575466,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90194575466),
//--TRIMMABLE-BOUNDARY-START(94489542762),
    {
      "t": 262250,
      "n": "Host",
      "d": 262250,
      "h": 94489542762,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489542762),
//--TRIMMABLE-BOUNDARY-START(98784510058),
    {
      "t": 262250,
      "n": "IfMatch",
      "d": 262250,
      "h": 98784510058,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784510058),
//--TRIMMABLE-BOUNDARY-START(103079477354),
    {
      "t": 262250,
      "n": "IfModifiedSince",
      "d": 262250,
      "h": 103079477354,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079477354),
//--TRIMMABLE-BOUNDARY-START(107374444650),
    {
      "t": 262250,
      "n": "IfNoneMatch",
      "d": 262250,
      "h": 107374444650,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374444650),
//--TRIMMABLE-BOUNDARY-START(111669411946),
    {
      "t": 262250,
      "n": "IfRange",
      "d": 262250,
      "h": 111669411946,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669411946),
//--TRIMMABLE-BOUNDARY-START(115964379242),
    {
      "t": 262250,
      "n": "IfUnmodifiedSince",
      "d": 262250,
      "h": 115964379242,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964379242),
//--TRIMMABLE-BOUNDARY-START(128849281130),
    {
      "t": 262250,
      "n": "MaxForwards",
      "d": 262250,
      "h": 128849281130,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849281130),
//--TRIMMABLE-BOUNDARY-START(137439215722),
    {
      "t": 262250,
      "n": "ProxyAuthorization",
      "d": 262250,
      "h": 137439215722,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439215722),
//--TRIMMABLE-BOUNDARY-START(146029150314),
    {
      "t": 262250,
      "n": "Referer",
      "d": 262250,
      "h": 146029150314,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029150314),
//--TRIMMABLE-BOUNDARY-START(141734183018),
    {
      "t": 262250,
      "n": "Range",
      "d": 262250,
      "h": 141734183018,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734183018),
//--TRIMMABLE-BOUNDARY-START(150324117610),
    {
      "t": 262250,
      "n": "Te",
      "d": 262250,
      "h": 150324117610,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324117610),
//--TRIMMABLE-BOUNDARY-START(163209019498),
    {
      "t": 262250,
      "n": "Translate",
      "d": 262250,
      "h": 163209019498,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163209019498),
//--TRIMMABLE-BOUNDARY-START(171798954090),
    {
      "t": 262250,
      "n": "UserAgent",
      "d": 262250,
      "h": 171798954090,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171798954090)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229546),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262250,
      "h": 4295229546,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229546)
  ],
  "h": 262250
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.HttpRequestHeader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}HttpRequestHeader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262250)
        
        

        //--TRIMMABLE-BOUNDARY-START(393322)
        $asm.$str(`$snwh.SN.HttpResponseHeader`, ($self) => class HttpResponseHeader extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static CacheControl = 0;
            static Connection = 1;
            static Date = 2;
            static KeepAlive = 3;
            static Pragma = 4;
            static Trailer = 5;
            static TransferEncoding = 6;
            static Upgrade = 7;
            static Via = 8;
            static Warning = 9;
            static Allow = 10;
            static ContentLength = 11;
            static ContentType = 12;
            static ContentEncoding = 13;
            static ContentLanguage = 14;
            static ContentLocation = 15;
            static ContentMd5 = 16;
            static ContentRange = 17;
            static Expires = 18;
            static LastModified = 19;
            static AcceptRanges = 20;
            static Age = 21;
            static ETag = 22;
            static Location = 23;
            static ProxyAuthenticate = 24;
            static RetryAfter = 25;
            static Server = 26;
            static SetCookie = 27;
            static Vary = 28;
            static WwwAuthenticate = 29;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(393322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "CacheControl": 0n,
                    "Connection": 1n,
                    "Date": 2n,
                    "KeepAlive": 3n,
                    "Pragma": 4n,
                    "Trailer": 5n,
                    "TransferEncoding": 6n,
                    "Upgrade": 7n,
                    "Via": 8n,
                    "Warning": 9n,
                    "Allow": 10n,
                    "ContentLength": 11n,
                    "ContentType": 12n,
                    "ContentEncoding": 13n,
                    "ContentLanguage": 14n,
                    "ContentLocation": 15n,
                    "ContentMd5": 16n,
                    "ContentRange": 17n,
                    "Expires": 18n,
                    "LastModified": 19n,
                    "AcceptRanges": 20n,
                    "Age": 21n,
                    "ETag": 22n,
                    "Location": 23n,
                    "ProxyAuthenticate": 24n,
                    "RetryAfter": 25n,
                    "Server": 26n,
                    "SetCookie": 27n,
                    "Vary": 28n,
                    "WwwAuthenticate": 29n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295360618)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360618)
            
            //--TRIMMABLE-BOUNDARY-START(4295360618)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295360618)
            
            static $h = 393322;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475229802),
    {
      "t": 393322,
      "n": "CacheControl",
      "d": 393322,
      "h": 21475229802,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475229802),
//--TRIMMABLE-BOUNDARY-START(25770197098),
    {
      "t": 393322,
      "n": "Connection",
      "d": 393322,
      "h": 25770197098,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770197098),
//--TRIMMABLE-BOUNDARY-START(60129935466),
    {
      "t": 393322,
      "n": "Date",
      "d": 393322,
      "h": 60129935466,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60129935466),
//--TRIMMABLE-BOUNDARY-START(73014837354),
    {
      "t": 393322,
      "n": "KeepAlive",
      "d": 393322,
      "h": 73014837354,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73014837354),
//--TRIMMABLE-BOUNDARY-START(85899739242),
    {
      "t": 393322,
      "n": "Pragma",
      "d": 393322,
      "h": 85899739242,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899739242),
//--TRIMMABLE-BOUNDARY-START(107374575722),
    {
      "t": 393322,
      "n": "Trailer",
      "d": 393322,
      "h": 107374575722,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374575722),
//--TRIMMABLE-BOUNDARY-START(111669543018),
    {
      "t": 393322,
      "n": "TransferEncoding",
      "d": 393322,
      "h": 111669543018,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669543018),
//--TRIMMABLE-BOUNDARY-START(115964510314),
    {
      "t": 393322,
      "n": "Upgrade",
      "d": 393322,
      "h": 115964510314,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964510314),
//--TRIMMABLE-BOUNDARY-START(124554444906),
    {
      "t": 393322,
      "n": "Via",
      "d": 393322,
      "h": 124554444906,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554444906),
//--TRIMMABLE-BOUNDARY-START(128849412202),
    {
      "t": 393322,
      "n": "Warning",
      "d": 393322,
      "h": 128849412202,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849412202),
//--TRIMMABLE-BOUNDARY-START(17180262506),
    {
      "t": 393322,
      "n": "Allow",
      "d": 393322,
      "h": 17180262506,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180262506),
//--TRIMMABLE-BOUNDARY-START(38655098986),
    {
      "t": 393322,
      "n": "ContentLength",
      "d": 393322,
      "h": 38655098986,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655098986),
//--TRIMMABLE-BOUNDARY-START(55834968170),
    {
      "t": 393322,
      "n": "ContentType",
      "d": 393322,
      "h": 55834968170,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834968170),
//--TRIMMABLE-BOUNDARY-START(30065164394),
    {
      "t": 393322,
      "n": "ContentEncoding",
      "d": 393322,
      "h": 30065164394,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065164394),
//--TRIMMABLE-BOUNDARY-START(34360131690),
    {
      "t": 393322,
      "n": "ContentLanguage",
      "d": 393322,
      "h": 34360131690,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360131690),
//--TRIMMABLE-BOUNDARY-START(42950066282),
    {
      "t": 393322,
      "n": "ContentLocation",
      "d": 393322,
      "h": 42950066282,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950066282),
//--TRIMMABLE-BOUNDARY-START(47245033578),
    {
      "t": 393322,
      "n": "ContentMd5",
      "d": 393322,
      "h": 47245033578,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245033578),
//--TRIMMABLE-BOUNDARY-START(51540000874),
    {
      "t": 393322,
      "n": "ContentRange",
      "d": 393322,
      "h": 51540000874,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540000874),
//--TRIMMABLE-BOUNDARY-START(68719870058),
    {
      "t": 393322,
      "n": "Expires",
      "d": 393322,
      "h": 68719870058,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68719870058),
//--TRIMMABLE-BOUNDARY-START(77309804650),
    {
      "t": 393322,
      "n": "LastModified",
      "d": 393322,
      "h": 77309804650,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77309804650),
//--TRIMMABLE-BOUNDARY-START(8590327914),
    {
      "t": 393322,
      "n": "AcceptRanges",
      "d": 393322,
      "h": 8590327914,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590327914),
//--TRIMMABLE-BOUNDARY-START(12885295210),
    {
      "t": 393322,
      "n": "Age",
      "d": 393322,
      "h": 12885295210,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885295210),
//--TRIMMABLE-BOUNDARY-START(64424902762),
    {
      "t": 393322,
      "n": "ETag",
      "d": 393322,
      "h": 64424902762,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424902762),
//--TRIMMABLE-BOUNDARY-START(81604771946),
    {
      "t": 393322,
      "n": "Location",
      "d": 393322,
      "h": 81604771946,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604771946),
//--TRIMMABLE-BOUNDARY-START(90194706538),
    {
      "t": 393322,
      "n": "ProxyAuthenticate",
      "d": 393322,
      "h": 90194706538,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90194706538),
//--TRIMMABLE-BOUNDARY-START(94489673834),
    {
      "t": 393322,
      "n": "RetryAfter",
      "d": 393322,
      "h": 94489673834,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489673834),
//--TRIMMABLE-BOUNDARY-START(98784641130),
    {
      "t": 393322,
      "n": "Server",
      "d": 393322,
      "h": 98784641130,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784641130),
//--TRIMMABLE-BOUNDARY-START(103079608426),
    {
      "t": 393322,
      "n": "SetCookie",
      "d": 393322,
      "h": 103079608426,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079608426),
//--TRIMMABLE-BOUNDARY-START(120259477610),
    {
      "t": 393322,
      "n": "Vary",
      "d": 393322,
      "h": 120259477610,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259477610),
//--TRIMMABLE-BOUNDARY-START(133144379498),
    {
      "t": 393322,
      "n": "WwwAuthenticate",
      "d": 393322,
      "h": 133144379498,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144379498)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360618),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393322,
      "h": 4295360618,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360618)
  ],
  "h": 393322
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.HttpResponseHeader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}HttpResponseHeader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393322)
        
        

        //--TRIMMABLE-BOUNDARY-START(655466)
        $asm.$str(`$snwh.SN.WebHeaderCollectionType`, ($self) => class WebHeaderCollectionType extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static Unknown = 0;
            static WebRequest = 1;
            static WebResponse = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "WebRequest": 1n,
                    "WebResponse": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295622762)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622762)
            
            //--TRIMMABLE-BOUNDARY-START(4295622762)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295622762)
            
            static $h = 655466;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590590058),
    {
      "t": 655466,
      "n": "Unknown",
      "d": 655466,
      "h": 8590590058,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590590058),
//--TRIMMABLE-BOUNDARY-START(12885557354),
    {
      "t": 655466,
      "n": "WebRequest",
      "d": 655466,
      "h": 12885557354,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885557354),
//--TRIMMABLE-BOUNDARY-START(17180524650),
    {
      "t": 655466,
      "n": "WebResponse",
      "d": 655466,
      "h": 17180524650,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180524650)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622762),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655466,
      "h": 4295622762,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622762)
  ],
  "h": 655466
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebHeaderCollectionType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebHeaderCollectionType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655466)
        
        

        //--TRIMMABLE-BOUNDARY-START(589930)
        $asm.$cls(`$snwh.SN.WebHeaderCollection`, ($self) => class WebHeaderCollection extends $.$scs.SCS.NameValueCollection
        {
            //--TRIMMABLE-BOUNDARY-START(60130132074)
            /*int*/ static ApproxAveHeaderLineSize = 30;
            //--TRIMMABLE-BOUNDARY-END(60130132074)
            
            //--TRIMMABLE-BOUNDARY-START(64425099370)
            /*int*/ static ApproxHighAvgNumHeaders = 16;
            //--TRIMMABLE-BOUNDARY-END(64425099370)
            
            //--TRIMMABLE-BOUNDARY-START(8590524522)
            /*WebHeaderCollectionType*/ _type = 0;
            //--TRIMMABLE-BOUNDARY-END(8590524522)
            
            //--TRIMMABLE-BOUNDARY-START(4295557226)
            /*NameValueCollection?*/ _innerCollection = null;
            //--TRIMMABLE-BOUNDARY-END(4295557226)
            
            //--TRIMMABLE-BOUNDARY-START(21475426410)
            $ctor$18(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.$ctor$8();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475426410);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426410)
            
            //--TRIMMABLE-BOUNDARY-START(51540197482)
            /*bool */ get AllowHttpRequestHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194903146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._type === 0/*WebHeaderCollectionType.Unknown*/)
                {
                    this._type = 1/*WebHeaderCollectionType.WebRequest*/;
                }
                return this._type === 1/*WebHeaderCollectionType.WebRequest*/;
            }
            //--TRIMMABLE-BOUNDARY-END(51540197482)
            
            //--TRIMMABLE-BOUNDARY-START(184684183658)
            /*HeaderInfoTable*/ static $HeaderInfo = null;
            static /*HeaderInfoTable */ get HeaderInfo()
            {
                return $.$snwh.SN.WebHeaderCollection.HeaderInfo$ ??= new $.$snwh.SN.HeaderInfoTable().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(184684183658)
            
            //--TRIMMABLE-BOUNDARY-START(188979150954)
            /*NameValueCollection */ get InnerCollection()
            {
                return this._innerCollection ??= new $.$scs.SCS.NameValueCollection().$ctor$11(16/*ApproxHighAvgNumHeaders*/, $.$$.S.StringComparer.OrdinalIgnoreCase);
            }
            //--TRIMMABLE-BOUNDARY-END(188979150954)
            
            //--TRIMMABLE-BOUNDARY-START(55835164778)
            /*bool */ get AllowHttpResponseHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784837738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._type === 0/*WebHeaderCollectionType.Unknown*/)
                {
                    this._type = 2/*WebHeaderCollectionType.WebResponse*/;
                }
                return this._type === 2/*WebHeaderCollectionType.WebResponse*/;
            }
            //--TRIMMABLE-BOUNDARY-END(55835164778)
            
            //--TRIMMABLE-BOUNDARY-START(257698627690)
            /*string?*/ get_Item$3(/*HttpRequestHeader*/ header)
            {
                if (!this.AllowHttpRequestHeader)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwh.S.SR.net_headers_req);
                }
                return this.get_Item$2($.$snwh.SN.HttpRequestHeaderExtensions.GetName(header));
            }
            /*void*/ set_Item$2(/*HttpRequestHeader*/ header, /*string?*/ value)
            {
                if (!this.AllowHttpRequestHeader)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwh.S.SR.net_headers_req);
                }
                this.set_Item$1($.$snwh.SN.HttpRequestHeaderExtensions.GetName(header), value);
            }
            //--TRIMMABLE-BOUNDARY-END(257698627690)
            
            //--TRIMMABLE-BOUNDARY-START(261993594986)
            /*string?*/ get_Item$4(/*HttpResponseHeader*/ header)
            {
                if (!this.AllowHttpResponseHeader)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwh.S.SR.net_headers_rsp);
                }
                return this.get_Item$2($.$snwh.SN.HttpResponseHeaderExtensions.GetName(header));
            }
            /*void*/ set_Item$3(/*HttpResponseHeader*/ header, /*string?*/ value)
            {
                if (!this.AllowHttpResponseHeader)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwh.S.SR.net_headers_rsp);
                }
                this.set_Item$1($.$snwh.SN.HttpResponseHeaderExtensions.GetName(header), value);
            }
            //--TRIMMABLE-BOUNDARY-END(261993594986)
            
            //--TRIMMABLE-BOUNDARY-START(249108693098)
            /*void */ Set(/*string*/ name, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108693098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(name))
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("name");
                }
                name = $.$snwh.SN.HttpValidationHelpers.CheckBadHeaderNameChars(name);
                value = $.$snwh.SN.HttpValidationHelpers.CheckBadHeaderValueChars(value);
                this.InvalidateCachedArrays();
                this.InnerCollection.Set(name, value);
            }
            //--TRIMMABLE-BOUNDARY-END(249108693098)
            
            //--TRIMMABLE-BOUNDARY-START(240518758506)
            /*void */ Set$1(/*HttpRequestHeader*/ header, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518758506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.AllowHttpRequestHeader)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwh.S.SR.net_headers_req);
                }
                this.Set($.$snwh.SN.HttpRequestHeaderExtensions.GetName(header), value);
            }
            //--TRIMMABLE-BOUNDARY-END(240518758506)
            
            //--TRIMMABLE-BOUNDARY-START(244813725802)
            /*void */ Set$2(/*HttpResponseHeader*/ header, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813725802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.AllowHttpResponseHeader)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwh.S.SR.net_headers_rsp);
                }
                this.Set($.$snwh.SN.HttpResponseHeaderExtensions.GetName(header), value);
            }
            //--TRIMMABLE-BOUNDARY-END(244813725802)
            
            //--TRIMMABLE-BOUNDARY-START(171799281770)
            /*void */ GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799281770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(171799281770)
            
            //--TRIMMABLE-BOUNDARY-START(253403660394)
            /*void */ SRS$ISerializable$GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403660394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(253403660394)
            
            //--TRIMMABLE-BOUNDARY-START(210453987434)
            /*void */ Remove$1(/*HttpRequestHeader*/ header)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453987434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.AllowHttpRequestHeader)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwh.S.SR.net_headers_req);
                }
                this.Remove($.$snwh.SN.HttpRequestHeaderExtensions.GetName(header));
            }
            //--TRIMMABLE-BOUNDARY-END(210453987434)
            
            //--TRIMMABLE-BOUNDARY-START(214748954730)
            /*void */ Remove$2(/*HttpResponseHeader*/ header)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748954730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.AllowHttpResponseHeader)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwh.S.SR.net_headers_rsp);
                }
                this.Remove($.$snwh.SN.HttpResponseHeaderExtensions.GetName(header));
            }
            //--TRIMMABLE-BOUNDARY-END(214748954730)
            
            //--TRIMMABLE-BOUNDARY-START(206159020138)
            /*void */ OnDeserialization(/*object?*/ sender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159020138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(206159020138)
            
            //--TRIMMABLE-BOUNDARY-START(197569085546)
            static /*bool */ IsRestricted$1(/*string*/ headerName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569085546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$snwh.SN.WebHeaderCollection.IsRestricted(headerName, false);
            }
            //--TRIMMABLE-BOUNDARY-END(197569085546)
            
            //--TRIMMABLE-BOUNDARY-START(193274118250)
            static /*bool */ IsRestricted(/*string*/ headerName, /*bool*/ response)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274118250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                headerName = $.$snwh.SN.HttpValidationHelpers.CheckBadHeaderNameChars(headerName);
                return response ? $.$snwh.SN.WebHeaderCollection.HeaderInfo.get_Item$1(headerName).IsResponseRestricted : $.$snwh.SN.WebHeaderCollection.HeaderInfo.get_Item$1(headerName).IsRequestRestricted;
            }
            //--TRIMMABLE-BOUNDARY-END(193274118250)
            
            //--TRIMMABLE-BOUNDARY-START(176094249066)
            /*string[]? */ GetValues(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094249066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerCollection.GetValues(index);
            }
            //--TRIMMABLE-BOUNDARY-END(176094249066)
            
            //--TRIMMABLE-BOUNDARY-START(180389216362)
            /*string[]? */ GetValues$1(/*string*/ header)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389216362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*HeaderInfo*/ let info = $.$snwh.SN.WebHeaderCollection.HeaderInfo.get_Item$1(header);
                /*string[]?*/ let values = this.InnerCollection.GetValues$1(header);
                if (info === null || values === null || !info.AllowMultiValues)
                {
                    return values;
                }
                /*string[]*/ let tempValues;
                /*List<string>?*/ let valueList = null;
                for(/*int*/ let i = 0; i < values.length; i++)
                {
                    tempValues = info.Parser.Invoke($.$$.System.Array.$ReadT1.call(values, i));
                    if (valueList === null)
                    {
                        if (tempValues !== null)
                        {
                            valueList = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$2(values);
                            valueList.RemoveRange(i, ((values.length - i) | 0));
                            valueList.AddRange(tempValues);
                        }
                    }
                    else 
                    {
                        valueList.AddRange(tempValues);
                    }
                }
                if (valueList !== null)
                {
                    return valueList.ToArray();
                }
                return values;
            }
            //--TRIMMABLE-BOUNDARY-END(180389216362)
            
            //--TRIMMABLE-BOUNDARY-START(167504314474)
            /*string */ GetKey(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504314474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerCollection.GetKey(index);
            }
            //--TRIMMABLE-BOUNDARY-END(167504314474)
            
            //--TRIMMABLE-BOUNDARY-START(68720066666)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.InvalidateCachedArrays();
                this._innerCollection?.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(68720066666)
            
            //--TRIMMABLE-BOUNDARY-START(154619412586)
            /*string? */ Get(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619412586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._innerCollection === null)
                {
                    return null;
                }
                return this._innerCollection.Get(index);
            }
            //--TRIMMABLE-BOUNDARY-END(154619412586)
            
            //--TRIMMABLE-BOUNDARY-START(158914379882)
            /*string? */ Get$1(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914379882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._innerCollection === null)
                {
                    return null;
                }
                return this._innerCollection.Get$1(name);
            }
            //--TRIMMABLE-BOUNDARY-END(158914379882)
            
            //--TRIMMABLE-BOUNDARY-START(25770393706)
            /*void */ Add$2(/*HttpRequestHeader*/ header, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.AllowHttpRequestHeader)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwh.S.SR.net_headers_req);
                }
                this.Add($.$snwh.SN.HttpRequestHeaderExtensions.GetName(header), value);
            }
            //--TRIMMABLE-BOUNDARY-END(25770393706)
            
            //--TRIMMABLE-BOUNDARY-START(30065361002)
            /*void */ Add$3(/*HttpResponseHeader*/ header, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065361002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.AllowHttpResponseHeader)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwh.S.SR.net_headers_rsp);
                }
                this.Add($.$snwh.SN.HttpResponseHeaderExtensions.GetName(header), value);
            }
            //--TRIMMABLE-BOUNDARY-END(30065361002)
            
            //--TRIMMABLE-BOUNDARY-START(38655295594)
            /*void */ Add$4(/*string*/ header)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(header))
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("header");
                }
                /*int*/ let colpos = $.$$.S.String.IndexOf$3.call(header, /*:*/ 58);
                if (colpos < 0)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snwh.S.SR.net_WebHeaderMissingColon, "header");
                }
                /*string*/ let name = header.substr(0, colpos);
                /*string*/ let value = header.slice(((colpos + 1) | 0));
                name = $.$snwh.SN.HttpValidationHelpers.CheckBadHeaderNameChars(name);
                value = $.$snwh.SN.HttpValidationHelpers.CheckBadHeaderValueChars(value);
                this.InvalidateCachedArrays();
                this.InnerCollection.Add(name, value);
            }
            //--TRIMMABLE-BOUNDARY-END(38655295594)
            
            //--TRIMMABLE-BOUNDARY-START(34360328298)
            /*void */ Add(/*string*/ name, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentException.ThrowIfNullOrEmpty(name, "name");
                name = $.$snwh.SN.HttpValidationHelpers.CheckBadHeaderNameChars(name);
                value = $.$snwh.SN.HttpValidationHelpers.CheckBadHeaderValueChars(value);
                this.InvalidateCachedArrays();
                this.InnerCollection.Add(name, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360328298)
            
            //--TRIMMABLE-BOUNDARY-START(42950262890)
            /*void */ AddWithoutValidate(/*string*/ headerName, /*string?*/ headerValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950262890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                headerName = $.$snwh.SN.HttpValidationHelpers.CheckBadHeaderNameChars(headerName);
                headerValue = $.$snwh.SN.HttpValidationHelpers.CheckBadHeaderValueChars(headerValue);
                this.InvalidateCachedArrays();
                this.InnerCollection.Add(headerName, headerValue);
            }
            //--TRIMMABLE-BOUNDARY-END(42950262890)
            
            //--TRIMMABLE-BOUNDARY-START(219043922026)
            /*void */ Remove(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043922026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(name))
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("name");
                }
                name = $.$snwh.SN.HttpValidationHelpers.CheckBadHeaderNameChars(name);
                if (this._innerCollection !== null)
                {
                    this.InvalidateCachedArrays();
                    this._innerCollection.Remove(name);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219043922026)
            
            //--TRIMMABLE-BOUNDARY-START(270583529578)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583529578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Count === 0)
                {
                    return "\r\n";
                }
                /*var*/ let sb = new $.$$.ST.StringBuilder().$ctor$4(((30/*ApproxAveHeaderLineSize*/ * this.Count) | 0));
                let $en1 = this.InnerCollection.GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let key = $en1.SC$1$IEnumerator$Current;
                    {
                        /*string?*/ let val = this.InnerCollection.Get$1(key);
                        sb.Append$21(key).Append$21(": ").Append$21(val).Append$21("\r\n");
                    }
                }
                sb.Append$21("\r\n");
                return sb.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(270583529578)
            
            //--TRIMMABLE-BOUNDARY-START(266288562282)
            /*byte[] */ ToByteArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288562282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let tempString = this.ToString();
                return $.$$.ST.Encoding.ASCII.GetBytes$8(tempString);
            }
            //--TRIMMABLE-BOUNDARY-END(266288562282)
            
            //--TRIMMABLE-BOUNDARY-START(17180459114)
            $ctor$17()
            {
                super.$ctor$8();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180459114);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180459114)
            
            //--TRIMMABLE-BOUNDARY-START(73015033962)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374772330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._innerCollection === null ? 0 : this._innerCollection.Count);
            }
            //--TRIMMABLE-BOUNDARY-END(73015033962)
            
            //--TRIMMABLE-BOUNDARY-START(201864052842)
            /*KeysCollection */ get Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324445290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerCollection.Keys;
            }
            //--TRIMMABLE-BOUNDARY-END(201864052842)
            
            //--TRIMMABLE-BOUNDARY-START(47245230186)
            /*string[] */ get AllKeys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604968554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerCollection.AllKeys;
            }
            //--TRIMMABLE-BOUNDARY-END(47245230186)
            
            //--TRIMMABLE-BOUNDARY-START(163209347178)
            /*IEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209347178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerCollection.Keys.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(163209347178)
            
            //--TRIMMABLE-BOUNDARY-START(17180459114)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$17();
            }
            //--TRIMMABLE-BOUNDARY-END(17180459114)
            
            static $h = 589930;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$scs.SCS.NameValueCollection; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540197482),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194903146,
        "f": 50331650
      },
      "n": "AllowHttpRequestHeader",
      "d": 589930,
      "h": 51540197482,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51540197482),
//--TRIMMABLE-BOUNDARY-START(184684183658),
    {
      "p": 131178,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964706922,
        "f": 50331682
      },
      "n": "HeaderInfo",
      "d": 589930,
      "h": 184684183658,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(184684183658),
//--TRIMMABLE-BOUNDARY-START(188979150954),
    {
      "p": 983057,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554641514,
        "f": 50331650
      },
      "n": "InnerCollection",
      "d": 589930,
      "h": 188979150954,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(188979150954),
//--TRIMMABLE-BOUNDARY-START(55835164778),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784837738,
        "f": 50331650
      },
      "n": "AllowHttpResponseHeader",
      "d": 589930,
      "h": 55835164778,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55835164778),
//--TRIMMABLE-BOUNDARY-START(257698627690),
    {
      "p": 1310721,
      "i": [
        {
          "n": "header",
          "p": 262250
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144576106,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227633856618,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$3",
      "d": 589930,
      "h": 257698627690,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(257698627690),
//--TRIMMABLE-BOUNDARY-START(261993594986),
    {
      "p": 1310721,
      "i": [
        {
          "n": "header",
          "p": 393322
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734510698,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236223791210,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$4",
      "d": 589930,
      "h": 261993594986,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(261993594986),
//--TRIMMABLE-BOUNDARY-START(73015033962),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374772330,
        "f": 50364417
      },
      "n": "Count",
      "d": 589930,
      "h": 73015033962,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73015033962),
//--TRIMMABLE-BOUNDARY-START(201864052842),
    {
      "p": 786449,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324445290,
        "f": 50364417
      },
      "n": "Keys",
      "d": 589930,
      "h": 201864052842,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(201864052842),
//--TRIMMABLE-BOUNDARY-START(47245230186),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604968554,
        "f": 50364417
      },
      "n": "AllKeys",
      "d": 589930,
      "h": 47245230186,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47245230186)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(249108693098),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Set",
      "d": 589930,
      "h": 249108693098,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(249108693098),
//--TRIMMABLE-BOUNDARY-START(240518758506),
    {
      "r": 65537,
      "p": [
        {
          "n": "header",
          "p": 262250
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Set",
      "o": "@$1",
      "d": 589930,
      "h": 240518758506,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(240518758506),
//--TRIMMABLE-BOUNDARY-START(244813725802),
    {
      "r": 65537,
      "p": [
        {
          "n": "header",
          "p": 393322
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Set",
      "o": "@$2",
      "d": 589930,
      "h": 244813725802,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(244813725802),
//--TRIMMABLE-BOUNDARY-START(171799281770),
    {
      "r": 65537,
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": "GetObjectData",
      "d": 589930,
      "h": 171799281770,
      "f": 16809985,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0051",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171799281770),
//--TRIMMABLE-BOUNDARY-START(210453987434),
    {
      "r": 65537,
      "p": [
        {
          "n": "header",
          "p": 262250
        }
      ],
      "n": "Remove",
      "o": "@$1",
      "d": 589930,
      "h": 210453987434,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210453987434),
//--TRIMMABLE-BOUNDARY-START(214748954730),
    {
      "r": 65537,
      "p": [
        {
          "n": "header",
          "p": 393322
        }
      ],
      "n": "Remove",
      "o": "@$2",
      "d": 589930,
      "h": 214748954730,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214748954730),
//--TRIMMABLE-BOUNDARY-START(206159020138),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        }
      ],
      "n": "OnDeserialization",
      "d": 589930,
      "h": 206159020138,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(206159020138),
//--TRIMMABLE-BOUNDARY-START(197569085546),
    {
      "r": 262145,
      "p": [
        {
          "n": "headerName",
          "p": 1310721
        }
      ],
      "n": "IsRestricted",
      "o": "@$1",
      "d": 589930,
      "h": 197569085546,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(197569085546),
//--TRIMMABLE-BOUNDARY-START(193274118250),
    {
      "r": 262145,
      "p": [
        {
          "n": "headerName",
          "p": 1310721
        },
        {
          "n": "response",
          "p": 262145
        }
      ],
      "n": "IsRestricted",
      "d": 589930,
      "h": 193274118250,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(193274118250),
//--TRIMMABLE-BOUNDARY-START(176094249066),
    {
      "r": $.$typeArray($.$$.S.String).$h,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "GetValues",
      "d": 589930,
      "h": 176094249066,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176094249066),
//--TRIMMABLE-BOUNDARY-START(180389216362),
    {
      "r": $.$typeArray($.$$.S.String).$h,
      "p": [
        {
          "n": "header",
          "p": 1310721
        }
      ],
      "n": "GetValues",
      "o": "@$1",
      "d": 589930,
      "h": 180389216362,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389216362),
//--TRIMMABLE-BOUNDARY-START(167504314474),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "GetKey",
      "d": 589930,
      "h": 167504314474,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(167504314474),
//--TRIMMABLE-BOUNDARY-START(68720066666),
    {
      "r": 65537,
      "n": "Clear",
      "d": 589930,
      "h": 68720066666,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720066666),
//--TRIMMABLE-BOUNDARY-START(154619412586),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "Get",
      "d": 589930,
      "h": 154619412586,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154619412586),
//--TRIMMABLE-BOUNDARY-START(158914379882),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Get",
      "o": "@$1",
      "d": 589930,
      "h": 158914379882,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158914379882),
//--TRIMMABLE-BOUNDARY-START(25770393706),
    {
      "r": 65537,
      "p": [
        {
          "n": "header",
          "p": 262250
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Add",
      "o": "@$2",
      "d": 589930,
      "h": 25770393706,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770393706),
//--TRIMMABLE-BOUNDARY-START(30065361002),
    {
      "r": 65537,
      "p": [
        {
          "n": "header",
          "p": 393322
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Add",
      "o": "@$3",
      "d": 589930,
      "h": 30065361002,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065361002),
//--TRIMMABLE-BOUNDARY-START(38655295594),
    {
      "r": 65537,
      "p": [
        {
          "n": "header",
          "p": 1310721
        }
      ],
      "n": "Add",
      "o": "@$4",
      "d": 589930,
      "h": 38655295594,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655295594),
//--TRIMMABLE-BOUNDARY-START(34360328298),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Add",
      "d": 589930,
      "h": 34360328298,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360328298),
//--TRIMMABLE-BOUNDARY-START(42950262890),
    {
      "r": 65537,
      "p": [
        {
          "n": "headerName",
          "p": 1310721
        },
        {
          "n": "headerValue",
          "p": 1310721
        }
      ],
      "n": "AddWithoutValidate",
      "d": 589930,
      "h": 42950262890,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(42950262890),
//--TRIMMABLE-BOUNDARY-START(219043922026),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Remove",
      "d": 589930,
      "h": 219043922026,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(219043922026),
//--TRIMMABLE-BOUNDARY-START(270583529578),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 589930,
      "h": 270583529578,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(270583529578),
//--TRIMMABLE-BOUNDARY-START(266288562282),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "n": "ToByteArray",
      "d": 589930,
      "h": 266288562282,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(266288562282),
//--TRIMMABLE-BOUNDARY-START(163209347178),
    {
      "r": 63504385,
      "n": "GetEnumerator",
      "d": 589930,
      "h": 163209347178,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163209347178)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60130132074),
    {
      "t": 655361,
      "n": "ApproxAveHeaderLineSize",
      "d": 589930,
      "h": 60130132074,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60130132074),
//--TRIMMABLE-BOUNDARY-START(64425099370),
    {
      "t": 655361,
      "n": "ApproxHighAvgNumHeaders",
      "d": 589930,
      "h": 64425099370,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64425099370),
//--TRIMMABLE-BOUNDARY-START(8590524522),
    {
      "t": 655466,
      "n": "_type",
      "d": 589930,
      "h": 8590524522,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524522),
//--TRIMMABLE-BOUNDARY-START(4295557226),
    {
      "t": 983057,
      "n": "_innerCollection",
      "d": 589930,
      "h": 4295557226,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557226)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475426410),
    {
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$18",
      "d": 589930,
      "h": 21475426410,
      "f": 16777220,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0051",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475426410),
//--TRIMMABLE-BOUNDARY-START(17180459114),
    {
      "n": ".ctor",
      "o": "$ctor$17",
      "d": 589930,
      "h": 17180459114,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180459114)
  ],
  "h": 589930
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable, $.$$.SRS.IDeserializationCallback, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebHeaderCollection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebHeaderCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589930)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Diagnostics.Tracing"));
})();
//--TRIMMABLE-BOUNDARY-END(106)
