
//--TRIMMABLE-BOUNDARY-START(108)
(async function () {
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $srm, $sre, $srei, $srel, $srp, $str) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.Net.WebProxy", 
    {
  "h": 108,
  "f": "System.Net.WebProxy",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Net.WebProxy",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Net.WebProxy",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65644)
        $asm.$cls(`$snw.SN.IWebProxyScript`, ($self) => class IWebProxyScript
        {
            static $h = 65644;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032940),
    {
      "r": 65537,
      "n": "Close",
      "o": "SN$IWebProxyScript$Close",
      "d": 65644,
      "h": 4295032940,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295032940),
//--TRIMMABLE-BOUNDARY-START(8590000236),
    {
      "r": 262145,
      "p": [
        {
          "n": "scriptLocation",
          "p": 1703938
        },
        {
          "n": "script",
          "p": 1310721
        },
        {
          "n": "helperType",
          "p": 188547073
        }
      ],
      "n": "Load",
      "o": "SN$IWebProxyScript$Load",
      "d": 65644,
      "h": 8590000236,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590000236),
//--TRIMMABLE-BOUNDARY-START(12884967532),
    {
      "r": 1310721,
      "p": [
        {
          "n": "url",
          "p": 1310721
        },
        {
          "n": "host",
          "p": 1310721
        }
      ],
      "n": "Run",
      "o": "SN$IWebProxyScript$Run",
      "d": 65644,
      "h": 12884967532,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12884967532)
  ],
  "h": 65644
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.IWebProxyScript`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}IWebProxyScript`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65644)
        
        

        //--TRIMMABLE-BOUNDARY-START(262252)
        $asm.$cls(`$snw.S.Obsoletions`, ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382252351596)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382252351596)
            
            //--TRIMMABLE-BOUNDARY-START(433791959148)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433791959148)
            
            //--TRIMMABLE-BOUNDARY-START(429496991852)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429496991852)
            
            //--TRIMMABLE-BOUNDARY-START(266288234604)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266288234604)
            
            //--TRIMMABLE-BOUNDARY-START(261993267308)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261993267308)
            
            //--TRIMMABLE-BOUNDARY-START(77309673580)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77309673580)
            
            //--TRIMMABLE-BOUNDARY-START(73014706284)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73014706284)
            
            //--TRIMMABLE-BOUNDARY-START(94489542764)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94489542764)
            
            //--TRIMMABLE-BOUNDARY-START(90194575468)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90194575468)
            
            //--TRIMMABLE-BOUNDARY-START(214748627052)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214748627052)
            
            //--TRIMMABLE-BOUNDARY-START(210453659756)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210453659756)
            
            //--TRIMMABLE-BOUNDARY-START(442381893740)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442381893740)
            
            //--TRIMMABLE-BOUNDARY-START(446676861036)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446676861036)
            
            //--TRIMMABLE-BOUNDARY-START(438086926444)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438086926444)
            
            //--TRIMMABLE-BOUNDARY-START(146029150316)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146029150316)
            
            //--TRIMMABLE-BOUNDARY-START(141734183020)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141734183020)
            
            //--TRIMMABLE-BOUNDARY-START(120259346540)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120259346540)
            
            //--TRIMMABLE-BOUNDARY-START(115964379244)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115964379244)
            
            //--TRIMMABLE-BOUNDARY-START(51539869804)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51539869804)
            
            //--TRIMMABLE-BOUNDARY-START(47244902508)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47244902508)
            
            //--TRIMMABLE-BOUNDARY-START(326417776748)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326417776748)
            
            //--TRIMMABLE-BOUNDARY-START(322122809452)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322122809452)
            
            //--TRIMMABLE-BOUNDARY-START(60129804396)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60129804396)
            
            //--TRIMMABLE-BOUNDARY-START(55834837100)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55834837100)
            
            //--TRIMMABLE-BOUNDARY-START(85899608172)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85899608172)
            
            //--TRIMMABLE-BOUNDARY-START(81604640876)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81604640876)
            
            //--TRIMMABLE-BOUNDARY-START(197568757868)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197568757868)
            
            //--TRIMMABLE-BOUNDARY-START(193273790572)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193273790572)
            
            //--TRIMMABLE-BOUNDARY-START(489626533996)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489626533996)
            
            //--TRIMMABLE-BOUNDARY-START(485331566700)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485331566700)
            
            //--TRIMMABLE-BOUNDARY-START(163209019500)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163209019500)
            
            //--TRIMMABLE-BOUNDARY-START(158914052204)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158914052204)
            
            //--TRIMMABLE-BOUNDARY-START(206158692460)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206158692460)
            
            //--TRIMMABLE-BOUNDARY-START(201863725164)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201863725164)
            
            //--TRIMMABLE-BOUNDARY-START(399432220780)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399432220780)
            
            //--TRIMMABLE-BOUNDARY-START(395137253484)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395137253484)
            
            //--TRIMMABLE-BOUNDARY-START(300647972972)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300647972972)
            
            //--TRIMMABLE-BOUNDARY-START(296353005676)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296353005676)
            
            //--TRIMMABLE-BOUNDARY-START(377957384300)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377957384300)
            
            //--TRIMMABLE-BOUNDARY-START(373662417004)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373662417004)
            
            //--TRIMMABLE-BOUNDARY-START(231928496236)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231928496236)
            
            //--TRIMMABLE-BOUNDARY-START(227633528940)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227633528940)
            
            //--TRIMMABLE-BOUNDARY-START(154619084908)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154619084908)
            
            //--TRIMMABLE-BOUNDARY-START(150324117612)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150324117612)
            
            //--TRIMMABLE-BOUNDARY-START(352187580524)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352187580524)
            
            //--TRIMMABLE-BOUNDARY-START(347892613228)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347892613228)
            
            //--TRIMMABLE-BOUNDARY-START(360777515116)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360777515116)
            
            //--TRIMMABLE-BOUNDARY-START(356482547820)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356482547820)
            
            //--TRIMMABLE-BOUNDARY-START(17180131436)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17180131436)
            
            //--TRIMMABLE-BOUNDARY-START(12885164140)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12885164140)
            
            //--TRIMMABLE-BOUNDARY-START(408022155372)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408022155372)
            
            //--TRIMMABLE-BOUNDARY-START(403727188076)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403727188076)
            
            //--TRIMMABLE-BOUNDARY-START(498216468588)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498216468588)
            
            //--TRIMMABLE-BOUNDARY-START(493921501292)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493921501292)
            
            //--TRIMMABLE-BOUNDARY-START(283468103788)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283468103788)
            
            //--TRIMMABLE-BOUNDARY-START(279173136492)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279173136492)
            
            //--TRIMMABLE-BOUNDARY-START(506806403180)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506806403180)
            
            //--TRIMMABLE-BOUNDARY-START(502511435884)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502511435884)
            
            //--TRIMMABLE-BOUNDARY-START(274878169196)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274878169196)
            
            //--TRIMMABLE-BOUNDARY-START(270583201900)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270583201900)
            
            //--TRIMMABLE-BOUNDARY-START(481036599404)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481036599404)
            
            //--TRIMMABLE-BOUNDARY-START(476741632108)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476741632108)
            
            //--TRIMMABLE-BOUNDARY-START(128849281132)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128849281132)
            
            //--TRIMMABLE-BOUNDARY-START(124554313836)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124554313836)
            
            //--TRIMMABLE-BOUNDARY-START(111669411948)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111669411948)
            
            //--TRIMMABLE-BOUNDARY-START(107374444652)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107374444652)
            
            //--TRIMMABLE-BOUNDARY-START(335007711340)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335007711340)
            
            //--TRIMMABLE-BOUNDARY-START(330712744044)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330712744044)
            
            //--TRIMMABLE-BOUNDARY-START(68719738988)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68719738988)
            
            //--TRIMMABLE-BOUNDARY-START(64424771692)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64424771692)
            
            //--TRIMMABLE-BOUNDARY-START(390842286188)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390842286188)
            
            //--TRIMMABLE-BOUNDARY-START(386547318892)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386547318892)
            
            //--TRIMMABLE-BOUNDARY-START(309237907564)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309237907564)
            
            //--TRIMMABLE-BOUNDARY-START(304942940268)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304942940268)
            
            //--TRIMMABLE-BOUNDARY-START(42949935212)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42949935212)
            
            //--TRIMMABLE-BOUNDARY-START(38654967916)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38654967916)
            
            //--TRIMMABLE-BOUNDARY-START(416612089964)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416612089964)
            
            //--TRIMMABLE-BOUNDARY-START(412317122668)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412317122668)
            
            //--TRIMMABLE-BOUNDARY-START(472446664812)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472446664812)
            
            //--TRIMMABLE-BOUNDARY-START(468151697516)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468151697516)
            
            //--TRIMMABLE-BOUNDARY-START(188978823276)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188978823276)
            
            //--TRIMMABLE-BOUNDARY-START(184683855980)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184683855980)
            
            //--TRIMMABLE-BOUNDARY-START(171798954092)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171798954092)
            
            //--TRIMMABLE-BOUNDARY-START(167503986796)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167503986796)
            
            //--TRIMMABLE-BOUNDARY-START(180388888684)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180388888684)
            
            //--TRIMMABLE-BOUNDARY-START(176093921388)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176093921388)
            
            //--TRIMMABLE-BOUNDARY-START(34360000620)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34360000620)
            
            //--TRIMMABLE-BOUNDARY-START(30065033324)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30065033324)
            
            //--TRIMMABLE-BOUNDARY-START(137439215724)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137439215724)
            
            //--TRIMMABLE-BOUNDARY-START(133144248428)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133144248428)
            
            //--TRIMMABLE-BOUNDARY-START(103079477356)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103079477356)
            
            //--TRIMMABLE-BOUNDARY-START(98784510060)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98784510060)
            
            //--TRIMMABLE-BOUNDARY-START(523986272364)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523986272364)
            
            //--TRIMMABLE-BOUNDARY-START(519691305068)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519691305068)
            
            //--TRIMMABLE-BOUNDARY-START(369367449708)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369367449708)
            
            //--TRIMMABLE-BOUNDARY-START(365072482412)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365072482412)
            
            //--TRIMMABLE-BOUNDARY-START(223338561644)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223338561644)
            
            //--TRIMMABLE-BOUNDARY-START(219043594348)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219043594348)
            
            //--TRIMMABLE-BOUNDARY-START(249108365420)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249108365420)
            
            //--TRIMMABLE-BOUNDARY-START(236223463532)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236223463532)
            
            //--TRIMMABLE-BOUNDARY-START(244813398124)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244813398124)
            
            //--TRIMMABLE-BOUNDARY-START(240518430828)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240518430828)
            
            //--TRIMMABLE-BOUNDARY-START(317827842156)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317827842156)
            
            //--TRIMMABLE-BOUNDARY-START(313532874860)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313532874860)
            
            //--TRIMMABLE-BOUNDARY-START(8590196844)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590196844)
            
            //--TRIMMABLE-BOUNDARY-START(4295229548)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295229548)
            
            //--TRIMMABLE-BOUNDARY-START(455266795628)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455266795628)
            
            //--TRIMMABLE-BOUNDARY-START(450971828332)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450971828332)
            
            //--TRIMMABLE-BOUNDARY-START(25770066028)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25770066028)
            
            //--TRIMMABLE-BOUNDARY-START(21475098732)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21475098732)
            
            //--TRIMMABLE-BOUNDARY-START(257698300012)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257698300012)
            
            //--TRIMMABLE-BOUNDARY-START(253403332716)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253403332716)
            
            //--TRIMMABLE-BOUNDARY-START(515396337772)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515396337772)
            
            //--TRIMMABLE-BOUNDARY-START(511101370476)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511101370476)
            
            //--TRIMMABLE-BOUNDARY-START(463856730220)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463856730220)
            
            //--TRIMMABLE-BOUNDARY-START(459561762924)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459561762924)
            
            //--TRIMMABLE-BOUNDARY-START(425202024556)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425202024556)
            
            //--TRIMMABLE-BOUNDARY-START(420907057260)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420907057260)
            
            //--TRIMMABLE-BOUNDARY-START(343597645932)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343597645932)
            
            //--TRIMMABLE-BOUNDARY-START(339302678636)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339302678636)
            
            //--TRIMMABLE-BOUNDARY-START(292058038380)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292058038380)
            
            //--TRIMMABLE-BOUNDARY-START(287763071084)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287763071084)
            
            //--TRIMMABLE-BOUNDARY-START(532576206956)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532576206956)
            
            //--TRIMMABLE-BOUNDARY-START(528281239660)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528281239660)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382252351596)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382252351596)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433791959148)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433791959148)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429496991852)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429496991852)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288234604)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266288234604)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993267308)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261993267308)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77309673580)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77309673580)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73014706284)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73014706284)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489542764)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94489542764)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194575468)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90194575468)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214748627052)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214748627052)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210453659756)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210453659756)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442381893740)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442381893740)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446676861036)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446676861036)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438086926444)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438086926444)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029150316)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146029150316)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734183020)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141734183020)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259346540)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120259346540)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964379244)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115964379244)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539869804)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51539869804)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244902508)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47244902508)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326417776748)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326417776748)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322122809452)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322122809452)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60129804396)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60129804396)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834837100)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55834837100)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899608172)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85899608172)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81604640876)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81604640876)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197568757868)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197568757868)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193273790572)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193273790572)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489626533996)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489626533996)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485331566700)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485331566700)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163209019500)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163209019500)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914052204)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158914052204)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206158692460)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206158692460)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201863725164)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201863725164)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399432220780)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399432220780)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137253484)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395137253484)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300647972972)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300647972972)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296353005676)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296353005676)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957384300)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377957384300)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373662417004)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373662417004)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231928496236)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231928496236)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227633528940)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227633528940)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619084908)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154619084908)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324117612)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150324117612)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352187580524)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352187580524)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347892613228)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347892613228)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360777515116)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360777515116)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356482547820)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356482547820)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180131436)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17180131436)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885164140)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12885164140)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408022155372)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408022155372)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403727188076)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403727188076)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498216468588)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498216468588)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493921501292)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493921501292)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283468103788)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283468103788)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279173136492)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279173136492)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506806403180)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506806403180)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502511435884)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502511435884)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274878169196)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274878169196)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270583201900)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270583201900)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481036599404)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481036599404)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476741632108)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476741632108)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849281132)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128849281132)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554313836)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124554313836)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669411948)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111669411948)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374444652)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107374444652)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335007711340)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335007711340)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330712744044)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330712744044)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68719738988)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68719738988)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424771692)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64424771692)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390842286188)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390842286188)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547318892)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386547318892)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309237907564)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309237907564)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304942940268)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304942940268)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949935212)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42949935212)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654967916)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38654967916)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416612089964)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416612089964)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412317122668)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412317122668)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472446664812)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472446664812)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468151697516)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468151697516)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188978823276)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188978823276)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184683855980)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184683855980)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171798954092)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171798954092)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167503986796)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167503986796)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180388888684)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180388888684)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176093921388)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176093921388)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360000620)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34360000620)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065033324)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30065033324)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439215724)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137439215724)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144248428)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133144248428)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079477356)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103079477356)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784510060)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98784510060)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523986272364)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523986272364)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519691305068)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519691305068)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369367449708)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369367449708)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365072482412)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365072482412)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223338561644)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223338561644)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219043594348)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219043594348)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108365420)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249108365420)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223463532)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236223463532)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813398124)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244813398124)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518430828)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240518430828)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317827842156)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317827842156)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313532874860)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313532874860)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590196844)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8590196844)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295229548)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4295229548)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455266795628)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455266795628)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450971828332)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450971828332)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770066028)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25770066028)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475098732)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21475098732)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257698300012)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257698300012)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253403332716)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253403332716)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515396337772)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515396337772)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511101370476)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511101370476)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463856730220)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463856730220)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459561762924)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459561762924)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425202024556)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425202024556)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420907057260)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420907057260)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343597645932)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343597645932)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339302678636)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339302678636)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292058038380)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292058038380)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287763071084)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287763071084)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532576206956)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532576206956)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528281239660)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528281239660)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 262252;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(382252351596),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 262252,
      "h": 382252351596,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382252351596),
//--TRIMMABLE-BOUNDARY-START(433791959148),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 262252,
      "h": 433791959148,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433791959148),
//--TRIMMABLE-BOUNDARY-START(429496991852),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 262252,
      "h": 429496991852,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429496991852),
//--TRIMMABLE-BOUNDARY-START(266288234604),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 262252,
      "h": 266288234604,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266288234604),
//--TRIMMABLE-BOUNDARY-START(261993267308),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 262252,
      "h": 261993267308,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261993267308),
//--TRIMMABLE-BOUNDARY-START(77309673580),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 262252,
      "h": 77309673580,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77309673580),
//--TRIMMABLE-BOUNDARY-START(73014706284),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 262252,
      "h": 73014706284,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73014706284),
//--TRIMMABLE-BOUNDARY-START(94489542764),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 262252,
      "h": 94489542764,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94489542764),
//--TRIMMABLE-BOUNDARY-START(90194575468),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 262252,
      "h": 90194575468,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90194575468),
//--TRIMMABLE-BOUNDARY-START(214748627052),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 262252,
      "h": 214748627052,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214748627052),
//--TRIMMABLE-BOUNDARY-START(210453659756),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 262252,
      "h": 210453659756,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210453659756),
//--TRIMMABLE-BOUNDARY-START(442381893740),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 262252,
      "h": 442381893740,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442381893740),
//--TRIMMABLE-BOUNDARY-START(446676861036),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 262252,
      "h": 446676861036,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446676861036),
//--TRIMMABLE-BOUNDARY-START(438086926444),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 262252,
      "h": 438086926444,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438086926444),
//--TRIMMABLE-BOUNDARY-START(146029150316),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 262252,
      "h": 146029150316,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146029150316),
//--TRIMMABLE-BOUNDARY-START(141734183020),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 262252,
      "h": 141734183020,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141734183020),
//--TRIMMABLE-BOUNDARY-START(120259346540),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 262252,
      "h": 120259346540,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259346540),
//--TRIMMABLE-BOUNDARY-START(115964379244),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 262252,
      "h": 115964379244,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115964379244),
//--TRIMMABLE-BOUNDARY-START(51539869804),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 262252,
      "h": 51539869804,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51539869804),
//--TRIMMABLE-BOUNDARY-START(47244902508),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 262252,
      "h": 47244902508,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47244902508),
//--TRIMMABLE-BOUNDARY-START(326417776748),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 262252,
      "h": 326417776748,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326417776748),
//--TRIMMABLE-BOUNDARY-START(322122809452),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 262252,
      "h": 322122809452,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322122809452),
//--TRIMMABLE-BOUNDARY-START(60129804396),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 262252,
      "h": 60129804396,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60129804396),
//--TRIMMABLE-BOUNDARY-START(55834837100),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 262252,
      "h": 55834837100,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55834837100),
//--TRIMMABLE-BOUNDARY-START(85899608172),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 262252,
      "h": 85899608172,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85899608172),
//--TRIMMABLE-BOUNDARY-START(81604640876),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 262252,
      "h": 81604640876,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81604640876),
//--TRIMMABLE-BOUNDARY-START(197568757868),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 262252,
      "h": 197568757868,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197568757868),
//--TRIMMABLE-BOUNDARY-START(193273790572),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 262252,
      "h": 193273790572,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193273790572),
//--TRIMMABLE-BOUNDARY-START(489626533996),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 262252,
      "h": 489626533996,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489626533996),
//--TRIMMABLE-BOUNDARY-START(485331566700),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 262252,
      "h": 485331566700,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485331566700),
//--TRIMMABLE-BOUNDARY-START(163209019500),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 262252,
      "h": 163209019500,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163209019500),
//--TRIMMABLE-BOUNDARY-START(158914052204),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 262252,
      "h": 158914052204,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158914052204),
//--TRIMMABLE-BOUNDARY-START(206158692460),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 262252,
      "h": 206158692460,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206158692460),
//--TRIMMABLE-BOUNDARY-START(201863725164),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 262252,
      "h": 201863725164,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201863725164),
//--TRIMMABLE-BOUNDARY-START(399432220780),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 262252,
      "h": 399432220780,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399432220780),
//--TRIMMABLE-BOUNDARY-START(395137253484),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 262252,
      "h": 395137253484,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395137253484),
//--TRIMMABLE-BOUNDARY-START(300647972972),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 262252,
      "h": 300647972972,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300647972972),
//--TRIMMABLE-BOUNDARY-START(296353005676),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 262252,
      "h": 296353005676,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296353005676),
//--TRIMMABLE-BOUNDARY-START(377957384300),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 262252,
      "h": 377957384300,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377957384300),
//--TRIMMABLE-BOUNDARY-START(373662417004),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 262252,
      "h": 373662417004,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373662417004),
//--TRIMMABLE-BOUNDARY-START(231928496236),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 262252,
      "h": 231928496236,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231928496236),
//--TRIMMABLE-BOUNDARY-START(227633528940),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 262252,
      "h": 227633528940,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227633528940),
//--TRIMMABLE-BOUNDARY-START(154619084908),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 262252,
      "h": 154619084908,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154619084908),
//--TRIMMABLE-BOUNDARY-START(150324117612),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 262252,
      "h": 150324117612,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150324117612),
//--TRIMMABLE-BOUNDARY-START(352187580524),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 262252,
      "h": 352187580524,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352187580524),
//--TRIMMABLE-BOUNDARY-START(347892613228),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 262252,
      "h": 347892613228,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347892613228),
//--TRIMMABLE-BOUNDARY-START(360777515116),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 262252,
      "h": 360777515116,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360777515116),
//--TRIMMABLE-BOUNDARY-START(356482547820),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 262252,
      "h": 356482547820,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356482547820),
//--TRIMMABLE-BOUNDARY-START(17180131436),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 262252,
      "h": 17180131436,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180131436),
//--TRIMMABLE-BOUNDARY-START(12885164140),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 262252,
      "h": 12885164140,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885164140),
//--TRIMMABLE-BOUNDARY-START(408022155372),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 262252,
      "h": 408022155372,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408022155372),
//--TRIMMABLE-BOUNDARY-START(403727188076),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 262252,
      "h": 403727188076,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403727188076),
//--TRIMMABLE-BOUNDARY-START(498216468588),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 262252,
      "h": 498216468588,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498216468588),
//--TRIMMABLE-BOUNDARY-START(493921501292),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 262252,
      "h": 493921501292,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493921501292),
//--TRIMMABLE-BOUNDARY-START(283468103788),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 262252,
      "h": 283468103788,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283468103788),
//--TRIMMABLE-BOUNDARY-START(279173136492),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 262252,
      "h": 279173136492,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279173136492),
//--TRIMMABLE-BOUNDARY-START(506806403180),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 262252,
      "h": 506806403180,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506806403180),
//--TRIMMABLE-BOUNDARY-START(502511435884),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 262252,
      "h": 502511435884,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502511435884),
//--TRIMMABLE-BOUNDARY-START(274878169196),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 262252,
      "h": 274878169196,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274878169196),
//--TRIMMABLE-BOUNDARY-START(270583201900),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 262252,
      "h": 270583201900,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270583201900),
//--TRIMMABLE-BOUNDARY-START(481036599404),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 262252,
      "h": 481036599404,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481036599404),
//--TRIMMABLE-BOUNDARY-START(476741632108),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 262252,
      "h": 476741632108,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476741632108),
//--TRIMMABLE-BOUNDARY-START(128849281132),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 262252,
      "h": 128849281132,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849281132),
//--TRIMMABLE-BOUNDARY-START(124554313836),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 262252,
      "h": 124554313836,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554313836),
//--TRIMMABLE-BOUNDARY-START(111669411948),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 262252,
      "h": 111669411948,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111669411948),
//--TRIMMABLE-BOUNDARY-START(107374444652),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 262252,
      "h": 107374444652,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107374444652),
//--TRIMMABLE-BOUNDARY-START(335007711340),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 262252,
      "h": 335007711340,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335007711340),
//--TRIMMABLE-BOUNDARY-START(330712744044),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 262252,
      "h": 330712744044,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330712744044),
//--TRIMMABLE-BOUNDARY-START(68719738988),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 262252,
      "h": 68719738988,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68719738988),
//--TRIMMABLE-BOUNDARY-START(64424771692),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 262252,
      "h": 64424771692,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64424771692),
//--TRIMMABLE-BOUNDARY-START(390842286188),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 262252,
      "h": 390842286188,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390842286188),
//--TRIMMABLE-BOUNDARY-START(386547318892),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 262252,
      "h": 386547318892,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386547318892),
//--TRIMMABLE-BOUNDARY-START(309237907564),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 262252,
      "h": 309237907564,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309237907564),
//--TRIMMABLE-BOUNDARY-START(304942940268),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 262252,
      "h": 304942940268,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304942940268),
//--TRIMMABLE-BOUNDARY-START(42949935212),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 262252,
      "h": 42949935212,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42949935212),
//--TRIMMABLE-BOUNDARY-START(38654967916),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 262252,
      "h": 38654967916,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38654967916),
//--TRIMMABLE-BOUNDARY-START(416612089964),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 262252,
      "h": 416612089964,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416612089964),
//--TRIMMABLE-BOUNDARY-START(412317122668),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 262252,
      "h": 412317122668,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412317122668),
//--TRIMMABLE-BOUNDARY-START(472446664812),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 262252,
      "h": 472446664812,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472446664812),
//--TRIMMABLE-BOUNDARY-START(468151697516),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 262252,
      "h": 468151697516,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468151697516),
//--TRIMMABLE-BOUNDARY-START(188978823276),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 262252,
      "h": 188978823276,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188978823276),
//--TRIMMABLE-BOUNDARY-START(184683855980),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 262252,
      "h": 184683855980,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184683855980),
//--TRIMMABLE-BOUNDARY-START(171798954092),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 262252,
      "h": 171798954092,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171798954092),
//--TRIMMABLE-BOUNDARY-START(167503986796),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 262252,
      "h": 167503986796,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167503986796),
//--TRIMMABLE-BOUNDARY-START(180388888684),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 262252,
      "h": 180388888684,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180388888684),
//--TRIMMABLE-BOUNDARY-START(176093921388),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 262252,
      "h": 176093921388,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176093921388),
//--TRIMMABLE-BOUNDARY-START(34360000620),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 262252,
      "h": 34360000620,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360000620),
//--TRIMMABLE-BOUNDARY-START(30065033324),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 262252,
      "h": 30065033324,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065033324),
//--TRIMMABLE-BOUNDARY-START(137439215724),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 262252,
      "h": 137439215724,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137439215724),
//--TRIMMABLE-BOUNDARY-START(133144248428),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 262252,
      "h": 133144248428,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133144248428),
//--TRIMMABLE-BOUNDARY-START(103079477356),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 262252,
      "h": 103079477356,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103079477356),
//--TRIMMABLE-BOUNDARY-START(98784510060),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 262252,
      "h": 98784510060,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784510060),
//--TRIMMABLE-BOUNDARY-START(523986272364),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 262252,
      "h": 523986272364,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523986272364),
//--TRIMMABLE-BOUNDARY-START(519691305068),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 262252,
      "h": 519691305068,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519691305068),
//--TRIMMABLE-BOUNDARY-START(369367449708),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 262252,
      "h": 369367449708,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369367449708),
//--TRIMMABLE-BOUNDARY-START(365072482412),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 262252,
      "h": 365072482412,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365072482412),
//--TRIMMABLE-BOUNDARY-START(223338561644),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 262252,
      "h": 223338561644,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223338561644),
//--TRIMMABLE-BOUNDARY-START(219043594348),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 262252,
      "h": 219043594348,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219043594348),
//--TRIMMABLE-BOUNDARY-START(249108365420),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 262252,
      "h": 249108365420,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249108365420),
//--TRIMMABLE-BOUNDARY-START(236223463532),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 262252,
      "h": 236223463532,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236223463532),
//--TRIMMABLE-BOUNDARY-START(244813398124),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 262252,
      "h": 244813398124,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244813398124),
//--TRIMMABLE-BOUNDARY-START(240518430828),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 262252,
      "h": 240518430828,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240518430828),
//--TRIMMABLE-BOUNDARY-START(317827842156),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 262252,
      "h": 317827842156,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317827842156),
//--TRIMMABLE-BOUNDARY-START(313532874860),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 262252,
      "h": 313532874860,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313532874860),
//--TRIMMABLE-BOUNDARY-START(8590196844),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 262252,
      "h": 8590196844,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590196844),
//--TRIMMABLE-BOUNDARY-START(4295229548),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 262252,
      "h": 4295229548,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295229548),
//--TRIMMABLE-BOUNDARY-START(455266795628),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 262252,
      "h": 455266795628,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455266795628),
//--TRIMMABLE-BOUNDARY-START(450971828332),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 262252,
      "h": 450971828332,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450971828332),
//--TRIMMABLE-BOUNDARY-START(25770066028),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 262252,
      "h": 25770066028,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770066028),
//--TRIMMABLE-BOUNDARY-START(21475098732),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 262252,
      "h": 21475098732,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475098732),
//--TRIMMABLE-BOUNDARY-START(257698300012),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 262252,
      "h": 257698300012,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257698300012),
//--TRIMMABLE-BOUNDARY-START(253403332716),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 262252,
      "h": 253403332716,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253403332716),
//--TRIMMABLE-BOUNDARY-START(515396337772),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 262252,
      "h": 515396337772,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515396337772),
//--TRIMMABLE-BOUNDARY-START(511101370476),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 262252,
      "h": 511101370476,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511101370476),
//--TRIMMABLE-BOUNDARY-START(463856730220),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 262252,
      "h": 463856730220,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463856730220),
//--TRIMMABLE-BOUNDARY-START(459561762924),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 262252,
      "h": 459561762924,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459561762924),
//--TRIMMABLE-BOUNDARY-START(425202024556),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 262252,
      "h": 425202024556,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425202024556),
//--TRIMMABLE-BOUNDARY-START(420907057260),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 262252,
      "h": 420907057260,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420907057260),
//--TRIMMABLE-BOUNDARY-START(343597645932),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 262252,
      "h": 343597645932,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343597645932),
//--TRIMMABLE-BOUNDARY-START(339302678636),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 262252,
      "h": 339302678636,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339302678636),
//--TRIMMABLE-BOUNDARY-START(292058038380),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 262252,
      "h": 292058038380,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292058038380),
//--TRIMMABLE-BOUNDARY-START(287763071084),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 262252,
      "h": 287763071084,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287763071084),
//--TRIMMABLE-BOUNDARY-START(532576206956),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 262252,
      "h": 532576206956,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532576206956),
//--TRIMMABLE-BOUNDARY-START(528281239660),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 262252,
      "h": 528281239660,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528281239660)
  ],
  "h": 262252
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Obsoletions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262252)
        
        

        //--TRIMMABLE-BOUNDARY-START(131180)
        $asm.$cls(`$snw.SN.WebProxy`, ($self) => class WebProxy extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(167503855724)
            static /*bool */ IsLocal(/*Uri*/ host)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503855724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (host.IsLoopback)
                {
                    return true;
                }
                /*string*/ let hostString = host.Host;
                return !$.$snp.SN.IPAddress.IsValid($.$$.S.String.op_Implicit(hostString)) && !hostString.includes(".");
            }
            //--TRIMMABLE-BOUNDARY-END(167503855724)
            
            //--TRIMMABLE-BOUNDARY-START(4295098476)
            /*ChangeTrackingArrayList?*/ _bypassList = null;
            //--TRIMMABLE-BOUNDARY-END(4295098476)
            
            //--TRIMMABLE-BOUNDARY-START(8590065772)
            /*Regex[]?*/ _regexBypassList = null;
            //--TRIMMABLE-BOUNDARY-END(8590065772)
            
            //--TRIMMABLE-BOUNDARY-START(25769934956)
            $ctor$1()
            {
                this.$ctor$8(null, false, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769934956);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25769934956)
            
            //--TRIMMABLE-BOUNDARY-START(68719607916)
            $ctor$11(/*Uri?*/ Address)
            {
                this.$ctor$8(Address, false, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719607916);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68719607916)
            
            //--TRIMMABLE-BOUNDARY-START(64424640620)
            $ctor$10(/*Uri?*/ Address, /*bool*/ BypassOnLocal)
            {
                this.$ctor$8(Address, BypassOnLocal, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424640620);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64424640620)
            
            //--TRIMMABLE-BOUNDARY-START(60129673324)
            $ctor$9(/*Uri?*/ Address, /*bool*/ BypassOnLocal, /*string[]?*/ BypassList)
            {
                this.$ctor$8(Address, BypassOnLocal, BypassList, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129673324);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60129673324)
            
            //--TRIMMABLE-BOUNDARY-START(55834706028)
            $ctor$8(/*Uri?*/ Address, /*bool*/ BypassOnLocal, /*string[]?*/ BypassList, /*ICredentials?*/ Credentials)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834706028);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Address = Address;
                    this.Credentials = Credentials;
                    this.BypassProxyOnLocal = BypassOnLocal;
                    if (BypassList !== null)
                    {
                        this._bypassList = new $.$snw.SN.WebProxy.ChangeTrackingArrayList().$ctor$5(BypassList);
                        this.UpdateRegexList();
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55834706028)
            
            //--TRIMMABLE-BOUNDARY-START(47244771436)
            $ctor$6(/*string*/ Host, /*int*/ Port)
            {
                this.$ctor$8($.$snw.SN.WebProxy.CreateProxyUri(Host, Port), false, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244771436);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47244771436)
            
            //--TRIMMABLE-BOUNDARY-START(51539738732)
            $ctor$7(/*string?*/ Address)
            {
                this.$ctor$8($.$snw.SN.WebProxy.CreateProxyUri(Address, null), false, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539738732);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51539738732)
            
            //--TRIMMABLE-BOUNDARY-START(42949804140)
            $ctor$5(/*string?*/ Address, /*bool*/ BypassOnLocal)
            {
                this.$ctor$8($.$snw.SN.WebProxy.CreateProxyUri(Address, null), BypassOnLocal, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949804140);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42949804140)
            
            //--TRIMMABLE-BOUNDARY-START(38654836844)
            $ctor$4(/*string?*/ Address, /*bool*/ BypassOnLocal, /*string[]?*/ BypassList)
            {
                this.$ctor$8($.$snw.SN.WebProxy.CreateProxyUri(Address, null), BypassOnLocal, BypassList, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654836844);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38654836844)
            
            //--TRIMMABLE-BOUNDARY-START(34359869548)
            $ctor$3(/*string?*/ Address, /*bool*/ BypassOnLocal, /*string[]?*/ BypassList, /*ICredentials?*/ Credentials)
            {
                this.$ctor$8($.$snw.SN.WebProxy.CreateProxyUri(Address, null), BypassOnLocal, BypassList, Credentials);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34359869548);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34359869548)
            
            //--TRIMMABLE-BOUNDARY-START(73014575212)
            /*Uri?*/ Address = null;
            //--TRIMMABLE-BOUNDARY-END(73014575212)
            
            //--TRIMMABLE-BOUNDARY-START(85899477100)
            /*bool*/ BypassProxyOnLocal = false;
            //--TRIMMABLE-BOUNDARY-END(85899477100)
            
            //--TRIMMABLE-BOUNDARY-START(81604509804)
            /*string[] */ get BypassList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259215468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._bypassList === null)
                {
                    return $.$$.S.Array.Empty($.$$.S.String);
                }
                /*var*/ let bypassList = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [this._bypassList.Count], null);
                this._bypassList.CopyTo$1(bypassList);
                return bypassList;
            }
            /*string[] */ set BypassList(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978692204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._bypassList = value !== null ? new $.$snw.SN.WebProxy.ChangeTrackingArrayList().$ctor$5(value) : null;
                this.UpdateRegexList();
            }
            //--TRIMMABLE-BOUNDARY-END(81604509804)
            
            //--TRIMMABLE-BOUNDARY-START(77309542508)
            /*ArrayList */ get BypassArrayList()
            {
                return this._bypassList ??= new $.$snw.SN.WebProxy.ChangeTrackingArrayList().$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(77309542508)
            
            //--TRIMMABLE-BOUNDARY-START(94489411692)
            /*ICredentials?*/ Credentials = null;
            //--TRIMMABLE-BOUNDARY-END(94489411692)
            
            //--TRIMMABLE-BOUNDARY-START(227633397868)
            /*bool */ get UseDefaultCredentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029019244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Credentials === $.$snp.SN.CredentialCache.DefaultCredentials;
            }
            /*bool */ set UseDefaultCredentials(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748495980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Credentials = value ? $.$snp.SN.CredentialCache.DefaultCredentials : null;
            }
            //--TRIMMABLE-BOUNDARY-END(227633397868)
            
            //--TRIMMABLE-BOUNDARY-START(158913921132)
            /*Uri? */ GetProxy(/*Uri*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913921132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(destination, "destination");
                return this.IsBypassed(destination) ? destination : this.Address;
            }
            //--TRIMMABLE-BOUNDARY-END(158913921132)
            
            //--TRIMMABLE-BOUNDARY-START(90194444396)
            static /*Uri? */ CreateProxyUri(/*string?*/ address, /*int?*/ port)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194444396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (address === null)
                {
                    return null;
                }
                if (!$.$$.S.String.Contains$2.call(address, "://", 4/*StringComparison.Ordinal*/))
                {
                    address = "http://" + $.$strNN(address);
                }
                /*var*/ let proxyUri = new $.$spu.S.Uri().$ctor$5(address);
                if ($.$$.S.Nullable$$($.$$.S.Int32).HasValue$get.call(port) && proxyUri.IsAbsoluteUri)
                {
                    proxyUri = (() =>
                    {
                        //new $.$spu.S.UriBuilder()
                        const $t1 = $.$spu.S.UriBuilder;
                        const $i1 = new $t1();
                        $i1.$ctor$7(proxyUri);
                        $i1.Port = $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(port);
                        return $i1;
                    })().Uri;
                }
                return proxyUri;
            }
            //--TRIMMABLE-BOUNDARY-END(90194444396)
            
            //--TRIMMABLE-BOUNDARY-START(223338430572)
            /*void */ UpdateRegexList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338430572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let bypassList;
                if ($.$is(this._bypassList, $.$snw.SN.WebProxy.ChangeTrackingArrayList, { set $v($v){ bypassList = $v; } }))
                {
                    /*Regex[]?*/ let regexBypassList = null;
                    if (bypassList.Count > 0)
                    {
                        regexBypassList = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$str.STR.Regex), null, [bypassList.Count], null);
                        for(/*int*/ let i = 0; i < regexBypassList.length; i++)
                        {
                            $.$$.System.Array.$WriteT1.call(regexBypassList, new $.$str.STR.Regex().$ctor$6($.$cast(bypassList.get_Item(i), $.$$.S.String), 1/*RegexOptions.IgnoreCase*/ | 512/*RegexOptions.CultureInvariant*/), i);
                        }
                    }
                    this._regexBypassList = regexBypassList;
                    bypassList.IsChanged = false;
                }
                else 
                {
                    this._regexBypassList = null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223338430572)
            
            //--TRIMMABLE-BOUNDARY-START(171798823020)
            /*bool */ IsMatchInBypassList(/*Uri*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798823020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let bypassList;
                if ($.$is(this._bypassList, $.$snw.SN.WebProxy.ChangeTrackingArrayList, { set $v($v){ bypassList = $v; } }) && bypassList.IsChanged)
                {
                    try
                    {
                        this.UpdateRegexList();
                    }
                    catch($e)
                    {
                        this._regexBypassList = null;
                    }
                }
                let regexBypassList;
                if ($.$is(this._regexBypassList, $.$typeArray($.$str.STR.Regex), { set $v($v){ regexBypassList = $v; } }))
                {
                    /*bool*/ let isDefaultPort = input.IsDefaultPort;
                    /*int*/ let lengthRequired = $.$checked($.$checked($.$checked(input.Scheme.length + 3, 1) + input.Host.length, 1) + (isDefaultPort ? 0 : $.$checked(1 + 5, 1)), 1);
                    /*int*/ let charsWritten;
                    /*Span<char>*/ let url = (lengthRequired >>> 0) <= 256 ? $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Char, 256, null) : $.$$.S.Span$$($.$$.S.Char).op_Implicit$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), null, [lengthRequired], null));
                    /*bool*/ let formatted = isDefaultPort ? $.$$.S.MemoryExtensions.TryWrite(url, `${$.$strNN(input.Scheme)}://${$.$strNN(input.Host)}`, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.S.Int32)) : $.$$.S.MemoryExtensions.TryWrite(url, `${$.$strNN(input.Scheme)}://${$.$strNN(input.Host)}:${$.$strNN((input.Port >>> 0))}`, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.S.Int32));
                    $.$$.SD.Debug.Assert$4(formatted, "formatted");
                    url = url.Slice(0, charsWritten);
                    let $i4 = 0;
                    let $arr4 = regexBypassList;
                    while ($i4 < $arr4.length)
                    {
                        let r = $arr4[$i4++];
                        if (r.IsMatch$4($.$$.S.Span$$($.$$.S.Char).op_Implicit(url)))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(171798823020)
            
            //--TRIMMABLE-BOUNDARY-START(163208888428)
            /*bool */ IsBypassed(/*Uri*/ host)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163208888428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(host, "host");
                return $.$spu.S.Uri.op_Equality(this.Address, null) || (this.BypassProxyOnLocal && $.$snw.SN.WebProxy.IsLocal(host)) || this.IsMatchInBypassList(host);
            }
            //--TRIMMABLE-BOUNDARY-END(163208888428)
            
            //--TRIMMABLE-BOUNDARY-START(30064902252)
            $ctor$2(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064902252);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064902252)
            
            //--TRIMMABLE-BOUNDARY-START(219043463276)
            /*void */ SRS$ISerializable$GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(219043463276);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219043463276)
            
            //--TRIMMABLE-BOUNDARY-START(154618953836)
            /*void */ GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154618953836);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154618953836)
            
            //--TRIMMABLE-BOUNDARY-START(150323986540)
            static /*WebProxy */ GetDefaultProxy()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150323986540);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150323986540)
            
            //--TRIMMABLE-BOUNDARY-START(196716)
            static $_ChangeTrackingArrayList;
            static get ChangeTrackingArrayList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snw.SN.WebProxy;
                return $cls.$_ChangeTrackingArrayList ??= $asm.$ncls(`$snw.SN.WebProxy.ChangeTrackingArrayList`, ($self) => class ChangeTrackingArrayList extends $.$$.SC$1.ArrayList
                {
                    //--TRIMMABLE-BOUNDARY-START(4295164012)
                    $ctor$4()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295164012);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295164012)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590131308)
                    $ctor$5(/*ICollection*/ c)
                    {
                        super.$ctor$2(c);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590131308);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590131308)
                    
                    //--TRIMMABLE-BOUNDARY-START(42949869676)
                    /*bool*/ IsChanged = false;
                    //--TRIMMABLE-BOUNDARY-END(42949869676)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014640748)
                    /*object?*/ get_Item(/*int*/ index)
                    {
                        return super.get_Item(index);
                    }
                    /*void*/ set_Item(/*int*/ index, /*object?*/ value)
                    {
                        this.IsChanged = true;
                        super.set_Item(index, value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(73014640748)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885098604)
                    /*int */ Add(/*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885098604);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.IsChanged = true;
                        return super.Add(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885098604)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180065900)
                    /*void */ AddRange(/*ICollection*/ c)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180065900);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.IsChanged = true;
                        super.AddRange(c);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180065900)
                    
                    //--TRIMMABLE-BOUNDARY-START(34359935084)
                    /*void */ Insert(/*int*/ index, /*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34359935084);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.IsChanged = true;
                        super.Insert(index, value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34359935084)
                    
                    //--TRIMMABLE-BOUNDARY-START(38654902380)
                    /*void */ InsertRange(/*int*/ index, /*ICollection*/ c)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38654902380);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.IsChanged = true;
                        super.InsertRange(index, c);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38654902380)
                    
                    //--TRIMMABLE-BOUNDARY-START(68719673452)
                    /*void */ SetRange(/*int*/ index, /*ICollection*/ c)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68719673452);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.IsChanged = true;
                        super.SetRange(index, c);
                    }
                    //--TRIMMABLE-BOUNDARY-END(68719673452)
                    
                    //--TRIMMABLE-BOUNDARY-START(47244836972)
                    /*void */ Remove(/*object?*/ obj)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47244836972);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.IsChanged = true;
                        super.Remove(obj);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47244836972)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539804268)
                    /*void */ RemoveAt(/*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51539804268);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.IsChanged = true;
                        super.RemoveAt(index);
                    }
                    //--TRIMMABLE-BOUNDARY-END(51539804268)
                    
                    //--TRIMMABLE-BOUNDARY-START(55834771564)
                    /*void */ RemoveRange(/*int*/ index, /*int*/ count)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55834771564);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.IsChanged = true;
                        super.RemoveRange(index, count);
                    }
                    //--TRIMMABLE-BOUNDARY-END(55834771564)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475033196)
                    /*void */ Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475033196);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.IsChanged = true;
                        super.Clear();
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475033196)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295164012)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$4();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295164012)
                    
                    static $h = 196716;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.SC$1.ArrayList; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73014640748),
    {
      "p": 131073,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064967788,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424706156,
        "f": 83918849
      },
      "n": "Item",
      "d": 196716,
      "h": 73014640748,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73014640748)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885098604),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Add",
      "d": 196716,
      "h": 12885098604,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885098604),
//--TRIMMABLE-BOUNDARY-START(17180065900),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 63111169
        }
      ],
      "n": "AddRange",
      "d": 196716,
      "h": 17180065900,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180065900),
//--TRIMMABLE-BOUNDARY-START(34359935084),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Insert",
      "d": 196716,
      "h": 34359935084,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34359935084),
//--TRIMMABLE-BOUNDARY-START(38654902380),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "c",
          "p": 63111169
        }
      ],
      "n": "InsertRange",
      "d": 196716,
      "h": 38654902380,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38654902380),
//--TRIMMABLE-BOUNDARY-START(68719673452),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "c",
          "p": 63111169
        }
      ],
      "n": "SetRange",
      "d": 196716,
      "h": 68719673452,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68719673452),
//--TRIMMABLE-BOUNDARY-START(47244836972),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Remove",
      "d": 196716,
      "h": 47244836972,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47244836972),
//--TRIMMABLE-BOUNDARY-START(51539804268),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "d": 196716,
      "h": 51539804268,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51539804268),
//--TRIMMABLE-BOUNDARY-START(55834771564),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "RemoveRange",
      "d": 196716,
      "h": 55834771564,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55834771564),
//--TRIMMABLE-BOUNDARY-START(21475033196),
    {
      "r": 65537,
      "n": "Clear",
      "d": 196716,
      "h": 21475033196,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475033196)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42949869676),
    {
      "t": 262145,
      "n": "IsChanged",
      "d": 196716,
      "h": 42949869676,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(42949869676)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295164012),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 196716,
      "h": 4295164012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295164012),
//--TRIMMABLE-BOUNDARY-START(8590131308),
    {
      "p": [
        {
          "n": "c",
          "p": 63111169
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 196716,
      "h": 8590131308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590131308)
  ],
  "d": 131180,
  "h": 196716
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SC$1.IList, $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable, $.$$.S.ICloneable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Net.WebProxy+ChangeTrackingArrayList`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebProxy${separator}ChangeTrackingArrayList`; }
                }, $cls, ($v) => $cls.$_ChangeTrackingArrayList = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196716)
            
            //--TRIMMABLE-BOUNDARY-START(17183408175)
            //Generated interface implemetation for System.Net.IWebProxy.GetProxy(System.Uri)
            SN$IWebProxy$GetProxy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183408175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetProxy(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17183408175)
            
            //--TRIMMABLE-BOUNDARY-START(21478375471)
            //Generated interface implemetation for System.Net.IWebProxy.IsBypassed(System.Uri)
            SN$IWebProxy$IsBypassed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478375471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsBypassed(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478375471)
            
            //--TRIMMABLE-BOUNDARY-START(12888440879)
            //Generated interface implemetation for System.Net.IWebProxy.Credentials.get
            get SN$IWebProxy$Credentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298506287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Credentials;
            }
            //--TRIMMABLE-BOUNDARY-END(12888440879)
            
            //--TRIMMABLE-BOUNDARY-START(30068310063)
            //Generated interface implemetation for System.Net.IWebProxy.Credentials.set
            set SN$IWebProxy$Credentials(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298506287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Credentials = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30068310063)
            
            //--TRIMMABLE-BOUNDARY-START(25769934956)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25769934956)
            
            static $h = 131180;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73014575212),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079346284,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180388757612,
        "f": 83886081
      },
      "n": "Address",
      "d": 131180,
      "h": 73014575212,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014575212),
//--TRIMMABLE-BOUNDARY-START(85899477100),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849150060,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197568626796,
        "f": 83886081
      },
      "n": "BypassProxyOnLocal",
      "d": 131180,
      "h": 85899477100,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899477100),
//--TRIMMABLE-BOUNDARY-START(81604509804),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259215468,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188978692204,
        "f": 83886081
      },
      "n": "BypassList",
      "d": 131180,
      "h": 81604509804,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604509804),
//--TRIMMABLE-BOUNDARY-START(77309542508),
    {
      "p": 55181313,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669280876,
        "f": 50331649
      },
      "n": "BypassArrayList",
      "d": 131180,
      "h": 77309542508,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309542508),
//--TRIMMABLE-BOUNDARY-START(94489411692),
    {
      "p": 2883631,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439084652,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206158561388,
        "f": 83886081
      },
      "n": "Credentials",
      "d": 131180,
      "h": 94489411692,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489411692),
//--TRIMMABLE-BOUNDARY-START(227633397868),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029019244,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214748495980,
        "f": 83886081
      },
      "n": "UseDefaultCredentials",
      "d": 131180,
      "h": 227633397868,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227633397868)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(167503855724),
    {
      "r": 262145,
      "p": [
        {
          "n": "host",
          "p": 1703938
        }
      ],
      "n": "IsLocal",
      "d": 131180,
      "h": 167503855724,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(167503855724),
//--TRIMMABLE-BOUNDARY-START(158913921132),
    {
      "r": 1703938,
      "p": [
        {
          "n": "destination",
          "p": 1703938
        }
      ],
      "n": "GetProxy",
      "d": 131180,
      "h": 158913921132,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158913921132),
//--TRIMMABLE-BOUNDARY-START(90194444396),
    {
      "r": 1703938,
      "p": [
        {
          "n": "address",
          "p": 1310721
        },
        {
          "n": "port",
          "p": $.$typeNullable($.$$.S.Int32).$h,
          "f": 65
        }
      ],
      "n": "CreateProxyUri",
      "d": 131180,
      "h": 90194444396,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90194444396),
//--TRIMMABLE-BOUNDARY-START(223338430572),
    {
      "r": 65537,
      "n": "UpdateRegexList",
      "d": 131180,
      "h": 223338430572,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223338430572),
//--TRIMMABLE-BOUNDARY-START(171798823020),
    {
      "r": 262145,
      "p": [
        {
          "n": "input",
          "p": 1703938
        }
      ],
      "n": "IsMatchInBypassList",
      "d": 131180,
      "h": 171798823020,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(171798823020),
//--TRIMMABLE-BOUNDARY-START(163208888428),
    {
      "r": 262145,
      "p": [
        {
          "n": "host",
          "p": 1703938
        }
      ],
      "n": "IsBypassed",
      "d": 131180,
      "h": 163208888428,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163208888428),
//--TRIMMABLE-BOUNDARY-START(154618953836),
    {
      "r": 65537,
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": "GetObjectData",
      "d": 131180,
      "h": 154618953836,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(154618953836),
//--TRIMMABLE-BOUNDARY-START(150323986540),
    {
      "r": 131180,
      "n": "GetDefaultProxy",
      "d": 131180,
      "h": 150323986540,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "WebProxy.GetDefaultProxy has been deprecated. Use the proxy selected for you by default.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150323986540)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098476),
    {
      "t": 196716,
      "n": "_bypassList",
      "d": 131180,
      "h": 4295098476,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098476),
//--TRIMMABLE-BOUNDARY-START(8590065772),
    {
      "t": $.$typeArray($.$str.STR.Regex).$h,
      "n": "_regexBypassList",
      "d": 131180,
      "h": 8590065772,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065772)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25769934956),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131180,
      "h": 25769934956,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769934956),
//--TRIMMABLE-BOUNDARY-START(68719607916),
    {
      "p": [
        {
          "n": "Address",
          "p": 1703938
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 131180,
      "h": 68719607916,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719607916),
//--TRIMMABLE-BOUNDARY-START(64424640620),
    {
      "p": [
        {
          "n": "Address",
          "p": 1703938
        },
        {
          "n": "BypassOnLocal",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 131180,
      "h": 64424640620,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424640620),
//--TRIMMABLE-BOUNDARY-START(60129673324),
    {
      "p": [
        {
          "n": "Address",
          "p": 1703938
        },
        {
          "n": "BypassOnLocal",
          "p": 262145
        },
        {
          "n": "BypassList",
          "p": $.$typeArray($.$$.S.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 131180,
      "h": 60129673324,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129673324),
//--TRIMMABLE-BOUNDARY-START(55834706028),
    {
      "p": [
        {
          "n": "Address",
          "p": 1703938
        },
        {
          "n": "BypassOnLocal",
          "p": 262145
        },
        {
          "n": "BypassList",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "Credentials",
          "p": 2883631
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 131180,
      "h": 55834706028,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834706028),
//--TRIMMABLE-BOUNDARY-START(47244771436),
    {
      "p": [
        {
          "n": "Host",
          "p": 1310721
        },
        {
          "n": "Port",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 131180,
      "h": 47244771436,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244771436),
//--TRIMMABLE-BOUNDARY-START(51539738732),
    {
      "p": [
        {
          "n": "Address",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 131180,
      "h": 51539738732,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539738732),
//--TRIMMABLE-BOUNDARY-START(42949804140),
    {
      "p": [
        {
          "n": "Address",
          "p": 1310721
        },
        {
          "n": "BypassOnLocal",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 131180,
      "h": 42949804140,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949804140),
//--TRIMMABLE-BOUNDARY-START(38654836844),
    {
      "p": [
        {
          "n": "Address",
          "p": 1310721
        },
        {
          "n": "BypassOnLocal",
          "p": 262145
        },
        {
          "n": "BypassList",
          "p": $.$typeArray($.$$.S.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 131180,
      "h": 38654836844,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654836844),
//--TRIMMABLE-BOUNDARY-START(34359869548),
    {
      "p": [
        {
          "n": "Address",
          "p": 1310721
        },
        {
          "n": "BypassOnLocal",
          "p": 262145
        },
        {
          "n": "BypassList",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "Credentials",
          "p": 2883631
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131180,
      "h": 34359869548,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359869548),
//--TRIMMABLE-BOUNDARY-START(30064902252),
    {
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131180,
      "h": 30064902252,
      "f": 16777220,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0051",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30064902252)
  ],
  "h": 131180
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$snp.SN.IWebProxy, $.$$.SRS.ISerializable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$snw.SN.WebProxy.ChangeTrackingArrayList ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebProxy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebProxy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131180)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Text.RegularExpressions"));
})();
//--TRIMMABLE-BOUNDARY-END(108)
