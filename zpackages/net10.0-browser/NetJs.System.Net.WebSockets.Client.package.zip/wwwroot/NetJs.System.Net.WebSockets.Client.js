
//--TRIMMABLE-BOUNDARY-START(105)
(async function () {
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $snwh, $snws) {
    "use strict";
    let _;
    let $YlYFki;
    
    
    
	$.$asm(
    "NetJs.System.Net.WebSockets.Client", 
    {
  "h": 105,
  "f": "System.Net.WebSockets.Client",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Net.WebSockets.Client",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Net.WebSockets.Client",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(458857)
        $asm.$cls(`$snwc.SNW.ClientWebSocketDeflateConstants`, ($self) => class ClientWebSocketDeflateConstants
        {
            //--TRIMMABLE-BOUNDARY-START(17180328041)
            /*int*/ static MaxExtensionLength = 128;
            //--TRIMMABLE-BOUNDARY-END(17180328041)
            
            //--TRIMMABLE-BOUNDARY-START(12885360745)
            /*string*/ static Extension = null;
            //--TRIMMABLE-BOUNDARY-END(12885360745)
            
            //--TRIMMABLE-BOUNDARY-START(4295426153)
            /*string*/ static ClientMaxWindowBits = null;
            //--TRIMMABLE-BOUNDARY-END(4295426153)
            
            //--TRIMMABLE-BOUNDARY-START(8590393449)
            /*string*/ static ClientNoContextTakeover = null;
            //--TRIMMABLE-BOUNDARY-END(8590393449)
            
            //--TRIMMABLE-BOUNDARY-START(21475295337)
            /*string*/ static ServerMaxWindowBits = null;
            //--TRIMMABLE-BOUNDARY-END(21475295337)
            
            //--TRIMMABLE-BOUNDARY-START(25770262633)
            /*string*/ static ServerNoContextTakeover = null;
            //--TRIMMABLE-BOUNDARY-END(25770262633)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885360745)
                    this.Extension = "permessage-deflate";
                    //--TRIMMABLE-BOUNDARY-END(12885360745)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295426153)
                    this.ClientMaxWindowBits = "client_max_window_bits";
                    //--TRIMMABLE-BOUNDARY-END(4295426153)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590393449)
                    this.ClientNoContextTakeover = "client_no_context_takeover";
                    //--TRIMMABLE-BOUNDARY-END(8590393449)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475295337)
                    this.ServerMaxWindowBits = "server_max_window_bits";
                    //--TRIMMABLE-BOUNDARY-END(21475295337)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770262633)
                    this.ServerNoContextTakeover = "server_no_context_takeover";
                    //--TRIMMABLE-BOUNDARY-END(25770262633)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 458857;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180328041),
    {
      "t": 655361,
      "n": "MaxExtensionLength",
      "d": 458857,
      "h": 17180328041,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180328041),
//--TRIMMABLE-BOUNDARY-START(12885360745),
    {
      "t": 1310721,
      "n": "Extension",
      "d": 458857,
      "h": 12885360745,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360745),
//--TRIMMABLE-BOUNDARY-START(4295426153),
    {
      "t": 1310721,
      "n": "ClientMaxWindowBits",
      "d": 458857,
      "h": 4295426153,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295426153),
//--TRIMMABLE-BOUNDARY-START(8590393449),
    {
      "t": 1310721,
      "n": "ClientNoContextTakeover",
      "d": 458857,
      "h": 8590393449,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590393449),
//--TRIMMABLE-BOUNDARY-START(21475295337),
    {
      "t": 1310721,
      "n": "ServerMaxWindowBits",
      "d": 458857,
      "h": 21475295337,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475295337),
//--TRIMMABLE-BOUNDARY-START(25770262633),
    {
      "t": 1310721,
      "n": "ServerNoContextTakeover",
      "d": 458857,
      "h": 25770262633,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770262633)
  ],
  "h": 458857
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.ClientWebSocketDeflateConstants`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}ClientWebSocketDeflateConstants`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458857)
        
        

        //--TRIMMABLE-BOUNDARY-START(524393)
        $asm.$cls(`$snwc.SNW.ClientWebSocketOptions`, ($self) => class ClientWebSocketOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295491689)
            /*bool*/ _isReadOnly = false;
            //--TRIMMABLE-BOUNDARY-END(4295491689)
            
            //--TRIMMABLE-BOUNDARY-START(12885426281)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885426281);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426281)
            
            //--TRIMMABLE-BOUNDARY-START(296353267817)
            /*void */ SetRequestHeader(/*string*/ headerName, /*string*/ headerValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353267817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(296353267817)
            
            //--TRIMMABLE-BOUNDARY-START(304943202409)
            /*bool */ get UseDefaultCredentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324379753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseDefaultCredentials(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468365929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(304943202409)
            
            //--TRIMMABLE-BOUNDARY-START(154619347049)
            /*Version */ get HttpVersion()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194837609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$snp.SN.HttpVersion.Version11;
            }
            /*Version */ set HttpVersion(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928758377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(154619347049)
            
            //--TRIMMABLE-BOUNDARY-START(158914314345)
            /*System.Net.Http.HttpVersionPolicy */ get HttpVersionPolicy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784772201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 0/*HttpVersionPolicy.RequestVersionOrLower*/;
            }
            /*System.Net.Http.HttpVersionPolicy */ set HttpVersionPolicy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518692969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(158914314345)
            
            //--TRIMMABLE-BOUNDARY-START(34360262761)
            /*System.Net.ICredentials */ get Credentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014968425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.ICredentials */ set Credentials(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748889193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360262761)
            
            //--TRIMMABLE-BOUNDARY-START(171799216233)
            /*System.Net.IWebProxy */ get Proxy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554575977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IWebProxy */ set Proxy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288496745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(171799216233)
            
            //--TRIMMABLE-BOUNDARY-START(21475360873)
            /*X509CertificateCollection */ get ClientCertificates()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245164649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*X509CertificateCollection */ set ClientCertificates(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979085417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475360873)
            
            //--TRIMMABLE-BOUNDARY-START(176094183529)
            /*System.Net.Security.RemoteCertificateValidationCallback */ get RemoteCertificateValidationCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144510569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback */ set RemoteCertificateValidationCallback(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878431337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(176094183529)
            
            //--TRIMMABLE-BOUNDARY-START(30065295465)
            /*System.Net.CookieContainer */ get Cookies()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425033833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.CookieContainer */ set Cookies(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158954601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065295465)
            
            //--TRIMMABLE-BOUNDARY-START(25770328169)
            /*bool */ get CollectHttpResponseDetails()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835099241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CollectHttpResponseDetails(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569020009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770328169)
            
            //--TRIMMABLE-BOUNDARY-START(17180393577)
            /*void */ AddSubProtocol(/*string*/ subProtocol)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180393577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._isReadOnly)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwc.S.SR.net_WebSockets_AlreadyStarted);
                }
                $.$snwc.SNW.WebSocketValidate.ValidateSubprotocol(subProtocol);
                /*List<string>*/ let subprotocols = this.RequestedSubProtocols;
                let $en1 = subprotocols.GetEnumerator();
                while ($en1.MoveNext())
                {
                    let item = $en1.Current;
                    {
                        if ($.$$.S.String.Equals$3(item, subProtocol, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            throw new $.$$.S.ArgumentException().$ctor$13($.$snwc.S.SR.Format$6($.$snwc.S.SR.net_WebSockets_NoDuplicateProtocol, subProtocol), "subProtocol");
                        }
                    }
                }
                subprotocols.Add(subProtocol);
            }
            //--TRIMMABLE-BOUNDARY-END(17180393577)
            
            //--TRIMMABLE-BOUNDARY-START(180389150825)
            /*List<string>*/ $RequestedSubProtocols = null;
            /*List<string> */ get RequestedSubProtocols()
            {
                return this.RequestedSubProtocols$ ??= new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(180389150825)
            
            //--TRIMMABLE-BOUNDARY-START(163209281641)
            /*TimeSpan */ get KeepAliveInterval()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374706793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*TimeSpan */ set KeepAliveInterval(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108627561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(163209281641)
            
            //--TRIMMABLE-BOUNDARY-START(167504248937)
            /*TimeSpan */ get KeepAliveTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964641385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*TimeSpan */ set KeepAliveTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698562153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(167504248937)
            
            //--TRIMMABLE-BOUNDARY-START(38655230057)
            /*WebSocketDeflateOptions? */ get DangerousDeflateOptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604903017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*WebSocketDeflateOptions? */ set DangerousDeflateOptions(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338823785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655230057)
            
            //--TRIMMABLE-BOUNDARY-START(292058300521)
            /*void */ SetBuffer$1(/*int*/ receiveBufferSize, /*int*/ sendBufferSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058300521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(292058300521)
            
            //--TRIMMABLE-BOUNDARY-START(287763333225)
            /*void */ SetBuffer(/*int*/ receiveBufferSize, /*int*/ sendBufferSize, /*ArraySegment<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763333225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(287763333225)
            
            //--TRIMMABLE-BOUNDARY-START(300648235113)
            /*void */ SetToReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648235113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!this._isReadOnly, "Already set");
                this._isReadOnly = true;
            }
            //--TRIMMABLE-BOUNDARY-END(300648235113)
            
            //--TRIMMABLE-BOUNDARY-START(12885426281)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885426281)
            
            static $h = 524393;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(304943202409),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324379753,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283468365929,
        "f": 83886081
      },
      "n": "UseDefaultCredentials",
      "d": 524393,
      "h": 304943202409,
      "f": 2097153,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(304943202409),
//--TRIMMABLE-BOUNDARY-START(154619347049),
    {
      "p": 190644225,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194837609,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928758377,
        "f": 83886081,
        "a": [
          {
            "t": 160169985,
            "c": 13045071873,
            "a": [
              {
                "v": "browser",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "HttpVersion",
      "d": 524393,
      "h": 154619347049,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619347049),
//--TRIMMABLE-BOUNDARY-START(158914314345),
    {
      "p": 8192053,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784772201,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518692969,
        "f": 83886081,
        "a": [
          {
            "t": 160169985,
            "c": 13045071873,
            "a": [
              {
                "v": "browser",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "HttpVersionPolicy",
      "d": 524393,
      "h": 158914314345,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914314345),
//--TRIMMABLE-BOUNDARY-START(34360262761),
    {
      "p": 2883631,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014968425,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214748889193,
        "f": 83886081
      },
      "n": "Credentials",
      "d": 524393,
      "h": 34360262761,
      "f": 2097153,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360262761),
//--TRIMMABLE-BOUNDARY-START(171799216233),
    {
      "p": 3538991,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554575977,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288496745,
        "f": 83886081
      },
      "n": "Proxy",
      "d": 524393,
      "h": 171799216233,
      "f": 2097153,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171799216233),
//--TRIMMABLE-BOUNDARY-START(21475360873),
    {
      "p": 28377118,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245164649,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188979085417,
        "f": 83886081
      },
      "n": "ClientCertificates",
      "d": 524393,
      "h": 21475360873,
      "f": 2097153,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475360873),
//--TRIMMABLE-BOUNDARY-START(176094183529),
    {
      "p": 720946,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144510569,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274878431337,
        "f": 83886081
      },
      "n": "RemoteCertificateValidationCallback",
      "d": 524393,
      "h": 176094183529,
      "f": 2097153,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176094183529),
//--TRIMMABLE-BOUNDARY-START(30065295465),
    {
      "p": 1376303,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425033833,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206158954601,
        "f": 83886081
      },
      "n": "Cookies",
      "d": 524393,
      "h": 30065295465,
      "f": 2097153,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065295465),
//--TRIMMABLE-BOUNDARY-START(25770328169),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835099241,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197569020009,
        "f": 83886081
      },
      "n": "CollectHttpResponseDetails",
      "d": 524393,
      "h": 25770328169,
      "f": 2097153,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770328169),
//--TRIMMABLE-BOUNDARY-START(180389150825),
    {
      "p": $.$$.SCG.List$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734445161,
        "f": 50331656
      },
      "n": "RequestedSubProtocols",
      "d": 524393,
      "h": 180389150825,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(180389150825),
//--TRIMMABLE-BOUNDARY-START(163209281641),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374706793,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108627561,
        "f": 83886081
      },
      "n": "KeepAliveInterval",
      "d": 524393,
      "h": 163209281641,
      "f": 2097153,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163209281641),
//--TRIMMABLE-BOUNDARY-START(167504248937),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964641385,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257698562153,
        "f": 83886081
      },
      "n": "KeepAliveTimeout",
      "d": 524393,
      "h": 167504248937,
      "f": 2097153,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167504248937),
//--TRIMMABLE-BOUNDARY-START(38655230057),
    {
      "p": 1900648,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604903017,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338823785,
        "f": 83886081
      },
      "n": "DangerousDeflateOptions",
      "d": 524393,
      "h": 38655230057,
      "f": 2097153,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655230057)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(296353267817),
    {
      "r": 65537,
      "p": [
        {
          "n": "headerName",
          "p": 1310721
        },
        {
          "n": "headerValue",
          "p": 1310721
        }
      ],
      "n": "SetRequestHeader",
      "d": 524393,
      "h": 296353267817,
      "f": 16777217,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(296353267817),
//--TRIMMABLE-BOUNDARY-START(17180393577),
    {
      "r": 65537,
      "p": [
        {
          "n": "subProtocol",
          "p": 1310721
        }
      ],
      "n": "AddSubProtocol",
      "d": 524393,
      "h": 17180393577,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180393577),
//--TRIMMABLE-BOUNDARY-START(292058300521),
    {
      "r": 65537,
      "p": [
        {
          "n": "receiveBufferSize",
          "p": 655361
        },
        {
          "n": "sendBufferSize",
          "p": 655361
        }
      ],
      "n": "SetBuffer",
      "o": "@$1",
      "d": 524393,
      "h": 292058300521,
      "f": 16777217,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(292058300521),
//--TRIMMABLE-BOUNDARY-START(287763333225),
    {
      "r": 65537,
      "p": [
        {
          "n": "receiveBufferSize",
          "p": 655361
        },
        {
          "n": "sendBufferSize",
          "p": 655361
        },
        {
          "n": "buffer",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        }
      ],
      "n": "SetBuffer",
      "d": 524393,
      "h": 287763333225,
      "f": 16777217,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(287763333225),
//--TRIMMABLE-BOUNDARY-START(300648235113),
    {
      "r": 65537,
      "n": "SetToReadOnly",
      "d": 524393,
      "h": 300648235113,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(300648235113)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295491689),
    {
      "t": 262145,
      "n": "_isReadOnly",
      "d": 524393,
      "h": 4295491689,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491689)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885426281),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524393,
      "h": 12885426281,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885426281)
  ],
  "h": 524393
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.ClientWebSocketOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}ClientWebSocketOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524393)
        
        

        //--TRIMMABLE-BOUNDARY-START(721001)
        $asm.$cls(`$snwc.SNW.WebSocketValidate`, ($self) => class WebSocketValidate
        {
            //--TRIMMABLE-BOUNDARY-START(34360459369)
            /*int*/ static MinDeflateWindowBits = 9;
            //--TRIMMABLE-BOUNDARY-END(34360459369)
            
            //--TRIMMABLE-BOUNDARY-START(30065492073)
            /*int*/ static MaxDeflateWindowBits = 15;
            //--TRIMMABLE-BOUNDARY-END(30065492073)
            
            //--TRIMMABLE-BOUNDARY-START(25770524777)
            /*int*/ static MaxControlFramePayloadLength = 123;
            //--TRIMMABLE-BOUNDARY-END(25770524777)
            
            //--TRIMMABLE-BOUNDARY-START(8590655593)
            /*int*/ static CloseStatusCodeAbort = 1006;
            //--TRIMMABLE-BOUNDARY-END(8590655593)
            
            //--TRIMMABLE-BOUNDARY-START(12885622889)
            /*int*/ static CloseStatusCodeFailedTLSHandshake = 1015;
            //--TRIMMABLE-BOUNDARY-END(12885622889)
            
            //--TRIMMABLE-BOUNDARY-START(17180590185)
            /*int*/ static InvalidCloseStatusCodesFrom = 0;
            //--TRIMMABLE-BOUNDARY-END(17180590185)
            
            //--TRIMMABLE-BOUNDARY-START(21475557481)
            /*int*/ static InvalidCloseStatusCodesTo = 999;
            //--TRIMMABLE-BOUNDARY-END(21475557481)
            
            //--TRIMMABLE-BOUNDARY-START(38655426665)
            /*SearchValues<char>*/ static s_validSubprotocolChars = null;
            //--TRIMMABLE-BOUNDARY-END(38655426665)
            
            //--TRIMMABLE-BOUNDARY-START(55835295849)
            static /*void */ ValidateSubprotocol(/*string*/ subProtocol)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentException.ThrowIfNullOrWhiteSpace(subProtocol, "subProtocol");
                /*int*/ let indexOfInvalidChar = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Char, $.$$.S.MemoryExtensions.AsSpan$4(subProtocol), $.$snwc.SNW.WebSocketValidate.s_validSubprotocolChars);
                if (indexOfInvalidChar >= 0)
                {
                    /*char*/ let invalidChar = $.$$.S.String.get_Chars.call(subProtocol, indexOfInvalidChar);
                    /*string*/ let invalidCharDescription = $.$$.S.Char.IsBetween$1(invalidChar, 33, 126) ? $.$$.S.Char.ToString.call(invalidChar) : `[${$.$strNN($.$cast(invalidChar, $.$$.S.Int32))}]`;
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snwc.S.SR.Format$5($.$snwc.S.SR.net_WebSockets_InvalidCharInProtocolString, subProtocol, invalidCharDescription), "subProtocol");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835295849)
            
            //--TRIMMABLE-BOUNDARY-START(51540328553)
            static /*void */ ValidateCloseStatus(/*WebSocketCloseStatus*/ closeStatus, /*string?*/ statusDescription)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (closeStatus === 1005/*WebSocketCloseStatus.Empty*/ && !$.$$.S.String.IsNullOrEmpty(statusDescription))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snwc.S.SR.Format$5($.$snwc.S.SR.net_WebSockets_ReasonNotNull, statusDescription, $.$box(1005/*WebSocketCloseStatus.Empty*/, $.$snws.SNW.WebSocketCloseStatus)), "statusDescription");
                }
                /*int*/ let closeStatusCode = closeStatus;
                if ((closeStatusCode >= 0/*InvalidCloseStatusCodesFrom*/ && closeStatusCode <= 999/*InvalidCloseStatusCodesTo*/) || closeStatusCode === 1006/*CloseStatusCodeAbort*/ || closeStatusCode === 1015/*CloseStatusCodeFailedTLSHandshake*/)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snwc.S.SR.Format$6($.$snwc.S.SR.net_WebSockets_InvalidCloseStatusCode, $.$box(closeStatusCode, $.$$.S.Int32)), "closeStatus");
                }
                if (!$.$$.S.String.IsNullOrEmpty(statusDescription) && $.$$.ST.Encoding.UTF8.GetMaxByteCount(statusDescription.length) > 123/*MaxControlFramePayloadLength*/ && $.$$.ST.Encoding.UTF8.GetByteCount$6(statusDescription) > 123/*MaxControlFramePayloadLength*/)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snwc.S.SR.Format$5($.$snwc.S.SR.net_WebSockets_InvalidCloseStatusDescription, statusDescription, $.$box(123/*MaxControlFramePayloadLength*/, $.$$.S.Int32)), "statusDescription");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540328553)
            
            //--TRIMMABLE-BOUNDARY-START(42950393961)
            static /*void */ ValidateArraySegment(/*ArraySegment<byte>*/ arraySegment, /*string*/ parameterName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!$.$$.S.String.IsNullOrEmpty(parameterName), "'parameterName' MUST NOT be NULL or string.Empty");
                if (arraySegment.Array === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19($.$strNN(parameterName) + "." + $.$strNN("Array"));
                }
                if (arraySegment.Offset < 0 || arraySegment.Offset > arraySegment.Array.length)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20($.$strNN(parameterName) + "." + $.$strNN("Offset"));
                }
                if (arraySegment.Count < 0 || arraySegment.Count > (((arraySegment.Array.length - arraySegment.Offset) | 0)))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20($.$strNN(parameterName) + "." + $.$strNN("Count"));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950393961)
            
            //--TRIMMABLE-BOUNDARY-START(47245361257)
            static /*void */ ValidateBuffer(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(buffer, "buffer");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, offset, "offset");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.S.Int32, offset, buffer.length, "offset");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, count, "count");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.S.Int32, count, ((buffer.length - offset) | 0), "count");
            }
            //--TRIMMABLE-BOUNDARY-END(47245361257)
            
            //--TRIMMABLE-BOUNDARY-START(4295688297)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(38655426665)
                    this.s_validSubprotocolChars = $.$$.SB.SearchValues.Create$1($.$$.S.String.op_Implicit("!#$%&'*+-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ^_`abcdefghijklmnopqrstuvwxyz|~"));
                    //--TRIMMABLE-BOUNDARY-END(38655426665)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295688297)
            
            static $h = 721001;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835295849),
    {
      "r": 65537,
      "p": [
        {
          "n": "subProtocol",
          "p": 1310721
        }
      ],
      "n": "ValidateSubprotocol",
      "d": 721001,
      "h": 55835295849,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55835295849),
//--TRIMMABLE-BOUNDARY-START(51540328553),
    {
      "r": 65537,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "statusDescription",
          "p": 1310721
        }
      ],
      "n": "ValidateCloseStatus",
      "d": 721001,
      "h": 51540328553,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51540328553),
//--TRIMMABLE-BOUNDARY-START(42950393961),
    {
      "r": 65537,
      "p": [
        {
          "n": "arraySegment",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": "ValidateArraySegment",
      "d": 721001,
      "h": 42950393961,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42950393961),
//--TRIMMABLE-BOUNDARY-START(47245361257),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ValidateBuffer",
      "d": 721001,
      "h": 47245361257,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47245361257)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360459369),
    {
      "t": 655361,
      "n": "MinDeflateWindowBits",
      "d": 721001,
      "h": 34360459369,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360459369),
//--TRIMMABLE-BOUNDARY-START(30065492073),
    {
      "t": 655361,
      "n": "MaxDeflateWindowBits",
      "d": 721001,
      "h": 30065492073,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065492073),
//--TRIMMABLE-BOUNDARY-START(25770524777),
    {
      "t": 655361,
      "n": "MaxControlFramePayloadLength",
      "d": 721001,
      "h": 25770524777,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770524777),
//--TRIMMABLE-BOUNDARY-START(8590655593),
    {
      "t": 655361,
      "n": "CloseStatusCodeAbort",
      "d": 721001,
      "h": 8590655593,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590655593),
//--TRIMMABLE-BOUNDARY-START(12885622889),
    {
      "t": 655361,
      "n": "CloseStatusCodeFailedTLSHandshake",
      "d": 721001,
      "h": 12885622889,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885622889),
//--TRIMMABLE-BOUNDARY-START(17180590185),
    {
      "t": 655361,
      "n": "InvalidCloseStatusCodesFrom",
      "d": 721001,
      "h": 17180590185,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180590185),
//--TRIMMABLE-BOUNDARY-START(21475557481),
    {
      "t": 655361,
      "n": "InvalidCloseStatusCodesTo",
      "d": 721001,
      "h": 21475557481,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21475557481),
//--TRIMMABLE-BOUNDARY-START(38655426665),
    {
      "t": $.$$.SB.SearchValues$$($.$$.S.Char).$h,
      "n": "s_validSubprotocolChars",
      "d": 721001,
      "h": 38655426665,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38655426665)
  ],
  "h": 721001
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketValidate`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketValidate`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721001)
        
        

        //--TRIMMABLE-BOUNDARY-START(65641)
        $asm.$cls(`$snwc.SN.UriScheme`, ($self) => class UriScheme
        {
            //--TRIMMABLE-BOUNDARY-START(4295032937)
            /*string*/ static File = null;
            //--TRIMMABLE-BOUNDARY-END(4295032937)
            
            //--TRIMMABLE-BOUNDARY-START(8590000233)
            /*string*/ static Ftp = null;
            //--TRIMMABLE-BOUNDARY-END(8590000233)
            
            //--TRIMMABLE-BOUNDARY-START(12884967529)
            /*string*/ static Gopher = null;
            //--TRIMMABLE-BOUNDARY-END(12884967529)
            
            //--TRIMMABLE-BOUNDARY-START(17179934825)
            /*string*/ static Http = null;
            //--TRIMMABLE-BOUNDARY-END(17179934825)
            
            //--TRIMMABLE-BOUNDARY-START(21474902121)
            /*string*/ static Https = null;
            //--TRIMMABLE-BOUNDARY-END(21474902121)
            
            //--TRIMMABLE-BOUNDARY-START(38654771305)
            /*string*/ static News = null;
            //--TRIMMABLE-BOUNDARY-END(38654771305)
            
            //--TRIMMABLE-BOUNDARY-START(30064836713)
            /*string*/ static NetPipe = null;
            //--TRIMMABLE-BOUNDARY-END(30064836713)
            
            //--TRIMMABLE-BOUNDARY-START(34359804009)
            /*string*/ static NetTcp = null;
            //--TRIMMABLE-BOUNDARY-END(34359804009)
            
            //--TRIMMABLE-BOUNDARY-START(42949738601)
            /*string*/ static Nntp = null;
            //--TRIMMABLE-BOUNDARY-END(42949738601)
            
            //--TRIMMABLE-BOUNDARY-START(25769869417)
            /*string*/ static Mailto = null;
            //--TRIMMABLE-BOUNDARY-END(25769869417)
            
            //--TRIMMABLE-BOUNDARY-START(51539673193)
            /*string*/ static Ws = null;
            //--TRIMMABLE-BOUNDARY-END(51539673193)
            
            //--TRIMMABLE-BOUNDARY-START(55834640489)
            /*string*/ static Wss = null;
            //--TRIMMABLE-BOUNDARY-END(55834640489)
            
            //--TRIMMABLE-BOUNDARY-START(47244705897)
            /*string*/ static SchemeDelimiter = null;
            //--TRIMMABLE-BOUNDARY-END(47244705897)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032937)
                    this.File = "file";
                    //--TRIMMABLE-BOUNDARY-END(4295032937)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590000233)
                    this.Ftp = "ftp";
                    //--TRIMMABLE-BOUNDARY-END(8590000233)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12884967529)
                    this.Gopher = "gopher";
                    //--TRIMMABLE-BOUNDARY-END(12884967529)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17179934825)
                    this.Http = "http";
                    //--TRIMMABLE-BOUNDARY-END(17179934825)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474902121)
                    this.Https = "https";
                    //--TRIMMABLE-BOUNDARY-END(21474902121)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654771305)
                    this.News = "news";
                    //--TRIMMABLE-BOUNDARY-END(38654771305)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30064836713)
                    this.NetPipe = "net.pipe";
                    //--TRIMMABLE-BOUNDARY-END(30064836713)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359804009)
                    this.NetTcp = "net.tcp";
                    //--TRIMMABLE-BOUNDARY-END(34359804009)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949738601)
                    this.Nntp = "nntp";
                    //--TRIMMABLE-BOUNDARY-END(42949738601)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25769869417)
                    this.Mailto = "mailto";
                    //--TRIMMABLE-BOUNDARY-END(25769869417)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539673193)
                    this.Ws = "ws";
                    //--TRIMMABLE-BOUNDARY-END(51539673193)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834640489)
                    this.Wss = "wss";
                    //--TRIMMABLE-BOUNDARY-END(55834640489)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244705897)
                    this.SchemeDelimiter = "://";
                    //--TRIMMABLE-BOUNDARY-END(47244705897)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 65641;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032937),
    {
      "t": 1310721,
      "n": "File",
      "d": 65641,
      "h": 4295032937,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295032937),
//--TRIMMABLE-BOUNDARY-START(8590000233),
    {
      "t": 1310721,
      "n": "Ftp",
      "d": 65641,
      "h": 8590000233,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590000233),
//--TRIMMABLE-BOUNDARY-START(12884967529),
    {
      "t": 1310721,
      "n": "Gopher",
      "d": 65641,
      "h": 12884967529,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12884967529),
//--TRIMMABLE-BOUNDARY-START(17179934825),
    {
      "t": 1310721,
      "n": "Http",
      "d": 65641,
      "h": 17179934825,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17179934825),
//--TRIMMABLE-BOUNDARY-START(21474902121),
    {
      "t": 1310721,
      "n": "Https",
      "d": 65641,
      "h": 21474902121,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21474902121),
//--TRIMMABLE-BOUNDARY-START(38654771305),
    {
      "t": 1310721,
      "n": "News",
      "d": 65641,
      "h": 38654771305,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654771305),
//--TRIMMABLE-BOUNDARY-START(30064836713),
    {
      "t": 1310721,
      "n": "NetPipe",
      "d": 65641,
      "h": 30064836713,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064836713),
//--TRIMMABLE-BOUNDARY-START(34359804009),
    {
      "t": 1310721,
      "n": "NetTcp",
      "d": 65641,
      "h": 34359804009,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34359804009),
//--TRIMMABLE-BOUNDARY-START(42949738601),
    {
      "t": 1310721,
      "n": "Nntp",
      "d": 65641,
      "h": 42949738601,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949738601),
//--TRIMMABLE-BOUNDARY-START(25769869417),
    {
      "t": 1310721,
      "n": "Mailto",
      "d": 65641,
      "h": 25769869417,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25769869417),
//--TRIMMABLE-BOUNDARY-START(51539673193),
    {
      "t": 1310721,
      "n": "Ws",
      "d": 65641,
      "h": 51539673193,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539673193),
//--TRIMMABLE-BOUNDARY-START(55834640489),
    {
      "t": 1310721,
      "n": "Wss",
      "d": 65641,
      "h": 55834640489,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834640489),
//--TRIMMABLE-BOUNDARY-START(47244705897),
    {
      "t": 1310721,
      "n": "SchemeDelimiter",
      "d": 65641,
      "h": 47244705897,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47244705897)
  ],
  "h": 65641
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.UriScheme`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}UriScheme`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65641)
        
        

        //--TRIMMABLE-BOUNDARY-START(786537)
        $asm.$cls(`$snwc.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(481037123689)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(481037123689)
            
            //--TRIMMABLE-BOUNDARY-START(356483072105)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(356483072105);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(356483072105)
            
            //--TRIMMABLE-BOUNDARY-START(493922025577)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(493922025577);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snwc.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(493922025577)
            
            //--TRIMMABLE-BOUNDARY-START(352188104809)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352188104809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwc.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$snwc.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(352188104809)
            
            //--TRIMMABLE-BOUNDARY-START(347893137513)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893137513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$snwc.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(347893137513)
            
            //--TRIMMABLE-BOUNDARY-START(38655492201)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655492201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwc.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38655492201)
            
            //--TRIMMABLE-BOUNDARY-START(34360524905)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwc.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34360524905)
            
            //--TRIMMABLE-BOUNDARY-START(30065557609)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065557609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwc.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30065557609)
            
            //--TRIMMABLE-BOUNDARY-START(42950459497)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950459497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$snwc.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42950459497)
            
            //--TRIMMABLE-BOUNDARY-START(21475623017)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475623017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwc.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(21475623017)
            
            //--TRIMMABLE-BOUNDARY-START(17180655721)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwc.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(17180655721)
            
            //--TRIMMABLE-BOUNDARY-START(12885688425)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snwc.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(12885688425)
            
            //--TRIMMABLE-BOUNDARY-START(25770590313)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$snwc.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590313)
            
            //--TRIMMABLE-BOUNDARY-START(476742156393)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(476742156393)
            
            //--TRIMMABLE-BOUNDARY-START(468152221801)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(468152221801)
            
            //--TRIMMABLE-BOUNDARY-START(472447189097)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343598170217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$snwc.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.Net.WebSockets.Client", $.$snwc.S.SR.$type.Assembly);
                    $.$snwc.S.SR.s_resourceManager = temp;
                }
                return $.$snwc.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(472447189097)
            
            //--TRIMMABLE-BOUNDARY-START(8590721129)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259870825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$snwc.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489627058281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$snwc.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721129)
            
            //--TRIMMABLE-BOUNDARY-START(463857254505)
            static /*string */ get net_webstatus_ConnectFailure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335008235625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to connect to the remote server";
            }
            //--TRIMMABLE-BOUNDARY-END(463857254505)
            
            //--TRIMMABLE-BOUNDARY-START(365073006697)
            static /*string */ get net_uri_NotAbsolute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439740009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This operation is not supported for a relative URI.";
            }
            //--TRIMMABLE-BOUNDARY-END(365073006697)
            
            //--TRIMMABLE-BOUNDARY-START(373662941289)
            static /*string */ get net_Websockets_AlreadyOneOutstandingOperation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619609193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "There is already one outstanding '{0}' call for this WebSocket instance. ReceiveAsync and SendAsync can be called simultaneously, but at most one outstanding operation for each of them is allowed at the same time.";
            }
            //--TRIMMABLE-BOUNDARY-END(373662941289)
            
            //--TRIMMABLE-BOUNDARY-START(51540394089)
            static /*string */ Formatnet_Websockets_AlreadyOneOutstandingOperation(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540394089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("There is already one outstanding '{0}' call for this WebSocket instance. ReceiveAsync and SendAsync can be called simultaneously, but at most one outstanding operation for each of them is allowed at the same time.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(51540394089)
            
            //--TRIMMABLE-BOUNDARY-START(459562287209)
            static /*string */ get net_WebSockets_UnsupportedPlatform()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418301033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket protocol is not supported on this platform.";
            }
            //--TRIMMABLE-BOUNDARY-END(459562287209)
            
            //--TRIMMABLE-BOUNDARY-START(369367973993)
            static /*string */ get net_WebSockets_AcceptUnsupportedProtocol()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029674601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket client request requested '{0}' protocol(s), but server is only accepting '{1}' protocol(s).";
            }
            //--TRIMMABLE-BOUNDARY-END(369367973993)
            
            //--TRIMMABLE-BOUNDARY-START(47245426793)
            static /*string */ Formatnet_WebSockets_AcceptUnsupportedProtocol(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245426793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The WebSocket client request requested '{0}' protocol(s), but server is only accepting '{1}' protocol(s).", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(47245426793)
            
            //--TRIMMABLE-BOUNDARY-START(386547843177)
            static /*string */ get net_WebSockets_ArgumentOutOfRange_TooSmall()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389412969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The argument must be a value greater than {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(386547843177)
            
            //--TRIMMABLE-BOUNDARY-START(60130328681)
            static /*string */ Formatnet_WebSockets_ArgumentOutOfRange_TooSmall(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130328681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The argument must be a value greater than {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(60130328681)
            
            //--TRIMMABLE-BOUNDARY-START(395137777769)
            static /*string */ get net_WebSockets_ConnectStatusExpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569282153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The server returned status code '{0}' when status code '{1}' was expected.";
            }
            //--TRIMMABLE-BOUNDARY-END(395137777769)
            
            //--TRIMMABLE-BOUNDARY-START(68720263273)
            static /*string */ Formatnet_WebSockets_ConnectStatusExpected(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720263273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The server returned status code '{0}' when status code '{1}' was expected.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(68720263273)
            
            //--TRIMMABLE-BOUNDARY-START(429497516137)
            static /*string */ get net_WebSockets_MissingResponseHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288758889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The server's response was missing the required header '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(429497516137)
            
            //--TRIMMABLE-BOUNDARY-START(98785034345)
            static /*string */ Formatnet_WebSockets_MissingResponseHeader(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785034345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The server's response was missing the required header '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(98785034345)
            
            //--TRIMMABLE-BOUNDARY-START(425202548841)
            static /*string */ get net_WebSockets_InvalidState_ClosedOrAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108889705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The '{0}' instance cannot be used for communication because it has been transitioned into the '{1}' state.";
            }
            //--TRIMMABLE-BOUNDARY-END(425202548841)
            
            //--TRIMMABLE-BOUNDARY-START(90195099753)
            static /*string */ Formatnet_WebSockets_InvalidState_ClosedOrAborted(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195099753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The '{0}' instance cannot be used for communication because it has been transitioned into the '{1}' state.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(90195099753)
            
            //--TRIMMABLE-BOUNDARY-START(420907581545)
            static /*string */ get net_WebSockets_InvalidState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698824297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket is in an invalid state ('{0}') for this operation. Valid states are: '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(420907581545)
            
            //--TRIMMABLE-BOUNDARY-START(94490067049)
            static /*string */ Formatnet_WebSockets_InvalidState(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490067049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The WebSocket is in an invalid state ('{0}') for this operation. Valid states are: '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(94490067049)
            
            //--TRIMMABLE-BOUNDARY-START(382252875881)
            static /*string */ get net_WebSockets_Argument_InvalidMessageType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799478377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The message type '{0}' is not allowed for the '{1}' operation. Valid message types are: '{2}, {3}'. To close the WebSocket, use the '{4}' operation instead. ";
            }
            //--TRIMMABLE-BOUNDARY-END(382252875881)
            
            //--TRIMMABLE-BOUNDARY-START(55835361385)
            static /*string */ Formatnet_WebSockets_Argument_InvalidMessageType(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4, /*object*/ arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835361385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$11("The message type '{0}' is not allowed for the '{1}' operation. Valid message types are: '{2}, {3}'. To close the WebSocket, use the '{4}' operation instead. ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ arg1, arg2, arg3, arg4, arg5 ]));
            }
            //--TRIMMABLE-BOUNDARY-END(55835361385)
            
            //--TRIMMABLE-BOUNDARY-START(403727712361)
            static /*string */ get net_WebSockets_InvalidCharInProtocolString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749151337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket protocol '{0}' is invalid because it contains the invalid character '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(403727712361)
            
            //--TRIMMABLE-BOUNDARY-START(73015230569)
            static /*string */ Formatnet_WebSockets_InvalidCharInProtocolString(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015230569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The WebSocket protocol '{0}' is invalid because it contains the invalid character '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(73015230569)
            
            //--TRIMMABLE-BOUNDARY-START(446677385321)
            static /*string */ get net_WebSockets_ReasonNotNull()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648497257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The close status description '{0}' is invalid. When using close status code '{1}' the description must be null.";
            }
            //--TRIMMABLE-BOUNDARY-END(446677385321)
            
            //--TRIMMABLE-BOUNDARY-START(107374968937)
            static /*string */ Formatnet_WebSockets_ReasonNotNull(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374968937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The close status description '{0}' is invalid. When using close status code '{1}' the description must be null.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(107374968937)
            
            //--TRIMMABLE-BOUNDARY-START(408022679657)
            static /*string */ get net_WebSockets_InvalidCloseStatusCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339085929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The close status code '{0}' is reserved for system use only and cannot be specified when calling this method.";
            }
            //--TRIMMABLE-BOUNDARY-END(408022679657)
            
            //--TRIMMABLE-BOUNDARY-START(77310197865)
            static /*string */ Formatnet_WebSockets_InvalidCloseStatusCode(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310197865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The close status code '{0}' is reserved for system use only and cannot be specified when calling this method.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(77310197865)
            
            //--TRIMMABLE-BOUNDARY-START(412317646953)
            static /*string */ get net_WebSockets_InvalidCloseStatusDescription()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929020521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The close status description '{0}' is too long. The UTF-8 representation of the status description must not be longer than {1} bytes.";
            }
            //--TRIMMABLE-BOUNDARY-END(412317646953)
            
            //--TRIMMABLE-BOUNDARY-START(81605165161)
            static /*string */ Formatnet_WebSockets_InvalidCloseStatusDescription(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605165161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The close status description '{0}' is too long. The UTF-8 representation of the status description must not be longer than {1} bytes.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(81605165161)
            
            //--TRIMMABLE-BOUNDARY-START(450972352617)
            static /*string */ get net_WebSockets_Scheme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238431849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Only Uris starting with 'ws://' or 'wss://' are supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(450972352617)
            
            //--TRIMMABLE-BOUNDARY-START(377957908585)
            static /*string */ get net_WebSockets_AlreadyStarted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209543785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket has already been started.";
            }
            //--TRIMMABLE-BOUNDARY-END(377957908585)
            
            //--TRIMMABLE-BOUNDARY-START(416612614249)
            static /*string */ get net_WebSockets_InvalidResponseHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518955113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The '{0}' header value '{1}' is invalid.";
            }
            //--TRIMMABLE-BOUNDARY-END(416612614249)
            
            //--TRIMMABLE-BOUNDARY-START(85900132457)
            static /*string */ Formatnet_WebSockets_InvalidResponseHeader(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900132457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The '{0}' header value '{1}' is invalid.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(85900132457)
            
            //--TRIMMABLE-BOUNDARY-START(438087450729)
            static /*string */ get net_WebSockets_NotConnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468628073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket is not connected.";
            }
            //--TRIMMABLE-BOUNDARY-END(438087450729)
            
            //--TRIMMABLE-BOUNDARY-START(433792483433)
            static /*string */ get net_WebSockets_NoDuplicateProtocol()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878693481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Duplicate protocols are not allowed: '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(433792483433)
            
            //--TRIMMABLE-BOUNDARY-START(103080001641)
            static /*string */ Formatnet_WebSockets_NoDuplicateProtocol(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080001641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Duplicate protocols are not allowed: '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(103080001641)
            
            //--TRIMMABLE-BOUNDARY-START(360778039401)
            static /*string */ get net_securityprotocolnotsupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849805417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The requested security protocol is not supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(360778039401)
            
            //--TRIMMABLE-BOUNDARY-START(455267319913)
            static /*string */ get net_WebSockets_ServerWindowBitsNegotiationFailure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828366441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket failed to negotiate max server window bits. The client requested {0} but the server responded with {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(455267319913)
            
            //--TRIMMABLE-BOUNDARY-START(111669936233)
            static /*string */ Formatnet_WebSockets_ServerWindowBitsNegotiationFailure(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669936233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The WebSocket failed to negotiate max server window bits. The client requested {0} but the server responded with {1}.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(111669936233)
            
            //--TRIMMABLE-BOUNDARY-START(390842810473)
            static /*string */ get net_WebSockets_ClientWindowBitsNegotiationFailure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979347561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket failed to negotiate max client window bits. The client requested {0} but the server responded with {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(390842810473)
            
            //--TRIMMABLE-BOUNDARY-START(64425295977)
            static /*string */ Formatnet_WebSockets_ClientWindowBitsNegotiationFailure(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425295977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The WebSocket failed to negotiate max client window bits. The client requested {0} but the server responded with {1}.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(64425295977)
            
            //--TRIMMABLE-BOUNDARY-START(442382418025)
            static /*string */ get net_WebSockets_OptionsIncompatibleWithCustomInvoker()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058562665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "UseDefaultCredentials, Credentials, Proxy, ClientCertificates, RemoteCertificateValidationCallback and Cookies must not be set on ClientWebSocketOptions when an HttpMessageInvoker instance is also specified. These options should be set on the HttpMessageInvoker's underlying HttpMessageHandler instead.";
            }
            //--TRIMMABLE-BOUNDARY-END(442382418025)
            
            //--TRIMMABLE-BOUNDARY-START(399432745065)
            static /*string */ get net_WebSockets_CustomInvokerRequiredForHttp2()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159216745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An HttpMessageInvoker instance must be passed to ConnectAsync when using HTTP/2.";
            }
            //--TRIMMABLE-BOUNDARY-END(399432745065)
            
            //--TRIMMABLE-BOUNDARY-START(4295753833)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295753833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(481037123689)
                    this.s_usingResourceKeys = $.$snwc.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(481037123689)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295753833)
            
            static $h = 786537;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 786537
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786537)
        
        

        //--TRIMMABLE-BOUNDARY-START(655465)
        $asm.$cls(`$snwc.SNW.WebSocketHandle`, ($self) => class WebSocketHandle extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295622761)
            /*WebSocketState*/ _state = 1;
            //--TRIMMABLE-BOUNDARY-END(4295622761)
            
            //--TRIMMABLE-BOUNDARY-START(77310066793)
            /*HttpStatusCode */ get HttpStatusCode()
            {
                return $.$cast(0, $.$snp.SN.HttpStatusCode);
            }
            //--TRIMMABLE-BOUNDARY-END(77310066793)
            
            //--TRIMMABLE-BOUNDARY-START(73015099497)
            /*IReadOnlyDictionary<string, IEnumerable<string>>?*/ HttpResponseHeaders = null;
            //--TRIMMABLE-BOUNDARY-END(73015099497)
            
            //--TRIMMABLE-BOUNDARY-START(103079870569)
            /*WebSocket?*/ WebSocket = null;
            //--TRIMMABLE-BOUNDARY-END(103079870569)
            
            //--TRIMMABLE-BOUNDARY-START(98784903273)
            /*WebSocketState */ get State()
            {
                return (this.WebSocket?.State ?? null) ?? this._state;
            }
            //--TRIMMABLE-BOUNDARY-END(98784903273)
            
            //--TRIMMABLE-BOUNDARY-START(30065426537)
            static /*ClientWebSocketOptions */ CreateDefaultOptions()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065426537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$snwc.SNW.ClientWebSocketOptions().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065426537)
            
            //--TRIMMABLE-BOUNDARY-START(34360393833)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360393833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._state = 5/*WebSocketState.Closed*/;
                this.WebSocket?.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(34360393833)
            
            //--TRIMMABLE-BOUNDARY-START(21475491945)
            /*void */ Abort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475491945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._state = 6/*WebSocketState.Aborted*/;
                this.WebSocket?.Abort();
            }
            //--TRIMMABLE-BOUNDARY-END(21475491945)
            
            //--TRIMMABLE-BOUNDARY-START(25770459241)
            /*Task */ ConnectAsync(/*Uri*/ uri, /*HttpMessageInvoker?*/ _, /*CancellationToken*/ cancellationToken, /*ClientWebSocketOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770459241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                cancellationToken.ThrowIfCancellationRequested();
                /*var*/ let ws = new $.$snwc.SNW.BrowserWebSocket().$ctor$2();
                this.WebSocket = ws;
                return ws.ConnectAsync(uri, options.RequestedSubProtocols, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(25770459241)
            
            //--TRIMMABLE-BOUNDARY-START(17180524649)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180524649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180524649)
            
            //--TRIMMABLE-BOUNDARY-START(17180524649)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180524649)
            
            static $h = 655465;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310066793),
    {
      "p": 2752559,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540263017,
        "f": 50331649
      },
      "n": "HttpStatusCode",
      "d": 655465,
      "h": 77310066793,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310066793),
//--TRIMMABLE-BOUNDARY-START(73015099497),
    {
      "p": $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.String)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950328425,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900001385,
        "f": 83886081
      },
      "n": "HttpResponseHeaders",
      "d": 655465,
      "h": 73015099497,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015099497),
//--TRIMMABLE-BOUNDARY-START(103079870569),
    {
      "p": 1572968,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720132201,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489935977,
        "f": 83886082
      },
      "n": "WebSocket",
      "d": 655465,
      "h": 103079870569,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079870569),
//--TRIMMABLE-BOUNDARY-START(98784903273),
    {
      "p": 2293864,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130197609,
        "f": 50331649
      },
      "n": "State",
      "d": 655465,
      "h": 98784903273,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784903273)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065426537),
    {
      "r": 524393,
      "n": "CreateDefaultOptions",
      "d": 655465,
      "h": 30065426537,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065426537),
//--TRIMMABLE-BOUNDARY-START(34360393833),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 655465,
      "h": 34360393833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360393833),
//--TRIMMABLE-BOUNDARY-START(21475491945),
    {
      "r": 65537,
      "n": "Abort",
      "d": 655465,
      "h": 21475491945,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475491945),
//--TRIMMABLE-BOUNDARY-START(25770459241),
    {
      "r": 178454529,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        },
        {
          "n": "_",
          "p": 7143477
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "options",
          "p": 524393
        }
      ],
      "n": "ConnectAsync",
      "d": 655465,
      "h": 25770459241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770459241)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622761),
    {
      "t": 2293864,
      "n": "_state",
      "d": 655465,
      "h": 4295622761,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622761)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180524649),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655465,
      "h": 17180524649,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180524649)
  ],
  "h": 655465
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketHandle`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketHandle`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655465)
        
        

        //--TRIMMABLE-BOUNDARY-START(131177)
        $asm.$cls(`$snwc.SNW.BrowserInterop`, ($self) => class BrowserInterop
        {
            //--TRIMMABLE-BOUNDARY-START(196713)
            static $_WebSocketJSObject;
            static get WebSocketJSObject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snwc.SNW.BrowserInterop;
                return $cls.$_WebSocketJSObject ??= $asm.$ncls(`$snwc.SNW.BrowserInterop.WebSocketJSObject`, ($self) => class WebSocketJSObject extends $.$srij.SRIJ.JSObject
                {
                    //--TRIMMABLE-BOUNDARY-START(34359935081)
                    $ctor$3(/*string*/ uri, /*string?[]?*/ subProtocols, /*IntPtr*/ responseStatusPtr)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34359935081);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.uri = uri;
                            this.subProtocols = subProtocols;
                            this.responseStatusPtr = responseStatusPtr;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34359935081)
                    
                    //--TRIMMABLE-BOUNDARY-START(154619019369)
                    /*string*/ uri = null;
                    //--TRIMMABLE-BOUNDARY-END(154619019369)
                    
                    //--TRIMMABLE-BOUNDARY-START(150324052073)
                    /*string?[]?*/ subProtocols = null;
                    //--TRIMMABLE-BOUNDARY-END(150324052073)
                    
                    //--TRIMMABLE-BOUNDARY-START(111669346409)
                    /*IntPtr*/ responseStatusPtr = 0;
                    //--TRIMMABLE-BOUNDARY-END(111669346409)
                    
                    //--TRIMMABLE-BOUNDARY-START(158913986665)
                    /*Window.WebSocket?*/ webSocket = null;
                    //--TRIMMABLE-BOUNDARY-END(158913986665)
                    
                    //--TRIMMABLE-BOUNDARY-START(103079411817)
                    /*IntPtr*/ receiveBufferPtr = 0;
                    //--TRIMMABLE-BOUNDARY-END(103079411817)
                    
                    //--TRIMMABLE-BOUNDARY-START(98784444521)
                    /*int*/ receiveBufferLen = 0;
                    //--TRIMMABLE-BOUNDARY-END(98784444521)
                    
                    //--TRIMMABLE-BOUNDARY-START(107374379113)
                    /*TaskCompletionSource?*/ receiveTask = null;
                    //--TRIMMABLE-BOUNDARY-END(107374379113)
                    
                    static $h = 196713;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSObject; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(154619019369),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899542633,
        "f": 50331649
      },
      "n": "uri",
      "d": 196713,
      "h": 154619019369,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619019369),
//--TRIMMABLE-BOUNDARY-START(150324052073),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309608041,
        "f": 50331649
      },
      "n": "subProtocols",
      "d": 196713,
      "h": 150324052073,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150324052073),
//--TRIMMABLE-BOUNDARY-START(111669346409),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719673449,
        "f": 50331649
      },
      "n": "responseStatusPtr",
      "d": 196713,
      "h": 111669346409,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669346409),
//--TRIMMABLE-BOUNDARY-START(158913986665),
    {
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489477225,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029084777,
        "f": 83886081
      },
      "n": "webSocket",
      "d": 196713,
      "h": 158913986665,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158913986665),
//--TRIMMABLE-BOUNDARY-START(103079411817),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539804265,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849215593,
        "f": 83886081
      },
      "n": "receiveBufferPtr",
      "d": 196713,
      "h": 103079411817,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079411817),
//--TRIMMABLE-BOUNDARY-START(98784444521),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949869673,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259281001,
        "f": 83886081
      },
      "n": "receiveBufferLen",
      "d": 196713,
      "h": 98784444521,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784444521),
//--TRIMMABLE-BOUNDARY-START(107374379113),
    {
      "p": 179568641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129738857,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439150185,
        "f": 83886081
      },
      "n": "receiveTask",
      "d": 196713,
      "h": 107374379113,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374379113)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34359935081),
    {
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "subProtocols",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "responseStatusPtr",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196713,
      "h": 34359935081,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359935081)
  ],
  "d": 131177,
  "h": 196713
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.BrowserInterop+WebSocketJSObject`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}BrowserInterop${separator}WebSocketJSObject`; }
                }, $cls, ($v) => $cls.$_WebSocketJSObject = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196713)
            
            //--TRIMMABLE-BOUNDARY-START(12885033065)
            static /*string? */ GetProtocol(/*JSObject?*/ webSocket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885033065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (webSocket === null || webSocket.IsDisposed)
                {
                    return null;
                }
                /*string?*/ let protocol = webSocket.GetPropertyAsString("protocol");
                return protocol;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033065)
            
            //--TRIMMABLE-BOUNDARY-START(4295098473)
            static /*WebSocketCloseStatus? */ GetCloseStatus(/*JSObject?*/ webSocket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (webSocket === null || webSocket.IsDisposed)
                {
                    return null;
                }
                if (!webSocket.HasProperty("close_status"))
                {
                    return null;
                }
                /*int*/ let status = webSocket.GetPropertyAsInt32("close_status");
                return $.$cast(status, $.$snws.SNW.WebSocketCloseStatus);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098473)
            
            //--TRIMMABLE-BOUNDARY-START(8590065769)
            static /*string? */ GetCloseStatusDescription(/*JSObject?*/ webSocket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (webSocket === null || webSocket.IsDisposed)
                {
                    return null;
                }
                /*string?*/ let description = webSocket.GetPropertyAsString("close_status_description");
                return description;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065769)
            
            //--TRIMMABLE-BOUNDARY-START(17180000361)
            static /*int */ GetReadyState(/*JSObject?*/ webSocket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (webSocket === null || webSocket.IsDisposed)
                {
                    return -1;
                }
                return $.$snwc.SNW.BrowserInterop.WebSocketGetState(webSocket);
            }
            //--TRIMMABLE-BOUNDARY-END(17180000361)
            
            //--TRIMMABLE-BOUNDARY-START(47244771433)
            static /*int */ WebSocketGetState(/*JSObject*/ webSocket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244771433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let ws = webSocket;
                if (ws.webSocket === null)
                {
                    return 0/*Window.WebSocket.CONNECTING*/;
                }
                return ws.webSocket.readyState;
            }
            //--TRIMMABLE-BOUNDARY-END(47244771433)
            
            //--TRIMMABLE-BOUNDARY-START(42949804137)
            static /*JSObject */ WebSocketCreate(/*string*/ uri, /*string?[]?*/ subProtocols, /*IntPtr*/ responseStatusPtr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$snwc.SNW.BrowserInterop.WebSocketJSObject().$ctor$3(uri, subProtocols, responseStatusPtr);
            }
            //--TRIMMABLE-BOUNDARY-END(42949804137)
            
            //--TRIMMABLE-BOUNDARY-START(25769934953)
            static /*JSObject */ UnsafeCreate(/*string*/ uri, /*string?[]?*/ subProtocols, /*MemoryHandle*/ responseHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$snwc.SNW.BrowserInterop.WebSocketCreate(uri, subProtocols, $.$$.$interop.$ptr2Addr(responseHandle.Pointer));
            }
            //--TRIMMABLE-BOUNDARY-END(25769934953)
            
            //--TRIMMABLE-BOUNDARY-START(51539738729)
            static /*Task */ WebSocketOpen(/*JSObject*/ webSocket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539738729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let ws = webSocket;
                ws.webSocket = new WebSocket(ws.uri, ws.subProtocols);
                /*var*/ let tcs = new $.$$.STT.TaskCompletionSource().$ctor$1();
                ws.webSocket.addEventListener("open",  (/**/ mevent) =>
                {
                    tcs.SetResult();
                }, null);
                /*void*/  function UpdateReceiveStatus(/*int*/ count, /*WebSocketMessageType*/ type, /*bool*/ endOfMessage)
                {
                    /*var*/ let responseStatus = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [3], null);
                    $.$$.System.Array.$WriteT1.call(responseStatus, count, 0);
                    $.$$.System.Array.$WriteT1.call(responseStatus, type, 1);
                    $.$$.System.Array.$WriteT1.call(responseStatus, endOfMessage ? 1 : 0, 2);
                    $.$$.SRI.Marshal.Copy$4(responseStatus, 0, ws.responseStatusPtr, responseStatus.length);
                }
                ws.webSocket.addEventListener("message", /*async*/  (/**/ mevent) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                    {
                        /*var*/ let evt = mevent;
                        if (typeof evt.data === "string")
                        {
                            /*var*/ let str = evt.data;
                            /*var*/ let bytes = $.$$.ST.Encoding.UTF8.GetBytes$8(str);
                            if (ws.receiveBufferPtr !== 0)
                            {
                                $.$$.SRI.Marshal.Copy(bytes, 0, ws.receiveBufferPtr, $.$$.S.Math.Min$4(bytes.length, ws.receiveBufferLen));
                                ws.receiveBufferPtr = 0;
                            }
                            UpdateReceiveStatus.call(this, bytes.length, 0/*WebSocketMessageType.Text*/, true);
                            ws.receiveTask?.SetResult();
                        }
                        else if (evt.data instanceof ArrayBuffer)
                        {
                            /*var*/ let arrayBuffer = evt.data;
                            /*var*/ let uint8Array = new Uint8Array(arrayBuffer);
                            /*var*/ let bytes = $.$$.S.Array.from(uint8Array);
                            if (ws.receiveBufferPtr !== 0)
                            {
                                $.$$.SRI.Marshal.Copy(bytes, 0, ws.receiveBufferPtr, $.$$.S.Math.Min$4(bytes.length, ws.receiveBufferLen));
                                ws.receiveBufferPtr = 0;
                                UpdateReceiveStatus.call(this, bytes.length, 1/*WebSocketMessageType.Binary*/, true);
                                ws.receiveTask?.SetResult();
                            }
                        }
                        else if (evt.data instanceof Blob)
                        {
                            /*var*/ let blob = evt.data;
                            blob.arrayBuffer().then( (/*arrayBuffer*/ arrayBuffer) =>
                            {
                                /*var*/ let uint8Array = new Uint8Array(arrayBuffer);
                                /*var*/ let bytes = $.$$.S.Array.from(uint8Array);
                                if (ws.receiveBufferPtr !== 0)
                                {
                                    $.$$.SRI.Marshal.Copy(bytes, 0, ws.receiveBufferPtr, $.$$.S.Math.Min$4(bytes.length, ws.receiveBufferLen));
                                    ws.receiveBufferPtr = 0;
                                    UpdateReceiveStatus.call(this, bytes.length, 1/*WebSocketMessageType.Binary*/, true);
                                    ws.receiveTask?.SetResult();
                                }
                            });
                        }
                        else 
                        {
                            throw null;
                        }
                    });
                }, null);
                ws.webSocket.addEventListener("error",  (/*error*/ error) =>
                {
                    tcs.TrySetException$1(new $.$$.S.Exception().$ctor$4("WebSocket error"));
                }, null);
                ws.webSocket.addEventListener("close",  (/*mevent*/ mevent) =>
                {
                    /*var*/ let closeEv = mevent;
                    ws.SetProperty$3("close_status", closeEv.code);
                    ws.SetProperty$4("closeReason", closeEv.reason);
                    ws.SetProperty("wasCleanClose", closeEv.wasClean);
                    UpdateReceiveStatus.call(this, 0, 2/*WebSocketMessageType.Close*/, true);
                }, null);
                return tcs.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(51539738729)
            
            //--TRIMMABLE-BOUNDARY-START(60129673321)
            static /*Task? */ WebSocketSend(/*JSObject*/ webSocket, /*IntPtr*/ bufferPtr, /*int*/ bufferLength, /*int*/ messageType, /*bool*/ endOfMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let ws = webSocket;
                /*var*/ let type = messageType;
                /*var*/ let data = $.$$.$interop.$addr2Ptr(bufferPtr, null);
                if (type === 0/*WebSocketMessageType.Text*/)
                {
                    /*var*/ let str = $.$$.SRI.Marshal.PtrToStringUTF8(bufferPtr, bufferLength);
                    ws.webSocket.send(str);
                    return $.$$.STT.Task.CompletedTask;
                }
                else if (type === 1/*WebSocketMessageType.Binary*/)
                {
                    /*var*/ let bytes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [bufferLength], null);
                    $.$$.SRI.Marshal.Copy$6(bufferPtr, bytes, 0, bufferLength);
                    /*var*/ let arrayBuffer = new Uint8Array(bytes);
                    ws.webSocket?.send(arrayBuffer);
                    return $.$$.STT.Task.CompletedTask;
                }
                else 
                {
                    throw new $.$$.S.NotSupportedException().$ctor$12(`Unsupported message type: ${$.$strNN($.$$.S.Enum.ToStringT($.$snws.SNW.WebSocketMessageType, $.$$.S.UInt32, type))}`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129673321)
            
            //--TRIMMABLE-BOUNDARY-START(30064902249)
            static /*Task? */ UnsafeSend(/*JSObject*/ jsWs, /*MemoryHandle*/ pinBuffer, /*int*/ length, /*WebSocketMessageType*/ messageType, /*bool*/ endOfMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$snwc.SNW.BrowserInterop.WebSocketSend(jsWs, $.$$.$interop.$ptr2Addr(pinBuffer.Pointer), length, messageType, endOfMessage);
            }
            //--TRIMMABLE-BOUNDARY-END(30064902249)
            
            //--TRIMMABLE-BOUNDARY-START(55834706025)
            static /*Task? */ WebSocketReceive(/*JSObject*/ webSocket, /*IntPtr*/ bufferPtr, /*int*/ bufferLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834706025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let ws = webSocket;
                ws.receiveBufferPtr = bufferPtr;
                ws.receiveBufferLen = bufferLength;
                ws.receiveTask = new $.$$.STT.TaskCompletionSource().$ctor$1();
                return ws.receiveTask.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(55834706025)
            
            //--TRIMMABLE-BOUNDARY-START(21474967657)
            static /*Task? */ ReceiveUnsafe(/*JSObject*/ jsWs, /*MemoryHandle*/ pinBuffer, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$snwc.SNW.BrowserInterop.WebSocketReceive(jsWs, $.$$.$interop.$ptr2Addr(pinBuffer.Pointer), length);
            }
            //--TRIMMABLE-BOUNDARY-END(21474967657)
            
            //--TRIMMABLE-BOUNDARY-START(38654836841)
            static /*Task? */ WebSocketClose(/*JSObject*/ webSocket, /*int*/ code, /*string?*/ reason, /*bool*/ waitForCloseReceived)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let ws = webSocket;
                ws.webSocket?.close(code, reason);
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(38654836841)
            
            //--TRIMMABLE-BOUNDARY-START(34359869545)
            static /*void */ WebSocketAbort(/*JSObject*/ webSocket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let ws = webSocket;
                ws.webSocket?.close(1000, null);
            }
            //--TRIMMABLE-BOUNDARY-END(34359869545)
            
            static $h = 131177;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885033065),
    {
      "r": 1310721,
      "p": [
        {
          "n": "webSocket",
          "p": 2228235
        }
      ],
      "n": "GetProtocol",
      "d": 131177,
      "h": 12885033065,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885033065),
//--TRIMMABLE-BOUNDARY-START(4295098473),
    {
      "r": $.$typeNullable($.$snws.SNW.WebSocketCloseStatus).$h,
      "p": [
        {
          "n": "webSocket",
          "p": 2228235
        }
      ],
      "n": "GetCloseStatus",
      "d": 131177,
      "h": 4295098473,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295098473),
//--TRIMMABLE-BOUNDARY-START(8590065769),
    {
      "r": 1310721,
      "p": [
        {
          "n": "webSocket",
          "p": 2228235
        }
      ],
      "n": "GetCloseStatusDescription",
      "d": 131177,
      "h": 8590065769,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590065769),
//--TRIMMABLE-BOUNDARY-START(17180000361),
    {
      "r": 655361,
      "p": [
        {
          "n": "webSocket",
          "p": 2228235
        }
      ],
      "n": "GetReadyState",
      "d": 131177,
      "h": 17180000361,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180000361),
//--TRIMMABLE-BOUNDARY-START(47244771433),
    {
      "r": 655361,
      "p": [
        {
          "n": "webSocket",
          "p": 2228235
        }
      ],
      "n": "WebSocketGetState",
      "d": 131177,
      "h": 47244771433,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.ws_get_state",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47244771433),
//--TRIMMABLE-BOUNDARY-START(42949804137),
    {
      "r": 2228235,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "subProtocols",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "responseStatusPtr",
          "p": 786433
        }
      ],
      "n": "WebSocketCreate",
      "d": 131177,
      "h": 42949804137,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.ws_wasm_create",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42949804137),
//--TRIMMABLE-BOUNDARY-START(25769934953),
    {
      "r": 2228235,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "subProtocols",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "responseHandle",
          "p": 50003969
        }
      ],
      "n": "UnsafeCreate",
      "d": 131177,
      "h": 25769934953,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769934953),
//--TRIMMABLE-BOUNDARY-START(51539738729),
    {
      "r": 178454529,
      "p": [
        {
          "n": "webSocket",
          "p": 2228235
        }
      ],
      "n": "WebSocketOpen",
      "d": 131177,
      "h": 51539738729,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.ws_wasm_open",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51539738729),
//--TRIMMABLE-BOUNDARY-START(60129673321),
    {
      "r": 178454529,
      "p": [
        {
          "n": "webSocket",
          "p": 2228235
        },
        {
          "n": "bufferPtr",
          "p": 786433
        },
        {
          "n": "bufferLength",
          "p": 655361
        },
        {
          "n": "messageType",
          "p": 655361
        },
        {
          "n": "endOfMessage",
          "p": 262145
        }
      ],
      "n": "WebSocketSend",
      "d": 131177,
      "h": 60129673321,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.ws_wasm_send",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60129673321),
//--TRIMMABLE-BOUNDARY-START(30064902249),
    {
      "r": 178454529,
      "p": [
        {
          "n": "jsWs",
          "p": 2228235
        },
        {
          "n": "pinBuffer",
          "p": 50003969
        },
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "endOfMessage",
          "p": 262145
        }
      ],
      "n": "UnsafeSend",
      "d": 131177,
      "h": 30064902249,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30064902249),
//--TRIMMABLE-BOUNDARY-START(55834706025),
    {
      "r": 178454529,
      "p": [
        {
          "n": "webSocket",
          "p": 2228235
        },
        {
          "n": "bufferPtr",
          "p": 786433
        },
        {
          "n": "bufferLength",
          "p": 655361
        }
      ],
      "n": "WebSocketReceive",
      "d": 131177,
      "h": 55834706025,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.ws_wasm_receive",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834706025),
//--TRIMMABLE-BOUNDARY-START(21474967657),
    {
      "r": 178454529,
      "p": [
        {
          "n": "jsWs",
          "p": 2228235
        },
        {
          "n": "pinBuffer",
          "p": 50003969
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "ReceiveUnsafe",
      "d": 131177,
      "h": 21474967657,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21474967657),
//--TRIMMABLE-BOUNDARY-START(38654836841),
    {
      "r": 178454529,
      "p": [
        {
          "n": "webSocket",
          "p": 2228235
        },
        {
          "n": "code",
          "p": 655361
        },
        {
          "n": "reason",
          "p": 1310721
        },
        {
          "n": "waitForCloseReceived",
          "p": 262145
        }
      ],
      "n": "WebSocketClose",
      "d": 131177,
      "h": 38654836841,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.ws_wasm_close",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38654836841),
//--TRIMMABLE-BOUNDARY-START(34359869545),
    {
      "r": 65537,
      "p": [
        {
          "n": "webSocket",
          "p": 2228235
        }
      ],
      "n": "WebSocketAbort",
      "d": 131177,
      "h": 34359869545,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.ws_wasm_abort",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34359869545)
  ],
  "h": 131177
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$snwc.SNW.BrowserInterop.WebSocketJSObject ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.BrowserInterop`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}BrowserInterop`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131177)
        
        

        //--TRIMMABLE-BOUNDARY-START(327785)
        $asm.$cls(`$snwc.SNW.ClientWebSocket`, ($self) => class ClientWebSocket extends $.$snws.SNW.WebSocket
        {
            //--TRIMMABLE-BOUNDARY-START(8590262377)
            /*InternalState*/ _state = 0;
            //--TRIMMABLE-BOUNDARY-END(8590262377)
            
            //--TRIMMABLE-BOUNDARY-START(4295295081)
            /*WebSocketHandle?*/ _innerWebSocket = null;
            //--TRIMMABLE-BOUNDARY-END(4295295081)
            
            //--TRIMMABLE-BOUNDARY-START(17180196969)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180196969);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._state = 0/*InternalState.Created*/;
                    this.Options = $.$snwc.SNW.WebSocketHandle.CreateDefaultOptions();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196969)
            
            //--TRIMMABLE-BOUNDARY-START(141734248553)
            /*ClientWebSocketOptions*/ Options = null;
            //--TRIMMABLE-BOUNDARY-END(141734248553)
            
            //--TRIMMABLE-BOUNDARY-START(34360066153)
            /*WebSocketCloseStatus? */ get CloseStatus()
            {
                return (this._innerWebSocket?.WebSocket?.CloseStatus ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(34360066153)
            
            //--TRIMMABLE-BOUNDARY-START(38655033449)
            /*string? */ get CloseStatusDescription()
            {
                return (this._innerWebSocket?.WebSocket?.CloseStatusDescription ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(38655033449)
            
            //--TRIMMABLE-BOUNDARY-START(180388954217)
            /*string? */ get SubProtocol()
            {
                return (this._innerWebSocket?.WebSocket?.SubProtocol ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(180388954217)
            
            //--TRIMMABLE-BOUNDARY-START(176093986921)
            /*WebSocketState */ get State()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259412073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._innerWebSocket !== null)
                {
                    return this._innerWebSocket.State;
                }
                switch(this._state)
                {
                    case 0/*InternalState.Created*/:
                    return 0/*WebSocketState.None*/;
                    case 1/*InternalState.Connecting*/:
                    return 1/*WebSocketState.Connecting*/;
                    default:
                    $.$$.SD.Debug.Assert$4(this._state === 3/*InternalState.Disposed*/, "_state == InternalState.Disposed");
                    return 5/*WebSocketState.Closed*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176093986921)
            
            //--TRIMMABLE-BOUNDARY-START(137439281257)
            /*System.Net.HttpStatusCode */ get HttpStatusCode()
            {
                return (this._innerWebSocket?.HttpStatusCode ?? null) ?? 0;
            }
            //--TRIMMABLE-BOUNDARY-END(137439281257)
            
            //--TRIMMABLE-BOUNDARY-START(133144313961)
            /*IReadOnlyDictionary<string, IEnumerable<string>>? */ get HttpResponseHeaders()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489608297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._innerWebSocket?.HttpResponseHeaders ?? null);
            }
            /*IReadOnlyDictionary<string, IEnumerable<string>>? */ set HttpResponseHeaders(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799019625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._innerWebSocket !== null)
                {
                    this._innerWebSocket.HttpResponseHeaders = value;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144313961)
            
            //--TRIMMABLE-BOUNDARY-START(47244968041)
            /*Task */ ConnectAsync$1(/*Uri*/ uri, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244968041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ConnectAsync(uri, null, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(47244968041)
            
            //--TRIMMABLE-BOUNDARY-START(42950000745)
            /*Task */ ConnectAsync(/*Uri*/ uri, /*HttpMessageInvoker?*/ invoker, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950000745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                if (!uri.IsAbsoluteUri)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snwc.S.SR.net_uri_NotAbsolute, "uri");
                }
                if (uri.Scheme !== "ws"/*UriScheme.Ws*/ && uri.Scheme !== "wss"/*UriScheme.Wss*/)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snwc.S.SR.net_WebSockets_Scheme, "uri");
                }
                let $switch2 = $.$$.ST$1.Interlocked.CompareExchange$14($.$snwc.SNW.ClientWebSocket.InternalState, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$snwc.SNW.ClientWebSocket.InternalState, () => this._state, ($v) => this._state = $v, null, true), 1/*InternalState.Connecting*/, 0/*InternalState.Created*/);
                switch($switch2)
                {
                    case 3/*InternalState.Disposed*/:
                    throw new $.$$.S.ObjectDisposedException().$ctor$17($.$$.S.Object.GetType.call(this).FullName);
                    case 0/*InternalState.Created*/:
                    break;
                    default:
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwc.S.SR.net_WebSockets_AlreadyStarted);
                }
                this.Options.SetToReadOnly();
                return this.ConnectAsyncCore(uri, invoker, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(42950000745)
            
            //--TRIMMABLE-BOUNDARY-START(51539935337)
            /*Task *//*async*/  ConnectAsyncCore(/*Uri*/ uri, /*HttpMessageInvoker?*/ invoker, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539935337);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._innerWebSocket = new $.$snwc.SNW.WebSocketHandle().$ctor$1();
                    try
                    {
                        let $t4, $r4;
                        ($t4 = this._innerWebSocket.ConnectAsync(uri, invoker, cancellationToken, this.Options).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    }
                    catch($e)
                    {
                        this.Dispose();
                        throw $e;
                    }
                    if ($.$$.ST$1.Interlocked.CompareExchange$14($.$snwc.SNW.ClientWebSocket.InternalState, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$snwc.SNW.ClientWebSocket.InternalState, () => this._state, ($v) => this._state = $v, null, true), 2/*InternalState.Connected*/, 1/*InternalState.Connecting*/) !== 1/*InternalState.Connecting*/)
                    {
                        $.$$.SD.Debug.Assert$4(this._state === 3/*InternalState.Disposed*/, "_state == InternalState.Disposed");
                        throw new $.$$.S.ObjectDisposedException().$ctor$17($.$$.S.Object.GetType.call(this).FullName);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51539935337)
            
            //--TRIMMABLE-BOUNDARY-START(154619150441)
            /*Task */ SendAsync(/*ArraySegment<byte>*/ buffer, /*WebSocketMessageType*/ messageType, /*bool*/ endOfMessage, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154619150441);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ConnectedWebSocket.SendAsync(buffer, messageType, endOfMessage, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619150441)
            
            //--TRIMMABLE-BOUNDARY-START(158914117737)
            /*ValueTask */ SendAsync$1(/*ReadOnlyMemory<byte>*/ buffer, /*WebSocketMessageType*/ messageType, /*bool*/ endOfMessage, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914117737);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ConnectedWebSocket.SendAsync$1(buffer, messageType, endOfMessage, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914117737)
            
            //--TRIMMABLE-BOUNDARY-START(163209085033)
            /*ValueTask */ SendAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*WebSocketMessageType*/ messageType, /*WebSocketMessageFlags*/ messageFlags, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209085033);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ConnectedWebSocket.SendAsync$2(buffer, messageType, messageFlags, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209085033)
            
            //--TRIMMABLE-BOUNDARY-START(146029215849)
            /*Task<WebSocketReceiveResult> */ ReceiveAsync(/*ArraySegment<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146029215849);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ConnectedWebSocket.ReceiveAsync(buffer, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029215849)
            
            //--TRIMMABLE-BOUNDARY-START(150324183145)
            /*ValueTask<ValueWebSocketReceiveResult> */ ReceiveAsync$1(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324183145);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ConnectedWebSocket.ReceiveAsync$1(buffer, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324183145)
            
            //--TRIMMABLE-BOUNDARY-START(25770131561)
            /*Task */ CloseAsync(/*WebSocketCloseStatus*/ closeStatus, /*string?*/ statusDescription, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770131561);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ConnectedWebSocket.CloseAsync(closeStatus, statusDescription, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770131561)
            
            //--TRIMMABLE-BOUNDARY-START(30065098857)
            /*Task */ CloseOutputAsync(/*WebSocketCloseStatus*/ closeStatus, /*string?*/ statusDescription, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065098857);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ConnectedWebSocket.CloseOutputAsync(closeStatus, statusDescription, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065098857)
            
            //--TRIMMABLE-BOUNDARY-START(55834902633)
            /*WebSocket */ get ConnectedWebSocket()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ObjectDisposedException.ThrowIf(this._state === 3/*InternalState.Disposed*/, this);
                if (this._state !== 2/*InternalState.Connected*/)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwc.S.SR.net_WebSockets_NotConnected);
                }
                $.$$.SD.Debug.Assert$4(this._innerWebSocket !== null, "_innerWebSocket != null");
                $.$$.SD.Debug.Assert$4(this._innerWebSocket.WebSocket !== null, "_innerWebSocket.WebSocket != null");
                return this._innerWebSocket.WebSocket;
            }
            //--TRIMMABLE-BOUNDARY-END(55834902633)
            
            //--TRIMMABLE-BOUNDARY-START(21475164265)
            /*void */ Abort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._state !== 3/*InternalState.Disposed*/)
                {
                    this._innerWebSocket?.Abort();
                    this.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475164265)
            
            //--TRIMMABLE-BOUNDARY-START(60129869929)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129869929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.ST$1.Interlocked.Exchange$14($.$snwc.SNW.ClientWebSocket.InternalState, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$snwc.SNW.ClientWebSocket.InternalState, () => this._state, ($v) => this._state = $v, null, true), 3/*InternalState.Disposed*/) !== 3/*InternalState.Disposed*/)
                {
                    this._innerWebSocket?.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129869929)
            
            //--TRIMMABLE-BOUNDARY-START(393321)
            static $_InternalState;
            static get InternalState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(393321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snwc.SNW.ClientWebSocket;
                return $cls.$_InternalState ??= $asm.$nstr(`$snwc.SNW.ClientWebSocket.InternalState`, ($self) => class InternalState extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static Created = 0;
                    static Connecting = 1;
                    static Connected = 2;
                    static Disposed = 3;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(393321);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "Created": 0n,
                            "Connecting": 1n,
                            "Connected": 2n,
                            "Disposed": 3n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4295360617)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295360617);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295360617)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295360617)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295360617)
                    
                    static $h = 393321;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180262505),
    {
      "t": 393321,
      "n": "Created",
      "d": 393321,
      "h": 17180262505,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180262505),
//--TRIMMABLE-BOUNDARY-START(12885295209),
    {
      "t": 393321,
      "n": "Connecting",
      "d": 393321,
      "h": 12885295209,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885295209),
//--TRIMMABLE-BOUNDARY-START(8590327913),
    {
      "t": 393321,
      "n": "Connected",
      "d": 393321,
      "h": 8590327913,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590327913),
//--TRIMMABLE-BOUNDARY-START(21475229801),
    {
      "t": 393321,
      "n": "Disposed",
      "d": 393321,
      "h": 21475229801,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475229801)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360617),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393321,
      "h": 4295360617,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360617)
  ],
  "d": 327785,
  "h": 393321
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.ClientWebSocket+InternalState`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}ClientWebSocket${separator}InternalState`; }
                }, $cls, ($v) => $cls.$_InternalState = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393321)
            
            //--TRIMMABLE-BOUNDARY-START(17180196969)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17180196969)
            
            static $h = 327785;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snws.SNW.WebSocket; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(141734248553),
    {
      "p": 524393,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669477481,
        "f": 50331649
      },
      "n": "Options",
      "d": 327785,
      "h": 141734248553,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734248553),
//--TRIMMABLE-BOUNDARY-START(34360066153),
    {
      "p": $.$typeNullable($.$snws.SNW.WebSocketCloseStatus).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719804521,
        "f": 50364417
      },
      "n": "CloseStatus",
      "d": 327785,
      "h": 34360066153,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360066153),
//--TRIMMABLE-BOUNDARY-START(38655033449),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309739113,
        "f": 50364417
      },
      "n": "CloseStatusDescription",
      "d": 327785,
      "h": 38655033449,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655033449),
//--TRIMMABLE-BOUNDARY-START(180388954217),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849346665,
        "f": 50364417
      },
      "n": "SubProtocol",
      "d": 327785,
      "h": 180388954217,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180388954217),
//--TRIMMABLE-BOUNDARY-START(176093986921),
    {
      "p": 2293864,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259412073,
        "f": 50364417
      },
      "n": "State",
      "d": 327785,
      "h": 176093986921,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(176093986921),
//--TRIMMABLE-BOUNDARY-START(137439281257),
    {
      "p": 2752559,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079542889,
        "f": 50331649
      },
      "n": "HttpStatusCode",
      "d": 327785,
      "h": 137439281257,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439281257),
//--TRIMMABLE-BOUNDARY-START(133144313961),
    {
      "p": $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.String)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489608297,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799019625,
        "f": 83886081
      },
      "n": "HttpResponseHeaders",
      "d": 327785,
      "h": 133144313961,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144313961),
//--TRIMMABLE-BOUNDARY-START(55834902633),
    {
      "p": 1572968,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899673705,
        "f": 50331650
      },
      "n": "ConnectedWebSocket",
      "d": 327785,
      "h": 55834902633,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55834902633)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47244968041),
    {
      "r": 178454529,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ConnectAsync",
      "o": "@$1",
      "d": 327785,
      "h": 47244968041,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244968041),
//--TRIMMABLE-BOUNDARY-START(42950000745),
    {
      "r": 178454529,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        },
        {
          "n": "invoker",
          "p": 7143477
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ConnectAsync",
      "d": 327785,
      "h": 42950000745,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950000745),
//--TRIMMABLE-BOUNDARY-START(51539935337),
    {
      "r": 178454529,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        },
        {
          "n": "invoker",
          "p": 7143477
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ConnectAsyncCore",
      "d": 327785,
      "h": 51539935337,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(51539935337),
//--TRIMMABLE-BOUNDARY-START(154619150441),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "SendAsync",
      "d": 327785,
      "h": 154619150441,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154619150441),
//--TRIMMABLE-BOUNDARY-START(158914117737),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "SendAsync",
      "o": "@$1",
      "d": 327785,
      "h": 158914117737,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158914117737),
//--TRIMMABLE-BOUNDARY-START(163209085033),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "messageFlags",
          "p": 2097256
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "SendAsync",
      "o": "@$2",
      "d": 327785,
      "h": 163209085033,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163209085033),
//--TRIMMABLE-BOUNDARY-START(146029215849),
    {
      "r": $.$$.STT.Task$$($.$snws.SNW.WebSocketReceiveResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReceiveAsync",
      "d": 327785,
      "h": 146029215849,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146029215849),
//--TRIMMABLE-BOUNDARY-START(150324183145),
    {
      "r": $.$$.STT.ValueTask$$($.$snws.SNW.ValueWebSocketReceiveResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReceiveAsync",
      "o": "@$1",
      "d": 327785,
      "h": 150324183145,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324183145),
//--TRIMMABLE-BOUNDARY-START(25770131561),
    {
      "r": 178454529,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "statusDescription",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CloseAsync",
      "d": 327785,
      "h": 25770131561,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770131561),
//--TRIMMABLE-BOUNDARY-START(30065098857),
    {
      "r": 178454529,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "statusDescription",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CloseOutputAsync",
      "d": 327785,
      "h": 30065098857,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065098857),
//--TRIMMABLE-BOUNDARY-START(21475164265),
    {
      "r": 65537,
      "n": "Abort",
      "d": 327785,
      "h": 21475164265,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475164265),
//--TRIMMABLE-BOUNDARY-START(60129869929),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 327785,
      "h": 60129869929,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60129869929)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590262377),
    {
      "t": 393321,
      "n": "_state",
      "d": 327785,
      "h": 8590262377,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590262377),
//--TRIMMABLE-BOUNDARY-START(4295295081),
    {
      "t": 655465,
      "n": "_innerWebSocket",
      "d": 327785,
      "h": 4295295081,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295081)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180196969),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327785,
      "h": 17180196969,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180196969)
  ],
  "h": 327785
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$snwc.SNW.ClientWebSocket.InternalState ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.ClientWebSocket`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}ClientWebSocket`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327785)
        
        

        //--TRIMMABLE-BOUNDARY-START(262249)
        $asm.$cls(`$snwc.SNW.BrowserWebSocket`, ($self) => class BrowserWebSocket extends $.$snws.SNW.WebSocket
        {
            //--TRIMMABLE-BOUNDARY-START(38654967913)
            /*object*/ _lockObject = null;
            //--TRIMMABLE-BOUNDARY-END(38654967913)
            
            //--TRIMMABLE-BOUNDARY-START(21475098729)
            /*WebSocketCloseStatus?*/ _closeStatus = null;
            //--TRIMMABLE-BOUNDARY-END(21475098729)
            
            //--TRIMMABLE-BOUNDARY-START(25770066025)
            /*string?*/ _closeStatusDescription = null;
            //--TRIMMABLE-BOUNDARY-END(25770066025)
            
            //--TRIMMABLE-BOUNDARY-START(34360000617)
            /*JSObject?*/ _innerWebSocket = null;
            //--TRIMMABLE-BOUNDARY-END(34360000617)
            
            //--TRIMMABLE-BOUNDARY-START(47244902505)
            /*WebSocketState*/ _state = 0;
            //--TRIMMABLE-BOUNDARY-END(47244902505)
            
            //--TRIMMABLE-BOUNDARY-START(17180131433)
            /*bool*/ _closeSent = false;
            //--TRIMMABLE-BOUNDARY-END(17180131433)
            
            //--TRIMMABLE-BOUNDARY-START(12885164137)
            /*bool*/ _closeReceived = false;
            //--TRIMMABLE-BOUNDARY-END(12885164137)
            
            //--TRIMMABLE-BOUNDARY-START(30065033321)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(30065033321)
            
            //--TRIMMABLE-BOUNDARY-START(4295229545)
            /*bool*/ _aborted = false;
            //--TRIMMABLE-BOUNDARY-END(4295229545)
            
            //--TRIMMABLE-BOUNDARY-START(42949935209)
            /*bool*/ _shouldAbort = false;
            //--TRIMMABLE-BOUNDARY-END(42949935209)
            
            //--TRIMMABLE-BOUNDARY-START(8590196841)
            /*bool*/ _cancelled = false;
            //--TRIMMABLE-BOUNDARY-END(8590196841)
            
            //--TRIMMABLE-BOUNDARY-START(184683855977)
            /*int[]*/ responseStatus = null;
            //--TRIMMABLE-BOUNDARY-END(184683855977)
            
            //--TRIMMABLE-BOUNDARY-START(188978823273)
            /*MemoryHandle?*/ responseStatusHandle = null;
            //--TRIMMABLE-BOUNDARY-END(188978823273)
            
            //--TRIMMABLE-BOUNDARY-START(210453659753)
            /*WebSocketState */ get State()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324117609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_lockObject)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                    {
                        if (this._innerWebSocket === null || this._disposed || this._state === 6/*WebSocketState.Aborted*/ || this._state === 5/*WebSocketState.Closed*/)
                        {
                            return this._state;
                        }
                        /*var*/ let st = $.$snwc.SNW.BrowserWebSocket.GetReadyStateLocked(this._innerWebSocket);
                        if (st === 5/*WebSocketState.Closed*/ || st === 3/*WebSocketState.CloseSent*/)
                        {
                            if (this._closeReceived && this._closeSent)
                            {
                                st = 5/*WebSocketState.Closed*/;
                            }
                            else if (this._closeReceived && !this._closeSent)
                            {
                                st = 4/*WebSocketState.CloseReceived*/;
                            }
                            else if (!this._closeReceived && this._closeSent)
                            {
                                st = 3/*WebSocketState.CloseSent*/;
                            }
                        }
                        return this.FastState = st;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._lockObject)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(210453659753)
            
            //--TRIMMABLE-BOUNDARY-START(111669411945)
            /*WebSocketState */ get FastState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734183017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_lockObject)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                    {
                        return this._state;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._lockObject)
                }
            }
            /*WebSocketState */ set FastState(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158692457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_lockObject)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                    {
                        this._state = value;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._lockObject)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669411945)
            
            //--TRIMMABLE-BOUNDARY-START(81604640873)
            /*WebSocketCloseStatus? */ get CloseStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554313833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_lockObject)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                    {
                        if (this._closeStatus !== null)
                        {
                            return this._closeStatus;
                        }
                        if (this._disposed || this._aborted || this._cancelled)
                        {
                            return null;
                        }
                        return this.GetCloseStatusLocked();
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._lockObject)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604640873)
            
            //--TRIMMABLE-BOUNDARY-START(85899608169)
            /*string? */ get CloseStatusDescription()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144248425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_lockObject)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                    {
                        if (this._closeStatusDescription !== null)
                        {
                            return this._closeStatusDescription;
                        }
                        if (this._disposed || this._aborted || this._cancelled)
                        {
                            return null;
                        }
                        return this.GetCloseStatusDescriptionLocked();
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._lockObject)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899608169)
            
            //--TRIMMABLE-BOUNDARY-START(214748627049)
            /*string? */ get SubProtocol()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914052201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                //lock(_lockObject)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                    {
                        if (this._innerWebSocket === null)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwc.S.SR.net_WebSockets_NotConnected);
                        }
                        return $.$snwc.SNW.BrowserInterop.GetProtocol(this._innerWebSocket);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._lockObject)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214748627049)
            
            //--TRIMMABLE-BOUNDARY-START(90194575465)
            /*Task */ ConnectAsync(/*Uri*/ uri, /*List<string>?*/ requestedSubProtocols, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194575465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AbortIfCancelationRequested(cancellationToken);
                //lock(_lockObject)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                    {
                        this.ThrowIfDisposed();
                        if (this.FastState !== 0/*WebSocketState.None*/)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwc.S.SR.net_WebSockets_AlreadyStarted);
                        }
                        this.FastState = 1/*WebSocketState.Connecting*/;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._lockObject)
                }
                this.CreateCore(uri, requestedSubProtocols);
                return this.ConnectAsyncCore(cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(90194575465)
            
            //--TRIMMABLE-BOUNDARY-START(193273790569)
            /*Task */ SendAsync(/*ArraySegment<byte>*/ buffer, /*WebSocketMessageType*/ messageType, /*bool*/ endOfMessage, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273790569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (messageType !== 1/*WebSocketMessageType.Binary*/ && messageType !== 0/*WebSocketMessageType.Text*/)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snwc.S.SR.Format$7($.$snwc.S.SR.net_WebSockets_Argument_InvalidMessageType, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$box(messageType, $.$snws.SNW.WebSocketMessageType), "SendAsync", $.$box(1/*WebSocketMessageType.Binary*/, $.$snws.SNW.WebSocketMessageType), $.$box(0/*WebSocketMessageType.Text*/, $.$snws.SNW.WebSocketMessageType), "CloseOutputAsync" ], null, null)), "messageType");
                }
                $.$snwc.SNW.WebSocketValidate.ValidateArraySegment(buffer, "buffer");
                this.ThrowIfDisposed();
                return this.SendAsyncCore(buffer, messageType, endOfMessage, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(193273790569)
            
            //--TRIMMABLE-BOUNDARY-START(176093921385)
            /*Task<WebSocketReceiveResult> */ ReceiveAsync(/*ArraySegment<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093921385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$snwc.SNW.WebSocketValidate.ValidateArraySegment(buffer, "buffer");
                this.ThrowIfDisposed();
                return this.ReceiveAsyncCore(buffer, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(176093921385)
            
            //--TRIMMABLE-BOUNDARY-START(77309673577)
            /*Task */ CloseOutputAsync(/*WebSocketCloseStatus*/ closeStatus, /*string?*/ statusDescription, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309673577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$snwc.SNW.WebSocketValidate.ValidateCloseStatus(closeStatus, statusDescription);
                this.ThrowIfDisposed();
                return this.CloseAsyncCore(closeStatus, statusDescription, false, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(77309673577)
            
            //--TRIMMABLE-BOUNDARY-START(68719738985)
            /*Task */ CloseAsync(/*WebSocketCloseStatus*/ closeStatus, /*string?*/ statusDescription, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719738985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$snwc.SNW.WebSocketValidate.ValidateCloseStatus(closeStatus, statusDescription);
                this.ThrowIfDisposed();
                return this.CloseAsyncCore(closeStatus, statusDescription, true, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(68719738985)
            
            //--TRIMMABLE-BOUNDARY-START(55834837097)
            /*void */ Abort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_lockObject)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                    {
                        if (this._disposed || this._aborted)
                        {
                            return;
                        }
                        /*var*/ let fastState = this.FastState;
                        if (fastState === 5/*WebSocketState.Closed*/ || fastState === 6/*WebSocketState.Aborted*/)
                        {
                            return;
                        }
                        this.FastState = 6/*WebSocketState.Aborted*/;
                        this._aborted = true;
                        $.$snwc.SNW.BrowserInterop.WebSocketAbort(this._innerWebSocket);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._lockObject)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834837097)
            
            //--TRIMMABLE-BOUNDARY-START(107374444649)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374444649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*WebSocketState*/ let state;
                //lock(_lockObject)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        this._disposed = true;
                        state = this.State;
                        if (state < 5/*WebSocketState.Closed*/ && state !== 0/*WebSocketState.None*/)
                        {
                            this._shouldAbort = true;
                            this.FastState = 6/*WebSocketState.Aborted*/;
                        }
                        else if (state !== 6/*WebSocketState.Aborted*/)
                        {
                            this.FastState = 5/*WebSocketState.Closed*/;
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._lockObject)
                }
                /*static void*/  function Cleanup(/*object?*/ _state)
                {
                    /*var*/ let self = $.$cast(_state, $.$snwc.SNW.BrowserWebSocket);
                    /*var*/ let state = self.State;
                    //lock(self._lockObject)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(self._lockObject)
                        {
                            if (self._shouldAbort && !self._aborted)
                            {
                                self._aborted = true;
                                self._shouldAbort = false;
                                $.$snwc.SNW.BrowserInterop.WebSocketAbort(self._innerWebSocket);
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(self._lockObject)
                    }
                    self._innerWebSocket?.Dispose();
                    self.responseStatusHandle?.Dispose();
                }
                Cleanup(this);
            }
            //--TRIMMABLE-BOUNDARY-END(107374444649)
            
            //--TRIMMABLE-BOUNDARY-START(219043594345)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043594345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_lockObject)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                    {
                        $.$$.S.ObjectDisposedException.ThrowIf(this._disposed, this);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._lockObject)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219043594345)
            
            //--TRIMMABLE-BOUNDARY-START(60129804393)
            /*void */ AbortIfCancelationRequested(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129804393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (cancellationToken.IsCancellationRequested)
                {
                    //lock(_lockObject)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                        {
                            this.Abort();
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this._lockObject)
                    }
                    cancellationToken.ThrowIfCancellationRequested();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129804393)
            
            //--TRIMMABLE-BOUNDARY-START(103079477353)
            /*void */ CreateCore(/*Uri*/ uri, /*List<string>?*/ requestedSubProtocols)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079477353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    /*string[]?*/ let subProtocols = (requestedSubProtocols?.ToArray() ?? null);
                    /*Memory<int>*/ let responseMemory = new ($.$$.S.Memory$$($.$$.S.Int32))().$ctor$8(this.responseStatus);
                    this.responseStatusHandle = responseMemory.Pin();
                    this._innerWebSocket = $.$snwc.SNW.BrowserInterop.UnsafeCreate(uri.ToString(), subProtocols, $.$$.S.Nullable$$($.$$.SB.MemoryHandle).Value$get.call(this.responseStatusHandle));
                }
                catch($e)
                {
                    this.Dispose();
                    throw $e;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079477353)
            
            //--TRIMMABLE-BOUNDARY-START(94489542761)
            /*Task *//*async*/  ConnectAsyncCore(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489542761);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*Task*/ let openTask;
                    //lock(_lockObject)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                        {
                            if (this._aborted)
                            {
                                this.FastState = 5/*WebSocketState.Closed*/;
                                throw new $.$snws.SNW.WebSocketException().$ctor$30(2/*WebSocketError.Faulted*/, $.$snwc.S.SR.net_webstatus_ConnectFailure);
                            }
                            this.ThrowIfDisposed();
                            openTask = $.$snwc.SNW.BrowserInterop.WebSocketOpen(this._innerWebSocket);
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this._lockObject)
                    }
                    try
                    {
                        let $t1, $r1;
                        ($t1 = this.CancellationHelper(openTask, cancellationToken, 1/*WebSocketState.Connecting*/).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        //lock(_lockObject)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                            {
                                /*WebSocketState*/ let state = this.State;
                                if (state === 1/*WebSocketState.Connecting*/)
                                {
                                    this.FastState = 2/*WebSocketState.Open*/;
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit(this._lockObject)
                        }
                    }
                    catch($e)
                    {
                        if ($e instanceof $.$$.S.OperationCanceledException)
                        {
                            let ex = $e;
                            //lock(_lockObject)
                            try
                            {
                                $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                                {
                                    this.FastState = 5/*WebSocketState.Closed*/;
                                    if (this._aborted)
                                    {
                                        throw new $.$snws.SNW.WebSocketException().$ctor$29(2/*WebSocketError.Faulted*/, $.$snwc.S.SR.net_webstatus_ConnectFailure, ex);
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.ST$1.Monitor.Exit(this._lockObject)
                            }
                            throw ex;
                        }
                        else if ($e instanceof $.$$.S.Exception)
                        {
                            //lock(_lockObject)
                            try
                            {
                                $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                                {
                                    this.FastState = 5/*WebSocketState.Closed*/;
                                }
                            }
                            finally
                            {
                                $.$$.ST$1.Monitor.Exit(this._lockObject)
                            }
                            this.Dispose();
                            throw $e;
                        }
                        else
                        {
                            throw $e;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(94489542761)
            
            //--TRIMMABLE-BOUNDARY-START(197568757865)
            /*Task *//*async*/  SendAsyncCore(/*ArraySegment<byte>*/ buffer, /*WebSocketMessageType*/ messageType, /*bool*/ endOfMessage, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197568757865);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*WebSocketState*/ let previousState = 0/*WebSocketState.None*/;
                    /*Task?*/ let sendTask;
                    /*MemoryHandle?*/ let pinBuffer = null;
                    try
                    {
                        //lock(_lockObject)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                            {
                                this.ThrowIfDisposed();
                                previousState = this.FastState;
                                if (previousState !== 2/*WebSocketState.Open*/ && previousState !== 4/*WebSocketState.CloseReceived*/)
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snwc.S.SR.net_WebSockets_NotConnected);
                                }
                                this.AbortIfCancelationRequested(cancellationToken);
                                if (buffer.Count === 0)
                                {
                                    sendTask = $.$snwc.SNW.BrowserInterop.WebSocketSend(this._innerWebSocket, $.$$.S.IntPtr.Zero, 0, messageType, endOfMessage);
                                }
                                else 
                                {
                                    /*Memory<byte>*/ let bufferMemory = $.$$.S.MemoryExtensions.AsMemory$7($.$$.S.Byte, buffer);
                                    pinBuffer = bufferMemory.Pin();
                                    sendTask = $.$snwc.SNW.BrowserInterop.UnsafeSend(this._innerWebSocket, $.$$.S.Nullable$$($.$$.SB.MemoryHandle).Value$get.call(pinBuffer), bufferMemory.Length, messageType, endOfMessage);
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit(this._lockObject)
                        }
                        if (sendTask !== null)
                        {
                            let $t2, $r2;
                            ($t2 = this.CancellationHelper(sendTask, cancellationToken, previousState).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        }
                    }
                    catch(ex)
                    {
                        if (ex.Message.startsWith("InvalidState:"))
                        {
                            throw new $.$snws.SNW.WebSocketException().$ctor$29(9/*WebSocketError.InvalidState*/, $.$snwc.S.SR.Format$5($.$snwc.S.SR.net_WebSockets_InvalidState, $.$box(previousState, $.$snws.SNW.WebSocketState), "Open"), ex);
                        }
                        throw new $.$snws.SNW.WebSocketException().$ctor$24(3/*WebSocketError.NativeError*/, ex);
                    }
                    finally
                    {
                        {
                            pinBuffer?.Dispose();
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(197568757865)
            
            //--TRIMMABLE-BOUNDARY-START(180388888681)
            /*Task<WebSocketReceiveResult> *//*async*/  ReceiveAsyncCore(/*ArraySegment<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$snws.SNW.WebSocketReceiveResult), $.$snws.SNW.WebSocketReceiveResult, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(180388888681);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*WebSocketState*/ let previousState = 0/*WebSocketState.None*/;
                    /*Task?*/ let receiveTask;
                    /*MemoryHandle?*/ let pinBuffer = null;
                    try
                    {
                        //lock(_lockObject)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                            {
                                this.ThrowIfDisposed();
                                previousState = this.FastState;
                                if (previousState !== 2/*WebSocketState.Open*/ && previousState !== 3/*WebSocketState.CloseSent*/)
                                {
                                    throw new $.$snws.SNW.WebSocketException().$ctor$30(9/*WebSocketError.InvalidState*/, $.$snwc.S.SR.Format$5($.$snwc.S.SR.net_WebSockets_InvalidState, $.$box(previousState, $.$snws.SNW.WebSocketState), "Open, CloseSent"));
                                }
                                this.AbortIfCancelationRequested(cancellationToken);
                                /*Memory<byte>*/ let bufferMemory = $.$$.S.MemoryExtensions.AsMemory$7($.$$.S.Byte, buffer);
                                pinBuffer = bufferMemory.Pin();
                                receiveTask = $.$snwc.SNW.BrowserInterop.ReceiveUnsafe(this._innerWebSocket, $.$$.S.Nullable$$($.$$.SB.MemoryHandle).Value$get.call(pinBuffer), bufferMemory.Length);
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit(this._lockObject)
                        }
                        if (receiveTask !== null)
                        {
                            let $t3, $r3;
                            ($t3 = this.CancellationHelper(receiveTask, cancellationToken, previousState).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        }
                        return $.$$.N.AsyncResolver.Result($asnycContext, this.ConvertResponse());
                    }
                    catch(ex)
                    {
                        if (ex.Message.startsWith("InvalidState:"))
                        {
                            throw new $.$snws.SNW.WebSocketException().$ctor$29(9/*WebSocketError.InvalidState*/, $.$snwc.S.SR.Format$5($.$snwc.S.SR.net_WebSockets_InvalidState, $.$box(previousState, $.$snws.SNW.WebSocketState), "Open, CloseSent"), ex);
                        }
                        throw new $.$snws.SNW.WebSocketException().$ctor$24(3/*WebSocketError.NativeError*/, ex);
                    }
                    finally
                    {
                        {
                            pinBuffer?.Dispose();
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(180388888681)
            
            //--TRIMMABLE-BOUNDARY-START(98784510057)
            /*WebSocketReceiveResult */ ConvertResponse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784510057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let countIndex = 0;
                /*int*/ let typeIndex = 1;
                /*int*/ let endIndex = 2;
                /*int*/ let count;
                /*WebSocketMessageType*/ let messageType;
                /*bool*/ let isEnd = $.$$.System.Array.$ReadT1.call(this.responseStatus, endIndex) !== 0;
                //lock(_lockObject)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                    {
                        messageType = $.$cast($.$$.System.Array.$ReadT1.call(this.responseStatus, typeIndex), $.$snws.SNW.WebSocketMessageType);
                        count = $.$$.System.Array.$ReadT1.call(this.responseStatus, countIndex);
                        if (messageType === 2/*WebSocketMessageType.Close*/)
                        {
                            this._closeReceived = true;
                            this.FastState = this._closeSent ? 5/*WebSocketState.Closed*/ : 4/*WebSocketState.CloseReceived*/;
                            this.ForceReadCloseStatusLocked();
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._lockObject)
                }
                if (messageType === 2/*WebSocketMessageType.Close*/)
                {
                    let $switch4 = this._closeStatus ?? 1000/*WebSocketCloseStatus.NormalClosure*/;
                    switch($switch4)
                    {
                        case 1000/*WebSocketCloseStatus.NormalClosure*/:
                        case 1005/*WebSocketCloseStatus.Empty*/:
                        return new $.$snws.SNW.WebSocketReceiveResult().$ctor$1(count, messageType, isEnd, this._closeStatus, this._closeStatusDescription);
                        case 1003/*WebSocketCloseStatus.InvalidMessageType*/:
                        case 1007/*WebSocketCloseStatus.InvalidPayloadData*/:
                        throw new $.$snws.SNW.WebSocketException().$ctor$30(1/*WebSocketError.InvalidMessageType*/, this._closeStatusDescription);
                        case 1001/*WebSocketCloseStatus.EndpointUnavailable*/:
                        throw new $.$snws.SNW.WebSocketException().$ctor$30(4/*WebSocketError.NotAWebSocket*/, this._closeStatusDescription);
                        case 1002/*WebSocketCloseStatus.ProtocolError*/:
                        throw new $.$snws.SNW.WebSocketException().$ctor$30(6/*WebSocketError.UnsupportedProtocol*/, this._closeStatusDescription);
                        case 1011/*WebSocketCloseStatus.InternalServerError*/:
                        throw new $.$snws.SNW.WebSocketException().$ctor$30(2/*WebSocketError.Faulted*/, this._closeStatusDescription);
                        default:
                        throw new $.$snws.SNW.WebSocketException().$ctor$27(3/*WebSocketError.NativeError*/, $.$$.S.Nullable$$($.$snws.SNW.WebSocketCloseStatus).Value$get.call(this._closeStatus), this._closeStatusDescription);
                    }
                }
                return new $.$snws.SNW.WebSocketReceiveResult().$ctor$2(count, messageType, isEnd);
            }
            //--TRIMMABLE-BOUNDARY-END(98784510057)
            
            //--TRIMMABLE-BOUNDARY-START(73014706281)
            /*Task *//*async*/  CloseAsyncCore(/*WebSocketCloseStatus*/ closeStatus, /*string?*/ statusDescription, /*bool*/ fullClose, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014706281);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*Task?*/ let closeTask;
                    /*WebSocketState*/ let previousState;
                    //lock(_lockObject)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                        {
                            previousState = this.FastState;
                            if (this._aborted)
                            {
                                return $.$$.N.AsyncResolver.Result($asnycContext,);
                            }
                            if (previousState === 0/*WebSocketState.None*/ || previousState === 5/*WebSocketState.Closed*/)
                            {
                                throw new $.$snws.SNW.WebSocketException().$ctor$30(9/*WebSocketError.InvalidState*/, $.$snwc.S.SR.Format$5($.$snwc.S.SR.net_WebSockets_InvalidState, $.$box(previousState, $.$snws.SNW.WebSocketState), "Connecting, Open, CloseSent, CloseReceived, Aborted"));
                            }
                            this.AbortIfCancelationRequested(cancellationToken);
                            if (!this._closeReceived)
                            {
                                this._closeStatus = closeStatus;
                                this._closeStatusDescription = statusDescription;
                            }
                            this._closeSent = true;
                            closeTask = $.$snwc.SNW.BrowserInterop.WebSocketClose(this._innerWebSocket, closeStatus, statusDescription, fullClose);
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this._lockObject)
                    }
                    if (closeTask !== null)
                    {
                        let $t5, $r5;
                        ($t5 = this.CancellationHelper(closeTask, cancellationToken, previousState).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    }
                    if (fullClose)
                    {
                        //lock(_lockObject)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                            {
                                this._closeReceived = true;
                                this.ForceReadCloseStatusLocked();
                                _ = this.State;
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit(this._lockObject)
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73014706281)
            
            //--TRIMMABLE-BOUNDARY-START(64424771689)
            /*Task *//*async*/  CancellationHelper(/*Task*/ promise, /*CancellationToken*/ cancellationToken, /*WebSocketState*/ previousState)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424771689);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        if (promise.IsCompletedSuccessfully)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext,);
                        }
                        if (promise.IsCompleted)
                        {
                            let $t6, $r6;
                            ($t6 = promise.ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                            return $.$$.N.AsyncResolver.Result($asnycContext,);
                        }
                        this.AbortIfCancelationRequested(cancellationToken);
                        let receiveRegistration = null;
                        try
                        {
                            let $t7, $r7;
                            receiveRegistration = cancellationToken.Register$4(new ($.$$.S.Action$$($.$$.S.Object))().$ctor($.$snwc.SNW.BrowserWebSocket, /*static*/ (/*s*/ s) =>
                            {
                                $.$srij.SRIJ.CancelablePromise.CancelPromise($.$cast(s, $.$$.STT.Task));
                            }, $YlYFki ??= {"r":65537,"p":[{"n":"s","p":131073}],"n":"","d":262249,"h":0,"f":17825826}), promise);
                            ($t7 = promise.ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                            return $.$$.N.AsyncResolver.Result($asnycContext,);
                        }
                        finally
                        {
                            receiveRegistration?.S$IDisposable$Dispose();
                        }
                    }
                    catch(ex)
                    {
                        //lock(_lockObject)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                            {
                                /*var*/ let state = this.State;
                                this.ForceReadCloseStatusLocked();
                                if (state === 6/*WebSocketState.Aborted*/)
                                {
                                    throw new $.$$.S.OperationCanceledException().$ctor$12("Aborted", ex);
                                }
                                if ($.$is(ex, $.$$.S.OperationCanceledException) || cancellationToken.IsCancellationRequested || ex.Message === "Error: OperationCanceledException")
                                {
                                    if (state !== 5/*WebSocketState.Closed*/)
                                    {
                                        this.FastState = 6/*WebSocketState.Aborted*/;
                                    }
                                    this._cancelled = true;
                                    throw new $.$$.S.OperationCanceledException().$ctor$11("The operation was cancelled.", ex, cancellationToken);
                                }
                                if (previousState === 1/*WebSocketState.Connecting*/)
                                {
                                    throw new $.$snws.SNW.WebSocketException().$ctor$29(2/*WebSocketError.Faulted*/, $.$snwc.S.SR.net_webstatus_ConnectFailure, ex);
                                }
                                throw new $.$snws.SNW.WebSocketException().$ctor$24(3/*WebSocketError.NativeError*/, ex);
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit(this._lockObject)
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64424771689)
            
            //--TRIMMABLE-BOUNDARY-START(115964379241)
            /*void */ ForceReadCloseStatusLocked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964379241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed && this._closeStatus === null)
                {
                    this.GetCloseStatusLocked();
                    this.GetCloseStatusDescriptionLocked();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964379241)
            
            //--TRIMMABLE-BOUNDARY-START(167503986793)
            /*WebSocketCloseStatus? */ GetCloseStatusLocked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503986793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                /*var*/ let closeStatus = $.$snwc.SNW.BrowserInterop.GetCloseStatus(this._innerWebSocket);
                if (closeStatus !== null && this._closeStatus === null)
                {
                    this._closeStatus = closeStatus;
                }
                return this._closeStatus;
            }
            //--TRIMMABLE-BOUNDARY-END(167503986793)
            
            //--TRIMMABLE-BOUNDARY-START(163209019497)
            /*string? */ GetCloseStatusDescriptionLocked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209019497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                /*var*/ let closeStatusDescription = $.$snwc.SNW.BrowserInterop.GetCloseStatusDescription(this._innerWebSocket);
                if (closeStatusDescription !== null && this._closeStatusDescription === null)
                {
                    this._closeStatusDescription = closeStatusDescription;
                }
                return this._closeStatusDescription;
            }
            //--TRIMMABLE-BOUNDARY-END(163209019497)
            
            //--TRIMMABLE-BOUNDARY-START(171798954089)
            static /*WebSocketState */ GetReadyStateLocked(/*JSObject*/ innerWebSocket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798954089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let readyState = $.$snwc.SNW.BrowserInterop.GetReadyState(innerWebSocket);
                return (() =>
                {
                    if (readyState === 0)
                    {
                        return 1/*WebSocketState.Connecting*/;
                    }
                    if (readyState === 1)
                    {
                        return 2/*WebSocketState.Open*/;
                    }
                    if (readyState === 2)
                    {
                        return 3/*WebSocketState.CloseSent*/;
                    }
                    if (readyState === 3)
                    {
                        return 5/*WebSocketState.Closed*/;
                    }
                    return 0/*WebSocketState.None*/;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(171798954089)
            
            //--TRIMMABLE-BOUNDARY-START(51539869801)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539869801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51539869801)
            
            //--TRIMMABLE-BOUNDARY-START(51539869801)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(51539869801)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38654967913)
                this._lockObject = new $.$$.S.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(38654967913)
                
                //--TRIMMABLE-BOUNDARY-START(184683855977)
                this.responseStatus = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [3], null);
                //--TRIMMABLE-BOUNDARY-END(184683855977)
                
                //--TRIMMABLE-BOUNDARY-START(188978823273)
                this.responseStatusHandle = null;
                //--TRIMMABLE-BOUNDARY-END(188978823273)
                
            }
            static $h = 262249;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snws.SNW.WebSocket; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(210453659753),
    {
      "p": 2293864,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324117609,
        "f": 50364417
      },
      "n": "State",
      "d": 262249,
      "h": 210453659753,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(210453659753),
//--TRIMMABLE-BOUNDARY-START(111669411945),
    {
      "p": 2293864,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734183017,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206158692457,
        "f": 83886082
      },
      "n": "FastState",
      "d": 262249,
      "h": 111669411945,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(111669411945),
//--TRIMMABLE-BOUNDARY-START(81604640873),
    {
      "p": $.$typeNullable($.$snws.SNW.WebSocketCloseStatus).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554313833,
        "f": 50364417
      },
      "n": "CloseStatus",
      "d": 262249,
      "h": 81604640873,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81604640873),
//--TRIMMABLE-BOUNDARY-START(85899608169),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144248425,
        "f": 50364417
      },
      "n": "CloseStatusDescription",
      "d": 262249,
      "h": 85899608169,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(85899608169),
//--TRIMMABLE-BOUNDARY-START(214748627049),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914052201,
        "f": 50364417
      },
      "n": "SubProtocol",
      "d": 262249,
      "h": 214748627049,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(214748627049)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90194575465),
    {
      "r": 178454529,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        },
        {
          "n": "requestedSubProtocols",
          "p": $.$$.SCG.List$$($.$$.S.String).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ConnectAsync",
      "d": 262249,
      "h": 90194575465,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(90194575465),
//--TRIMMABLE-BOUNDARY-START(193273790569),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "SendAsync",
      "d": 262249,
      "h": 193273790569,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193273790569),
//--TRIMMABLE-BOUNDARY-START(176093921385),
    {
      "r": $.$$.STT.Task$$($.$snws.SNW.WebSocketReceiveResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReceiveAsync",
      "d": 262249,
      "h": 176093921385,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176093921385),
//--TRIMMABLE-BOUNDARY-START(77309673577),
    {
      "r": 178454529,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "statusDescription",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CloseOutputAsync",
      "d": 262249,
      "h": 77309673577,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77309673577),
//--TRIMMABLE-BOUNDARY-START(68719738985),
    {
      "r": 178454529,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "statusDescription",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CloseAsync",
      "d": 262249,
      "h": 68719738985,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68719738985),
//--TRIMMABLE-BOUNDARY-START(55834837097),
    {
      "r": 65537,
      "n": "Abort",
      "d": 262249,
      "h": 55834837097,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55834837097),
//--TRIMMABLE-BOUNDARY-START(107374444649),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 262249,
      "h": 107374444649,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107374444649),
//--TRIMMABLE-BOUNDARY-START(219043594345),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": 262249,
      "h": 219043594345,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(219043594345),
//--TRIMMABLE-BOUNDARY-START(60129804393),
    {
      "r": 65537,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "AbortIfCancelationRequested",
      "d": 262249,
      "h": 60129804393,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60129804393),
//--TRIMMABLE-BOUNDARY-START(103079477353),
    {
      "r": 65537,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        },
        {
          "n": "requestedSubProtocols",
          "p": $.$$.SCG.List$$($.$$.S.String).$h
        }
      ],
      "n": "CreateCore",
      "d": 262249,
      "h": 103079477353,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103079477353),
//--TRIMMABLE-BOUNDARY-START(94489542761),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ConnectAsyncCore",
      "d": 262249,
      "h": 94489542761,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(94489542761),
//--TRIMMABLE-BOUNDARY-START(197568757865),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "SendAsyncCore",
      "d": 262249,
      "h": 197568757865,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(197568757865),
//--TRIMMABLE-BOUNDARY-START(180388888681),
    {
      "r": $.$$.STT.Task$$($.$snws.SNW.WebSocketReceiveResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReceiveAsyncCore",
      "d": 262249,
      "h": 180388888681,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(180388888681),
//--TRIMMABLE-BOUNDARY-START(98784510057),
    {
      "r": 2228328,
      "n": "ConvertResponse",
      "d": 262249,
      "h": 98784510057,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98784510057),
//--TRIMMABLE-BOUNDARY-START(73014706281),
    {
      "r": 178454529,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "statusDescription",
          "p": 1310721
        },
        {
          "n": "fullClose",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CloseAsyncCore",
      "d": 262249,
      "h": 73014706281,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(73014706281),
//--TRIMMABLE-BOUNDARY-START(64424771689),
    {
      "r": 178454529,
      "p": [
        {
          "n": "promise",
          "p": 178454529
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "previousState",
          "p": 2293864
        }
      ],
      "n": "CancellationHelper",
      "d": 262249,
      "h": 64424771689,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(64424771689),
//--TRIMMABLE-BOUNDARY-START(115964379241),
    {
      "r": 65537,
      "n": "ForceReadCloseStatusLocked",
      "d": 262249,
      "h": 115964379241,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115964379241),
//--TRIMMABLE-BOUNDARY-START(167503986793),
    {
      "r": $.$typeNullable($.$snws.SNW.WebSocketCloseStatus).$h,
      "n": "GetCloseStatusLocked",
      "d": 262249,
      "h": 167503986793,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167503986793),
//--TRIMMABLE-BOUNDARY-START(163209019497),
    {
      "r": 1310721,
      "n": "GetCloseStatusDescriptionLocked",
      "d": 262249,
      "h": 163209019497,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163209019497),
//--TRIMMABLE-BOUNDARY-START(171798954089),
    {
      "r": 2293864,
      "p": [
        {
          "n": "innerWebSocket",
          "p": 2228235
        }
      ],
      "n": "GetReadyStateLocked",
      "d": 262249,
      "h": 171798954089,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(171798954089)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38654967913),
    {
      "t": 131073,
      "n": "_lockObject",
      "d": 262249,
      "h": 38654967913,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38654967913),
//--TRIMMABLE-BOUNDARY-START(21475098729),
    {
      "t": $.$typeNullable($.$snws.SNW.WebSocketCloseStatus).$h,
      "n": "_closeStatus",
      "d": 262249,
      "h": 21475098729,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475098729),
//--TRIMMABLE-BOUNDARY-START(25770066025),
    {
      "t": 1310721,
      "n": "_closeStatusDescription",
      "d": 262249,
      "h": 25770066025,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770066025),
//--TRIMMABLE-BOUNDARY-START(34360000617),
    {
      "t": 2228235,
      "n": "_innerWebSocket",
      "d": 262249,
      "h": 34360000617,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360000617),
//--TRIMMABLE-BOUNDARY-START(47244902505),
    {
      "t": 2293864,
      "n": "_state",
      "d": 262249,
      "h": 47244902505,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47244902505),
//--TRIMMABLE-BOUNDARY-START(17180131433),
    {
      "t": 262145,
      "n": "_closeSent",
      "d": 262249,
      "h": 17180131433,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180131433),
//--TRIMMABLE-BOUNDARY-START(12885164137),
    {
      "t": 262145,
      "n": "_closeReceived",
      "d": 262249,
      "h": 12885164137,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885164137),
//--TRIMMABLE-BOUNDARY-START(30065033321),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 262249,
      "h": 30065033321,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065033321),
//--TRIMMABLE-BOUNDARY-START(4295229545),
    {
      "t": 262145,
      "n": "_aborted",
      "d": 262249,
      "h": 4295229545,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229545),
//--TRIMMABLE-BOUNDARY-START(42949935209),
    {
      "t": 262145,
      "n": "_shouldAbort",
      "d": 262249,
      "h": 42949935209,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42949935209),
//--TRIMMABLE-BOUNDARY-START(8590196841),
    {
      "t": 262145,
      "n": "_cancelled",
      "d": 262249,
      "h": 8590196841,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196841),
//--TRIMMABLE-BOUNDARY-START(184683855977),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "responseStatus",
      "d": 262249,
      "h": 184683855977,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(184683855977),
//--TRIMMABLE-BOUNDARY-START(188978823273),
    {
      "t": $.$typeNullable($.$$.SB.MemoryHandle).$h,
      "n": "responseStatusHandle",
      "d": 262249,
      "h": 188978823273,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(188978823273)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51539869801),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262249,
      "h": 51539869801,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539869801)
  ],
  "h": 262249
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.BrowserWebSocket`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}BrowserWebSocket`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262249)
        
        

        //--TRIMMABLE-BOUNDARY-START(589929)
        $asm.$cls(`$snwc.SNW.HttpResponseHeadersReadOnlyCollection`, ($self) => class HttpResponseHeadersReadOnlyCollection extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295557225)
            /*HttpHeadersNonValidated*/ _headers;
            //--TRIMMABLE-BOUNDARY-END(4295557225)
            
            //--TRIMMABLE-BOUNDARY-START(8590524521)
            $ctor$1(/*HttpResponseHeaders*/ headers)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590524521);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._headers = headers.NonValidated;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524521)
            
            //--TRIMMABLE-BOUNDARY-START(68720066665)
            /*IEnumerable<string>*/ get_Item$1(/*string*/ key)
            {
                return this._headers.get_Item$1(key);
        ;
            }
            //--TRIMMABLE-BOUNDARY-END(68720066665)
            
            //--TRIMMABLE-BOUNDARY-START(60130132073)
            /*IEnumerable<string> */ get Keys()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.S.String))().$ctor$1(function*()
                {
                    let $en1 = this._headers.GetEnumerator();
                    while ($en1.MoveNext())
                    {
                        let header = $en1.Current;
                        {
                            yield header.Key;
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(60130132073)
            
            //--TRIMMABLE-BOUNDARY-START(77310001257)
            /*IEnumerable<IEnumerable<string>> */ get Values()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.IEnumerable$$($.$$.S.String)))().$ctor$1(function*()
                {
                    let $en2 = this._headers.GetEnumerator();
                    while ($en2.MoveNext())
                    {
                        let header = $en2.Current;
                        {
                            yield header.Value;
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(77310001257)
            
            //--TRIMMABLE-BOUNDARY-START(17180459113)
            /*int */ get Count()
            {
                return this._headers.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17180459113)
            
            //--TRIMMABLE-BOUNDARY-START(12885491817)
            /*bool */ ContainsKey(/*string*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885491817);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._headers.Contains(key);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885491817)
            
            //--TRIMMABLE-BOUNDARY-START(55835164777)
            /*IEnumerator<KeyValuePair<string, IEnumerable<string>>> */ GetEnumerator()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.String))))().$ctor$1(function*()
                {
                    let $en3 = this._headers.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        let header = $en3.Current;
                        {
                            yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.String)))().$ctor$3(header.Key, header.Value);
                        }
                    }
                }.bind(this)).GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(55835164777)
            
            //--TRIMMABLE-BOUNDARY-START(73015033961)
            /*bool */ TryGetValue(/*string*/ key, /*out IEnumerable<string>*/ value)
            {
                /*HeaderStringValues*/ let values;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._headers.TryGetValues(key, $.$ref(() => values, ($v) => values = $v, $.$snh.SNHH.HeaderStringValues)))
                {
                    value.$v = values;
                    return true;
                }
                value.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(73015033961)
            
            //--TRIMMABLE-BOUNDARY-START(64425099369)
            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425099369);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425099369)
            
            //--TRIMMABLE-BOUNDARY-START(4355784705)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<string, System.Collections.Generic.IEnumerable<string>>.ContainsKey(string)
            SCG$IReadOnlyDictionary$$$$ContainsKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355784705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ContainsKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355784705)
            
            //--TRIMMABLE-BOUNDARY-START(43010490369)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<string, System.Collections.Generic.IEnumerable<string>>.TryGetValue(string, out System.Collections.Generic.IEnumerable<string>)
            SCG$IReadOnlyDictionary$$$$TryGetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43010490369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(43010490369)
            
            //--TRIMMABLE-BOUNDARY-START(12945719297)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<string, System.Collections.Generic.IEnumerable<string>>.this[string].get
            SCG$IReadOnlyDictionary$$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945719297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12945719297)
            
            //--TRIMMABLE-BOUNDARY-START(21535653889)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<string, System.Collections.Generic.IEnumerable<string>>.Keys.get
            get SCG$IReadOnlyDictionary$$$$Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34420555777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Keys;
            }
            //--TRIMMABLE-BOUNDARY-END(21535653889)
            
            //--TRIMMABLE-BOUNDARY-START(30125588481)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<string, System.Collections.Generic.IEnumerable<string>>.Values.get
            get SCG$IReadOnlyDictionary$$$$Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47305457665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(30125588481)
            
            //--TRIMMABLE-BOUNDARY-START(12945653761)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, System.Collections.Generic.IEnumerable<string>>>.Count.get
            get SCG$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355719169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12945653761)
            
            //--TRIMMABLE-BOUNDARY-START(4355325953)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, System.Collections.Generic.IEnumerable<string>>>.GetEnumerator()
            SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355325953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355325953)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295557225)
                this._headers = $.$default($.$snh.SNHH.HttpHeadersNonValidated);
                //--TRIMMABLE-BOUNDARY-END(4295557225)
                
            }
            static $h = 589929;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720066665),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "i": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360328297,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 589929,
      "h": 68720066665,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(68720066665),
//--TRIMMABLE-BOUNDARY-START(60130132073),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262889,
        "f": 50331649
      },
      "n": "Keys",
      "d": 589929,
      "h": 60130132073,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130132073),
//--TRIMMABLE-BOUNDARY-START(77310001257),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.IEnumerable$$($.$$.S.String)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197481,
        "f": 50331649
      },
      "n": "Values",
      "d": 589929,
      "h": 77310001257,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310001257),
//--TRIMMABLE-BOUNDARY-START(17180459113),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770393705,
        "f": 50331649
      },
      "n": "Count",
      "d": 589929,
      "h": 17180459113,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180459113)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885491817),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "ContainsKey",
      "d": 589929,
      "h": 12885491817,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885491817),
//--TRIMMABLE-BOUNDARY-START(55835164777),
    {
      "r": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.String))).$h,
      "n": "GetEnumerator",
      "d": 589929,
      "h": 55835164777,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835164777),
//--TRIMMABLE-BOUNDARY-START(73015033961),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": 589929,
      "h": 73015033961,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015033961)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557225),
    {
      "t": 4063285,
      "n": "_headers",
      "d": 589929,
      "h": 4295557225,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557225)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590524521),
    {
      "p": [
        {
          "n": "headers",
          "p": 4390965
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589929,
      "h": 8590524521,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590524521)
  ],
  "h": 589929
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.String)), $.$$.SCG.IReadOnlyCollection$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.String))), $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.String))), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.HttpResponseHeadersReadOnlyCollection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}HttpResponseHeadersReadOnlyCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589929)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.WebSockets"));
})();
//--TRIMMABLE-BOUNDARY-END(105)
