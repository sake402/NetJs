
//--TRIMMABLE-BOUNDARY-START(104)
(async function () {
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $sic, $stt, $sim, $stee, $srm, $sds, $srn, $sfa, $snp, $sscr) {
    "use strict";
    let _;
    let $pFjNud;
    let $DWwLcg;
    let $chfUbb;
    let $gxlbUg;
    let $dAJfdf;
    let $aJjlVh;
    
    
    
	$.$asm(
    "NetJs.System.Net.WebSockets", 
    {
  "h": 104,
  "f": "System.Net.WebSockets",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Net.WebSockets",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Net.WebSockets",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1704040)
        $asm.$cls(`$snws.SNW.WebSocketContext`, ($self) => class WebSocketContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296671336)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296671336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296671336)
            
            //--TRIMMABLE-BOUNDARY-START(4296671336)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296671336)
            
            static $h = 1704040;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137440657512),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721180776,
        "f": 50331905
      },
      "n": "RequestUri",
      "d": 1704040,
      "h": 137440657512,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(137440657512),
//--TRIMMABLE-BOUNDARY-START(115965821032),
    {
      "p": 983057,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771507816,
        "f": 50331905
      },
      "n": "Headers",
      "d": 1704040,
      "h": 115965821032,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(115965821032),
//--TRIMMABLE-BOUNDARY-START(133145690216),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131246184,
        "f": 50331905
      },
      "n": "Origin",
      "d": 1704040,
      "h": 133145690216,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(133145690216),
//--TRIMMABLE-BOUNDARY-START(146030592104),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901049960,
        "f": 50331905
      },
      "n": "SecWebSocketProtocols",
      "d": 1704040,
      "h": 146030592104,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(146030592104),
//--TRIMMABLE-BOUNDARY-START(150325559400),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490984552,
        "f": 50331905
      },
      "n": "SecWebSocketVersion",
      "d": 1704040,
      "h": 150325559400,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(150325559400),
//--TRIMMABLE-BOUNDARY-START(141735624808),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311115368,
        "f": 50331905
      },
      "n": "SecWebSocketKey",
      "d": 1704040,
      "h": 141735624808,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(141735624808),
//--TRIMMABLE-BOUNDARY-START(8591638632),
    {
      "p": 1179695,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181573224,
        "f": 50331905
      },
      "n": "CookieCollection",
      "d": 1704040,
      "h": 8591638632,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591638632),
//--TRIMMABLE-BOUNDARY-START(154620526696),
    {
      "p": 162004993,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080919144,
        "f": 50331905
      },
      "n": "User",
      "d": 1704040,
      "h": 154620526696,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(154620526696),
//--TRIMMABLE-BOUNDARY-START(120260788328),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361442408,
        "f": 50331905
      },
      "n": "IsAuthenticated",
      "d": 1704040,
      "h": 120260788328,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(120260788328),
//--TRIMMABLE-BOUNDARY-START(124555755624),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951377000,
        "f": 50331905
      },
      "n": "IsLocal",
      "d": 1704040,
      "h": 124555755624,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(124555755624),
//--TRIMMABLE-BOUNDARY-START(128850722920),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541311592,
        "f": 50331905
      },
      "n": "IsSecureConnection",
      "d": 1704040,
      "h": 128850722920,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(128850722920),
//--TRIMMABLE-BOUNDARY-START(158915493992),
    {
      "p": 1572968,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670853736,
        "f": 50331905
      },
      "n": "WebSocket",
      "d": 1704040,
      "h": 158915493992,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(158915493992)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671336),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1704040,
      "h": 4296671336,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296671336)
  ],
  "h": 1704040
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704040)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572968)
        $asm.$cls(`$snws.SNW.WebSocket`, ($self) => class WebSocket extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115965689960)
            /*ValueTask<ValueWebSocketReceiveResult> *//*async*/  ReceiveAsync$1(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$snws.SNW.ValueWebSocketReceiveResult), $.$snws.SNW.ValueWebSocketReceiveResult, async ($asnycContext) => 
                {
                    /*ArraySegment<byte>*/ let arraySegment;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115965689960);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.SRI.MemoryMarshal.TryGetArray($.$$.S.Byte, $.$$.S.Memory$$($.$$.S.Byte).op_Implicit(buffer), $.$ref(() => arraySegment, ($v) => arraySegment = $v, $.$$.S.ArraySegment$$($.$$.S.Byte))))
                    {
                        let $t2, $r2;
                        /*WebSocketReceiveResult*/ let r = ($t2 = this.ReceiveAsync(arraySegment, cancellationToken).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, new $.$snws.SNW.ValueWebSocketReceiveResult().$ctor$3(r.Count, r.MessageType, r.EndOfMessage));
                    }
                    /*byte[]*/ let array = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(buffer.Length);
                    try
                    {
                        let $t3, $r3;
                        /*WebSocketReceiveResult*/ let r = ($t3 = this.ReceiveAsync(new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$3(array, 0, buffer.Length), cancellationToken).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$6(array, 0, r.Count).CopyTo(buffer.Span);
                        return $.$$.N.AsyncResolver.Result($asnycContext, new $.$snws.SNW.ValueWebSocketReceiveResult().$ctor$3(r.Count, r.MessageType, r.EndOfMessage));
                    }
                    finally
                    {
                        {
                            $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(array, false);
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(115965689960)
            
            //--TRIMMABLE-BOUNDARY-START(128850591848)
            /*ValueTask */ SendAsync$1(/*ReadOnlyMemory<byte>*/ buffer, /*WebSocketMessageType*/ messageType, /*bool*/ endOfMessage, /*CancellationToken*/ cancellationToken)
            {
                {
                    /*ArraySegment<byte>*/ let arraySegment;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128850591848);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.SRI.MemoryMarshal.TryGetArray($.$$.S.Byte, buffer, $.$ref(() => arraySegment, ($v) => arraySegment = $v, $.$$.S.ArraySegment$$($.$$.S.Byte))) ? new $.$$.STT.ValueTask().$ctor$5(this.SendAsync(arraySegment, messageType, endOfMessage, cancellationToken)) : this.SendWithArrayPoolAsync(buffer, messageType, endOfMessage, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128850591848)
            
            //--TRIMMABLE-BOUNDARY-START(133145559144)
            /*ValueTask */ SendAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*WebSocketMessageType*/ messageType, /*WebSocketMessageFlags*/ messageFlags, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145559144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SendAsync$1(buffer, messageType, ((messageFlags & (1/*WebSocketMessageFlags.EndOfMessage*/)) == (1/*WebSocketMessageFlags.EndOfMessage*/)), cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(133145559144)
            
            //--TRIMMABLE-BOUNDARY-START(137440526440)
            /*ValueTask *//*async*/  SendWithArrayPoolAsync(/*ReadOnlyMemory<byte>*/ buffer, /*WebSocketMessageType*/ messageType, /*bool*/ endOfMessage, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137440526440);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*byte[]*/ let array = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(buffer.Length);
                    try
                    {
                        let $t5, $r5;
                        buffer.Span.CopyTo($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(array));
                        ($t5 = this.SendAsync(new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$3(array, 0, buffer.Length), messageType, endOfMessage, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    }
                    finally
                    {
                        {
                            $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(array, false);
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(137440526440)
            
            //--TRIMMABLE-BOUNDARY-START(51541180520)
            static /*TimeSpan */ get DefaultKeepAliveInterval()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605951592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$snws.SNW.WebSocketDefaults.DefaultClientKeepAliveInterval;
            }
            //--TRIMMABLE-BOUNDARY-END(51541180520)
            
            //--TRIMMABLE-BOUNDARY-START(150325428328)
            static /*void */ ThrowOnInvalidState(/*WebSocketState*/ state, /*params WebSocketState[]*/ validStates)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325428328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let validStatesText = $.$$.S.String.Empty;
                if (validStates !== null && validStates.length > 0)
                {
                    let $i6 = 0;
                    let $arr6 = validStates;
                    while ($i6 < $arr6.length)
                    {
                        let currentState = $arr6[$i6++];
                        if (state === currentState)
                        {
                            return;
                        }
                    }
                    validStatesText = $.$$.S.String.Join$12($.$snws.SNW.WebSocketState, ", ", validStates);
                }
                throw new $.$snws.SNW.WebSocketException().$ctor$30(9/*WebSocketError.InvalidState*/, $.$snws.S.SR.Format$5($.$snws.S.SR.net_WebSockets_InvalidState, $.$box(state, $.$snws.SNW.WebSocketState), validStatesText));
            }
            //--TRIMMABLE-BOUNDARY-END(150325428328)
            
            //--TRIMMABLE-BOUNDARY-START(107375755368)
            static /*bool */ IsStateTerminal(/*WebSocketState*/ state)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107375755368);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return state === 5/*WebSocketState.Closed*/ || state === 6/*WebSocketState.Aborted*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107375755368)
            
            //--TRIMMABLE-BOUNDARY-START(30066344040)
            static /*ArraySegment<byte> */ CreateClientBuffer(/*int*/ receiveBufferSize, /*int*/ sendBufferSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066344040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.S.Int32, receiveBufferSize, "receiveBufferSize");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.S.Int32, sendBufferSize, "sendBufferSize");
                return new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [$.$$.S.Math.Max$4(receiveBufferSize, sendBufferSize)], null));
            }
            //--TRIMMABLE-BOUNDARY-END(30066344040)
            
            //--TRIMMABLE-BOUNDARY-START(47246213224)
            static /*ArraySegment<byte> */ CreateServerBuffer(/*int*/ receiveBufferSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246213224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.S.Int32, receiveBufferSize, "receiveBufferSize");
                return new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [receiveBufferSize], null));
            }
            //--TRIMMABLE-BOUNDARY-END(47246213224)
            
            //--TRIMMABLE-BOUNDARY-START(38656278632)
            static /*WebSocket */ CreateFromStream(/*Stream*/ stream, /*bool*/ isServer, /*string?*/ subProtocol, /*TimeSpan*/ keepAliveInterval)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656278632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                if (!stream.CanRead || !stream.CanWrite)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13(!stream.CanRead ? $.$snws.S.SR.NotReadableStream : $.$snws.S.SR.NotWriteableStream, "stream");
                }
                if (subProtocol !== null)
                {
                    $.$snws.SNW.WebSocketValidate.ValidateSubprotocol(subProtocol);
                }
                if ($.$$.S.TimeSpan.op_Inequality(keepAliveInterval, $.$$.ST$1.Timeout.InfiniteTimeSpan) && $.$$.S.TimeSpan.op_LessThan(keepAliveInterval, $.$$.S.TimeSpan.Zero))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("keepAliveInterval", keepAliveInterval, $.$snws.S.SR.Format$6($.$snws.S.SR.net_WebSockets_ArgumentOutOfRange_TooSmall, $.$box(0, $.$$.S.Int32)));
                }
                return new $.$snws.SNW.ManagedWebSocket().$ctor$2(stream, isServer, subProtocol, keepAliveInterval, $.$snws.SNW.WebSocketDefaults.DefaultKeepAliveTimeout);
            }
            //--TRIMMABLE-BOUNDARY-END(38656278632)
            
            //--TRIMMABLE-BOUNDARY-START(42951245928)
            static /*WebSocket */ CreateFromStream$1(/*Stream*/ stream, /*WebSocketCreationOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951245928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(options, "options");
                if (!stream.CanRead || !stream.CanWrite)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13(!stream.CanRead ? $.$snws.S.SR.NotReadableStream : $.$snws.S.SR.NotWriteableStream, "stream");
                }
                return new $.$snws.SNW.ManagedWebSocket().$ctor$3(stream, options);
            }
            //--TRIMMABLE-BOUNDARY-END(42951245928)
            
            //--TRIMMABLE-BOUNDARY-START(103080788072)
            static /*bool */ IsApplicationTargeting45()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103080788072);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080788072)
            
            //--TRIMMABLE-BOUNDARY-START(120260657256)
            static /*void */ RegisterPrefixes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260657256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120260657256)
            
            //--TRIMMABLE-BOUNDARY-START(34361311336)
            static /*WebSocket */ CreateClientWebSocket(/*Stream*/ innerStream, /*string?*/ subProtocol, /*int*/ receiveBufferSize, /*int*/ sendBufferSize, /*TimeSpan*/ keepAliveInterval, /*bool*/ useZeroMaskingKey, /*ArraySegment<byte>*/ internalBuffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361311336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(innerStream, "innerStream");
                if (!innerStream.CanRead || !innerStream.CanWrite)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13(!innerStream.CanRead ? $.$snws.S.SR.NotReadableStream : $.$snws.S.SR.NotWriteableStream, "innerStream");
                }
                if (subProtocol !== null)
                {
                    $.$snws.SNW.WebSocketValidate.ValidateSubprotocol(subProtocol);
                }
                if ($.$$.S.TimeSpan.op_Inequality(keepAliveInterval, $.$$.ST$1.Timeout.InfiniteTimeSpan) && $.$$.S.TimeSpan.op_LessThan(keepAliveInterval, $.$$.S.TimeSpan.Zero))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("keepAliveInterval", keepAliveInterval, $.$snws.S.SR.Format$6($.$snws.S.SR.net_WebSockets_ArgumentOutOfRange_TooSmall, $.$box(0, $.$$.S.Int32)));
                }
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.S.Int32, receiveBufferSize, "receiveBufferSize");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.S.Int32, sendBufferSize, "sendBufferSize");
                return new $.$snws.SNW.ManagedWebSocket().$ctor$2(innerStream, false, subProtocol, keepAliveInterval, $.$snws.SNW.WebSocketDefaults.DefaultKeepAliveTimeout);
            }
            //--TRIMMABLE-BOUNDARY-END(34361311336)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(4296540264)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540264)
            
            //--TRIMMABLE-BOUNDARY-START(4296540264)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296540264)
            
            static $h = 1572968;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476409448),
    {
      "p": $.$typeNullable($.$snws.SNW.WebSocketCloseStatus).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426082408,
        "f": 50331905
      },
      "n": "CloseStatus",
      "d": 1572968,
      "h": 21476409448,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21476409448),
//--TRIMMABLE-BOUNDARY-START(25771376744),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016017000,
        "f": 50331905
      },
      "n": "CloseStatusDescription",
      "d": 1572968,
      "h": 25771376744,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25771376744),
//--TRIMMABLE-BOUNDARY-START(146030461032),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785820776,
        "f": 50331905
      },
      "n": "SubProtocol",
      "d": 1572968,
      "h": 146030461032,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(146030461032),
//--TRIMMABLE-BOUNDARY-START(141735493736),
    {
      "p": 2293864,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195886184,
        "f": 50331905
      },
      "n": "State",
      "d": 1572968,
      "h": 141735493736,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(141735493736),
//--TRIMMABLE-BOUNDARY-START(51541180520),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605951592,
        "f": 50331681
      },
      "n": "DefaultKeepAliveInterval",
      "d": 1572968,
      "h": 51541180520,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(51541180520)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591507560),
    {
      "r": 65537,
      "n": "Abort",
      "d": 1572968,
      "h": 8591507560,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591507560),
//--TRIMMABLE-BOUNDARY-START(12886474856),
    {
      "r": 178454529,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "statusDescription",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CloseAsync",
      "d": 1572968,
      "h": 12886474856,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886474856),
//--TRIMMABLE-BOUNDARY-START(17181442152),
    {
      "r": 178454529,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "statusDescription",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CloseOutputAsync",
      "d": 1572968,
      "h": 17181442152,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17181442152),
//--TRIMMABLE-BOUNDARY-START(55836147816),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1572968,
      "h": 55836147816,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(55836147816),
//--TRIMMABLE-BOUNDARY-START(111670722664),
    {
      "r": $.$$.STT.Task$$($.$snws.SNW.WebSocketReceiveResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReceiveAsync",
      "d": 1572968,
      "h": 111670722664,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(111670722664),
//--TRIMMABLE-BOUNDARY-START(124555624552),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "SendAsync",
      "d": 1572968,
      "h": 124555624552,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(124555624552),
//--TRIMMABLE-BOUNDARY-START(115965689960),
    {
      "r": $.$$.STT.ValueTask$$($.$snws.SNW.ValueWebSocketReceiveResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReceiveAsync",
      "o": "@$1",
      "d": 1572968,
      "h": 115965689960,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(115965689960),
//--TRIMMABLE-BOUNDARY-START(128850591848),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "SendAsync",
      "o": "@$1",
      "d": 1572968,
      "h": 128850591848,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(128850591848),
//--TRIMMABLE-BOUNDARY-START(133145559144),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "messageFlags",
          "p": 2097256
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "SendAsync",
      "o": "@$2",
      "d": 1572968,
      "h": 133145559144,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(133145559144),
//--TRIMMABLE-BOUNDARY-START(137440526440),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "SendWithArrayPoolAsync",
      "d": 1572968,
      "h": 137440526440,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(137440526440),
//--TRIMMABLE-BOUNDARY-START(150325428328),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": 2293864
        },
        {
          "n": "validStates",
          "p": $.$typeArray($.$snws.SNW.WebSocketState).$h,
          "f": 16
        }
      ],
      "n": "ThrowOnInvalidState",
      "d": 1572968,
      "h": 150325428328,
      "f": 16777252
    },
//--TRIMMABLE-BOUNDARY-END(150325428328),
//--TRIMMABLE-BOUNDARY-START(107375755368),
    {
      "r": 262145,
      "p": [
        {
          "n": "state",
          "p": 2293864
        }
      ],
      "n": "IsStateTerminal",
      "d": 1572968,
      "h": 107375755368,
      "f": 16777252
    },
//--TRIMMABLE-BOUNDARY-END(107375755368),
//--TRIMMABLE-BOUNDARY-START(30066344040),
    {
      "r": $.$$.S.ArraySegment$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "receiveBufferSize",
          "p": 655361
        },
        {
          "n": "sendBufferSize",
          "p": 655361
        }
      ],
      "n": "CreateClientBuffer",
      "d": 1572968,
      "h": 30066344040,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066344040),
//--TRIMMABLE-BOUNDARY-START(47246213224),
    {
      "r": $.$$.S.ArraySegment$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "receiveBufferSize",
          "p": 655361
        }
      ],
      "n": "CreateServerBuffer",
      "d": 1572968,
      "h": 47246213224,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47246213224),
//--TRIMMABLE-BOUNDARY-START(38656278632),
    {
      "r": 1572968,
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "isServer",
          "p": 262145
        },
        {
          "n": "subProtocol",
          "p": 1310721
        },
        {
          "n": "keepAliveInterval",
          "p": 186646529
        }
      ],
      "n": "CreateFromStream",
      "d": 1572968,
      "h": 38656278632,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656278632),
//--TRIMMABLE-BOUNDARY-START(42951245928),
    {
      "r": 1572968,
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "options",
          "p": 1769576
        }
      ],
      "n": "CreateFromStream",
      "o": "@$1",
      "d": 1572968,
      "h": 42951245928,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951245928),
//--TRIMMABLE-BOUNDARY-START(103080788072),
    {
      "r": 262145,
      "n": "IsApplicationTargeting45",
      "d": 1572968,
      "h": 103080788072,
      "f": 16777249,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        },
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103080788072),
//--TRIMMABLE-BOUNDARY-START(120260657256),
    {
      "r": 65537,
      "n": "RegisterPrefixes",
      "d": 1572968,
      "h": 120260657256,
      "f": 16777249,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        },
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120260657256),
//--TRIMMABLE-BOUNDARY-START(34361311336),
    {
      "r": 1572968,
      "p": [
        {
          "n": "innerStream",
          "p": 95748097
        },
        {
          "n": "subProtocol",
          "p": 1310721
        },
        {
          "n": "receiveBufferSize",
          "p": 655361
        },
        {
          "n": "sendBufferSize",
          "p": 655361
        },
        {
          "n": "keepAliveInterval",
          "p": 186646529
        },
        {
          "n": "useZeroMaskingKey",
          "p": 262145
        },
        {
          "n": "internalBuffer",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        }
      ],
      "n": "CreateClientWebSocket",
      "d": 1572968,
      "h": 34361311336,
      "f": 16777249,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361311336)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540264),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1572968,
      "h": 4296540264,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296540264)
  ],
  "h": 1572968
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocket`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocket`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572968)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900648)
        $asm.$cls(`$snws.SNW.WebSocketDeflateOptions`, ($self) => class WebSocketDeflateOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296867944)
            /*int*/ _clientMaxWindowBits = 15;
            //--TRIMMABLE-BOUNDARY-END(4296867944)
            
            //--TRIMMABLE-BOUNDARY-START(8591835240)
            /*int*/ _serverMaxWindowBits = 15;
            //--TRIMMABLE-BOUNDARY-END(8591835240)
            
            //--TRIMMABLE-BOUNDARY-START(30066671720)
            /*int */ get ClientMaxWindowBits()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246540904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._clientMaxWindowBits;
            }
            /*int */ set ClientMaxWindowBits(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196213864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 9/*WebSocketValidate.MinDeflateWindowBits*/ || value > 15/*WebSocketValidate.MaxDeflateWindowBits*/)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("ClientMaxWindowBits", $.$box(value, $.$$.S.Int32), $.$snws.S.SR.Format$5($.$snws.S.SR.net_WebSockets_ArgumentOutOfRange, $.$box(9/*WebSocketValidate.MinDeflateWindowBits*/, $.$$.S.Int32), $.$box(15/*WebSocketValidate.MaxDeflateWindowBits*/, $.$$.S.Int32)));
                }
                this._clientMaxWindowBits = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30066671720)
            
            //--TRIMMABLE-BOUNDARY-START(25771704424)
            /*bool*/ ClientContextTakeover = false;
            //--TRIMMABLE-BOUNDARY-END(25771704424)
            
            //--TRIMMABLE-BOUNDARY-START(73016344680)
            /*int */ get ServerMaxWindowBits()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426410088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._serverMaxWindowBits;
            }
            /*int */ set ServerMaxWindowBits(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376083048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 9/*WebSocketValidate.MinDeflateWindowBits*/ || value > 15/*WebSocketValidate.MaxDeflateWindowBits*/)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("ServerMaxWindowBits", $.$box(value, $.$$.S.Int32), $.$snws.S.SR.Format$5($.$snws.S.SR.net_WebSockets_ArgumentOutOfRange, $.$box(9/*WebSocketValidate.MinDeflateWindowBits*/, $.$$.S.Int32), $.$box(15/*WebSocketValidate.MaxDeflateWindowBits*/, $.$$.S.Int32)));
                }
                this._serverMaxWindowBits = value;
            }
            //--TRIMMABLE-BOUNDARY-END(73016344680)
            
            //--TRIMMABLE-BOUNDARY-START(68721377384)
            /*bool*/ ServerContextTakeover = false;
            //--TRIMMABLE-BOUNDARY-END(68721377384)
            
            //--TRIMMABLE-BOUNDARY-START(21476737128)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476737128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476737128)
            
            //--TRIMMABLE-BOUNDARY-START(21476737128)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21476737128)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25771704424)
                this.ClientContextTakeover = true;
                //--TRIMMABLE-BOUNDARY-END(25771704424)
                
                //--TRIMMABLE-BOUNDARY-START(68721377384)
                this.ServerContextTakeover = true;
                //--TRIMMABLE-BOUNDARY-END(68721377384)
                
            }
            static $h = 1900648;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066671720),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246540904,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196213864,
        "f": 83886081
      },
      "n": "ClientMaxWindowBits",
      "d": 1900648,
      "h": 30066671720,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066671720),
//--TRIMMABLE-BOUNDARY-START(25771704424),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656606312,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81606279272,
        "f": 83886081
      },
      "n": "ClientContextTakeover",
      "d": 1900648,
      "h": 25771704424,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771704424),
//--TRIMMABLE-BOUNDARY-START(73016344680),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426410088,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107376083048,
        "f": 83886081
      },
      "n": "ServerMaxWindowBits",
      "d": 1900648,
      "h": 73016344680,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016344680),
//--TRIMMABLE-BOUNDARY-START(68721377384),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836475496,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98786148456,
        "f": 83886081
      },
      "n": "ServerContextTakeover",
      "d": 1900648,
      "h": 68721377384,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721377384)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296867944),
    {
      "t": 655361,
      "n": "_clientMaxWindowBits",
      "d": 1900648,
      "h": 4296867944,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296867944),
//--TRIMMABLE-BOUNDARY-START(8591835240),
    {
      "t": 655361,
      "n": "_serverMaxWindowBits",
      "d": 1900648,
      "h": 8591835240,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591835240)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476737128),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1900648,
      "h": 21476737128,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476737128)
  ],
  "h": 1900648
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketDeflateOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketDeflateOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900648)
        
        

        //--TRIMMABLE-BOUNDARY-START(262248)
        $asm.$cls(`$snws.SIC.ZLibNative`, ($self) => class ZLibNative
        {
            //--TRIMMABLE-BOUNDARY-START(786536)
            static $_ZStream;
            static get ZStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SIC.ZLibNative;
                return $cls.$_ZStream ??= $asm.$nstr(`$snws.SIC.ZLibNative.ZStream`, ($self) => class ZStream extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(25770590312)
                    /*IntPtr*/  get nextIn() { return this.$getField(0, $.$$.S.IntPtr); }
                    /*IntPtr*/  set nextIn(value) { this.$setField(0, $.$$.S.IntPtr, value); }
                    //--TRIMMABLE-BOUNDARY-END(25770590312)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065557608)
                    /*IntPtr*/  get nextOut() { return this.$getField(4, $.$$.S.IntPtr); }
                    /*IntPtr*/  set nextOut(value) { this.$setField(4, $.$$.S.IntPtr, value); }
                    //--TRIMMABLE-BOUNDARY-END(30065557608)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475623016)
                    /*IntPtr*/  get msg() { return this.$getField(8, $.$$.S.IntPtr); }
                    /*IntPtr*/  set msg(value) { this.$setField(8, $.$$.S.IntPtr, value); }
                    //--TRIMMABLE-BOUNDARY-END(21475623016)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180655720)
                    /*IntPtr*/  get internalState() { return this.$getField(12, $.$$.S.IntPtr); }
                    /*IntPtr*/  set internalState(value) { this.$setField(12, $.$$.S.IntPtr, value); }
                    //--TRIMMABLE-BOUNDARY-END(17180655720)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590721128)
                    /*uint*/  get availIn() { return this.$getField(16, $.$$.S.UInt32); }
                    /*uint*/  set availIn(value) { this.$setField(16, $.$$.S.UInt32, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590721128)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885688424)
                    /*uint*/  get availOut() { return this.$getField(20, $.$$.S.UInt32); }
                    /*uint*/  set availOut(value) { this.$setField(20, $.$$.S.UInt32, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885688424)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295753832)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295753832);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295753832)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295753832)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295753832)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.nextIn = this.nextIn;
                        copy.nextOut = this.nextOut;
                        copy.msg = this.msg;
                        copy.internalState = this.internalState;
                        copy.availIn = this.availIn;
                        copy.availOut = this.availOut;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(25770590312)
                        this.nextIn = 0;
                        //--TRIMMABLE-BOUNDARY-END(25770590312)
                        
                        //--TRIMMABLE-BOUNDARY-START(30065557608)
                        this.nextOut = 0;
                        //--TRIMMABLE-BOUNDARY-END(30065557608)
                        
                        //--TRIMMABLE-BOUNDARY-START(21475623016)
                        this.msg = 0;
                        //--TRIMMABLE-BOUNDARY-END(21475623016)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180655720)
                        this.internalState = 0;
                        //--TRIMMABLE-BOUNDARY-END(17180655720)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590721128)
                        this.availIn = 0;
                        //--TRIMMABLE-BOUNDARY-END(8590721128)
                        
                        //--TRIMMABLE-BOUNDARY-START(12885688424)
                        this.availOut = 0;
                        //--TRIMMABLE-BOUNDARY-END(12885688424)
                        
                    }
                    static $h = 786536;
                    static $z = 24;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770590312),
    {
      "t": 786433,
      "n": "nextIn",
      "d": 786536,
      "h": 25770590312,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(25770590312),
//--TRIMMABLE-BOUNDARY-START(30065557608),
    {
      "t": 786433,
      "n": "nextOut",
      "d": 786536,
      "h": 30065557608,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(30065557608),
//--TRIMMABLE-BOUNDARY-START(21475623016),
    {
      "t": 786433,
      "n": "msg",
      "d": 786536,
      "h": 21475623016,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21475623016),
//--TRIMMABLE-BOUNDARY-START(17180655720),
    {
      "t": 786433,
      "n": "internalState",
      "d": 786536,
      "h": 17180655720,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180655720),
//--TRIMMABLE-BOUNDARY-START(8590721128),
    {
      "t": 720897,
      "n": "availIn",
      "d": 786536,
      "h": 8590721128,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590721128),
//--TRIMMABLE-BOUNDARY-START(12885688424),
    {
      "t": 720897,
      "n": "availOut",
      "d": 786536,
      "h": 12885688424,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885688424)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753832),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786536,
      "h": 4295753832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753832)
  ],
  "d": 262248,
  "h": 786536,
  "a": [
    {
      "t": 148176897,
      "c": 13033078785,
      "a": [
        {
          "v": 0,
          "t": 143654913
        }
      ],
      "n": [
        {
          "n": "CharSet",
          "v": 2,
          "t": 136773633
        }
      ]
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Compression.ZLibNative+ZStream`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Compression${separator}ZLibNative${separator}ZStream`; }
                }, $cls, ($v) => $cls.$_ZStream = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786536)
            
            //--TRIMMABLE-BOUNDARY-START(327784)
            static $_CompressionLevel;
            static get CompressionLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SIC.ZLibNative;
                return $cls.$_CompressionLevel ??= $asm.$nstr(`$snws.SIC.ZLibNative.CompressionLevel`, ($self) => class CompressionLevel extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static NoCompression = 0;
                    static BestSpeed = 1;
                    static DefaultCompression = -1;
                    static BestCompression = 9;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(327784);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "NoCompression": 0n,
                            "BestSpeed": 1n,
                            "DefaultCompression": 4294967295n,
                            "BestCompression": 9n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4295295080)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295295080);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295295080)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295295080)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295295080)
                    
                    static $h = 327784;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475164264),
    {
      "t": 327784,
      "n": "NoCompression",
      "d": 327784,
      "h": 21475164264,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475164264),
//--TRIMMABLE-BOUNDARY-START(12885229672),
    {
      "t": 327784,
      "n": "BestSpeed",
      "d": 327784,
      "h": 12885229672,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885229672),
//--TRIMMABLE-BOUNDARY-START(17180196968),
    {
      "t": 327784,
      "n": "DefaultCompression",
      "d": 327784,
      "h": 17180196968,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180196968),
//--TRIMMABLE-BOUNDARY-START(8590262376),
    {
      "t": 327784,
      "n": "BestCompression",
      "d": 327784,
      "h": 8590262376,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590262376)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295080),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327784,
      "h": 4295295080,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295080)
  ],
  "d": 262248,
  "h": 327784
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Compression.ZLibNative+CompressionLevel`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Compression${separator}ZLibNative${separator}CompressionLevel`; }
                }, $cls, ($v) => $cls.$_CompressionLevel = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327784)
            
            //--TRIMMABLE-BOUNDARY-START(47244902504)
            /*IntPtr*/ static ZNullPtr = 0;
            //--TRIMMABLE-BOUNDARY-END(47244902504)
            
            //--TRIMMABLE-BOUNDARY-START(589928)
            static $_FlushCode;
            static get FlushCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(589928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SIC.ZLibNative;
                return $cls.$_FlushCode ??= $asm.$nstr(`$snws.SIC.ZLibNative.FlushCode`, ($self) => class FlushCode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static NoFlush = 0;
                    static SyncFlush = 2;
                    static Finish = 4;
                    static Block = 5;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(589928);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "NoFlush": 0n,
                            "SyncFlush": 2n,
                            "Finish": 4n,
                            "Block": 5n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4295557224)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295557224);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295557224)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295557224)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295557224)
                    
                    static $h = 589928;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180459112),
    {
      "t": 589928,
      "n": "NoFlush",
      "d": 589928,
      "h": 17180459112,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180459112),
//--TRIMMABLE-BOUNDARY-START(21475426408),
    {
      "t": 589928,
      "n": "SyncFlush",
      "d": 589928,
      "h": 21475426408,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475426408),
//--TRIMMABLE-BOUNDARY-START(12885491816),
    {
      "t": 589928,
      "n": "Finish",
      "d": 589928,
      "h": 12885491816,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885491816),
//--TRIMMABLE-BOUNDARY-START(8590524520),
    {
      "t": 589928,
      "n": "Block",
      "d": 589928,
      "h": 8590524520,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590524520)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557224),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589928,
      "h": 4295557224,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557224)
  ],
  "d": 262248,
  "h": 589928
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Compression.ZLibNative+FlushCode`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Compression${separator}ZLibNative${separator}FlushCode`; }
                }, $cls, ($v) => $cls.$_FlushCode = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(589928)
            
            //--TRIMMABLE-BOUNDARY-START(524392)
            static $_ErrorCode;
            static get ErrorCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SIC.ZLibNative;
                return $cls.$_ErrorCode ??= $asm.$nstr(`$snws.SIC.ZLibNative.ErrorCode`, ($self) => class ErrorCode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static Ok = 0;
                    static StreamEnd = 1;
                    static StreamError = -2;
                    static DataError = -3;
                    static MemError = -4;
                    static BufError = -5;
                    static VersionError = -6;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(524392);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "Ok": 0n,
                            "StreamEnd": 1n,
                            "StreamError": 4294967294n,
                            "DataError": 4294967293n,
                            "MemError": 4294967292n,
                            "BufError": 4294967291n,
                            "VersionError": 4294967290n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4295491688)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295491688);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295491688)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295491688)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295491688)
                    
                    static $h = 524392;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475360872),
    {
      "t": 524392,
      "n": "Ok",
      "d": 524392,
      "h": 21475360872,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475360872),
//--TRIMMABLE-BOUNDARY-START(25770328168),
    {
      "t": 524392,
      "n": "StreamEnd",
      "d": 524392,
      "h": 25770328168,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328168),
//--TRIMMABLE-BOUNDARY-START(30065295464),
    {
      "t": 524392,
      "n": "StreamError",
      "d": 524392,
      "h": 30065295464,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065295464),
//--TRIMMABLE-BOUNDARY-START(12885426280),
    {
      "t": 524392,
      "n": "DataError",
      "d": 524392,
      "h": 12885426280,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426280),
//--TRIMMABLE-BOUNDARY-START(17180393576),
    {
      "t": 524392,
      "n": "MemError",
      "d": 524392,
      "h": 17180393576,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393576),
//--TRIMMABLE-BOUNDARY-START(8590458984),
    {
      "t": 524392,
      "n": "BufError",
      "d": 524392,
      "h": 8590458984,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590458984),
//--TRIMMABLE-BOUNDARY-START(34360262760),
    {
      "t": 524392,
      "n": "VersionError",
      "d": 524392,
      "h": 34360262760,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360262760)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491688),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524392,
      "h": 4295491688,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491688)
  ],
  "d": 262248,
  "h": 524392
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Compression.ZLibNative+ErrorCode`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Compression${separator}ZLibNative${separator}ErrorCode`; }
                }, $cls, ($v) => $cls.$_ErrorCode = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(524392)
            
            //--TRIMMABLE-BOUNDARY-START(458856)
            static $_CompressionStrategy;
            static get CompressionStrategy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(458856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SIC.ZLibNative;
                return $cls.$_CompressionStrategy ??= $asm.$nstr(`$snws.SIC.ZLibNative.CompressionStrategy`, ($self) => class CompressionStrategy extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static DefaultStrategy = 0;
                    static Filtered = 1;
                    static HuffmanOnly = 2;
                    static RunLengthEncoding = 3;
                    static Fixed = 4;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(458856);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "DefaultStrategy": 0n,
                            "Filtered": 1n,
                            "HuffmanOnly": 2n,
                            "RunLengthEncoding": 3n,
                            "Fixed": 4n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4295426152)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295426152);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295426152)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295426152)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295426152)
                    
                    static $h = 458856;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393448),
    {
      "t": 458856,
      "n": "DefaultStrategy",
      "d": 458856,
      "h": 8590393448,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590393448),
//--TRIMMABLE-BOUNDARY-START(12885360744),
    {
      "t": 458856,
      "n": "Filtered",
      "d": 458856,
      "h": 12885360744,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360744),
//--TRIMMABLE-BOUNDARY-START(21475295336),
    {
      "t": 458856,
      "n": "HuffmanOnly",
      "d": 458856,
      "h": 21475295336,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475295336),
//--TRIMMABLE-BOUNDARY-START(25770262632),
    {
      "t": 458856,
      "n": "RunLengthEncoding",
      "d": 458856,
      "h": 25770262632,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770262632),
//--TRIMMABLE-BOUNDARY-START(17180328040),
    {
      "t": 458856,
      "n": "Fixed",
      "d": 458856,
      "h": 17180328040,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180328040)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426152),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458856,
      "h": 4295426152,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426152)
  ],
  "d": 262248,
  "h": 458856
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Compression.ZLibNative+CompressionStrategy`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Compression${separator}ZLibNative${separator}CompressionStrategy`; }
                }, $cls, ($v) => $cls.$_CompressionStrategy = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(458856)
            
            //--TRIMMABLE-BOUNDARY-START(393320)
            static $_CompressionMethod;
            static get CompressionMethod()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(393320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SIC.ZLibNative;
                return $cls.$_CompressionMethod ??= $asm.$nstr(`$snws.SIC.ZLibNative.CompressionMethod`, ($self) => class CompressionMethod extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static Deflated = 8;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(393320);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "Deflated": 8n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4295360616)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295360616);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295360616)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295360616)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295360616)
                    
                    static $h = 393320;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590327912),
    {
      "t": 393320,
      "n": "Deflated",
      "d": 393320,
      "h": 8590327912,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590327912)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360616),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393320,
      "h": 4295360616,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360616)
  ],
  "d": 262248,
  "h": 393320
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Compression.ZLibNative+CompressionMethod`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Compression${separator}ZLibNative${separator}CompressionMethod`; }
                }, $cls, ($v) => $cls.$_CompressionMethod = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393320)
            
            //--TRIMMABLE-BOUNDARY-START(21475098728)
            /*int*/ static Deflate_DefaultWindowBits = -15;
            //--TRIMMABLE-BOUNDARY-END(21475098728)
            
            //--TRIMMABLE-BOUNDARY-START(42949935208)
            /*int*/ static ZLib_DefaultWindowBits = 15;
            //--TRIMMABLE-BOUNDARY-END(42949935208)
            
            //--TRIMMABLE-BOUNDARY-START(30065033320)
            /*int*/ static GZip_DefaultWindowBits = 31;
            //--TRIMMABLE-BOUNDARY-END(30065033320)
            
            //--TRIMMABLE-BOUNDARY-START(17180131432)
            /*int*/ static Deflate_DefaultMemLevel = 8;
            //--TRIMMABLE-BOUNDARY-END(17180131432)
            
            //--TRIMMABLE-BOUNDARY-START(25770066024)
            /*int*/ static Deflate_NoCompressionMemLevel = 7;
            //--TRIMMABLE-BOUNDARY-END(25770066024)
            
            //--TRIMMABLE-BOUNDARY-START(34360000616)
            /*byte*/ static GZip_Header_ID1 = 31;
            //--TRIMMABLE-BOUNDARY-END(34360000616)
            
            //--TRIMMABLE-BOUNDARY-START(38654967912)
            /*byte*/ static GZip_Header_ID2 = 139;
            //--TRIMMABLE-BOUNDARY-END(38654967912)
            
            //--TRIMMABLE-BOUNDARY-START(655464)
            static $_ZLibStreamHandle;
            static get ZLibStreamHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SIC.ZLibNative;
                return $cls.$_ZLibStreamHandle ??= $asm.$ncls(`$snws.SIC.ZLibNative.ZLibStreamHandle`, ($self) => class ZLibStreamHandle extends $.$$.SRI.SafeHandle
                {
                    //--TRIMMABLE-BOUNDARY-START(721000)
                    static $_State;
                    static get State()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(721000);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $cls = $.$snws.SIC.ZLibNative.ZLibStreamHandle;
                        return $cls.$_State ??= $asm.$nstr(`$snws.SIC.ZLibNative.ZLibStreamHandle.State`, ($self) => class State extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                        {
                            static NotInitialized = 0;
                            static InitializedForDeflate = 1;
                            static InitializedForInflate = 2;
                            static Disposed = 3;
                            static $map;
                            static get Map()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(721000);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.$map ??= 
                                {
                                    "NotInitialized": 0n,
                                    "InitializedForDeflate": 1n,
                                    "InitializedForInflate": 2n,
                                    "Disposed": 3n
                                };
                            }
                            //--TRIMMABLE-BOUNDARY-START(4295688296)
                            //default constructor overload
                            $ctor$3()
                            {
                                super.$ctor$2();
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4295688296);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(4295688296)
                            
                            //--TRIMMABLE-BOUNDARY-START(4295688296)
                            //generic new constructor
                            $gctor()
                            {
                                return this.$ctor$3();
                            }
                            //--TRIMMABLE-BOUNDARY-END(4295688296)
                            
                            static $h = 721000;
                            static $z = 4;
                            static $f = 0b110000011010001001;
                            static $k = 4;
                            static $$b;
                            static get $b() { return this.$$b ??= $.$$.S.Enum; }
                            static get $eut() { return $.$$.S.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475557480),
    {
      "t": 721000,
      "n": "NotInitialized",
      "d": 721000,
      "h": 21475557480,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475557480),
//--TRIMMABLE-BOUNDARY-START(12885622888),
    {
      "t": 721000,
      "n": "InitializedForDeflate",
      "d": 721000,
      "h": 12885622888,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885622888),
//--TRIMMABLE-BOUNDARY-START(17180590184),
    {
      "t": 721000,
      "n": "InitializedForInflate",
      "d": 721000,
      "h": 17180590184,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590184),
//--TRIMMABLE-BOUNDARY-START(8590655592),
    {
      "t": 721000,
      "n": "Disposed",
      "d": 721000,
      "h": 8590655592,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590655592)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688296),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 721000,
      "h": 4295688296,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688296)
  ],
  "d": 655464,
  "h": 721000
}; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                            static $$fullName;
                            static get $fullName() { return this.$$fullName ??= `System.IO.Compression.ZLibNative+ZLibStreamHandle+State`; }
                            static $$getFullName = {};
                            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Compression${separator}ZLibNative${separator}ZLibStreamHandle${separator}State`; }
                        }, $cls, ($v) => $cls.$_State = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(721000)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590590056)
                    /*ZStream*/ _zStream;
                    //--TRIMMABLE-BOUNDARY-END(8590590056)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295622760)
                    /*State*/ _initializationState = 0;
                    //--TRIMMABLE-BOUNDARY-END(4295622760)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557352)
                    $ctor$3()
                    {
                        super.$ctor$2(new $.$$.S.IntPtr().$ctor$3(-1), true);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885557352);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._initializationState = 0/*State.NotInitialized*/;
                            this.SetHandle($.$$.S.IntPtr.Zero);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885557352)
                    
                    //--TRIMMABLE-BOUNDARY-START(124554707048)
                    /*bool */ get IsInvalid()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77310066792);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.handle === new $.$$.S.IntPtr().$ctor$3(-1);
                    }
                    //--TRIMMABLE-BOUNDARY-END(124554707048)
                    
                    //--TRIMMABLE-BOUNDARY-START(120259739752)
                    /*State */ get InitializationState()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68720132200);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._initializationState;
                    }
                    //--TRIMMABLE-BOUNDARY-END(120259739752)
                    
                    //--TRIMMABLE-BOUNDARY-START(137439608936)
                    /*bool */ ReleaseHandle()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(137439608936);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return (() =>
                            {
                                if (this.InitializationState === 0/*State.NotInitialized*/)
                                {
                                    return true;
                                }
                                if (this.InitializationState === 1/*State.InitializedForDeflate*/)
                                {
                                    return (this.DeflateEnd() === 0/*ErrorCode.Ok*/);
                                }
                                if (this.InitializationState === 2/*State.InitializedForInflate*/)
                                {
                                    return (this.InflateEnd() === 0/*ErrorCode.Ok*/);
                                }
                                if (this.InitializationState === 3/*State.Disposed*/)
                                {
                                    return true;
                                }
                                return false;
                            })();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(137439608936)
                    
                    //--TRIMMABLE-BOUNDARY-START(128849674344)
                    /*IntPtr */ get NextIn()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85900001384);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._zStream.nextIn;
                    }
                    /*IntPtr */ set NextIn(value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(163209412712);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._zStream.nextIn = value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(128849674344)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180524648)
                    /*uint */ get AvailIn()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540263016);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._zStream.availIn;
                    }
                    /*uint */ set AvailIn(value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(146029543528);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._zStream.availIn = value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180524648)
                    
                    //--TRIMMABLE-BOUNDARY-START(133144641640)
                    /*IntPtr */ get NextOut()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(94489935976);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._zStream.nextOut;
                    }
                    /*IntPtr */ set NextOut(value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(171799347304);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._zStream.nextOut = value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(133144641640)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475491944)
                    /*uint */ get AvailOut()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60130197608);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._zStream.availOut;
                    }
                    /*uint */ set AvailOut(value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(154619478120);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._zStream.availOut = value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475491944)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655361128)
                    /*void */ EnsureNotDisposed()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655361128);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.S.ObjectDisposedException.ThrowIf(this.InitializationState === 3/*State.Disposed*/, this);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655361128)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950328424)
                    /*void */ EnsureState(/*State*/ requiredState)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950328424);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this.InitializationState !== requiredState)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12("InitializationState != " + $.$strNN($.$$.S.Enum.ToStringT($.$snws.SIC.ZLibNative.ZLibStreamHandle.State, $.$$.S.UInt32, requiredState)));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950328424)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360393832)
                    /*ErrorCode */ DeflateInit2_(/*CompressionLevel*/ level, /*int*/ windowBits, /*int*/ memLevel, /*CompressionStrategy*/ strategy)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360393832);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.EnsureNotDisposed();
                        this.EnsureState(0/*State.NotInitialized*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$snws.SIC.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null, true);
                            /*ErrorCode*/ let errC = $.$snws.Interop.ZLib.DeflateInit2_(stream, level, 8/*CompressionMethod.Deflated*/, windowBits, memLevel, strategy);
                            this._initializationState = 1/*State.InitializedForDeflate*/;
                            return errC;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360393832)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770459240)
                    /*ErrorCode */ Deflate(/*FlushCode*/ flush)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770459240);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.EnsureNotDisposed();
                        this.EnsureState(1/*State.InitializedForDeflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$snws.SIC.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null, true);
                            return $.$snws.Interop.ZLib.Deflate(stream, flush);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770459240)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065426536)
                    /*ErrorCode */ DeflateEnd()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065426536);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.EnsureNotDisposed();
                        this.EnsureState(1/*State.InitializedForDeflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$snws.SIC.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null, true);
                            /*ErrorCode*/ let errC = $.$snws.Interop.ZLib.DeflateEnd(stream);
                            this._initializationState = 3/*State.Disposed*/;
                            return errC;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065426536)
                    
                    //--TRIMMABLE-BOUNDARY-START(111669805160)
                    /*ErrorCode */ InflateInit2_(/*int*/ windowBits)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(111669805160);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.EnsureNotDisposed();
                        this.EnsureState(0/*State.NotInitialized*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$snws.SIC.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null, true);
                            /*ErrorCode*/ let errC = $.$snws.Interop.ZLib.InflateInit2_(stream, windowBits);
                            this._initializationState = 2/*State.InitializedForInflate*/;
                            return errC;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(111669805160)
                    
                    //--TRIMMABLE-BOUNDARY-START(115964772456)
                    /*ErrorCode */ InflateReset2_(/*int*/ windowBits)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(115964772456);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.EnsureNotDisposed();
                        this.EnsureState(2/*State.InitializedForInflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$snws.SIC.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null, true);
                            return $.$snws.Interop.ZLib.InflateReset2_(stream, windowBits);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(115964772456)
                    
                    //--TRIMMABLE-BOUNDARY-START(103079870568)
                    /*ErrorCode */ Inflate(/*FlushCode*/ flush)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(103079870568);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.EnsureNotDisposed();
                        this.EnsureState(2/*State.InitializedForInflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$snws.SIC.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null, true);
                            return $.$snws.Interop.ZLib.Inflate(stream, flush);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(103079870568)
                    
                    //--TRIMMABLE-BOUNDARY-START(107374837864)
                    /*ErrorCode */ InflateEnd()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(107374837864);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.EnsureNotDisposed();
                        this.EnsureState(2/*State.InitializedForInflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$snws.SIC.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null, true);
                            /*ErrorCode*/ let errC = $.$snws.Interop.ZLib.InflateEnd(stream);
                            this._initializationState = 3/*State.Disposed*/;
                            return errC;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(107374837864)
                    
                    //--TRIMMABLE-BOUNDARY-START(98784903272)
                    /*string */ GetErrorMessage()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(98784903272);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._zStream.msg !== $.$snws.SIC.ZLibNative.ZNullPtr ? $.$$.SRI.Marshal.PtrToStringUTF8$1(this._zStream.msg) : $.$$.S.String.Empty;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(98784903272)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557352)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885557352)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590590056)
                        this._zStream = $.$default($.$snws.SIC.ZLibNative.ZStream);
                        //--TRIMMABLE-BOUNDARY-END(8590590056)
                        
                    }
                    static $h = 655464;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.SRI.SafeHandle; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124554707048),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310066792,
        "f": 50364417
      },
      "n": "IsInvalid",
      "d": 655464,
      "h": 124554707048,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(124554707048),
//--TRIMMABLE-BOUNDARY-START(120259739752),
    {
      "p": 721000,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720132200,
        "f": 50331649
      },
      "n": "InitializationState",
      "d": 655464,
      "h": 120259739752,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259739752),
//--TRIMMABLE-BOUNDARY-START(128849674344),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900001384,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209412712,
        "f": 83886081
      },
      "n": "NextIn",
      "d": 655464,
      "h": 128849674344,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849674344),
//--TRIMMABLE-BOUNDARY-START(17180524648),
    {
      "p": 720897,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540263016,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029543528,
        "f": 83886081
      },
      "n": "AvailIn",
      "d": 655464,
      "h": 17180524648,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180524648),
//--TRIMMABLE-BOUNDARY-START(133144641640),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489935976,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799347304,
        "f": 83886081
      },
      "n": "NextOut",
      "d": 655464,
      "h": 133144641640,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144641640),
//--TRIMMABLE-BOUNDARY-START(21475491944),
    {
      "p": 720897,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130197608,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619478120,
        "f": 83886081
      },
      "n": "AvailOut",
      "d": 655464,
      "h": 21475491944,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475491944)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137439608936),
    {
      "r": 262145,
      "n": "ReleaseHandle",
      "d": 655464,
      "h": 137439608936,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(137439608936),
//--TRIMMABLE-BOUNDARY-START(38655361128),
    {
      "r": 65537,
      "n": "EnsureNotDisposed",
      "d": 655464,
      "h": 38655361128,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655361128),
//--TRIMMABLE-BOUNDARY-START(42950328424),
    {
      "r": 65537,
      "p": [
        {
          "n": "requiredState",
          "p": 721000
        }
      ],
      "n": "EnsureState",
      "d": 655464,
      "h": 42950328424,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950328424),
//--TRIMMABLE-BOUNDARY-START(34360393832),
    {
      "r": 524392,
      "p": [
        {
          "n": "level",
          "p": 327784
        },
        {
          "n": "windowBits",
          "p": 655361
        },
        {
          "n": "memLevel",
          "p": 655361
        },
        {
          "n": "strategy",
          "p": 458856
        }
      ],
      "n": "DeflateInit2_",
      "d": 655464,
      "h": 34360393832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360393832),
//--TRIMMABLE-BOUNDARY-START(25770459240),
    {
      "r": 524392,
      "p": [
        {
          "n": "flush",
          "p": 589928
        }
      ],
      "n": "Deflate",
      "d": 655464,
      "h": 25770459240,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770459240),
//--TRIMMABLE-BOUNDARY-START(30065426536),
    {
      "r": 524392,
      "n": "DeflateEnd",
      "d": 655464,
      "h": 30065426536,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065426536),
//--TRIMMABLE-BOUNDARY-START(111669805160),
    {
      "r": 524392,
      "p": [
        {
          "n": "windowBits",
          "p": 655361
        }
      ],
      "n": "InflateInit2_",
      "d": 655464,
      "h": 111669805160,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669805160),
//--TRIMMABLE-BOUNDARY-START(115964772456),
    {
      "r": 524392,
      "p": [
        {
          "n": "windowBits",
          "p": 655361
        }
      ],
      "n": "InflateReset2_",
      "d": 655464,
      "h": 115964772456,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964772456),
//--TRIMMABLE-BOUNDARY-START(103079870568),
    {
      "r": 524392,
      "p": [
        {
          "n": "flush",
          "p": 589928
        }
      ],
      "n": "Inflate",
      "d": 655464,
      "h": 103079870568,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079870568),
//--TRIMMABLE-BOUNDARY-START(107374837864),
    {
      "r": 524392,
      "n": "InflateEnd",
      "d": 655464,
      "h": 107374837864,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374837864),
//--TRIMMABLE-BOUNDARY-START(98784903272),
    {
      "r": 1310721,
      "n": "GetErrorMessage",
      "d": 655464,
      "h": 98784903272,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784903272)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590590056),
    {
      "t": 786536,
      "n": "_zStream",
      "d": 655464,
      "h": 8590590056,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590590056),
//--TRIMMABLE-BOUNDARY-START(4295622760),
    {
      "t": 721000,
      "n": "_initializationState",
      "d": 655464,
      "h": 4295622760,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622760)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885557352),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655464,
      "h": 12885557352,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557352)
  ],
  "d": 262248,
  "h": 655464
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                    static $$n;
                    static get $n() { return this.$$n ??= [ $.$snws.SIC.ZLibNative.ZLibStreamHandle.State ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Compression.ZLibNative+ZLibStreamHandle`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Compression${separator}ZLibNative${separator}ZLibStreamHandle`; }
                }, $cls, ($v) => $cls.$_ZLibStreamHandle = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655464)
            
            //--TRIMMABLE-BOUNDARY-START(8590196840)
            static /*ErrorCode */ CreateZLibStreamForDeflate(/*out ZLibStreamHandle*/ zLibStreamHandle, /*CompressionLevel*/ level, /*int*/ windowBits, /*int*/ memLevel, /*CompressionStrategy*/ strategy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                zLibStreamHandle.$v = new $.$snws.SIC.ZLibNative.ZLibStreamHandle().$ctor$3();
                return zLibStreamHandle.$v.DeflateInit2_(level, windowBits, memLevel, strategy);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196840)
            
            //--TRIMMABLE-BOUNDARY-START(12885164136)
            static /*ErrorCode */ CreateZLibStreamForInflate(/*out ZLibStreamHandle*/ zLibStreamHandle, /*int*/ windowBits)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                zLibStreamHandle.$v = new $.$snws.SIC.ZLibNative.ZLibStreamHandle().$ctor$3();
                return zLibStreamHandle.$v.InflateInit2_(windowBits);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164136)
            
            //--TRIMMABLE-BOUNDARY-START(4295229544)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(47244902504)
                    this.ZNullPtr = $.$$.S.IntPtr.Zero;
                    //--TRIMMABLE-BOUNDARY-END(47244902504)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295229544)
            
            static $h = 262248;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590196840),
    {
      "r": 524392,
      "p": [
        {
          "n": "zLibStreamHandle",
          "p": 655464,
          "f": 2
        },
        {
          "n": "level",
          "p": 327784
        },
        {
          "n": "windowBits",
          "p": 655361
        },
        {
          "n": "memLevel",
          "p": 655361
        },
        {
          "n": "strategy",
          "p": 458856
        }
      ],
      "n": "CreateZLibStreamForDeflate",
      "d": 262248,
      "h": 8590196840,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590196840),
//--TRIMMABLE-BOUNDARY-START(12885164136),
    {
      "r": 524392,
      "p": [
        {
          "n": "zLibStreamHandle",
          "p": 655464,
          "f": 2
        },
        {
          "n": "windowBits",
          "p": 655361
        }
      ],
      "n": "CreateZLibStreamForInflate",
      "d": 262248,
      "h": 12885164136,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885164136)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47244902504),
    {
      "t": 786433,
      "n": "ZNullPtr",
      "d": 262248,
      "h": 47244902504,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47244902504),
//--TRIMMABLE-BOUNDARY-START(21475098728),
    {
      "t": 655361,
      "n": "Deflate_DefaultWindowBits",
      "d": 262248,
      "h": 21475098728,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475098728),
//--TRIMMABLE-BOUNDARY-START(42949935208),
    {
      "t": 655361,
      "n": "ZLib_DefaultWindowBits",
      "d": 262248,
      "h": 42949935208,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949935208),
//--TRIMMABLE-BOUNDARY-START(30065033320),
    {
      "t": 655361,
      "n": "GZip_DefaultWindowBits",
      "d": 262248,
      "h": 30065033320,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065033320),
//--TRIMMABLE-BOUNDARY-START(17180131432),
    {
      "t": 655361,
      "n": "Deflate_DefaultMemLevel",
      "d": 262248,
      "h": 17180131432,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180131432),
//--TRIMMABLE-BOUNDARY-START(25770066024),
    {
      "t": 655361,
      "n": "Deflate_NoCompressionMemLevel",
      "d": 262248,
      "h": 25770066024,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770066024),
//--TRIMMABLE-BOUNDARY-START(34360000616),
    {
      "t": 393217,
      "n": "GZip_Header_ID1",
      "d": 262248,
      "h": 34360000616,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360000616),
//--TRIMMABLE-BOUNDARY-START(38654967912),
    {
      "t": 393217,
      "n": "GZip_Header_ID2",
      "d": 262248,
      "h": 38654967912,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654967912)
  ],
  "h": 262248
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$snws.SIC.ZLibNative.ZStream, $.$snws.SIC.ZLibNative.CompressionLevel, $.$snws.SIC.ZLibNative.FlushCode, $.$snws.SIC.ZLibNative.ErrorCode, $.$snws.SIC.ZLibNative.CompressionStrategy, $.$snws.SIC.ZLibNative.CompressionMethod, $.$snws.SIC.ZLibNative.ZLibStreamHandle ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Compression.ZLibNative`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Compression${separator}ZLibNative`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262248)
        
        

        //--TRIMMABLE-BOUNDARY-START(65640)
        $asm.$cls(`$snws.Interop`, ($self) => class Interop
        {
            //--TRIMMABLE-BOUNDARY-START(196712)
            static $_ZLib;
            static get ZLib()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.Interop;
                return $cls.$_ZLib ??= $asm.$ncls(`$snws.Interop.ZLib`, ($self) => class ZLib
                {
                    //--TRIMMABLE-BOUNDARY-START(17180065896)
                    static /*ZLibNative.ErrorCode */ DeflateInit2_(/*ZLibNative.ZStream**/ stream, /*ZLibNative.CompressionLevel*/ level, /*ZLibNative.CompressionMethod*/ method, /*int*/ windowBits, /*int*/ memLevel, /*ZLibNative.CompressionStrategy*/ strategy)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180065896);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return -2/*ZLibNative.ErrorCode.StreamError*/;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180065896)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590131304)
                    static /*ZLibNative.ErrorCode */ Deflate(/*ZLibNative.ZStream**/ stream, /*ZLibNative.FlushCode*/ flush)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590131304);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return -2/*ZLibNative.ErrorCode.StreamError*/;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590131304)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885098600)
                    static /*ZLibNative.ErrorCode */ DeflateEnd(/*ZLibNative.ZStream**/ stream)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885098600);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return -2/*ZLibNative.ErrorCode.StreamError*/;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885098600)
                    
                    //--TRIMMABLE-BOUNDARY-START(30064967784)
                    static /*ZLibNative.ErrorCode */ InflateInit2_(/*ZLibNative.ZStream**/ stream, /*int*/ windowBits)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30064967784);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return -2/*ZLibNative.ErrorCode.StreamError*/;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30064967784)
                    
                    //--TRIMMABLE-BOUNDARY-START(34359935080)
                    static /*ZLibNative.ErrorCode */ InflateReset2_(/*ZLibNative.ZStream**/ stream, /*int*/ windowBits)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34359935080);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return -2/*ZLibNative.ErrorCode.StreamError*/;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34359935080)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475033192)
                    static /*ZLibNative.ErrorCode */ Inflate(/*ZLibNative.ZStream**/ stream, /*ZLibNative.FlushCode*/ flush)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475033192);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return -2/*ZLibNative.ErrorCode.StreamError*/;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475033192)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770000488)
                    static /*ZLibNative.ErrorCode */ InflateEnd(/*ZLibNative.ZStream**/ stream)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770000488);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return -2/*ZLibNative.ErrorCode.StreamError*/;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770000488)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295164008)
                    static /*uint */ crc32(/*uint*/ crc, /*byte**/ buffer, /*int*/ len)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295164008);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295164008)
                    
                    static $h = 196712;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180065896),
    {
      "r": 524392,
      "p": [
        {
          "n": "stream",
          "p": $.$typePointer($.$snws.SIC.ZLibNative.ZStream).$h
        },
        {
          "n": "level",
          "p": 327784
        },
        {
          "n": "method",
          "p": 393320
        },
        {
          "n": "windowBits",
          "p": 655361
        },
        {
          "n": "memLevel",
          "p": 655361
        },
        {
          "n": "strategy",
          "p": 458856
        }
      ],
      "n": "DeflateInit2_",
      "d": 196712,
      "h": 17180065896,
      "f": 16777256,
      "a": [
        {
          "t": 143785985,
          "c": 25913589761,
          "a": [
            {
              "v": "libSystem.IO.Compression.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "CompressionNative_DeflateInit2_",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180065896),
//--TRIMMABLE-BOUNDARY-START(8590131304),
    {
      "r": 524392,
      "p": [
        {
          "n": "stream",
          "p": $.$typePointer($.$snws.SIC.ZLibNative.ZStream).$h
        },
        {
          "n": "flush",
          "p": 589928
        }
      ],
      "n": "Deflate",
      "d": 196712,
      "h": 8590131304,
      "f": 16777256,
      "a": [
        {
          "t": 143785985,
          "c": 25913589761,
          "a": [
            {
              "v": "libSystem.IO.Compression.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "CompressionNative_Deflate",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590131304),
//--TRIMMABLE-BOUNDARY-START(12885098600),
    {
      "r": 524392,
      "p": [
        {
          "n": "stream",
          "p": $.$typePointer($.$snws.SIC.ZLibNative.ZStream).$h
        }
      ],
      "n": "DeflateEnd",
      "d": 196712,
      "h": 12885098600,
      "f": 16777256,
      "a": [
        {
          "t": 143785985,
          "c": 25913589761,
          "a": [
            {
              "v": "libSystem.IO.Compression.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "CompressionNative_DeflateEnd",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885098600),
//--TRIMMABLE-BOUNDARY-START(30064967784),
    {
      "r": 524392,
      "p": [
        {
          "n": "stream",
          "p": $.$typePointer($.$snws.SIC.ZLibNative.ZStream).$h
        },
        {
          "n": "windowBits",
          "p": 655361
        }
      ],
      "n": "InflateInit2_",
      "d": 196712,
      "h": 30064967784,
      "f": 16777256,
      "a": [
        {
          "t": 143785985,
          "c": 25913589761,
          "a": [
            {
              "v": "libSystem.IO.Compression.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "CompressionNative_InflateInit2_",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30064967784),
//--TRIMMABLE-BOUNDARY-START(34359935080),
    {
      "r": 524392,
      "p": [
        {
          "n": "stream",
          "p": $.$typePointer($.$snws.SIC.ZLibNative.ZStream).$h
        },
        {
          "n": "windowBits",
          "p": 655361
        }
      ],
      "n": "InflateReset2_",
      "d": 196712,
      "h": 34359935080,
      "f": 16777256,
      "a": [
        {
          "t": 143785985,
          "c": 25913589761,
          "a": [
            {
              "v": "libSystem.IO.Compression.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "CompressionNative_InflateReset2_",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34359935080),
//--TRIMMABLE-BOUNDARY-START(21475033192),
    {
      "r": 524392,
      "p": [
        {
          "n": "stream",
          "p": $.$typePointer($.$snws.SIC.ZLibNative.ZStream).$h
        },
        {
          "n": "flush",
          "p": 589928
        }
      ],
      "n": "Inflate",
      "d": 196712,
      "h": 21475033192,
      "f": 16777256,
      "a": [
        {
          "t": 143785985,
          "c": 25913589761,
          "a": [
            {
              "v": "libSystem.IO.Compression.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "CompressionNative_Inflate",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475033192),
//--TRIMMABLE-BOUNDARY-START(25770000488),
    {
      "r": 524392,
      "p": [
        {
          "n": "stream",
          "p": $.$typePointer($.$snws.SIC.ZLibNative.ZStream).$h
        }
      ],
      "n": "InflateEnd",
      "d": 196712,
      "h": 25770000488,
      "f": 16777256,
      "a": [
        {
          "t": 143785985,
          "c": 25913589761,
          "a": [
            {
              "v": "libSystem.IO.Compression.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "CompressionNative_InflateEnd",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770000488),
//--TRIMMABLE-BOUNDARY-START(4295164008),
    {
      "r": 720897,
      "p": [
        {
          "n": "crc",
          "p": 720897
        },
        {
          "n": "buffer",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "len",
          "p": 655361
        }
      ],
      "n": "crc32",
      "d": 196712,
      "h": 4295164008,
      "f": 16777256,
      "a": [
        {
          "t": 143785985,
          "c": 25913589761,
          "a": [
            {
              "v": "libSystem.IO.Compression.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "CompressionNative_Crc32",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295164008)
  ],
  "d": 65640,
  "h": 196712
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Interop+ZLib`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Interop${separator}ZLib`; }
                }, $cls, ($v) => $cls.$_ZLib = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196712)
            
            //--TRIMMABLE-BOUNDARY-START(131176)
            static $_Libraries;
            static get Libraries()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(131176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.Interop;
                return $cls.$_Libraries ??= $asm.$ncls(`$snws.Interop.Libraries`, ($self) => class Libraries
                {
                    //--TRIMMABLE-BOUNDARY-START(25769934952)
                    /*string*/ static libc = null;
                    //--TRIMMABLE-BOUNDARY-END(25769934952)
                    
                    //--TRIMMABLE-BOUNDARY-START(34359869544)
                    /*string*/ static SystemNative = null;
                    //--TRIMMABLE-BOUNDARY-END(34359869544)
                    
                    //--TRIMMABLE-BOUNDARY-START(30064902248)
                    /*string*/ static NetSecurityNative = null;
                    //--TRIMMABLE-BOUNDARY-END(30064902248)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590065768)
                    /*string*/ static CryptoNative = null;
                    //--TRIMMABLE-BOUNDARY-END(8590065768)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295098472)
                    /*string*/ static CompressionNative = null;
                    //--TRIMMABLE-BOUNDARY-END(4295098472)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885033064)
                    /*string*/ static GlobalizationNative = null;
                    //--TRIMMABLE-BOUNDARY-END(12885033064)
                    
                    //--TRIMMABLE-BOUNDARY-START(21474967656)
                    /*string*/ static IOPortsNative = null;
                    //--TRIMMABLE-BOUNDARY-END(21474967656)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180000360)
                    /*string*/ static HostPolicy = null;
                    //--TRIMMABLE-BOUNDARY-END(17180000360)
                    
                    //--TRIMMABLE-BOUNDARY-START(SINIT)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(25769934952)
                            this.libc = "libc";
                            //--TRIMMABLE-BOUNDARY-END(25769934952)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(34359869544)
                            this.SystemNative = "libSystem.Native";
                            //--TRIMMABLE-BOUNDARY-END(34359869544)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(30064902248)
                            this.NetSecurityNative = "libSystem.Net.Security.Native";
                            //--TRIMMABLE-BOUNDARY-END(30064902248)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(8590065768)
                            this.CryptoNative = "libSystem.Security.Cryptography.Native.OpenSsl";
                            //--TRIMMABLE-BOUNDARY-END(8590065768)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(4295098472)
                            this.CompressionNative = "libSystem.IO.Compression.Native";
                            //--TRIMMABLE-BOUNDARY-END(4295098472)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12885033064)
                            this.GlobalizationNative = "libSystem.Globalization.Native";
                            //--TRIMMABLE-BOUNDARY-END(12885033064)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(21474967656)
                            this.IOPortsNative = "libSystem.IO.Ports.Native";
                            //--TRIMMABLE-BOUNDARY-END(21474967656)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(17180000360)
                            this.HostPolicy = "libhostpolicy";
                            //--TRIMMABLE-BOUNDARY-END(17180000360)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(SINIT)
                    
                    static $h = 131176;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(25769934952),
    {
      "t": 1310721,
      "n": "libc",
      "d": 131176,
      "h": 25769934952,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25769934952),
//--TRIMMABLE-BOUNDARY-START(34359869544),
    {
      "t": 1310721,
      "n": "SystemNative",
      "d": 131176,
      "h": 34359869544,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34359869544),
//--TRIMMABLE-BOUNDARY-START(30064902248),
    {
      "t": 1310721,
      "n": "NetSecurityNative",
      "d": 131176,
      "h": 30064902248,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30064902248),
//--TRIMMABLE-BOUNDARY-START(8590065768),
    {
      "t": 1310721,
      "n": "CryptoNative",
      "d": 131176,
      "h": 8590065768,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590065768),
//--TRIMMABLE-BOUNDARY-START(4295098472),
    {
      "t": 1310721,
      "n": "CompressionNative",
      "d": 131176,
      "h": 4295098472,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295098472),
//--TRIMMABLE-BOUNDARY-START(12885033064),
    {
      "t": 1310721,
      "n": "GlobalizationNative",
      "d": 131176,
      "h": 12885033064,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885033064),
//--TRIMMABLE-BOUNDARY-START(21474967656),
    {
      "t": 1310721,
      "n": "IOPortsNative",
      "d": 131176,
      "h": 21474967656,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474967656),
//--TRIMMABLE-BOUNDARY-START(17180000360),
    {
      "t": 1310721,
      "n": "HostPolicy",
      "d": 131176,
      "h": 17180000360,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180000360)
  ],
  "d": 65640,
  "h": 131176
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Interop+Libraries`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Interop${separator}Libraries`; }
                }, $cls, ($v) => $cls.$_Libraries = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(131176)
            
            static $h = 65640;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 65640
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$snws.Interop.ZLib, $.$snws.Interop.Libraries ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Interop`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Interop`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65640)
        
        

        //--TRIMMABLE-BOUNDARY-START(2228328)
        $asm.$cls(`$snws.SNW.WebSocketReceiveResult`, ($self) => class WebSocketReceiveResult extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30066999400)
            $ctor$2(/*int*/ count, /*WebSocketMessageType*/ messageType, /*bool*/ endOfMessage)
            {
                this.$ctor$1(count, messageType, endOfMessage, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066999400);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066999400)
            
            //--TRIMMABLE-BOUNDARY-START(25772032104)
            $ctor$1(/*int*/ count, /*WebSocketMessageType*/ messageType, /*bool*/ endOfMessage, /*WebSocketCloseStatus?*/ closeStatus, /*string?*/ closeStatusDescription)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772032104);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, count, "count");
                    this.Count = count;
                    this.EndOfMessage = endOfMessage;
                    this.MessageType = messageType;
                    this.CloseStatus = closeStatus;
                    this.CloseStatusDescription = closeStatusDescription;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772032104)
            
            //--TRIMMABLE-BOUNDARY-START(42951901288)
            /*int*/ Count = 0;
            //--TRIMMABLE-BOUNDARY-END(42951901288)
            
            //--TRIMMABLE-BOUNDARY-START(47246868584)
            /*bool*/ EndOfMessage = false;
            //--TRIMMABLE-BOUNDARY-END(47246868584)
            
            //--TRIMMABLE-BOUNDARY-START(94491508840)
            /*WebSocketMessageType*/ MessageType = 0;
            //--TRIMMABLE-BOUNDARY-END(94491508840)
            
            //--TRIMMABLE-BOUNDARY-START(34361966696)
            /*WebSocketCloseStatus?*/ CloseStatus = null;
            //--TRIMMABLE-BOUNDARY-END(34361966696)
            
            //--TRIMMABLE-BOUNDARY-START(38656933992)
            /*string?*/ CloseStatusDescription = null;
            //--TRIMMABLE-BOUNDARY-END(38656933992)
            
            static $h = 2228328;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951901288),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016672360,
        "f": 50331649
      },
      "n": "Count",
      "d": 2228328,
      "h": 42951901288,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951901288),
//--TRIMMABLE-BOUNDARY-START(47246868584),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606606952,
        "f": 50331649
      },
      "n": "EndOfMessage",
      "d": 2228328,
      "h": 47246868584,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246868584),
//--TRIMMABLE-BOUNDARY-START(94491508840),
    {
      "p": 2162792,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196541544,
        "f": 50331649
      },
      "n": "MessageType",
      "d": 2228328,
      "h": 94491508840,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94491508840),
//--TRIMMABLE-BOUNDARY-START(34361966696),
    {
      "p": $.$typeNullable($.$snws.SNW.WebSocketCloseStatus).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836803176,
        "f": 50331649
      },
      "n": "CloseStatus",
      "d": 2228328,
      "h": 34361966696,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361966696),
//--TRIMMABLE-BOUNDARY-START(38656933992),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426737768,
        "f": 50331649
      },
      "n": "CloseStatusDescription",
      "d": 2228328,
      "h": 38656933992,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656933992)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066999400),
    {
      "p": [
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "endOfMessage",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2228328,
      "h": 30066999400,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066999400),
//--TRIMMABLE-BOUNDARY-START(25772032104),
    {
      "p": [
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "closeStatus",
          "p": $.$typeNullable($.$snws.SNW.WebSocketCloseStatus).$h
        },
        {
          "n": "closeStatusDescription",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2228328,
      "h": 25772032104,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772032104)
  ],
  "h": 2228328
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketReceiveResult`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketReceiveResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228328)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769576)
        $asm.$cls(`$snws.SNW.WebSocketCreationOptions`, ($self) => class WebSocketCreationOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886671464)
            /*string?*/ _subProtocol = null;
            //--TRIMMABLE-BOUNDARY-END(12886671464)
            
            //--TRIMMABLE-BOUNDARY-START(4296736872)
            /*TimeSpan*/ _keepAliveInterval;
            //--TRIMMABLE-BOUNDARY-END(4296736872)
            
            //--TRIMMABLE-BOUNDARY-START(8591704168)
            /*TimeSpan*/ _keepAliveTimeout;
            //--TRIMMABLE-BOUNDARY-END(8591704168)
            
            //--TRIMMABLE-BOUNDARY-START(77311180904)
            /*bool*/ IsServer = false;
            //--TRIMMABLE-BOUNDARY-END(77311180904)
            
            //--TRIMMABLE-BOUNDARY-START(133145755752)
            /*string? */ get SubProtocol()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016213608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._subProtocol;
            }
            /*string? */ set SubProtocol(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850788456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(value === null))
                {
                    $.$snws.SNW.WebSocketValidate.ValidateSubprotocol(value);
                }
                this._subProtocol = value;
            }
            //--TRIMMABLE-BOUNDARY-END(133145755752)
            
            //--TRIMMABLE-BOUNDARY-START(81606148200)
            /*TimeSpan */ get KeepAliveInterval()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836344424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._keepAliveInterval;
            }
            /*TimeSpan */ set KeepAliveInterval(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670919272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.TimeSpan.op_Inequality(value, $.$$.ST$1.Timeout.InfiniteTimeSpan) && $.$$.S.TimeSpan.op_LessThan(value, $.$$.S.TimeSpan.Zero))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("KeepAliveInterval", value, $.$snws.S.SR.Format$6($.$snws.S.SR.net_WebSockets_ArgumentOutOfRange_TooSmall, $.$box(0, $.$$.S.Int32)));
                }
                this._keepAliveInterval = value;
            }
            //--TRIMMABLE-BOUNDARY-END(81606148200)
            
            //--TRIMMABLE-BOUNDARY-START(85901115496)
            /*TimeSpan */ get KeepAliveTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426279016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._keepAliveTimeout;
            }
            /*TimeSpan */ set KeepAliveTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260853864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.TimeSpan.op_Inequality(value, $.$$.ST$1.Timeout.InfiniteTimeSpan) && $.$$.S.TimeSpan.op_LessThan(value, $.$$.S.TimeSpan.Zero))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("KeepAliveTimeout", value, $.$snws.S.SR.Format$6($.$snws.S.SR.net_WebSockets_ArgumentOutOfRange_TooSmall, $.$box(0, $.$$.S.Int32)));
                }
                this._keepAliveTimeout = value;
            }
            //--TRIMMABLE-BOUNDARY-END(85901115496)
            
            //--TRIMMABLE-BOUNDARY-START(30066540648)
            /*WebSocketDeflateOptions?*/ DangerousDeflateOptions = null;
            //--TRIMMABLE-BOUNDARY-END(30066540648)
            
            //--TRIMMABLE-BOUNDARY-START(25771573352)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771573352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771573352)
            
            //--TRIMMABLE-BOUNDARY-START(25771573352)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25771573352)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296736872)
                this._keepAliveInterval = $.$snws.SNW.WebSocketDefaults.DefaultKeepAliveInterval;
                //--TRIMMABLE-BOUNDARY-END(4296736872)
                
                //--TRIMMABLE-BOUNDARY-START(8591704168)
                this._keepAliveTimeout = $.$snws.SNW.WebSocketDefaults.DefaultKeepAliveTimeout;
                //--TRIMMABLE-BOUNDARY-END(8591704168)
                
            }
            static $h = 1769576;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311180904),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246409832,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080984680,
        "f": 83886081
      },
      "n": "IsServer",
      "d": 1769576,
      "h": 77311180904,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311180904),
//--TRIMMABLE-BOUNDARY-START(133145755752),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016213608,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850788456,
        "f": 83886081
      },
      "n": "SubProtocol",
      "d": 1769576,
      "h": 133145755752,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145755752),
//--TRIMMABLE-BOUNDARY-START(81606148200),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836344424,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670919272,
        "f": 83886081
      },
      "n": "KeepAliveInterval",
      "d": 1769576,
      "h": 81606148200,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606148200),
//--TRIMMABLE-BOUNDARY-START(85901115496),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426279016,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260853864,
        "f": 83886081
      },
      "n": "KeepAliveTimeout",
      "d": 1769576,
      "h": 85901115496,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85901115496),
//--TRIMMABLE-BOUNDARY-START(30066540648),
    {
      "p": 1900648,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656475240,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491050088,
        "f": 83886081
      },
      "n": "DangerousDeflateOptions",
      "d": 1769576,
      "h": 30066540648,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066540648)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886671464),
    {
      "t": 1310721,
      "n": "_subProtocol",
      "d": 1769576,
      "h": 12886671464,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886671464),
//--TRIMMABLE-BOUNDARY-START(4296736872),
    {
      "t": 186646529,
      "n": "_keepAliveInterval",
      "d": 1769576,
      "h": 4296736872,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296736872),
//--TRIMMABLE-BOUNDARY-START(8591704168),
    {
      "t": 186646529,
      "n": "_keepAliveTimeout",
      "d": 1769576,
      "h": 8591704168,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591704168)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771573352),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1769576,
      "h": 25771573352,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771573352)
  ],
  "h": 1769576
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketCreationOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketCreationOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769576)
        
        

        //--TRIMMABLE-BOUNDARY-START(2359400)
        $asm.$cls(`$snws.SNW.WebSocketStateHelper`, ($self) => class WebSocketStateHelper
        {
            //--TRIMMABLE-BOUNDARY-START(30067130472)
            /*ManagedWebSocketStates*/ static ValidSendStates = 20;
            //--TRIMMABLE-BOUNDARY-END(30067130472)
            
            //--TRIMMABLE-BOUNDARY-START(25772163176)
            /*ManagedWebSocketStates*/ static ValidReceiveStates = 12;
            //--TRIMMABLE-BOUNDARY-END(25772163176)
            
            //--TRIMMABLE-BOUNDARY-START(17182228584)
            /*ManagedWebSocketStates*/ static ValidCloseOutputStates = 20;
            //--TRIMMABLE-BOUNDARY-END(17182228584)
            
            //--TRIMMABLE-BOUNDARY-START(21477195880)
            /*ManagedWebSocketStates*/ static ValidCloseStates = 28;
            //--TRIMMABLE-BOUNDARY-END(21477195880)
            
            //--TRIMMABLE-BOUNDARY-START(4297326696)
            static /*bool */ IsValidSendState(/*WebSocketState*/ state)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297326696);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ((20/*ValidSendStates*/ & ($.$snws.SNW.WebSocketStateHelper.ToFlag(state))) == ($.$snws.SNW.WebSocketStateHelper.ToFlag(state)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297326696)
            
            //--TRIMMABLE-BOUNDARY-START(8592293992)
            static /*void */ ThrowIfInvalidState(/*WebSocketState*/ currentState, /*bool*/ isDisposed, /*Exception?*/ innerException, /*ManagedWebSocketStates*/ validStates)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592293992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ManagedWebSocketStates*/ let state = $.$snws.SNW.WebSocketStateHelper.ToFlag(currentState);
                if ((state & validStates) === 0)
                {
                    /*string*/ let invalidStateMessage = $.$snws.S.SR.Format$5($.$snws.S.SR.net_WebSockets_InvalidState, $.$box(currentState, $.$snws.SNW.WebSocketState), $.$box(validStates, $.$snws.SNW.ManagedWebSocketStates));
                    throw new $.$snws.SNW.WebSocketException().$ctor$29(9/*WebSocketError.InvalidState*/, invalidStateMessage, innerException);
                }
                if (!(innerException === null))
                {
                    $.$$.SD.Debug.Assert$4(state === 64/*ManagedWebSocketStates.Aborted*/, "state == ManagedWebSocketStates.Aborted");
                    throw new $.$$.S.OperationCanceledException().$ctor$12("Aborted", innerException);
                }
                $.$$.S.ObjectDisposedException.ThrowIf$1(isDisposed, $.$snws.SNW.WebSocket.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(8592293992)
            
            //--TRIMMABLE-BOUNDARY-START(12887261288)
            static /*ManagedWebSocketStates */ ToFlag(/*WebSocketState*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887261288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ManagedWebSocketStates*/ let flag = $.$cast((1 << value), $.$snws.SNW.ManagedWebSocketStates);
                $.$$.SD.Debug.Assert$4($.$$.S.Enum.IsDefined$1($.$snws.SNW.ManagedWebSocketStates, flag), "Enum.IsDefined(flag)");
                return flag;
            }
            //--TRIMMABLE-BOUNDARY-END(12887261288)
            
            static $h = 2359400;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297326696),
    {
      "r": 262145,
      "p": [
        {
          "n": "state",
          "p": 2293864
        }
      ],
      "n": "IsValidSendState",
      "d": 2359400,
      "h": 4297326696,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297326696),
//--TRIMMABLE-BOUNDARY-START(8592293992),
    {
      "r": 65537,
      "p": [
        {
          "n": "currentState",
          "p": 2293864
        },
        {
          "n": "isDisposed",
          "p": 262145
        },
        {
          "n": "innerException",
          "p": 80805889
        },
        {
          "n": "validStates",
          "p": 1441896
        }
      ],
      "n": "ThrowIfInvalidState",
      "d": 2359400,
      "h": 8592293992,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8592293992),
//--TRIMMABLE-BOUNDARY-START(12887261288),
    {
      "r": 1441896,
      "p": [
        {
          "n": "value",
          "p": 2293864
        }
      ],
      "n": "ToFlag",
      "d": 2359400,
      "h": 12887261288,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12887261288)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30067130472),
    {
      "t": 1441896,
      "n": "ValidSendStates",
      "d": 2359400,
      "h": 30067130472,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30067130472),
//--TRIMMABLE-BOUNDARY-START(25772163176),
    {
      "t": 1441896,
      "n": "ValidReceiveStates",
      "d": 2359400,
      "h": 25772163176,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25772163176),
//--TRIMMABLE-BOUNDARY-START(17182228584),
    {
      "t": 1441896,
      "n": "ValidCloseOutputStates",
      "d": 2359400,
      "h": 17182228584,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17182228584),
//--TRIMMABLE-BOUNDARY-START(21477195880),
    {
      "t": 1441896,
      "n": "ValidCloseStates",
      "d": 2359400,
      "h": 21477195880,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21477195880)
  ],
  "h": 2359400
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketStateHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketStateHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359400)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835112)
        $asm.$cls(`$snws.SNW.WebSocketDefaults`, ($self) => class WebSocketDefaults
        {
            //--TRIMMABLE-BOUNDARY-START(12886737000)
            /*TimeSpan*/ static DefaultKeepAliveInterval;
            //--TRIMMABLE-BOUNDARY-END(12886737000)
            
            //--TRIMMABLE-BOUNDARY-START(8591769704)
            /*TimeSpan*/ static DefaultClientKeepAliveInterval;
            //--TRIMMABLE-BOUNDARY-END(8591769704)
            
            //--TRIMMABLE-BOUNDARY-START(17181704296)
            /*TimeSpan*/ static DefaultKeepAliveTimeout;
            //--TRIMMABLE-BOUNDARY-END(17181704296)
            
            //--TRIMMABLE-BOUNDARY-START(4296802408)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296802408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12886737000)
                    this.DefaultKeepAliveInterval = $.$$.S.TimeSpan.Zero;
                    //--TRIMMABLE-BOUNDARY-END(12886737000)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591769704)
                    this.DefaultClientKeepAliveInterval = $.$$.S.TimeSpan.FromSeconds$2(30n);
                    //--TRIMMABLE-BOUNDARY-END(8591769704)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181704296)
                    this.DefaultKeepAliveTimeout = $.$$.ST$1.Timeout.InfiniteTimeSpan;
                    //--TRIMMABLE-BOUNDARY-END(17181704296)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296802408)
            
            static $h = 1835112;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886737000),
    {
      "t": 186646529,
      "n": "DefaultKeepAliveInterval",
      "d": 1835112,
      "h": 12886737000,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886737000),
//--TRIMMABLE-BOUNDARY-START(8591769704),
    {
      "t": 186646529,
      "n": "DefaultClientKeepAliveInterval",
      "d": 1835112,
      "h": 8591769704,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591769704),
//--TRIMMABLE-BOUNDARY-START(17181704296),
    {
      "t": 186646529,
      "n": "DefaultKeepAliveTimeout",
      "d": 1835112,
      "h": 17181704296,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181704296)
  ],
  "h": 1835112
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketDefaults`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketDefaults`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835112)
        
        

        //--TRIMMABLE-BOUNDARY-START(2687080)
        $asm.$cls(`$snws.SNW.WebSocketValidate`, ($self) => class WebSocketValidate
        {
            //--TRIMMABLE-BOUNDARY-START(34362425448)
            /*int*/ static MinDeflateWindowBits = 9;
            //--TRIMMABLE-BOUNDARY-END(34362425448)
            
            //--TRIMMABLE-BOUNDARY-START(30067458152)
            /*int*/ static MaxDeflateWindowBits = 15;
            //--TRIMMABLE-BOUNDARY-END(30067458152)
            
            //--TRIMMABLE-BOUNDARY-START(25772490856)
            /*int*/ static MaxControlFramePayloadLength = 123;
            //--TRIMMABLE-BOUNDARY-END(25772490856)
            
            //--TRIMMABLE-BOUNDARY-START(8592621672)
            /*int*/ static CloseStatusCodeAbort = 1006;
            //--TRIMMABLE-BOUNDARY-END(8592621672)
            
            //--TRIMMABLE-BOUNDARY-START(12887588968)
            /*int*/ static CloseStatusCodeFailedTLSHandshake = 1015;
            //--TRIMMABLE-BOUNDARY-END(12887588968)
            
            //--TRIMMABLE-BOUNDARY-START(17182556264)
            /*int*/ static InvalidCloseStatusCodesFrom = 0;
            //--TRIMMABLE-BOUNDARY-END(17182556264)
            
            //--TRIMMABLE-BOUNDARY-START(21477523560)
            /*int*/ static InvalidCloseStatusCodesTo = 999;
            //--TRIMMABLE-BOUNDARY-END(21477523560)
            
            //--TRIMMABLE-BOUNDARY-START(38657392744)
            /*SearchValues<char>*/ static s_validSubprotocolChars = null;
            //--TRIMMABLE-BOUNDARY-END(38657392744)
            
            //--TRIMMABLE-BOUNDARY-START(55837261928)
            static /*void */ ValidateSubprotocol(/*string*/ subProtocol)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837261928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentException.ThrowIfNullOrWhiteSpace(subProtocol, "subProtocol");
                /*int*/ let indexOfInvalidChar = $.$$.S.MemoryExtensions.IndexOfAnyExcept($.$$.S.Char, $.$$.S.MemoryExtensions.AsSpan$4(subProtocol), $.$snws.SNW.WebSocketValidate.s_validSubprotocolChars);
                if (indexOfInvalidChar >= 0)
                {
                    /*char*/ let invalidChar = $.$$.S.String.get_Chars.call(subProtocol, indexOfInvalidChar);
                    /*string*/ let invalidCharDescription = $.$$.S.Char.IsBetween$1(invalidChar, 33, 126) ? $.$$.S.Char.ToString.call(invalidChar) : `[${$.$strNN($.$cast(invalidChar, $.$$.S.Int32))}]`;
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snws.S.SR.Format$5($.$snws.S.SR.net_WebSockets_InvalidCharInProtocolString, subProtocol, invalidCharDescription), "subProtocol");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55837261928)
            
            //--TRIMMABLE-BOUNDARY-START(51542294632)
            static /*void */ ValidateCloseStatus(/*WebSocketCloseStatus*/ closeStatus, /*string?*/ statusDescription)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542294632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (closeStatus === 1005/*WebSocketCloseStatus.Empty*/ && !$.$$.S.String.IsNullOrEmpty(statusDescription))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snws.S.SR.Format$5($.$snws.S.SR.net_WebSockets_ReasonNotNull, statusDescription, $.$box(1005/*WebSocketCloseStatus.Empty*/, $.$snws.SNW.WebSocketCloseStatus)), "statusDescription");
                }
                /*int*/ let closeStatusCode = closeStatus;
                if ((closeStatusCode >= 0/*InvalidCloseStatusCodesFrom*/ && closeStatusCode <= 999/*InvalidCloseStatusCodesTo*/) || closeStatusCode === 1006/*CloseStatusCodeAbort*/ || closeStatusCode === 1015/*CloseStatusCodeFailedTLSHandshake*/)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snws.S.SR.Format$6($.$snws.S.SR.net_WebSockets_InvalidCloseStatusCode, $.$box(closeStatusCode, $.$$.S.Int32)), "closeStatus");
                }
                if (!$.$$.S.String.IsNullOrEmpty(statusDescription) && $.$$.ST.Encoding.UTF8.GetMaxByteCount(statusDescription.length) > 123/*MaxControlFramePayloadLength*/ && $.$$.ST.Encoding.UTF8.GetByteCount$6(statusDescription) > 123/*MaxControlFramePayloadLength*/)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$snws.S.SR.Format$5($.$snws.S.SR.net_WebSockets_InvalidCloseStatusDescription, statusDescription, $.$box(123/*MaxControlFramePayloadLength*/, $.$$.S.Int32)), "statusDescription");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51542294632)
            
            //--TRIMMABLE-BOUNDARY-START(42952360040)
            static /*void */ ValidateArraySegment(/*ArraySegment<byte>*/ arraySegment, /*string*/ parameterName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952360040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!$.$$.S.String.IsNullOrEmpty(parameterName), "'parameterName' MUST NOT be NULL or string.Empty");
                if (arraySegment.Array === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19($.$strNN(parameterName) + "." + $.$strNN("Array"));
                }
                if (arraySegment.Offset < 0 || arraySegment.Offset > arraySegment.Array.length)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20($.$strNN(parameterName) + "." + $.$strNN("Offset"));
                }
                if (arraySegment.Count < 0 || arraySegment.Count > (((arraySegment.Array.length - arraySegment.Offset) | 0)))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20($.$strNN(parameterName) + "." + $.$strNN("Count"));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42952360040)
            
            //--TRIMMABLE-BOUNDARY-START(47247327336)
            static /*void */ ValidateBuffer(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247327336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(buffer, "buffer");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, offset, "offset");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.S.Int32, offset, buffer.length, "offset");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, count, "count");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.S.Int32, count, ((buffer.length - offset) | 0), "count");
            }
            //--TRIMMABLE-BOUNDARY-END(47247327336)
            
            //--TRIMMABLE-BOUNDARY-START(4297654376)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297654376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(38657392744)
                    this.s_validSubprotocolChars = $.$$.SB.SearchValues.Create$1($.$$.S.String.op_Implicit("!#$%&'*+-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ^_`abcdefghijklmnopqrstuvwxyz|~"));
                    //--TRIMMABLE-BOUNDARY-END(38657392744)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297654376)
            
            static $h = 2687080;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(55837261928),
    {
      "r": 65537,
      "p": [
        {
          "n": "subProtocol",
          "p": 1310721
        }
      ],
      "n": "ValidateSubprotocol",
      "d": 2687080,
      "h": 55837261928,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55837261928),
//--TRIMMABLE-BOUNDARY-START(51542294632),
    {
      "r": 65537,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "statusDescription",
          "p": 1310721
        }
      ],
      "n": "ValidateCloseStatus",
      "d": 2687080,
      "h": 51542294632,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51542294632),
//--TRIMMABLE-BOUNDARY-START(42952360040),
    {
      "r": 65537,
      "p": [
        {
          "n": "arraySegment",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": "ValidateArraySegment",
      "d": 2687080,
      "h": 42952360040,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42952360040),
//--TRIMMABLE-BOUNDARY-START(47247327336),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ValidateBuffer",
      "d": 2687080,
      "h": 47247327336,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47247327336)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34362425448),
    {
      "t": 655361,
      "n": "MinDeflateWindowBits",
      "d": 2687080,
      "h": 34362425448,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34362425448),
//--TRIMMABLE-BOUNDARY-START(30067458152),
    {
      "t": 655361,
      "n": "MaxDeflateWindowBits",
      "d": 2687080,
      "h": 30067458152,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30067458152),
//--TRIMMABLE-BOUNDARY-START(25772490856),
    {
      "t": 655361,
      "n": "MaxControlFramePayloadLength",
      "d": 2687080,
      "h": 25772490856,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25772490856),
//--TRIMMABLE-BOUNDARY-START(8592621672),
    {
      "t": 655361,
      "n": "CloseStatusCodeAbort",
      "d": 2687080,
      "h": 8592621672,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8592621672),
//--TRIMMABLE-BOUNDARY-START(12887588968),
    {
      "t": 655361,
      "n": "CloseStatusCodeFailedTLSHandshake",
      "d": 2687080,
      "h": 12887588968,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12887588968),
//--TRIMMABLE-BOUNDARY-START(17182556264),
    {
      "t": 655361,
      "n": "InvalidCloseStatusCodesFrom",
      "d": 2687080,
      "h": 17182556264,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17182556264),
//--TRIMMABLE-BOUNDARY-START(21477523560),
    {
      "t": 655361,
      "n": "InvalidCloseStatusCodesTo",
      "d": 2687080,
      "h": 21477523560,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21477523560),
//--TRIMMABLE-BOUNDARY-START(38657392744),
    {
      "t": $.$$.SB.SearchValues$$($.$$.S.Char).$h,
      "n": "s_validSubprotocolChars",
      "d": 2687080,
      "h": 38657392744,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38657392744)
  ],
  "h": 2687080
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketValidate`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketValidate`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2687080)
        
        

        //--TRIMMABLE-BOUNDARY-START(2818152)
        $asm.$cls(`$snws.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(648542879848)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(648542879848)
            
            //--TRIMMABLE-BOUNDARY-START(476744188008)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(476744188008);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(476744188008)
            
            //--TRIMMABLE-BOUNDARY-START(661427781736)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(661427781736);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snws.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(661427781736)
            
            //--TRIMMABLE-BOUNDARY-START(472449220712)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472449220712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$snws.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(472449220712)
            
            //--TRIMMABLE-BOUNDARY-START(468154253416)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468154253416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$snws.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(468154253416)
            
            //--TRIMMABLE-BOUNDARY-START(38657523816)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657523816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38657523816)
            
            //--TRIMMABLE-BOUNDARY-START(34362556520)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362556520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34362556520)
            
            //--TRIMMABLE-BOUNDARY-START(30067589224)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067589224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30067589224)
            
            //--TRIMMABLE-BOUNDARY-START(42952491112)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952491112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$snws.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42952491112)
            
            //--TRIMMABLE-BOUNDARY-START(21477654632)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477654632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(21477654632)
            
            //--TRIMMABLE-BOUNDARY-START(17182687336)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182687336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(17182687336)
            
            //--TRIMMABLE-BOUNDARY-START(12887720040)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887720040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(12887720040)
            
            //--TRIMMABLE-BOUNDARY-START(25772621928)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772621928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$snws.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(25772621928)
            
            //--TRIMMABLE-BOUNDARY-START(644247912552)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(644247912552)
            
            //--TRIMMABLE-BOUNDARY-START(635657977960)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(635657977960)
            
            //--TRIMMABLE-BOUNDARY-START(639952945256)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420909613160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$snws.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.Net.WebSockets", $.$snws.S.SR.$type.Assembly);
                    $.$snws.S.SR.s_resourceManager = temp;
                }
                return $.$snws.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(639952945256)
            
            //--TRIMMABLE-BOUNDARY-START(8592752744)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082033256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$snws.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(657132814440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$snws.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8592752744)
            
            //--TRIMMABLE-BOUNDARY-START(554053599336)
            static /*string */ get net_WebSockets_InvalidState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266290790504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket is in an invalid state ('{0}') for this operation. Valid states are: '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(554053599336)
            
            //--TRIMMABLE-BOUNDARY-START(81607196776)
            static /*string */ Formatnet_WebSockets_InvalidState(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81607196776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The WebSocket is in an invalid state ('{0}') for this operation. Valid states are: '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(81607196776)
            
            //--TRIMMABLE-BOUNDARY-START(519693860968)
            static /*string */ get net_WebSockets_Generic()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188981379176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An internal WebSocket error occurred. Please see the innerException, if present, for more details. ";
            }
            //--TRIMMABLE-BOUNDARY-END(519693860968)
            
            //--TRIMMABLE-BOUNDARY-START(545463664744)
            static /*string */ get net_WebSockets_InvalidMessageType_Generic()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240520986728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The received  message type is invalid after calling {0}. {0} should only be used if no more data is expected from the remote endpoint. Use '{1}' instead to keep being able to receive data but close the output channel.";
            }
            //--TRIMMABLE-BOUNDARY-END(545463664744)
            
            //--TRIMMABLE-BOUNDARY-START(77312229480)
            static /*string */ Formatnet_WebSockets_InvalidMessageType_Generic(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312229480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$7("The received  message type is invalid after calling {0}. {0} should only be used if no more data is expected from the remote endpoint. Use '{1}' instead to keep being able to receive data but close the output channel.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(77312229480)
            
            //--TRIMMABLE-BOUNDARY-START(618478108776)
            static /*string */ get net_Websockets_WebSocketBaseFaulted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386549874792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An exception caused the WebSocket to enter the Aborted state. Please see the InnerException, if present, for more details.";
            }
            //--TRIMMABLE-BOUNDARY-END(618478108776)
            
            //--TRIMMABLE-BOUNDARY-START(571233468520)
            static /*string */ get net_WebSockets_NotAWebSocket_Generic()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292060594280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A WebSocket operation was called on a request or response that is not a WebSocket.";
            }
            //--TRIMMABLE-BOUNDARY-END(571233468520)
            
            //--TRIMMABLE-BOUNDARY-START(614183141480)
            static /*string */ get net_WebSockets_UnsupportedWebSocketVersion_Generic()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377959940200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported WebSocket version.";
            }
            //--TRIMMABLE-BOUNDARY-END(614183141480)
            
            //--TRIMMABLE-BOUNDARY-START(609888174184)
            static /*string */ get net_WebSockets_UnsupportedProtocol_Generic()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369370005608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket request or response operation was called with unsupported protocol(s). ";
            }
            //--TRIMMABLE-BOUNDARY-END(609888174184)
            
            //--TRIMMABLE-BOUNDARY-START(523988828264)
            static /*string */ get net_WebSockets_HeaderError_Generic()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197571313768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket request or response contained unsupported header(s). ";
            }
            //--TRIMMABLE-BOUNDARY-END(523988828264)
            
            //--TRIMMABLE-BOUNDARY-START(506808959080)
            static /*string */ get net_WebSockets_ConnectionClosedPrematurely_Generic()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211575400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The remote party closed the WebSocket connection without completing the close handshake.";
            }
            //--TRIMMABLE-BOUNDARY-END(506808959080)
            
            //--TRIMMABLE-BOUNDARY-START(558348566632)
            static /*string */ get net_WebSockets_InvalidState_Generic()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257700855912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket instance cannot be used for communication because it has been transitioned into an invalid state.";
            }
            //--TRIMMABLE-BOUNDARY-END(558348566632)
            
            //--TRIMMABLE-BOUNDARY-START(498219024488)
            static /*string */ get net_WebSockets_ArgumentOutOfRange_TooSmall()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441771624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The argument must be a value greater than {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(498219024488)
            
            //--TRIMMABLE-BOUNDARY-START(55837393000)
            static /*string */ Formatnet_WebSockets_ArgumentOutOfRange_TooSmall(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837393000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The argument must be a value greater than {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(55837393000)
            
            //--TRIMMABLE-BOUNDARY-START(528283795560)
            static /*string */ get net_WebSockets_InvalidCharInProtocolString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206161248360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket protocol '{0}' is invalid because it contains the invalid character '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(528283795560)
            
            //--TRIMMABLE-BOUNDARY-START(64427327592)
            static /*string */ Formatnet_WebSockets_InvalidCharInProtocolString(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427327592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The WebSocket protocol '{0}' is invalid because it contains the invalid character '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(64427327592)
            
            //--TRIMMABLE-BOUNDARY-START(584118370408)
            static /*string */ get net_WebSockets_ReasonNotNull()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317830398056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The close status description '{0}' is invalid. When using close status code '{1}' the description must be null.";
            }
            //--TRIMMABLE-BOUNDARY-END(584118370408)
            
            //--TRIMMABLE-BOUNDARY-START(85902164072)
            static /*string */ Formatnet_WebSockets_ReasonNotNull(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902164072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The close status description '{0}' is invalid. When using close status code '{1}' the description must be null.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(85902164072)
            
            //--TRIMMABLE-BOUNDARY-START(532578762856)
            static /*string */ get net_WebSockets_InvalidCloseStatusCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214751182952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The close status code '{0}' is reserved for system use only and cannot be specified when calling this method.";
            }
            //--TRIMMABLE-BOUNDARY-END(532578762856)
            
            //--TRIMMABLE-BOUNDARY-START(68722294888)
            static /*string */ Formatnet_WebSockets_InvalidCloseStatusCode(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722294888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The close status code '{0}' is reserved for system use only and cannot be specified when calling this method.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(68722294888)
            
            //--TRIMMABLE-BOUNDARY-START(536873730152)
            static /*string */ get net_WebSockets_InvalidCloseStatusDescription()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223341117544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The close status description '{0}' is too long. The UTF-8 representation of the status description must not be longer than {1} bytes.";
            }
            //--TRIMMABLE-BOUNDARY-END(536873730152)
            
            //--TRIMMABLE-BOUNDARY-START(73017262184)
            static /*string */ Formatnet_WebSockets_InvalidCloseStatusDescription(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017262184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The close status description '{0}' is too long. The UTF-8 representation of the status description must not be longer than {1} bytes.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(73017262184)
            
            //--TRIMMABLE-BOUNDARY-START(605593206888)
            static /*string */ get net_WebSockets_UnsupportedPlatform()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360780071016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket protocol is not supported on this platform.";
            }
            //--TRIMMABLE-BOUNDARY-END(605593206888)
            
            //--TRIMMABLE-BOUNDARY-START(485334122600)
            static /*string */ get net_WebSockets_Argument_InvalidMessageType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261902440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The message type '{0}' is not allowed for the '{1}' operation. Valid message types are: '{2}, {3}'. To close the WebSocket, use the '{4}' operation instead. ";
            }
            //--TRIMMABLE-BOUNDARY-END(485334122600)
            
            //--TRIMMABLE-BOUNDARY-START(51542425704)
            static /*string */ Formatnet_WebSockets_Argument_InvalidMessageType(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4, /*object*/ arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542425704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$11("The message type '{0}' is not allowed for the '{1}' operation. Valid message types are: '{2}, {3}'. To close the WebSocket, use the '{4}' operation instead. ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ arg1, arg2, arg3, arg4, arg5 ]));
            }
            //--TRIMMABLE-BOUNDARY-END(51542425704)
            
            //--TRIMMABLE-BOUNDARY-START(481039155304)
            static /*string */ get net_Websockets_AlreadyOneOutstandingOperation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671967848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "There is already one outstanding '{0}' call for this WebSocket instance. ReceiveAsync and SendAsync can be called simultaneously, but at most one outstanding operation for each of them is allowed at the same time.";
            }
            //--TRIMMABLE-BOUNDARY-END(481039155304)
            
            //--TRIMMABLE-BOUNDARY-START(47247458408)
            static /*string */ Formatnet_Websockets_AlreadyOneOutstandingOperation(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247458408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("There is already one outstanding '{0}' call for this WebSocket instance. ReceiveAsync and SendAsync can be called simultaneously, but at most one outstanding operation for each of them is allowed at the same time.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(47247458408)
            
            //--TRIMMABLE-BOUNDARY-START(588413337704)
            static /*string */ get net_Websockets_ReservedBitsSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326420332648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket received a frame with one or more reserved bits set.";
            }
            //--TRIMMABLE-BOUNDARY-END(588413337704)
            
            //--TRIMMABLE-BOUNDARY-START(502513991784)
            static /*string */ get net_Websockets_ClientReceivedMaskedFrame()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621640808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket server sent a masked frame.";
            }
            //--TRIMMABLE-BOUNDARY-END(502513991784)
            
            //--TRIMMABLE-BOUNDARY-START(592708305000)
            static /*string */ get net_Websockets_ServerReceivedUnmaskedFrame()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335010267240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket client sent an unmasked frame.";
            }
            //--TRIMMABLE-BOUNDARY-END(592708305000)
            
            //--TRIMMABLE-BOUNDARY-START(511103926376)
            static /*string */ get net_Websockets_ContinuationFromFinalFrame()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801509992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket received a continuation frame from a previous final message.";
            }
            //--TRIMMABLE-BOUNDARY-END(511103926376)
            
            //--TRIMMABLE-BOUNDARY-START(566938501224)
            static /*string */ get net_Websockets_NonContinuationAfterNonFinalFrame()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283470659688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket expected a continuation frame after having received a previous non-final frame.";
            }
            //--TRIMMABLE-BOUNDARY-END(566938501224)
            
            //--TRIMMABLE-BOUNDARY-START(541168697448)
            static /*string */ get net_Websockets_InvalidControlMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231931052136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket received an invalid control message.";
            }
            //--TRIMMABLE-BOUNDARY-END(541168697448)
            
            //--TRIMMABLE-BOUNDARY-START(601298239592)
            static /*string */ get net_Websockets_UnknownOpcode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352190136424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket received a frame with an unknown opcode: '0x{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(601298239592)
            
            //--TRIMMABLE-BOUNDARY-START(90197131368)
            static /*string */ Formatnet_Websockets_UnknownOpcode(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197131368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The WebSocket received a frame with an unknown opcode: '0x{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(90197131368)
            
            //--TRIMMABLE-BOUNDARY-START(622773076072)
            static /*string */ get NotReadableStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395139809384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The base stream is not readable.";
            }
            //--TRIMMABLE-BOUNDARY-END(622773076072)
            
            //--TRIMMABLE-BOUNDARY-START(627068043368)
            static /*string */ get NotWriteableStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403729743976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The base stream is not writeable.";
            }
            //--TRIMMABLE-BOUNDARY-END(627068043368)
            
            //--TRIMMABLE-BOUNDARY-START(493924057192)
            static /*string */ get net_WebSockets_ArgumentOutOfRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031706216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The argument must be a value between {0} and {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(493924057192)
            
            //--TRIMMABLE-BOUNDARY-START(60132360296)
            static /*string */ Formatnet_WebSockets_ArgumentOutOfRange(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132360296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("The argument must be a value between {0} and {1}.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(60132360296)
            
            //--TRIMMABLE-BOUNDARY-START(597003272296)
            static /*string */ get net_WebSockets_TimeoutOutOfRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343600201832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The timeout must be a value between non-negative or Timeout.InfiniteTimeSpan.";
            }
            //--TRIMMABLE-BOUNDARY-END(597003272296)
            
            //--TRIMMABLE-BOUNDARY-START(562643533928)
            static /*string */ get net_Websockets_KeepAlivePingTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274880725096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket didn't recieve a Pong frame in response to a Ping frame within the configured KeepAliveTimeout.";
            }
            //--TRIMMABLE-BOUNDARY-END(562643533928)
            
            //--TRIMMABLE-BOUNDARY-START(575528435816)
            static /*string */ get net_Websockets_PerMessageCompressedFlagInContinuation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300650528872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket received a continuation frame with Per-Message Compressed flag set.";
            }
            //--TRIMMABLE-BOUNDARY-END(575528435816)
            
            //--TRIMMABLE-BOUNDARY-START(579823403112)
            static /*string */ get net_Websockets_PerMessageCompressedFlagWhenNotEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309240463464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket received compressed frame when compression is not enabled.";
            }
            //--TRIMMABLE-BOUNDARY-END(579823403112)
            
            //--TRIMMABLE-BOUNDARY-START(665722749032)
            static /*string */ get ZLibErrorDLLLoadError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429499547752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The underlying compression routine could not be loaded correctly.";
            }
            //--TRIMMABLE-BOUNDARY-END(665722749032)
            
            //--TRIMMABLE-BOUNDARY-START(670017716328)
            static /*string */ get ZLibErrorInconsistentStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438089482344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The stream state of the underlying compression routine is inconsistent.";
            }
            //--TRIMMABLE-BOUNDARY-END(670017716328)
            
            //--TRIMMABLE-BOUNDARY-START(674312683624)
            static /*string */ get ZLibErrorNotEnoughMemory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446679416936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The underlying compression routine could not reserve sufficient memory.";
            }
            //--TRIMMABLE-BOUNDARY-END(674312683624)
            
            //--TRIMMABLE-BOUNDARY-START(678607650920)
            static /*string */ get ZLibErrorUnexpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455269351528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The underlying compression routine returned an unexpected error code {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(678607650920)
            
            //--TRIMMABLE-BOUNDARY-START(94492098664)
            static /*string */ FormatZLibErrorUnexpected(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492098664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The underlying compression routine returned an unexpected error code {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(94492098664)
            
            //--TRIMMABLE-BOUNDARY-START(682902618216)
            static /*string */ get ZLibUnsupportedCompression()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463859286120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The message was compressed using an unsupported compression method.";
            }
            //--TRIMMABLE-BOUNDARY-END(682902618216)
            
            //--TRIMMABLE-BOUNDARY-START(515398893672)
            static /*string */ get net_WebSockets_DataAfterBFinal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391444584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Data received after the DEFLATE stream was terminated with BFINAL.";
            }
            //--TRIMMABLE-BOUNDARY-END(515398893672)
            
            //--TRIMMABLE-BOUNDARY-START(489629089896)
            static /*string */ get net_WebSockets_Argument_MessageFlagsHasDifferentCompressionOptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851837032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The compression options for a continuation cannot be different than the options used to send the first fragment of the message.";
            }
            //--TRIMMABLE-BOUNDARY-END(489629089896)
            
            //--TRIMMABLE-BOUNDARY-START(549758632040)
            static /*string */ get net_Websockets_InvalidPayloadLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249110921320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The WebSocket received a frame with an invalid payload length.";
            }
            //--TRIMMABLE-BOUNDARY-END(549758632040)
            
            //--TRIMMABLE-BOUNDARY-START(631363010664)
            static /*string */ get PlatformNotSupported_WebSockets()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412319678568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "WebSockets is not supported on this platform.";
            }
            //--TRIMMABLE-BOUNDARY-END(631363010664)
            
            //--TRIMMABLE-BOUNDARY-START(4297785448)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297785448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(648542879848)
                    this.s_usingResourceKeys = $.$snws.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(648542879848)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297785448)
            
            static $h = 2818152;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2818152
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2818152)
        
        

        //--TRIMMABLE-BOUNDARY-START(2752616)
        $asm.$cls(`$snws.S.Obsoletions`, ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382254841960)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382254841960)
            
            //--TRIMMABLE-BOUNDARY-START(433794449512)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433794449512)
            
            //--TRIMMABLE-BOUNDARY-START(429499482216)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429499482216)
            
            //--TRIMMABLE-BOUNDARY-START(266290724968)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266290724968)
            
            //--TRIMMABLE-BOUNDARY-START(261995757672)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261995757672)
            
            //--TRIMMABLE-BOUNDARY-START(77312163944)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77312163944)
            
            //--TRIMMABLE-BOUNDARY-START(73017196648)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73017196648)
            
            //--TRIMMABLE-BOUNDARY-START(94492033128)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94492033128)
            
            //--TRIMMABLE-BOUNDARY-START(90197065832)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90197065832)
            
            //--TRIMMABLE-BOUNDARY-START(214751117416)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214751117416)
            
            //--TRIMMABLE-BOUNDARY-START(210456150120)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210456150120)
            
            //--TRIMMABLE-BOUNDARY-START(442384384104)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442384384104)
            
            //--TRIMMABLE-BOUNDARY-START(446679351400)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446679351400)
            
            //--TRIMMABLE-BOUNDARY-START(438089416808)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438089416808)
            
            //--TRIMMABLE-BOUNDARY-START(146031640680)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146031640680)
            
            //--TRIMMABLE-BOUNDARY-START(141736673384)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141736673384)
            
            //--TRIMMABLE-BOUNDARY-START(120261836904)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120261836904)
            
            //--TRIMMABLE-BOUNDARY-START(115966869608)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115966869608)
            
            //--TRIMMABLE-BOUNDARY-START(51542360168)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51542360168)
            
            //--TRIMMABLE-BOUNDARY-START(47247392872)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47247392872)
            
            //--TRIMMABLE-BOUNDARY-START(326420267112)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326420267112)
            
            //--TRIMMABLE-BOUNDARY-START(322125299816)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322125299816)
            
            //--TRIMMABLE-BOUNDARY-START(60132294760)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60132294760)
            
            //--TRIMMABLE-BOUNDARY-START(55837327464)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55837327464)
            
            //--TRIMMABLE-BOUNDARY-START(85902098536)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85902098536)
            
            //--TRIMMABLE-BOUNDARY-START(81607131240)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81607131240)
            
            //--TRIMMABLE-BOUNDARY-START(197571248232)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197571248232)
            
            //--TRIMMABLE-BOUNDARY-START(193276280936)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193276280936)
            
            //--TRIMMABLE-BOUNDARY-START(489629024360)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489629024360)
            
            //--TRIMMABLE-BOUNDARY-START(485334057064)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485334057064)
            
            //--TRIMMABLE-BOUNDARY-START(163211509864)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163211509864)
            
            //--TRIMMABLE-BOUNDARY-START(158916542568)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158916542568)
            
            //--TRIMMABLE-BOUNDARY-START(206161182824)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206161182824)
            
            //--TRIMMABLE-BOUNDARY-START(201866215528)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201866215528)
            
            //--TRIMMABLE-BOUNDARY-START(399434711144)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399434711144)
            
            //--TRIMMABLE-BOUNDARY-START(395139743848)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395139743848)
            
            //--TRIMMABLE-BOUNDARY-START(300650463336)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300650463336)
            
            //--TRIMMABLE-BOUNDARY-START(296355496040)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296355496040)
            
            //--TRIMMABLE-BOUNDARY-START(377959874664)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377959874664)
            
            //--TRIMMABLE-BOUNDARY-START(373664907368)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373664907368)
            
            //--TRIMMABLE-BOUNDARY-START(231930986600)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231930986600)
            
            //--TRIMMABLE-BOUNDARY-START(227636019304)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227636019304)
            
            //--TRIMMABLE-BOUNDARY-START(154621575272)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154621575272)
            
            //--TRIMMABLE-BOUNDARY-START(150326607976)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150326607976)
            
            //--TRIMMABLE-BOUNDARY-START(352190070888)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352190070888)
            
            //--TRIMMABLE-BOUNDARY-START(347895103592)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347895103592)
            
            //--TRIMMABLE-BOUNDARY-START(360780005480)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360780005480)
            
            //--TRIMMABLE-BOUNDARY-START(356485038184)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356485038184)
            
            //--TRIMMABLE-BOUNDARY-START(17182621800)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17182621800)
            
            //--TRIMMABLE-BOUNDARY-START(12887654504)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12887654504)
            
            //--TRIMMABLE-BOUNDARY-START(408024645736)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408024645736)
            
            //--TRIMMABLE-BOUNDARY-START(403729678440)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403729678440)
            
            //--TRIMMABLE-BOUNDARY-START(498218958952)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498218958952)
            
            //--TRIMMABLE-BOUNDARY-START(493923991656)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493923991656)
            
            //--TRIMMABLE-BOUNDARY-START(283470594152)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283470594152)
            
            //--TRIMMABLE-BOUNDARY-START(279175626856)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279175626856)
            
            //--TRIMMABLE-BOUNDARY-START(506808893544)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506808893544)
            
            //--TRIMMABLE-BOUNDARY-START(502513926248)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502513926248)
            
            //--TRIMMABLE-BOUNDARY-START(274880659560)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274880659560)
            
            //--TRIMMABLE-BOUNDARY-START(270585692264)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270585692264)
            
            //--TRIMMABLE-BOUNDARY-START(481039089768)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481039089768)
            
            //--TRIMMABLE-BOUNDARY-START(476744122472)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476744122472)
            
            //--TRIMMABLE-BOUNDARY-START(128851771496)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128851771496)
            
            //--TRIMMABLE-BOUNDARY-START(124556804200)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124556804200)
            
            //--TRIMMABLE-BOUNDARY-START(111671902312)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111671902312)
            
            //--TRIMMABLE-BOUNDARY-START(107376935016)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107376935016)
            
            //--TRIMMABLE-BOUNDARY-START(335010201704)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335010201704)
            
            //--TRIMMABLE-BOUNDARY-START(330715234408)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330715234408)
            
            //--TRIMMABLE-BOUNDARY-START(68722229352)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68722229352)
            
            //--TRIMMABLE-BOUNDARY-START(64427262056)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64427262056)
            
            //--TRIMMABLE-BOUNDARY-START(390844776552)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390844776552)
            
            //--TRIMMABLE-BOUNDARY-START(386549809256)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386549809256)
            
            //--TRIMMABLE-BOUNDARY-START(309240397928)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309240397928)
            
            //--TRIMMABLE-BOUNDARY-START(304945430632)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304945430632)
            
            //--TRIMMABLE-BOUNDARY-START(42952425576)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42952425576)
            
            //--TRIMMABLE-BOUNDARY-START(38657458280)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38657458280)
            
            //--TRIMMABLE-BOUNDARY-START(416614580328)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416614580328)
            
            //--TRIMMABLE-BOUNDARY-START(412319613032)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412319613032)
            
            //--TRIMMABLE-BOUNDARY-START(472449155176)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472449155176)
            
            //--TRIMMABLE-BOUNDARY-START(468154187880)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468154187880)
            
            //--TRIMMABLE-BOUNDARY-START(188981313640)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188981313640)
            
            //--TRIMMABLE-BOUNDARY-START(184686346344)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184686346344)
            
            //--TRIMMABLE-BOUNDARY-START(171801444456)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171801444456)
            
            //--TRIMMABLE-BOUNDARY-START(167506477160)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167506477160)
            
            //--TRIMMABLE-BOUNDARY-START(180391379048)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180391379048)
            
            //--TRIMMABLE-BOUNDARY-START(176096411752)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176096411752)
            
            //--TRIMMABLE-BOUNDARY-START(34362490984)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34362490984)
            
            //--TRIMMABLE-BOUNDARY-START(30067523688)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30067523688)
            
            //--TRIMMABLE-BOUNDARY-START(137441706088)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137441706088)
            
            //--TRIMMABLE-BOUNDARY-START(133146738792)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133146738792)
            
            //--TRIMMABLE-BOUNDARY-START(103081967720)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103081967720)
            
            //--TRIMMABLE-BOUNDARY-START(98787000424)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98787000424)
            
            //--TRIMMABLE-BOUNDARY-START(523988762728)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523988762728)
            
            //--TRIMMABLE-BOUNDARY-START(519693795432)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519693795432)
            
            //--TRIMMABLE-BOUNDARY-START(369369940072)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369369940072)
            
            //--TRIMMABLE-BOUNDARY-START(365074972776)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365074972776)
            
            //--TRIMMABLE-BOUNDARY-START(223341052008)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223341052008)
            
            //--TRIMMABLE-BOUNDARY-START(219046084712)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219046084712)
            
            //--TRIMMABLE-BOUNDARY-START(249110855784)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249110855784)
            
            //--TRIMMABLE-BOUNDARY-START(236225953896)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236225953896)
            
            //--TRIMMABLE-BOUNDARY-START(244815888488)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244815888488)
            
            //--TRIMMABLE-BOUNDARY-START(240520921192)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240520921192)
            
            //--TRIMMABLE-BOUNDARY-START(317830332520)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317830332520)
            
            //--TRIMMABLE-BOUNDARY-START(313535365224)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313535365224)
            
            //--TRIMMABLE-BOUNDARY-START(8592687208)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8592687208)
            
            //--TRIMMABLE-BOUNDARY-START(4297719912)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4297719912)
            
            //--TRIMMABLE-BOUNDARY-START(455269285992)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455269285992)
            
            //--TRIMMABLE-BOUNDARY-START(450974318696)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450974318696)
            
            //--TRIMMABLE-BOUNDARY-START(25772556392)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25772556392)
            
            //--TRIMMABLE-BOUNDARY-START(21477589096)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21477589096)
            
            //--TRIMMABLE-BOUNDARY-START(257700790376)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257700790376)
            
            //--TRIMMABLE-BOUNDARY-START(253405823080)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253405823080)
            
            //--TRIMMABLE-BOUNDARY-START(515398828136)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515398828136)
            
            //--TRIMMABLE-BOUNDARY-START(511103860840)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511103860840)
            
            //--TRIMMABLE-BOUNDARY-START(463859220584)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463859220584)
            
            //--TRIMMABLE-BOUNDARY-START(459564253288)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459564253288)
            
            //--TRIMMABLE-BOUNDARY-START(425204514920)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425204514920)
            
            //--TRIMMABLE-BOUNDARY-START(420909547624)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420909547624)
            
            //--TRIMMABLE-BOUNDARY-START(343600136296)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343600136296)
            
            //--TRIMMABLE-BOUNDARY-START(339305169000)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339305169000)
            
            //--TRIMMABLE-BOUNDARY-START(292060528744)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292060528744)
            
            //--TRIMMABLE-BOUNDARY-START(287765561448)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287765561448)
            
            //--TRIMMABLE-BOUNDARY-START(532578697320)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532578697320)
            
            //--TRIMMABLE-BOUNDARY-START(528283730024)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528283730024)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382254841960)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382254841960)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433794449512)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433794449512)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429499482216)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429499482216)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266290724968)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266290724968)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261995757672)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261995757672)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77312163944)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77312163944)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73017196648)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73017196648)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94492033128)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94492033128)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90197065832)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90197065832)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214751117416)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214751117416)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210456150120)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210456150120)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442384384104)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442384384104)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446679351400)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446679351400)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438089416808)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438089416808)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146031640680)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146031640680)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141736673384)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141736673384)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120261836904)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120261836904)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115966869608)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115966869608)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51542360168)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51542360168)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47247392872)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47247392872)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326420267112)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326420267112)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322125299816)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322125299816)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60132294760)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60132294760)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55837327464)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55837327464)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85902098536)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85902098536)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81607131240)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81607131240)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197571248232)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197571248232)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193276280936)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193276280936)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489629024360)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489629024360)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485334057064)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485334057064)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163211509864)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163211509864)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158916542568)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158916542568)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206161182824)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206161182824)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201866215528)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201866215528)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399434711144)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399434711144)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395139743848)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395139743848)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300650463336)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300650463336)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296355496040)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296355496040)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377959874664)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377959874664)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373664907368)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373664907368)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231930986600)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231930986600)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227636019304)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227636019304)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154621575272)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154621575272)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150326607976)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150326607976)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352190070888)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352190070888)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347895103592)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347895103592)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360780005480)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360780005480)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356485038184)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356485038184)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17182621800)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17182621800)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12887654504)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12887654504)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408024645736)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408024645736)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403729678440)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403729678440)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498218958952)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498218958952)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493923991656)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493923991656)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283470594152)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283470594152)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279175626856)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279175626856)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506808893544)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506808893544)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502513926248)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502513926248)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274880659560)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274880659560)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270585692264)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270585692264)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481039089768)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481039089768)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476744122472)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476744122472)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128851771496)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128851771496)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124556804200)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124556804200)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111671902312)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111671902312)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107376935016)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107376935016)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335010201704)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335010201704)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330715234408)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330715234408)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68722229352)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68722229352)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64427262056)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64427262056)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390844776552)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390844776552)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386549809256)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386549809256)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309240397928)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309240397928)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304945430632)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304945430632)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42952425576)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42952425576)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38657458280)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38657458280)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416614580328)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416614580328)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412319613032)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412319613032)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472449155176)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472449155176)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468154187880)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468154187880)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188981313640)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188981313640)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184686346344)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184686346344)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171801444456)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171801444456)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167506477160)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167506477160)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180391379048)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180391379048)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176096411752)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176096411752)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34362490984)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34362490984)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30067523688)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30067523688)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137441706088)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137441706088)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133146738792)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133146738792)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103081967720)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103081967720)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98787000424)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98787000424)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523988762728)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523988762728)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519693795432)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519693795432)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369369940072)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369369940072)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365074972776)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365074972776)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223341052008)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223341052008)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219046084712)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219046084712)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249110855784)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249110855784)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236225953896)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236225953896)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244815888488)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244815888488)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240520921192)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240520921192)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317830332520)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317830332520)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313535365224)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313535365224)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8592687208)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8592687208)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4297719912)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4297719912)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455269285992)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455269285992)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450974318696)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450974318696)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25772556392)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25772556392)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21477589096)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21477589096)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257700790376)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257700790376)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253405823080)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253405823080)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515398828136)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515398828136)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511103860840)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511103860840)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463859220584)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463859220584)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459564253288)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459564253288)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425204514920)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425204514920)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420909547624)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420909547624)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343600136296)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343600136296)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339305169000)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339305169000)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292060528744)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292060528744)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287765561448)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287765561448)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532578697320)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532578697320)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528283730024)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528283730024)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 2752616;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(382254841960),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 2752616,
      "h": 382254841960,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382254841960),
//--TRIMMABLE-BOUNDARY-START(433794449512),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 2752616,
      "h": 433794449512,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433794449512),
//--TRIMMABLE-BOUNDARY-START(429499482216),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 2752616,
      "h": 429499482216,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429499482216),
//--TRIMMABLE-BOUNDARY-START(266290724968),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 2752616,
      "h": 266290724968,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266290724968),
//--TRIMMABLE-BOUNDARY-START(261995757672),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 2752616,
      "h": 261995757672,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261995757672),
//--TRIMMABLE-BOUNDARY-START(77312163944),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 2752616,
      "h": 77312163944,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77312163944),
//--TRIMMABLE-BOUNDARY-START(73017196648),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 2752616,
      "h": 73017196648,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73017196648),
//--TRIMMABLE-BOUNDARY-START(94492033128),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 2752616,
      "h": 94492033128,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94492033128),
//--TRIMMABLE-BOUNDARY-START(90197065832),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 2752616,
      "h": 90197065832,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90197065832),
//--TRIMMABLE-BOUNDARY-START(214751117416),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 2752616,
      "h": 214751117416,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214751117416),
//--TRIMMABLE-BOUNDARY-START(210456150120),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 2752616,
      "h": 210456150120,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210456150120),
//--TRIMMABLE-BOUNDARY-START(442384384104),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 2752616,
      "h": 442384384104,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442384384104),
//--TRIMMABLE-BOUNDARY-START(446679351400),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 2752616,
      "h": 446679351400,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446679351400),
//--TRIMMABLE-BOUNDARY-START(438089416808),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 2752616,
      "h": 438089416808,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438089416808),
//--TRIMMABLE-BOUNDARY-START(146031640680),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 2752616,
      "h": 146031640680,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146031640680),
//--TRIMMABLE-BOUNDARY-START(141736673384),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 2752616,
      "h": 141736673384,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141736673384),
//--TRIMMABLE-BOUNDARY-START(120261836904),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 2752616,
      "h": 120261836904,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120261836904),
//--TRIMMABLE-BOUNDARY-START(115966869608),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 2752616,
      "h": 115966869608,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115966869608),
//--TRIMMABLE-BOUNDARY-START(51542360168),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 2752616,
      "h": 51542360168,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51542360168),
//--TRIMMABLE-BOUNDARY-START(47247392872),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 2752616,
      "h": 47247392872,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47247392872),
//--TRIMMABLE-BOUNDARY-START(326420267112),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 2752616,
      "h": 326420267112,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326420267112),
//--TRIMMABLE-BOUNDARY-START(322125299816),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 2752616,
      "h": 322125299816,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322125299816),
//--TRIMMABLE-BOUNDARY-START(60132294760),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 2752616,
      "h": 60132294760,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60132294760),
//--TRIMMABLE-BOUNDARY-START(55837327464),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 2752616,
      "h": 55837327464,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55837327464),
//--TRIMMABLE-BOUNDARY-START(85902098536),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 2752616,
      "h": 85902098536,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85902098536),
//--TRIMMABLE-BOUNDARY-START(81607131240),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 2752616,
      "h": 81607131240,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81607131240),
//--TRIMMABLE-BOUNDARY-START(197571248232),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 2752616,
      "h": 197571248232,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197571248232),
//--TRIMMABLE-BOUNDARY-START(193276280936),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 2752616,
      "h": 193276280936,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193276280936),
//--TRIMMABLE-BOUNDARY-START(489629024360),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 2752616,
      "h": 489629024360,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489629024360),
//--TRIMMABLE-BOUNDARY-START(485334057064),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 2752616,
      "h": 485334057064,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485334057064),
//--TRIMMABLE-BOUNDARY-START(163211509864),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 2752616,
      "h": 163211509864,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163211509864),
//--TRIMMABLE-BOUNDARY-START(158916542568),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 2752616,
      "h": 158916542568,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158916542568),
//--TRIMMABLE-BOUNDARY-START(206161182824),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 2752616,
      "h": 206161182824,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206161182824),
//--TRIMMABLE-BOUNDARY-START(201866215528),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 2752616,
      "h": 201866215528,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201866215528),
//--TRIMMABLE-BOUNDARY-START(399434711144),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 2752616,
      "h": 399434711144,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399434711144),
//--TRIMMABLE-BOUNDARY-START(395139743848),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 2752616,
      "h": 395139743848,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395139743848),
//--TRIMMABLE-BOUNDARY-START(300650463336),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 2752616,
      "h": 300650463336,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300650463336),
//--TRIMMABLE-BOUNDARY-START(296355496040),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 2752616,
      "h": 296355496040,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296355496040),
//--TRIMMABLE-BOUNDARY-START(377959874664),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 2752616,
      "h": 377959874664,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377959874664),
//--TRIMMABLE-BOUNDARY-START(373664907368),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 2752616,
      "h": 373664907368,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373664907368),
//--TRIMMABLE-BOUNDARY-START(231930986600),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 2752616,
      "h": 231930986600,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231930986600),
//--TRIMMABLE-BOUNDARY-START(227636019304),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 2752616,
      "h": 227636019304,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227636019304),
//--TRIMMABLE-BOUNDARY-START(154621575272),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 2752616,
      "h": 154621575272,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154621575272),
//--TRIMMABLE-BOUNDARY-START(150326607976),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 2752616,
      "h": 150326607976,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150326607976),
//--TRIMMABLE-BOUNDARY-START(352190070888),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 2752616,
      "h": 352190070888,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352190070888),
//--TRIMMABLE-BOUNDARY-START(347895103592),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 2752616,
      "h": 347895103592,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347895103592),
//--TRIMMABLE-BOUNDARY-START(360780005480),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 2752616,
      "h": 360780005480,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360780005480),
//--TRIMMABLE-BOUNDARY-START(356485038184),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 2752616,
      "h": 356485038184,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356485038184),
//--TRIMMABLE-BOUNDARY-START(17182621800),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 2752616,
      "h": 17182621800,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17182621800),
//--TRIMMABLE-BOUNDARY-START(12887654504),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 2752616,
      "h": 12887654504,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12887654504),
//--TRIMMABLE-BOUNDARY-START(408024645736),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 2752616,
      "h": 408024645736,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408024645736),
//--TRIMMABLE-BOUNDARY-START(403729678440),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 2752616,
      "h": 403729678440,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403729678440),
//--TRIMMABLE-BOUNDARY-START(498218958952),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 2752616,
      "h": 498218958952,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498218958952),
//--TRIMMABLE-BOUNDARY-START(493923991656),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 2752616,
      "h": 493923991656,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493923991656),
//--TRIMMABLE-BOUNDARY-START(283470594152),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 2752616,
      "h": 283470594152,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283470594152),
//--TRIMMABLE-BOUNDARY-START(279175626856),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 2752616,
      "h": 279175626856,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279175626856),
//--TRIMMABLE-BOUNDARY-START(506808893544),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 2752616,
      "h": 506808893544,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506808893544),
//--TRIMMABLE-BOUNDARY-START(502513926248),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 2752616,
      "h": 502513926248,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502513926248),
//--TRIMMABLE-BOUNDARY-START(274880659560),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 2752616,
      "h": 274880659560,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274880659560),
//--TRIMMABLE-BOUNDARY-START(270585692264),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 2752616,
      "h": 270585692264,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270585692264),
//--TRIMMABLE-BOUNDARY-START(481039089768),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 2752616,
      "h": 481039089768,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481039089768),
//--TRIMMABLE-BOUNDARY-START(476744122472),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 2752616,
      "h": 476744122472,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476744122472),
//--TRIMMABLE-BOUNDARY-START(128851771496),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 2752616,
      "h": 128851771496,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128851771496),
//--TRIMMABLE-BOUNDARY-START(124556804200),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 2752616,
      "h": 124556804200,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124556804200),
//--TRIMMABLE-BOUNDARY-START(111671902312),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 2752616,
      "h": 111671902312,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111671902312),
//--TRIMMABLE-BOUNDARY-START(107376935016),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 2752616,
      "h": 107376935016,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107376935016),
//--TRIMMABLE-BOUNDARY-START(335010201704),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 2752616,
      "h": 335010201704,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335010201704),
//--TRIMMABLE-BOUNDARY-START(330715234408),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 2752616,
      "h": 330715234408,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330715234408),
//--TRIMMABLE-BOUNDARY-START(68722229352),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 2752616,
      "h": 68722229352,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68722229352),
//--TRIMMABLE-BOUNDARY-START(64427262056),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 2752616,
      "h": 64427262056,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64427262056),
//--TRIMMABLE-BOUNDARY-START(390844776552),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 2752616,
      "h": 390844776552,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390844776552),
//--TRIMMABLE-BOUNDARY-START(386549809256),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 2752616,
      "h": 386549809256,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386549809256),
//--TRIMMABLE-BOUNDARY-START(309240397928),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 2752616,
      "h": 309240397928,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309240397928),
//--TRIMMABLE-BOUNDARY-START(304945430632),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 2752616,
      "h": 304945430632,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304945430632),
//--TRIMMABLE-BOUNDARY-START(42952425576),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 2752616,
      "h": 42952425576,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42952425576),
//--TRIMMABLE-BOUNDARY-START(38657458280),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 2752616,
      "h": 38657458280,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38657458280),
//--TRIMMABLE-BOUNDARY-START(416614580328),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 2752616,
      "h": 416614580328,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416614580328),
//--TRIMMABLE-BOUNDARY-START(412319613032),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 2752616,
      "h": 412319613032,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412319613032),
//--TRIMMABLE-BOUNDARY-START(472449155176),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 2752616,
      "h": 472449155176,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472449155176),
//--TRIMMABLE-BOUNDARY-START(468154187880),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 2752616,
      "h": 468154187880,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468154187880),
//--TRIMMABLE-BOUNDARY-START(188981313640),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 2752616,
      "h": 188981313640,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188981313640),
//--TRIMMABLE-BOUNDARY-START(184686346344),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 2752616,
      "h": 184686346344,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184686346344),
//--TRIMMABLE-BOUNDARY-START(171801444456),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 2752616,
      "h": 171801444456,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171801444456),
//--TRIMMABLE-BOUNDARY-START(167506477160),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 2752616,
      "h": 167506477160,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167506477160),
//--TRIMMABLE-BOUNDARY-START(180391379048),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 2752616,
      "h": 180391379048,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180391379048),
//--TRIMMABLE-BOUNDARY-START(176096411752),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 2752616,
      "h": 176096411752,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176096411752),
//--TRIMMABLE-BOUNDARY-START(34362490984),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 2752616,
      "h": 34362490984,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34362490984),
//--TRIMMABLE-BOUNDARY-START(30067523688),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 2752616,
      "h": 30067523688,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30067523688),
//--TRIMMABLE-BOUNDARY-START(137441706088),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 2752616,
      "h": 137441706088,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137441706088),
//--TRIMMABLE-BOUNDARY-START(133146738792),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 2752616,
      "h": 133146738792,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133146738792),
//--TRIMMABLE-BOUNDARY-START(103081967720),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 2752616,
      "h": 103081967720,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103081967720),
//--TRIMMABLE-BOUNDARY-START(98787000424),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 2752616,
      "h": 98787000424,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98787000424),
//--TRIMMABLE-BOUNDARY-START(523988762728),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 2752616,
      "h": 523988762728,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523988762728),
//--TRIMMABLE-BOUNDARY-START(519693795432),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 2752616,
      "h": 519693795432,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519693795432),
//--TRIMMABLE-BOUNDARY-START(369369940072),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 2752616,
      "h": 369369940072,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369369940072),
//--TRIMMABLE-BOUNDARY-START(365074972776),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 2752616,
      "h": 365074972776,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365074972776),
//--TRIMMABLE-BOUNDARY-START(223341052008),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 2752616,
      "h": 223341052008,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223341052008),
//--TRIMMABLE-BOUNDARY-START(219046084712),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 2752616,
      "h": 219046084712,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219046084712),
//--TRIMMABLE-BOUNDARY-START(249110855784),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 2752616,
      "h": 249110855784,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249110855784),
//--TRIMMABLE-BOUNDARY-START(236225953896),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 2752616,
      "h": 236225953896,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236225953896),
//--TRIMMABLE-BOUNDARY-START(244815888488),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 2752616,
      "h": 244815888488,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244815888488),
//--TRIMMABLE-BOUNDARY-START(240520921192),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 2752616,
      "h": 240520921192,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240520921192),
//--TRIMMABLE-BOUNDARY-START(317830332520),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 2752616,
      "h": 317830332520,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317830332520),
//--TRIMMABLE-BOUNDARY-START(313535365224),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 2752616,
      "h": 313535365224,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313535365224),
//--TRIMMABLE-BOUNDARY-START(8592687208),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 2752616,
      "h": 8592687208,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8592687208),
//--TRIMMABLE-BOUNDARY-START(4297719912),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 2752616,
      "h": 4297719912,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4297719912),
//--TRIMMABLE-BOUNDARY-START(455269285992),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 2752616,
      "h": 455269285992,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455269285992),
//--TRIMMABLE-BOUNDARY-START(450974318696),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 2752616,
      "h": 450974318696,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450974318696),
//--TRIMMABLE-BOUNDARY-START(25772556392),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 2752616,
      "h": 25772556392,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25772556392),
//--TRIMMABLE-BOUNDARY-START(21477589096),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 2752616,
      "h": 21477589096,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21477589096),
//--TRIMMABLE-BOUNDARY-START(257700790376),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 2752616,
      "h": 257700790376,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257700790376),
//--TRIMMABLE-BOUNDARY-START(253405823080),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 2752616,
      "h": 253405823080,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253405823080),
//--TRIMMABLE-BOUNDARY-START(515398828136),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 2752616,
      "h": 515398828136,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515398828136),
//--TRIMMABLE-BOUNDARY-START(511103860840),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 2752616,
      "h": 511103860840,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511103860840),
//--TRIMMABLE-BOUNDARY-START(463859220584),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 2752616,
      "h": 463859220584,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463859220584),
//--TRIMMABLE-BOUNDARY-START(459564253288),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 2752616,
      "h": 459564253288,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459564253288),
//--TRIMMABLE-BOUNDARY-START(425204514920),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 2752616,
      "h": 425204514920,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425204514920),
//--TRIMMABLE-BOUNDARY-START(420909547624),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 2752616,
      "h": 420909547624,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420909547624),
//--TRIMMABLE-BOUNDARY-START(343600136296),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 2752616,
      "h": 343600136296,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343600136296),
//--TRIMMABLE-BOUNDARY-START(339305169000),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 2752616,
      "h": 339305169000,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339305169000),
//--TRIMMABLE-BOUNDARY-START(292060528744),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 2752616,
      "h": 292060528744,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292060528744),
//--TRIMMABLE-BOUNDARY-START(287765561448),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 2752616,
      "h": 287765561448,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287765561448),
//--TRIMMABLE-BOUNDARY-START(532578697320),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 2752616,
      "h": 532578697320,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532578697320),
//--TRIMMABLE-BOUNDARY-START(528283730024),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 2752616,
      "h": 528283730024,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528283730024)
  ],
  "h": 2752616
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Obsoletions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752616)
        
        

        //--TRIMMABLE-BOUNDARY-START(2883688)
        $asm.$cls(`$snws.ST.AsyncMutex`, ($self) => class AsyncMutex extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297850984)
            /*int*/ _gate = 1;
            //--TRIMMABLE-BOUNDARY-END(4297850984)
            
            //--TRIMMABLE-BOUNDARY-START(8592818280)
            /*bool*/ _lockedSemaphoreFull = true;
            //--TRIMMABLE-BOUNDARY-END(8592818280)
            
            //--TRIMMABLE-BOUNDARY-START(12887785576)
            /*Waiter?*/ _waitersTail = null;
            //--TRIMMABLE-BOUNDARY-END(12887785576)
            
            //--TRIMMABLE-BOUNDARY-START(47247523944)
            /*bool */ get IsHeld()
            {
                return this._gate !== 1;
            }
            //--TRIMMABLE-BOUNDARY-END(47247523944)
            
            //--TRIMMABLE-BOUNDARY-START(51542491240)
            /*object */ get SyncObj()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51542491240)
            
            //--TRIMMABLE-BOUNDARY-START(21477720168)
            /*Task */ EnterAsync(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477720168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.STT.Task.FromCanceled$1(cancellationToken);
                }
                /*int*/ let gate = $.$$.ST$1.Interlocked.Decrement($.$ref(() => this._gate, ($v) => this._gate = $v, $.$$.S.Int32));
                if (gate >= 0)
                {
                    return $.$$.STT.Task.CompletedTask;
                }
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, `Waiting to enter, queue length ${$.$strNN(-gate)}`, "EnterAsync");
                }
                return Contended.call(this, cancellationToken);
                /*Task*/  function Contended(/*CancellationToken*/ cancellationToken)
                {
                    /*var*/ let w = new $.$snws.ST.AsyncMutex.Waiter().$ctor$5(this);
                    w.CancellationRegistration = cancellationToken.UnsafeRegister(new ($.$$.S.Action$$$($.$$.S.Object, $.$$.ST$1.CancellationToken))().$ctor(this,  (/*s*/ s, /*token*/ token) =>
                    {
                        return OnCancellation(s, token);
                    }, $pFjNud ??= {"r":65537,"p":[{"n":"s","p":131073},{"n":"token","p":170852353}],"n":"","d":2883688,"h":0,"f":17825794}), w);
                    //lock(SyncObj)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                        {
                            if (!this._lockedSemaphoreFull)
                            {
                                w.CancellationRegistration.Unregister();
                                this._lockedSemaphoreFull = true;
                                return $.$$.STT.Task.CompletedTask;
                            }
                            if (cancellationToken.IsCancellationRequested)
                            {
                                w.TrySetCanceled$1(cancellationToken);
                                return w.Task;
                            }
                            if (this._waitersTail === null)
                            {
                                w.Next = w.Prev = w;
                            }
                            else 
                            {
                                $.$$.SD.Debug.Assert$4(this._waitersTail.Next !== null && this._waitersTail.Prev !== null, "_waitersTail.Next != null && _waitersTail.Prev != null");
                                w.Next = this._waitersTail;
                                w.Prev = this._waitersTail.Prev;
                                w.Prev.Next = w.Next.Prev = w;
                            }
                            this._waitersTail = w;
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this.SyncObj)
                    }
                    return w.Task;
                    /*static void*/  function OnCancellation(/*object?*/ state, /*CancellationToken*/ cancellationToken)
                    {
                        /*Waiter?*/ let w = $.$cast(state, $.$snws.ST.AsyncMutex.Waiter);
                        /*AsyncMutex*/ let m = w.Owner;
                        //lock(m.SyncObj)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1(m.SyncObj)
                            {
                                /*bool*/ let inList = w.Next !== null;
                                if (inList)
                                {
                                    $.$$.SD.Debug.Assert$4(w.Prev !== null, "w.Prev != null");
                                    $.$$.ST$1.Interlocked.Increment($.$ref(() => m._gate, ($v) => m._gate = $v, $.$$.S.Int32));
                                    if (w.Next === w)
                                    {
                                        $.$$.SD.Debug.Assert$4(m._waitersTail === w, "m._waitersTail == w");
                                        m._waitersTail = null;
                                    }
                                    else 
                                    {
                                        w.Next.Prev = w.Prev;
                                        w.Prev.Next = w.Next;
                                        if (m._waitersTail === w)
                                        {
                                            m._waitersTail = w.Next;
                                        }
                                    }
                                    w.Next = w.Prev = null;
                                }
                                else 
                                {
                                    w = null;
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit(m.SyncObj)
                        }
                        w?.TrySetCanceled$1(cancellationToken);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477720168)
            
            //--TRIMMABLE-BOUNDARY-START(25772687464)
            /*void */ Exit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772687464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let gate = $.$$.ST$1.Interlocked.Increment($.$ref(() => this._gate, ($v) => this._gate = $v, $.$$.S.Int32));
                if (gate < 1)
                {
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.Trace(this, `Unblocking next waiter on exit, remaining queue length ${$.$strNN(-this._gate)}`, "Exit");
                    }
                    Contended.call(this);
                }
                /*void*/  function Contended()
                {
                    /*Waiter?*/ let w;
                    //lock(SyncObj)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                        {
                            $.$$.SD.Debug.Assert$4(this._lockedSemaphoreFull, "_lockedSemaphoreFull");
                            w = this._waitersTail;
                            if (w === null)
                            {
                                this._lockedSemaphoreFull = false;
                            }
                            else 
                            {
                                $.$$.SD.Debug.Assert$4(w.Next !== null && w.Prev !== null, "w.Next != null && w.Prev != null");
                                $.$$.SD.Debug.Assert$4(w.Next !== w || w.Prev === w, "w.Next != w || w.Prev == w");
                                $.$$.SD.Debug.Assert$4(w.Prev !== w || w.Next === w, "w.Prev != w || w.Next == w");
                                if (w.Next === w)
                                {
                                    this._waitersTail = null;
                                }
                                else 
                                {
                                    w = w.Prev;
                                    $.$$.SD.Debug.Assert$4(w.Next !== null && w.Prev !== null, "w.Next != null && w.Prev != null");
                                    $.$$.SD.Debug.Assert$4(w.Next !== w && w.Prev !== w, "w.Next != w && w.Prev != w");
                                    w.Next.Prev = w.Prev;
                                    w.Prev.Next = w.Next;
                                }
                                w.Next = w.Prev = null;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this.SyncObj)
                    }
                    if (!(w === null))
                    {
                        w.CancellationRegistration.Unregister();
                        w.TrySetResult();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772687464)
            
            //--TRIMMABLE-BOUNDARY-START(2949224)
            static $_Waiter;
            static get Waiter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2949224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.ST.AsyncMutex;
                return $cls.$_Waiter ??= $asm.$ncls(`$snws.ST.AsyncMutex.Waiter`, ($self) => class Waiter extends $.$$.STT.TaskCompletionSource
                {
                    //--TRIMMABLE-BOUNDARY-START(21477785704)
                    $ctor$5(/*AsyncMutex*/ owner)
                    {
                        super.$ctor$4(64/*TaskCreationOptions.RunContinuationsAsynchronously*/);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21477785704);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Owner = owner;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477785704)
                    
                    //--TRIMMABLE-BOUNDARY-START(68722425960)
                    /*AsyncMutex*/ Owner = null;
                    //--TRIMMABLE-BOUNDARY-END(68722425960)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772753000)
                    /*CancellationTokenRegistration*/ CancellationRegistration;
                    //--TRIMMABLE-BOUNDARY-END(25772753000)
                    
                    //--TRIMMABLE-BOUNDARY-START(64427458664)
                    /*Waiter?*/ Next = null;
                    //--TRIMMABLE-BOUNDARY-END(64427458664)
                    
                    //--TRIMMABLE-BOUNDARY-START(73017393256)
                    /*Waiter?*/ Prev = null;
                    //--TRIMMABLE-BOUNDARY-END(73017393256)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(25772753000)
                        this.CancellationRegistration = $.$default($.$$.ST$1.CancellationTokenRegistration);
                        //--TRIMMABLE-BOUNDARY-END(25772753000)
                        
                    }
                    static $h = 2949224;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.STT.TaskCompletionSource; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68722425960),
    {
      "p": 2883688,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542556776,
        "f": 50331649
      },
      "n": "Owner",
      "d": 2949224,
      "h": 68722425960,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68722425960),
//--TRIMMABLE-BOUNDARY-START(25772753000),
    {
      "p": 170917889,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362687592,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81607327848,
        "f": 83886081
      },
      "n": "CancellationRegistration",
      "d": 2949224,
      "h": 25772753000,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772753000),
//--TRIMMABLE-BOUNDARY-START(64427458664),
    {
      "p": 2949224,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952622184,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90197262440,
        "f": 83886081
      },
      "n": "Next",
      "d": 2949224,
      "h": 64427458664,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64427458664),
//--TRIMMABLE-BOUNDARY-START(73017393256),
    {
      "p": 2949224,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132491368,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98787197032,
        "f": 83886081
      },
      "n": "Prev",
      "d": 2949224,
      "h": 73017393256,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73017393256)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477785704),
    {
      "p": [
        {
          "n": "owner",
          "p": 2883688
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2949224,
      "h": 21477785704,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477785704)
  ],
  "d": 2883688,
  "h": 2949224
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Threading.AsyncMutex+Waiter`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Threading${separator}AsyncMutex${separator}Waiter`; }
                }, $cls, ($v) => $cls.$_Waiter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2949224)
            
            //--TRIMMABLE-BOUNDARY-START(17182752872)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182752872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182752872)
            
            //--TRIMMABLE-BOUNDARY-START(17182752872)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17182752872)
            
            static $h = 2883688;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47247523944),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362622056,
        "f": 50331649
      },
      "n": "IsHeld",
      "d": 2883688,
      "h": 47247523944,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247523944),
//--TRIMMABLE-BOUNDARY-START(51542491240),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952556648,
        "f": 50331650
      },
      "n": "SyncObj",
      "d": 2883688,
      "h": 51542491240,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51542491240)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477720168),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "EnterAsync",
      "d": 2883688,
      "h": 21477720168,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477720168),
//--TRIMMABLE-BOUNDARY-START(25772687464),
    {
      "r": 65537,
      "n": "Exit",
      "d": 2883688,
      "h": 25772687464,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772687464)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297850984),
    {
      "t": 655361,
      "n": "_gate",
      "d": 2883688,
      "h": 4297850984,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297850984),
//--TRIMMABLE-BOUNDARY-START(8592818280),
    {
      "t": 262145,
      "n": "_lockedSemaphoreFull",
      "d": 2883688,
      "h": 8592818280,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592818280),
//--TRIMMABLE-BOUNDARY-START(12887785576),
    {
      "t": 2949224,
      "n": "_waitersTail",
      "d": 2883688,
      "h": 12887785576,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887785576)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182752872),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2883688,
      "h": 17182752872,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182752872)
  ],
  "h": 2883688
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$snws.ST.AsyncMutex.Waiter ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Threading.AsyncMutex`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Threading${separator}AsyncMutex`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2883688)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048680)
        $asm.$cls(`$snws.SNWC.WebSocketInflater`, ($self) => class WebSocketInflater extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64425558120)
            /*int*/ static FlushMarkerLength = 4;
            //--TRIMMABLE-BOUNDARY-END(64425558120)
            
            //--TRIMMABLE-BOUNDARY-START(60130590824)
            static /*ReadOnlySpan<byte> */ get FlushMarker()
            {
                return this.$cacheFlushMarker ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([ 0, 0, 255, 255 ]);
            }
            //--TRIMMABLE-BOUNDARY-END(60130590824)
            
            //--TRIMMABLE-BOUNDARY-START(34360787048)
            /*int*/ _windowBits = 0;
            //--TRIMMABLE-BOUNDARY-END(34360787048)
            
            //--TRIMMABLE-BOUNDARY-START(30065819752)
            /*ZLibStreamHandle?*/ _stream = null;
            //--TRIMMABLE-BOUNDARY-END(30065819752)
            
            //--TRIMMABLE-BOUNDARY-START(17180917864)
            /*bool*/ _persisted = false;
            //--TRIMMABLE-BOUNDARY-END(17180917864)
            
            //--TRIMMABLE-BOUNDARY-START(25770852456)
            /*byte?*/ _remainingByte = null;
            //--TRIMMABLE-BOUNDARY-END(25770852456)
            
            //--TRIMMABLE-BOUNDARY-START(12885950568)
            /*bool*/ _endOfMessage = false;
            //--TRIMMABLE-BOUNDARY-END(12885950568)
            
            //--TRIMMABLE-BOUNDARY-START(8590983272)
            /*byte[]?*/ _buffer = null;
            //--TRIMMABLE-BOUNDARY-END(8590983272)
            
            //--TRIMMABLE-BOUNDARY-START(21475885160)
            /*int*/ _position = 0;
            //--TRIMMABLE-BOUNDARY-END(21475885160)
            
            //--TRIMMABLE-BOUNDARY-START(4296015976)
            /*int*/ _available = 0;
            //--TRIMMABLE-BOUNDARY-END(4296015976)
            
            //--TRIMMABLE-BOUNDARY-START(38655754344)
            $ctor$1(/*int*/ windowBits, /*bool*/ persisted)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655754344);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._windowBits = -windowBits;
                    this._persisted = persisted;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655754344)
            
            //--TRIMMABLE-BOUNDARY-START(107375231080)
            /*Memory<byte> */ get Memory()
            {
                return $.$$.S.MemoryExtensions.AsMemory$10($.$$.S.Byte, this._buffer, ((this._position + this._available) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(107375231080)
            
            //--TRIMMABLE-BOUNDARY-START(120260132968)
            /*Span<byte> */ get Span()
            {
                return $.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, ((this._position + this._available) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(120260132968)
            
            //--TRIMMABLE-BOUNDARY-START(51540656232)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540656232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._stream?.Dispose();
                this.ReleaseBuffer();
            }
            //--TRIMMABLE-BOUNDARY-END(51540656232)
            
            //--TRIMMABLE-BOUNDARY-START(111670198376)
            /*void */ Prepare(/*long*/ payloadLength, /*int*/ userBufferLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670198376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(this._buffer === null))
                {
                    $.$$.SD.Debug.Assert$4(this._available > 0, "_available > 0");
                    $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, this._buffer, this._position, this._available).CopyTo($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(this._buffer));
                    this._position = 0;
                }
                else 
                {
                    this._buffer = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent($.$cast($.$$.S.Math.Min$5(BigInt(userBufferLength), payloadLength), $.$$.S.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111670198376)
            
            //--TRIMMABLE-BOUNDARY-START(42950721640)
            /*void */ AddBytes(/*int*/ totalBytesReceived, /*bool*/ endOfMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950721640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(totalBytesReceived === 0 || !(this._buffer === null), "Prepare must be called.");
                this._available += totalBytesReceived;
                this._endOfMessage = endOfMessage;
                if (endOfMessage)
                {
                    if (this._buffer === null)
                    {
                        $.$$.SD.Debug.Assert$4(this._available === 0, "_available == 0");
                        this._buffer = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(4/*FlushMarkerLength*/);
                        this._available = 4/*FlushMarkerLength*/;
                        $.$snws.SNWC.WebSocketInflater.FlushMarker.CopyTo($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(this._buffer));
                    }
                    else 
                    {
                        if (this._buffer.length < ((this._available + 4/*FlushMarkerLength*/) | 0))
                        {
                            /*byte[]*/ let newBuffer = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(((this._available + 4/*FlushMarkerLength*/) | 0));
                            $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, this._buffer, 0, this._available).CopyTo($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(newBuffer));
                            /*byte[]*/ let toReturn = this._buffer;
                            this._buffer = newBuffer;
                            $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(toReturn, false);
                        }
                        $.$snws.SNWC.WebSocketInflater.FlushMarker.CopyTo($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._available));
                        this._available += 4/*FlushMarkerLength*/;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950721640)
            
            //--TRIMMABLE-BOUNDARY-START(98785296488)
            /*bool */ Inflate$1(/*Span<byte>*/ output, /*out int*/ written)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785296488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._stream ??= this.CreateInflater();
                /*bool*/ let streamEnded = false;
                if (this._available > 0 && output.Length > 0)
                {
                    /*int*/ let consumed;
                    /*fixed*/ 
                    {
                        /*byte**/ let bufferPtr = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$$.S.Byte, this._buffer, null, false, true);
                        this._stream.NextIn = $.$$.$interop.$ptr2Addr((bufferPtr.Add(this._position)));
                        this._stream.AvailIn = (this._available >>> 0);
                        written.$v = $.$snws.SNWC.WebSocketInflater.Inflate(this._stream, output, 0/*FlushCode.NoFlush*/, $.$ref(() => streamEnded, ($v) => streamEnded = $v, $.$$.S.Boolean));
                        consumed = ((this._available - (this._stream.AvailIn | 0)) | 0);
                    }
                    this._position += consumed;
                    this._available -= consumed;
                }
                else 
                {
                    written.$v = 0;
                }
                if (this._available === 0)
                {
                    this.ReleaseBuffer();
                    return this._endOfMessage ? this.Finish(output, written) : true;
                }
                if (streamEnded && this._available > 0)
                {
                    throw new $.$snws.SNW.WebSocketException().$ctor$34($.$snws.S.SR.net_WebSockets_DataAfterBFinal);
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(98785296488)
            
            //--TRIMMABLE-BOUNDARY-START(55835623528)
            /*bool */ Finish(/*Span<byte>*/ output, /*ref int*/ written)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835623528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!(this._stream === null) && this._stream.AvailIn === 0, "_stream is not null && _stream.AvailIn == 0");
                $.$$.SD.Debug.Assert$4(this._available === 0, "_available == 0");
                if (!(this._remainingByte === null))
                {
                    if (output.Length === written.$v)
                    {
                        return false;
                    }
                    output._reference.SetAt($.$$.S.Nullable$$($.$$.S.Byte).GetValueOrDefault.call(this._remainingByte), written.$v);
                    this._remainingByte = null;
                    written.$v += 1;
                }
                if (output.Length > written.$v)
                {
                    let $t3 = output;
                    written.$v += $.$snws.SNWC.WebSocketInflater.Inflate(this._stream, $t3.Slice(written.$v, $t3.Length - written.$v), 2/*FlushCode.SyncFlush*/, $.$discardRef());
                }
                if (written.$v < output.Length || $.$snws.SNWC.WebSocketInflater.IsFinished(this._stream, $.$ref(() => this._remainingByte, ($v) => this._remainingByte = $v, $.$typeNullable($.$$.S.Byte))))
                {
                    if (!this._persisted)
                    {
                        this._stream.Dispose();
                        this._stream = null;
                    }
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(55835623528)
            
            //--TRIMMABLE-BOUNDARY-START(115965165672)
            /*void */ ReleaseBuffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965165672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let toReturn;
                if ($.$is(this._buffer, $.$typeArray($.$$.S.Byte), { set $v($v){ toReturn = $v; } }))
                {
                    this._buffer = null;
                    this._available = 0;
                    this._position = 0;
                    $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115965165672)
            
            //--TRIMMABLE-BOUNDARY-START(103080263784)
            static /*bool */ IsFinished(/*ZLibStreamHandle*/ stream, /*out byte?*/ remainingByte)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080263784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte*/ let b = 0;
                if ($.$snws.SNWC.WebSocketInflater.Inflate(stream, new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$4($.$ref(() => b, ($v) => b = $v, $.$$.S.Byte)), 2/*FlushCode.SyncFlush*/, $.$discardRef()) === 0)
                {
                    remainingByte.$v = null;
                    return true;
                }
                remainingByte.$v = b;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(103080263784)
            
            //--TRIMMABLE-BOUNDARY-START(94490329192)
            static /*int */ Inflate(/*ZLibStreamHandle*/ stream, /*Span<byte>*/ destination, /*FlushCode*/ flushCode, /*out bool*/ streamEnded)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490329192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(destination.Length > 0, "destination.Length > 0");
                /*ErrorCode*/ let errorCode;
                /*fixed*/ 
                {
                    /*byte**/ let bufPtr = destination.GetPinnableReference();
                    stream.NextOut = $.$$.$interop.$ptr2Addr(bufPtr);
                    stream.AvailOut = (destination.Length >>> 0);
                    errorCode = stream.Inflate(flushCode);
                    if (((errorCode === 0/*ErrorCode.Ok*/) || (errorCode === 1/*ErrorCode.StreamEnd*/)) || (errorCode === -5/*ErrorCode.BufError*/))
                    {
                        streamEnded.$v = errorCode === 1/*ErrorCode.StreamEnd*/;
                        return ((destination.Length - (stream.AvailOut | 0)) | 0);
                    }
                }
                /*string*/ let message = (() =>
                {
                    if (errorCode === -4/*ErrorCode.MemError*/)
                    {
                        return $.$snws.S.SR.ZLibErrorNotEnoughMemory;
                    }
                    if (errorCode === -3/*ErrorCode.DataError*/)
                    {
                        return $.$snws.S.SR.ZLibUnsupportedCompression;
                    }
                    if (errorCode === -2/*ErrorCode.StreamError*/)
                    {
                        return $.$snws.S.SR.ZLibErrorInconsistentStream;
                    }
                    return $.$snws.S.SR.Format$6($.$snws.S.SR.ZLibErrorUnexpected, $.$box(errorCode, $.$$.S.Int32));
                })();
                throw new $.$snws.SNW.WebSocketException().$ctor$34(message);
            }
            //--TRIMMABLE-BOUNDARY-END(94490329192)
            
            //--TRIMMABLE-BOUNDARY-START(47245688936)
            /*ZLibStreamHandle */ CreateInflater()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245688936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ZLibStreamHandle?*/ let stream = null;
                /*ErrorCode*/ let errorCode;
                try
                {
                    errorCode = $.$snws.SIC.ZLibNative.CreateZLibStreamForInflate($.$ref(() => stream, ($v) => stream = $v, $.$snws.SIC.ZLibNative.ZLibStreamHandle), this._windowBits);
                }
                catch(exception)
                {
                    stream?.Dispose();
                    throw new $.$snws.SNW.WebSocketException().$ctor$33($.$snws.S.SR.ZLibErrorDLLLoadError, exception);
                }
                if (errorCode === 0/*ErrorCode.Ok*/)
                {
                    return stream;
                }
                stream.Dispose();
                /*string*/ let message = errorCode === -4/*ErrorCode.MemError*/ ? $.$snws.S.SR.ZLibErrorNotEnoughMemory : $.$snws.S.SR.Format$6($.$snws.S.SR.ZLibErrorUnexpected, $.$box(errorCode, $.$$.S.Int32));
                throw new $.$snws.SNW.WebSocketException().$ctor$34(message);
            }
            //--TRIMMABLE-BOUNDARY-END(47245688936)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            static $h = 1048680;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130590824),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015492712,
        "f": 50331688
      },
      "n": "FlushMarker",
      "d": 1048680,
      "h": 60130590824,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(60130590824),
//--TRIMMABLE-BOUNDARY-START(107375231080),
    {
      "p": $.$$.S.Memory$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605427304,
        "f": 50331649
      },
      "n": "Memory",
      "d": 1048680,
      "h": 107375231080,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375231080),
//--TRIMMABLE-BOUNDARY-START(120260132968),
    {
      "p": $.$$.S.Span$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195361896,
        "f": 50331649
      },
      "n": "Span",
      "d": 1048680,
      "h": 120260132968,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260132968)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540656232),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1048680,
      "h": 51540656232,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540656232),
//--TRIMMABLE-BOUNDARY-START(111670198376),
    {
      "r": 65537,
      "p": [
        {
          "n": "payloadLength",
          "p": 917505
        },
        {
          "n": "userBufferLength",
          "p": 655361
        }
      ],
      "n": "Prepare",
      "d": 1048680,
      "h": 111670198376,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670198376),
//--TRIMMABLE-BOUNDARY-START(42950721640),
    {
      "r": 65537,
      "p": [
        {
          "n": "totalBytesReceived",
          "p": 655361
        },
        {
          "n": "endOfMessage",
          "p": 262145
        }
      ],
      "n": "AddBytes",
      "d": 1048680,
      "h": 42950721640,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950721640),
//--TRIMMABLE-BOUNDARY-START(98785296488),
    {
      "r": 262145,
      "p": [
        {
          "n": "output",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "written",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "Inflate",
      "o": "@$1",
      "d": 1048680,
      "h": 98785296488,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98785296488),
//--TRIMMABLE-BOUNDARY-START(55835623528),
    {
      "r": 262145,
      "p": [
        {
          "n": "output",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "written",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "Finish",
      "d": 1048680,
      "h": 55835623528,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55835623528),
//--TRIMMABLE-BOUNDARY-START(115965165672),
    {
      "r": 65537,
      "n": "ReleaseBuffer",
      "d": 1048680,
      "h": 115965165672,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115965165672),
//--TRIMMABLE-BOUNDARY-START(103080263784),
    {
      "r": 262145,
      "p": [
        {
          "n": "stream",
          "p": 655464
        },
        {
          "n": "remainingByte",
          "p": $.$typeNullable($.$$.S.Byte).$h,
          "f": 2
        }
      ],
      "n": "IsFinished",
      "d": 1048680,
      "h": 103080263784,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103080263784),
//--TRIMMABLE-BOUNDARY-START(94490329192),
    {
      "r": 655361,
      "p": [
        {
          "n": "stream",
          "p": 655464
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "flushCode",
          "p": 589928
        },
        {
          "n": "streamEnded",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "Inflate",
      "d": 1048680,
      "h": 94490329192,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94490329192),
//--TRIMMABLE-BOUNDARY-START(47245688936),
    {
      "r": 655464,
      "n": "CreateInflater",
      "d": 1048680,
      "h": 47245688936,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47245688936)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64425558120),
    {
      "t": 655361,
      "n": "FlushMarkerLength",
      "d": 1048680,
      "h": 64425558120,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64425558120),
//--TRIMMABLE-BOUNDARY-START(34360787048),
    {
      "t": 655361,
      "n": "_windowBits",
      "d": 1048680,
      "h": 34360787048,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360787048),
//--TRIMMABLE-BOUNDARY-START(30065819752),
    {
      "t": 655464,
      "n": "_stream",
      "d": 1048680,
      "h": 30065819752,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065819752),
//--TRIMMABLE-BOUNDARY-START(17180917864),
    {
      "t": 262145,
      "n": "_persisted",
      "d": 1048680,
      "h": 17180917864,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180917864),
//--TRIMMABLE-BOUNDARY-START(25770852456),
    {
      "t": $.$typeNullable($.$$.S.Byte).$h,
      "n": "_remainingByte",
      "d": 1048680,
      "h": 25770852456,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770852456),
//--TRIMMABLE-BOUNDARY-START(12885950568),
    {
      "t": 262145,
      "n": "_endOfMessage",
      "d": 1048680,
      "h": 12885950568,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885950568),
//--TRIMMABLE-BOUNDARY-START(8590983272),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_buffer",
      "d": 1048680,
      "h": 8590983272,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590983272),
//--TRIMMABLE-BOUNDARY-START(21475885160),
    {
      "t": 655361,
      "n": "_position",
      "d": 1048680,
      "h": 21475885160,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475885160),
//--TRIMMABLE-BOUNDARY-START(4296015976),
    {
      "t": 655361,
      "n": "_available",
      "d": 1048680,
      "h": 4296015976,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296015976)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655754344),
    {
      "p": [
        {
          "n": "windowBits",
          "p": 655361
        },
        {
          "n": "persisted",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048680,
      "h": 38655754344,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38655754344)
  ],
  "h": 1048680
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.Compression.WebSocketInflater`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}Compression${separator}WebSocketInflater`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048680)
        
        

        //--TRIMMABLE-BOUNDARY-START(983144)
        $asm.$cls(`$snws.SNWC.WebSocketDeflater`, ($self) => class WebSocketDeflater extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180852328)
            /*int*/ _windowBits = 0;
            //--TRIMMABLE-BOUNDARY-END(17180852328)
            
            //--TRIMMABLE-BOUNDARY-START(12885885032)
            /*ZLibStreamHandle?*/ _stream = null;
            //--TRIMMABLE-BOUNDARY-END(12885885032)
            
            //--TRIMMABLE-BOUNDARY-START(8590917736)
            /*bool*/ _persisted = false;
            //--TRIMMABLE-BOUNDARY-END(8590917736)
            
            //--TRIMMABLE-BOUNDARY-START(4295950440)
            /*byte[]?*/ _buffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295950440)
            
            //--TRIMMABLE-BOUNDARY-START(21475819624)
            $ctor$1(/*int*/ windowBits, /*bool*/ persisted)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475819624);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._windowBits = -windowBits;
                    this._persisted = persisted;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475819624)
            
            //--TRIMMABLE-BOUNDARY-START(42950656104)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._stream?.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(42950656104)
            
            //--TRIMMABLE-BOUNDARY-START(47245623400)
            /*void */ ReleaseBuffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245623400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let toReturn;
                if ($.$is(this._buffer, $.$typeArray($.$$.S.Byte), { set $v($v){ toReturn = $v; } }))
                {
                    this._buffer = null;
                    $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245623400)
            
            //--TRIMMABLE-BOUNDARY-START(34360721512)
            /*ReadOnlySpan<byte> */ Deflate$1(/*ReadOnlySpan<byte>*/ payload, /*bool*/ endOfMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360721512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._buffer === null, "Invalid state, ReleaseBuffer not called.");
                /*int*/ let MinInitialBufferLength = ((4 * 1024) | 0);
                this._buffer = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent($.$$.S.Math.Max$4(payload.Length, MinInitialBufferLength));
                /*int*/ let position = 0;
                while(true)
                {
                    /*int*/ let consumed;
                    /*int*/ let written;
                    /*bool*/ let needsMoreOutput;
                    this.DeflatePrivate(payload, $.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, position), endOfMessage, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$ref(() => written, ($v) => written = $v, $.$$.S.Int32), $.$ref(() => needsMoreOutput, ($v) => needsMoreOutput = $v, $.$$.S.Boolean));
                    position += written;
                    if (!needsMoreOutput)
                    {
                        $.$$.SD.Debug.Assert$4(consumed === payload.Length, "consumed == payload.Length");
                        break;
                    }
                    payload = payload.Slice$1(consumed);
                    /*byte[]*/ let newBuffer = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent($.$cast((this._buffer.length * 1.3), $.$$.S.Int32));
                    $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, this._buffer, 0, position).CopyTo($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(newBuffer));
                    /*byte[]*/ let toReturn = this._buffer;
                    this._buffer = newBuffer;
                    $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(toReturn, false);
                }
                return new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$6(this._buffer, 0, position);
            }
            //--TRIMMABLE-BOUNDARY-END(34360721512)
            
            //--TRIMMABLE-BOUNDARY-START(38655688808)
            /*void */ DeflatePrivate(/*ReadOnlySpan<byte>*/ payload, /*Span<byte>*/ output, /*bool*/ endOfMessage, /*out int*/ consumed, /*out int*/ written, /*out bool*/ needsMoreOutput)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655688808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._stream ??= this.CreateDeflater();
                if (payload.Length === 0)
                {
                    consumed.$v = 0;
                    written.$v = 0;
                }
                else 
                {
                    this.UnsafeDeflate(payload, output, consumed, written, needsMoreOutput);
                    if (needsMoreOutput.$v)
                    {
                        $.$$.SD.Debug.Assert$4(written.$v === output.Length, "written == output.Length");
                        return;
                    }
                }
                written.$v += this.UnsafeFlush(output.Slice$1(written.$v), needsMoreOutput);
                if (needsMoreOutput.$v)
                {
                    return;
                }
                $.$$.SD.Debug.Assert$4($.$$.S.MemoryExtensions.EndsWith$2($.$$.S.Byte, $.$$.S.Span$$($.$$.S.Byte).op_Implicit(output.Slice(((written.$v - 4/*WebSocketInflater.FlushMarkerLength*/) | 0), 4/*WebSocketInflater.FlushMarkerLength*/)), $.$snws.SNWC.WebSocketInflater.FlushMarker), "The deflated block must always end with a flush marker.");
                if (endOfMessage)
                {
                    written.$v -= 4/*WebSocketInflater.FlushMarkerLength*/;
                }
                if (endOfMessage && !this._persisted)
                {
                    this._stream.Dispose();
                    this._stream = null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655688808)
            
            //--TRIMMABLE-BOUNDARY-START(51540590696)
            /*void */ UnsafeDeflate(/*ReadOnlySpan<byte>*/ input, /*Span<byte>*/ output, /*out int*/ consumed, /*out int*/ written, /*out bool*/ needsMoreBuffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540590696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!(this._stream === null), "_stream is not null");
                /*fixed*/ 
                {
                    /*byte**/ let fixedInput = input.GetPinnableReference();
                    /*fixed*/ 
                    {
                        /*byte**/ let fixedOutput = output.GetPinnableReference();
                        this._stream.NextIn = $.$$.$interop.$ptr2Addr(fixedInput);
                        this._stream.AvailIn = (input.Length >>> 0);
                        this._stream.NextOut = $.$$.$interop.$ptr2Addr(fixedOutput);
                        this._stream.AvailOut = (output.Length >>> 0);
                        /*var*/ let errorCode = $.$snws.SNWC.WebSocketDeflater.Deflate(this._stream, 0/*FlushCode.NoFlush*/);
                        consumed.$v = ((input.Length - (this._stream.AvailIn | 0)) | 0);
                        written.$v = ((output.Length - (this._stream.AvailOut | 0)) | 0);
                        needsMoreBuffer.$v = errorCode === -5/*ErrorCode.BufError*/ || this._stream.AvailIn > 0 || written.$v === output.Length;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540590696)
            
            //--TRIMMABLE-BOUNDARY-START(55835557992)
            /*int */ UnsafeFlush(/*Span<byte>*/ output, /*out bool*/ needsMoreBuffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835557992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!(this._stream === null), "_stream is not null");
                $.$$.SD.Debug.Assert$4(this._stream.AvailIn === 0, "_stream.AvailIn == 0");
                $.$$.SD.Debug.Assert$4(output.Length > 0, "output.Length > 0");
                /*fixed*/ 
                {
                    /*byte**/ let fixedOutput = output.GetPinnableReference();
                    this._stream.NextIn = $.$$.S.IntPtr.Zero;
                    this._stream.AvailIn = 0;
                    this._stream.NextOut = $.$$.$interop.$ptr2Addr(fixedOutput);
                    this._stream.AvailOut = (output.Length >>> 0);
                    /*ErrorCode*/ let errorCode = $.$snws.SNWC.WebSocketDeflater.Deflate(this._stream, 5/*FlushCode.Block*/);
                    $.$$.SD.Debug.Assert$4((errorCode === 0/*ErrorCode.Ok*/) || (errorCode === -5/*ErrorCode.BufError*/), "errorCode is ErrorCode.Ok or ErrorCode.BufError");
                    needsMoreBuffer.$v = this._stream.AvailOut < 6;
                    if (!needsMoreBuffer.$v)
                    {
                        errorCode = $.$snws.SNWC.WebSocketDeflater.Deflate(this._stream, 2/*FlushCode.SyncFlush*/);
                        $.$$.SD.Debug.Assert$4(errorCode === 0/*ErrorCode.Ok*/, "errorCode == ErrorCode.Ok");
                    }
                    return ((output.Length - (this._stream.AvailOut | 0)) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835557992)
            
            //--TRIMMABLE-BOUNDARY-START(30065754216)
            static /*ErrorCode */ Deflate(/*ZLibStreamHandle*/ stream, /*FlushCode*/ flushCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065754216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ErrorCode*/ let errorCode = stream.Deflate(flushCode);
                if (((errorCode === 0/*ErrorCode.Ok*/) || (errorCode === 1/*ErrorCode.StreamEnd*/)) || (errorCode === -5/*ErrorCode.BufError*/))
                {
                    return errorCode;
                }
                /*string*/ let message = errorCode === -2/*ErrorCode.StreamError*/ ? $.$snws.S.SR.ZLibErrorInconsistentStream : $.$snws.S.SR.Format$6($.$snws.S.SR.ZLibErrorUnexpected, $.$box(errorCode, $.$$.S.Int32));
                throw new $.$snws.SNW.WebSocketException().$ctor$34(message);
            }
            //--TRIMMABLE-BOUNDARY-END(30065754216)
            
            //--TRIMMABLE-BOUNDARY-START(25770786920)
            /*ZLibStreamHandle */ CreateDeflater()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770786920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ZLibStreamHandle?*/ let stream = null;
                /*ErrorCode*/ let errorCode;
                try
                {
                    errorCode = $.$snws.SIC.ZLibNative.CreateZLibStreamForDeflate($.$ref(() => stream, ($v) => stream = $v, $.$snws.SIC.ZLibNative.ZLibStreamHandle), -1/*CompressionLevel.DefaultCompression*/, this._windowBits, 8/*Deflate_DefaultMemLevel*/, 0/*CompressionStrategy.DefaultStrategy*/);
                }
                catch(cause)
                {
                    stream?.Dispose();
                    throw new $.$snws.SNW.WebSocketException().$ctor$33($.$snws.S.SR.ZLibErrorDLLLoadError, cause);
                }
                if (errorCode === 0/*ErrorCode.Ok*/)
                {
                    return stream;
                }
                stream.Dispose();
                /*string*/ let message = errorCode === -4/*ErrorCode.MemError*/ ? $.$snws.S.SR.ZLibErrorNotEnoughMemory : $.$snws.S.SR.Format$6($.$snws.S.SR.ZLibErrorUnexpected, $.$box(errorCode, $.$$.S.Int32));
                throw new $.$snws.SNW.WebSocketException().$ctor$34(message);
            }
            //--TRIMMABLE-BOUNDARY-END(25770786920)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            static $h = 983144;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950656104),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 983144,
      "h": 42950656104,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950656104),
//--TRIMMABLE-BOUNDARY-START(47245623400),
    {
      "r": 65537,
      "n": "ReleaseBuffer",
      "d": 983144,
      "h": 47245623400,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245623400),
//--TRIMMABLE-BOUNDARY-START(34360721512),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "payload",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "endOfMessage",
          "p": 262145
        }
      ],
      "n": "Deflate",
      "o": "@$1",
      "d": 983144,
      "h": 34360721512,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360721512),
//--TRIMMABLE-BOUNDARY-START(38655688808),
    {
      "r": 65537,
      "p": [
        {
          "n": "payload",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "output",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "consumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "written",
          "p": 655361,
          "f": 2
        },
        {
          "n": "needsMoreOutput",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "DeflatePrivate",
      "d": 983144,
      "h": 38655688808,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655688808),
//--TRIMMABLE-BOUNDARY-START(51540590696),
    {
      "r": 65537,
      "p": [
        {
          "n": "input",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "output",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "consumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "written",
          "p": 655361,
          "f": 2
        },
        {
          "n": "needsMoreBuffer",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "UnsafeDeflate",
      "d": 983144,
      "h": 51540590696,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540590696),
//--TRIMMABLE-BOUNDARY-START(55835557992),
    {
      "r": 655361,
      "p": [
        {
          "n": "output",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "needsMoreBuffer",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "UnsafeFlush",
      "d": 983144,
      "h": 55835557992,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55835557992),
//--TRIMMABLE-BOUNDARY-START(30065754216),
    {
      "r": 524392,
      "p": [
        {
          "n": "stream",
          "p": 655464
        },
        {
          "n": "flushCode",
          "p": 589928
        }
      ],
      "n": "Deflate",
      "d": 983144,
      "h": 30065754216,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065754216),
//--TRIMMABLE-BOUNDARY-START(25770786920),
    {
      "r": 655464,
      "n": "CreateDeflater",
      "d": 983144,
      "h": 25770786920,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770786920)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180852328),
    {
      "t": 655361,
      "n": "_windowBits",
      "d": 983144,
      "h": 17180852328,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180852328),
//--TRIMMABLE-BOUNDARY-START(12885885032),
    {
      "t": 655464,
      "n": "_stream",
      "d": 983144,
      "h": 12885885032,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885885032),
//--TRIMMABLE-BOUNDARY-START(8590917736),
    {
      "t": 262145,
      "n": "_persisted",
      "d": 983144,
      "h": 8590917736,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590917736),
//--TRIMMABLE-BOUNDARY-START(4295950440),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_buffer",
      "d": 983144,
      "h": 4295950440,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950440)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475819624),
    {
      "p": [
        {
          "n": "windowBits",
          "p": 655361
        },
        {
          "n": "persisted",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983144,
      "h": 21475819624,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475819624)
  ],
  "h": 983144
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.Compression.WebSocketDeflater`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}Compression${separator}WebSocketDeflater`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983144)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507432)
        $asm.$str(`$snws.SNW.ValueWebSocketReceiveResult`, ($self) => class ValueWebSocketReceiveResult extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296474728)
            /*uint*/ _countAndEndOfMessage = 0;
            //--TRIMMABLE-BOUNDARY-END(4296474728)
            
            //--TRIMMABLE-BOUNDARY-START(8591442024)
            /*WebSocketMessageType*/ _messageType = 0;
            //--TRIMMABLE-BOUNDARY-END(8591442024)
            
            //--TRIMMABLE-BOUNDARY-START(17181376616)
            $ctor$3(/*int*/ count, /*WebSocketMessageType*/ messageType, /*bool*/ endOfMessage)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181376616);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, count, "count");
                    if ((messageType >>> 0) > (2/*WebSocketMessageType.Close*/ >>> 0))
                    {
                        $.$snws.SNW.ValueWebSocketReceiveResult.ThrowMessageTypeOutOfRange();
                    }
                    this._countAndEndOfMessage = (count >>> 0) | ((endOfMessage ? 1 << 31 : 0) >>> 0);
                    this._messageType = messageType;
                    $.$$.SD.Debug.Assert$4(count === this.Count, "count == Count");
                    $.$$.SD.Debug.Assert$4(messageType === this.MessageType, "messageType == MessageType");
                    $.$$.SD.Debug.Assert$4(endOfMessage === this.EndOfMessage, "endOfMessage == EndOfMessage");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181376616)
            
            //--TRIMMABLE-BOUNDARY-START(21476343912)
            /*int */ get Count()
            {
                return ((this._countAndEndOfMessage & 2147483647) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(21476343912)
            
            //--TRIMMABLE-BOUNDARY-START(25771311208)
            /*bool */ get EndOfMessage()
            {
                return (this._countAndEndOfMessage & 2147483648) === 2147483648;
            }
            //--TRIMMABLE-BOUNDARY-END(25771311208)
            
            //--TRIMMABLE-BOUNDARY-START(55836082280)
            /*WebSocketMessageType */ get MessageType()
            {
                return this._messageType;
            }
            //--TRIMMABLE-BOUNDARY-END(55836082280)
            
            //--TRIMMABLE-BOUNDARY-START(60131049576)
            static /*void */ ThrowMessageTypeOutOfRange()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131049576);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("messageType");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131049576)
            
            //--TRIMMABLE-BOUNDARY-START(12886409320)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886409320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886409320)
            
            //--TRIMMABLE-BOUNDARY-START(12886409320)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886409320)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._countAndEndOfMessage = this._countAndEndOfMessage;
                copy._messageType = this._messageType;
                return copy;
            }
            static $h = 1507432;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476343912),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361245800,
        "f": 50331649
      },
      "n": "Count",
      "d": 1507432,
      "h": 21476343912,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476343912),
//--TRIMMABLE-BOUNDARY-START(25771311208),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951180392,
        "f": 50331649
      },
      "n": "EndOfMessage",
      "d": 1507432,
      "h": 25771311208,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771311208),
//--TRIMMABLE-BOUNDARY-START(55836082280),
    {
      "p": 2162792,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541114984,
        "f": 50331649
      },
      "n": "MessageType",
      "d": 1507432,
      "h": 55836082280,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836082280)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60131049576),
    {
      "r": 65537,
      "n": "ThrowMessageTypeOutOfRange",
      "d": 1507432,
      "h": 60131049576,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60131049576)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296474728),
    {
      "t": 720897,
      "n": "_countAndEndOfMessage",
      "d": 1507432,
      "h": 4296474728,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474728),
//--TRIMMABLE-BOUNDARY-START(8591442024),
    {
      "t": 2162792,
      "n": "_messageType",
      "d": 1507432,
      "h": 8591442024,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591442024)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181376616),
    {
      "p": [
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "endOfMessage",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1507432,
      "h": 17181376616,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181376616),
//--TRIMMABLE-BOUNDARY-START(12886409320),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1507432,
      "h": 12886409320,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886409320)
  ],
  "h": 1507432
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.ValueWebSocketReceiveResult`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}ValueWebSocketReceiveResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507432)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114216)
        $asm.$cls(`$snws.SNW.ManagedWebSocket`, ($self) => class ManagedWebSocket extends $.$snws.SNW.WebSocket
        {
            //--TRIMMABLE-BOUNDARY-START(266289086568)
            /*bool */ get IsUnsolicitedPongKeepAlive()
            {
                return this._keepAlivePingState === null;
            }
            //--TRIMMABLE-BOUNDARY-END(266289086568)
            
            //--TRIMMABLE-BOUNDARY-START(261994119272)
            /*void */ HeartBeat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994119272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsUnsolicitedPongKeepAlive)
                {
                    this.UnsolicitedPongHeartBeat();
                }
                else 
                {
                    this.KeepAlivePingHeartBeat();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(261994119272)
            
            //--TRIMMABLE-BOUNDARY-START(416612941928)
            /*void */ UnsolicitedPongHeartBeat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612941928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, null, "UnsolicitedPongHeartBeat");
                }
                this.LogExceptions$1(this.TrySendKeepAliveFrameAsync(10/*MessageOpcode.Pong*/, new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))()));
            }
            //--TRIMMABLE-BOUNDARY-END(416612941928)
            
            //--TRIMMABLE-BOUNDARY-START(408023007336)
            /*ValueTask */ TrySendKeepAliveFrameAsync(/*MessageOpcode*/ opcode, /*ReadOnlyMemory<byte>*/ payload)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408023007336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4((opcode === 10) || (!this.IsUnsolicitedPongKeepAlive && opcode === 9), "(opcode is MessageOpcode.Pong) || (!IsUnsolicitedPongKeepAlive && opcode is MessageOpcode.Ping)");
                if (!$.$snws.SNW.WebSocketStateHelper.IsValidSendState(this._state))
                {
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.Trace(this, `Cannot send keep-alive frame in ${$.$strNN("_state")}=${$.$strNN($.$$.S.Enum.ToStringT($.$snws.SNW.WebSocketState, $.$$.S.UInt32, this._state))}`, "TrySendKeepAliveFrameAsync");
                    }
                    return $.$$.STT.ValueTask.CompletedTask;
                }
                return this.SendFrameAsync(opcode, true, true, payload, $.$$.ST$1.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(408023007336)
            
            //--TRIMMABLE-BOUNDARY-START(274879021160)
            /*void */ KeepAlivePingHeartBeat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879021160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._keepAlivePingState !== null, "_keepAlivePingState != null");
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, null, "KeepAlivePingHeartBeat");
                }
                /*bool*/ let shouldSendPing = false;
                /*long*/ let pingPayload = BigInt(-1);
                try
                {
                    //lock(StateUpdateLock)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this.StateUpdateLock)
                        {
                            if (!(this._keepAlivePingState.Exception === null))
                            {
                                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                                {
                                    $.$snws.SN.NetEventSource.Trace(this, `KeepAlive already faulted, skipping... (exception: ${$.$strNN(this._keepAlivePingState.Exception.Message)})`, "KeepAlivePingHeartBeat");
                                }
                                return;
                            }
                            /*long*/ let now = $.$$.S.Environment.TickCount64;
                            if (this._keepAlivePingState.PingSent)
                            {
                                if (now > this._keepAlivePingState.PingTimeoutTimestamp)
                                {
                                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                                    {
                                        $.$snws.SN.NetEventSource.Trace(this, `Keep-alive ping timed out after ${$.$strNN(this._keepAlivePingState.TimeoutMs)}ms. Expected pong with payload ${$.$strNN(this._keepAlivePingState.PingPayload)}`, "KeepAlivePingHeartBeat");
                                    }
                                    /*Exception*/ let exc = $.$$.SRE$1.ExceptionDispatchInfo.SetCurrentStackTrace(new $.$snws.SNW.WebSocketException().$ctor$30(2/*WebSocketError.Faulted*/, $.$snws.S.SR.net_Websockets_KeepAlivePingTimeout));
                                    this._keepAlivePingState.OnKeepAliveFaultedCore(exc);
                                    return;
                                }
                            }
                            else 
                            {
                                if (now > this._keepAlivePingState.NextPingRequestTimestamp)
                                {
                                    this._keepAlivePingState.OnNextPingRequestCore();
                                    shouldSendPing = true;
                                    pingPayload = this._keepAlivePingState.PingPayload;
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this.StateUpdateLock)
                    }
                    if (shouldSendPing)
                    {
                        this.LogExceptions$1(this.SendPingAsync(pingPayload));
                    }
                }
                catch(e)
                {
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.TraceException(this, e, "KeepAlivePingHeartBeat");
                    }
                    this._keepAlivePingState.OnKeepAliveFaulted(e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(274879021160)
            
            //--TRIMMABLE-BOUNDARY-START(360778367080)
            /*ValueTask *//*async*/  SendPingAsync(/*long*/ pingPayload)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(360778367080);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(this._keepAlivePingState !== null, "_keepAlivePingState != null");
                    /*byte[]*/ let pingPayloadBuffer = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [8], null);
                    $.$$.SBB.BinaryPrimitives.WriteInt64BigEndian($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(pingPayloadBuffer), pingPayload);
                    ($t1 = this.TrySendKeepAliveFrameAsync(9/*MessageOpcode.Ping*/, $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).op_Implicit$1(pingPayloadBuffer)).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.KeepAlivePingSent(this, pingPayload);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(360778367080)
            
            //--TRIMMABLE-BOUNDARY-START(1179752)
            static $_KeepAlivePingState;
            static get KeepAlivePingState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1179752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SNW.ManagedWebSocket;
                return $cls.$_KeepAlivePingState ??= $asm.$ncls(`$snws.SNW.ManagedWebSocket.KeepAlivePingState`, ($self) => class KeepAlivePingState extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(167504904296)
                    /*int*/ static PingPayloadSize = 8;
                    //--TRIMMABLE-BOUNDARY-END(167504904296)
                    
                    //--TRIMMABLE-BOUNDARY-START(133145165928)
                    /*int*/ static MinIntervalMs = 1;
                    //--TRIMMABLE-BOUNDARY-END(133145165928)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296147048)
                    /*ManagedWebSocket*/ _parent = null;
                    //--TRIMMABLE-BOUNDARY-END(4296147048)
                    
                    //--TRIMMABLE-BOUNDARY-START(223339479144)
                    /*object */ get StateUpdateLock()
                    {
                        return this._parent.StateUpdateLock;
                    }
                    //--TRIMMABLE-BOUNDARY-END(223339479144)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950852712)
                    /*int*/ DelayMs = 0;
                    //--TRIMMABLE-BOUNDARY-END(42950852712)
                    
                    //--TRIMMABLE-BOUNDARY-START(227634446440)
                    /*int*/ TimeoutMs = 0;
                    //--TRIMMABLE-BOUNDARY-END(227634446440)
                    
                    //--TRIMMABLE-BOUNDARY-START(128850198632)
                    /*int */ get HeartBeatIntervalMs()
                    {
                        return $.$$.S.Math.Max$4($.trunc($.$$.S.Math.Min$4(this.DelayMs, this.TimeoutMs) / 4), 1/*MinIntervalMs*/);
                    }
                    //--TRIMMABLE-BOUNDARY-END(128850198632)
                    
                    //--TRIMMABLE-BOUNDARY-START(163209937000)
                    /*long*/ PingPayload = 0n;
                    //--TRIMMABLE-BOUNDARY-END(163209937000)
                    
                    //--TRIMMABLE-BOUNDARY-START(171799871592)
                    /*bool*/ PingSent = false;
                    //--TRIMMABLE-BOUNDARY-END(171799871592)
                    
                    //--TRIMMABLE-BOUNDARY-START(176094838888)
                    /*long*/ PingTimeoutTimestamp = 0n;
                    //--TRIMMABLE-BOUNDARY-END(176094838888)
                    
                    //--TRIMMABLE-BOUNDARY-START(137440133224)
                    /*long*/ NextPingRequestTimestamp = 0n;
                    //--TRIMMABLE-BOUNDARY-END(137440133224)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245820008)
                    /*Exception?*/ Exception = null;
                    //--TRIMMABLE-BOUNDARY-END(47245820008)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655885416)
                    $ctor$1(/*TimeSpan*/ keepAliveInterval, /*TimeSpan*/ keepAliveTimeout, /*ManagedWebSocket*/ parent)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(38655885416);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.DelayMs = TimeSpanToMs(keepAliveInterval);
                            this.TimeoutMs = TimeSpanToMs(keepAliveTimeout);
                            this.NextPingRequestTimestamp = BigInt.asIntN(64, $.$$.S.Environment.TickCount64 + BigInt(this.DelayMs));
                            this.PingTimeoutTimestamp = BigInt(-1/*Timeout.Infinite*/);
                            this._parent = parent;
                            /*static int*/  function TimeSpanToMs(/*TimeSpan*/ value)
                            {
                                {
                                    return $.$cast($.$$.S.Math.Clamp$5($.$cast(value.TotalMilliseconds, $.$$.S.Int64), BigInt(1/*MinIntervalMs*/), BigInt(2147483647/*int.MaxValue*/)), $.$$.S.Int32);
                                }
                            }
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655885416)
                    
                    //--TRIMMABLE-BOUNDARY-START(141735100520)
                    /*void */ OnDataReceived()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(141735100520);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock(StateUpdateLock)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1(this.StateUpdateLock)
                            {
                                this.NextPingRequestTimestamp = BigInt.asIntN(64, $.$$.S.Environment.TickCount64 + BigInt(this.DelayMs));
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit(this.StateUpdateLock)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(141735100520)
                    
                    //--TRIMMABLE-BOUNDARY-START(158914969704)
                    /*void */ OnPongResponseReceived(/*long*/ pongPayload)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(158914969704);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock(StateUpdateLock)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1(this.StateUpdateLock)
                            {
                                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                                {
                                    $.$snws.SN.NetEventSource.Trace(this, `pongPayload=${$.$strNN(pongPayload)}`, "OnPongResponseReceived");
                                }
                                if (!this.PingSent)
                                {
                                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                                    {
                                        $.$snws.SN.NetEventSource.Trace(this, `Not waiting for Pong. Skipping.`, "OnPongResponseReceived");
                                    }
                                    return;
                                }
                                if (pongPayload === this.PingPayload)
                                {
                                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                                    {
                                        $.$snws.SN.NetEventSource.PongResponseReceived(this, pongPayload);
                                    }
                                    this.PingTimeoutTimestamp = 9223372036854775807n;
                                    this.PingSent = false;
                                }
                                else 
                                {
                                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                                    {
                                        $.$snws.SN.NetEventSource.Trace(this, `Expected payload ${$.$strNN(this.PingPayload)}. Skipping.`, "OnPongResponseReceived");
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit(this.StateUpdateLock)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(158914969704)
                    
                    //--TRIMMABLE-BOUNDARY-START(154620002408)
                    /*void */ OnNextPingRequestCore()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(154620002408);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4($.$$.ST$1.Monitor.IsEntered(this.StateUpdateLock), "Monitor.IsEntered(StateUpdateLock)");
                        this.PingSent = true;
                        this.PingTimeoutTimestamp = BigInt.asIntN(64, $.$$.S.Environment.TickCount64 + BigInt(this.TimeoutMs));
                        ++this.PingPayload;
                    }
                    //--TRIMMABLE-BOUNDARY-END(154620002408)
                    
                    //--TRIMMABLE-BOUNDARY-START(146030067816)
                    /*void */ OnKeepAliveFaulted(/*Exception*/ exc)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(146030067816);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock(StateUpdateLock)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1(this.StateUpdateLock)
                            {
                                this.OnKeepAliveFaultedCore(exc);
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit(this.StateUpdateLock)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(146030067816)
                    
                    //--TRIMMABLE-BOUNDARY-START(150325035112)
                    /*void */ OnKeepAliveFaultedCore(/*Exception*/ exc)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(150325035112);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4($.$$.ST$1.Monitor.IsEntered(this.StateUpdateLock), "Monitor.IsEntered(StateUpdateLock)");
                        if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                        {
                            $.$snws.SN.NetEventSource.TraceErrorMsg(this, exc, "OnKeepAliveFaultedCore");
                        }
                        if (this._parent._disposed)
                        {
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.Trace(this, `WebSocket already disposed, skipping...`, "OnKeepAliveFaultedCore");
                            }
                            return;
                        }
                        if (this._parent.State === 5)
                        {
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.Trace(this, `WebSocket is already closed, skipping...`, "OnKeepAliveFaultedCore");
                            }
                            return;
                        }
                        if (this._parent.State === 6)
                        {
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.Trace(this, `WebSocket is already aborted, skipping...`, "OnKeepAliveFaultedCore");
                            }
                            this._parent.Dispose();
                            return;
                        }
                        this.Exception = exc;
                        this._parent.OnAbortedCore();
                        this._parent.DisposeCore();
                    }
                    //--TRIMMABLE-BOUNDARY-END(150325035112)
                    
                    static $h = 1179752;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(223339479144),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965296744,
        "f": 50331650
      },
      "n": "StateUpdateLock",
      "d": 1179752,
      "h": 223339479144,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(223339479144),
//--TRIMMABLE-BOUNDARY-START(42950852712),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835754600,
        "f": 50331656
      },
      "n": "DelayMs",
      "d": 1179752,
      "h": 42950852712,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(42950852712),
//--TRIMMABLE-BOUNDARY-START(227634446440),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555231336,
        "f": 50331656
      },
      "n": "TimeoutMs",
      "d": 1179752,
      "h": 227634446440,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(227634446440),
//--TRIMMABLE-BOUNDARY-START(128850198632),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015623784,
        "f": 50331656
      },
      "n": "HeartBeatIntervalMs",
      "d": 1179752,
      "h": 128850198632,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(128850198632),
//--TRIMMABLE-BOUNDARY-START(163209937000),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195492968,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201864642664,
        "f": 83886082
      },
      "n": "PingPayload",
      "d": 1179752,
      "h": 163209937000,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(163209937000),
//--TRIMMABLE-BOUNDARY-START(171799871592),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785427560,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454577256,
        "f": 83886082
      },
      "n": "PingSent",
      "d": 1179752,
      "h": 171799871592,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(171799871592),
//--TRIMMABLE-BOUNDARY-START(176094838888),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375362152,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044511848,
        "f": 83886082
      },
      "n": "PingTimeoutTimestamp",
      "d": 1179752,
      "h": 176094838888,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(176094838888),
//--TRIMMABLE-BOUNDARY-START(137440133224),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605558376,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193274708072,
        "f": 83886082
      },
      "n": "NextPingRequestTimestamp",
      "d": 1179752,
      "h": 137440133224,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(137440133224)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(141735100520),
    {
      "r": 65537,
      "n": "OnDataReceived",
      "d": 1179752,
      "h": 141735100520,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(141735100520),
//--TRIMMABLE-BOUNDARY-START(158914969704),
    {
      "r": 65537,
      "p": [
        {
          "n": "pongPayload",
          "p": 917505
        }
      ],
      "n": "OnPongResponseReceived",
      "d": 1179752,
      "h": 158914969704,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(158914969704),
//--TRIMMABLE-BOUNDARY-START(154620002408),
    {
      "r": 65537,
      "n": "OnNextPingRequestCore",
      "d": 1179752,
      "h": 154620002408,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(154620002408),
//--TRIMMABLE-BOUNDARY-START(146030067816),
    {
      "r": 65537,
      "p": [
        {
          "n": "exc",
          "p": 80805889
        }
      ],
      "n": "OnKeepAliveFaulted",
      "d": 1179752,
      "h": 146030067816,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(146030067816),
//--TRIMMABLE-BOUNDARY-START(150325035112),
    {
      "r": 65537,
      "p": [
        {
          "n": "exc",
          "p": 80805889
        }
      ],
      "n": "OnKeepAliveFaultedCore",
      "d": 1179752,
      "h": 150325035112,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(150325035112)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(167504904296),
    {
      "t": 655361,
      "n": "PingPayloadSize",
      "d": 1179752,
      "h": 167504904296,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167504904296),
//--TRIMMABLE-BOUNDARY-START(133145165928),
    {
      "t": 655361,
      "n": "MinIntervalMs",
      "d": 1179752,
      "h": 133145165928,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(133145165928),
//--TRIMMABLE-BOUNDARY-START(4296147048),
    {
      "t": 1114216,
      "n": "_parent",
      "d": 1179752,
      "h": 4296147048,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147048)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655885416),
    {
      "p": [
        {
          "n": "keepAliveInterval",
          "p": 186646529
        },
        {
          "n": "keepAliveTimeout",
          "p": 186646529
        },
        {
          "n": "parent",
          "p": 1114216
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1179752,
      "h": 38655885416,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655885416)
  ],
  "d": 1114216,
  "h": 1179752
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.ManagedWebSocket+KeepAlivePingState`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}ManagedWebSocket${separator}KeepAlivePingState`; }
                }, $cls, ($v) => $cls.$_KeepAlivePingState = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1179752)
            
            //--TRIMMABLE-BOUNDARY-START(326418628712)
            /*UTF8Encoding*/ static s_textEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(326418628712)
            
            //--TRIMMABLE-BOUNDARY-START(296353857640)
            /*int*/ static MaxMessageHeaderLength = 14;
            //--TRIMMABLE-BOUNDARY-END(296353857640)
            
            //--TRIMMABLE-BOUNDARY-START(292058890344)
            /*int*/ static MaxControlPayloadLength = 125;
            //--TRIMMABLE-BOUNDARY-END(292058890344)
            
            //--TRIMMABLE-BOUNDARY-START(287763923048)
            /*int*/ static MaskLength = 4;
            //--TRIMMABLE-BOUNDARY-END(287763923048)
            
            //--TRIMMABLE-BOUNDARY-START(94490394728)
            /*Stream*/ _stream = null;
            //--TRIMMABLE-BOUNDARY-END(94490394728)
            
            //--TRIMMABLE-BOUNDARY-START(25770917992)
            /*bool*/ _isServer = false;
            //--TRIMMABLE-BOUNDARY-END(25770917992)
            
            //--TRIMMABLE-BOUNDARY-START(98785362024)
            /*string?*/ _subprotocol = null;
            //--TRIMMABLE-BOUNDARY-END(98785362024)
            
            //--TRIMMABLE-BOUNDARY-START(34360852584)
            /*Timer?*/ _keepAliveTimer = null;
            //--TRIMMABLE-BOUNDARY-END(34360852584)
            
            //--TRIMMABLE-BOUNDARY-START(51540721768)
            /*Memory<byte>*/ _receiveBuffer;
            //--TRIMMABLE-BOUNDARY-END(51540721768)
            
            //--TRIMMABLE-BOUNDARY-START(103080329320)
            /*Utf8MessageState*/ _utf8TextState = null;
            //--TRIMMABLE-BOUNDARY-END(103080329320)
            
            //--TRIMMABLE-BOUNDARY-START(81605492840)
            /*AsyncMutex*/ _sendMutex = null;
            //--TRIMMABLE-BOUNDARY-END(81605492840)
            
            //--TRIMMABLE-BOUNDARY-START(73015558248)
            /*AsyncMutex*/ _receiveMutex = null;
            //--TRIMMABLE-BOUNDARY-END(73015558248)
            
            //--TRIMMABLE-BOUNDARY-START(90195427432)
            /*WebSocketState*/ _state = 2;
            //--TRIMMABLE-BOUNDARY-END(90195427432)
            
            //--TRIMMABLE-BOUNDARY-START(17180983400)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(17180983400)
            
            //--TRIMMABLE-BOUNDARY-START(85900460136)
            /*bool*/ _sentCloseFrame = false;
            //--TRIMMABLE-BOUNDARY-END(85900460136)
            
            //--TRIMMABLE-BOUNDARY-START(64425623656)
            /*bool*/ _receivedCloseFrame = false;
            //--TRIMMABLE-BOUNDARY-END(64425623656)
            
            //--TRIMMABLE-BOUNDARY-START(4296081512)
            /*WebSocketCloseStatus?*/ _closeStatus = null;
            //--TRIMMABLE-BOUNDARY-END(4296081512)
            
            //--TRIMMABLE-BOUNDARY-START(8591048808)
            /*string?*/ _closeStatusDescription = null;
            //--TRIMMABLE-BOUNDARY-END(8591048808)
            
            //--TRIMMABLE-BOUNDARY-START(38655819880)
            /*MessageHeader*/ _lastReceiveHeader;
            //--TRIMMABLE-BOUNDARY-END(38655819880)
            
            //--TRIMMABLE-BOUNDARY-START(60130656360)
            /*int*/ _receiveBufferOffset = 0;
            //--TRIMMABLE-BOUNDARY-END(60130656360)
            
            //--TRIMMABLE-BOUNDARY-START(55835689064)
            /*int*/ _receiveBufferCount = 0;
            //--TRIMMABLE-BOUNDARY-END(55835689064)
            
            //--TRIMMABLE-BOUNDARY-START(68720590952)
            /*int*/ _receivedMaskOffsetOffset = 0;
            //--TRIMMABLE-BOUNDARY-END(68720590952)
            
            //--TRIMMABLE-BOUNDARY-START(77310525544)
            /*byte[]?*/ _sendBuffer = null;
            //--TRIMMABLE-BOUNDARY-END(77310525544)
            
            //--TRIMMABLE-BOUNDARY-START(47245754472)
            /*bool*/ _lastSendWasFragment = false;
            //--TRIMMABLE-BOUNDARY-END(47245754472)
            
            //--TRIMMABLE-BOUNDARY-START(42950787176)
            /*bool*/ _lastSendHadDisableCompression = false;
            //--TRIMMABLE-BOUNDARY-END(42950787176)
            
            //--TRIMMABLE-BOUNDARY-START(369368301672)
            /*object */ get StateUpdateLock()
            {
                return this._sendMutex;
            }
            //--TRIMMABLE-BOUNDARY-END(369368301672)
            
            //--TRIMMABLE-BOUNDARY-START(21475950696)
            /*WebSocketInflater?*/ _inflater = null;
            //--TRIMMABLE-BOUNDARY-END(21475950696)
            
            //--TRIMMABLE-BOUNDARY-START(12886016104)
            /*WebSocketDeflater?*/ _deflater = null;
            //--TRIMMABLE-BOUNDARY-END(12886016104)
            
            //--TRIMMABLE-BOUNDARY-START(30065885288)
            /*KeepAlivePingState?*/ _keepAlivePingState = null;
            //--TRIMMABLE-BOUNDARY-END(30065885288)
            
            //--TRIMMABLE-BOUNDARY-START(111670263912)
            $ctor$2(/*Stream*/ stream, /*bool*/ isServer, /*string?*/ subprotocol, /*TimeSpan*/ keepAliveInterval, /*TimeSpan*/ keepAliveTimeout)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670263912);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(this.StateUpdateLock !== null, `Expected ${$.$strNN("StateUpdateLock")} to be non-null`);
                    $.$$.SD.Debug.Assert$4(stream !== null, `Expected non-null ${$.$strNN("stream")}`);
                    $.$$.SD.Debug.Assert$4(stream.CanRead, `Expected readable ${$.$strNN("stream")}`);
                    $.$$.SD.Debug.Assert$4(stream.CanWrite, `Expected writeable ${$.$strNN("stream")}`);
                    $.$$.SD.Debug.Assert$1($.$$.S.TimeSpan.op_Equality(keepAliveInterval, $.$$.ST$1.Timeout.InfiniteTimeSpan) || $.$$.S.TimeSpan.op_GreaterThanOrEqual(keepAliveInterval, $.$$.S.TimeSpan.Zero), `Invalid ${$.$strNN("keepAliveInterval")}: ${$.$strNN(keepAliveInterval.ToString())}`);
                    $.$$.SD.Debug.Assert$1($.$$.S.TimeSpan.op_Equality(keepAliveTimeout, $.$$.ST$1.Timeout.InfiniteTimeSpan) || $.$$.S.TimeSpan.op_GreaterThanOrEqual(keepAliveTimeout, $.$$.S.TimeSpan.Zero), `Invalid ${$.$strNN("keepAliveTimeout")}: ${$.$strNN(keepAliveTimeout.ToString())}`);
                    this._stream = stream;
                    this._isServer = isServer;
                    this._subprotocol = subprotocol;
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.Associate$1(this, stream, "ManagedWebSocket");
                        $.$snws.SN.NetEventSource.Associate$1(this, this._sendMutex, "ManagedWebSocket");
                        $.$snws.SN.NetEventSource.Associate$1(this, this._receiveMutex, "ManagedWebSocket");
                    }
                    /*int*/ let ReceiveBufferMinLength = 125/*MaxControlPayloadLength*/;
                    this._receiveBuffer = $.$$.S.Memory$$($.$$.S.Byte).op_Implicit$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [ReceiveBufferMinLength], null));
                    if ($.$$.S.TimeSpan.op_GreaterThan(keepAliveInterval, $.$$.S.TimeSpan.Zero))
                    {
                        /*long*/ let heartBeatIntervalMs = $.$cast(keepAliveInterval.TotalMilliseconds, $.$$.S.Int64);
                        if ($.$$.S.TimeSpan.op_GreaterThan(keepAliveTimeout, $.$$.S.TimeSpan.Zero))
                        {
                            this._keepAlivePingState = new $.$snws.SNW.ManagedWebSocket.KeepAlivePingState().$ctor$1(keepAliveInterval, keepAliveTimeout, this);
                            heartBeatIntervalMs = BigInt(this._keepAlivePingState.HeartBeatIntervalMs);
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.Associate$1(this, this._keepAlivePingState, "ManagedWebSocket");
                                $.$snws.SN.NetEventSource.Trace(this, `Enabling Ping/Pong Keep-Alive strategy: ping delay=${$.$strNN(this._keepAlivePingState.DelayMs)}ms, timeout=${$.$strNN(this._keepAlivePingState.TimeoutMs)}ms, heartbeat=${$.$strNN(heartBeatIntervalMs)}ms`, "ManagedWebSocket");
                            }
                        }
                        else if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                        {
                            $.$snws.SN.NetEventSource.Trace(this, `Enabling Unsolicited Pong Keep-Alive strategy: heartbeat=${$.$strNN(heartBeatIntervalMs)}ms`, "ManagedWebSocket");
                        }
                        this._keepAliveTimer = new $.$$.ST$1.Timer().$ctor$4(new $.$$.ST$1.TimerCallback().$ctor($.$snws.SNW.ManagedWebSocket, /*static*/ (/*s*/ s) =>
                        {
                            /*ManagedWebSocket?*/ let thisRef;
                            /*var*/ let wr = $.$cast(s, $.$$.S.WeakReference$$($.$snws.SNW.ManagedWebSocket));
                            if (wr.TryGetTarget($.$ref(() => thisRef, ($v) => thisRef = $v, $.$snws.SNW.ManagedWebSocket)))
                            {
                                thisRef.HeartBeat();
                            }
                        }, $DWwLcg ??= {"r":65537,"p":[{"n":"s","p":131073}],"n":"","d":1114216,"h":0,"f":17825826}), new ($.$$.S.WeakReference$$($.$snws.SNW.ManagedWebSocket))().$ctor$3(this), heartBeatIntervalMs, heartBeatIntervalMs);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(111670263912)
            
            //--TRIMMABLE-BOUNDARY-START(115965231208)
            $ctor$3(/*Stream*/ stream, /*WebSocketCreationOptions*/ options)
            {
                this.$ctor$2(stream, options.IsServer, options.SubProtocol, options.KeepAliveInterval, options.KeepAliveTimeout);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115965231208);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let deflateOptions = options.DangerousDeflateOptions;
                    if (!(deflateOptions === null))
                    {
                        if (options.IsServer)
                        {
                            this._inflater = new $.$snws.SNWC.WebSocketInflater().$ctor$1(deflateOptions.ClientMaxWindowBits, deflateOptions.ClientContextTakeover);
                            this._deflater = new $.$snws.SNWC.WebSocketDeflater().$ctor$1(deflateOptions.ServerMaxWindowBits, deflateOptions.ServerContextTakeover);
                        }
                        else 
                        {
                            this._inflater = new $.$snws.SNWC.WebSocketInflater().$ctor$1(deflateOptions.ServerMaxWindowBits, deflateOptions.ServerContextTakeover);
                            this._deflater = new $.$snws.SNWC.WebSocketDeflater().$ctor$1(deflateOptions.ClientMaxWindowBits, deflateOptions.ClientContextTakeover);
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(115965231208)
            
            //--TRIMMABLE-BOUNDARY-START(180389740648)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389740648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, null, "Dispose");
                }
                //lock(StateUpdateLock)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.StateUpdateLock)
                    {
                        this.DisposeCore();
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.StateUpdateLock)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180389740648)
            
            //--TRIMMABLE-BOUNDARY-START(184684707944)
            /*void */ DisposeCore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684707944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$$.ST$1.Monitor.IsEntered(this.StateUpdateLock), `Expected ${$.$strNN("StateUpdateLock")} to be held`);
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, `${$.$strNN("_disposed")}=${$.$strNN(this._disposed)}`, "DisposeCore");
                }
                if (!this._disposed)
                {
                    this._disposed = true;
                    this._keepAliveTimer?.Dispose();
                    this._stream.Dispose();
                    /*WebSocketState*/ let state = this._state;
                    if (state < 6/*WebSocketState.Aborted*/)
                    {
                        this._state = 5/*WebSocketState.Closed*/;
                    }
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.Trace(this, `State transition from ${$.$strNN($.$$.S.Enum.ToStringT($.$snws.SNW.WebSocketState, $.$$.S.UInt32, state))} to ${$.$strNN($.$$.S.Enum.ToStringT($.$snws.SNW.WebSocketState, $.$$.S.UInt32, this._state))}`, "DisposeCore");
                    }
                    $.$snws.SNW.ManagedWebSocket.DisposeSafe(this._inflater, this._receiveMutex);
                    $.$snws.SNW.ManagedWebSocket.DisposeSafe(this._deflater, this._sendMutex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684707944)
            
            //--TRIMMABLE-BOUNDARY-START(188979675240)
            static /*void */ DisposeSafe(/*IDisposable?*/ resource, /*AsyncMutex*/ mutex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979675240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(resource === null))
                {
                    /*Task*/ let lockTask = mutex.EnterAsync($.$$.ST$1.CancellationToken.None);
                    if (lockTask.IsCompleted)
                    {
                        if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                        {
                            $.$snws.SN.NetEventSource.MutexEntered(mutex, "DisposeSafe");
                        }
                        resource.S$IDisposable$Dispose();
                        mutex.Exit();
                        if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                        {
                            $.$snws.SN.NetEventSource.MutexExited(mutex, "DisposeSafe");
                        }
                    }
                    else 
                    {
                        lockTask.GetAwaiter().UnsafeOnCompleted(new $.$$.S.Action().$ctor(this,  () =>
                        {
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.MutexEntered(mutex, "DisposeSafe");
                            }
                            resource.S$IDisposable$Dispose();
                            mutex.Exit();
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.MutexExited(mutex, "DisposeSafe");
                            }
                        }, $chfUbb ??= {"r":65537,"n":"","d":1114216,"h":0,"f":17825794}));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979675240)
            
            //--TRIMMABLE-BOUNDARY-START(154619936872)
            /*WebSocketCloseStatus? */ get CloseStatus()
            {
                return this._closeStatus;
            }
            //--TRIMMABLE-BOUNDARY-END(154619936872)
            
            //--TRIMMABLE-BOUNDARY-START(158914904168)
            /*string? */ get CloseStatusDescription()
            {
                return this._closeStatusDescription;
            }
            //--TRIMMABLE-BOUNDARY-END(158914904168)
            
            //--TRIMMABLE-BOUNDARY-START(365073334376)
            /*WebSocketState */ get State()
            {
                return this._state;
            }
            //--TRIMMABLE-BOUNDARY-END(365073334376)
            
            //--TRIMMABLE-BOUNDARY-START(373663268968)
            /*string? */ get SubProtocol()
            {
                return this._subprotocol;
            }
            //--TRIMMABLE-BOUNDARY-END(373663268968)
            
            //--TRIMMABLE-BOUNDARY-START(330713596008)
            /*Task */ SendAsync(/*ArraySegment<byte>*/ buffer, /*WebSocketMessageType*/ messageType, /*bool*/ endOfMessage, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713596008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, null, "SendAsync");
                }
                $.$snws.SNW.ManagedWebSocket.ThrowIfInvalidMessageType(messageType, "messageType");
                $.$snws.SNW.WebSocketValidate.ValidateArraySegment(buffer, "buffer");
                return this.SendAsync$2($.$$.S.ReadOnlyMemory$$($.$$.S.Byte).op_Implicit(buffer), messageType, endOfMessage ? 1/*WebSocketMessageFlags.EndOfMessage*/ : 0, cancellationToken).AsTask();
            }
            //--TRIMMABLE-BOUNDARY-END(330713596008)
            
            //--TRIMMABLE-BOUNDARY-START(335008563304)
            /*ValueTask */ SendAsync$1(/*ReadOnlyMemory<byte>*/ buffer, /*WebSocketMessageType*/ messageType, /*bool*/ endOfMessage, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(335008563304);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.SendAsync$2(buffer, messageType, endOfMessage ? 1/*WebSocketMessageFlags.EndOfMessage*/ : 0, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(335008563304)
            
            //--TRIMMABLE-BOUNDARY-START(339303530600)
            /*ValueTask */ SendAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*WebSocketMessageType*/ messageType, /*WebSocketMessageFlags*/ messageFlags, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303530600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, null, "SendAsync");
                }
                $.$snws.SNW.ManagedWebSocket.ThrowIfInvalidMessageType(messageType, "messageType");
                try
                {
                    this.ThrowIfInvalidState(20/*WebSocketStateHelper.ValidSendStates*/);
                }
                catch(exc)
                {
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.TraceException(this, exc, "SendAsync");
                    }
                    return $.$$.STT.ValueTask.FromException(exc);
                }
                /*bool*/ let endOfMessage = ((messageFlags & (1/*WebSocketMessageFlags.EndOfMessage*/)) == (1/*WebSocketMessageFlags.EndOfMessage*/));
                /*bool*/ let disableCompression = ((messageFlags & (2/*WebSocketMessageFlags.DisableCompression*/)) == (2/*WebSocketMessageFlags.DisableCompression*/));
                /*MessageOpcode*/ let opcode;
                if (this._lastSendWasFragment)
                {
                    if (this._lastSendHadDisableCompression !== disableCompression)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$snws.S.SR.net_WebSockets_Argument_MessageFlagsHasDifferentCompressionOptions, "messageFlags");
                    }
                    opcode = 0/*MessageOpcode.Continuation*/;
                }
                else 
                {
                    opcode = messageType === 1/*WebSocketMessageType.Binary*/ ? 2/*MessageOpcode.Binary*/ : 1/*MessageOpcode.Text*/;
                }
                /*ValueTask*/ let t = this.SendFrameAsync(opcode, endOfMessage, disableCompression, buffer, cancellationToken);
                this._lastSendWasFragment = !endOfMessage;
                this._lastSendHadDisableCompression = disableCompression;
                return t;
            }
            //--TRIMMABLE-BOUNDARY-END(339303530600)
            
            //--TRIMMABLE-BOUNDARY-START(309238759528)
            /*Task<WebSocketReceiveResult> */ ReceiveAsync(/*ArraySegment<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238759528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, null, "ReceiveAsync");
                }
                $.$snws.SNW.WebSocketValidate.ValidateArraySegment(buffer, "buffer");
                try
                {
                    this.ThrowIfInvalidState(12/*WebSocketStateHelper.ValidReceiveStates*/);
                    return this.ReceiveAsyncPrivate($.$snws.SNW.WebSocketReceiveResult, $.$$.S.Memory$$($.$$.S.Byte).op_Implicit$1(buffer), cancellationToken).AsTask();
                }
                catch(exc)
                {
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.TraceException(this, exc, "ReceiveAsync");
                    }
                    return $.$$.STT.Task.FromException$1($.$snws.SNW.WebSocketReceiveResult, exc);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(309238759528)
            
            //--TRIMMABLE-BOUNDARY-START(313533726824)
            /*ValueTask<ValueWebSocketReceiveResult> */ ReceiveAsync$1(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533726824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, null, "ReceiveAsync");
                }
                try
                {
                    this.ThrowIfInvalidState(12/*WebSocketStateHelper.ValidReceiveStates*/);
                    return this.ReceiveAsyncPrivate($.$snws.SNW.ValueWebSocketReceiveResult, buffer, cancellationToken);
                }
                catch(exc)
                {
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.TraceException(this, exc, "ReceiveAsync");
                    }
                    return $.$$.STT.ValueTask.FromException$1($.$snws.SNW.ValueWebSocketReceiveResult, exc);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(313533726824)
            
            //--TRIMMABLE-BOUNDARY-START(137440067688)
            /*Task */ CloseAsync(/*WebSocketCloseStatus*/ closeStatus, /*string?*/ statusDescription, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440067688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, null, "CloseAsync");
                }
                $.$snws.SNW.WebSocketValidate.ValidateCloseStatus(closeStatus, statusDescription);
                try
                {
                    this.ThrowIfInvalidState(28/*WebSocketStateHelper.ValidCloseStates*/);
                }
                catch(exc)
                {
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.TraceException(this, exc, "CloseAsync");
                    }
                    return $.$$.STT.Task.FromException(exc);
                }
                return this.CloseAsyncPrivate(closeStatus, statusDescription, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(137440067688)
            
            //--TRIMMABLE-BOUNDARY-START(146030002280)
            /*Task */ CloseOutputAsync(/*WebSocketCloseStatus*/ closeStatus, /*string?*/ statusDescription, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030002280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, null, "CloseOutputAsync");
                }
                $.$snws.SNW.WebSocketValidate.ValidateCloseStatus(closeStatus, statusDescription);
                return this.CloseOutputAsyncCore(closeStatus, statusDescription, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(146030002280)
            
            //--TRIMMABLE-BOUNDARY-START(150324969576)
            /*Task *//*async*/  CloseOutputAsyncCore(/*WebSocketCloseStatus*/ closeStatus, /*string?*/ statusDescription, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324969576);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.Trace(this, null, "CloseOutputAsyncCore");
                    }
                    this.ThrowIfInvalidState(20/*WebSocketStateHelper.ValidCloseOutputStates*/);
                    ($t3 = this.SendCloseFrameAsync(closeStatus, statusDescription, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    //lock(StateUpdateLock)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this.StateUpdateLock)
                        {
                            $.$$.SD.Debug.Assert$4(this._sentCloseFrame, "_sentCloseFrame");
                            if (this._receivedCloseFrame)
                            {
                                this.DisposeCore();
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this.StateUpdateLock)
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(150324969576)
            
            //--TRIMMABLE-BOUNDARY-START(120260198504)
            /*void */ Abort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260198504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, null, "Abort");
                }
                this.OnAborted();
                this.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(120260198504)
            
            //--TRIMMABLE-BOUNDARY-START(300648824936)
            /*void */ OnAborted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648824936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, null, "OnAborted");
                }
                //lock(StateUpdateLock)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.StateUpdateLock)
                    {
                        this.OnAbortedCore();
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.StateUpdateLock)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(300648824936)
            
            //--TRIMMABLE-BOUNDARY-START(304943792232)
            /*void */ OnAbortedCore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943792232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$$.ST$1.Monitor.IsEntered(this.StateUpdateLock), `Expected ${$.$strNN("StateUpdateLock")} to be held`);
                /*WebSocketState*/ let state = this._state;
                if ((state !== 5/*WebSocketState.Closed*/) && (state !== 6/*WebSocketState.Aborted*/))
                {
                    this._state = (state !== 0/*WebSocketState.None*/) && (state !== 1/*WebSocketState.Connecting*/) ? 6/*WebSocketState.Aborted*/ : 5/*WebSocketState.Closed*/;
                }
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, `State transition from ${$.$strNN($.$$.S.Enum.ToStringT($.$snws.SNW.WebSocketState, $.$$.S.UInt32, state))} to ${$.$strNN($.$$.S.Enum.ToStringT($.$snws.SNW.WebSocketState, $.$$.S.UInt32, this._state))}`, "OnAbortedCore");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(304943792232)
            
            //--TRIMMABLE-BOUNDARY-START(347893465192)
            /*ValueTask */ SendFrameAsync(/*MessageOpcode*/ opcode, /*bool*/ endOfMessage, /*bool*/ disableCompression, /*ReadOnlyMemory<byte>*/ payloadBuffer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893465192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.SendFrameAsyncStarted(this, $.$$.S.Enum.ToStringT($.$snws.SNW.ManagedWebSocket.MessageOpcode, $.$$.S.Byte, opcode), payloadBuffer.Length, "SendFrameAsync");
                }
                /*Task*/ let lockTask = this._sendMutex.EnterAsync(cancellationToken);
                return cancellationToken.CanBeCanceled || !lockTask.IsCompletedSuccessfully ? this.SendFrameFallbackAsync(opcode, endOfMessage, disableCompression, payloadBuffer, lockTask, cancellationToken) : this.SendFrameLockAcquiredNonCancelableAsync(opcode, endOfMessage, disableCompression, payloadBuffer);
            }
            //--TRIMMABLE-BOUNDARY-END(347893465192)
            
            //--TRIMMABLE-BOUNDARY-START(356483399784)
            /*ValueTask */ SendFrameLockAcquiredNonCancelableAsync(/*MessageOpcode*/ opcode, /*bool*/ endOfMessage, /*bool*/ disableCompression, /*ReadOnlyMemory<byte>*/ payloadBuffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483399784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._sendMutex.IsHeld, `Caller should hold the ${$.$strNN("_sendMutex")}`);
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.MutexEntered(this._sendMutex, "SendFrameLockAcquiredNonCancelableAsync");
                }
                /*ValueTask*/ let writeTask = new $.$$.STT.ValueTask();
                /*bool*/ let releaseSendBufferAndSemaphore = true;
                try
                {
                    /*int*/ let sendBytes = this.WriteFrameToSendBuffer(opcode, endOfMessage, disableCompression, payloadBuffer.Span);
                    writeTask = this._stream.WriteAsync$2(new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))().$ctor$4(this._sendBuffer, 0, sendBytes), new $.$$.ST$1.CancellationToken());
                    if (writeTask.IsCompleted)
                    {
                        writeTask.GetAwaiter().GetResult();
                        /*ValueTask*/ let flushTask = new $.$$.STT.ValueTask().$ctor$5(this._stream.FlushAsync());
                        if (flushTask.IsCompleted)
                        {
                            return flushTask;
                        }
                        else 
                        {
                            releaseSendBufferAndSemaphore = false;
                            return this.WaitForWriteTaskAsync(flushTask, false);
                        }
                    }
                    releaseSendBufferAndSemaphore = false;
                }
                catch(exc)
                {
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.TraceException(this, exc, "SendFrameLockAcquiredNonCancelableAsync");
                    }
                    return $.$$.STT.ValueTask.FromException($.$is(exc, $.$$.S.OperationCanceledException) ? exc : this._state === 6/*WebSocketState.Aborted*/ ? $.$snws.SNW.ManagedWebSocket.CreateOperationCanceledException(exc, new $.$$.ST$1.CancellationToken()) : $.$$.SRE$1.ExceptionDispatchInfo.SetCurrentStackTrace(new $.$snws.SNW.WebSocketException().$ctor$24(8/*WebSocketError.ConnectionClosedPrematurely*/, exc)));
                }
                finally
                {
                    {
                        if (releaseSendBufferAndSemaphore)
                        {
                            this.ReleaseSendBuffer();
                            this._sendMutex.Exit();
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.MutexExited(this._sendMutex, "SendFrameLockAcquiredNonCancelableAsync");
                                $.$snws.SN.NetEventSource.SendFrameAsyncCompleted(this, "SendFrameLockAcquiredNonCancelableAsync");
                            }
                        }
                    }
                }
                return this.WaitForWriteTaskAsync(writeTask, true);
            }
            //--TRIMMABLE-BOUNDARY-END(356483399784)
            
            //--TRIMMABLE-BOUNDARY-START(425202876520)
            /*ValueTask *//*async*/  WaitForWriteTaskAsync(/*ValueTask*/ writeTask, /*bool*/ shouldFlush)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(425202876520);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t4, $r4;
                        ($t4 = writeTask.ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        if (shouldFlush)
                        {
                            let $t5, $r5;
                            ($t5 = this._stream.FlushAsync().ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        }
                    }
                    catch(exc)
                    {
                        if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                        {
                            $.$snws.SN.NetEventSource.TraceException(this, exc, "WaitForWriteTaskAsync");
                        }
                        if ($.$is(exc, $.$$.S.OperationCanceledException))
                        {
                            throw exc;
                        }
                        throw this._state === 6/*WebSocketState.Aborted*/ ? $.$snws.SNW.ManagedWebSocket.CreateOperationCanceledException(exc, new $.$$.ST$1.CancellationToken()) : new $.$snws.SNW.WebSocketException().$ctor$24(8/*WebSocketError.ConnectionClosedPrematurely*/, exc);
                    }
                    finally
                    {
                        {
                            this.ReleaseSendBuffer();
                            this._sendMutex.Exit();
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.MutexExited(this._sendMutex, "WaitForWriteTaskAsync");
                                $.$snws.SN.NetEventSource.SendFrameAsyncCompleted(this, "WaitForWriteTaskAsync");
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(425202876520)
            
            //--TRIMMABLE-BOUNDARY-START(352188432488)
            /*ValueTask *//*async*/  SendFrameFallbackAsync(/*MessageOpcode*/ opcode, /*bool*/ endOfMessage, /*bool*/ disableCompression, /*ReadOnlyMemory<byte>*/ payloadBuffer, /*Task*/ lockTask, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(352188432488);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t6 = lockTask.ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.MutexEntered(this._sendMutex, "SendFrameFallbackAsync");
                    }
                    try
                    {
                        /*int*/ let sendBytes = this.WriteFrameToSendBuffer(opcode, endOfMessage, disableCompression, payloadBuffer.Span);
                        let $disposable7 = null;
                        try
                        {
                            let $t8, $r8;
                            let $t9, $r9;
                            $disposable7 = cancellationToken.Register$4(new ($.$$.S.Action$$($.$$.S.Object))().$ctor($.$snws.SNW.ManagedWebSocket, /*static*/ (/*s*/ s) =>
                            {
                                return ($.$cast(s, $.$snws.SNW.ManagedWebSocket)).Abort();
                            }, $gxlbUg ??= {"r":65537,"p":[{"n":"s","p":131073}],"n":"","d":1114216,"h":0,"f":17825826}), this);
                            ($t8 = this._stream.WriteAsync$2(new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))().$ctor$4(this._sendBuffer, 0, sendBytes), cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                            ($t9 = this._stream.FlushAsync$1(cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                        }
                        finally
                        {
                            $disposable7?.S$IDisposable$Dispose();
                        }
                    }
                    catch(exc)
                    {
                        if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                        {
                            $.$snws.SN.NetEventSource.TraceException(this, exc, "SendFrameFallbackAsync");
                        }
                        if ($.$is(exc, $.$$.S.OperationCanceledException))
                        {
                            throw exc;
                        }
                        throw this._state === 6/*WebSocketState.Aborted*/ ? $.$snws.SNW.ManagedWebSocket.CreateOperationCanceledException(exc, cancellationToken) : new $.$snws.SNW.WebSocketException().$ctor$24(8/*WebSocketError.ConnectionClosedPrematurely*/, exc);
                    }
                    finally
                    {
                        {
                            this.ReleaseSendBuffer();
                            this._sendMutex.Exit();
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.MutexExited(this._sendMutex, "SendFrameFallbackAsync");
                                $.$snws.SN.NetEventSource.SendFrameAsyncCompleted(this, "SendFrameFallbackAsync");
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(352188432488)
            
            //--TRIMMABLE-BOUNDARY-START(429497843816)
            /*int */ WriteFrameToSendBuffer(/*MessageOpcode*/ opcode, /*bool*/ endOfMessage, /*bool*/ disableCompression, /*ReadOnlySpan<byte>*/ payloadBuffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429497843816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if (!(this._deflater === null) && !disableCompression)
                {
                    payloadBuffer = this._deflater.Deflate$1(payloadBuffer, endOfMessage);
                }
                /*int*/ let payloadLength = payloadBuffer.Length;
                this.AllocateSendBuffer(((payloadLength + 14/*MaxMessageHeaderLength*/) | 0));
                $.$$.SD.Debug.Assert$4(this._sendBuffer !== null, "_sendBuffer != null");
                /*int*/ let headerLength;
                /*int?*/ let maskOffset = null;
                if (this._isServer)
                {
                    headerLength = $.$snws.SNW.ManagedWebSocket.WriteHeader(opcode, this._sendBuffer, payloadBuffer, endOfMessage, false, !(this._deflater === null) && !disableCompression);
                }
                else 
                {
                    maskOffset = $.$snws.SNW.ManagedWebSocket.WriteHeader(opcode, this._sendBuffer, payloadBuffer, endOfMessage, true, !(this._deflater === null) && !disableCompression);
                    headerLength = (($.$$.S.Nullable$$($.$$.S.Int32).GetValueOrDefault.call(maskOffset) + 4/*MaskLength*/) | 0);
                }
                if (payloadBuffer.Length > 0)
                {
                    payloadBuffer.CopyTo(new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$6(this._sendBuffer, headerLength, payloadLength));
                    this._deflater?.ReleaseBuffer();
                    if ($.$$.S.Nullable$$($.$$.S.Int32).HasValue$get.call(maskOffset))
                    {
                        $.$snws.SNW.ManagedWebSocket.ApplyMask(new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$6(this._sendBuffer, headerLength, payloadLength), this._sendBuffer, $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(maskOffset), 0);
                    }
                }
                return ((headerLength + payloadLength) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(429497843816)
            
            //--TRIMMABLE-BOUNDARY-START(433792811112)
            static /*int */ WriteHeader(/*MessageOpcode*/ opcode, /*byte[]*/ sendBuffer, /*ReadOnlySpan<byte>*/ payload, /*bool*/ endOfMessage, /*bool*/ useMask, /*bool*/ compressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792811112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$1(sendBuffer.length >= 14/*MaxMessageHeaderLength*/, `Expected ${$.$strNN("sendBuffer")} to be at least ${$.$strNN(14/*MaxMessageHeaderLength*/)}, got ${$.$strNN(sendBuffer.length)}`);
                $.$$.System.Array.$WriteT1.call(sendBuffer, opcode, 0);
                if (endOfMessage)
                {
                    $.$$.System.Array.$WriteT1.call(sendBuffer, $.$$.System.Array.$ReadT1.call(sendBuffer, 0) | 128, 0);
                }
                if (compressed && opcode !== 0/*MessageOpcode.Continuation*/)
                {
                    $.$$.System.Array.$WriteT1.call(sendBuffer, $.$$.System.Array.$ReadT1.call(sendBuffer, 0) | 64, 0);
                }
                /*int*/ let maskOffset;
                if (payload.Length <= 125)
                {
                    $.$$.System.Array.$WriteT1.call(sendBuffer, $.$cast(payload.Length, $.$$.S.Byte), 1);
                    maskOffset = 2;
                }
                else if (payload.Length <= 65535/*ushort.MaxValue*/)
                {
                    $.$$.System.Array.$WriteT1.call(sendBuffer, 126, 1);
                    $.$$.SBB.BinaryPrimitives.WriteUInt16BigEndian($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, sendBuffer, 2), $.$cast(payload.Length, $.$$.S.UInt16));
                    maskOffset = ((2 + 2) | 0);
                }
                else 
                {
                    $.$$.System.Array.$WriteT1.call(sendBuffer, 127, 1);
                    $.$$.SBB.BinaryPrimitives.WriteUInt64BigEndian($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, sendBuffer, 2), $.$cast(payload.Length, $.$$.S.UInt64));
                    maskOffset = ((2 + 8) | 0);
                }
                if (useMask)
                {
                    $.$$.System.Array.$WriteT1.call(sendBuffer, $.$$.System.Array.$ReadT1.call(sendBuffer, 1) | 128, 1);
                    $.$snws.SNW.ManagedWebSocket.WriteRandomMask(sendBuffer, maskOffset);
                }
                return maskOffset;
            }
            //--TRIMMABLE-BOUNDARY-END(433792811112)
            
            //--TRIMMABLE-BOUNDARY-START(438087778408)
            static /*void */ WriteRandomMask(/*byte[]*/ buffer, /*int*/ offset)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(438087778408);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sscr.SSC.RandomNumberGenerator.Fill($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, buffer, offset, 4/*MaskLength*/));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(438087778408)
            
            //--TRIMMABLE-BOUNDARY-START(317828694120)
            /*ValueTask<TResult> *//*async*/  ReceiveAsyncPrivate(TResult, /*Memory<byte>*/ payloadBuffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(TResult), TResult, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(317828694120);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.ReceiveAsyncPrivateStarted(this, payloadBuffer.Length, "ReceiveAsyncPrivate");
                    }
                    /*CancellationTokenRegistration*/ let registration = new $.$$.ST$1.CancellationTokenRegistration();
                    try
                    {
                        let $t10, $r10;
                        registration = cancellationToken.Register$4(new ($.$$.S.Action$$($.$$.S.Object))().$ctor($.$snws.SNW.ManagedWebSocket, /*static*/ (/*s*/ s) =>
                        {
                            return ($.$cast(s, $.$snws.SNW.ManagedWebSocket)).Abort();
                        }, $dAJfdf ??= {"r":65537,"p":[{"n":"s","p":131073}],"n":"","d":1114216,"h":0,"f":17825826}), this);
                        ($t10 = this._receiveMutex.EnterAsync(cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                        if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                        {
                            $.$snws.SN.NetEventSource.MutexEntered(this._receiveMutex, "ReceiveAsyncPrivate");
                        }
                        try
                        {
                            this.ThrowIfDisposed();
                            while(true)
                            {
                                /*MessageHeader*/ let header = $.$clone(this._lastReceiveHeader);
                                if (header.Processed)
                                {
                                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                                    {
                                        $.$snws.SN.NetEventSource.Trace(this, "Reading the next frame header", "ReceiveAsyncPrivate");
                                    }
                                    if (this._receiveBufferCount < (this._isServer ? 14/*MaxMessageHeaderLength*/ : (((14/*MaxMessageHeaderLength*/ - 4/*MaskLength*/) | 0))))
                                    {
                                        if (this._receiveBufferCount < 2)
                                        {
                                            let $t12, $r12;
                                            if (payloadBuffer.IsEmpty)
                                            {
                                                let $t11, $r11;
                                                ($t11 = this._stream.ReadAsync$2($.$$.S.Memory$$($.$$.S.Byte).Empty, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                                            }
                                            ($t12 = this.EnsureBufferContainsAsync(2, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                                        }
                                        /*long*/ let payloadLength = BigInt(this._receiveBuffer.Span._reference.GetAt(((this._receiveBufferOffset + 1) | 0)) & 127);
                                        if (this._isServer || payloadLength > 125n)
                                        {
                                            let $t13, $r13;
                                            /*int*/ let minNeeded = ((((2 + (this._isServer ? 4/*MaskLength*/ : 0)) | 0) + (payloadLength <= 125n ? 0 : payloadLength === 126n ? 2 : 8)) | 0);
                                            ($t13 = this.EnsureBufferContainsAsync(minNeeded, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                                        }
                                    }
                                    /*string?*/ let headerErrorMessage = this.TryParseMessageHeaderFromReceiveBuffer($.$ref(() => header, ($v) => header = $v, $.$snws.SNW.ManagedWebSocket.MessageHeader));
                                    if (headerErrorMessage !== null)
                                    {
                                        let $t15, $r15;
                                        ($t15 = this.CloseWithReceiveErrorAndThrowAsync(1002/*WebSocketCloseStatus.ProtocolError*/, 2/*WebSocketError.Faulted*/, headerErrorMessage, null).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                                    }
                                    this._receivedMaskOffsetOffset = 0;
                                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                                    {
                                        $.$snws.SN.NetEventSource.Trace(this, `Next frame opcode=${$.$strNN($.$$.S.Enum.ToStringT($.$snws.SNW.ManagedWebSocket.MessageOpcode, $.$$.S.Byte, header.Opcode))}, fin=${$.$strNN(header.Fin)}, compressed=${$.$strNN(header.Compressed)}, payloadLength=${$.$strNN(header.PayloadLength)}`, "ReceiveAsyncPrivate");
                                    }
                                    if (header.PayloadLength === 0n && header.Compressed)
                                    {
                                        this._inflater.AddBytes(0, header.Fin);
                                    }
                                }
                                if (header.Opcode === 9/*MessageOpcode.Ping*/ || header.Opcode === 10/*MessageOpcode.Pong*/)
                                {
                                    let $t16, $r16;
                                    ($t16 = this.HandleReceivedPingPongAsync($.$clone(header), cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                                    continue;
                                }
                                else if (header.Opcode === 8/*MessageOpcode.Close*/)
                                {
                                    let $t17, $r17;
                                    ($t17 = this.HandleReceivedCloseAsync($.$clone(header), cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t17, { set $v($v) { $r17 = $v; } }) ? $r17 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t17)));
                                    return $.$$.N.AsyncResolver.Result($asnycContext, this.GetReceiveResult(TResult, 0, 2/*WebSocketMessageType.Close*/, true));
                                }
                                if (header.Opcode === 0/*MessageOpcode.Continuation*/)
                                {
                                    header.Opcode = this._lastReceiveHeader.Opcode;
                                    header.Compressed = this._lastReceiveHeader.Compressed;
                                }
                                $.$$.SD.Debug.Assert$1(header.Opcode === 2/*MessageOpcode.Binary*/ || header.Opcode === 1/*MessageOpcode.Text*/, `Unexpected opcode ${$.$strNN($.$$.S.Enum.ToStringT($.$snws.SNW.ManagedWebSocket.MessageOpcode, $.$$.S.Byte, header.Opcode))}`);
                                if (header.Processed || payloadBuffer.Length === 0)
                                {
                                    this._lastReceiveHeader = $.$clone(header);
                                    return $.$$.N.AsyncResolver.Result($asnycContext, this.GetReceiveResult(TResult, 0, header.Opcode === 1/*MessageOpcode.Text*/ ? 0/*WebSocketMessageType.Text*/ : 1/*WebSocketMessageType.Binary*/, header.EndOfMessage));
                                }
                                /*int*/ let totalBytesReceived = 0;
                                if (header.PayloadLength > 0n)
                                {
                                    if (header.Compressed)
                                    {
                                        $.$$.SD.Debug.Assert$4(!(this._inflater === null), "_inflater is not null");
                                        this._inflater.Prepare(header.PayloadLength, payloadBuffer.Length);
                                    }
                                    /*int*/ let limit = $.$cast($.$$.S.Math.Min$5(BigInt(header.Compressed ? this._inflater.Span.Length : payloadBuffer.Length), header.PayloadLength), $.$$.S.Int32);
                                    if (this._receiveBufferCount > 0)
                                    {
                                        /*int*/ let receiveBufferBytesToCopy = $.$$.S.Math.Min$4(limit, this._receiveBufferCount);
                                        this._receiveBuffer.Span.Slice(this._receiveBufferOffset, receiveBufferBytesToCopy).CopyTo(header.Compressed ? this._inflater.Span : payloadBuffer.Span);
                                        this.ConsumeFromBuffer(receiveBufferBytesToCopy);
                                        totalBytesReceived += receiveBufferBytesToCopy;
                                    }
                                    if (totalBytesReceived < limit)
                                    {
                                        let $t18, $r18;
                                        /*int*/ let bytesToRead = ((limit - totalBytesReceived) | 0);
                                        /*Memory<byte>*/ let readBuffer = header.Compressed ? this._inflater.Memory.Slice(totalBytesReceived, bytesToRead) : payloadBuffer.Slice(totalBytesReceived, bytesToRead);
                                        /*int*/ let numBytesRead = ($t18 = this._stream.ReadAtLeastAsync(readBuffer, bytesToRead, false, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t18, { set $v($v) { $r18 = $v; } }) ? $r18 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t18)));
                                        if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                                        {
                                            $.$snws.SN.NetEventSource.Trace(this, `bytesRead=${$.$strNN(numBytesRead)}`, "ReceiveAsyncPrivate");
                                        }
                                        if (numBytesRead < bytesToRead)
                                        {
                                            this.ThrowEOFUnexpected();
                                        }
                                        this._keepAlivePingState?.OnDataReceived();
                                        totalBytesReceived += numBytesRead;
                                    }
                                    if (this._isServer)
                                    {
                                        this._receivedMaskOffsetOffset = $.$snws.SNW.ManagedWebSocket.ApplyMask$1(header.Compressed ? this._inflater.Span.Slice(0, totalBytesReceived) : payloadBuffer.Span.Slice(0, totalBytesReceived), header.Mask, this._receivedMaskOffsetOffset);
                                    }
                                    header.PayloadLength -= BigInt(totalBytesReceived);
                                    if (header.Compressed)
                                    {
                                        this._inflater.AddBytes(totalBytesReceived, header.Fin && header.PayloadLength === 0n);
                                    }
                                }
                                if (header.Compressed)
                                {
                                    header.Processed = this._inflater.Inflate$1(payloadBuffer.Span, $.$ref(() => totalBytesReceived, ($v) => totalBytesReceived = $v, $.$$.S.Int32)) && header.PayloadLength === 0n;
                                }
                                else 
                                {
                                    header.Processed = header.PayloadLength === 0n;
                                }
                                if (header.Opcode === 1/*MessageOpcode.Text*/ && !$.$snws.SNW.ManagedWebSocket.TryValidateUtf8($.$$.S.Span$$($.$$.S.Byte).op_Implicit(payloadBuffer.Span.Slice(0, totalBytesReceived)), header.EndOfMessage, this._utf8TextState))
                                {
                                    let $t20, $r20;
                                    ($t20 = this.CloseWithReceiveErrorAndThrowAsync(1007/*WebSocketCloseStatus.InvalidPayloadData*/, 2/*WebSocketError.Faulted*/, null, null).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20)));
                                }
                                if (header.Processed)
                                {
                                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                                    {
                                        $.$snws.SN.NetEventSource.Trace(this, "Data frame fully processed", "ReceiveAsyncPrivate");
                                    }
                                }
                                this._lastReceiveHeader = $.$clone(header);
                                return $.$$.N.AsyncResolver.Result($asnycContext, this.GetReceiveResult(TResult, totalBytesReceived, header.Opcode === 1/*MessageOpcode.Text*/ ? 0/*WebSocketMessageType.Text*/ : 1/*WebSocketMessageType.Binary*/, header.EndOfMessage));
                            }
                        }
                        finally
                        {
                            {
                                this._receiveMutex.Exit();
                                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                                {
                                    $.$snws.SN.NetEventSource.MutexExited(this._receiveMutex, "ReceiveAsyncPrivate");
                                }
                            }
                        }
                    }
                    catch(exc)
                    {
                        if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                        {
                            $.$snws.SN.NetEventSource.TraceException(this, exc, "ReceiveAsyncPrivate");
                        }
                        if ($.$is(exc, $.$$.S.OperationCanceledException))
                        {
                            throw exc;
                        }
                        if (this._state === 6/*WebSocketState.Aborted*/)
                        {
                            /*Exception*/ let inner = exc;
                            if (!((this._keepAlivePingState?.Exception ?? null) === null))
                            {
                                inner = $.$$.SRE$1.ExceptionDispatchInfo.SetCurrentStackTrace(new $.$$.S.AggregateException().$ctor$8($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Exception), [ this._keepAlivePingState.Exception, exc ], null, null)));
                            }
                            throw new $.$$.S.OperationCanceledException().$ctor$12("Aborted", inner);
                        }
                        this.OnAborted();
                        if ($.$is(exc, $.$snws.SNW.WebSocketException))
                        {
                            throw exc;
                        }
                        throw new $.$snws.SNW.WebSocketException().$ctor$24(8/*WebSocketError.ConnectionClosedPrematurely*/, exc);
                    }
                    finally
                    {
                        {
                            registration.Dispose();
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.ReceiveAsyncPrivateCompleted(this, "ReceiveAsyncPrivate");
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(317828694120)
            
            //--TRIMMABLE-BOUNDARY-START(249109217384)
            /*TResult */ GetReceiveResult(TResult, /*int*/ count, /*WebSocketMessageType*/ messageType, /*bool*/ endOfMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109217384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (TResult.$type === $.$snws.SNW.ValueWebSocketReceiveResult.$type)
                {
                    return $.$cast($.$cast(new $.$snws.SNW.ValueWebSocketReceiveResult().$ctor$3(count, messageType, endOfMessage), $.$$.S.Object), TResult);
                }
                return $.$cast(new $.$snws.SNW.WebSocketReceiveResult().$ctor$1(count, messageType, endOfMessage, this._closeStatus, this._closeStatusDescription), TResult);
            }
            //--TRIMMABLE-BOUNDARY-END(249109217384)
            
            //--TRIMMABLE-BOUNDARY-START(253404184680)
            /*ValueTask *//*async*/  HandleReceivedCloseAsync(/*MessageHeader*/ header, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(253404184680);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    //lock(StateUpdateLock)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this.StateUpdateLock)
                        {
                            this._receivedCloseFrame = true;
                            /*WebSocketState*/ let state = this._state;
                            if (this._sentCloseFrame && state < 5/*WebSocketState.Closed*/)
                            {
                                this._state = 5/*WebSocketState.Closed*/;
                            }
                            else if (state < 4/*WebSocketState.CloseReceived*/)
                            {
                                this._state = 4/*WebSocketState.CloseReceived*/;
                            }
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.Trace(this, `State transition from ${$.$strNN($.$$.S.Enum.ToStringT($.$snws.SNW.WebSocketState, $.$$.S.UInt32, state))} to ${$.$strNN($.$$.S.Enum.ToStringT($.$snws.SNW.WebSocketState, $.$$.S.UInt32, this._state))}`, "HandleReceivedCloseAsync");
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this.StateUpdateLock)
                    }
                    /*WebSocketCloseStatus*/ let closeStatus = 1000/*WebSocketCloseStatus.NormalClosure*/;
                    /*string*/ let closeStatusDescription = $.$$.S.String.Empty;
                    if (header.PayloadLength === 1n)
                    {
                        let $t21, $r21;
                        ($t21 = this.CloseWithReceiveErrorAndThrowAsync(1002/*WebSocketCloseStatus.ProtocolError*/, 2/*WebSocketError.Faulted*/, null, null).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t21, { set $v($v) { $r21 = $v; } }) ? $r21 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t21)));
                    }
                    else if (header.PayloadLength >= 2n)
                    {
                        if (BigInt(this._receiveBufferCount) < header.PayloadLength)
                        {
                            let $t22, $r22;
                            ($t22 = this.EnsureBufferContainsAsync($.$cast(header.PayloadLength, $.$$.S.Int32), cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t22, { set $v($v) { $r22 = $v; } }) ? $r22 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t22)));
                        }
                        if (this._isServer)
                        {
                            $.$snws.SNW.ManagedWebSocket.ApplyMask$1(this._receiveBuffer.Span.Slice(this._receiveBufferOffset, $.$cast(header.PayloadLength, $.$$.S.Int32)), header.Mask, 0);
                        }
                        closeStatus = $.$cast($.$$.SBB.BinaryPrimitives.ReadUInt16BigEndian($.$$.S.Span$$($.$$.S.Byte).op_Implicit(this._receiveBuffer.Span.Slice$1(this._receiveBufferOffset))), $.$snws.SNW.WebSocketCloseStatus);
                        if (!$.$snws.SNW.ManagedWebSocket.IsValidCloseStatus(closeStatus))
                        {
                            let $t23, $r23;
                            ($t23 = this.CloseWithReceiveErrorAndThrowAsync(1002/*WebSocketCloseStatus.ProtocolError*/, 2/*WebSocketError.Faulted*/, null, null).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t23, { set $v($v) { $r23 = $v; } }) ? $r23 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t23)));
                        }
                        if (header.PayloadLength > 2n)
                        {
                            try
                            {
                                closeStatusDescription = $.$snws.SNW.ManagedWebSocket.s_textEncoding.GetString$3($.$$.S.Span$$($.$$.S.Byte).op_Implicit(this._receiveBuffer.Span.Slice(((this._receiveBufferOffset + 2) | 0), (($.$cast(header.PayloadLength, $.$$.S.Int32) - 2) | 0))));
                            }
                            catch(exc)
                            {
                                let $t24, $r24;
                                ($t24 = this.CloseWithReceiveErrorAndThrowAsync(1002/*WebSocketCloseStatus.ProtocolError*/, 2/*WebSocketError.Faulted*/, null, exc).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t24, { set $v($v) { $r24 = $v; } }) ? $r24 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t24)));
                            }
                        }
                        this.ConsumeFromBuffer($.$cast(header.PayloadLength, $.$$.S.Int32));
                    }
                    this._closeStatus = closeStatus;
                    this._closeStatusDescription = closeStatusDescription;
                    if (!this._isServer && this._sentCloseFrame)
                    {
                        let $t25, $r25;
                        ($t25 = this.WaitForServerToCloseConnectionAsync(cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t25, { set $v($v) { $r25 = $v; } }) ? $r25 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t25)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(253404184680)
            
            //--TRIMMABLE-BOUNDARY-START(420907909224)
            /*ValueTask *//*async*/  WaitForServerToCloseConnectionAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(420907909224);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.Trace(this, null, "WaitForServerToCloseConnectionAsync");
                    }
                    /*ValueTask<int>*/ let finalReadTask = this._stream.ReadAsync$2(this._receiveBuffer, cancellationToken);
                    if (finalReadTask.IsCompletedSuccessfully)
                    {
                        finalReadTask.GetAwaiter().GetResult();
                    }
                    else 
                    {
                        /*int*/ let WaitForCloseTimeoutMs = 1000;
                        /*Task*/ let task = finalReadTask.AsTask();
                        try
                        {
                            let $t26, $r26;
                            ($t26 = task.WaitAsync$4($.$$.S.TimeSpan.FromMilliseconds$2(BigInt(WaitForCloseTimeoutMs))).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t26, { set $v($v) { $r26 = $v; } }) ? $r26 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t26)));
                        }
                        catch($e)
                        {
                            this.LogExceptions(task);
                            this.Abort();
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(420907909224)
            
            //--TRIMMABLE-BOUNDARY-START(257699151976)
            /*ValueTask *//*async*/  HandleReceivedPingPongAsync(/*MessageHeader*/ header, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(257699151976);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(this._receiveMutex.IsHeld, `Caller should hold the ${$.$strNN("_receiveMutex")}`);
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.Trace(this, null, "HandleReceivedPingPongAsync");
                    }
                    if (header.PayloadLength > 0n && BigInt(this._receiveBufferCount) < header.PayloadLength)
                    {
                        let $t27, $r27;
                        ($t27 = this.EnsureBufferContainsAsync($.$cast(header.PayloadLength, $.$$.S.Int32), cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t27, { set $v($v) { $r27 = $v; } }) ? $r27 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t27)));
                    }
                    /*bool*/ let processPing = header.Opcode === 9/*MessageOpcode.Ping*/;
                    /*bool*/ let processPong = header.Opcode === 10/*MessageOpcode.Pong*/ && !(this._keepAlivePingState === null) && header.PayloadLength === BigInt(8/*KeepAlivePingState.PingPayloadSize*/);
                    if ((processPing || processPong) && this._isServer)
                    {
                        $.$snws.SNW.ManagedWebSocket.ApplyMask$1(this._receiveBuffer.Span.Slice(this._receiveBufferOffset, $.$cast(header.PayloadLength, $.$$.S.Int32)), header.Mask, 0);
                    }
                    if (processPing)
                    {
                        let $t28, $r28;
                        if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                        {
                            $.$snws.SN.NetEventSource.Trace(this, "Processing incoming Ping", "HandleReceivedPingPongAsync");
                        }
                        ($t28 = this.SendFrameAsync(10/*MessageOpcode.Pong*/, true, true, $.$$.S.Memory$$($.$$.S.Byte).op_Implicit(this._receiveBuffer.Slice(this._receiveBufferOffset, $.$cast(header.PayloadLength, $.$$.S.Int32))), cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t28, { set $v($v) { $r28 = $v; } }) ? $r28 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t28)));
                    }
                    else if (processPong)
                    {
                        if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                        {
                            $.$snws.SN.NetEventSource.Trace(this, "Processing incoming Pong", "HandleReceivedPingPongAsync");
                        }
                        /*long*/ let pongPayload = $.$$.SBB.BinaryPrimitives.ReadInt64BigEndian($.$$.S.Span$$($.$$.S.Byte).op_Implicit(this._receiveBuffer.Span.Slice(this._receiveBufferOffset, $.$cast(header.PayloadLength, $.$$.S.Int32))));
                        //lock(StateUpdateLock)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1(this.StateUpdateLock)
                            {
                                this._keepAlivePingState.OnPongResponseReceived(pongPayload);
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit(this.StateUpdateLock)
                        }
                    }
                    else 
                    {
                        if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                        {
                            $.$snws.SN.NetEventSource.Trace(this, "Received Unsolicited Pong. Skipping.", "HandleReceivedPingPongAsync");
                        }
                    }
                    if (header.PayloadLength > 0n)
                    {
                        this.ConsumeFromBuffer($.$cast(header.PayloadLength, $.$$.S.Int32));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(257699151976)
            
            //--TRIMMABLE-BOUNDARY-START(270584053864)
            static /*bool */ IsValidCloseStatus(/*WebSocketCloseStatus*/ closeStatus)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584053864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (closeStatus < $.$cast(1000, $.$snws.SNW.WebSocketCloseStatus) || closeStatus >= $.$cast(5000, $.$snws.SNW.WebSocketCloseStatus))
                {
                    return false;
                }
                if (closeStatus >= $.$cast(3000, $.$snws.SNW.WebSocketCloseStatus))
                {
                    return true;
                }
                switch(closeStatus)
                {
                    case 1001/*WebSocketCloseStatus.EndpointUnavailable*/:
                    case 1011/*WebSocketCloseStatus.InternalServerError*/:
                    case 1003/*WebSocketCloseStatus.InvalidMessageType*/:
                    case 1007/*WebSocketCloseStatus.InvalidPayloadData*/:
                    case 1010/*WebSocketCloseStatus.MandatoryExtension*/:
                    case 1009/*WebSocketCloseStatus.MessageTooBig*/:
                    case 1000/*WebSocketCloseStatus.NormalClosure*/:
                    case 1008/*WebSocketCloseStatus.PolicyViolation*/:
                    case 1002/*WebSocketCloseStatus.ProtocolError*/:
                    case $.$cast(1012, $.$snws.SNW.WebSocketCloseStatus):
                    case $.$cast(1013, $.$snws.SNW.WebSocketCloseStatus):
                    case $.$cast(1014, $.$snws.SNW.WebSocketCloseStatus):
                    return true;
                    default:
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(270584053864)
            
            //--TRIMMABLE-BOUNDARY-START(163209871464)
            /*ValueTask *//*async*/  CloseWithReceiveErrorAndThrowAsync(/*WebSocketCloseStatus*/ closeStatus, /*WebSocketError*/ error, /*string?*/ errorMessage, /*Exception?*/ innerException)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209871464);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.Trace(this, errorMessage, "CloseWithReceiveErrorAndThrowAsync");
                    }
                    if (!this._sentCloseFrame)
                    {
                        let $t30, $r30;
                        ($t30 = this.CloseOutputAsync(closeStatus, $.$$.S.String.Empty, new $.$$.ST$1.CancellationToken()).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t30, { set $v($v) { $r30 = $v; } }) ? $r30 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t30)));
                    }
                    this._receiveBufferCount = 0;
                    throw errorMessage !== null ? new $.$snws.SNW.WebSocketException().$ctor$29(error, errorMessage, innerException) : new $.$snws.SNW.WebSocketException().$ctor$24(error, innerException);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(163209871464)
            
            //--TRIMMABLE-BOUNDARY-START(403728040040)
            /*string? */ TryParseMessageHeaderFromReceiveBuffer(/*out MessageHeader*/ resultHeader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403728040040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._receiveBufferCount >= 2, "Expected to at least have the first two bytes of the header.");
                /*MessageHeader*/ let header = new $.$snws.SNW.ManagedWebSocket.MessageHeader();
                /*Span<byte>*/ let receiveBufferSpan = this._receiveBuffer.Span;
                header.Fin = (receiveBufferSpan._reference.GetAt(this._receiveBufferOffset) & 128) !== 0;
                /*bool*/ let reservedSet = (receiveBufferSpan._reference.GetAt(this._receiveBufferOffset) & 48) !== 0;
                header.Opcode = $.$cast((receiveBufferSpan._reference.GetAt(this._receiveBufferOffset) & 15), $.$snws.SNW.ManagedWebSocket.MessageOpcode);
                header.Compressed = (receiveBufferSpan._reference.GetAt(this._receiveBufferOffset) & 64) !== 0;
                /*bool*/ let masked = (receiveBufferSpan._reference.GetAt(((this._receiveBufferOffset + 1) | 0)) & 128) !== 0;
                header.PayloadLength = BigInt(receiveBufferSpan._reference.GetAt(((this._receiveBufferOffset + 1) | 0)) & 127);
                this.ConsumeFromBuffer(2);
                if (header.PayloadLength === 126n)
                {
                    $.$$.SD.Debug.Assert$4(this._receiveBufferCount >= 2, "Expected to have two bytes for the payload length.");
                    header.PayloadLength = BigInt($.$$.SBB.BinaryPrimitives.ReadUInt16BigEndian($.$$.S.Span$$($.$$.S.Byte).op_Implicit(receiveBufferSpan.Slice$1(this._receiveBufferOffset))));
                    this.ConsumeFromBuffer(2);
                }
                else if (header.PayloadLength === 127n)
                {
                    $.$$.SD.Debug.Assert$4(this._receiveBufferCount >= 8, "Expected to have eight bytes for the payload length.");
                    header.PayloadLength = $.$$.SBB.BinaryPrimitives.ReadInt64BigEndian($.$$.S.Span$$($.$$.S.Byte).op_Implicit(receiveBufferSpan.Slice$1(this._receiveBufferOffset)));
                    this.ConsumeFromBuffer(8);
                }
                if (reservedSet)
                {
                    resultHeader.$v = new $.$snws.SNW.ManagedWebSocket.MessageHeader();
                    return $.$snws.S.SR.net_Websockets_ReservedBitsSet;
                }
                if (header.PayloadLength < 0n)
                {
                    resultHeader.$v = new $.$snws.SNW.ManagedWebSocket.MessageHeader();
                    return $.$snws.S.SR.net_Websockets_InvalidPayloadLength;
                }
                if (header.Compressed && this._inflater === null)
                {
                    resultHeader.$v = new $.$snws.SNW.ManagedWebSocket.MessageHeader();
                    return $.$snws.S.SR.net_Websockets_PerMessageCompressedFlagWhenNotEnabled;
                }
                if (masked)
                {
                    if (!this._isServer)
                    {
                        resultHeader.$v = new $.$snws.SNW.ManagedWebSocket.MessageHeader();
                        return $.$snws.S.SR.net_Websockets_ClientReceivedMaskedFrame;
                    }
                    header.Mask = $.$snws.SNW.ManagedWebSocket.CombineMaskBytes($.$$.S.Span$$($.$$.S.Byte).op_Implicit(receiveBufferSpan), this._receiveBufferOffset);
                    this.ConsumeFromBuffer(4);
                }
                else if (this._isServer)
                {
                    resultHeader.$v = new $.$snws.SNW.ManagedWebSocket.MessageHeader();
                    return $.$snws.S.SR.net_Websockets_ServerReceivedUnmaskedFrame;
                }
                let $switch31 = header.Opcode;
                switch($switch31)
                {
                    case 0/*MessageOpcode.Continuation*/:
                    if (this._lastReceiveHeader.Fin)
                    {
                        resultHeader.$v = new $.$snws.SNW.ManagedWebSocket.MessageHeader();
                        return $.$snws.S.SR.net_Websockets_ContinuationFromFinalFrame;
                    }
                    if (header.Compressed)
                    {
                        resultHeader.$v = new $.$snws.SNW.ManagedWebSocket.MessageHeader();
                        return $.$snws.S.SR.net_Websockets_PerMessageCompressedFlagInContinuation;
                    }
                    header.Compressed = this._lastReceiveHeader.Compressed;
                    break;
                    case 2/*MessageOpcode.Binary*/:
                    case 1/*MessageOpcode.Text*/:
                    if (!this._lastReceiveHeader.Fin)
                    {
                        resultHeader.$v = new $.$snws.SNW.ManagedWebSocket.MessageHeader();
                        return $.$snws.S.SR.net_Websockets_NonContinuationAfterNonFinalFrame;
                    }
                    break;
                    case 8/*MessageOpcode.Close*/:
                    case 9/*MessageOpcode.Ping*/:
                    case 10/*MessageOpcode.Pong*/:
                    if (header.PayloadLength > BigInt(125/*MaxControlPayloadLength*/) || !header.Fin)
                    {
                        resultHeader.$v = new $.$snws.SNW.ManagedWebSocket.MessageHeader();
                        return $.$snws.S.SR.net_Websockets_InvalidControlMessage;
                    }
                    break;
                    default:
                    resultHeader.$v = new $.$snws.SNW.ManagedWebSocket.MessageHeader();
                    return $.$snws.S.SR.Format$6($.$snws.S.SR.net_Websockets_UnknownOpcode, $.$box(header.Opcode, $.$snws.SNW.ManagedWebSocket.MessageOpcode));
                }
                header.Processed = header.PayloadLength === 0n && !header.Compressed;
                resultHeader.$v = $.$clone(header);
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(403728040040)
            
            //--TRIMMABLE-BOUNDARY-START(141735034984)
            /*Task *//*async*/  CloseAsyncPrivate(/*WebSocketCloseStatus*/ closeStatus, /*string?*/ statusDescription, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141735034984);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.CloseAsyncPrivateStarted(this, "CloseAsyncPrivate");
                    }
                    try
                    {
                        if (!this._sentCloseFrame)
                        {
                            let $t32, $r32;
                            ($t32 = this.SendCloseFrameAsync(closeStatus, statusDescription, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t32, { set $v($v) { $r32 = $v; } }) ? $r32 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t32)));
                        }
                        $.$$.SD.Debug.Assert$1(this.State === 3/*WebSocketState.CloseSent*/ || this.State === 5/*WebSocketState.Closed*/ || this.State === 6/*WebSocketState.Aborted*/, `Unexpected state ${$.$strNN($.$$.S.Enum.ToStringT($.$snws.SNW.WebSocketState, $.$$.S.UInt32, this.State))}.`);
                        if (this.State === 3/*WebSocketState.CloseSent*/)
                        {
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.Trace(this, "Waiting for a close frame", "CloseAsyncPrivate");
                            }
                            /*byte[]*/ let closeBuffer = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(((14/*MaxMessageHeaderLength*/ + 125/*MaxControlPayloadLength*/) | 0));
                            try
                            {
                                while(!this._receivedCloseFrame)
                                {
                                    let $t34, $r34;
                                    /*ValueTask<ValueWebSocketReceiveResult>*/ let receiveTask = new ($.$$.STT.ValueTask$$($.$snws.SNW.ValueWebSocketReceiveResult))();
                                    try
                                    {
                                        let $t33, $r33;
                                        ($t33 = this._receiveMutex.EnterAsync(cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t33, { set $v($v) { $r33 = $v; } }) ? $r33 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t33)));
                                        if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                                        {
                                            $.$snws.SN.NetEventSource.MutexEntered(this._receiveMutex, "CloseAsyncPrivate");
                                        }
                                        try
                                        {
                                            if (!this._receivedCloseFrame)
                                            {
                                                receiveTask = this.ReceiveAsyncPrivate($.$snws.SNW.ValueWebSocketReceiveResult, $.$$.S.Memory$$($.$$.S.Byte).op_Implicit$2(closeBuffer), cancellationToken);
                                            }
                                        }
                                        finally
                                        {
                                            {
                                                this._receiveMutex.Exit();
                                                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                                                {
                                                    $.$snws.SN.NetEventSource.MutexExited(this._receiveMutex, "CloseAsyncPrivate");
                                                }
                                            }
                                        }
                                    }
                                    catch($e)
                                    {
                                        this.Abort();
                                        throw $e;
                                    }
                                    ($t34 = receiveTask.ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t34, { set $v($v) { $r34 = $v; } }) ? $r34 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t34)));
                                }
                            }
                            finally
                            {
                                {
                                    $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(closeBuffer, false);
                                }
                            }
                        }
                        //lock(StateUpdateLock)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1(this.StateUpdateLock)
                            {
                                this.DisposeCore();
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit(this.StateUpdateLock)
                        }
                    }
                    catch(exc)
                    {
                        if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                        {
                            $.$snws.SN.NetEventSource.TraceException(this, exc, "CloseAsyncPrivate");
                        }
                        throw exc;
                    }
                    finally
                    {
                        {
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.CloseAsyncPrivateCompleted(this, "CloseAsyncPrivate");
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(141735034984)
            
            //--TRIMMABLE-BOUNDARY-START(343598497896)
            /*ValueTask *//*async*/  SendCloseFrameAsync(/*WebSocketCloseStatus*/ closeStatus, /*string?*/ closeStatusDescription, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(343598497896);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*byte[]?*/ let buffer = null;
                    try
                    {
                        let $t35, $r35;
                        /*int*/ let count = 2;
                        if ($.$$.S.String.IsNullOrEmpty(closeStatusDescription))
                        {
                            buffer = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(count);
                        }
                        else 
                        {
                            count += $.$snws.SNW.ManagedWebSocket.s_textEncoding.GetByteCount$6(closeStatusDescription);
                            buffer = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(count);
                            /*int*/ let encodedLength = $.$snws.SNW.ManagedWebSocket.s_textEncoding.GetBytes$6(closeStatusDescription, 0, closeStatusDescription.length, buffer, 2);
                            $.$$.SD.Debug.Assert$4(((count - 2) | 0) === encodedLength, `${$.$strNN("GetByteCount")} and ${$.$strNN("GetBytes")} encoded count didn't match`);
                        }
                        $.$$.SBB.BinaryPrimitives.WriteUInt16BigEndian($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(buffer), $.$cast(closeStatus, $.$$.S.UInt16));
                        ($t35 = this.SendFrameAsync(8/*MessageOpcode.Close*/, true, true, $.$$.S.Memory$$($.$$.S.Byte).op_Implicit(new ($.$$.S.Memory$$($.$$.S.Byte))().$ctor$6(buffer, 0, count)), cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t35, { set $v($v) { $r35 = $v; } }) ? $r35 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t35)));
                    }
                    finally
                    {
                        {
                            if (buffer !== null)
                            {
                                $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(buffer, false);
                            }
                        }
                    }
                    //lock(StateUpdateLock)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this.StateUpdateLock)
                        {
                            this._sentCloseFrame = true;
                            /*WebSocketState*/ let state = this._state;
                            if (this._receivedCloseFrame && state < 5/*WebSocketState.Closed*/)
                            {
                                this._state = 5/*WebSocketState.Closed*/;
                            }
                            else if (state < 3/*WebSocketState.CloseSent*/)
                            {
                                this._state = 3/*WebSocketState.CloseSent*/;
                            }
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.Trace(this, `State transition from ${$.$strNN($.$$.S.Enum.ToStringT($.$snws.SNW.WebSocketState, $.$$.S.UInt32, state))} to ${$.$strNN($.$$.S.Enum.ToStringT($.$snws.SNW.WebSocketState, $.$$.S.UInt32, this._state))}`, "SendCloseFrameAsync");
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this.StateUpdateLock)
                    }
                    if (!this._isServer && this._receivedCloseFrame)
                    {
                        let $t36, $r36;
                        ($t36 = this.WaitForServerToCloseConnectionAsync(cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t36, { set $v($v) { $r36 = $v; } }) ? $r36 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t36)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(343598497896)
            
            //--TRIMMABLE-BOUNDARY-START(171799806056)
            /*void */ ConsumeFromBuffer(/*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799806056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$1(count >= 0, `Expected non-negative ${$.$strNN("count")}, got ${$.$strNN(count)}`);
                $.$$.SD.Debug.Assert$1(count <= this._receiveBufferCount, `Trying to consume ${$.$strNN(count)}, which is more than exists ${$.$strNN(this._receiveBufferCount)}`);
                this._receiveBufferCount -= count;
                this._receiveBufferOffset += count;
            }
            //--TRIMMABLE-BOUNDARY-END(171799806056)
            
            //--TRIMMABLE-BOUNDARY-START(193274642536)
            /*ValueTask *//*async*/  EnsureBufferContainsAsync(/*int*/ minimumRequiredBytes, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193274642536);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$1(minimumRequiredBytes <= this._receiveBuffer.Length, `Requested number of bytes ${$.$strNN(minimumRequiredBytes)} must not exceed ${$.$strNN(this._receiveBuffer.Length)}`);
                    if (this._receiveBufferCount < minimumRequiredBytes)
                    {
                        if (this._receiveBufferCount > 0)
                        {
                            this._receiveBuffer.Span.Slice(this._receiveBufferOffset, this._receiveBufferCount).CopyTo(this._receiveBuffer.Span);
                        }
                        this._receiveBufferOffset = 0;
                        if (this._receiveBufferCount < minimumRequiredBytes)
                        {
                            let $t37, $r37;
                            /*int*/ let bytesToRead = ((minimumRequiredBytes - this._receiveBufferCount) | 0);
                            /*int*/ let numRead = ($t37 = this._stream.ReadAtLeastAsync(this._receiveBuffer.Slice$1(this._receiveBufferCount), bytesToRead, false, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t37, { set $v($v) { $r37 = $v; } }) ? $r37 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t37)));
                            this._receiveBufferCount += numRead;
                            if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                            {
                                $.$snws.SN.NetEventSource.Trace(this, `bytesRead=${$.$strNN(numRead)}`, "EnsureBufferContainsAsync");
                            }
                            if (numRead < bytesToRead)
                            {
                                this.ThrowEOFUnexpected();
                            }
                            this._keepAlivePingState?.OnDataReceived();
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(193274642536)
            
            //--TRIMMABLE-BOUNDARY-START(377958236264)
            /*void */ ThrowEOFUnexpected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377958236264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                throw new $.$snws.SNW.WebSocketException().$ctor$31(8/*WebSocketError.ConnectionClosedPrematurely*/);
            }
            //--TRIMMABLE-BOUNDARY-END(377958236264)
            
            //--TRIMMABLE-BOUNDARY-START(124555165800)
            /*void */ AllocateSendBuffer(/*int*/ minLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555165800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._sendBuffer === null, "_sendBuffer == null");
                this._sendBuffer = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(minLength);
            }
            //--TRIMMABLE-BOUNDARY-END(124555165800)
            
            //--TRIMMABLE-BOUNDARY-START(322123661416)
            /*void */ ReleaseSendBuffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123661416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._sendMutex.IsHeld, `Caller should hold the ${$.$strNN("_sendMutex")}`);
                let toReturn;
                if ($.$is(this._sendBuffer, $.$typeArray($.$$.S.Byte), { set $v($v){ toReturn = $v; } }))
                {
                    this._sendBuffer = null;
                    $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(322123661416)
            
            //--TRIMMABLE-BOUNDARY-START(167504838760)
            static /*int */ CombineMaskBytes(/*ReadOnlySpan<byte>*/ buffer, /*int*/ maskOffset)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504838760);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.BitConverter.ToInt32$1(buffer.Slice$1(maskOffset));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504838760)
            
            //--TRIMMABLE-BOUNDARY-START(128850133096)
            static /*int */ ApplyMask(/*Span<byte>*/ toMask, /*byte[]*/ mask, /*int*/ maskOffset, /*int*/ maskOffsetIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850133096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$1(maskOffsetIndex < 4/*MaskLength*/, `Unexpected ${$.$strNN("maskOffsetIndex")}: ${$.$strNN(maskOffsetIndex)}`);
                $.$$.SD.Debug.Assert$1(mask.length >= ((4/*MaskLength*/ + maskOffset) | 0), `Unexpected inputs: ${$.$strNN(mask.length)}, ${$.$strNN(maskOffset)}`);
                return $.$snws.SNW.ManagedWebSocket.ApplyMask$1(toMask, $.$snws.SNW.ManagedWebSocket.CombineMaskBytes($.$$.S.ReadOnlySpan$$($.$$.S.Byte).op_Implicit$1(mask), maskOffset), maskOffsetIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(128850133096)
            
            //--TRIMMABLE-BOUNDARY-START(133145100392)
            static /*int */ ApplyMask$1(/*Span<byte>*/ toMask, /*int*/ mask, /*int*/ maskIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145100392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(maskIndex < 4, "maskIndex < sizeof(int)");
                /*fixed*/ 
                {
                    /*byte**/ let toMaskBeg = $.$$.SRI.MemoryMarshal.GetReference$1($.$$.S.Byte, toMask);
                    /*byte**/ let toMaskPtr = toMaskBeg;
                    /*byte**/ let toMaskEnd = toMaskBeg.Add(toMask.Length);
                    if (toMaskEnd.Subtract(toMaskPtr, false) >= BigInt(4))
                    {
                        /*int*/ let rolledMask = $.$$.S.BitConverter.IsLittleEndian ? ($.$$.SN$1.BitOperations.RotateRight((mask >>> 0), ((maskIndex * 8) | 0)) | 0) : ($.$$.SN$1.BitOperations.RotateLeft((mask >>> 0), ((maskIndex * 8) | 0)) | 0);
                        //if (Vector.IsHardwareAccelerated && (toMaskEnd - toMaskPtr) >= Vector<byte>.Count) { ... }
                        while(toMaskEnd.Subtract(toMaskPtr, false) >= BigInt(4))
                        {
                            $.$cast(toMaskPtr, $.$typePointer($.$$.S.Int32)).$v ^= rolledMask;
                            toMaskPtr = toMaskPtr.Add(4);
                        }
                    }
                    /*byte**/ let maskPtr = $.$cast($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Int32, () => mask, ($v) => mask = $v, null, true), $.$typePointer($.$$.S.Byte));
                    while($.$$.N.RefOrPointer.Compare(toMaskPtr, toMaskEnd) != 0)
                    {
                        (() =>
                        {
                            var $old = toMaskPtr;
                            toMaskPtr = toMaskPtr.Add(1);
                            return $old;
                        })().$v ^= maskPtr.GetAt(maskIndex);
                        maskIndex = (((maskIndex + 1) | 0)) & 3;
                    }
                }
                return maskIndex;
            }
            //--TRIMMABLE-BOUNDARY-END(133145100392)
            
            //--TRIMMABLE-BOUNDARY-START(395138105448)
            /*void */ ThrowIfOperationInProgress(/*bool*/ operationCompleted, /*string?*/ methodName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395138105448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!operationCompleted)
                {
                    this.Abort();
                    $.$snws.SNW.ManagedWebSocket.ThrowOperationInProgress(methodName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(395138105448)
            
            //--TRIMMABLE-BOUNDARY-START(399433072744)
            static /*void */ ThrowOperationInProgress(/*string?*/ methodName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(399433072744);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$snws.S.SR.Format$6($.$snws.S.SR.net_Websockets_AlreadyOneOutstandingOperation, methodName));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(399433072744)
            
            //--TRIMMABLE-BOUNDARY-START(176094773352)
            static /*OperationCanceledException */ CreateOperationCanceledException(/*Exception*/ innerException, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094773352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast($.$$.SRE$1.ExceptionDispatchInfo.SetCurrentStackTrace(new $.$$.S.OperationCanceledException().$ctor$11(new $.$$.S.OperationCanceledException().$ctor$9().Message, innerException, cancellationToken)), $.$$.S.OperationCanceledException);
            }
            //--TRIMMABLE-BOUNDARY-END(176094773352)
            
            //--TRIMMABLE-BOUNDARY-START(382253203560)
            /*void */ ThrowIfDisposed()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(382253203560);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ThrowIfInvalidState(124/*ManagedWebSocketStates.All*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(382253203560)
            
            //--TRIMMABLE-BOUNDARY-START(390843138152)
            /*void */ ThrowIfInvalidState(/*ManagedWebSocketStates*/ validStates)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390843138152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let disposed = this._disposed;
                /*WebSocketState*/ let state = this._state;
                /*Exception?*/ let keepAliveException = null;
                if (!(this._keepAlivePingState === null))
                {
                    //lock(StateUpdateLock)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this.StateUpdateLock)
                        {
                            disposed = this._disposed;
                            state = this._state;
                            keepAliveException = this._keepAlivePingState.Exception;
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this.StateUpdateLock)
                    }
                }
                if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                {
                    $.$snws.SN.NetEventSource.Trace(this, `_state=${$.$strNN($.$$.S.Enum.ToStringT($.$snws.SNW.WebSocketState, $.$$.S.UInt32, state))}, _disposed=${$.$strNN(disposed)}, _keepAlivePingState.Exception=${$.$strNN(keepAliveException.ToString())}`, "ThrowIfInvalidState");
                }
                $.$snws.SNW.WebSocketStateHelper.ThrowIfInvalidState(state, disposed, keepAliveException, validStates);
            }
            //--TRIMMABLE-BOUNDARY-END(390843138152)
            
            //--TRIMMABLE-BOUNDARY-START(412317974632)
            static /*bool */ TryValidateUtf8(/*ReadOnlySpan<byte>*/ span, /*bool*/ endOfMessage, /*Utf8MessageState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412317974632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (endOfMessage && !state.SequenceInProgress)
                {
                    return $.$$.STU.Utf8.IsValid(span);
                }
                for(/*int*/ let i = 0; i < span.Length; )
                {
                    if (!state.SequenceInProgress)
                    {
                        /*int*/ let firstNonAscii = $.$$.S.MemoryExtensions.IndexOfAnyExceptInRange($.$$.S.Byte, span.Slice$1(i), 0, 127);
                        if (firstNonAscii < 0)
                        {
                            break;
                        }
                        i += firstNonAscii;
                        state.SequenceInProgress = true;
                        /*byte*/ let b = span._reference.GetAt(i);
                        i++;
                        $.$$.SD.Debug.Assert$4((b & 128) !== 0, "Should have already skipped past ASCII");
                        if ((b & 192) === 128)
                        {
                            return false;
                        }
                        else if ((b & 224) === 192)
                        {
                            state.AdditionalBytesExpected = 1;
                            state.CurrentDecodeBits = b & 31;
                            state.ExpectedValueMin = 128;
                        }
                        else if ((b & 240) === 224)
                        {
                            state.AdditionalBytesExpected = 2;
                            state.CurrentDecodeBits = b & 15;
                            state.ExpectedValueMin = 2048;
                        }
                        else if ((b & 248) === 240)
                        {
                            state.AdditionalBytesExpected = 3;
                            state.CurrentDecodeBits = b & 7;
                            state.ExpectedValueMin = 65536;
                        }
                        else 
                        {
                            return false;
                        }
                    }
                    while(state.AdditionalBytesExpected > 0 && i < span.Length)
                    {
                        /*byte*/ let b = span._reference.GetAt(i);
                        if ((b & 192) !== 128)
                        {
                            return false;
                        }
                        i++;
                        state.AdditionalBytesExpected--;
                        state.CurrentDecodeBits = (state.CurrentDecodeBits << 6) | (b & 63);
                        if (state.AdditionalBytesExpected === 1 && state.CurrentDecodeBits >= 864 && state.CurrentDecodeBits <= 895)
                        {
                            return false;
                        }
                        if (state.AdditionalBytesExpected === 2 && state.CurrentDecodeBits >= 272)
                        {
                            return false;
                        }
                    }
                    if (state.AdditionalBytesExpected === 0)
                    {
                        state.SequenceInProgress = false;
                        if (state.CurrentDecodeBits < state.ExpectedValueMin)
                        {
                            return false;
                        }
                    }
                }
                return !endOfMessage || !state.SequenceInProgress;
            }
            //--TRIMMABLE-BOUNDARY-END(412317974632)
            
            //--TRIMMABLE-BOUNDARY-START(283468955752)
            /*void */ LogExceptions$1(/*ValueTask*/ t)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468955752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (t.IsCompletedSuccessfully)
                {
                    t.GetAwaiter().GetResult();
                }
                else 
                {
                    this.LogExceptions(t.AsTask());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(283468955752)
            
            //--TRIMMABLE-BOUNDARY-START(279173988456)
            /*void */ LogExceptions(/*Task*/ t)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173988456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (t.IsCompleted)
                {
                    if (t.IsFaulted)
                    {
                        LogFaulted(t, this);
                    }
                }
                else 
                {
                    t.ContinueWith(new ($.$$.S.Action$$$($.$$.STT.Task, $.$$.S.Object))().$ctor($.$snws.SNW.ManagedWebSocket, LogFaulted, $aJjlVh ??= {"r":65537,"p":[{"n":"task","p":178454529},{"n":"thisObj","p":131073}],"n":"LogFaulted","d":1114216,"h":0,"f":16777250}), this, $.$$.ST$1.CancellationToken.None, 327680/*TaskContinuationOptions.OnlyOnFaulted*/ | 524288/*TaskContinuationOptions.ExecuteSynchronously*/, $.$$.STT.TaskScheduler.Default);
                }
                /*static void*/  function LogFaulted(/*Task*/ task, /*object?*/ thisObj)
                {
                    $.$$.SD.Debug.Assert$4(task.IsFaulted, "task.IsFaulted");
                    /*Exception*/ let e = task.Exception.InnerException;
                    if ($.$snws.SN.NetEventSource.Log.IsEnabled())
                    {
                        $.$snws.SN.NetEventSource.TraceException(thisObj, e, "LogExceptions");
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(279173988456)
            
            //--TRIMMABLE-BOUNDARY-START(386548170856)
            static /*void */ ThrowIfInvalidMessageType(/*WebSocketMessageType*/ messageType, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548170856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!((messageType === 0/*WebSocketMessageType.Text*/) || (messageType === 1/*WebSocketMessageType.Binary*/)))
                {
                    ThrowInvalidMessageType(paramName);
                }
                /*static void*/  function ThrowInvalidMessageType(/*string?*/ paramName)
                {
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$snws.S.SR.Format$7($.$snws.S.SR.net_WebSockets_Argument_InvalidMessageType, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ "Close", "SendAsync", "Binary", "Text", "CloseOutputAsync" ], null, null)), paramName);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(386548170856)
            
            //--TRIMMABLE-BOUNDARY-START(1376360)
            static $_Utf8MessageState;
            static get Utf8MessageState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1376360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SNW.ManagedWebSocket;
                return $cls.$_Utf8MessageState ??= $asm.$ncls(`$snws.SNW.ManagedWebSocket.Utf8MessageState`, ($self) => class Utf8MessageState extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(21476212840)
                    /*bool*/ SequenceInProgress = false;
                    //--TRIMMABLE-BOUNDARY-END(21476212840)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591310952)
                    /*int*/ AdditionalBytesExpected = 0;
                    //--TRIMMABLE-BOUNDARY-END(8591310952)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181245544)
                    /*int*/ ExpectedValueMin = 0;
                    //--TRIMMABLE-BOUNDARY-END(17181245544)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886278248)
                    /*int*/ CurrentDecodeBits = 0;
                    //--TRIMMABLE-BOUNDARY-END(12886278248)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296343656)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296343656);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296343656)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296343656)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296343656)
                    
                    static $h = 1376360;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476212840),
    {
      "t": 262145,
      "n": "SequenceInProgress",
      "d": 1376360,
      "h": 21476212840,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21476212840),
//--TRIMMABLE-BOUNDARY-START(8591310952),
    {
      "t": 655361,
      "n": "AdditionalBytesExpected",
      "d": 1376360,
      "h": 8591310952,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8591310952),
//--TRIMMABLE-BOUNDARY-START(17181245544),
    {
      "t": 655361,
      "n": "ExpectedValueMin",
      "d": 1376360,
      "h": 17181245544,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17181245544),
//--TRIMMABLE-BOUNDARY-START(12886278248),
    {
      "t": 655361,
      "n": "CurrentDecodeBits",
      "d": 1376360,
      "h": 12886278248,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12886278248)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343656),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376360,
      "h": 4296343656,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343656)
  ],
  "d": 1114216,
  "h": 1376360
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.ManagedWebSocket+Utf8MessageState`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}ManagedWebSocket${separator}Utf8MessageState`; }
                }, $cls, ($v) => $cls.$_Utf8MessageState = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1376360)
            
            //--TRIMMABLE-BOUNDARY-START(1310824)
            static $_MessageOpcode;
            static get MessageOpcode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1310824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SNW.ManagedWebSocket;
                return $cls.$_MessageOpcode ??= $asm.$nstr(`$snws.SNW.ManagedWebSocket.MessageOpcode`, ($self) => class MessageOpcode extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
                {
                    static Continuation = 0;
                    static Text = 1;
                    static Binary = 2;
                    static Close = 8;
                    static Ping = 9;
                    static Pong = 10;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(1310824);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "Continuation": 0n,
                            "Text": 1n,
                            "Binary": 2n,
                            "Close": 8n,
                            "Ping": 9n,
                            "Pong": 10n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4296278120)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296278120);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296278120)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296278120)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296278120)
                    
                    static $h = 1310824;
                    static $z = 1;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Byte; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181180008),
    {
      "t": 1310824,
      "n": "Continuation",
      "d": 1310824,
      "h": 17181180008,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181180008),
//--TRIMMABLE-BOUNDARY-START(30066081896),
    {
      "t": 1310824,
      "n": "Text",
      "d": 1310824,
      "h": 30066081896,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066081896),
//--TRIMMABLE-BOUNDARY-START(8591245416),
    {
      "t": 1310824,
      "n": "Binary",
      "d": 1310824,
      "h": 8591245416,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591245416),
//--TRIMMABLE-BOUNDARY-START(12886212712),
    {
      "t": 1310824,
      "n": "Close",
      "d": 1310824,
      "h": 12886212712,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886212712),
//--TRIMMABLE-BOUNDARY-START(21476147304),
    {
      "t": 1310824,
      "n": "Ping",
      "d": 1310824,
      "h": 21476147304,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476147304),
//--TRIMMABLE-BOUNDARY-START(25771114600),
    {
      "t": 1310824,
      "n": "Pong",
      "d": 1310824,
      "h": 25771114600,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771114600)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278120),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1310824,
      "h": 4296278120,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278120)
  ],
  "d": 1114216,
  "h": 1310824
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.ManagedWebSocket+MessageOpcode`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}ManagedWebSocket${separator}MessageOpcode`; }
                }, $cls, ($v) => $cls.$_MessageOpcode = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1310824)
            
            //--TRIMMABLE-BOUNDARY-START(1245288)
            static $_MessageHeader;
            static get MessageHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1245288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SNW.ManagedWebSocket;
                return $cls.$_MessageHeader ??= $asm.$nstr(`$snws.SNW.ManagedWebSocket.MessageHeader`, ($self) => class MessageHeader extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(47245885544)
                    /*MessageOpcode*/ Opcode = 0;
                    //--TRIMMABLE-BOUNDARY-END(47245885544)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476081768)
                    /*bool*/ Fin = false;
                    //--TRIMMABLE-BOUNDARY-END(21476081768)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540852840)
                    /*long*/ PayloadLength = 0n;
                    //--TRIMMABLE-BOUNDARY-END(51540852840)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886147176)
                    /*bool*/ Compressed = false;
                    //--TRIMMABLE-BOUNDARY-END(12886147176)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950918248)
                    /*int*/ Mask = 0;
                    //--TRIMMABLE-BOUNDARY-END(42950918248)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835820136)
                    /*bool*/ Processed = false;
                    //--TRIMMABLE-BOUNDARY-END(55835820136)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181114472)
                    /*bool */ get EndOfMessage()
                    {
                        return this.Fin && this.Processed && this.PayloadLength === 0n;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181114472)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591179880)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8591179880);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591179880)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591179880)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591179880)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Opcode = this.Opcode;
                        copy.Fin = this.Fin;
                        copy.PayloadLength = this.PayloadLength;
                        copy.Compressed = this.Compressed;
                        copy.Mask = this.Mask;
                        copy.Processed = this.Processed;
                        return copy;
                    }
                    static $h = 1245288;
                    static $z = 16;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835820136),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655950952,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425754728,
        "f": 83886088
      },
      "n": "Processed",
      "d": 1245288,
      "h": 55835820136,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(55835820136),
//--TRIMMABLE-BOUNDARY-START(17181114472),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066016360,
        "f": 50331656
      },
      "n": "EndOfMessage",
      "d": 1245288,
      "h": 17181114472,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(17181114472)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245885544),
    {
      "t": 1310824,
      "n": "Opcode",
      "d": 1245288,
      "h": 47245885544,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(47245885544),
//--TRIMMABLE-BOUNDARY-START(21476081768),
    {
      "t": 262145,
      "n": "Fin",
      "d": 1245288,
      "h": 21476081768,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21476081768),
//--TRIMMABLE-BOUNDARY-START(51540852840),
    {
      "t": 917505,
      "n": "PayloadLength",
      "d": 1245288,
      "h": 51540852840,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(51540852840),
//--TRIMMABLE-BOUNDARY-START(12886147176),
    {
      "t": 262145,
      "n": "Compressed",
      "d": 1245288,
      "h": 12886147176,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12886147176),
//--TRIMMABLE-BOUNDARY-START(42950918248),
    {
      "t": 655361,
      "n": "Mask",
      "d": 1245288,
      "h": 42950918248,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(42950918248)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591179880),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245288,
      "h": 8591179880,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591179880)
  ],
  "d": 1114216,
  "h": 1245288,
  "a": [
    {
      "t": 148176897,
      "c": 13033078785,
      "a": [
        {
          "v": 3,
          "t": 143654913
        }
      ]
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.ManagedWebSocket+MessageHeader`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}ManagedWebSocket${separator}MessageHeader`; }
                }, $cls, ($v) => $cls.$_MessageHeader = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1245288)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51540721768)
                this._receiveBuffer = $.$default($.$$.S.Memory$$($.$$.S.Byte));
                //--TRIMMABLE-BOUNDARY-END(51540721768)
                
                //--TRIMMABLE-BOUNDARY-START(103080329320)
                this._utf8TextState = new $.$snws.SNW.ManagedWebSocket.Utf8MessageState().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(103080329320)
                
                //--TRIMMABLE-BOUNDARY-START(81605492840)
                this._sendMutex = new $.$snws.ST.AsyncMutex().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(81605492840)
                
                //--TRIMMABLE-BOUNDARY-START(73015558248)
                this._receiveMutex = new $.$snws.ST.AsyncMutex().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(73015558248)
                
                //--TRIMMABLE-BOUNDARY-START(38655819880)
                this._lastReceiveHeader = (() =>
                {
                    //new $.$snws.SNW.ManagedWebSocket.MessageHeader()
                    const $t38 = $.$snws.SNW.ManagedWebSocket.MessageHeader;
                    const $i38 = new $t38();
                    $i38.$ctor$2();
                    $i38.Opcode = 1/*MessageOpcode.Text*/;
                    $i38.Fin = true;
                    $i38.Processed = true;
                    return $i38;
                })();
                //--TRIMMABLE-BOUNDARY-END(38655819880)
                
            }
            //--TRIMMABLE-BOUNDARY-START(107375296616)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375296616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(326418628712)
                    this.s_textEncoding = new $.$$.ST.UTF8Encoding().$ctor$5(false, true);
                    //--TRIMMABLE-BOUNDARY-END(326418628712)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107375296616)
            
            static $h = 1114216;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snws.SNW.WebSocket; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(266289086568),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219044446312,
        "f": 50331650
      },
      "n": "IsUnsolicitedPongKeepAlive",
      "d": 1114216,
      "h": 266289086568,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(266289086568),
//--TRIMMABLE-BOUNDARY-START(369368301672),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236224315496,
        "f": 50331650
      },
      "n": "StateUpdateLock",
      "d": 1114216,
      "h": 369368301672,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(369368301672),
//--TRIMMABLE-BOUNDARY-START(154619936872),
    {
      "p": $.$typeNullable($.$snws.SNW.WebSocketCloseStatus).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201864577128,
        "f": 50364417
      },
      "n": "CloseStatus",
      "d": 1114216,
      "h": 154619936872,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619936872),
//--TRIMMABLE-BOUNDARY-START(158914904168),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210454511720,
        "f": 50364417
      },
      "n": "CloseStatusDescription",
      "d": 1114216,
      "h": 158914904168,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158914904168),
//--TRIMMABLE-BOUNDARY-START(365073334376),
    {
      "p": 2293864,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227634380904,
        "f": 50364417
      },
      "n": "State",
      "d": 1114216,
      "h": 365073334376,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(365073334376),
//--TRIMMABLE-BOUNDARY-START(373663268968),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244814250088,
        "f": 50364417
      },
      "n": "SubProtocol",
      "d": 1114216,
      "h": 373663268968,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(373663268968)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(261994119272),
    {
      "r": 65537,
      "n": "HeartBeat",
      "d": 1114216,
      "h": 261994119272,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(261994119272),
//--TRIMMABLE-BOUNDARY-START(416612941928),
    {
      "r": 65537,
      "n": "UnsolicitedPongHeartBeat",
      "d": 1114216,
      "h": 416612941928,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(416612941928),
//--TRIMMABLE-BOUNDARY-START(408023007336),
    {
      "r": 181338113,
      "p": [
        {
          "n": "opcode",
          "p": 1310824
        },
        {
          "n": "payload",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
          "f": 65
        }
      ],
      "n": "TrySendKeepAliveFrameAsync",
      "d": 1114216,
      "h": 408023007336,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(408023007336),
//--TRIMMABLE-BOUNDARY-START(274879021160),
    {
      "r": 65537,
      "n": "KeepAlivePingHeartBeat",
      "d": 1114216,
      "h": 274879021160,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(274879021160),
//--TRIMMABLE-BOUNDARY-START(360778367080),
    {
      "r": 181338113,
      "p": [
        {
          "n": "pingPayload",
          "p": 917505
        }
      ],
      "n": "SendPingAsync",
      "d": 1114216,
      "h": 360778367080,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(360778367080),
//--TRIMMABLE-BOUNDARY-START(180389740648),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1114216,
      "h": 180389740648,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389740648),
//--TRIMMABLE-BOUNDARY-START(184684707944),
    {
      "r": 65537,
      "n": "DisposeCore",
      "d": 1114216,
      "h": 184684707944,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(184684707944),
//--TRIMMABLE-BOUNDARY-START(188979675240),
    {
      "r": 65537,
      "p": [
        {
          "n": "resource",
          "p": 91095041
        },
        {
          "n": "mutex",
          "p": 2883688
        }
      ],
      "n": "DisposeSafe",
      "d": 1114216,
      "h": 188979675240,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(188979675240),
//--TRIMMABLE-BOUNDARY-START(330713596008),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "SendAsync",
      "d": 1114216,
      "h": 330713596008,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(330713596008),
//--TRIMMABLE-BOUNDARY-START(335008563304),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "SendAsync",
      "o": "@$1",
      "d": 1114216,
      "h": 335008563304,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(335008563304),
//--TRIMMABLE-BOUNDARY-START(339303530600),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "messageFlags",
          "p": 2097256
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "SendAsync",
      "o": "@$2",
      "d": 1114216,
      "h": 339303530600,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(339303530600),
//--TRIMMABLE-BOUNDARY-START(309238759528),
    {
      "r": $.$$.STT.Task$$($.$snws.SNW.WebSocketReceiveResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReceiveAsync",
      "d": 1114216,
      "h": 309238759528,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(309238759528),
//--TRIMMABLE-BOUNDARY-START(313533726824),
    {
      "r": $.$$.STT.ValueTask$$($.$snws.SNW.ValueWebSocketReceiveResult).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReceiveAsync",
      "o": "@$1",
      "d": 1114216,
      "h": 313533726824,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(313533726824),
//--TRIMMABLE-BOUNDARY-START(137440067688),
    {
      "r": 178454529,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "statusDescription",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CloseAsync",
      "d": 1114216,
      "h": 137440067688,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(137440067688),
//--TRIMMABLE-BOUNDARY-START(146030002280),
    {
      "r": 178454529,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "statusDescription",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CloseOutputAsync",
      "d": 1114216,
      "h": 146030002280,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146030002280),
//--TRIMMABLE-BOUNDARY-START(150324969576),
    {
      "r": 178454529,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "statusDescription",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CloseOutputAsyncCore",
      "d": 1114216,
      "h": 150324969576,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(150324969576),
//--TRIMMABLE-BOUNDARY-START(120260198504),
    {
      "r": 65537,
      "n": "Abort",
      "d": 1114216,
      "h": 120260198504,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120260198504),
//--TRIMMABLE-BOUNDARY-START(300648824936),
    {
      "r": 65537,
      "n": "OnAborted",
      "d": 1114216,
      "h": 300648824936,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(300648824936),
//--TRIMMABLE-BOUNDARY-START(304943792232),
    {
      "r": 65537,
      "n": "OnAbortedCore",
      "d": 1114216,
      "h": 304943792232,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(304943792232),
//--TRIMMABLE-BOUNDARY-START(347893465192),
    {
      "r": 181338113,
      "p": [
        {
          "n": "opcode",
          "p": 1310824
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "disableCompression",
          "p": 262145
        },
        {
          "n": "payloadBuffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "SendFrameAsync",
      "d": 1114216,
      "h": 347893465192,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(347893465192),
//--TRIMMABLE-BOUNDARY-START(356483399784),
    {
      "r": 181338113,
      "p": [
        {
          "n": "opcode",
          "p": 1310824
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "disableCompression",
          "p": 262145
        },
        {
          "n": "payloadBuffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        }
      ],
      "n": "SendFrameLockAcquiredNonCancelableAsync",
      "d": 1114216,
      "h": 356483399784,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(356483399784),
//--TRIMMABLE-BOUNDARY-START(425202876520),
    {
      "r": 181338113,
      "p": [
        {
          "n": "writeTask",
          "p": 181338113
        },
        {
          "n": "shouldFlush",
          "p": 262145
        }
      ],
      "n": "WaitForWriteTaskAsync",
      "d": 1114216,
      "h": 425202876520,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(425202876520),
//--TRIMMABLE-BOUNDARY-START(352188432488),
    {
      "r": 181338113,
      "p": [
        {
          "n": "opcode",
          "p": 1310824
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "disableCompression",
          "p": 262145
        },
        {
          "n": "payloadBuffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "lockTask",
          "p": 178454529
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "SendFrameFallbackAsync",
      "d": 1114216,
      "h": 352188432488,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(352188432488),
//--TRIMMABLE-BOUNDARY-START(429497843816),
    {
      "r": 655361,
      "p": [
        {
          "n": "opcode",
          "p": 1310824
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "disableCompression",
          "p": 262145
        },
        {
          "n": "payloadBuffer",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "WriteFrameToSendBuffer",
      "d": 1114216,
      "h": 429497843816,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(429497843816),
//--TRIMMABLE-BOUNDARY-START(433792811112),
    {
      "r": 655361,
      "p": [
        {
          "n": "opcode",
          "p": 1310824
        },
        {
          "n": "sendBuffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "payload",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "useMask",
          "p": 262145
        },
        {
          "n": "compressed",
          "p": 262145
        }
      ],
      "n": "WriteHeader",
      "d": 1114216,
      "h": 433792811112,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(433792811112),
//--TRIMMABLE-BOUNDARY-START(438087778408),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "WriteRandomMask",
      "d": 1114216,
      "h": 438087778408,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(438087778408),
//--TRIMMABLE-BOUNDARY-START(317828694120),
    {
      "r": (TResult) => $.$$.STT.ValueTask$$(TResult).$h,
      "p": [
        {
          "n": "payloadBuffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "ReceiveAsyncPrivate",
      "d": 1114216,
      "h": 317828694120,
      "f": 16912386,
      "a": [
        {
          "t": 124649473,
          "c": 8714584065,
          "a": [
            {
              "v": 132382721,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(317828694120),
//--TRIMMABLE-BOUNDARY-START(249109217384),
    {
      "r": (TResult) => TResult.$h,
      "p": [
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "endOfMessage",
          "p": 262145
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "GetReceiveResult",
      "d": 1114216,
      "h": 249109217384,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(249109217384),
//--TRIMMABLE-BOUNDARY-START(253404184680),
    {
      "r": 181338113,
      "p": [
        {
          "n": "header",
          "p": 1245288
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "HandleReceivedCloseAsync",
      "d": 1114216,
      "h": 253404184680,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(253404184680),
//--TRIMMABLE-BOUNDARY-START(420907909224),
    {
      "r": 181338113,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WaitForServerToCloseConnectionAsync",
      "d": 1114216,
      "h": 420907909224,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(420907909224),
//--TRIMMABLE-BOUNDARY-START(257699151976),
    {
      "r": 181338113,
      "p": [
        {
          "n": "header",
          "p": 1245288
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "HandleReceivedPingPongAsync",
      "d": 1114216,
      "h": 257699151976,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(257699151976),
//--TRIMMABLE-BOUNDARY-START(270584053864),
    {
      "r": 262145,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        }
      ],
      "n": "IsValidCloseStatus",
      "d": 1114216,
      "h": 270584053864,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(270584053864),
//--TRIMMABLE-BOUNDARY-START(163209871464),
    {
      "r": 181338113,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "error",
          "p": 1966184
        },
        {
          "n": "errorMessage",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "innerException",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "CloseWithReceiveErrorAndThrowAsync",
      "d": 1114216,
      "h": 163209871464,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(163209871464),
//--TRIMMABLE-BOUNDARY-START(403728040040),
    {
      "r": 1310721,
      "p": [
        {
          "n": "resultHeader",
          "p": 1245288,
          "f": 2
        }
      ],
      "n": "TryParseMessageHeaderFromReceiveBuffer",
      "d": 1114216,
      "h": 403728040040,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(403728040040),
//--TRIMMABLE-BOUNDARY-START(141735034984),
    {
      "r": 178454529,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "statusDescription",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CloseAsyncPrivate",
      "d": 1114216,
      "h": 141735034984,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(141735034984),
//--TRIMMABLE-BOUNDARY-START(343598497896),
    {
      "r": 181338113,
      "p": [
        {
          "n": "closeStatus",
          "p": 1638504
        },
        {
          "n": "closeStatusDescription",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "SendCloseFrameAsync",
      "d": 1114216,
      "h": 343598497896,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(343598497896),
//--TRIMMABLE-BOUNDARY-START(171799806056),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ConsumeFromBuffer",
      "d": 1114216,
      "h": 171799806056,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(171799806056),
//--TRIMMABLE-BOUNDARY-START(193274642536),
    {
      "r": 181338113,
      "p": [
        {
          "n": "minimumRequiredBytes",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "EnsureBufferContainsAsync",
      "d": 1114216,
      "h": 193274642536,
      "f": 16781314,
      "a": [
        {
          "t": 124649473,
          "c": 8714584065,
          "a": [
            {
              "v": 132317185,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193274642536),
//--TRIMMABLE-BOUNDARY-START(377958236264),
    {
      "r": 65537,
      "n": "ThrowEOFUnexpected",
      "d": 1114216,
      "h": 377958236264,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(377958236264),
//--TRIMMABLE-BOUNDARY-START(124555165800),
    {
      "r": 65537,
      "p": [
        {
          "n": "minLength",
          "p": 655361
        }
      ],
      "n": "AllocateSendBuffer",
      "d": 1114216,
      "h": 124555165800,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124555165800),
//--TRIMMABLE-BOUNDARY-START(322123661416),
    {
      "r": 65537,
      "n": "ReleaseSendBuffer",
      "d": 1114216,
      "h": 322123661416,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(322123661416),
//--TRIMMABLE-BOUNDARY-START(167504838760),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "maskOffset",
          "p": 655361
        }
      ],
      "n": "CombineMaskBytes",
      "d": 1114216,
      "h": 167504838760,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(167504838760),
//--TRIMMABLE-BOUNDARY-START(128850133096),
    {
      "r": 655361,
      "p": [
        {
          "n": "toMask",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "mask",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "maskOffset",
          "p": 655361
        },
        {
          "n": "maskOffsetIndex",
          "p": 655361
        }
      ],
      "n": "ApplyMask",
      "d": 1114216,
      "h": 128850133096,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(128850133096),
//--TRIMMABLE-BOUNDARY-START(133145100392),
    {
      "r": 655361,
      "p": [
        {
          "n": "toMask",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "mask",
          "p": 655361
        },
        {
          "n": "maskIndex",
          "p": 655361
        }
      ],
      "n": "ApplyMask",
      "o": "@$1",
      "d": 1114216,
      "h": 133145100392,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(133145100392),
//--TRIMMABLE-BOUNDARY-START(395138105448),
    {
      "r": 65537,
      "p": [
        {
          "n": "operationCompleted",
          "p": 262145
        },
        {
          "n": "methodName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "ThrowIfOperationInProgress",
      "d": 1114216,
      "h": 395138105448,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(395138105448),
//--TRIMMABLE-BOUNDARY-START(399433072744),
    {
      "r": 65537,
      "p": [
        {
          "n": "methodName",
          "p": 1310721
        }
      ],
      "n": "ThrowOperationInProgress",
      "d": 1114216,
      "h": 399433072744,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(399433072744),
//--TRIMMABLE-BOUNDARY-START(176094773352),
    {
      "r": 104660993,
      "p": [
        {
          "n": "innerException",
          "p": 80805889
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "CreateOperationCanceledException",
      "d": 1114216,
      "h": 176094773352,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(176094773352),
//--TRIMMABLE-BOUNDARY-START(382253203560),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": 1114216,
      "h": 382253203560,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(382253203560),
//--TRIMMABLE-BOUNDARY-START(390843138152),
    {
      "r": 65537,
      "p": [
        {
          "n": "validStates",
          "p": 1441896
        }
      ],
      "n": "ThrowIfInvalidState",
      "d": 1114216,
      "h": 390843138152,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(390843138152),
//--TRIMMABLE-BOUNDARY-START(412317974632),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "endOfMessage",
          "p": 262145
        },
        {
          "n": "state",
          "p": 1376360
        }
      ],
      "n": "TryValidateUtf8",
      "d": 1114216,
      "h": 412317974632,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(412317974632),
//--TRIMMABLE-BOUNDARY-START(283468955752),
    {
      "r": 65537,
      "p": [
        {
          "n": "t",
          "p": 181338113
        }
      ],
      "n": "LogExceptions",
      "o": "@$1",
      "d": 1114216,
      "h": 283468955752,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(283468955752),
//--TRIMMABLE-BOUNDARY-START(279173988456),
    {
      "r": 65537,
      "p": [
        {
          "n": "t",
          "p": 178454529
        }
      ],
      "n": "LogExceptions",
      "d": 1114216,
      "h": 279173988456,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(279173988456),
//--TRIMMABLE-BOUNDARY-START(386548170856),
    {
      "r": 65537,
      "p": [
        {
          "n": "messageType",
          "p": 2162792
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "messageType",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfInvalidMessageType",
      "d": 1114216,
      "h": 386548170856,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(386548170856)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(326418628712),
    {
      "t": 169607169,
      "n": "s_textEncoding",
      "d": 1114216,
      "h": 326418628712,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(326418628712),
//--TRIMMABLE-BOUNDARY-START(296353857640),
    {
      "t": 655361,
      "n": "MaxMessageHeaderLength",
      "d": 1114216,
      "h": 296353857640,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296353857640),
//--TRIMMABLE-BOUNDARY-START(292058890344),
    {
      "t": 655361,
      "n": "MaxControlPayloadLength",
      "d": 1114216,
      "h": 292058890344,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(292058890344),
//--TRIMMABLE-BOUNDARY-START(287763923048),
    {
      "t": 655361,
      "n": "MaskLength",
      "d": 1114216,
      "h": 287763923048,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(287763923048),
//--TRIMMABLE-BOUNDARY-START(94490394728),
    {
      "t": 95748097,
      "n": "_stream",
      "d": 1114216,
      "h": 94490394728,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(94490394728),
//--TRIMMABLE-BOUNDARY-START(25770917992),
    {
      "t": 262145,
      "n": "_isServer",
      "d": 1114216,
      "h": 25770917992,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770917992),
//--TRIMMABLE-BOUNDARY-START(98785362024),
    {
      "t": 1310721,
      "n": "_subprotocol",
      "d": 1114216,
      "h": 98785362024,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98785362024),
//--TRIMMABLE-BOUNDARY-START(34360852584),
    {
      "t": 183762945,
      "n": "_keepAliveTimer",
      "d": 1114216,
      "h": 34360852584,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360852584),
//--TRIMMABLE-BOUNDARY-START(51540721768),
    {
      "t": $.$$.S.Memory$$($.$$.S.Byte).$h,
      "n": "_receiveBuffer",
      "d": 1114216,
      "h": 51540721768,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540721768),
//--TRIMMABLE-BOUNDARY-START(103080329320),
    {
      "t": 1376360,
      "n": "_utf8TextState",
      "d": 1114216,
      "h": 103080329320,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(103080329320),
//--TRIMMABLE-BOUNDARY-START(81605492840),
    {
      "t": 2883688,
      "n": "_sendMutex",
      "d": 1114216,
      "h": 81605492840,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81605492840),
//--TRIMMABLE-BOUNDARY-START(73015558248),
    {
      "t": 2883688,
      "n": "_receiveMutex",
      "d": 1114216,
      "h": 73015558248,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73015558248),
//--TRIMMABLE-BOUNDARY-START(90195427432),
    {
      "t": 2293864,
      "n": "_state",
      "d": 1114216,
      "h": 90195427432,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(90195427432),
//--TRIMMABLE-BOUNDARY-START(17180983400),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 1114216,
      "h": 17180983400,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180983400),
//--TRIMMABLE-BOUNDARY-START(85900460136),
    {
      "t": 262145,
      "n": "_sentCloseFrame",
      "d": 1114216,
      "h": 85900460136,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85900460136),
//--TRIMMABLE-BOUNDARY-START(64425623656),
    {
      "t": 262145,
      "n": "_receivedCloseFrame",
      "d": 1114216,
      "h": 64425623656,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425623656),
//--TRIMMABLE-BOUNDARY-START(4296081512),
    {
      "t": $.$typeNullable($.$snws.SNW.WebSocketCloseStatus).$h,
      "n": "_closeStatus",
      "d": 1114216,
      "h": 4296081512,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081512),
//--TRIMMABLE-BOUNDARY-START(8591048808),
    {
      "t": 1310721,
      "n": "_closeStatusDescription",
      "d": 1114216,
      "h": 8591048808,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591048808),
//--TRIMMABLE-BOUNDARY-START(38655819880),
    {
      "t": 1245288,
      "n": "_lastReceiveHeader",
      "d": 1114216,
      "h": 38655819880,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655819880),
//--TRIMMABLE-BOUNDARY-START(60130656360),
    {
      "t": 655361,
      "n": "_receiveBufferOffset",
      "d": 1114216,
      "h": 60130656360,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60130656360),
//--TRIMMABLE-BOUNDARY-START(55835689064),
    {
      "t": 655361,
      "n": "_receiveBufferCount",
      "d": 1114216,
      "h": 55835689064,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835689064),
//--TRIMMABLE-BOUNDARY-START(68720590952),
    {
      "t": 655361,
      "n": "_receivedMaskOffsetOffset",
      "d": 1114216,
      "h": 68720590952,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68720590952),
//--TRIMMABLE-BOUNDARY-START(77310525544),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_sendBuffer",
      "d": 1114216,
      "h": 77310525544,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77310525544),
//--TRIMMABLE-BOUNDARY-START(47245754472),
    {
      "t": 262145,
      "n": "_lastSendWasFragment",
      "d": 1114216,
      "h": 47245754472,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245754472),
//--TRIMMABLE-BOUNDARY-START(42950787176),
    {
      "t": 262145,
      "n": "_lastSendHadDisableCompression",
      "d": 1114216,
      "h": 42950787176,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950787176),
//--TRIMMABLE-BOUNDARY-START(21475950696),
    {
      "t": 1048680,
      "n": "_inflater",
      "d": 1114216,
      "h": 21475950696,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475950696),
//--TRIMMABLE-BOUNDARY-START(12886016104),
    {
      "t": 983144,
      "n": "_deflater",
      "d": 1114216,
      "h": 12886016104,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886016104),
//--TRIMMABLE-BOUNDARY-START(30065885288),
    {
      "t": 1179752,
      "n": "_keepAlivePingState",
      "d": 1114216,
      "h": 30065885288,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065885288)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(111670263912),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "isServer",
          "p": 262145
        },
        {
          "n": "subprotocol",
          "p": 1310721
        },
        {
          "n": "keepAliveInterval",
          "p": 186646529
        },
        {
          "n": "keepAliveTimeout",
          "p": 186646529
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114216,
      "h": 111670263912,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(111670263912),
//--TRIMMABLE-BOUNDARY-START(115965231208),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "options",
          "p": 1769576
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1114216,
      "h": 115965231208,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(115965231208)
  ],
  "h": 1114216
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$snws.SNW.ManagedWebSocket.KeepAlivePingState, $.$snws.SNW.ManagedWebSocket.Utf8MessageState, $.$snws.SNW.ManagedWebSocket.MessageOpcode, $.$snws.SNW.ManagedWebSocket.MessageHeader ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.ManagedWebSocket`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}ManagedWebSocket`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114216)
        
        

        //--TRIMMABLE-BOUNDARY-START(2424936)
        $asm.$cls(`$snws.SNW.WebSocketStream`, ($self) => class WebSocketStream extends $.$$.SI.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(55836999784)
            /*int*/ static DefaultCloseTimeoutSeconds = 16;
            //--TRIMMABLE-BOUNDARY-END(55836999784)
            
            //--TRIMMABLE-BOUNDARY-START(4297392232)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(4297392232)
            
            //--TRIMMABLE-BOUNDARY-START(12887326824)
            $ctor$3(/*WebSocket*/ webSocket)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887326824);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.WebSocket = webSocket;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887326824)
            
            //--TRIMMABLE-BOUNDARY-START(38657130600)
            static /*WebSocketStream */ Create(/*WebSocket*/ webSocket, /*WebSocketMessageType*/ writeMessageType, /*bool*/ ownsWebSocket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657130600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(webSocket, "webSocket");
                $.$snws.SNW.ManagedWebSocket.ThrowIfInvalidMessageType(writeMessageType, "writeMessageType");
                return new $.$snws.SNW.WebSocketStream.ReadWriteStream().$ctor$4(webSocket, writeMessageType, ownsWebSocket ? $.$$.S.TimeSpan.FromSeconds$2(BigInt(16/*DefaultCloseTimeoutSeconds*/)) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(38657130600)
            
            //--TRIMMABLE-BOUNDARY-START(42952097896)
            static /*WebSocketStream */ Create$1(/*WebSocket*/ webSocket, /*WebSocketMessageType*/ writeMessageType, /*TimeSpan*/ closeTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952097896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(webSocket, "webSocket");
                $.$snws.SNW.ManagedWebSocket.ThrowIfInvalidMessageType(writeMessageType, "writeMessageType");
                if ($.$$.S.TimeSpan.op_LessThan(closeTimeout, $.$$.S.TimeSpan.Zero) && $.$$.S.TimeSpan.op_Inequality(closeTimeout, $.$$.ST$1.Timeout.InfiniteTimeSpan))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("closeTimeout", $.$snws.S.SR.net_WebSockets_TimeoutOutOfRange);
                }
                return new $.$snws.SNW.WebSocketStream.ReadWriteStream().$ctor$4(webSocket, writeMessageType, closeTimeout);
            }
            //--TRIMMABLE-BOUNDARY-END(42952097896)
            
            //--TRIMMABLE-BOUNDARY-START(51542032488)
            static /*WebSocketStream */ CreateWritableMessageStream(/*WebSocket*/ webSocket, /*WebSocketMessageType*/ writeMessageType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542032488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(webSocket, "webSocket");
                $.$snws.SNW.ManagedWebSocket.ThrowIfInvalidMessageType(writeMessageType, "writeMessageType");
                return new $.$snws.SNW.WebSocketStream.WriteMessageStream().$ctor$4(webSocket, writeMessageType);
            }
            //--TRIMMABLE-BOUNDARY-END(51542032488)
            
            //--TRIMMABLE-BOUNDARY-START(47247065192)
            static /*WebSocketStream */ CreateReadableMessageStream(/*WebSocket*/ webSocket)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247065192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(webSocket, "webSocket");
                return new $.$snws.SNW.WebSocketStream.ReadMessageStream().$ctor$4(webSocket);
            }
            //--TRIMMABLE-BOUNDARY-END(47247065192)
            
            //--TRIMMABLE-BOUNDARY-START(171801116776)
            /*WebSocket*/ WebSocket = null;
            //--TRIMMABLE-BOUNDARY-END(171801116776)
            
            //--TRIMMABLE-BOUNDARY-START(25772228712)
            /*bool */ get CanRead()
            {
                return !this._disposed && (this.WebSocket.State === 2/*WebSocketState.Open*/) || (this.WebSocket.State === 3/*WebSocketState.CloseSent*/);
            }
            //--TRIMMABLE-BOUNDARY-END(25772228712)
            
            //--TRIMMABLE-BOUNDARY-START(34362163304)
            /*bool */ get CanWrite()
            {
                return !this._disposed && (this.WebSocket.State === 2/*WebSocketState.Open*/) || (this.WebSocket.State === 4/*WebSocketState.CloseReceived*/);
            }
            //--TRIMMABLE-BOUNDARY-END(34362163304)
            
            //--TRIMMABLE-BOUNDARY-START(30067196008)
            /*bool */ get CanSeek()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(30067196008)
            
            //--TRIMMABLE-BOUNDARY-START(60131967080)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131967080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (disposing)
                {
                    this.DisposeAsync().AsTask().GetAwaiter().GetResult();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131967080)
            
            //--TRIMMABLE-BOUNDARY-START(73016868968)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016868968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(73016868968)
            
            //--TRIMMABLE-BOUNDARY-START(77311836264)
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77311836264);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return cancellationToken.IsCancellationRequested ? $.$$.STT.Task.FromCanceled$1(cancellationToken) : $.$$.STT.Task.CompletedTask;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77311836264)
            
            //--TRIMMABLE-BOUNDARY-START(146031313000)
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031313000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SI.Stream.ValidateBufferArguments(buffer, offset, count);
                return this.ReadAsync$2($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, buffer, offset, count), cancellationToken).AsTask();
            }
            //--TRIMMABLE-BOUNDARY-END(146031313000)
            
            //--TRIMMABLE-BOUNDARY-START(150326280296)
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150326280296);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.ValueTask.FromException$1($.$$.S.Int32, $.$$.SRE$1.ExceptionDispatchInfo.SetCurrentStackTrace(new $.$$.S.NotSupportedException().$ctor$9()));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150326280296)
            
            //--TRIMMABLE-BOUNDARY-START(17182294120)
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182294120);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.TaskToAsyncResult.Begin(this.ReadAsync$1(buffer, offset, count), callback, state);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182294120)
            
            //--TRIMMABLE-BOUNDARY-START(64426934376)
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426934376);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.TaskToAsyncResult.End$1($.$$.S.Int32, asyncResult);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64426934376)
            
            //--TRIMMABLE-BOUNDARY-START(180391051368)
            /*Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391051368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SI.Stream.ValidateBufferArguments(buffer, offset, count);
                return this.WriteAsync$2($.$$.S.Memory$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, buffer, offset, count)), cancellationToken).AsTask();
            }
            //--TRIMMABLE-BOUNDARY-END(180391051368)
            
            //--TRIMMABLE-BOUNDARY-START(184686018664)
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184686018664);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.ValueTask.FromException($.$$.SRE$1.ExceptionDispatchInfo.SetCurrentStackTrace(new $.$$.S.NotSupportedException().$ctor$9()));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184686018664)
            
            //--TRIMMABLE-BOUNDARY-START(21477261416)
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477261416);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.TaskToAsyncResult.Begin(this.WriteAsync$1(buffer, offset, count), callback, state);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477261416)
            
            //--TRIMMABLE-BOUNDARY-START(68721901672)
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721901672);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.TaskToAsyncResult.End(asyncResult);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721901672)
            
            //--TRIMMABLE-BOUNDARY-START(141736345704)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141736345704);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ReadAsync(buffer, offset, count, new $.$$.ST$1.CancellationToken()).GetAwaiter$1().GetResult();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141736345704)
            
            //--TRIMMABLE-BOUNDARY-START(176096084072)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176096084072);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.WriteAsync(buffer, offset, count, new $.$$.ST$1.CancellationToken()).GetAwaiter().GetResult();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176096084072)
            
            //--TRIMMABLE-BOUNDARY-START(133146411112)
            /*long */ get Length()
            {
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(133146411112)
            
            //--TRIMMABLE-BOUNDARY-START(137441378408)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261509224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211182184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(137441378408)
            
            //--TRIMMABLE-BOUNDARY-START(154621247592)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154621247592);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154621247592)
            
            //--TRIMMABLE-BOUNDARY-START(167506149480)
            /*void */ SetLength(/*long*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167506149480);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167506149480)
            
            //--TRIMMABLE-BOUNDARY-START(2556008)
            static $_ReadWriteStream;
            static get ReadWriteStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2556008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SNW.WebSocketStream;
                return $cls.$_ReadWriteStream ??= $asm.$ncls(`$snws.SNW.WebSocketStream.ReadWriteStream`, ($self) => class ReadWriteStream extends $.$snws.SNW.WebSocketStream
                {
                    //--TRIMMABLE-BOUNDARY-START(8592490600)
                    /*WebSocketMessageType*/ _messageType = 0;
                    //--TRIMMABLE-BOUNDARY-END(8592490600)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297523304)
                    /*TimeSpan?*/ _closeTimeout = null;
                    //--TRIMMABLE-BOUNDARY-END(4297523304)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772359784)
                    /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25772359784);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._disposed)
                        {
                            return $.$$.STT.ValueTask.FromException($.$$.SRE$1.ExceptionDispatchInfo.SetCurrentStackTrace(new $.$$.S.ObjectDisposedException().$ctor$17($.$$.S.Object.GetType.call(this).FullName)));
                        }
                        if (!this.CanWrite)
                        {
                            return $.$$.STT.ValueTask.FromException($.$$.SRE$1.ExceptionDispatchInfo.SetCurrentStackTrace(new $.$$.S.NotSupportedException().$ctor$12($.$snws.S.SR.NotWriteableStream)));
                        }
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return $.$$.STT.ValueTask.FromCanceled(cancellationToken);
                        }
                        return this.WebSocket.SendAsync$1(buffer, this._messageType, true, cancellationToken);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772359784)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477392488)
                    /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Int32), $.$$.S.Int32, async ($asnycContext) => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21477392488);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.S.ObjectDisposedException.ThrowIf(this._disposed, this);
                            if (!this.CanRead)
                            {
                                throw new $.$$.S.NotSupportedException().$ctor$12($.$snws.S.SR.NotReadableStream);
                            }
                            cancellationToken.ThrowIfCancellationRequested();
                            while(this.WebSocket.State < 4/*WebSocketState.CloseReceived*/)
                            {
                                let $t1, $r1;
                                /*ValueWebSocketReceiveResult*/ let result = ($t1 = this.WebSocket.ReceiveAsync$1(buffer, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                                if (result.MessageType === 2)
                                {
                                    break;
                                }
                                if (result.Count > 0 || buffer.IsEmpty)
                                {
                                    return $.$$.N.AsyncResolver.Result($asnycContext, result.Count);
                                }
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext, 0);
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477392488)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182425192)
                    /*ValueTask *//*async*/  DisposeAsync()
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17182425192);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            if (!this._disposed)
                            {
                                this._disposed = true;
                                let timeout;
                                if ((timeout = this._closeTimeout, timeout != null && true))
                                {
                                    if (this.WebSocket.State < 5/*WebSocketState.Closed*/)
                                    {
                                        /*CancellationTokenSource?*/ let cts = null;
                                        /*CancellationToken*/ let ct;
                                        if ($.$$.S.TimeSpan.op_Equality(timeout, new $.$$.S.TimeSpan()))
                                        {
                                            ct = new $.$$.ST$1.CancellationToken().$ctor$3(true);
                                        }
                                        else if ($.$$.S.TimeSpan.op_Equality(timeout, $.$$.ST$1.Timeout.InfiniteTimeSpan))
                                        {
                                            ct = $.$$.ST$1.CancellationToken.None;
                                        }
                                        else 
                                        {
                                            cts = new $.$$.ST$1.CancellationTokenSource().$ctor$4(timeout);
                                            ct = cts.Token;
                                        }
                                        try
                                        {
                                            let $t2, $r2;
                                            ($t2 = this.WebSocket.CloseAsync(1000/*WebSocketCloseStatus.NormalClosure*/, null, ct).ConfigureAwait$1(2/*ConfigureAwaitOptions.SuppressThrowing*/), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                                        }
                                        finally
                                        {
                                            {
                                                cts?.Dispose();
                                            }
                                        }
                                    }
                                    this.WebSocket.Dispose();
                                }
                            }
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182425192)
                    
                    //Begin primary constructor
                    /*WebSocket*/ webSocket = null;
                    /*WebSocketMessageType*/ writeMessageType = 0;
                    /*TimeSpan?*/ closeTimeout = null;
                    $ctor$4(/*WebSocket*/webSocket, /*WebSocketMessageType*/writeMessageType, /*TimeSpan?*/closeTimeout)
                    {
                        this.webSocket = webSocket;
                        this.writeMessageType = writeMessageType;
                        this.closeTimeout = closeTimeout;
                        super.$ctor$3(this.webSocket);
                        //--TRIMMABLE-BOUNDARY-START(8592490600)
                        //depends on primary constructor parameter
                        this._messageType = this.writeMessageType;
                        //--TRIMMABLE-BOUNDARY-END(8592490600)
                        
                        //--TRIMMABLE-BOUNDARY-START(4297523304)
                        //depends on primary constructor parameter
                        this._closeTimeout = $.$clone(this.closeTimeout);
                        //--TRIMMABLE-BOUNDARY-END(4297523304)
                        
                        return this
                    }
                    //End primary constructor
                    static $h = 2556008;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$snws.SNW.WebSocketStream; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772359784),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 2556008,
      "h": 25772359784,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25772359784),
//--TRIMMABLE-BOUNDARY-START(21477392488),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 2556008,
      "h": 21477392488,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(21477392488),
//--TRIMMABLE-BOUNDARY-START(17182425192),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 2556008,
      "h": 17182425192,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(17182425192)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592490600),
    {
      "t": 2162792,
      "n": "_messageType",
      "d": 2556008,
      "h": 8592490600,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592490600),
//--TRIMMABLE-BOUNDARY-START(4297523304),
    {
      "t": $.$typeNullable($.$$.S.TimeSpan).$h,
      "n": "_closeTimeout",
      "d": 2556008,
      "h": 4297523304,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297523304)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887457896),
    {
      "p": [
        {
          "n": "webSocket",
          "p": 1572968
        },
        {
          "n": "writeMessageType",
          "p": 2162792
        },
        {
          "n": "closeTimeout",
          "p": $.$typeNullable($.$$.S.TimeSpan).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2556008,
      "h": 12887457896,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887457896)
  ],
  "d": 2424936,
  "h": 2556008
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketStream+ReadWriteStream`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketStream${separator}ReadWriteStream`; }
                }, $cls, ($v) => $cls.$_ReadWriteStream = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2556008)
            
            //--TRIMMABLE-BOUNDARY-START(2621544)
            static $_WriteMessageStream;
            static get WriteMessageStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2621544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SNW.WebSocketStream;
                return $cls.$_WriteMessageStream ??= $asm.$ncls(`$snws.SNW.WebSocketStream.WriteMessageStream`, ($self) => class WriteMessageStream extends $.$snws.SNW.WebSocketStream
                {
                    //--TRIMMABLE-BOUNDARY-START(4297588840)
                    /*WebSocketMessageType*/ _messageType = 0;
                    //--TRIMMABLE-BOUNDARY-END(4297588840)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887523432)
                    /*bool */ get CanRead()
                    {
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887523432)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067392616)
                    /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30067392616);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._disposed)
                        {
                            return $.$$.STT.ValueTask.FromException($.$$.SRE$1.ExceptionDispatchInfo.SetCurrentStackTrace(new $.$$.S.ObjectDisposedException().$ctor$17($.$$.S.Object.GetType.call(this).FullName)));
                        }
                        if (!this.CanWrite)
                        {
                            return $.$$.STT.ValueTask.FromException($.$$.SRE$1.ExceptionDispatchInfo.SetCurrentStackTrace(new $.$$.S.NotSupportedException().$ctor$12($.$snws.S.SR.NotWriteableStream)));
                        }
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return $.$$.STT.ValueTask.FromCanceled(cancellationToken);
                        }
                        return this.WebSocket.SendAsync$1(buffer, this._messageType, false, cancellationToken);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067392616)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182490728)
                    /*ValueTask */ DisposeAsync()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17182490728);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!this._disposed)
                        {
                            this._disposed = true;
                            return this.WebSocket.SendAsync$1($.$$.S.ReadOnlyMemory$$($.$$.S.Byte).Empty, this._messageType, true, $.$$.ST$1.CancellationToken.None);
                        }
                        return new $.$$.STT.ValueTask();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182490728)
                    
                    //Begin primary constructor
                    /*WebSocket*/ webSocket = null;
                    /*WebSocketMessageType*/ writeMessageType = 0;
                    $ctor$4(/*WebSocket*/webSocket, /*WebSocketMessageType*/writeMessageType)
                    {
                        this.webSocket = webSocket;
                        this.writeMessageType = writeMessageType;
                        super.$ctor$3(this.webSocket);
                        //--TRIMMABLE-BOUNDARY-START(4297588840)
                        //depends on primary constructor parameter
                        this._messageType = this.writeMessageType;
                        //--TRIMMABLE-BOUNDARY-END(4297588840)
                        
                        return this
                    }
                    //End primary constructor
                    static $h = 2621544;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$snws.SNW.WebSocketStream; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887523432),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772425320,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 2621544,
      "h": 12887523432,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12887523432)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067392616),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 2621544,
      "h": 30067392616,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067392616),
//--TRIMMABLE-BOUNDARY-START(17182490728),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 2621544,
      "h": 17182490728,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17182490728)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297588840),
    {
      "t": 2162792,
      "n": "_messageType",
      "d": 2621544,
      "h": 4297588840,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297588840)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592556136),
    {
      "p": [
        {
          "n": "webSocket",
          "p": 1572968
        },
        {
          "n": "writeMessageType",
          "p": 2162792
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2621544,
      "h": 8592556136,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592556136)
  ],
  "d": 2424936,
  "h": 2621544
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketStream+WriteMessageStream`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketStream${separator}WriteMessageStream`; }
                }, $cls, ($v) => $cls.$_WriteMessageStream = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2621544)
            
            //--TRIMMABLE-BOUNDARY-START(2490472)
            static $_ReadMessageStream;
            static get ReadMessageStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2490472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SNW.WebSocketStream;
                return $cls.$_ReadMessageStream ??= $asm.$ncls(`$snws.SNW.WebSocketStream.ReadMessageStream`, ($self) => class ReadMessageStream extends $.$snws.SNW.WebSocketStream
                {
                    //--TRIMMABLE-BOUNDARY-START(4297457768)
                    /*bool*/ _eof = false;
                    //--TRIMMABLE-BOUNDARY-END(4297457768)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887392360)
                    /*bool */ get CanWrite()
                    {
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887392360)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067261544)
                    /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Int32), $.$$.S.Int32, async ($asnycContext) => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30067261544);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.S.ObjectDisposedException.ThrowIf(this._disposed, this);
                            if (!this.CanRead)
                            {
                                throw new $.$$.S.NotSupportedException().$ctor$12($.$snws.S.SR.NotReadableStream);
                            }
                            cancellationToken.ThrowIfCancellationRequested();
                            while(!this._eof && this.WebSocket.State < 4/*WebSocketState.CloseReceived*/)
                            {
                                let $t3, $r3;
                                /*ValueWebSocketReceiveResult*/ let result = ($t3 = this.WebSocket.ReceiveAsync$1(buffer, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                if (result.MessageType === 2)
                                {
                                    break;
                                }
                                if (result.EndOfMessage)
                                {
                                    this._eof = true;
                                }
                                if (result.Count > 0 || buffer.IsEmpty)
                                {
                                    return $.$$.N.AsyncResolver.Result($asnycContext, result.Count);
                                }
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext, 0);
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067261544)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182359656)
                    /*ValueTask */ DisposeAsync()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17182359656);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._disposed = true;
                        if (!this._eof && this.WebSocket.State < 4/*WebSocketState.CloseReceived*/)
                        {
                            this.WebSocket.Abort();
                        }
                        return new $.$$.STT.ValueTask();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182359656)
                    
                    //Begin primary constructor
                    /*WebSocket*/ webSocket = null;
                    $ctor$4(/*WebSocket*/webSocket)
                    {
                        this.webSocket = webSocket;
                        super.$ctor$3(this.webSocket);
                        return this
                    }
                    //End primary constructor
                    static $h = 2490472;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$snws.SNW.WebSocketStream; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887392360),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772294248,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 2490472,
      "h": 12887392360,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12887392360)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067261544),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 2490472,
      "h": 30067261544,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(30067261544),
//--TRIMMABLE-BOUNDARY-START(17182359656),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 2490472,
      "h": 17182359656,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17182359656)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297457768),
    {
      "t": 262145,
      "n": "_eof",
      "d": 2490472,
      "h": 4297457768,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297457768)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592425064),
    {
      "p": [
        {
          "n": "webSocket",
          "p": 1572968
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2490472,
      "h": 8592425064,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592425064)
  ],
  "d": 2424936,
  "h": 2490472
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketStream+ReadMessageStream`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketStream${separator}ReadMessageStream`; }
                }, $cls, ($v) => $cls.$_ReadMessageStream = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2490472)
            
            static $h = 2424936;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.Stream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(171801116776),
    {
      "p": 1572968,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128851443816,
        "f": 50331649
      },
      "n": "WebSocket",
      "d": 2424936,
      "h": 171801116776,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171801116776),
//--TRIMMABLE-BOUNDARY-START(25772228712),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901770856,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 2424936,
      "h": 25772228712,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25772228712),
//--TRIMMABLE-BOUNDARY-START(34362163304),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081640040,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 2424936,
      "h": 34362163304,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362163304),
//--TRIMMABLE-BOUNDARY-START(30067196008),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491705448,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 2424936,
      "h": 30067196008,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30067196008),
//--TRIMMABLE-BOUNDARY-START(133146411112),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671574632,
        "f": 50364417
      },
      "n": "Length",
      "d": 2424936,
      "h": 133146411112,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133146411112),
//--TRIMMABLE-BOUNDARY-START(137441378408),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261509224,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163211182184,
        "f": 83918849
      },
      "n": "Position",
      "d": 2424936,
      "h": 137441378408,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137441378408)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38657130600),
    {
      "r": 2424936,
      "p": [
        {
          "n": "webSocket",
          "p": 1572968
        },
        {
          "n": "writeMessageType",
          "p": 2162792
        },
        {
          "n": "ownsWebSocket",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "Create",
      "d": 2424936,
      "h": 38657130600,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38657130600),
//--TRIMMABLE-BOUNDARY-START(42952097896),
    {
      "r": 2424936,
      "p": [
        {
          "n": "webSocket",
          "p": 1572968
        },
        {
          "n": "writeMessageType",
          "p": 2162792
        },
        {
          "n": "closeTimeout",
          "p": 186646529
        }
      ],
      "n": "Create",
      "o": "@$1",
      "d": 2424936,
      "h": 42952097896,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42952097896),
//--TRIMMABLE-BOUNDARY-START(51542032488),
    {
      "r": 2424936,
      "p": [
        {
          "n": "webSocket",
          "p": 1572968
        },
        {
          "n": "writeMessageType",
          "p": 2162792
        }
      ],
      "n": "CreateWritableMessageStream",
      "d": 2424936,
      "h": 51542032488,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51542032488),
//--TRIMMABLE-BOUNDARY-START(47247065192),
    {
      "r": 2424936,
      "p": [
        {
          "n": "webSocket",
          "p": 1572968
        }
      ],
      "n": "CreateReadableMessageStream",
      "d": 2424936,
      "h": 47247065192,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47247065192),
//--TRIMMABLE-BOUNDARY-START(60131967080),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 2424936,
      "h": 60131967080,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(60131967080),
//--TRIMMABLE-BOUNDARY-START(73016868968),
    {
      "r": 65537,
      "n": "Flush",
      "d": 2424936,
      "h": 73016868968,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73016868968),
//--TRIMMABLE-BOUNDARY-START(77311836264),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 2424936,
      "h": 77311836264,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77311836264),
//--TRIMMABLE-BOUNDARY-START(146031313000),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "d": 2424936,
      "h": 146031313000,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146031313000),
//--TRIMMABLE-BOUNDARY-START(150326280296),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 2424936,
      "h": 150326280296,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150326280296),
//--TRIMMABLE-BOUNDARY-START(17182294120),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginRead",
      "d": 2424936,
      "h": 17182294120,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17182294120),
//--TRIMMABLE-BOUNDARY-START(64426934376),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndRead",
      "d": 2424936,
      "h": 64426934376,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64426934376),
//--TRIMMABLE-BOUNDARY-START(180391051368),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WriteAsync",
      "d": 2424936,
      "h": 180391051368,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180391051368),
//--TRIMMABLE-BOUNDARY-START(184686018664),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 2424936,
      "h": 184686018664,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184686018664),
//--TRIMMABLE-BOUNDARY-START(21477261416),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginWrite",
      "d": 2424936,
      "h": 21477261416,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21477261416),
//--TRIMMABLE-BOUNDARY-START(68721901672),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndWrite",
      "d": 2424936,
      "h": 68721901672,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68721901672),
//--TRIMMABLE-BOUNDARY-START(141736345704),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 2424936,
      "h": 141736345704,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(141736345704),
//--TRIMMABLE-BOUNDARY-START(176096084072),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 2424936,
      "h": 176096084072,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176096084072),
//--TRIMMABLE-BOUNDARY-START(154621247592),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 95289345
        }
      ],
      "n": "Seek",
      "d": 2424936,
      "h": 154621247592,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154621247592),
//--TRIMMABLE-BOUNDARY-START(167506149480),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 2424936,
      "h": 167506149480,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(167506149480)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55836999784),
    {
      "t": 655361,
      "n": "DefaultCloseTimeoutSeconds",
      "d": 2424936,
      "h": 55836999784,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55836999784),
//--TRIMMABLE-BOUNDARY-START(4297392232),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 2424936,
      "h": 4297392232,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297392232)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887326824),
    {
      "p": [
        {
          "n": "webSocket",
          "p": 1572968
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2424936,
      "h": 12887326824,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12887326824)
  ],
  "h": 2424936
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$snws.SNW.WebSocketStream.ReadWriteStream, $.$snws.SNW.WebSocketStream.WriteMessageStream, $.$snws.SNW.WebSocketStream.ReadMessageStream ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424936)
        
        

        //--TRIMMABLE-BOUNDARY-START(1966184)
        $asm.$str(`$snws.SNW.WebSocketError`, ($self) => class WebSocketError extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Success = 0;
            static InvalidMessageType = 1;
            static Faulted = 2;
            static NativeError = 3;
            static NotAWebSocket = 4;
            static UnsupportedVersion = 5;
            static UnsupportedProtocol = 6;
            static HeaderError = 7;
            static ConnectionClosedPrematurely = 8;
            static InvalidState = 9;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1966184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Success": 0n,
                    "InvalidMessageType": 1n,
                    "Faulted": 2n,
                    "NativeError": 3n,
                    "NotAWebSocket": 4n,
                    "UnsupportedVersion": 5n,
                    "UnsupportedProtocol": 6n,
                    "HeaderError": 7n,
                    "ConnectionClosedPrematurely": 8n,
                    "InvalidState": 9n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296933480)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296933480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296933480)
            
            //--TRIMMABLE-BOUNDARY-START(4296933480)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296933480)
            
            static $h = 1966184;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656671848),
    {
      "t": 1966184,
      "n": "Success",
      "d": 1966184,
      "h": 38656671848,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656671848),
//--TRIMMABLE-BOUNDARY-START(21476802664),
    {
      "t": 1966184,
      "n": "InvalidMessageType",
      "d": 1966184,
      "h": 21476802664,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476802664),
//--TRIMMABLE-BOUNDARY-START(12886868072),
    {
      "t": 1966184,
      "n": "Faulted",
      "d": 1966184,
      "h": 12886868072,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886868072),
//--TRIMMABLE-BOUNDARY-START(30066737256),
    {
      "t": 1966184,
      "n": "NativeError",
      "d": 1966184,
      "h": 30066737256,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066737256),
//--TRIMMABLE-BOUNDARY-START(34361704552),
    {
      "t": 1966184,
      "n": "NotAWebSocket",
      "d": 1966184,
      "h": 34361704552,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361704552),
//--TRIMMABLE-BOUNDARY-START(47246606440),
    {
      "t": 1966184,
      "n": "UnsupportedVersion",
      "d": 1966184,
      "h": 47246606440,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246606440),
//--TRIMMABLE-BOUNDARY-START(42951639144),
    {
      "t": 1966184,
      "n": "UnsupportedProtocol",
      "d": 1966184,
      "h": 42951639144,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951639144),
//--TRIMMABLE-BOUNDARY-START(17181835368),
    {
      "t": 1966184,
      "n": "HeaderError",
      "d": 1966184,
      "h": 17181835368,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181835368),
//--TRIMMABLE-BOUNDARY-START(8591900776),
    {
      "t": 1966184,
      "n": "ConnectionClosedPrematurely",
      "d": 1966184,
      "h": 8591900776,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591900776),
//--TRIMMABLE-BOUNDARY-START(25771769960),
    {
      "t": 1966184,
      "n": "InvalidState",
      "d": 1966184,
      "h": 25771769960,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771769960)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296933480),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1966184,
      "h": 4296933480,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296933480)
  ],
  "h": 1966184,
  "a": [
    {
      "t": 134479873,
      "c": 8724414465,
      "a": [
        {
          "v": "System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketError`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketError`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966184)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638504)
        $asm.$str(`$snws.SNW.WebSocketCloseStatus`, ($self) => class WebSocketCloseStatus extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static NormalClosure = 1000;
            static EndpointUnavailable = 1001;
            static ProtocolError = 1002;
            static InvalidMessageType = 1003;
            static Empty = 1005;
            static InvalidPayloadData = 1007;
            static PolicyViolation = 1008;
            static MessageTooBig = 1009;
            static MandatoryExtension = 1010;
            static InternalServerError = 1011;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1638504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "NormalClosure": 1000n,
                    "EndpointUnavailable": 1001n,
                    "ProtocolError": 1002n,
                    "InvalidMessageType": 1003n,
                    "Empty": 1005n,
                    "InvalidPayloadData": 1007n,
                    "PolicyViolation": 1008n,
                    "MessageTooBig": 1009n,
                    "MandatoryExtension": 1010n,
                    "InternalServerError": 1011n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296605800)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296605800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605800)
            
            //--TRIMMABLE-BOUNDARY-START(4296605800)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296605800)
            
            static $h = 1638504;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656344168),
    {
      "t": 1638504,
      "n": "NormalClosure",
      "d": 1638504,
      "h": 38656344168,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656344168),
//--TRIMMABLE-BOUNDARY-START(12886540392),
    {
      "t": 1638504,
      "n": "EndpointUnavailable",
      "d": 1638504,
      "h": 12886540392,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886540392),
//--TRIMMABLE-BOUNDARY-START(47246278760),
    {
      "t": 1638504,
      "n": "ProtocolError",
      "d": 1638504,
      "h": 47246278760,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246278760),
//--TRIMMABLE-BOUNDARY-START(21476474984),
    {
      "t": 1638504,
      "n": "InvalidMessageType",
      "d": 1638504,
      "h": 21476474984,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476474984),
//--TRIMMABLE-BOUNDARY-START(8591573096),
    {
      "t": 1638504,
      "n": "Empty",
      "d": 1638504,
      "h": 8591573096,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591573096),
//--TRIMMABLE-BOUNDARY-START(25771442280),
    {
      "t": 1638504,
      "n": "InvalidPayloadData",
      "d": 1638504,
      "h": 25771442280,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771442280),
//--TRIMMABLE-BOUNDARY-START(42951311464),
    {
      "t": 1638504,
      "n": "PolicyViolation",
      "d": 1638504,
      "h": 42951311464,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951311464),
//--TRIMMABLE-BOUNDARY-START(34361376872),
    {
      "t": 1638504,
      "n": "MessageTooBig",
      "d": 1638504,
      "h": 34361376872,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361376872),
//--TRIMMABLE-BOUNDARY-START(30066409576),
    {
      "t": 1638504,
      "n": "MandatoryExtension",
      "d": 1638504,
      "h": 30066409576,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066409576),
//--TRIMMABLE-BOUNDARY-START(17181507688),
    {
      "t": 1638504,
      "n": "InternalServerError",
      "d": 1638504,
      "h": 17181507688,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181507688)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605800),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638504,
      "h": 4296605800,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605800)
  ],
  "h": 1638504
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketCloseStatus`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketCloseStatus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638504)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441896)
        $asm.$str(`$snws.SNW.ManagedWebSocketStates`, ($self) => class ManagedWebSocketStates extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Open = 4;
            static CloseSent = 8;
            static CloseReceived = 16;
            static Closed = 32;
            static Aborted = 64;
            static All = 124;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1441896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Open": 4n,
                    "CloseSent": 8n,
                    "CloseReceived": 16n,
                    "Closed": 32n,
                    "Aborted": 64n,
                    "All": 124n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296409192)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296409192)
            
            //--TRIMMABLE-BOUNDARY-START(4296409192)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296409192)
            
            static $h = 1441896;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(30066212968),
    {
      "t": 1441896,
      "n": "None",
      "d": 1441896,
      "h": 30066212968,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066212968),
//--TRIMMABLE-BOUNDARY-START(34361180264),
    {
      "t": 1441896,
      "n": "Open",
      "d": 1441896,
      "h": 34361180264,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361180264),
//--TRIMMABLE-BOUNDARY-START(25771245672),
    {
      "t": 1441896,
      "n": "CloseSent",
      "d": 1441896,
      "h": 25771245672,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771245672),
//--TRIMMABLE-BOUNDARY-START(21476278376),
    {
      "t": 1441896,
      "n": "CloseReceived",
      "d": 1441896,
      "h": 21476278376,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476278376),
//--TRIMMABLE-BOUNDARY-START(17181311080),
    {
      "t": 1441896,
      "n": "Closed",
      "d": 1441896,
      "h": 17181311080,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181311080),
//--TRIMMABLE-BOUNDARY-START(8591376488),
    {
      "t": 1441896,
      "n": "Aborted",
      "d": 1441896,
      "h": 8591376488,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591376488),
//--TRIMMABLE-BOUNDARY-START(12886343784),
    {
      "t": 1441896,
      "n": "All",
      "d": 1441896,
      "h": 12886343784,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886343784)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409192),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1441896,
      "h": 4296409192,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296409192)
  ],
  "h": 1441896,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.ManagedWebSocketStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}ManagedWebSocketStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441896)
        
        

        //--TRIMMABLE-BOUNDARY-START(2162792)
        $asm.$str(`$snws.SNW.WebSocketMessageType`, ($self) => class WebSocketMessageType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Text = 0;
            static Binary = 1;
            static Close = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2162792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Text": 0n,
                    "Binary": 1n,
                    "Close": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297130088)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297130088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297130088)
            
            //--TRIMMABLE-BOUNDARY-START(4297130088)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297130088)
            
            static $h = 2162792;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182031976),
    {
      "t": 2162792,
      "n": "Text",
      "d": 2162792,
      "h": 17182031976,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182031976),
//--TRIMMABLE-BOUNDARY-START(8592097384),
    {
      "t": 2162792,
      "n": "Binary",
      "d": 2162792,
      "h": 8592097384,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592097384),
//--TRIMMABLE-BOUNDARY-START(12887064680),
    {
      "t": 2162792,
      "n": "Close",
      "d": 2162792,
      "h": 12887064680,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887064680)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297130088),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2162792,
      "h": 4297130088,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297130088)
  ],
  "h": 2162792
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketMessageType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketMessageType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162792)
        
        

        //--TRIMMABLE-BOUNDARY-START(2097256)
        $asm.$str(`$snws.SNW.WebSocketMessageFlags`, ($self) => class WebSocketMessageFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static EndOfMessage = 1;
            static DisableCompression = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2097256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "EndOfMessage": 1n,
                    "DisableCompression": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297064552)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297064552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297064552)
            
            //--TRIMMABLE-BOUNDARY-START(4297064552)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297064552)
            
            static $h = 2097256;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181966440),
    {
      "t": 2097256,
      "n": "None",
      "d": 2097256,
      "h": 17181966440,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181966440),
//--TRIMMABLE-BOUNDARY-START(12886999144),
    {
      "t": 2097256,
      "n": "EndOfMessage",
      "d": 2097256,
      "h": 12886999144,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886999144),
//--TRIMMABLE-BOUNDARY-START(8592031848),
    {
      "t": 2097256,
      "n": "DisableCompression",
      "d": 2097256,
      "h": 8592031848,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592031848)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297064552),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2097256,
      "h": 4297064552,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297064552)
  ],
  "h": 2097256,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketMessageFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketMessageFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097256)
        
        

        //--TRIMMABLE-BOUNDARY-START(2293864)
        $asm.$str(`$snws.SNW.WebSocketState`, ($self) => class WebSocketState extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Connecting = 1;
            static Open = 2;
            static CloseSent = 3;
            static CloseReceived = 4;
            static Closed = 5;
            static Aborted = 6;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2293864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Connecting": 1n,
                    "Open": 2n,
                    "CloseSent": 3n,
                    "CloseReceived": 4n,
                    "Closed": 5n,
                    "Aborted": 6n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297261160)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297261160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297261160)
            
            //--TRIMMABLE-BOUNDARY-START(4297261160)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297261160)
            
            static $h = 2293864;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(30067064936),
    {
      "t": 2293864,
      "n": "None",
      "d": 2293864,
      "h": 30067064936,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067064936),
//--TRIMMABLE-BOUNDARY-START(25772097640),
    {
      "t": 2293864,
      "n": "Connecting",
      "d": 2293864,
      "h": 25772097640,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772097640),
//--TRIMMABLE-BOUNDARY-START(34362032232),
    {
      "t": 2293864,
      "n": "Open",
      "d": 2293864,
      "h": 34362032232,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34362032232),
//--TRIMMABLE-BOUNDARY-START(21477130344),
    {
      "t": 2293864,
      "n": "CloseSent",
      "d": 2293864,
      "h": 21477130344,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477130344),
//--TRIMMABLE-BOUNDARY-START(17182163048),
    {
      "t": 2293864,
      "n": "CloseReceived",
      "d": 2293864,
      "h": 17182163048,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182163048),
//--TRIMMABLE-BOUNDARY-START(12887195752),
    {
      "t": 2293864,
      "n": "Closed",
      "d": 2293864,
      "h": 12887195752,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887195752),
//--TRIMMABLE-BOUNDARY-START(8592228456),
    {
      "t": 2293864,
      "n": "Aborted",
      "d": 2293864,
      "h": 8592228456,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592228456)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297261160),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2293864,
      "h": 4297261160,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297261160)
  ],
  "h": 2293864
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293864)
        
        

        //--TRIMMABLE-BOUNDARY-START(852072)
        $asm.$cls(`$snws.SN.NetEventSource`, ($self) => class NetEventSource extends $.$$.SDT.EventSource
        {
            //--TRIMMABLE-BOUNDARY-START(133144838248)
            /*int*/ static KeepAliveSentId = 5;
            //--TRIMMABLE-BOUNDARY-END(133144838248)
            
            //--TRIMMABLE-BOUNDARY-START(120259936360)
            /*int*/ static KeepAliveAckedId = 6;
            //--TRIMMABLE-BOUNDARY-END(120259936360)
            
            //--TRIMMABLE-BOUNDARY-START(292058628200)
            /*int*/ static WsTraceId = 7;
            //--TRIMMABLE-BOUNDARY-END(292058628200)
            
            //--TRIMMABLE-BOUNDARY-START(47245492328)
            /*int*/ static CloseStartId = 8;
            //--TRIMMABLE-BOUNDARY-END(47245492328)
            
            //--TRIMMABLE-BOUNDARY-START(55835426920)
            /*int*/ static CloseStopId = 9;
            //--TRIMMABLE-BOUNDARY-END(55835426920)
            
            //--TRIMMABLE-BOUNDARY-START(210454249576)
            /*int*/ static ReceiveStartId = 10;
            //--TRIMMABLE-BOUNDARY-END(210454249576)
            
            //--TRIMMABLE-BOUNDARY-START(219044184168)
            /*int*/ static ReceiveStopId = 11;
            //--TRIMMABLE-BOUNDARY-END(219044184168)
            
            //--TRIMMABLE-BOUNDARY-START(236224053352)
            /*int*/ static SendStartId = 12;
            //--TRIMMABLE-BOUNDARY-END(236224053352)
            
            //--TRIMMABLE-BOUNDARY-START(244813987944)
            /*int*/ static SendStopId = 13;
            //--TRIMMABLE-BOUNDARY-END(244813987944)
            
            //--TRIMMABLE-BOUNDARY-START(154619674728)
            /*int*/ static MutexEnterId = 14;
            //--TRIMMABLE-BOUNDARY-END(154619674728)
            
            //--TRIMMABLE-BOUNDARY-START(167504576616)
            /*int*/ static MutexExitId = 15;
            //--TRIMMABLE-BOUNDARY-END(167504576616)
            
            //--TRIMMABLE-BOUNDARY-START(184684445800)
            /*string*/ static Ping = null;
            //--TRIMMABLE-BOUNDARY-END(184684445800)
            
            //--TRIMMABLE-BOUNDARY-START(188979413096)
            /*string*/ static Pong = null;
            //--TRIMMABLE-BOUNDARY-END(188979413096)
            
            //--TRIMMABLE-BOUNDARY-START(128849870952)
            /*void */ KeepAliveSent(/*string*/ objName, /*string*/ opcode, /*long*/ payload)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128849870952);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.WriteEvent$20(5/*KeepAliveSentId*/, objName, opcode, payload);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849870952)
            
            //--TRIMMABLE-BOUNDARY-START(115964969064)
            /*void */ KeepAliveAcked(/*string*/ objName, /*long*/ payload)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964969064);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.WriteEvent$14(6/*KeepAliveAckedId*/, objName, payload);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964969064)
            
            //--TRIMMABLE-BOUNDARY-START(124554903656)
            static /*void */ KeepAlivePingSent(/*object?*/ obj, /*long*/ payload)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554903656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$snws.SN.NetEventSource.Log.IsEnabled(), "Log.IsEnabled()");
                $.$snws.SN.NetEventSource.Log.KeepAliveSent($.$snws.SN.NetEventSource.IdOf(obj), "Ping"/*Ping*/, payload);
            }
            //--TRIMMABLE-BOUNDARY-END(124554903656)
            
            //--TRIMMABLE-BOUNDARY-START(266288824424)
            static /*void */ UnsolicitedPongSent(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288824424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$snws.SN.NetEventSource.Log.IsEnabled(), "Log.IsEnabled()");
                $.$snws.SN.NetEventSource.Log.KeepAliveSent($.$snws.SN.NetEventSource.IdOf(obj), "Pong"/*Pong*/, 0n);
            }
            //--TRIMMABLE-BOUNDARY-END(266288824424)
            
            //--TRIMMABLE-BOUNDARY-START(193274380392)
            static /*void */ PongResponseReceived(/*object?*/ obj, /*long*/ payload)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274380392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$snws.SN.NetEventSource.Log.IsEnabled(), "Log.IsEnabled()");
                $.$snws.SN.NetEventSource.Log.KeepAliveAcked($.$snws.SN.NetEventSource.IdOf(obj), payload);
            }
            //--TRIMMABLE-BOUNDARY-END(193274380392)
            
            //--TRIMMABLE-BOUNDARY-START(287763660904)
            /*void */ WsTrace(/*string*/ objName, /*string*/ memberName, /*string*/ message)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(287763660904);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.WriteEvent$15(7/*WsTraceId*/, objName, memberName, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(287763660904)
            
            //--TRIMMABLE-BOUNDARY-START(257698889832)
            static /*void */ TraceErrorMsg(/*object?*/ obj, /*Exception*/ exception, /*string?*/ memberName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(257698889832);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snws.SN.NetEventSource.Trace(obj, `${$.$strNN(exception.GetType$1().Name)}: ${$.$strNN(exception.Message)}`, memberName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257698889832)
            
            //--TRIMMABLE-BOUNDARY-START(261993857128)
            static /*void */ TraceException(/*object?*/ obj, /*Exception*/ exception, /*string?*/ memberName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(261993857128);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snws.SN.NetEventSource.Trace(obj, exception.ToString(), memberName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(261993857128)
            
            //--TRIMMABLE-BOUNDARY-START(253403922536)
            static /*void */ Trace(/*object?*/ obj, /*string?*/ message, /*string?*/ memberName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403922536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$snws.SN.NetEventSource.Log.IsEnabled(), "Log.IsEnabled()");
                $.$snws.SN.NetEventSource.Log.WsTrace($.$snws.SN.NetEventSource.IdOf(obj), memberName ?? "(?)"/*MissingMember*/, message ?? memberName ?? $.$$.S.String.Empty);
            }
            //--TRIMMABLE-BOUNDARY-END(253403922536)
            
            //--TRIMMABLE-BOUNDARY-START(42950525032)
            /*void */ CloseStart(/*string*/ objName, /*string*/ memberName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950525032);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.WriteEvent$16(8/*CloseStartId*/, objName, memberName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950525032)
            
            //--TRIMMABLE-BOUNDARY-START(51540459624)
            /*void */ CloseStop(/*string*/ objName, /*string*/ memberName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540459624);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.WriteEvent$16(9/*CloseStopId*/, objName, memberName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540459624)
            
            //--TRIMMABLE-BOUNDARY-START(38655557736)
            static /*void */ CloseAsyncPrivateStarted(/*object?*/ obj, /*string?*/ memberName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655557736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$snws.SN.NetEventSource.Log.IsEnabled(), "Log.IsEnabled()");
                $.$snws.SN.NetEventSource.Log.CloseStart($.$snws.SN.NetEventSource.IdOf(obj), memberName ?? "(?)"/*MissingMember*/);
            }
            //--TRIMMABLE-BOUNDARY-END(38655557736)
            
            //--TRIMMABLE-BOUNDARY-START(34360590440)
            static /*void */ CloseAsyncPrivateCompleted(/*object?*/ obj, /*string?*/ memberName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360590440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$snws.SN.NetEventSource.Log.IsEnabled(), "Log.IsEnabled()");
                $.$snws.SN.NetEventSource.Log.CloseStop($.$snws.SN.NetEventSource.IdOf(obj), memberName ?? "(?)"/*MissingMember*/);
            }
            //--TRIMMABLE-BOUNDARY-END(34360590440)
            
            //--TRIMMABLE-BOUNDARY-START(206159282280)
            /*void */ ReceiveStart(/*string*/ objName, /*string*/ memberName, /*int*/ bufferLength)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206159282280);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.WriteEvent$19(10/*ReceiveStartId*/, objName, memberName, bufferLength);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206159282280)
            
            //--TRIMMABLE-BOUNDARY-START(214749216872)
            /*void */ ReceiveStop(/*string*/ objName, /*string*/ memberName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214749216872);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.WriteEvent$16(11/*ReceiveStopId*/, objName, memberName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214749216872)
            
            //--TRIMMABLE-BOUNDARY-START(201864314984)
            static /*void */ ReceiveAsyncPrivateStarted(/*object?*/ obj, /*int*/ bufferLength, /*string?*/ memberName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864314984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$snws.SN.NetEventSource.Log.IsEnabled(), "Log.IsEnabled()");
                $.$snws.SN.NetEventSource.Log.ReceiveStart($.$snws.SN.NetEventSource.IdOf(obj), memberName ?? "(?)"/*MissingMember*/, bufferLength);
            }
            //--TRIMMABLE-BOUNDARY-END(201864314984)
            
            //--TRIMMABLE-BOUNDARY-START(197569347688)
            static /*void */ ReceiveAsyncPrivateCompleted(/*object?*/ obj, /*string?*/ memberName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569347688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$snws.SN.NetEventSource.Log.IsEnabled(), "Log.IsEnabled()");
                $.$snws.SN.NetEventSource.Log.ReceiveStop($.$snws.SN.NetEventSource.IdOf(obj), memberName ?? "(?)"/*MissingMember*/);
            }
            //--TRIMMABLE-BOUNDARY-END(197569347688)
            
            //--TRIMMABLE-BOUNDARY-START(231929086056)
            /*void */ SendStart(/*string*/ objName, /*string*/ memberName, /*string*/ opcode, /*int*/ bufferLength)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(231929086056);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.WriteEvent$21(12/*SendStartId*/, objName, memberName, opcode, bufferLength);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231929086056)
            
            //--TRIMMABLE-BOUNDARY-START(240519020648)
            /*void */ SendStop(/*string*/ objName, /*string*/ memberName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(240519020648);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.WriteEvent$16(13/*SendStopId*/, objName, memberName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(240519020648)
            
            //--TRIMMABLE-BOUNDARY-START(227634118760)
            static /*void */ SendFrameAsyncStarted(/*object?*/ obj, /*string*/ opcode, /*int*/ bufferLength, /*string?*/ memberName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634118760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$snws.SN.NetEventSource.Log.IsEnabled(), "Log.IsEnabled()");
                $.$snws.SN.NetEventSource.Log.SendStart($.$snws.SN.NetEventSource.IdOf(obj), memberName ?? "(?)"/*MissingMember*/, opcode, bufferLength);
            }
            //--TRIMMABLE-BOUNDARY-END(227634118760)
            
            //--TRIMMABLE-BOUNDARY-START(223339151464)
            static /*void */ SendFrameAsyncCompleted(/*object?*/ obj, /*string?*/ memberName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339151464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$snws.SN.NetEventSource.Log.IsEnabled(), "Log.IsEnabled()");
                $.$snws.SN.NetEventSource.Log.SendStop($.$snws.SN.NetEventSource.IdOf(obj), memberName ?? "(?)"/*MissingMember*/);
            }
            //--TRIMMABLE-BOUNDARY-END(223339151464)
            
            //--TRIMMABLE-BOUNDARY-START(146029740136)
            /*void */ MutexEnter(/*string*/ objName, /*string*/ memberName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146029740136);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.WriteEvent$16(14/*MutexEnterId*/, objName, memberName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029740136)
            
            //--TRIMMABLE-BOUNDARY-START(158914642024)
            /*void */ MutexExit(/*string*/ objName, /*string*/ memberName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914642024);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.WriteEvent$16(15/*MutexExitId*/, objName, memberName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914642024)
            
            //--TRIMMABLE-BOUNDARY-START(150324707432)
            static /*void */ MutexEntered(/*object?*/ obj, /*string?*/ memberName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324707432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$snws.SN.NetEventSource.Log.IsEnabled(), "Log.IsEnabled()");
                $.$snws.SN.NetEventSource.Log.MutexEnter($.$snws.SN.NetEventSource.IdOf(obj), memberName ?? "(?)"/*MissingMember*/);
            }
            //--TRIMMABLE-BOUNDARY-END(150324707432)
            
            //--TRIMMABLE-BOUNDARY-START(163209609320)
            static /*void */ MutexExited(/*object?*/ obj, /*string?*/ memberName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209609320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$snws.SN.NetEventSource.Log.IsEnabled(), "Log.IsEnabled()");
                $.$snws.SN.NetEventSource.Log.MutexExit($.$snws.SN.NetEventSource.IdOf(obj), memberName ?? "(?)"/*MissingMember*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163209609320)
            
            //--TRIMMABLE-BOUNDARY-START(274878759016)
            /*void */ WriteEvent$20(/*int*/ eventId, /*string*/ arg1, /*string*/ arg2, /*long*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878759016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*fixed*/ 
                {
                    /*char**/ let arg1Ptr = $.$$.S.String.GetPinnableReference.call(arg1);
                    /*fixed*/ 
                    {
                        /*char**/ let arg2Ptr = $.$$.S.String.GetPinnableReference.call(arg2);
                        /*int*/ let NumEventDatas = 3;
                        /*EventData**/ let descrs = $.$$.SRC.RuntimeHelpers.StackAllocPointer($.$$.SDT.EventSource.EventData, NumEventDatas, null);
                        descrs.SetAt((() =>
                        {
                            //new $.$$.SDT.EventSource.EventData()
                            const $t1 = $.$$.SDT.EventSource.EventData;
                            const $i1 = new $t1();
                            $i1.$ctor$2();
                            $i1.DataPointer = $.$$.$interop.$ptr2Addr((arg1Ptr));
                            $i1.Size = (((((arg1.length + 1) | 0)) * 2) | 0);
                            return $i1;
                        })(), 0);
                        descrs.SetAt((() =>
                        {
                            //new $.$$.SDT.EventSource.EventData()
                            const $t2 = $.$$.SDT.EventSource.EventData;
                            const $i2 = new $t2();
                            $i2.$ctor$2();
                            $i2.DataPointer = $.$$.$interop.$ptr2Addr((arg2Ptr));
                            $i2.Size = (((((arg2.length + 1) | 0)) * 2) | 0);
                            return $i2;
                        })(), 1);
                        descrs.SetAt((() =>
                        {
                            //new $.$$.SDT.EventSource.EventData()
                            const $t3 = $.$$.SDT.EventSource.EventData;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            $i3.DataPointer = $.$$.$interop.castObject2Address($.$box(arg3, $.$$.S.Int64), 0, false, true, 1);
                            $i3.Size = 8;
                            return $i3;
                        })(), 2);
                        this.WriteEventCore(eventId, NumEventDatas, descrs);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(274878759016)
            
            //--TRIMMABLE-BOUNDARY-START(279173726312)
            /*void */ WriteEvent$21(/*int*/ eventId, /*string*/ arg1, /*string*/ arg2, /*string*/ arg3, /*int*/ arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173726312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*fixed*/ 
                {
                    /*char**/ let arg1Ptr = $.$$.S.String.GetPinnableReference.call(arg1);
                    /*fixed*/ 
                    {
                        /*char**/ let arg2Ptr = $.$$.S.String.GetPinnableReference.call(arg2);
                        /*fixed*/ 
                        {
                            /*char**/ let arg3Ptr = $.$$.S.String.GetPinnableReference.call(arg3);
                            /*int*/ let NumEventDatas = 4;
                            /*EventData**/ let descrs = $.$$.SRC.RuntimeHelpers.StackAllocPointer($.$$.SDT.EventSource.EventData, NumEventDatas, null);
                            descrs.SetAt((() =>
                            {
                                //new $.$$.SDT.EventSource.EventData()
                                const $t4 = $.$$.SDT.EventSource.EventData;
                                const $i4 = new $t4();
                                $i4.$ctor$2();
                                $i4.DataPointer = $.$$.$interop.$ptr2Addr((arg1Ptr));
                                $i4.Size = (((((arg1.length + 1) | 0)) * 2) | 0);
                                return $i4;
                            })(), 0);
                            descrs.SetAt((() =>
                            {
                                //new $.$$.SDT.EventSource.EventData()
                                const $t5 = $.$$.SDT.EventSource.EventData;
                                const $i5 = new $t5();
                                $i5.$ctor$2();
                                $i5.DataPointer = $.$$.$interop.$ptr2Addr((arg2Ptr));
                                $i5.Size = (((((arg2.length + 1) | 0)) * 2) | 0);
                                return $i5;
                            })(), 1);
                            descrs.SetAt((() =>
                            {
                                //new $.$$.SDT.EventSource.EventData()
                                const $t6 = $.$$.SDT.EventSource.EventData;
                                const $i6 = new $t6();
                                $i6.$ctor$2();
                                $i6.DataPointer = $.$$.$interop.$ptr2Addr((arg3Ptr));
                                $i6.Size = (((((arg3.length + 1) | 0)) * 2) | 0);
                                return $i6;
                            })(), 2);
                            descrs.SetAt((() =>
                            {
                                //new $.$$.SDT.EventSource.EventData()
                                const $t7 = $.$$.SDT.EventSource.EventData;
                                const $i7 = new $t7();
                                $i7.$ctor$2();
                                $i7.DataPointer = $.$$.$interop.$ptr2Addr(($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Int32, () => arg4, ($v) => arg4 = $v, null, true)));
                                $i7.Size = 4;
                                return $i7;
                            })(), 3);
                            this.WriteEventCore(eventId, NumEventDatas, descrs);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(279173726312)
            
            //--TRIMMABLE-BOUNDARY-START(77310263400)
            /*string*/ static EventSourceSuppressMessage$1 = null;
            //--TRIMMABLE-BOUNDARY-END(77310263400)
            
            //--TRIMMABLE-BOUNDARY-START(137439805544)
            /*NetEventSource*/ static Log = null;
            //--TRIMMABLE-BOUNDARY-END(137439805544)
            
            //--TRIMMABLE-BOUNDARY-START(917608)
            static $_Keywords;
            static get Keywords()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(917608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snws.SN.NetEventSource;
                return $cls.$_Keywords ??= $asm.$ncls(`$snws.SN.NetEventSource.Keywords`, ($self) => class Keywords
                {
                    //--TRIMMABLE-BOUNDARY-START(8590852200)
                    /*EventKeywords*/ static Default = 1n;
                    //--TRIMMABLE-BOUNDARY-END(8590852200)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295884904)
                    /*EventKeywords*/ static Debug = 2n;
                    //--TRIMMABLE-BOUNDARY-END(4295884904)
                    
                    static $h = 917608;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852200),
    {
      "t": 74383361,
      "n": "Default",
      "d": 917608,
      "h": 8590852200,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590852200),
//--TRIMMABLE-BOUNDARY-START(4295884904),
    {
      "t": 74383361,
      "n": "Debug",
      "d": 917608,
      "h": 4295884904,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295884904)
  ],
  "d": 852072,
  "h": 917608
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Net.NetEventSource+Keywords`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}NetEventSource${separator}Keywords`; }
                }, $cls, ($v) => $cls.$_Keywords = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917608)
            
            //--TRIMMABLE-BOUNDARY-START(141734772840)
            /*string*/ static MissingMember = null;
            //--TRIMMABLE-BOUNDARY-END(141734772840)
            
            //--TRIMMABLE-BOUNDARY-START(180389478504)
            /*string*/ static NullInstance = null;
            //--TRIMMABLE-BOUNDARY-END(180389478504)
            
            //--TRIMMABLE-BOUNDARY-START(249108955240)
            /*string*/ static StaticMethodObject = null;
            //--TRIMMABLE-BOUNDARY-END(249108955240)
            
            //--TRIMMABLE-BOUNDARY-START(176094511208)
            /*string*/ static NoParameters = null;
            //--TRIMMABLE-BOUNDARY-END(176094511208)
            
            //--TRIMMABLE-BOUNDARY-START(111670001768)
            /*int*/ static InfoEventId = 1;
            //--TRIMMABLE-BOUNDARY-END(111670001768)
            
            //--TRIMMABLE-BOUNDARY-START(68720328808)
            /*int*/ static ErrorEventId = 2;
            //--TRIMMABLE-BOUNDARY-END(68720328808)
            
            //--TRIMMABLE-BOUNDARY-START(171799543912)
            /*int*/ static NextAvailableEventId = 5;
            //--TRIMMABLE-BOUNDARY-END(171799543912)
            
            //--TRIMMABLE-BOUNDARY-START(98785099880)
            static /*void */ Info(/*object?*/ thisOrContextObject, /*FormattableString?*/ formattableString, /*string?*/ memberName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98785099880);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snws.SN.NetEventSource.Log.Info$2($.$snws.SN.NetEventSource.IdOf(thisOrContextObject), memberName, formattableString !== null ? $.$snws.SN.NetEventSource.Format(formattableString) : ""/*NoParameters*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785099880)
            
            //--TRIMMABLE-BOUNDARY-START(103080067176)
            static /*void */ Info$1(/*object?*/ thisOrContextObject, /*object?*/ message, /*string?*/ memberName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103080067176);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snws.SN.NetEventSource.Log.Info$2($.$snws.SN.NetEventSource.IdOf(thisOrContextObject), memberName, $.$snws.SN.NetEventSource.Format$1(message));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080067176)
            
            //--TRIMMABLE-BOUNDARY-START(107375034472)
            /*void */ Info$2(/*string*/ thisOrContextObject, /*string?*/ memberName, /*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375034472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this.IsEnabled(), "IsEnabled()");
                this.WriteEvent$15(1/*InfoEventId*/, thisOrContextObject, memberName ?? "(?)"/*MissingMember*/, message);
            }
            //--TRIMMABLE-BOUNDARY-END(107375034472)
            
            //--TRIMMABLE-BOUNDARY-START(60130394216)
            static /*void */ Error(/*object?*/ thisOrContextObject, /*FormattableString*/ formattableString, /*string?*/ memberName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130394216);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snws.SN.NetEventSource.Log.ErrorMessage($.$snws.SN.NetEventSource.IdOf(thisOrContextObject), memberName, $.$snws.SN.NetEventSource.Format(formattableString));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130394216)
            
            //--TRIMMABLE-BOUNDARY-START(64425361512)
            static /*void */ Error$1(/*object?*/ thisOrContextObject, /*object*/ message, /*string?*/ memberName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425361512);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snws.SN.NetEventSource.Log.ErrorMessage($.$snws.SN.NetEventSource.IdOf(thisOrContextObject), memberName, $.$snws.SN.NetEventSource.Format$1(message));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425361512)
            
            //--TRIMMABLE-BOUNDARY-START(73015296104)
            /*void */ ErrorMessage(/*string*/ thisOrContextObject, /*string?*/ memberName, /*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015296104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this.IsEnabled(), "IsEnabled()");
                this.WriteEvent$15(2/*ErrorEventId*/, thisOrContextObject, memberName ?? "(?)"/*MissingMember*/, message);
            }
            //--TRIMMABLE-BOUNDARY-END(73015296104)
            
            //--TRIMMABLE-BOUNDARY-START(94490132584)
            static /*string */ IdOf(/*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490132584);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return value !== null ? $.$strNN($.$$.S.Object.GetType.call(value).Name) + "#" + $.$snws.SN.NetEventSource.GetHashCode$1(value) : "(null)"/*NullInstance*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490132584)
            
            //--TRIMMABLE-BOUNDARY-START(90195165288)
            static /*int */ GetHashCode$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195165288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca1__;
                return ((__ca1__ = value) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.GetHashCode) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(90195165288)
            
            //--TRIMMABLE-BOUNDARY-START(85900197992)
            static /*string? */ Format$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900197992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return "(null)"/*NullInstance*/;
                }
                /*string?*/ let result = null;
                //$.$snws.SN.NetEventSource.AdditionalCustomizedToString(value, $.$ref(() => result, ($v) => result = $v, $.$$.S.String));
                if (!(result === null))
                {
                    return result;
                }
                let arr;
                if ($.$is(value, $.$$.S.Array, { set $v($v){ arr = $v; } }))
                {
                    return `${$.$strNN($.$$.S.Object.GetType.call(arr).GetElementType().ToString())}[${$.$strNN(($.$cast(value, $.$$.S.Array)).length)}]`;
                }
                let c;
                if ($.$is(value, $.$$.SC$1.ICollection, { set $v($v){ c = $v; } }))
                {
                    return `${$.$strNN($.$$.S.Object.GetType.call(c).Name)}(${$.$strNN(c.SC$1$ICollection$Count)})`;
                }
                let handle;
                if ($.$is(value, $.$$.SRI.SafeHandle, { set $v($v){ handle = $v; } }))
                {
                    return (() =>
                    {
                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(3, 3);
                        $handler.AppendFormatted($.$box($.$$.S.Object.GetType.call(handle).Name, $.$$.S.String), null, null);
                        $handler.AppendLiteral(":");
                        $handler.AppendFormatted($.$box($.$dsp(handle, $.$$.S.Object, ($t) => $t.GetHashCode), $.$$.S.Int32), null, null);
                        $handler.AppendLiteral("(0x");
                        $handler.AppendFormatted($.$box(handle.DangerousGetHandle(), $.$$.S.IntPtr), null, "X");
                        $handler.AppendLiteral(")");
                        return $handler.ToStringAndClear                ();
                    })();
                }
                if ($.$is(value, $.$$.S.IntPtr))
                {
                    return (() =>
                    {
                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                        $handler.AppendLiteral("0x");
                        $handler.AppendFormatted(value, null, "X");
                        return $handler.ToStringAndClear                ();
                    })();
                }
                /*string?*/ let toString = $.$dspc(value, $.$$.S.Object, ($t) => $t.ToString);
                if (toString === null || toString === $.$$.S.Object.GetType.call(value).FullName)
                {
                    return $.$snws.SN.NetEventSource.IdOf(value);
                }
                return $.$dspc(value, $.$$.S.Object, ($t) => $t.ToString);
            }
            //--TRIMMABLE-BOUNDARY-END(85900197992)
            
            //--TRIMMABLE-BOUNDARY-START(81605230696)
            static /*string */ Format(/*FormattableString*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605230696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var formattedArgs;
                let $switch9 = s.ArgumentCount;
                switch($switch9)
                {
                    case 0:
                    return s.Format;
                    case 1:
                    return $.$$.S.String.Format$9(s.Format, $.$snws.SN.NetEventSource.Format$1(s.GetArgument(0)));
                    case 2:
                    return $.$$.S.String.Format$8(s.Format, $.$snws.SN.NetEventSource.Format$1(s.GetArgument(0)), $.$snws.SN.NetEventSource.Format$1(s.GetArgument(1)));
                    case 3:
                    return $.$$.S.String.Format$7(s.Format, $.$snws.SN.NetEventSource.Format$1(s.GetArgument(0)), $.$snws.SN.NetEventSource.Format$1(s.GetArgument(1)), $.$snws.SN.NetEventSource.Format$1(s.GetArgument(2)));
                    default:
                    formattedArgs = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [s.ArgumentCount], null);
                    for(/*int*/ let i = 0; i < formattedArgs.length; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(formattedArgs, $.$snws.SN.NetEventSource.Format$1(s.GetArgument(i)), i);
                    }
                    return $.$$.S.String.Format$11(s.Format, $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1(formattedArgs));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605230696)
            
            //--TRIMMABLE-BOUNDARY-START(270583791720)
            /*void */ WriteEvent$19(/*int*/ eventId, /*string?*/ arg1, /*string?*/ arg2, /*int*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583791720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                arg1 ??= "";
                arg2 ??= "";
                /*fixed*/ 
                {
                    /*char**/ let arg1Ptr = $.$$.S.String.GetPinnableReference.call(arg1);
                    /*fixed*/ 
                    {
                        /*char**/ let arg2Ptr = $.$$.S.String.GetPinnableReference.call(arg2);
                        /*int*/ let NumEventDatas = 3;
                        /*EventData**/ let descrs = $.$$.SRC.RuntimeHelpers.StackAllocPointer($.$$.SDT.EventSource.EventData, NumEventDatas, null);
                        descrs.SetAt((() =>
                        {
                            //new $.$$.SDT.EventSource.EventData()
                            const $t10 = $.$$.SDT.EventSource.EventData;
                            const $i10 = new $t10();
                            $i10.$ctor$2();
                            $i10.DataPointer = $.$$.$interop.$ptr2Addr((arg1Ptr));
                            $i10.Size = (((((arg1.length + 1) | 0)) * 2) | 0);
                            return $i10;
                        })(), 0);
                        descrs.SetAt((() =>
                        {
                            //new $.$$.SDT.EventSource.EventData()
                            const $t11 = $.$$.SDT.EventSource.EventData;
                            const $i11 = new $t11();
                            $i11.$ctor$2();
                            $i11.DataPointer = $.$$.$interop.$ptr2Addr((arg2Ptr));
                            $i11.Size = (((((arg2.length + 1) | 0)) * 2) | 0);
                            return $i11;
                        })(), 1);
                        descrs.SetAt((() =>
                        {
                            //new $.$$.SDT.EventSource.EventData()
                            const $t12 = $.$$.SDT.EventSource.EventData;
                            const $i12 = new $t12();
                            $i12.$ctor$2();
                            $i12.DataPointer = $.$$.$interop.$ptr2Addr(($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Int32, () => arg3, ($v) => arg3 = $v, null, true)));
                            $i12.Size = 4;
                            return $i12;
                        })(), 2);
                        this.WriteEventCore(eventId, NumEventDatas, descrs);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(270583791720)
            
            //--TRIMMABLE-BOUNDARY-START(30065623144)
            /*int*/ static AssociateEventId = 3;
            //--TRIMMABLE-BOUNDARY-END(30065623144)
            
            //--TRIMMABLE-BOUNDARY-START(21475688552)
            static /*void */ Associate$1(/*object*/ first, /*object*/ second, /*string?*/ memberName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475688552);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snws.SN.NetEventSource.Associate(first, first, second, memberName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475688552)
            
            //--TRIMMABLE-BOUNDARY-START(17180721256)
            static /*void */ Associate(/*object?*/ thisOrContextObject, /*object*/ first, /*object*/ second, /*string?*/ memberName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180721256);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snws.SN.NetEventSource.Log.Associate$2($.$snws.SN.NetEventSource.IdOf(thisOrContextObject), memberName, $.$snws.SN.NetEventSource.IdOf(first), $.$snws.SN.NetEventSource.IdOf(second));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180721256)
            
            //--TRIMMABLE-BOUNDARY-START(25770655848)
            /*void */ Associate$2(/*string*/ thisOrContextObject, /*string?*/ memberName, /*string*/ first, /*string*/ second)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770655848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this.IsEnabled(), "IsEnabled()");
                this.WriteEvent$22(3/*AssociateEventId*/, thisOrContextObject, memberName ?? "(?)"/*MissingMember*/, first, second);
            }
            //--TRIMMABLE-BOUNDARY-END(25770655848)
            
            //--TRIMMABLE-BOUNDARY-START(283468693608)
            /*void */ WriteEvent$22(/*int*/ eventId, /*string?*/ arg1, /*string?*/ arg2, /*string?*/ arg3, /*string?*/ arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468693608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                arg1 ??= "";
                arg2 ??= "";
                arg3 ??= "";
                arg4 ??= "";
                /*fixed*/ 
                {
                    /*char**/ let string1Bytes = $.$$.S.String.GetPinnableReference.call(arg1);
                    /*fixed*/ 
                    {
                        /*char**/ let string2Bytes = $.$$.S.String.GetPinnableReference.call(arg2);
                        /*fixed*/ 
                        {
                            /*char**/ let string3Bytes = $.$$.S.String.GetPinnableReference.call(arg3);
                            /*fixed*/ 
                            {
                                /*char**/ let string4Bytes = $.$$.S.String.GetPinnableReference.call(arg4);
                                /*int*/ let NumEventDatas = 4;
                                /*EventData**/ let descrs = $.$$.SRC.RuntimeHelpers.StackAllocPointer($.$$.SDT.EventSource.EventData, NumEventDatas, null);
                                descrs.SetAt((() =>
                                {
                                    //new $.$$.SDT.EventSource.EventData()
                                    const $t13 = $.$$.SDT.EventSource.EventData;
                                    const $i13 = new $t13();
                                    $i13.$ctor$2();
                                    $i13.DataPointer = $.$$.$interop.$ptr2Addr(string1Bytes);
                                    $i13.Size = ((((((arg1.length + 1) | 0)) * 2) | 0));
                                    return $i13;
                                })(), 0);
                                descrs.SetAt((() =>
                                {
                                    //new $.$$.SDT.EventSource.EventData()
                                    const $t14 = $.$$.SDT.EventSource.EventData;
                                    const $i14 = new $t14();
                                    $i14.$ctor$2();
                                    $i14.DataPointer = $.$$.$interop.$ptr2Addr(string2Bytes);
                                    $i14.Size = ((((((arg2.length + 1) | 0)) * 2) | 0));
                                    return $i14;
                                })(), 1);
                                descrs.SetAt((() =>
                                {
                                    //new $.$$.SDT.EventSource.EventData()
                                    const $t15 = $.$$.SDT.EventSource.EventData;
                                    const $i15 = new $t15();
                                    $i15.$ctor$2();
                                    $i15.DataPointer = $.$$.$interop.$ptr2Addr(string3Bytes);
                                    $i15.Size = ((((((arg3.length + 1) | 0)) * 2) | 0));
                                    return $i15;
                                })(), 2);
                                descrs.SetAt((() =>
                                {
                                    //new $.$$.SDT.EventSource.EventData()
                                    const $t16 = $.$$.SDT.EventSource.EventData;
                                    const $i16 = new $t16();
                                    $i16.$ctor$2();
                                    $i16.DataPointer = $.$$.$interop.$ptr2Addr(string4Bytes);
                                    $i16.Size = ((((((arg4.length + 1) | 0)) * 2) | 0));
                                    return $i16;
                                })(), 3);
                                this.WriteEventCore(eventId, NumEventDatas, descrs);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(283468693608)
            
            //--TRIMMABLE-BOUNDARY-START(8590786664)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590786664)
            
            //--TRIMMABLE-BOUNDARY-START(8590786664)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(8590786664)
            
            //--TRIMMABLE-BOUNDARY-START(4295819368)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(184684445800)
                    this.Ping = "Ping";
                    //--TRIMMABLE-BOUNDARY-END(184684445800)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188979413096)
                    this.Pong = "Pong";
                    //--TRIMMABLE-BOUNDARY-END(188979413096)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310263400)
                    this.EventSourceSuppressMessage$1 = "Parameters to this method are primitive and are trimmer safe";
                    //--TRIMMABLE-BOUNDARY-END(77310263400)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439805544)
                    this.Log = new $.$snws.SN.NetEventSource().$ctor$10();
                    //--TRIMMABLE-BOUNDARY-END(137439805544)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734772840)
                    this.MissingMember = "(?)";
                    //--TRIMMABLE-BOUNDARY-END(141734772840)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180389478504)
                    this.NullInstance = "(null)";
                    //--TRIMMABLE-BOUNDARY-END(180389478504)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108955240)
                    this.StaticMethodObject = "(static)";
                    //--TRIMMABLE-BOUNDARY-END(249108955240)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176094511208)
                    this.NoParameters = "";
                    //--TRIMMABLE-BOUNDARY-END(176094511208)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295819368)
            
            static $h = 852072;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SDT.EventSource; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849870952),
    {
      "r": 65537,
      "p": [
        {
          "n": "objName",
          "p": 1310721
        },
        {
          "n": "opcode",
          "p": 1310721
        },
        {
          "n": "payload",
          "p": 917505
        }
      ],
      "n": "KeepAliveSent",
      "d": 852072,
      "h": 128849870952,
      "f": 16777218,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 5,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Keywords",
              "v": 2,
              "t": 74383361
            },
            {
              "n": "Level",
              "v": 4,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128849870952),
//--TRIMMABLE-BOUNDARY-START(115964969064),
    {
      "r": 65537,
      "p": [
        {
          "n": "objName",
          "p": 1310721
        },
        {
          "n": "payload",
          "p": 917505
        }
      ],
      "n": "KeepAliveAcked",
      "d": 852072,
      "h": 115964969064,
      "f": 16777218,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 6,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Keywords",
              "v": 2,
              "t": 74383361
            },
            {
              "n": "Level",
              "v": 4,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115964969064),
//--TRIMMABLE-BOUNDARY-START(124554903656),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "payload",
          "p": 917505
        }
      ],
      "n": "KeepAlivePingSent",
      "d": 852072,
      "h": 124554903656,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124554903656),
//--TRIMMABLE-BOUNDARY-START(266288824424),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "UnsolicitedPongSent",
      "d": 852072,
      "h": 266288824424,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(266288824424),
//--TRIMMABLE-BOUNDARY-START(193274380392),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "payload",
          "p": 917505
        }
      ],
      "n": "PongResponseReceived",
      "d": 852072,
      "h": 193274380392,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193274380392),
//--TRIMMABLE-BOUNDARY-START(287763660904),
    {
      "r": 65537,
      "p": [
        {
          "n": "objName",
          "p": 1310721
        },
        {
          "n": "memberName",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WsTrace",
      "d": 852072,
      "h": 287763660904,
      "f": 16777218,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 7,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Keywords",
              "v": 2,
              "t": 74383361
            },
            {
              "n": "Level",
              "v": 5,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(287763660904),
//--TRIMMABLE-BOUNDARY-START(257698889832),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "exception",
          "p": 80805889
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "TraceErrorMsg",
      "d": 852072,
      "h": 257698889832,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(257698889832),
//--TRIMMABLE-BOUNDARY-START(261993857128),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "exception",
          "p": 80805889
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "TraceException",
      "d": 852072,
      "h": 261993857128,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(261993857128),
//--TRIMMABLE-BOUNDARY-START(253403922536),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "message",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "Trace",
      "d": 852072,
      "h": 253403922536,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253403922536),
//--TRIMMABLE-BOUNDARY-START(42950525032),
    {
      "r": 65537,
      "p": [
        {
          "n": "objName",
          "p": 1310721
        },
        {
          "n": "memberName",
          "p": 1310721
        }
      ],
      "n": "CloseStart",
      "d": 852072,
      "h": 42950525032,
      "f": 16777218,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 8,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Keywords",
              "v": 2,
              "t": 74383361
            },
            {
              "n": "Level",
              "v": 5,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950525032),
//--TRIMMABLE-BOUNDARY-START(51540459624),
    {
      "r": 65537,
      "p": [
        {
          "n": "objName",
          "p": 1310721
        },
        {
          "n": "memberName",
          "p": 1310721
        }
      ],
      "n": "CloseStop",
      "d": 852072,
      "h": 51540459624,
      "f": 16777218,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 9,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Keywords",
              "v": 2,
              "t": 74383361
            },
            {
              "n": "Level",
              "v": 5,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540459624),
//--TRIMMABLE-BOUNDARY-START(38655557736),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "CloseAsyncPrivateStarted",
      "d": 852072,
      "h": 38655557736,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655557736),
//--TRIMMABLE-BOUNDARY-START(34360590440),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "CloseAsyncPrivateCompleted",
      "d": 852072,
      "h": 34360590440,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360590440),
//--TRIMMABLE-BOUNDARY-START(206159282280),
    {
      "r": 65537,
      "p": [
        {
          "n": "objName",
          "p": 1310721
        },
        {
          "n": "memberName",
          "p": 1310721
        },
        {
          "n": "bufferLength",
          "p": 655361
        }
      ],
      "n": "ReceiveStart",
      "d": 852072,
      "h": 206159282280,
      "f": 16777218,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 10,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Keywords",
              "v": 2,
              "t": 74383361
            },
            {
              "n": "Level",
              "v": 4,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206159282280),
//--TRIMMABLE-BOUNDARY-START(214749216872),
    {
      "r": 65537,
      "p": [
        {
          "n": "objName",
          "p": 1310721
        },
        {
          "n": "memberName",
          "p": 1310721
        }
      ],
      "n": "ReceiveStop",
      "d": 852072,
      "h": 214749216872,
      "f": 16777218,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 11,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Keywords",
              "v": 2,
              "t": 74383361
            },
            {
              "n": "Level",
              "v": 4,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214749216872),
//--TRIMMABLE-BOUNDARY-START(201864314984),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "bufferLength",
          "p": 655361
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "ReceiveAsyncPrivateStarted",
      "d": 852072,
      "h": 201864314984,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201864314984),
//--TRIMMABLE-BOUNDARY-START(197569347688),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "ReceiveAsyncPrivateCompleted",
      "d": 852072,
      "h": 197569347688,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197569347688),
//--TRIMMABLE-BOUNDARY-START(231929086056),
    {
      "r": 65537,
      "p": [
        {
          "n": "objName",
          "p": 1310721
        },
        {
          "n": "memberName",
          "p": 1310721
        },
        {
          "n": "opcode",
          "p": 1310721
        },
        {
          "n": "bufferLength",
          "p": 655361
        }
      ],
      "n": "SendStart",
      "d": 852072,
      "h": 231929086056,
      "f": 16777218,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 12,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Keywords",
              "v": 2,
              "t": 74383361
            },
            {
              "n": "Level",
              "v": 5,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231929086056),
//--TRIMMABLE-BOUNDARY-START(240519020648),
    {
      "r": 65537,
      "p": [
        {
          "n": "objName",
          "p": 1310721
        },
        {
          "n": "memberName",
          "p": 1310721
        }
      ],
      "n": "SendStop",
      "d": 852072,
      "h": 240519020648,
      "f": 16777218,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 13,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Keywords",
              "v": 2,
              "t": 74383361
            },
            {
              "n": "Level",
              "v": 5,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(240519020648),
//--TRIMMABLE-BOUNDARY-START(227634118760),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "opcode",
          "p": 1310721
        },
        {
          "n": "bufferLength",
          "p": 655361
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "SendFrameAsyncStarted",
      "d": 852072,
      "h": 227634118760,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(227634118760),
//--TRIMMABLE-BOUNDARY-START(223339151464),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "SendFrameAsyncCompleted",
      "d": 852072,
      "h": 223339151464,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(223339151464),
//--TRIMMABLE-BOUNDARY-START(146029740136),
    {
      "r": 65537,
      "p": [
        {
          "n": "objName",
          "p": 1310721
        },
        {
          "n": "memberName",
          "p": 1310721
        }
      ],
      "n": "MutexEnter",
      "d": 852072,
      "h": 146029740136,
      "f": 16777218,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 14,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Keywords",
              "v": 2,
              "t": 74383361
            },
            {
              "n": "Level",
              "v": 5,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146029740136),
//--TRIMMABLE-BOUNDARY-START(158914642024),
    {
      "r": 65537,
      "p": [
        {
          "n": "objName",
          "p": 1310721
        },
        {
          "n": "memberName",
          "p": 1310721
        }
      ],
      "n": "MutexExit",
      "d": 852072,
      "h": 158914642024,
      "f": 16777218,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 15,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Keywords",
              "v": 2,
              "t": 74383361
            },
            {
              "n": "Level",
              "v": 5,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914642024),
//--TRIMMABLE-BOUNDARY-START(150324707432),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "MutexEntered",
      "d": 852072,
      "h": 150324707432,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150324707432),
//--TRIMMABLE-BOUNDARY-START(163209609320),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "MutexExited",
      "d": 852072,
      "h": 163209609320,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163209609320),
//--TRIMMABLE-BOUNDARY-START(274878759016),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventId",
          "p": 655361
        },
        {
          "n": "arg1",
          "p": 1310721
        },
        {
          "n": "arg2",
          "p": 1310721
        },
        {
          "n": "arg3",
          "p": 917505
        }
      ],
      "n": "WriteEvent",
      "o": "@$20",
      "d": 852072,
      "h": 274878759016,
      "f": 16777218,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(274878759016),
//--TRIMMABLE-BOUNDARY-START(279173726312),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventId",
          "p": 655361
        },
        {
          "n": "arg1",
          "p": 1310721
        },
        {
          "n": "arg2",
          "p": 1310721
        },
        {
          "n": "arg3",
          "p": 1310721
        },
        {
          "n": "arg4",
          "p": 655361
        }
      ],
      "n": "WriteEvent",
      "o": "@$21",
      "d": 852072,
      "h": 279173726312,
      "f": 16777218,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(279173726312),
//--TRIMMABLE-BOUNDARY-START(98785099880),
    {
      "r": 65537,
      "p": [
        {
          "n": "thisOrContextObject",
          "p": 131073
        },
        {
          "n": "formattableString",
          "p": 81395713,
          "f": 65
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "Info",
      "d": 852072,
      "h": 98785099880,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98785099880),
//--TRIMMABLE-BOUNDARY-START(103080067176),
    {
      "r": 65537,
      "p": [
        {
          "n": "thisOrContextObject",
          "p": 131073
        },
        {
          "n": "message",
          "p": 131073
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "Info",
      "o": "@$1",
      "d": 852072,
      "h": 103080067176,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103080067176),
//--TRIMMABLE-BOUNDARY-START(107375034472),
    {
      "r": 65537,
      "p": [
        {
          "n": "thisOrContextObject",
          "p": 1310721
        },
        {
          "n": "memberName",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Info",
      "o": "@$2",
      "d": 852072,
      "h": 107375034472,
      "f": 16777218,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 1,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 4,
              "t": 74448897
            },
            {
              "n": "Keywords",
              "v": 1,
              "t": 74383361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107375034472),
//--TRIMMABLE-BOUNDARY-START(60130394216),
    {
      "r": 65537,
      "p": [
        {
          "n": "thisOrContextObject",
          "p": 131073
        },
        {
          "n": "formattableString",
          "p": 81395713
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "Error",
      "d": 852072,
      "h": 60130394216,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130394216),
//--TRIMMABLE-BOUNDARY-START(64425361512),
    {
      "r": 65537,
      "p": [
        {
          "n": "thisOrContextObject",
          "p": 131073
        },
        {
          "n": "message",
          "p": 131073
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "Error",
      "o": "@$1",
      "d": 852072,
      "h": 64425361512,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425361512),
//--TRIMMABLE-BOUNDARY-START(73015296104),
    {
      "r": 65537,
      "p": [
        {
          "n": "thisOrContextObject",
          "p": 1310721
        },
        {
          "n": "memberName",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ErrorMessage",
      "d": 852072,
      "h": 73015296104,
      "f": 16777218,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 2,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 2,
              "t": 74448897
            },
            {
              "n": "Keywords",
              "v": 1,
              "t": 74383361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015296104),
//--TRIMMABLE-BOUNDARY-START(94490132584),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IdOf",
      "d": 852072,
      "h": 94490132584,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94490132584),
//--TRIMMABLE-BOUNDARY-START(90195165288),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "GetHashCode",
      "o": "@$1",
      "d": 852072,
      "h": 90195165288,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90195165288),
//--TRIMMABLE-BOUNDARY-START(85900197992),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Format",
      "o": "@$1",
      "d": 852072,
      "h": 85900197992,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900197992),
//--TRIMMABLE-BOUNDARY-START(81605230696),
    {
      "r": 1310721,
      "p": [
        {
          "n": "s",
          "p": 81395713
        }
      ],
      "n": "Format",
      "d": 852072,
      "h": 81605230696,
      "f": 16777250,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605230696),
//--TRIMMABLE-BOUNDARY-START(12885753960),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "result",
          "p": 1310721,
          "f": 4
        }
      ],
      "n": "AdditionalCustomizedToString",
      "d": 852072,
      "h": 12885753960,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885753960),
//--TRIMMABLE-BOUNDARY-START(270583791720),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventId",
          "p": 655361
        },
        {
          "n": "arg1",
          "p": 1310721
        },
        {
          "n": "arg2",
          "p": 1310721
        },
        {
          "n": "arg3",
          "p": 655361
        }
      ],
      "n": "WriteEvent",
      "o": "@$19",
      "d": 852072,
      "h": 270583791720,
      "f": 16777218,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(270583791720),
//--TRIMMABLE-BOUNDARY-START(21475688552),
    {
      "r": 65537,
      "p": [
        {
          "n": "first",
          "p": 131073
        },
        {
          "n": "second",
          "p": 131073
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "Associate",
      "o": "@$1",
      "d": 852072,
      "h": 21475688552,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475688552),
//--TRIMMABLE-BOUNDARY-START(17180721256),
    {
      "r": 65537,
      "p": [
        {
          "n": "thisOrContextObject",
          "p": 131073
        },
        {
          "n": "first",
          "p": 131073
        },
        {
          "n": "second",
          "p": 131073
        },
        {
          "n": "memberName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "Associate",
      "d": 852072,
      "h": 17180721256,
      "f": 16777249,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180721256),
//--TRIMMABLE-BOUNDARY-START(25770655848),
    {
      "r": 65537,
      "p": [
        {
          "n": "thisOrContextObject",
          "p": 1310721
        },
        {
          "n": "memberName",
          "p": 1310721
        },
        {
          "n": "first",
          "p": 1310721
        },
        {
          "n": "second",
          "p": 1310721
        }
      ],
      "n": "Associate",
      "o": "@$2",
      "d": 852072,
      "h": 25770655848,
      "f": 16777218,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 3,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 4,
              "t": 74448897
            },
            {
              "n": "Keywords",
              "v": 1,
              "t": 74383361
            },
            {
              "n": "Message",
              "v": "[{2}]\u003C--\u003E[{3}]",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770655848),
//--TRIMMABLE-BOUNDARY-START(283468693608),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventId",
          "p": 655361
        },
        {
          "n": "arg1",
          "p": 1310721
        },
        {
          "n": "arg2",
          "p": 1310721
        },
        {
          "n": "arg3",
          "p": 1310721
        },
        {
          "n": "arg4",
          "p": 1310721
        }
      ],
      "n": "WriteEvent",
      "o": "@$22",
      "d": 852072,
      "h": 283468693608,
      "f": 16777218,
      "a": [
        {
          "t": 77791233,
          "c": 4372758529
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(283468693608)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(133144838248),
    {
      "t": 655361,
      "n": "KeepAliveSentId",
      "d": 852072,
      "h": 133144838248,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(133144838248),
//--TRIMMABLE-BOUNDARY-START(120259936360),
    {
      "t": 655361,
      "n": "KeepAliveAckedId",
      "d": 852072,
      "h": 120259936360,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(120259936360),
//--TRIMMABLE-BOUNDARY-START(292058628200),
    {
      "t": 655361,
      "n": "WsTraceId",
      "d": 852072,
      "h": 292058628200,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(292058628200),
//--TRIMMABLE-BOUNDARY-START(47245492328),
    {
      "t": 655361,
      "n": "CloseStartId",
      "d": 852072,
      "h": 47245492328,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245492328),
//--TRIMMABLE-BOUNDARY-START(55835426920),
    {
      "t": 655361,
      "n": "CloseStopId",
      "d": 852072,
      "h": 55835426920,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55835426920),
//--TRIMMABLE-BOUNDARY-START(210454249576),
    {
      "t": 655361,
      "n": "ReceiveStartId",
      "d": 852072,
      "h": 210454249576,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(210454249576),
//--TRIMMABLE-BOUNDARY-START(219044184168),
    {
      "t": 655361,
      "n": "ReceiveStopId",
      "d": 852072,
      "h": 219044184168,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(219044184168),
//--TRIMMABLE-BOUNDARY-START(236224053352),
    {
      "t": 655361,
      "n": "SendStartId",
      "d": 852072,
      "h": 236224053352,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(236224053352),
//--TRIMMABLE-BOUNDARY-START(244813987944),
    {
      "t": 655361,
      "n": "SendStopId",
      "d": 852072,
      "h": 244813987944,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(244813987944),
//--TRIMMABLE-BOUNDARY-START(154619674728),
    {
      "t": 655361,
      "n": "MutexEnterId",
      "d": 852072,
      "h": 154619674728,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(154619674728),
//--TRIMMABLE-BOUNDARY-START(167504576616),
    {
      "t": 655361,
      "n": "MutexExitId",
      "d": 852072,
      "h": 167504576616,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(167504576616),
//--TRIMMABLE-BOUNDARY-START(184684445800),
    {
      "t": 1310721,
      "n": "Ping",
      "d": 852072,
      "h": 184684445800,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(184684445800),
//--TRIMMABLE-BOUNDARY-START(188979413096),
    {
      "t": 1310721,
      "n": "Pong",
      "d": 852072,
      "h": 188979413096,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(188979413096),
//--TRIMMABLE-BOUNDARY-START(77310263400),
    {
      "t": 1310721,
      "n": "EventSourceSuppressMessage",
      "o": "@$1",
      "d": 852072,
      "h": 77310263400,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77310263400),
//--TRIMMABLE-BOUNDARY-START(137439805544),
    {
      "t": 852072,
      "n": "Log",
      "d": 852072,
      "h": 137439805544,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439805544),
//--TRIMMABLE-BOUNDARY-START(141734772840),
    {
      "t": 1310721,
      "n": "MissingMember",
      "d": 852072,
      "h": 141734772840,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(141734772840),
//--TRIMMABLE-BOUNDARY-START(180389478504),
    {
      "t": 1310721,
      "n": "NullInstance",
      "d": 852072,
      "h": 180389478504,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(180389478504),
//--TRIMMABLE-BOUNDARY-START(249108955240),
    {
      "t": 1310721,
      "n": "StaticMethodObject",
      "d": 852072,
      "h": 249108955240,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(249108955240),
//--TRIMMABLE-BOUNDARY-START(176094511208),
    {
      "t": 1310721,
      "n": "NoParameters",
      "d": 852072,
      "h": 176094511208,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(176094511208),
//--TRIMMABLE-BOUNDARY-START(111670001768),
    {
      "t": 655361,
      "n": "InfoEventId",
      "d": 852072,
      "h": 111670001768,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(111670001768),
//--TRIMMABLE-BOUNDARY-START(68720328808),
    {
      "t": 655361,
      "n": "ErrorEventId",
      "d": 852072,
      "h": 68720328808,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68720328808),
//--TRIMMABLE-BOUNDARY-START(171799543912),
    {
      "t": 655361,
      "n": "NextAvailableEventId",
      "d": 852072,
      "h": 171799543912,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(171799543912),
//--TRIMMABLE-BOUNDARY-START(30065623144),
    {
      "t": 655361,
      "n": "AssociateEventId",
      "d": 852072,
      "h": 30065623144,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30065623144)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590786664),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 852072,
      "h": 8590786664,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590786664)
  ],
  "h": 852072,
  "a": [
    {
      "t": 75563009,
      "c": 17255432193,
      "n": [
        {
          "n": "Name",
          "v": "Private.InternalDiagnostics.System.Net.WebSockets",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$snws.SN.NetEventSource.Keywords ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.NetEventSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}NetEventSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852072)
        
        

        //--TRIMMABLE-BOUNDARY-START(2031720)
        $asm.$cls(`$snws.SNW.WebSocketException`, ($self) => class WebSocketException extends $.$$.SC$2.Win32Exception
        {
            //--TRIMMABLE-BOUNDARY-START(4296999016)
            /*WebSocketError*/ _webSocketErrorCode = 0;
            //--TRIMMABLE-BOUNDARY-END(4296999016)
            
            //--TRIMMABLE-BOUNDARY-START(8591966312)
            $ctor$20()
            {
                this.$ctor$23($.$$.SRI.Marshal.GetLastPInvokeError());
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591966312);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591966312)
            
            //--TRIMMABLE-BOUNDARY-START(55836606568)
            $ctor$31(/*WebSocketError*/ error)
            {
                this.$ctor$30(error, $.$snws.SNW.WebSocketException.GetErrorMessage(error));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836606568);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55836606568)
            
            //--TRIMMABLE-BOUNDARY-START(51541639272)
            $ctor$30(/*WebSocketError*/ error, /*string?*/ message)
            {
                super.$ctor$19(message ?? $.$snws.S.SR.net_WebSockets_Generic);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541639272);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._webSocketErrorCode = error;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51541639272)
            
            //--TRIMMABLE-BOUNDARY-START(25771835496)
            $ctor$24(/*WebSocketError*/ error, /*Exception?*/ innerException)
            {
                this.$ctor$29(error, $.$snws.SNW.WebSocketException.GetErrorMessage(error), innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771835496);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771835496)
            
            //--TRIMMABLE-BOUNDARY-START(47246671976)
            $ctor$29(/*WebSocketError*/ error, /*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$18(message ?? $.$snws.S.SR.net_WebSockets_Generic, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246671976);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._webSocketErrorCode = error;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47246671976)
            
            //--TRIMMABLE-BOUNDARY-START(21476868200)
            $ctor$23(/*int*/ nativeError)
            {
                super.$ctor$16(nativeError);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476868200);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._webSocketErrorCode = !$.$snws.SNW.WebSocketException.Succeeded(nativeError) ? 3/*WebSocketError.NativeError*/ : 0/*WebSocketError.Success*/;
                    this.SetErrorCodeOnError(nativeError);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476868200)
            
            //--TRIMMABLE-BOUNDARY-START(17181900904)
            $ctor$22(/*int*/ nativeError, /*string?*/ message)
            {
                super.$ctor$15(nativeError, message);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181900904);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._webSocketErrorCode = !$.$snws.SNW.WebSocketException.Succeeded(nativeError) ? 3/*WebSocketError.NativeError*/ : 0/*WebSocketError.Success*/;
                    this.SetErrorCodeOnError(nativeError);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181900904)
            
            //--TRIMMABLE-BOUNDARY-START(12886933608)
            $ctor$21(/*int*/ nativeError, /*Exception?*/ innerException)
            {
                super.$ctor$18($.$snws.S.SR.net_WebSockets_Generic, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886933608);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._webSocketErrorCode = !$.$snws.SNW.WebSocketException.Succeeded(nativeError) ? 3/*WebSocketError.NativeError*/ : 0/*WebSocketError.Success*/;
                    this.SetErrorCodeOnError(nativeError);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886933608)
            
            //--TRIMMABLE-BOUNDARY-START(42951704680)
            $ctor$28(/*WebSocketError*/ error, /*int*/ nativeError)
            {
                this.$ctor$27(error, nativeError, $.$snws.SNW.WebSocketException.GetErrorMessage(error));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951704680);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951704680)
            
            //--TRIMMABLE-BOUNDARY-START(38656737384)
            $ctor$27(/*WebSocketError*/ error, /*int*/ nativeError, /*string?*/ message)
            {
                super.$ctor$19(message ?? $.$snws.S.SR.net_WebSockets_Generic);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656737384);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._webSocketErrorCode = error;
                    this.SetErrorCodeOnError(nativeError);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656737384)
            
            //--TRIMMABLE-BOUNDARY-START(30066802792)
            $ctor$25(/*WebSocketError*/ error, /*int*/ nativeError, /*Exception?*/ innerException)
            {
                this.$ctor$26(error, nativeError, $.$snws.SNW.WebSocketException.GetErrorMessage(error), innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066802792);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066802792)
            
            //--TRIMMABLE-BOUNDARY-START(34361770088)
            $ctor$26(/*WebSocketError*/ error, /*int*/ nativeError, /*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$18(message ?? $.$snws.S.SR.net_WebSockets_Generic, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361770088);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._webSocketErrorCode = error;
                    this.SetErrorCodeOnError(nativeError);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361770088)
            
            //--TRIMMABLE-BOUNDARY-START(68721508456)
            $ctor$34(/*string?*/ message)
            {
                super.$ctor$19(message ?? $.$snws.S.SR.net_WebSockets_Generic);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721508456);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68721508456)
            
            //--TRIMMABLE-BOUNDARY-START(64426541160)
            $ctor$33(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$18(message ?? $.$snws.S.SR.net_WebSockets_Generic, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426541160);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64426541160)
            
            //--TRIMMABLE-BOUNDARY-START(60131573864)
            $ctor$32(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.$ctor$17(serializationInfo, streamingContext);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131573864);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60131573864)
            
            //--TRIMMABLE-BOUNDARY-START(98786279528)
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786279528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.GetObjectData(info, context);
                info.AddValue$10("WebSocketErrorCode", $.$box(this._webSocketErrorCode, $.$snws.SNW.WebSocketError));
            }
            //--TRIMMABLE-BOUNDARY-END(98786279528)
            
            //--TRIMMABLE-BOUNDARY-START(73016475752)
            /*int */ get ErrorCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606410344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.NativeErrorCode;
            }
            //--TRIMMABLE-BOUNDARY-END(73016475752)
            
            //--TRIMMABLE-BOUNDARY-START(111671181416)
            /*WebSocketError */ get WebSocketErrorCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196344936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._webSocketErrorCode;
            }
            //--TRIMMABLE-BOUNDARY-END(111671181416)
            
            //--TRIMMABLE-BOUNDARY-START(94491312232)
            static /*string */ GetErrorMessage(/*WebSocketError*/ error)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94491312232);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        if (error === 1/*WebSocketError.InvalidMessageType*/)
                        {
                            return $.$snws.S.SR.Format$5($.$snws.S.SR.net_WebSockets_InvalidMessageType_Generic, `${$.$strNN("WebSocket")}.${$.$strNN("CloseAsync")}`, `${$.$strNN("WebSocket")}.${$.$strNN("CloseOutputAsync")}`);
                        }
                        if (error === 2/*WebSocketError.Faulted*/)
                        {
                            return $.$snws.S.SR.net_Websockets_WebSocketBaseFaulted;
                        }
                        if (error === 4/*WebSocketError.NotAWebSocket*/)
                        {
                            return $.$snws.S.SR.net_WebSockets_NotAWebSocket_Generic;
                        }
                        if (error === 5/*WebSocketError.UnsupportedVersion*/)
                        {
                            return $.$snws.S.SR.net_WebSockets_UnsupportedWebSocketVersion_Generic;
                        }
                        if (error === 6/*WebSocketError.UnsupportedProtocol*/)
                        {
                            return $.$snws.S.SR.net_WebSockets_UnsupportedProtocol_Generic;
                        }
                        if (error === 7/*WebSocketError.HeaderError*/)
                        {
                            return $.$snws.S.SR.net_WebSockets_HeaderError_Generic;
                        }
                        if (error === 8/*WebSocketError.ConnectionClosedPrematurely*/)
                        {
                            return $.$snws.S.SR.net_WebSockets_ConnectionClosedPrematurely_Generic;
                        }
                        if (error === 9/*WebSocketError.InvalidState*/)
                        {
                            return $.$snws.S.SR.net_WebSockets_InvalidState_Generic;
                        }
                        return $.$snws.S.SR.net_WebSockets_Generic;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94491312232)
            
            //--TRIMMABLE-BOUNDARY-START(103081246824)
            /*void */ SetErrorCodeOnError(/*int*/ nativeError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081246824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$snws.SNW.WebSocketException.Succeeded(nativeError))
                {
                    this.HResult = nativeError;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103081246824)
            
            //--TRIMMABLE-BOUNDARY-START(107376214120)
            static /*bool */ Succeeded(/*int*/ hr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376214120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (hr >= 0);
            }
            //--TRIMMABLE-BOUNDARY-END(107376214120)
            
            //--TRIMMABLE-BOUNDARY-START(8591966312)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$20();
            }
            //--TRIMMABLE-BOUNDARY-END(8591966312)
            
            static $h = 2031720;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SC$2.Win32Exception; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2031720
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebSockets.WebSocketException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebSockets${separator}WebSocketException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031720)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Cryptography"));
})();
//--TRIMMABLE-BOUNDARY-END(104)
