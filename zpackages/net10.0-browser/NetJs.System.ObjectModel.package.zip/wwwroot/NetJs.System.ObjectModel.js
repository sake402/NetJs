
(function ($global, $, $$, $sc, $sm, $spu, $sr, $st) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.ObjectModel", 
    {"h":37903,"f":"System.ObjectModel","v":"1.0.35.0","a":[{"t":96206849,"c":4391174145,"a":[{"v":$.$$.System.Collections.ObjectModel.ReadOnlyDictionary$$$().$h,"t":142475265}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.ObjectModel","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.ObjectModel","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$so.System.Collections.Specialized.INotifyCollectionChanged", ($self) => class INotifyCollectionChanged
        {
            static $h = 562191;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"e":[{"e":758799,"m":{"r":65537,"p":[{"n":"value","p":758799}],"n":"add_CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$add_CollectionChanged","d":562191,"h":4295529487,"f":150995201},"r":{"r":65537,"p":[{"n":"value","p":758799}],"n":"remove_CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$remove_CollectionChanged","d":562191,"h":8590496783,"f":285212929},"n":"CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged","d":562191,"h":12885464079,"f":8388865}],"h":562191}; }
            static get $fullName() { return `System.Collections.Specialized.INotifyCollectionChanged`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.INotifyPropertyChanged", ($self) => class INotifyPropertyChanged
        {
            static $h = 1086479;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"e":[{"e":1283087,"m":{"r":65537,"p":[{"n":"value","p":1283087}],"n":"add_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$add_PropertyChanged","d":1086479,"h":4296053775,"f":150995201},"r":{"r":65537,"p":[{"n":"value","p":1283087}],"n":"remove_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$remove_PropertyChanged","d":1086479,"h":8591021071,"f":285212929},"n":"PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$PropertyChanged","d":1086479,"h":12885988367,"f":8388865}],"h":1086479}; }
            static get $fullName() { return `System.ComponentModel.INotifyPropertyChanged`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.INotifyPropertyChanging", ($self) => class INotifyPropertyChanging
        {
            static $h = 1152015;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"e":[{"e":1414159,"m":{"r":65537,"p":[{"n":"value","p":1414159}],"n":"add_PropertyChanging","o":"System$ComponentModel$INotifyPropertyChanging$add_PropertyChanging","d":1152015,"h":4296119311,"f":150995201},"r":{"r":65537,"p":[{"n":"value","p":1414159}],"n":"remove_PropertyChanging","o":"System$ComponentModel$INotifyPropertyChanging$remove_PropertyChanging","d":1152015,"h":8591086607,"f":285212929},"n":"PropertyChanging","o":"System$ComponentModel$INotifyPropertyChanging$PropertyChanging","d":1152015,"h":12886053903,"f":8388865}],"h":1152015}; }
            static get $fullName() { return `System.ComponentModel.INotifyPropertyChanging`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.INotifyDataErrorInfo", ($self) => class INotifyDataErrorInfo
        {
            static $h = 1020943;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":8590955535,"f":50331905},"n":"HasErrors","o":"System$ComponentModel$INotifyDataErrorInfo$HasErrors","d":1020943,"h":4295988239,"f":2097409}],"m":[{"r":31719425,"p":[{"n":"propertyName","p":1310721}],"n":"GetErrors","o":"System$ComponentModel$INotifyDataErrorInfo$GetErrors","d":1020943,"h":12885922831,"f":16777473}],"e":[{"e":$.$$.System.EventHandler$$($.$so.System.ComponentModel.DataErrorsChangedEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$$.System.EventHandler$$($.$so.System.ComponentModel.DataErrorsChangedEventArgs).$h}],"n":"add_ErrorsChanged","o":"System$ComponentModel$INotifyDataErrorInfo$add_ErrorsChanged","d":1020943,"h":17180890127,"f":150995201},"r":{"r":65537,"p":[{"n":"value","p":$.$$.System.EventHandler$$($.$so.System.ComponentModel.DataErrorsChangedEventArgs).$h}],"n":"remove_ErrorsChanged","o":"System$ComponentModel$INotifyDataErrorInfo$remove_ErrorsChanged","d":1020943,"h":21475857423,"f":285212929},"n":"ErrorsChanged","o":"System$ComponentModel$INotifyDataErrorInfo$ErrorsChanged","d":1020943,"h":25770824719,"f":8388865}],"h":1020943}; }
            static get $fullName() { return `System.ComponentModel.INotifyDataErrorInfo`; }
        });
        
        $asm.$cls("$so.System.Reflection.ICustomTypeProvider", ($self) => class ICustomTypeProvider
        {
            static $h = 1610767;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":142475265,"n":"GetCustomType","o":"System$Reflection$ICustomTypeProvider$GetCustomType","d":1610767,"h":4296578063,"f":16777473}],"h":1610767}; }
            static get $fullName() { return `System.Reflection.ICustomTypeProvider`; }
        });
        
        $asm.$cls("$so.System.Windows.Input.ICommand", ($self) => class ICommand
        {
            static $h = 1741839;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262145,"p":[{"n":"parameter","p":131073}],"n":"CanExecute","o":"System$Windows$Input$ICommand$CanExecute","d":1741839,"h":17181611023,"f":16777473},{"r":65537,"p":[{"n":"parameter","p":131073}],"n":"Execute","o":"System$Windows$Input$ICommand$Execute","d":1741839,"h":21476578319,"f":16777473}],"e":[{"e":47054849,"m":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"add_CanExecuteChanged","o":"System$Windows$Input$ICommand$add_CanExecuteChanged","d":1741839,"h":4296709135,"f":150995201},"r":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"remove_CanExecuteChanged","o":"System$Windows$Input$ICommand$remove_CanExecuteChanged","d":1741839,"h":8591676431,"f":285212929},"n":"CanExecuteChanged","o":"System$Windows$Input$ICommand$CanExecuteChanged","d":1741839,"h":12886643727,"f":8388865}],"h":1741839,"a":[{"t":96141313,"c":4391108609,"a":[{"v":"PresentationCore, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]},{"t":1479695,"c":17181348879,"a":[{"v":"System.Windows.Input.CommandConverter, PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, Custom=null","t":1310721}]},{"t":1807375,"c":17181676559,"a":[{"v":"System.Windows.Input.CommandValueSerializer, PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, Custom=null","t":1310721}]}]}; }
            static get $fullName() { return `System.Windows.Input.ICommand`; }
        });
        
        $asm.$cls("$so.System.Collections.CollectionHelpers", ($self) => class CollectionHelpers
        {
            static /*void */ ValidateCopyToArguments(/*int*/ sourceCount, /*Array*/ array, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.Arg_NonZeroLowerBound, "array");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, index, array.length, "index");
                if (((array.length - index) | 0) < sourceCount)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$so.System.SR.Arg_ArrayPlusOffTooSmall);
                }
            }
            static $h = 103439;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"sourceCount","p":655361},{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"ValidateCopyToArguments","d":103439,"h":4295070735,"f":16777256}],"h":103439}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.CollectionHelpers`; }
        });
        
        $asm.$cls("$so.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$so.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.ObjectModel", $.$so.System.SR.$type.Assembly);
                    $.$so.System.SR.s_resourceManager = temp;
                }
                return $.$so.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$so.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$so.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentOutOfRange_InvalidThreshold()
            {
                return "The specified threshold for creating dictionary is out of range.";
            }
            static /*string */ get Argument_ItemNotExist()
            {
                return "The specified item does not exist in this KeyedCollection.";
            }
            static /*string */ get Argument_AddingDuplicate()
            {
                return "An item with the same key has already been added. Key: {0}";
            }
            static /*string */ FormatArgument_AddingDuplicate(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("An item with the same key has already been added. Key: {0}", arg1);
            }
            static /*string */ get Arg_NonZeroLowerBound()
            {
                return "The lower bound of target array must be zero.";
            }
            static /*string */ get Arg_ArrayPlusOffTooSmall()
            {
                return "Destination array is not long enough to copy all the items in the collection. Check array index and length.";
            }
            static /*string */ get NotSupported_ReadOnlyCollection()
            {
                return "Collection is read-only.";
            }
            static /*string */ get ObservableCollectionReentrancyNotAllowed()
            {
                return "Cannot change ObservableCollection during a CollectionChanged event.";
            }
            static /*string */ get WrongActionForCtor()
            {
                return "Constructor supports only the '{0}' action.";
            }
            static /*string */ FormatWrongActionForCtor(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Constructor supports only the '{0}' action.", arg1);
            }
            static /*string */ get MustBeResetAddOrRemoveActionForCtor()
            {
                return "Constructor only supports either a Reset, Add, or Remove action.";
            }
            static /*string */ get ResetActionRequiresNullItem()
            {
                return "Reset action must be initialized with no changed items.";
            }
            static /*string */ get ResetActionRequiresIndexMinus1()
            {
                return "Reset action must be initialized with index -1.";
            }
            static /*string */ get Arg_RankMultiDimNotSupported()
            {
                return "Only single dimensional arrays are supported for the requested action.";
            }
            static /*string */ get Argument_IncompatibleArrayType()
            {
                return "Target array type is not compatible with the type of items in the collection.";
            }
            static /*string */ get Arg_KeyNotFoundWithKey()
            {
                return "The given key '{0}' was not present in the dictionary.";
            }
            static /*string */ FormatArg_KeyNotFoundWithKey(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The given key '{0}' was not present in the dictionary.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$so.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$so.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$so.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$so.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$so.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$so.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1676303;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1676303}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$so.System.Collections.Generic.CollectionDebugView<>", (T) => $asm.$gt("$so.System.Collections.Generic.CollectionDebugView<>", [T], ($self) => class CollectionDebugView$$ extends $.$$.System.Object
        {
            /*ICollection<T>*/ _collection = null;
            $ctor$1(/*ICollection<T>*/ collection)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._collection = collection;
                }
                return this;
            }
            /*T[] */ get Items()
            {
                /*T[]*/ let items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this._collection.System$Collections$Generic$ICollection$$$Count], null);
                this._collection.System$Collections$Generic$ICollection$$$CopyTo(items, 0, [T]);
                return items;
            }
            static $h = 168975;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$typeArray(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Items","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153,"a":[{"t":37421057,"c":4332388353,"a":[{"v":3,"t":37486593}]}]}],"l":[{"t":$.$$.System.Collections.Generic.ICollection$$(T).$h,"n":"_collection","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"collection","p":$.$$.System.Collections.Generic.ICollection$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.CollectionDebugView<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$so.System.Collections.ObjectModel.EventArgsCache", ($self) => class EventArgsCache
        {
            /*PropertyChangedEventArgs*/ static CountPropertyChanged = null;
            /*PropertyChangedEventArgs*/ static IndexerPropertyChanged = null;
            /*NotifyCollectionChangedEventArgs*/ static ResetCollectionChanged = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.CountPropertyChanged = new $.$so.System.ComponentModel.PropertyChangedEventArgs().$ctor$2("Count");
                }
                {
                    this.IndexerPropertyChanged = new $.$so.System.ComponentModel.PropertyChangedEventArgs().$ctor$2("Item[]");
                }
                {
                    this.ResetCollectionChanged = new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs().$ctor$12(4/*NotifyCollectionChangedAction.Reset*/);
                }
            }
            static $h = 234511;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1217551,"n":"CountPropertyChanged","d":234511,"h":4295201807,"f":4194344},{"t":1217551,"n":"IndexerPropertyChanged","d":234511,"h":8590169103,"f":4194344},{"t":693263,"n":"ResetCollectionChanged","d":234511,"h":12885136399,"f":4194344}],"h":234511}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.ObjectModel.EventArgsCache`; }
        });
        
        $asm.$cls("$so.System.Collections.Specialized.ReadOnlyList", ($self) => class ReadOnlyList extends $.$$.System.Object
        {
            /*IList*/ _list = null;
            $ctor$1(/*IList*/ list)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(list !== null, "list != null");
                    this._list = list;
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._list.System$Collections$ICollection$Count;
            }
            /*bool */ get IsReadOnly()
            {
                return true;
            }
            /*bool */ get IsFixedSize()
            {
                return true;
            }
            /*bool */ get IsSynchronized()
            {
                return this._list.System$Collections$ICollection$IsSynchronized;
            }
            /*object?*/ get_Item(/*int*/ index)
            {
                return this._list.System$Collections$IList$get_Item(index);
            }
            /*void*/ set_Item(/*int*/ index, /*object?*/ value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*object */ get SyncRoot()
            {
                return this._list.System$Collections$ICollection$SyncRoot;
            }
            /*int */ Add(/*object?*/ value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Clear()
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*bool */ Contains(/*object?*/ value)
            {
                return this._list.System$Collections$IList$Contains(value);
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                return this._list.System$Collections$ICollection$CopyTo(array, index);
            }
            /*IEnumerator */ GetEnumerator()
            {
                return this._list.System$Collections$IEnumerable$GetEnumerator();
            }
            /*int */ IndexOf(/*object?*/ value)
            {
                return this._list.System$Collections$IList$IndexOf(value);
            }
            /*void */ Insert(/*int*/ index, /*object?*/ value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Remove(/*object?*/ value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            //Generated interface implemetation for System.Collections.IList.this[int].get
            System$Collections$IList$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.this[int].set
            System$Collections$IList$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Add(object?)
            System$Collections$IList$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Contains(object?)
            System$Collections$IList$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Clear()
            System$Collections$IList$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.IsReadOnly.get
            get System$Collections$IList$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.IList.IsFixedSize.get
            get System$Collections$IList$IsFixedSize()
            {
                return this.IsFixedSize;
            }
            //Generated interface implemetation for System.Collections.IList.IndexOf(object?)
            System$Collections$IList$IndexOf()
            {
                return this.IndexOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Insert(int, object?)
            System$Collections$IList$Insert()
            {
                return this.Insert(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Remove(object?)
            System$Collections$IList$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            System$Collections$IList$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 824335;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180693519,"f":50331649},"n":"Count","d":824335,"h":12885726223,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":25770628111,"f":50331649},"n":"IsReadOnly","d":824335,"h":21475660815,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":34360562703,"f":50331649},"n":"IsFixedSize","d":824335,"h":30065595407,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":42950497295,"f":50331649},"n":"IsSynchronized","d":824335,"h":38655529999,"f":2097153},{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":51540431887,"f":50331649},"s":{"r":0,"d":0,"h":55835399183,"f":83886081},"n":"Item","o":"@$2","d":824335,"h":47245464591,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":64425333775,"f":50331649},"n":"SyncRoot","d":824335,"h":60130366479,"f":2097153}],"m":[{"r":655361,"p":[{"n":"value","p":131073}],"n":"Add","d":824335,"h":68720301071,"f":16777217},{"r":65537,"n":"Clear","d":824335,"h":73015268367,"f":16777217},{"r":262145,"p":[{"n":"value","p":131073}],"n":"Contains","d":824335,"h":77310235663,"f":16777217},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":824335,"h":81605202959,"f":16777217},{"r":31850497,"n":"GetEnumerator","d":824335,"h":85900170255,"f":16777217},{"r":655361,"p":[{"n":"value","p":131073}],"n":"IndexOf","d":824335,"h":90195137551,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"Insert","d":824335,"h":94490104847,"f":16777217},{"r":65537,"p":[{"n":"value","p":131073}],"n":"Remove","d":824335,"h":98785072143,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":824335,"h":103080039439,"f":16777217}],"l":[{"t":32047105,"n":"_list","d":824335,"h":4295791631,"f":4194306}],"c":[{"p":[{"n":"list","p":32047105}],"n":".ctor","o":"$ctor$1","d":824335,"h":8590758927,"f":16777224}],"i":[32047105,31457281,31719425],"h":824335}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.ReadOnlyList`; }
        });
        
        $asm.$cls("$so.System.Collections.Specialized.SingleItemReadOnlyList", ($self) => class SingleItemReadOnlyList extends $.$$.System.Object
        {
            /*object?*/ _item = null;
            $ctor$1(/*object?*/ item)
            {
                super.$ctor();
                this._item = item;
                return this;
            }
            /*object?*/ get_Item(/*int*/ index)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNotEqual($.$$.System.Int32, index, 0, "index");
                return this._item;
            }
            /*void*/ set_Item(/*int*/ index, /*object?*/ value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*bool */ get IsFixedSize()
            {
                return true;
            }
            /*bool */ get IsReadOnly()
            {
                return true;
            }
            /*int */ get Count()
            {
                return 1;
            }
            /*bool */ get IsSynchronized()
            {
                return false;
            }
            /*object */ get SyncRoot()
            {
                return this;
            }
            /*IEnumerator */ GetEnumerator()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    yield this._item;
                }.bind(this)).GetEnumerator();
            }
            /*bool */ Contains(/*object?*/ value)
            {
                return this._item === null ? value === null : $.$$.System.Object.Equals$1.call(this._item, value);
            }
            /*int */ IndexOf(/*object?*/ value)
            {
                return this.Contains(value) ? 0 : -1;
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                $.$so.System.Collections.CollectionHelpers.ValidateCopyToArguments(1, array, index);
                array.SetValue$2(this._item, index);
            }
            /*int */ Add(/*object?*/ value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Clear()
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Insert(/*int*/ index, /*object?*/ value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Remove(/*object?*/ value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            //Generated interface implemetation for System.Collections.IList.this[int].get
            System$Collections$IList$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.this[int].set
            System$Collections$IList$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Add(object?)
            System$Collections$IList$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Contains(object?)
            System$Collections$IList$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Clear()
            System$Collections$IList$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.IsReadOnly.get
            get System$Collections$IList$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.IList.IsFixedSize.get
            get System$Collections$IList$IsFixedSize()
            {
                return this.IsFixedSize;
            }
            //Generated interface implemetation for System.Collections.IList.IndexOf(object?)
            System$Collections$IList$IndexOf()
            {
                return this.IndexOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Insert(int, object?)
            System$Collections$IList$Insert()
            {
                return this.Insert(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Remove(object?)
            System$Collections$IList$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            System$Collections$IList$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 889871;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180759055,"f":50331649},"s":{"r":0,"d":0,"h":21475726351,"f":83886081},"n":"Item","o":"@$2","d":889871,"h":12885791759,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":30065660943,"f":50331649},"n":"IsFixedSize","d":889871,"h":25770693647,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":38655595535,"f":50331649},"n":"IsReadOnly","d":889871,"h":34360628239,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":47245530127,"f":50331649},"n":"Count","d":889871,"h":42950562831,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":55835464719,"f":50331649},"n":"IsSynchronized","d":889871,"h":51540497423,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":64425399311,"f":50331649},"n":"SyncRoot","d":889871,"h":60130432015,"f":2097153}],"m":[{"r":31850497,"n":"GetEnumerator","d":889871,"h":68720366607,"f":16777217},{"r":262145,"p":[{"n":"value","p":131073}],"n":"Contains","d":889871,"h":73015333903,"f":16777217},{"r":655361,"p":[{"n":"value","p":131073}],"n":"IndexOf","d":889871,"h":77310301199,"f":16777217},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":889871,"h":81605268495,"f":16777217},{"r":655361,"p":[{"n":"value","p":131073}],"n":"Add","d":889871,"h":85900235791,"f":16777217},{"r":65537,"n":"Clear","d":889871,"h":90195203087,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"Insert","d":889871,"h":94490170383,"f":16777217},{"r":65537,"p":[{"n":"value","p":131073}],"n":"Remove","d":889871,"h":98785137679,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":889871,"h":103080104975,"f":16777217}],"l":[{"t":131073,"n":"_item","d":889871,"h":4295857167,"f":4194306}],"c":[{"p":[{"n":"item","p":131073}],"n":".ctor","o":"$ctor$1","d":889871,"h":8590824463,"f":16777217}],"i":[32047105,31457281,31719425],"h":889871}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.SingleItemReadOnlyList`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.TypeConverterAttribute", ($self) => class TypeConverterAttribute extends $.$$.System.Attribute
        {
            /*TypeConverterAttribute*/ static Default = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this.ConverterTypeName = $.$$.System.String.Empty;
                }
                return this;
            }
            $ctor$4(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                    this.ConverterTypeName = type.AssemblyQualifiedName;
                }
                return this;
            }
            $ctor$3(/*string*/ typeName)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(typeName, "typeName");
                    this.ConverterTypeName = typeName;
                }
                return this;
            }
            /*string*/ ConverterTypeName = null;
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$so.System.ComponentModel.TypeConverterAttribute, { set $v(v){ other = v; } }) && $.$$.System.String.op_Equality(other.ConverterTypeName, this.ConverterTypeName);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$so.System.ComponentModel.TypeConverterAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.String.GetHashCode.call(this.ConverterTypeName);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$so.System.ComponentModel.TypeConverterAttribute.GetHashCode.apply(this, arguments); }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$so.System.ComponentModel.TypeConverterAttribute().$ctor$2();
                }
            }
            static $h = 1479695;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30066250767,"f":50331649},"n":"ConverterTypeName","d":1479695,"h":25771283471,"f":2097153}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1479695,"h":34361218063,"f":16809985},{"r":655361,"n":"GetHashCode","d":1479695,"h":38656185359,"f":16809985}],"l":[{"t":1479695,"n":"Default","d":1479695,"h":4296446991,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$2","d":1479695,"h":8591414287,"f":16777217},{"p":[{"n":"type","p":142475265}],"n":".ctor","o":"$ctor$4","d":1479695,"h":12886381583,"f":16777217},{"p":[{"n":"typeName","p":1310721}],"n":".ctor","o":"$ctor$3","d":1479695,"h":17181348879,"f":16777217}],"h":1479695,"a":[{"t":14745601,"c":21489582081,"a":[{"v":32767,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.TypeConverterAttribute`; }
        });
        
        $asm.$cls("$so.System.Windows.Markup.ValueSerializerAttribute", ($self) => class ValueSerializerAttribute extends $.$$.System.Attribute
        {
            /*Type?*/ _valueSerializerType = null;
            /*string?*/ _valueSerializerTypeName = null;
            $ctor$3(/*Type*/ valueSerializerType)
            {
                super.$ctor$1();
                {
                    this._valueSerializerType = valueSerializerType;
                }
                return this;
            }
            $ctor$2(/*string*/ valueSerializerTypeName)
            {
                super.$ctor$1();
                {
                    this._valueSerializerTypeName = valueSerializerTypeName;
                }
                return this;
            }
            /*Type */ get ValueSerializerType()
            {
                if ($.$$.System.Type.op_Equality$1(this._valueSerializerType, null) && $.$$.System.String.op_Inequality(this._valueSerializerTypeName, null))
                {
                    this._valueSerializerType = $.$$.System.Type.GetType$8(this._valueSerializerTypeName);
                }
                return this._valueSerializerType;
            }
            /*string */ get ValueSerializerTypeName()
            {
                if ($.$$.System.Type.op_Inequality$1(this._valueSerializerType, null))
                {
                    return this._valueSerializerType.AssemblyQualifiedName;
                }
                else 
                {
                    return this._valueSerializerTypeName;
                }
            }
            static $h = 1807375;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":25771611151,"f":50331649},"n":"ValueSerializerType","d":1807375,"h":21476643855,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":34361545743,"f":50331649},"n":"ValueSerializerTypeName","d":1807375,"h":30066578447,"f":2097153}],"l":[{"t":142475265,"n":"_valueSerializerType","d":1807375,"h":4296774671,"f":4194306},{"t":1310721,"n":"_valueSerializerTypeName","d":1807375,"h":8591741967,"f":4194306}],"c":[{"p":[{"n":"valueSerializerType","p":142475265}],"n":".ctor","o":"$ctor$3","d":1807375,"h":12886709263,"f":16777217},{"p":[{"n":"valueSerializerTypeName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1807375,"h":17181676559,"f":16777217}],"h":1807375,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1244,"t":14680065}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":true,"t":262145}]},{"t":96141313,"c":4391108609,"a":[{"v":"WindowsBase, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Windows.Markup.ValueSerializerAttribute`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.TypeDescriptionProviderAttribute", ($self) => class TypeDescriptionProviderAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*string*/ typeName)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(typeName, "typeName");
                    this.TypeName = typeName;
                }
                return this;
            }
            $ctor$3(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                    this.TypeName = type.AssemblyQualifiedName;
                }
                return this;
            }
            /*string*/ TypeName = null;
            static $h = 1545231;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21476381711,"f":50331649},"n":"TypeName","d":1545231,"h":17181414415,"f":2097153}],"c":[{"p":[{"n":"typeName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1545231,"h":4296512527,"f":16777217},{"p":[{"n":"type","p":142475265}],"n":".ctor","o":"$ctor$3","d":1545231,"h":8591479823,"f":16777217}],"h":1545231,"a":[{"t":14745601,"c":21489582081,"a":[{"v":4,"t":14680065}],"n":[{"n":"Inherited","v":true,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.TypeDescriptionProviderAttribute`; }
        });
        
        $asm.$cls("$so.System.Collections.ObjectModel.KeyedCollection<,>", (TKey, TItem) => $asm.$gt("$so.System.Collections.ObjectModel.KeyedCollection<,>", [TKey, TItem], ($self) => class KeyedCollection$$$ extends $.$$.System.Collections.ObjectModel.Collection$$(TItem)
        {
            /*int*/ static DefaultThreshold = 0;
            /*IEqualityComparer<TKey>*/ comparer = null;
            /*Dictionary<TKey, TItem>?*/ dict = null;
            /*int*/ keyCount = 0;
            /*int*/ threshold = 0;
            $ctor$3()
            {
                this.$ctor$4(null, 0/*DefaultThreshold*/);
                {
                }
                return this;
            }
            $ctor$5(/*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$4(comparer, 0/*DefaultThreshold*/);
                {
                }
                return this;
            }
            $ctor$4(/*IEqualityComparer<TKey>?*/ comparer, /*int*/ dictionaryCreationThreshold)
            {
                super.$ctor$2(new ($.$$.System.Collections.Generic.List$$(TItem))().$ctor$1());
                {
                    if (dictionaryCreationThreshold < -1)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("dictionaryCreationThreshold", $.$so.System.SR.ArgumentOutOfRange_InvalidThreshold);
                    }
                    this.comparer = comparer ?? $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default;
                    this.threshold = dictionaryCreationThreshold === -1 ? 2147483647/*int.MaxValue*/ : dictionaryCreationThreshold;
                }
                return this;
            }
            /*List<TItem> */ get Items$1()
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$is(super.Items, $.$$.System.Collections.Generic.List$$(TItem)), "base.Items is List<TItem>");
                return $.$cast(super.Items, $.$$.System.Collections.Generic.List$$(TItem));
            }
            /*IEqualityComparer<TKey> */ get Comparer()
            {
                return this.comparer;
            }
            /*TItem*/ get_Item$1(/*TKey*/ key)
            {
                /*TItem*/ let item;
                if (this.TryGetValue(key, $.$ref(() => item, ($v) => item = $v, TItem)))
                {
                    return item;
                }
                throw new $.$$.System.Collections.Generic.KeyNotFoundException().$ctor$12($.$so.System.SR.Format$6($.$so.System.SR.Arg_KeyNotFoundWithKey, $.$$.System.Object.ToString.call(key)));
            }
            /*bool */ Contains$1(/*TKey*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                if (this.dict !== null)
                {
                    return this.dict.ContainsKey(key);
                }
                var $en2 = this.Items$1.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        if (this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(this.GetKeyForItem(item), key, [TKey]))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*bool */ TryGetValue(/*TKey*/ key, /*out TItem*/ item)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                if (this.dict !== null)
                {
                    return this.dict.TryGetValue(key, item);
                }
                var $en2 = this.Items$1.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var itemInItems = $en2.Current;
                    {
                        /*TKey*/ let keyInItems = this.GetKeyForItem(itemInItems);
                        if ($.$box(keyInItems, TKey) !== null && this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(key, keyInItems, [TKey]))
                        {
                            item.$v = itemInItems;
                            return true;
                        }
                    }
                }
                item.$v = $.$default(TItem);
                return false;
            }
            /*bool */ ContainsItem(/*TItem*/ item)
            {
                /*TKey*/ let key;
                if ((this.dict === null) || (($.$box(key = this.GetKeyForItem(item), TKey)) === null))
                {
                    return this.Items$1.Contains(item);
                }
                /*TItem*/ let itemInDict;
                if (this.dict.TryGetValue(key, $.$ref(() => itemInDict, ($v) => itemInDict = $v, TItem)))
                {
                    return $.$$.System.Collections.Generic.EqualityComparer$$(TItem).Default.Equals$2(itemInDict, item);
                }
                return false;
            }
            /*bool */ Remove$1(/*TKey*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                if (this.dict !== null)
                {
                    /*TItem*/ let item;
                    return this.dict.TryGetValue(key, $.$ref(() => item, ($v) => item = $v, TItem)) && this.Remove(item);
                }
                for(/*int*/ let i = 0; i < this.Items$1.Count; i++)
                {
                    if (this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(this.GetKeyForItem(this.Items$1.get_Item(i)), key, [TKey]))
                    {
                        this.RemoveItem(i);
                        return true;
                    }
                }
                return false;
            }
            /*IDictionary<TKey, TItem>? */ get Dictionary()
            {
                return this.dict;
            }
            /*void */ ChangeItemKey(/*TItem*/ item, /*TKey*/ newKey)
            {
                if (!this.ContainsItem(item))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.Argument_ItemNotExist, "item");
                }
                /*TKey*/ let oldKey = this.GetKeyForItem(item);
                if (!this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(oldKey, newKey, [TKey]))
                {
                    if ($.$box(newKey, TKey) !== null)
                    {
                        this.AddKey(newKey, item);
                    }
                    if ($.$box(oldKey, TKey) !== null)
                    {
                        this.RemoveKey(oldKey);
                    }
                }
            }
            /*void */ ClearItems()
            {
                super.ClearItems();
                this.dict?.Clear();
                this.keyCount = 0;
            }
            /*void */ InsertItem(/*int*/ index, /*TItem*/ item)
            {
                /*TKey*/ let key = this.GetKeyForItem(item);
                if ($.$box(key, TKey) !== null)
                {
                    this.AddKey(key, item);
                }
                super.InsertItem(index, item);
            }
            /*void */ RemoveItem(/*int*/ index)
            {
                /*TKey*/ let key = this.GetKeyForItem(this.Items$1.get_Item(index));
                if ($.$box(key, TKey) !== null)
                {
                    this.RemoveKey(key);
                }
                super.RemoveItem(index);
            }
            /*void */ SetItem(/*int*/ index, /*TItem*/ item)
            {
                /*TKey*/ let newKey = this.GetKeyForItem(item);
                /*TKey*/ let oldKey = this.GetKeyForItem(this.Items$1.get_Item(index));
                if (this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(oldKey, newKey, [TKey]))
                {
                    if ($.$box(newKey, TKey) !== null && this.dict !== null)
                    {
                        this.dict.set_Item(newKey, item);
                    }
                }
                else 
                {
                    if ($.$box(newKey, TKey) !== null)
                    {
                        this.AddKey(newKey, item);
                    }
                    if ($.$box(oldKey, TKey) !== null)
                    {
                        this.RemoveKey(oldKey);
                    }
                }
                super.SetItem(index, item);
            }
            /*void */ AddKey(/*TKey*/ key, /*TItem*/ item)
            {
                if (this.dict !== null)
                {
                    this.dict.Add(key, item);
                }
                else if (this.keyCount === this.threshold)
                {
                    this.CreateDictionary();
                    this.dict.Add(key, item);
                }
                else 
                {
                    if (this.Contains$1(key))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.Format$6($.$so.System.SR.Argument_AddingDuplicate, $.$box(key, TKey)), "key");
                    }
                    this.keyCount++;
                }
            }
            /*void */ CreateDictionary()
            {
                this.dict = new ($.$$.System.Collections.Generic.Dictionary$$$(TKey, TItem))().$ctor$6(this.comparer);
                var $en2 = this.Items$1.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        /*TKey*/ let key = this.GetKeyForItem(item);
                        if ($.$box(key, TKey) !== null)
                        {
                            this.dict.Add(key, item);
                        }
                    }
                }
            }
            /*void */ RemoveKey(/*TKey*/ key)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$box(key, TKey) !== null, "key shouldn't be null!");
                if (this.dict !== null)
                {
                    this.dict.Remove$1(key);
                }
                else 
                {
                    this.keyCount--;
                }
            }
            static $h = 300047;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$$.System.Collections.Generic.List$$(TItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331650},"n":"Items","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097154},{"p":$.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":50331649},"n":"Comparer","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2097153},{"p":TItem?.$h??1572864,"i":[{"n":"key","p":TKey?.$h??1507328}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":50331649},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2097153},{"p":$.$$.System.Collections.Generic.IDictionary$$$(TKey, TItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1400000000n),"f":50331652},"n":"Dictionary","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":2097156}],"m":[{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328}],"n":"Contains","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16777217},{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"item","p":TItem?.$h??1572864,"f":2}],"n":"TryGetValue","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16777217},{"r":262145,"p":[{"n":"item","p":TItem?.$h??1572864}],"n":"ContainsItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777218},{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328}],"n":"Remove","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777217},{"r":65537,"p":[{"n":"item","p":TItem?.$h??1572864},{"n":"newKey","p":TKey?.$h??1507328}],"n":"ChangeItemKey","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777220},{"r":65537,"n":"ClearItems","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":16809988},{"r":TKey?.$h??1507328,"p":[{"n":"item","p":TItem?.$h??1572864}],"n":"GetKeyForItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":16777476},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":TItem?.$h??1572864}],"n":"InsertItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":16809988},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":16809988},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":TItem?.$h??1572864}],"n":"SetItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":16809988},{"r":65537,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"item","p":TItem?.$h??1572864}],"n":"AddKey","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":16777218},{"r":65537,"n":"CreateDictionary","d":this.$h,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":16777218},{"r":65537,"p":[{"n":"key","p":TKey?.$h??1507328}],"n":"RemoveKey","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":16777218}],"l":[{"t":655361,"n":"DefaultThreshold","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194338},{"t":$.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h,"n":"comparer","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":$.$$.System.Collections.Generic.Dictionary$$$(TKey, TItem).$h,"n":"dict","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":655361,"n":"keyCount","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306},{"t":655361,"n":"threshold","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777220},{"p":[{"n":"comparer","p":$.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777220},{"p":[{"n":"comparer","p":$.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h},{"n":"dictionaryCreationThreshold","p":655361}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777220}],"i":[$.$$.System.Collections.Generic.IList$$(TItem).$h,$.$$.System.Collections.Generic.ICollection$$(TItem).$h,32047105,31457281,$.$$.System.Collections.Generic.IReadOnlyList$$(TItem).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$(TItem).$h,$.$$.System.Collections.Generic.IEnumerable$$(TItem).$h,31719425],"g":[TKey?.$h??1507328,TItem?.$h??1572864],"s":[{"n":"TKey","f":64},null],"r":2,"h":this.$h,"a":[{"t":118095873,"c":4413063169},{"t":37945345,"c":8627879937,"a":[{"v":null,"t":142475265}]},{"t":37617665,"c":8627552257,"a":[{"v":"Count = {Count}","t":1310721}]},{"t":96141313,"c":4391108609,"a":[{"v":"mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Collections.ObjectModel.Collection$$(TItem); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$(TItem), $.$$.System.Collections.Generic.ICollection$$(TItem), $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyList$$(TItem), $.$$.System.Collections.Generic.IReadOnlyCollection$$(TItem), $.$$.System.Collections.Generic.IEnumerable$$(TItem), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.ObjectModel.KeyedCollection<${TKey?.$fullName},${TItem?.$fullName}>`; }
        }));
        
        $asm.$cls("$so.System.ComponentModel.PropertyChangedEventHandler", ($self) => class PropertyChangedEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 1283087;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1217551}],"n":"Invoke","d":1283087,"h":8591217679,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":1217551},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":1283087,"h":12886184975,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1283087,"h":17181152271,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1283087,"h":4296250383,"f":16777217}],"i":[57212929,113246209],"h":1283087}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.ComponentModel.PropertyChangedEventHandler`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.PropertyChangingEventHandler", ($self) => class PropertyChangingEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 1414159;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1348623}],"n":"Invoke","d":1414159,"h":8591348751,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":1348623},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":1414159,"h":12886316047,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1414159,"h":17181283343,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1414159,"h":4296381455,"f":16777217}],"i":[57212929,113246209],"h":1414159}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.ComponentModel.PropertyChangingEventHandler`; }
        });
        
        $asm.$cls("$so.System.Collections.Specialized.NotifyCollectionChangedEventHandler", ($self) => class NotifyCollectionChangedEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 758799;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":693263}],"n":"Invoke","d":758799,"h":8590693391,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":693263},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":758799,"h":12885660687,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":758799,"h":17180627983,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":758799,"h":4295726095,"f":16777217}],"i":[57212929,113246209],"h":758799}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Collections.Specialized.NotifyCollectionChangedEventHandler`; }
        });
        
        $asm.$str("$so.System.Collections.Specialized.NotifyCollectionChangedAction", ($self) => class NotifyCollectionChangedAction extends $.$$.System.Enum
        {
            static Add = 0;
            static Remove = 1;
            static Replace = 2;
            static Move = 3;
            static Reset = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Remove": 1n,
                    "Replace": 2n,
                    "Move": 3n,
                    "Reset": 4n
                };
            }
            static $h = 627727;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":627727,"n":"Add","d":627727,"h":4295595023,"f":4194337},{"t":627727,"n":"Remove","d":627727,"h":8590562319,"f":4194337},{"t":627727,"n":"Replace","d":627727,"h":12885529615,"f":4194337},{"t":627727,"n":"Move","d":627727,"h":17180496911,"f":4194337},{"t":627727,"n":"Reset","d":627727,"h":21475464207,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":627727,"h":25770431503,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":627727}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Collections.Specialized.NotifyCollectionChangedAction`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.DataErrorsChangedEventArgs", ($self) => class DataErrorsChangedEventArgs extends $.$$.System.EventArgs
        {
            $ctor$2(/*string?*/ propertyName)
            {
                super.$ctor$1();
                {
                    this.PropertyName = propertyName;
                }
                return this;
            }
            /*string?*/ PropertyName = null;
            static $h = 955407;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180824591,"f":50331777},"n":"PropertyName","d":955407,"h":12885857295,"f":2097281}],"c":[{"p":[{"n":"propertyName","p":1310721}],"n":".ctor","o":"$ctor$2","d":955407,"h":4295922703,"f":16777217}],"h":955407}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.ComponentModel.DataErrorsChangedEventArgs`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.PropertyChangedEventArgs", ($self) => class PropertyChangedEventArgs extends $.$$.System.EventArgs
        {
            $ctor$2(/*string?*/ propertyName)
            {
                super.$ctor$1();
                {
                    this.PropertyName = propertyName;
                }
                return this;
            }
            /*string?*/ PropertyName = null;
            static $h = 1217551;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181086735,"f":50331777},"n":"PropertyName","d":1217551,"h":12886119439,"f":2097281}],"c":[{"p":[{"n":"propertyName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1217551,"h":4296184847,"f":16777217}],"h":1217551}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.ComponentModel.PropertyChangedEventArgs`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.PropertyChangingEventArgs", ($self) => class PropertyChangingEventArgs extends $.$$.System.EventArgs
        {
            $ctor$2(/*string?*/ propertyName)
            {
                super.$ctor$1();
                {
                    this.PropertyName = propertyName;
                }
                return this;
            }
            /*string?*/ PropertyName = null;
            static $h = 1348623;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181217807,"f":50331777},"n":"PropertyName","d":1348623,"h":12886250511,"f":2097281}],"c":[{"p":[{"n":"propertyName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1348623,"h":4296315919,"f":16777217}],"h":1348623}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.ComponentModel.PropertyChangingEventArgs`; }
        });
        
        $asm.$cls("$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs", ($self) => class NotifyCollectionChangedEventArgs extends $.$$.System.EventArgs
        {
            /*NotifyCollectionChangedAction*/ _action = 0;
            /*IList?*/ _newItems = null;
            /*IList?*/ _oldItems = null;
            /*int*/ _newStartingIndex = -1;
            /*int*/ _oldStartingIndex = -1;
            $ctor$12(/*NotifyCollectionChangedAction*/ action)
            {
                super.$ctor$1();
                {
                    if (action !== 4/*NotifyCollectionChangedAction.Reset*/)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.Format$6($.$so.System.SR.WrongActionForCtor, $.$box(4/*NotifyCollectionChangedAction.Reset*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    this._action = action;
                }
                return this;
            }
            $ctor$11(/*NotifyCollectionChangedAction*/ action, /*object?*/ changedItem)
            {
                this.$ctor$8(action, changedItem, -1);
                {
                }
                return this;
            }
            $ctor$8(/*NotifyCollectionChangedAction*/ action, /*object?*/ changedItem, /*int*/ index)
            {
                super.$ctor$1();
                {
                    switch(action)
                    {
                        case 4/*NotifyCollectionChangedAction.Reset*/:
                        if (changedItem !== null)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.ResetActionRequiresNullItem, "action");
                        }
                        if (index !== -1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.ResetActionRequiresIndexMinus1, "action");
                        }
                        break;
                        case 0/*NotifyCollectionChangedAction.Add*/:
                        this._newItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(changedItem);
                        this._newStartingIndex = index;
                        break;
                        case 1/*NotifyCollectionChangedAction.Remove*/:
                        this._oldItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(changedItem);
                        this._oldStartingIndex = index;
                        break;
                        default:
                        throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.MustBeResetAddOrRemoveActionForCtor, "action");
                    }
                    this._action = action;
                }
                return this;
            }
            $ctor$6(/*NotifyCollectionChangedAction*/ action, /*IList?*/ changedItems)
            {
                this.$ctor$5(action, changedItems, -1);
                {
                }
                return this;
            }
            $ctor$5(/*NotifyCollectionChangedAction*/ action, /*IList?*/ changedItems, /*int*/ startingIndex)
            {
                super.$ctor$1();
                {
                    switch(action)
                    {
                        case 4/*NotifyCollectionChangedAction.Reset*/:
                        if (changedItems !== null)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.ResetActionRequiresNullItem, "action");
                        }
                        if (startingIndex !== -1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.ResetActionRequiresIndexMinus1, "action");
                        }
                        break;
                        case 0/*NotifyCollectionChangedAction.Add*/:
                        case 1/*NotifyCollectionChangedAction.Remove*/:
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(changedItems, "changedItems");
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, startingIndex, -1, "startingIndex");
                        if (action === 0/*NotifyCollectionChangedAction.Add*/)
                        {
                            this._newItems = new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(changedItems);
                            this._newStartingIndex = startingIndex;
                        }
                        else 
                        {
                            this._oldItems = new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(changedItems);
                            this._oldStartingIndex = startingIndex;
                        }
                        break;
                        default:
                        throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.MustBeResetAddOrRemoveActionForCtor, "action");
                    }
                    this._action = action;
                }
                return this;
            }
            $ctor$10(/*NotifyCollectionChangedAction*/ action, /*object?*/ newItem, /*object?*/ oldItem)
            {
                this.$ctor$9(action, newItem, oldItem, -1);
                {
                }
                return this;
            }
            $ctor$9(/*NotifyCollectionChangedAction*/ action, /*object?*/ newItem, /*object?*/ oldItem, /*int*/ index)
            {
                super.$ctor$1();
                {
                    if (action !== 2/*NotifyCollectionChangedAction.Replace*/)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.Format$6($.$so.System.SR.WrongActionForCtor, $.$box(2/*NotifyCollectionChangedAction.Replace*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    this._action = action;
                    this._newItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(newItem);
                    this._oldItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(oldItem);
                    this._newStartingIndex = this._oldStartingIndex = index;
                }
                return this;
            }
            $ctor$3(/*NotifyCollectionChangedAction*/ action, /*IList*/ newItems, /*IList*/ oldItems)
            {
                this.$ctor$2(action, newItems, oldItems, -1);
                {
                }
                return this;
            }
            $ctor$2(/*NotifyCollectionChangedAction*/ action, /*IList*/ newItems, /*IList*/ oldItems, /*int*/ startingIndex)
            {
                super.$ctor$1();
                {
                    if (action !== 2/*NotifyCollectionChangedAction.Replace*/)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.Format$6($.$so.System.SR.WrongActionForCtor, $.$box(2/*NotifyCollectionChangedAction.Replace*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(newItems, "newItems");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(oldItems, "oldItems");
                    this._action = action;
                    this._newItems = new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(newItems);
                    this._oldItems = new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(oldItems);
                    this._newStartingIndex = this._oldStartingIndex = startingIndex;
                }
                return this;
            }
            $ctor$7(/*NotifyCollectionChangedAction*/ action, /*object?*/ changedItem, /*int*/ index, /*int*/ oldIndex)
            {
                super.$ctor$1();
                {
                    if (action !== 3/*NotifyCollectionChangedAction.Move*/)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.Format$6($.$so.System.SR.WrongActionForCtor, $.$box(3/*NotifyCollectionChangedAction.Move*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                    this._action = action;
                    this._newItems = this._oldItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(changedItem);
                    this._newStartingIndex = index;
                    this._oldStartingIndex = oldIndex;
                }
                return this;
            }
            $ctor$4(/*NotifyCollectionChangedAction*/ action, /*IList?*/ changedItems, /*int*/ index, /*int*/ oldIndex)
            {
                super.$ctor$1();
                {
                    if (action !== 3/*NotifyCollectionChangedAction.Move*/)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$so.System.SR.Format$6($.$so.System.SR.WrongActionForCtor, $.$box(3/*NotifyCollectionChangedAction.Move*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                    this._action = action;
                    this._newItems = this._oldItems = !(changedItems === null) ? new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(changedItems) : null;
                    this._newStartingIndex = index;
                    this._oldStartingIndex = oldIndex;
                }
                return this;
            }
            /*NotifyCollectionChangedAction */ get Action()
            {
                return this._action;
            }
            /*IList? */ get NewItems()
            {
                return this._newItems;
            }
            /*IList? */ get OldItems()
            {
                return this._oldItems;
            }
            /*int */ get NewStartingIndex()
            {
                return this._newStartingIndex;
            }
            /*int */ get OldStartingIndex()
            {
                return this._oldStartingIndex;
            }
            static $h = 693263;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":627727,"g":{"r":0,"d":0,"h":77310104591,"f":50331649},"n":"Action","d":693263,"h":73015137295,"f":2097153},{"p":32047105,"g":{"r":0,"d":0,"h":85900039183,"f":50331649},"n":"NewItems","d":693263,"h":81605071887,"f":2097153},{"p":32047105,"g":{"r":0,"d":0,"h":94489973775,"f":50331649},"n":"OldItems","d":693263,"h":90195006479,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":103079908367,"f":50331649},"n":"NewStartingIndex","d":693263,"h":98784941071,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":111669842959,"f":50331649},"n":"OldStartingIndex","d":693263,"h":107374875663,"f":2097153}],"l":[{"t":627727,"n":"_action","d":693263,"h":4295660559,"f":4194306},{"t":32047105,"n":"_newItems","d":693263,"h":8590627855,"f":4194306},{"t":32047105,"n":"_oldItems","d":693263,"h":12885595151,"f":4194306},{"t":655361,"n":"_newStartingIndex","d":693263,"h":17180562447,"f":4194306},{"t":655361,"n":"_oldStartingIndex","d":693263,"h":21475529743,"f":4194306}],"c":[{"p":[{"n":"action","p":627727}],"n":".ctor","o":"$ctor$12","d":693263,"h":25770497039,"f":16777217},{"p":[{"n":"action","p":627727},{"n":"changedItem","p":131073}],"n":".ctor","o":"$ctor$11","d":693263,"h":30065464335,"f":16777217},{"p":[{"n":"action","p":627727},{"n":"changedItem","p":131073},{"n":"index","p":655361}],"n":".ctor","o":"$ctor$8","d":693263,"h":34360431631,"f":16777217},{"p":[{"n":"action","p":627727},{"n":"changedItems","p":32047105}],"n":".ctor","o":"$ctor$6","d":693263,"h":38655398927,"f":16777217},{"p":[{"n":"action","p":627727},{"n":"changedItems","p":32047105},{"n":"startingIndex","p":655361}],"n":".ctor","o":"$ctor$5","d":693263,"h":42950366223,"f":16777217},{"p":[{"n":"action","p":627727},{"n":"newItem","p":131073},{"n":"oldItem","p":131073}],"n":".ctor","o":"$ctor$10","d":693263,"h":47245333519,"f":16777217},{"p":[{"n":"action","p":627727},{"n":"newItem","p":131073},{"n":"oldItem","p":131073},{"n":"index","p":655361}],"n":".ctor","o":"$ctor$9","d":693263,"h":51540300815,"f":16777217},{"p":[{"n":"action","p":627727},{"n":"newItems","p":32047105},{"n":"oldItems","p":32047105}],"n":".ctor","o":"$ctor$3","d":693263,"h":55835268111,"f":16777217},{"p":[{"n":"action","p":627727},{"n":"newItems","p":32047105},{"n":"oldItems","p":32047105},{"n":"startingIndex","p":655361}],"n":".ctor","o":"$ctor$2","d":693263,"h":60130235407,"f":16777217},{"p":[{"n":"action","p":627727},{"n":"changedItem","p":131073},{"n":"index","p":655361},{"n":"oldIndex","p":655361}],"n":".ctor","o":"$ctor$7","d":693263,"h":64425202703,"f":16777217},{"p":[{"n":"action","p":627727},{"n":"changedItems","p":32047105},{"n":"index","p":655361},{"n":"oldIndex","p":655361}],"n":".ctor","o":"$ctor$4","d":693263,"h":68720169999,"f":16777217}],"h":693263}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.Collections.Specialized.NotifyCollectionChangedEventArgs`; }
        });
        
        $asm.$cls("$so.System.Collections.ObjectModel.ReadOnlyObservableCollection<>", (T) => $asm.$gt("$so.System.Collections.ObjectModel.ReadOnlyObservableCollection<>", [T], ($self) => class ReadOnlyObservableCollection$$ extends $.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(T)
        {
            $ctor$2(/*ObservableCollection<T>*/ list)
            {
                super.$ctor$1(list);
                {
                    ($.$cast(this.Items, $.$so.System.Collections.Specialized.INotifyCollectionChanged)).System$Collections$Specialized$INotifyCollectionChanged$add_CollectionChanged(new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventHandler().$ctor(this, this.HandleCollectionChanged));
                    ($.$cast(this.Items, $.$so.System.ComponentModel.INotifyPropertyChanged)).System$ComponentModel$INotifyPropertyChanged$add_PropertyChanged(new $.$so.System.ComponentModel.PropertyChangedEventHandler().$ctor(this, this.HandlePropertyChanged));
                }
                return this;
            }
            /*ReadOnlyObservableCollection<T>*/ static Empty$1 = null;
            /*NotifyCollectionChangedEventHandler?*/ System$Collections$Specialized$INotifyCollectionChanged$add_CollectionChanged(value)
            {
                return this.add_CollectionChanged(value);
            }
            /*NotifyCollectionChangedEventHandler?*/ System$Collections$Specialized$INotifyCollectionChanged$remove_CollectionChanged(value)
            {
                this.remove_CollectionChanged(value);
            }
            /*NotifyCollectionChangedEventHandler?*/ CollectionChanged = null;
            add_CollectionChanged(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                this.CollectionChanged = $.$$.System.Delegate.Combine(this.CollectionChanged, value);
            }
            remove_CollectionChanged(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                this.CollectionChanged = $.$$.System.Delegate.Remove(this.CollectionChanged, value);
            }
            /*void */ OnCollectionChanged(/*NotifyCollectionChangedEventArgs*/ args)
            {
                this.CollectionChanged?.Invoke(this, args);
            }
            /*PropertyChangedEventHandler?*/ System$ComponentModel$INotifyPropertyChanged$add_PropertyChanged(value)
            {
                return this.add_PropertyChanged(value);
            }
            /*PropertyChangedEventHandler?*/ System$ComponentModel$INotifyPropertyChanged$remove_PropertyChanged(value)
            {
                this.remove_PropertyChanged(value);
            }
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                this.PropertyChanged = $.$$.System.Delegate.Combine(this.PropertyChanged, value);
            }
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                this.PropertyChanged = $.$$.System.Delegate.Remove(this.PropertyChanged, value);
            }
            /*void */ OnPropertyChanged(/*PropertyChangedEventArgs*/ args)
            {
                this.PropertyChanged?.Invoke(this, args);
            }
            /*void */ HandleCollectionChanged(/*object?*/ sender, /*NotifyCollectionChangedEventArgs*/ e)
            {
                this.OnCollectionChanged(e);
            }
            /*void */ HandlePropertyChanged(/*object?*/ sender, /*PropertyChangedEventArgs*/ e)
            {
                this.OnPropertyChanged(e);
            }
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged
            System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged()
            {
                this.System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged;
            }
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                this.System$ComponentModel$INotifyPropertyChanged$PropertyChanged;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty$1 = new ($.$so.System.Collections.ObjectModel.ReadOnlyObservableCollection$$(T))().$ctor$2(new ($.$so.System.Collections.ObjectModel.ObservableCollection$$(T))().$ctor$3());
                }
            }
            static $h = 496655;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":this.$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331681},"n":"Empty","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097185}],"m":[{"r":65537,"p":[{"n":"args","p":693263}],"n":"OnCollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777348},{"r":65537,"p":[{"n":"args","p":1217551}],"n":"OnPropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777348},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":693263}],"n":"HandleCollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16777218},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1217551}],"n":"HandlePropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777218}],"c":[{"p":[{"n":"list","p":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"e":[{"e":758799,"m":{"r":65537,"p":[{"n":"value","p":758799}],"n":"{562191}.add_CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$add_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":150994946},"r":{"r":65537,"p":[{"n":"value","p":758799}],"n":"{562191}.remove_CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$remove_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":285212674},"n":"System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":8388610},{"e":758799,"m":{"r":65537,"p":[{"n":"value","p":758799}],"n":"add_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":150995076},"r":{"r":65537,"p":[{"n":"value","p":758799}],"n":"remove_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":285212804},"n":"CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":8388740},{"e":1283087,"m":{"r":65537,"p":[{"n":"value","p":1283087}],"n":"{1086479}.add_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$add_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":150994946},"r":{"r":65537,"p":[{"n":"value","p":1283087}],"n":"{1086479}.remove_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$remove_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":285212674},"n":"System.ComponentModel.INotifyPropertyChanged.PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":8388610},{"e":1283087,"m":{"r":65537,"p":[{"n":"value","p":1283087}],"n":"add_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":150995076},"r":{"r":65537,"p":[{"n":"value","p":1283087}],"n":"remove_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":285212804},"n":"PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":8388740}],"i":[$.$$.System.Collections.Generic.IList$$(T).$h,$.$$.System.Collections.Generic.ICollection$$(T).$h,32047105,31457281,$.$$.System.Collections.Generic.IReadOnlyList$$(T).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$$.System.Collections.Generic.IEnumerable$$(T).$h,31719425,562191,1086479],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":118095873,"c":4413063169},{"t":37945345,"c":8627879937,"a":[{"v":$.$so.System.Collections.Generic.CollectionDebugView$$().$h,"t":142475265}]},{"t":37617665,"c":8627552257,"a":[{"v":"Count = {Count}","t":1310721}]},{"t":96141313,"c":4391108609,"a":[{"v":"WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$(T), $.$$.System.Collections.Generic.ICollection$$(T), $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyList$$(T), $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable, $.$so.System.Collections.Specialized.INotifyCollectionChanged, $.$so.System.ComponentModel.INotifyPropertyChanged ]; }
            static get $fullName() { return `System.Collections.ObjectModel.ReadOnlyObservableCollection<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$so.System.Collections.ObjectModel.ObservableCollection<>", (T) => $asm.$gt("$so.System.Collections.ObjectModel.ObservableCollection<>", [T], ($self) => class ObservableCollection$$ extends $.$$.System.Collections.ObjectModel.Collection$$(T)
        {
            /*SimpleMonitor?*/ _monitor = null;
            /*int*/ _blockReentrancyCount = 0;
            $ctor$3()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*IEnumerable<T>*/ collection)
            {
                super.$ctor$2(new ($.$$.System.Collections.Generic.List$$(T))().$ctor$2($.$firstOf(collection, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("collection") })));
                {
                }
                return this;
            }
            $ctor$5(/*List<T>*/ list)
            {
                super.$ctor$2(new ($.$$.System.Collections.Generic.List$$(T))().$ctor$2($.$firstOf(list, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("list") })));
                {
                }
                return this;
            }
            /*void */ Move(/*int*/ oldIndex, /*int*/ newIndex)
            {
                return this.MoveItem(oldIndex, newIndex);
            }
            /*PropertyChangedEventHandler?*/ System$ComponentModel$INotifyPropertyChanged$add_PropertyChanged(value)
            {
                return this.add_PropertyChanged(value);
            }
            /*PropertyChangedEventHandler?*/ System$ComponentModel$INotifyPropertyChanged$remove_PropertyChanged(value)
            {
                this.remove_PropertyChanged(value);
            }
            /*NotifyCollectionChangedEventHandler?*/ CollectionChanged = null;
            add_CollectionChanged(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                this.CollectionChanged = $.$$.System.Delegate.Combine(this.CollectionChanged, value);
            }
            remove_CollectionChanged(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                this.CollectionChanged = $.$$.System.Delegate.Remove(this.CollectionChanged, value);
            }
            /*void */ ClearItems()
            {
                this.CheckReentrancy();
                super.ClearItems();
                this.OnCountPropertyChanged();
                this.OnIndexerPropertyChanged();
                this.OnCollectionReset();
            }
            /*void */ RemoveItem(/*int*/ index)
            {
                this.CheckReentrancy();
                /*T*/ let removedItem = this.get_Item(index);
                super.RemoveItem(index);
                this.OnCountPropertyChanged();
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged$1(1/*NotifyCollectionChangedAction.Remove*/, $.$box(removedItem, T), index);
            }
            /*void */ InsertItem(/*int*/ index, /*T*/ item)
            {
                this.CheckReentrancy();
                super.InsertItem(index, item);
                this.OnCountPropertyChanged();
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged$1(0/*NotifyCollectionChangedAction.Add*/, $.$box(item, T), index);
            }
            /*void */ SetItem(/*int*/ index, /*T*/ item)
            {
                this.CheckReentrancy();
                /*T*/ let originalItem = this.get_Item(index);
                super.SetItem(index, item);
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged$2(2/*NotifyCollectionChangedAction.Replace*/, $.$box(originalItem, T), $.$box(item, T), index);
            }
            /*void */ MoveItem(/*int*/ oldIndex, /*int*/ newIndex)
            {
                this.CheckReentrancy();
                /*T*/ let removedItem = this.get_Item(oldIndex);
                super.RemoveItem(oldIndex);
                super.InsertItem(newIndex, removedItem);
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged(3/*NotifyCollectionChangedAction.Move*/, $.$box(removedItem, T), newIndex, oldIndex);
            }
            /*void */ OnPropertyChanged(/*PropertyChangedEventArgs*/ e)
            {
                this.PropertyChanged?.Invoke(this, e);
            }
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                this.PropertyChanged = $.$$.System.Delegate.Combine(this.PropertyChanged, value);
            }
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                this.PropertyChanged = $.$$.System.Delegate.Remove(this.PropertyChanged, value);
            }
            /*void */ OnCollectionChanged$3(/*NotifyCollectionChangedEventArgs*/ e)
            {
                /*NotifyCollectionChangedEventHandler?*/ let handler = this.CollectionChanged;
                if (handler !== null)
                {
                    this._blockReentrancyCount++;
                    try
                    {
                        handler.Invoke(this, e);
                    }
                    finally
                    {
                        {
                            this._blockReentrancyCount--;
                        }
                    }
                }
            }
            /*IDisposable */ BlockReentrancy()
            {
                this._blockReentrancyCount++;
                return this.EnsureMonitorInitialized();
            }
            /*void */ CheckReentrancy()
            {
                if (this._blockReentrancyCount > 0)
                {
                    /*NotifyCollectionChangedEventHandler?*/ let handler = this.CollectionChanged;
                    if (handler !== null && !handler.HasSingleTarget)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$so.System.SR.ObservableCollectionReentrancyNotAllowed);
                    }
                }
            }
            /*void */ OnCountPropertyChanged()
            {
                return this.OnPropertyChanged($.$so.System.Collections.ObjectModel.EventArgsCache.CountPropertyChanged);
            }
            /*void */ OnIndexerPropertyChanged()
            {
                return this.OnPropertyChanged($.$so.System.Collections.ObjectModel.EventArgsCache.IndexerPropertyChanged);
            }
            /*void */ OnCollectionChanged$1(/*NotifyCollectionChangedAction*/ action, /*object?*/ item, /*int*/ index)
            {
                this.OnCollectionChanged$3(new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs().$ctor$8(action, item, index));
            }
            /*void */ OnCollectionChanged(/*NotifyCollectionChangedAction*/ action, /*object?*/ item, /*int*/ index, /*int*/ oldIndex)
            {
                this.OnCollectionChanged$3(new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs().$ctor$7(action, item, index, oldIndex));
            }
            /*void */ OnCollectionChanged$2(/*NotifyCollectionChangedAction*/ action, /*object?*/ oldItem, /*object?*/ newItem, /*int*/ index)
            {
                this.OnCollectionChanged$3(new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs().$ctor$9(action, newItem, oldItem, index));
            }
            /*void */ OnCollectionReset()
            {
                return this.OnCollectionChanged$3($.$so.System.Collections.ObjectModel.EventArgsCache.ResetCollectionChanged);
            }
            /*SimpleMonitor */ EnsureMonitorInitialized()
            {
                return this._monitor ??= new ($.$so.System.Collections.ObjectModel.ObservableCollection$$(T).SimpleMonitor)().$ctor$1(this);
            }
            /*void */ OnSerializing(/*StreamingContext*/ context)
            {
                this.EnsureMonitorInitialized();
                this._monitor._busyCount = this._blockReentrancyCount;
            }
            /*void */ OnDeserialized(/*StreamingContext*/ context)
            {
                if (this._monitor !== null)
                {
                    this._blockReentrancyCount = this._monitor._busyCount;
                    this._monitor._collection = this;
                }
            }
            static $_SimpleMonitor;
            static get SimpleMonitor()
            {
                let $cls = $.$so.System.Collections.ObjectModel.ObservableCollection$$(T);
                return $cls.$_SimpleMonitor ??= $asm.$ncls("$so.System.Collections.ObjectModel.ObservableCollection$$.SimpleMonitor", ($self) => class SimpleMonitor extends $.$$.System.Object
                {
                    /*int*/ _busyCount = 0;
                    /*ObservableCollection<T>*/ _collection = null;
                    $ctor$1(/*ObservableCollection<T>*/ collection)
                    {
                        super.$ctor();
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(collection !== null, "collection != null");
                            this._collection = collection;
                        }
                        return this;
                    }
                    /*void */ Dispose()
                    {
                        return this._collection._blockReentrancyCount--;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 431119;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217}],"l":[{"t":655361,"n":"_busyCount","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194312},{"t":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).$h,"n":"_collection","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194312,"a":[{"t":66519041,"c":4361486337}]}],"c":[{"p":[{"n":"collection","p":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217}],"i":[57540609],"d":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).$h,"h":this.$h,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]}]}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `System.Collections.ObjectModel.ObservableCollection<${T?.$fullName}>.SimpleMonitor`; }
                }, $cls, ($v) => $cls.$_SimpleMonitor = $v);
            }
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged.add
            System$Collections$Specialized$INotifyCollectionChanged$add_CollectionChanged()
            {
                return this.add_CollectionChanged(...arguments);
            }
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged.remove
            System$Collections$Specialized$INotifyCollectionChanged$remove_CollectionChanged()
            {
                return this.remove_CollectionChanged(...arguments);
            }
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged
            System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged()
            {
                this.CollectionChanged;
            }
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                this.System$ComponentModel$INotifyPropertyChanged$PropertyChanged;
            }
            static $h = 365583;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"oldIndex","p":655361},{"n":"newIndex","p":655361}],"n":"Move","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777217},{"r":65537,"n":"ClearItems","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16809988},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveItem","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16809988},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":T?.$h??1507328}],"n":"InsertItem","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16809988},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":T?.$h??1507328}],"n":"SetItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16809988},{"r":65537,"p":[{"n":"oldIndex","p":655361},{"n":"newIndex","p":655361}],"n":"MoveItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777348},{"r":65537,"p":[{"n":"e","p":1217551}],"n":"OnPropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777348},{"r":65537,"p":[{"n":"e","p":693263}],"n":"OnCollectionChanged","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":16777348},{"r":57540609,"n":"BlockReentrancy","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":16777220},{"r":65537,"n":"CheckReentrancy","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":16777220},{"r":65537,"n":"OnCountPropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":16777218},{"r":65537,"n":"OnIndexerPropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":16777218},{"r":65537,"p":[{"n":"action","p":627727},{"n":"item","p":131073},{"n":"index","p":655361}],"n":"OnCollectionChanged","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":16777218},{"r":65537,"p":[{"n":"action","p":627727},{"n":"item","p":131073},{"n":"index","p":655361},{"n":"oldIndex","p":655361}],"n":"OnCollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":16777218},{"r":65537,"p":[{"n":"action","p":627727},{"n":"oldItem","p":131073},{"n":"newItem","p":131073},{"n":"index","p":655361}],"n":"OnCollectionChanged","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":16777218},{"r":65537,"n":"OnCollectionReset","d":this.$h,"h":Number(BigInt(this.$h)|0x1E00000000n),"f":16777218},{"r":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).SimpleMonitor.$h,"n":"EnsureMonitorInitialized","d":this.$h,"h":Number(BigInt(this.$h)|0x1F00000000n),"f":16777218},{"r":65537,"p":[{"n":"context","p":113967105}],"n":"OnSerializing","d":this.$h,"h":Number(BigInt(this.$h)|0x2000000000n),"f":16777218,"a":[{"t":113508353,"c":4408475649}]},{"r":65537,"p":[{"n":"context","p":113967105}],"n":"OnDeserialized","d":this.$h,"h":Number(BigInt(this.$h)|0x2100000000n),"f":16777218,"a":[{"t":113311745,"c":4408279041}]}],"l":[{"t":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).SimpleMonitor.$h,"n":"_monitor","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":655361,"n":"_blockReentrancyCount","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306,"a":[{"t":66519041,"c":4361486337}]}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217},{"p":[{"n":"collection","p":$.$$.System.Collections.Generic.IEnumerable$$(T).$h}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217},{"p":[{"n":"list","p":$.$$.System.Collections.Generic.List$$(T).$h}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"e":[{"e":1283087,"m":{"r":65537,"p":[{"n":"value","p":1283087}],"n":"{1086479}.add_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$add_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":150994946},"r":{"r":65537,"p":[{"n":"value","p":1283087}],"n":"{1086479}.remove_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$remove_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":285212674},"n":"System.ComponentModel.INotifyPropertyChanged.PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":8388610},{"e":758799,"m":{"r":65537,"p":[{"n":"value","p":758799}],"n":"add_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":150995073},"r":{"r":65537,"p":[{"n":"value","p":758799}],"n":"remove_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":285212801},"n":"CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":8388737},{"e":1283087,"m":{"r":65537,"p":[{"n":"value","p":1283087}],"n":"add_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":150995076},"r":{"r":65537,"p":[{"n":"value","p":1283087}],"n":"remove_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":285212804},"n":"PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":8388740}],"i":[$.$$.System.Collections.Generic.IList$$(T).$h,$.$$.System.Collections.Generic.ICollection$$(T).$h,32047105,31457281,$.$$.System.Collections.Generic.IReadOnlyList$$(T).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$$.System.Collections.Generic.IEnumerable$$(T).$h,31719425,562191,1086479],"g":[T?.$h??1507328],"j":[$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).SimpleMonitor.$h],"r":1,"h":this.$h,"a":[{"t":118095873,"c":4413063169},{"t":37945345,"c":8627879937,"a":[{"v":$.$so.System.Collections.Generic.CollectionDebugView$$().$h,"t":142475265}]},{"t":37617665,"c":8627552257,"a":[{"v":"Count = {Count}","t":1310721}]},{"t":96141313,"c":4391108609,"a":[{"v":"WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Collections.ObjectModel.Collection$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$(T), $.$$.System.Collections.Generic.ICollection$$(T), $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyList$$(T), $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable, $.$so.System.Collections.Specialized.INotifyCollectionChanged, $.$so.System.ComponentModel.INotifyPropertyChanged ]; }
            static get $fullName() { return `System.Collections.ObjectModel.ObservableCollection<${T?.$fullName}>`; }
        }));
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading"))