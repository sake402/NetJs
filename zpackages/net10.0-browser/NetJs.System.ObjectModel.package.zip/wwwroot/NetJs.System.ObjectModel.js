
//--TRIMMABLE-BOUNDARY-START(18)
(async function () {
(function ($global, $, $$, $sc, $sm, $spu, $sr, $st) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.ObjectModel", 
    {
  "h": 18,
  "f": "System.ObjectModel",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 64552961,
          "t": 188547073
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.ObjectModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.ObjectModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1703954)
        $asm.$cls(`$so.SR.ICustomTypeProvider`, ($self) => class ICustomTypeProvider
        {
            static $h = 1703954;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296671250),
    {
      "r": 188547073,
      "n": "GetCustomType",
      "o": "SR$ICustomTypeProvider$GetCustomType",
      "d": 1703954,
      "h": 4296671250,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296671250)
  ],
  "h": 1703954
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Reflection.ICustomTypeProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Reflection${separator}ICustomTypeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703954)
        
        

        //--TRIMMABLE-BOUNDARY-START(655378)
        $asm.$cls(`$so.SCS.INotifyCollectionChanged`, ($self) => class INotifyCollectionChanged
        {
            static $h = 655378;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "e": [
//--TRIMMABLE-BOUNDARY-START(12885557266),
    {
      "e": 851986,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 851986
          }
        ],
        "n": "add_CollectionChanged",
        "o": "SCS$INotifyCollectionChanged$add_CollectionChanged",
        "d": 655378,
        "h": 8590589970,
        "f": 150995201
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 851986
          }
        ],
        "n": "remove_CollectionChanged",
        "o": "SCS$INotifyCollectionChanged$remove_CollectionChanged",
        "d": 655378,
        "h": 21475491858,
        "f": 285212929
      },
      "n": "CollectionChanged",
      "o": "System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged",
      "d": 655378,
      "h": 12885557266,
      "f": 8388865
    },
//--TRIMMABLE-BOUNDARY-END(12885557266)
  ],
  "h": 655378
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Specialized.INotifyCollectionChanged`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Specialized${separator}INotifyCollectionChanged`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655378)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179666)
        $asm.$cls(`$so.SC$1.INotifyPropertyChanged`, ($self) => class INotifyPropertyChanged
        {
            static $h = 1179666;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "e": [
//--TRIMMABLE-BOUNDARY-START(12886081554),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "o": "SC$1$INotifyPropertyChanged$add_PropertyChanged",
        "d": 1179666,
        "h": 8591114258,
        "f": 150995201
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "o": "SC$1$INotifyPropertyChanged$remove_PropertyChanged",
        "d": 1179666,
        "h": 21476016146,
        "f": 285212929
      },
      "n": "PropertyChanged",
      "o": "System$ComponentModel$INotifyPropertyChanged$PropertyChanged",
      "d": 1179666,
      "h": 12886081554,
      "f": 8388865
    },
//--TRIMMABLE-BOUNDARY-END(12886081554)
  ],
  "h": 1179666
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ComponentModel.INotifyPropertyChanged`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ComponentModel${separator}INotifyPropertyChanged`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179666)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245202)
        $asm.$cls(`$so.SC$1.INotifyPropertyChanging`, ($self) => class INotifyPropertyChanging
        {
            static $h = 1245202;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "e": [
//--TRIMMABLE-BOUNDARY-START(12886147090),
    {
      "e": 1507346,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1507346
          }
        ],
        "n": "add_PropertyChanging",
        "o": "SC$1$INotifyPropertyChanging$add_PropertyChanging",
        "d": 1245202,
        "h": 8591179794,
        "f": 150995201
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1507346
          }
        ],
        "n": "remove_PropertyChanging",
        "o": "SC$1$INotifyPropertyChanging$remove_PropertyChanging",
        "d": 1245202,
        "h": 21476081682,
        "f": 285212929
      },
      "n": "PropertyChanging",
      "o": "System$ComponentModel$INotifyPropertyChanging$PropertyChanging",
      "d": 1245202,
      "h": 12886147090,
      "f": 8388865
    },
//--TRIMMABLE-BOUNDARY-END(12886147090)
  ],
  "h": 1245202
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ComponentModel.INotifyPropertyChanging`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ComponentModel${separator}INotifyPropertyChanging`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245202)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114130)
        $asm.$cls(`$so.SC$1.INotifyDataErrorInfo`, ($self) => class INotifyDataErrorInfo
        {
            static $h = 1114130;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065885202),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475950610,
        "f": 50331905
      },
      "n": "HasErrors",
      "o": "SC$1$INotifyDataErrorInfo$HasErrors",
      "d": 1114130,
      "h": 30065885202,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30065885202)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770917906),
    {
      "r": 63373313,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetErrors",
      "o": "SC$1$INotifyDataErrorInfo$GetErrors",
      "d": 1114130,
      "h": 25770917906,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770917906)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(12886016018),
    {
      "e": $.$$.S.EventHandler$$($.$so.SC$1.DataErrorsChangedEventArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$so.SC$1.DataErrorsChangedEventArgs).$h
          }
        ],
        "n": "add_ErrorsChanged",
        "o": "SC$1$INotifyDataErrorInfo$add_ErrorsChanged",
        "d": 1114130,
        "h": 8591048722,
        "f": 150995201
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$so.SC$1.DataErrorsChangedEventArgs).$h
          }
        ],
        "n": "remove_ErrorsChanged",
        "o": "SC$1$INotifyDataErrorInfo$remove_ErrorsChanged",
        "d": 1114130,
        "h": 38655819794,
        "f": 285212929
      },
      "n": "ErrorsChanged",
      "o": "System$ComponentModel$INotifyDataErrorInfo$ErrorsChanged",
      "d": 1114130,
      "h": 12886016018,
      "f": 8388865
    },
//--TRIMMABLE-BOUNDARY-END(12886016018)
  ],
  "h": 1114130
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ComponentModel.INotifyDataErrorInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ComponentModel${separator}INotifyDataErrorInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114130)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835026)
        $asm.$cls(`$so.SWI.ICommand`, ($self) => class ICommand
        {
            static $h = 1835026;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886736914),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 131073
        }
      ],
      "n": "CanExecute",
      "o": "SWI$ICommand$CanExecute",
      "d": 1835026,
      "h": 12886736914,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886736914),
//--TRIMMABLE-BOUNDARY-START(21476671506),
    {
      "r": 65537,
      "p": [
        {
          "n": "parameter",
          "p": 131073
        }
      ],
      "n": "Execute",
      "o": "SWI$ICommand$Execute",
      "d": 1835026,
      "h": 21476671506,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21476671506)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(17181704210),
    {
      "e": 80609281,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "add_CanExecuteChanged",
        "o": "SWI$ICommand$add_CanExecuteChanged",
        "d": 1835026,
        "h": 8591769618,
        "f": 150995201
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "remove_CanExecuteChanged",
        "o": "SWI$ICommand$remove_CanExecuteChanged",
        "d": 1835026,
        "h": 30066606098,
        "f": 285212929
      },
      "n": "CanExecuteChanged",
      "o": "System$Windows$Input$ICommand$CanExecuteChanged",
      "d": 1835026,
      "h": 17181704210,
      "f": 8388865
    },
//--TRIMMABLE-BOUNDARY-END(17181704210)
  ],
  "h": 1835026,
  "a": [
    {
      "t": 134479873,
      "c": 8724414465,
      "a": [
        {
          "v": "PresentationCore, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35",
          "t": 1310721
        }
      ]
    },
    {
      "t": 1572882,
      "c": 17181442066,
      "a": [
        {
          "v": "System.Windows.Input.CommandConverter, PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, Custom=null",
          "t": 1310721
        }
      ]
    },
    {
      "t": 1900562,
      "c": 12886802450,
      "a": [
        {
          "v": "System.Windows.Input.CommandValueSerializer, PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, Custom=null",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Windows.Input.ICommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Windows${separator}Input${separator}ICommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835026)
        
        

        //--TRIMMABLE-BOUNDARY-START(131090)
        $asm.$cls(`$so.SCG.CollectionDebugView<>`, (T) => $asm.$gt(`$so.SCG.CollectionDebugView<>`, [T], ($self) => class CollectionDebugView$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295098386)
            /*ICollection<T>*/ _collection = null;
            //--TRIMMABLE-BOUNDARY-END(4295098386)
            
            //--TRIMMABLE-BOUNDARY-START(8590065682)
            $ctor$1(/*ICollection<T>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065682);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._collection = collection;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065682)
            
            //--TRIMMABLE-BOUNDARY-START(21474967570)
            /*T[] */ get Items()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*T[]*/ let items = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this._collection.SCG$ICollection$$$Count], null);
                this._collection.SCG$ICollection$$$CopyTo(items, 0);
                return items;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967570)
            
            static $H = 131090;
            static $h = 131090;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474967570),
    {
      "p": $.$typeArray(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17180000274,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "n": "Items",
      "d": this.$h,
      "H": 21474967570,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70909953,
          "c": 8660844545,
          "a": [
            {
              "v": 3,
              "t": 70975489
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21474967570)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098386),
    {
      "t": $.$$.SCG.ICollection$$(T).$h,
      "n": "_collection",
      "d": this.$h,
      "H": 4295098386,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098386)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065682),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.SCG.ICollection$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8590065682,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065682)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 131090,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Generic.CollectionDebugView<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Generic${separator}CollectionDebugView$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(131090)
        
        

        //--TRIMMABLE-BOUNDARY-START(65554)
        $asm.$cls(`$so.SC.CollectionHelpers`, ($self) => class CollectionHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(4295032850)
            static /*void */ ValidateCopyToArguments(/*int*/ sourceCount, /*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.S.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.Arg_NonZeroLowerBound, "array");
                }
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, index, "index");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.S.Int32, index, array.length, "index");
                if (((array.length - index) | 0) < sourceCount)
                {
                    throw new $.$$.S.ArgumentException().$ctor$14($.$so.S.SR.Arg_ArrayPlusOffTooSmall);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295032850)
            
            static $h = 65554;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032850),
    {
      "r": 65537,
      "p": [
        {
          "n": "sourceCount",
          "p": 655361
        },
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "ValidateCopyToArguments",
      "d": 65554,
      "h": 4295032850,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295032850)
  ],
  "h": 65554
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.CollectionHelpers`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}CollectionHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65554)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769490)
        $asm.$cls(`$so.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(279174643730)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(279174643730)
            
            //--TRIMMABLE-BOUNDARY-START(240519938066)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(240519938066);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(240519938066)
            
            //--TRIMMABLE-BOUNDARY-START(292059545618)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(292059545618);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$so.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(292059545618)
            
            //--TRIMMABLE-BOUNDARY-START(236224970770)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224970770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$so.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$so.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(236224970770)
            
            //--TRIMMABLE-BOUNDARY-START(231930003474)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930003474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$so.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(231930003474)
            
            //--TRIMMABLE-BOUNDARY-START(73016213522)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016213522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$so.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(73016213522)
            
            //--TRIMMABLE-BOUNDARY-START(68721246226)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721246226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$so.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(68721246226)
            
            //--TRIMMABLE-BOUNDARY-START(64426278930)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426278930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$so.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(64426278930)
            
            //--TRIMMABLE-BOUNDARY-START(77311180818)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311180818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$so.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(77311180818)
            
            //--TRIMMABLE-BOUNDARY-START(55836344338)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836344338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$so.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(55836344338)
            
            //--TRIMMABLE-BOUNDARY-START(51541377042)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541377042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$so.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(51541377042)
            
            //--TRIMMABLE-BOUNDARY-START(47246409746)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246409746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$so.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(47246409746)
            
            //--TRIMMABLE-BOUNDARY-START(60131311634)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131311634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$so.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(60131311634)
            
            //--TRIMMABLE-BOUNDARY-START(274879676434)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(274879676434)
            
            //--TRIMMABLE-BOUNDARY-START(266289741842)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(266289741842)
            
            //--TRIMMABLE-BOUNDARY-START(270584709138)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045101586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$so.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.ObjectModel", $.$so.S.SR.$type.Assembly);
                    $.$so.S.SR.s_resourceManager = temp;
                }
                return $.$so.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(270584709138)
            
            //--TRIMMABLE-BOUNDARY-START(42951442450)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505494034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$so.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764578322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$so.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(42951442450)
            
            //--TRIMMABLE-BOUNDARY-START(38656475154)
            static /*string */ get ArgumentOutOfRange_InvalidThreshold()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915559442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified threshold for creating dictionary is out of range.";
            }
            //--TRIMMABLE-BOUNDARY-END(38656475154)
            
            //--TRIMMABLE-BOUNDARY-START(34361507858)
            static /*string */ get Argument_ItemNotExist()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325624850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified item does not exist in this KeyedCollection.";
            }
            //--TRIMMABLE-BOUNDARY-END(34361507858)
            
            //--TRIMMABLE-BOUNDARY-START(25771573266)
            static /*string */ get Argument_AddingDuplicate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145755666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An item with the same key has already been added. Key: {0}";
            }
            //--TRIMMABLE-BOUNDARY-END(25771573266)
            
            //--TRIMMABLE-BOUNDARY-START(85901115410)
            static /*string */ FormatArgument_AddingDuplicate(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901115410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("An item with the same key has already been added. Key: {0}", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(85901115410)
            
            //--TRIMMABLE-BOUNDARY-START(17181638674)
            static /*string */ get Arg_NonZeroLowerBound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965886482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The lower bound of target array must be zero.";
            }
            //--TRIMMABLE-BOUNDARY-END(17181638674)
            
            //--TRIMMABLE-BOUNDARY-START(8591704082)
            static /*string */ get Arg_ArrayPlusOffTooSmall()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786017298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Destination array is not long enough to copy all the items in the collection. Check array index and length.";
            }
            //--TRIMMABLE-BOUNDARY-END(8591704082)
            
            //--TRIMMABLE-BOUNDARY-START(249109872658)
            static /*string */ get NotSupported_ReadOnlyCollection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685363218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Collection is read-only.";
            }
            //--TRIMMABLE-BOUNDARY-END(249109872658)
            
            //--TRIMMABLE-BOUNDARY-START(253404839954)
            static /*string */ get ObservableCollectionReentrancyNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275297810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot change ObservableCollection during a CollectionChanged event.";
            }
            //--TRIMMABLE-BOUNDARY-END(253404839954)
            
            //--TRIMMABLE-BOUNDARY-START(296354512914)
            static /*string */ get WrongActionForCtor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635036178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Constructor supports only the '{0}' action.";
            }
            //--TRIMMABLE-BOUNDARY-END(296354512914)
            
            //--TRIMMABLE-BOUNDARY-START(90196082706)
            static /*string */ FormatWrongActionForCtor(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196082706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Constructor supports only the '{0}' action.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(90196082706)
            
            //--TRIMMABLE-BOUNDARY-START(244814905362)
            static /*string */ get MustBeResetAddOrRemoveActionForCtor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095428626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Constructor only supports either a Reset, Add, or Remove action.";
            }
            //--TRIMMABLE-BOUNDARY-END(244814905362)
            
            //--TRIMMABLE-BOUNDARY-START(261994774546)
            static /*string */ get ResetActionRequiresNullItem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455166994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Reset action must be initialized with no changed items.";
            }
            //--TRIMMABLE-BOUNDARY-END(261994774546)
            
            //--TRIMMABLE-BOUNDARY-START(257699807250)
            static /*string */ get ResetActionRequiresIndexMinus1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865232402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Reset action must be initialized with index -1.";
            }
            //--TRIMMABLE-BOUNDARY-END(257699807250)
            
            //--TRIMMABLE-BOUNDARY-START(21476605970)
            static /*string */ get Arg_RankMultiDimNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555821074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Only single dimensional arrays are supported for the requested action.";
            }
            //--TRIMMABLE-BOUNDARY-END(21476605970)
            
            //--TRIMMABLE-BOUNDARY-START(30066540562)
            static /*string */ get Argument_IncompatibleArrayType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735690258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Target array type is not compatible with the type of items in the collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(30066540562)
            
            //--TRIMMABLE-BOUNDARY-START(12886671378)
            static /*string */ get Arg_KeyNotFoundWithKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375951890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The given key '{0}' was not present in the dictionary.";
            }
            //--TRIMMABLE-BOUNDARY-END(12886671378)
            
            //--TRIMMABLE-BOUNDARY-START(81606148114)
            static /*string */ FormatArg_KeyNotFoundWithKey(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606148114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The given key '{0}' was not present in the dictionary.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81606148114)
            
            //--TRIMMABLE-BOUNDARY-START(4296736786)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296736786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(279174643730)
                    this.s_usingResourceKeys = $.$so.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(279174643730)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296736786)
            
            static $h = 1769490;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1769490
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769490)
        
        

        //--TRIMMABLE-BOUNDARY-START(196626)
        $asm.$cls(`$so.SCO.EventArgsCache`, ($self) => class EventArgsCache
        {
            //--TRIMMABLE-BOUNDARY-START(8590131218)
            /*PropertyChangedEventArgs*/ static CountPropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(8590131218)
            
            //--TRIMMABLE-BOUNDARY-START(12885098514)
            /*PropertyChangedEventArgs*/ static IndexerPropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(12885098514)
            
            //--TRIMMABLE-BOUNDARY-START(17180065810)
            /*NotifyCollectionChangedEventArgs*/ static ResetCollectionChanged = null;
            //--TRIMMABLE-BOUNDARY-END(17180065810)
            
            //--TRIMMABLE-BOUNDARY-START(4295163922)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295163922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8590131218)
                    this.CountPropertyChanged = new $.$so.SC$1.PropertyChangedEventArgs().$ctor$2("Count");
                    //--TRIMMABLE-BOUNDARY-END(8590131218)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885098514)
                    this.IndexerPropertyChanged = new $.$so.SC$1.PropertyChangedEventArgs().$ctor$2("Item[]");
                    //--TRIMMABLE-BOUNDARY-END(12885098514)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180065810)
                    this.ResetCollectionChanged = new $.$so.SCS.NotifyCollectionChangedEventArgs().$ctor$12(4/*NotifyCollectionChangedAction.Reset*/);
                    //--TRIMMABLE-BOUNDARY-END(17180065810)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295163922)
            
            static $h = 196626;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590131218),
    {
      "t": 1310738,
      "n": "CountPropertyChanged",
      "d": 196626,
      "h": 8590131218,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590131218),
//--TRIMMABLE-BOUNDARY-START(12885098514),
    {
      "t": 1310738,
      "n": "IndexerPropertyChanged",
      "d": 196626,
      "h": 12885098514,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885098514),
//--TRIMMABLE-BOUNDARY-START(17180065810),
    {
      "t": 786450,
      "n": "ResetCollectionChanged",
      "d": 196626,
      "h": 17180065810,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180065810)
  ],
  "h": 196626
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.ObjectModel.EventArgsCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}ObjectModel${separator}EventArgsCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196626)
        
        

        //--TRIMMABLE-BOUNDARY-START(917522)
        $asm.$cls(`$so.SCS.ReadOnlyList`, ($self) => class ReadOnlyList extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295884818)
            /*IList*/ _list = null;
            //--TRIMMABLE-BOUNDARY-END(4295884818)
            
            //--TRIMMABLE-BOUNDARY-START(8590852114)
            $ctor$1(/*IList*/ list)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590852114);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(list !== null, "list != null");
                    this._list = list;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590852114)
            
            //--TRIMMABLE-BOUNDARY-START(30065688594)
            /*int */ get Count()
            {
                return this._list.SC$1$ICollection$Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30065688594)
            
            //--TRIMMABLE-BOUNDARY-START(103080132626)
            /*bool */ get IsReadOnly()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(103080132626)
            
            //--TRIMMABLE-BOUNDARY-START(98785165330)
            /*bool */ get IsFixedSize()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(98785165330)
            
            //--TRIMMABLE-BOUNDARY-START(107375099922)
            /*bool */ get IsSynchronized()
            {
                return this._list.SC$1$ICollection$IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(107375099922)
            
            //--TRIMMABLE-BOUNDARY-START(133144903698)
            /*object?*/ get_Item$1(/*int*/ index)
            {
                return this._list.SC$1$IList$get_Item(index);
            }
            /*void*/ set_Item$1(/*int*/ index, /*object?*/ value)
            {
                throw new $.$$.S.NotSupportedException().$ctor$12($.$so.S.SR.NotSupported_ReadOnlyCollection);
            }
            //--TRIMMABLE-BOUNDARY-END(133144903698)
            
            //--TRIMMABLE-BOUNDARY-START(128849936402)
            /*object */ get SyncRoot()
            {
                return this._list.SC$1$ICollection$SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(128849936402)
            
            //--TRIMMABLE-BOUNDARY-START(12885819410)
            /*int */ Add(/*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885819410);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$so.S.SR.NotSupported_ReadOnlyCollection);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885819410)
            
            //--TRIMMABLE-BOUNDARY-START(17180786706)
            /*void */ Clear()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180786706);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$so.S.SR.NotSupported_ReadOnlyCollection);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180786706)
            
            //--TRIMMABLE-BOUNDARY-START(21475754002)
            /*bool */ Contains(/*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475754002);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._list.SC$1$IList$Contains(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475754002)
            
            //--TRIMMABLE-BOUNDARY-START(25770721298)
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770721298);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._list.SC$1$ICollection$CopyTo(array, index);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770721298)
            
            //--TRIMMABLE-BOUNDARY-START(85900263442)
            /*IEnumerator */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900263442);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._list.SC$1$IEnumerable$GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900263442)
            
            //--TRIMMABLE-BOUNDARY-START(90195230738)
            /*int */ IndexOf(/*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195230738);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._list.SC$1$IList$IndexOf(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195230738)
            
            //--TRIMMABLE-BOUNDARY-START(94490198034)
            /*void */ Insert(/*int*/ index, /*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490198034);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$so.S.SR.NotSupported_ReadOnlyCollection);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490198034)
            
            //--TRIMMABLE-BOUNDARY-START(111670067218)
            /*void */ Remove(/*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670067218);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$so.S.SR.NotSupported_ReadOnlyCollection);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111670067218)
            
            //--TRIMMABLE-BOUNDARY-START(115965034514)
            /*void */ RemoveAt(/*int*/ index)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115965034514);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$so.S.SR.NotSupported_ReadOnlyCollection);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115965034514)
            
            //--TRIMMABLE-BOUNDARY-START(38718406657)
            //Generated interface implemetation for System.Collections.IList.this[int].get
            SC$1$IList$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38718406657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38718406657)
            
            //--TRIMMABLE-BOUNDARY-START(73078145025)
            //Generated interface implemetation for System.Collections.IList.this[int].set
            SC$1$IList$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73078145025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(73078145025)
            
            //--TRIMMABLE-BOUNDARY-START(4358668289)
            //Generated interface implemetation for System.Collections.IList.Add(object?)
            SC$1$IList$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358668289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358668289)
            
            //--TRIMMABLE-BOUNDARY-START(12948602881)
            //Generated interface implemetation for System.Collections.IList.Contains(object?)
            SC$1$IList$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12948602881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12948602881)
            
            //--TRIMMABLE-BOUNDARY-START(8653635585)
            //Generated interface implemetation for System.Collections.IList.Clear()
            SC$1$IList$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653635585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8653635585)
            
            //--TRIMMABLE-BOUNDARY-START(30128472065)
            //Generated interface implemetation for System.Collections.IList.IsReadOnly.get
            get SC$1$IList$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55898275841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(30128472065)
            
            //--TRIMMABLE-BOUNDARY-START(21538537473)
            //Generated interface implemetation for System.Collections.IList.IsFixedSize.get
            get SC$1$IList$IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51603308545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsFixedSize;
            }
            //--TRIMMABLE-BOUNDARY-END(21538537473)
            
            //--TRIMMABLE-BOUNDARY-START(43013373953)
            //Generated interface implemetation for System.Collections.IList.IndexOf(object?)
            SC$1$IList$IndexOf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43013373953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IndexOf(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(43013373953)
            
            //--TRIMMABLE-BOUNDARY-START(47308341249)
            //Generated interface implemetation for System.Collections.IList.Insert(int, object?)
            SC$1$IList$Insert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47308341249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Insert(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47308341249)
            
            //--TRIMMABLE-BOUNDARY-START(60193243137)
            //Generated interface implemetation for System.Collections.IList.Remove(object?)
            SC$1$IList$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60193243137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60193243137)
            
            //--TRIMMABLE-BOUNDARY-START(64488210433)
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            SC$1$IList$RemoveAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64488210433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveAt(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(64488210433)
            
            //--TRIMMABLE-BOUNDARY-START(4358078465)
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            SC$1$ICollection$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358078465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358078465)
            
            //--TRIMMABLE-BOUNDARY-START(17242980353)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get SC$1$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653045761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242980353)
            
            //--TRIMMABLE-BOUNDARY-START(34422849537)
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get SC$1$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43012784129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(34422849537)
            
            //--TRIMMABLE-BOUNDARY-START(25832914945)
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get SC$1$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38717816833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(25832914945)
            
            //--TRIMMABLE-BOUNDARY-START(4358340609)
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358340609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358340609)
            
            static $h = 917522;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065688594),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655623186,
        "f": 50331649
      },
      "n": "Count",
      "d": 917522,
      "h": 30065688594,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065688594),
//--TRIMMABLE-BOUNDARY-START(103080132626),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835492370,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 917522,
      "h": 103080132626,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080132626),
//--TRIMMABLE-BOUNDARY-START(98785165330),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245557778,
        "f": 50331649
      },
      "n": "IsFixedSize",
      "d": 917522,
      "h": 98785165330,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785165330),
//--TRIMMABLE-BOUNDARY-START(107375099922),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425426962,
        "f": 50331649
      },
      "n": "IsSynchronized",
      "d": 917522,
      "h": 107375099922,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375099922),
//--TRIMMABLE-BOUNDARY-START(133144903698),
    {
      "p": 131073,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015361554,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554969106,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 917522,
      "h": 133144903698,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(133144903698),
//--TRIMMABLE-BOUNDARY-START(128849936402),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605296146,
        "f": 50331649
      },
      "n": "SyncRoot",
      "d": 917522,
      "h": 128849936402,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849936402)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885819410),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Add",
      "d": 917522,
      "h": 12885819410,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885819410),
//--TRIMMABLE-BOUNDARY-START(17180786706),
    {
      "r": 65537,
      "n": "Clear",
      "d": 917522,
      "h": 17180786706,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786706),
//--TRIMMABLE-BOUNDARY-START(21475754002),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Contains",
      "d": 917522,
      "h": 21475754002,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475754002),
//--TRIMMABLE-BOUNDARY-START(25770721298),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 917522,
      "h": 25770721298,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770721298),
//--TRIMMABLE-BOUNDARY-START(85900263442),
    {
      "r": 63504385,
      "n": "GetEnumerator",
      "d": 917522,
      "h": 85900263442,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900263442),
//--TRIMMABLE-BOUNDARY-START(90195230738),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IndexOf",
      "d": 917522,
      "h": 90195230738,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195230738),
//--TRIMMABLE-BOUNDARY-START(94490198034),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Insert",
      "d": 917522,
      "h": 94490198034,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490198034),
//--TRIMMABLE-BOUNDARY-START(111670067218),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Remove",
      "d": 917522,
      "h": 111670067218,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670067218),
//--TRIMMABLE-BOUNDARY-START(115965034514),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "d": 917522,
      "h": 115965034514,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115965034514)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295884818),
    {
      "t": 63700993,
      "n": "_list",
      "d": 917522,
      "h": 4295884818,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884818)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590852114),
    {
      "p": [
        {
          "n": "list",
          "p": 63700993
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917522,
      "h": 8590852114,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8590852114)
  ],
  "h": 917522
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.IList, $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Specialized.ReadOnlyList`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Specialized${separator}ReadOnlyList`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917522)
        
        

        //--TRIMMABLE-BOUNDARY-START(983058)
        $asm.$cls(`$so.SCS.SingleItemReadOnlyList`, ($self) => class SingleItemReadOnlyList extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295950354)
            /*object?*/ _item = null;
            //--TRIMMABLE-BOUNDARY-END(4295950354)
            
            //--TRIMMABLE-BOUNDARY-START(8590917650)
            $ctor$1(/*object?*/ item)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590917650);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._item = item;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590917650)
            
            //--TRIMMABLE-BOUNDARY-START(133144969234)
            /*object?*/ get_Item$1(/*int*/ index)
            {
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNotEqual($.$$.S.Int32, index, 0, "index");
                return this._item;
            }
            /*void*/ set_Item$1(/*int*/ index, /*object?*/ value)
            {
                throw new $.$$.S.NotSupportedException().$ctor$12($.$so.S.SR.NotSupported_ReadOnlyCollection);
            }
            //--TRIMMABLE-BOUNDARY-END(133144969234)
            
            //--TRIMMABLE-BOUNDARY-START(98785230866)
            /*bool */ get IsFixedSize()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(98785230866)
            
            //--TRIMMABLE-BOUNDARY-START(103080198162)
            /*bool */ get IsReadOnly()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(103080198162)
            
            //--TRIMMABLE-BOUNDARY-START(30065754130)
            /*int */ get Count()
            {
                return 1;
            }
            //--TRIMMABLE-BOUNDARY-END(30065754130)
            
            //--TRIMMABLE-BOUNDARY-START(107375165458)
            /*bool */ get IsSynchronized()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(107375165458)
            
            //--TRIMMABLE-BOUNDARY-START(128850001938)
            /*object */ get SyncRoot()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(128850001938)
            
            //--TRIMMABLE-BOUNDARY-START(85900328978)
            /*IEnumerator */ GetEnumerator()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.S.Object))().$ctor$1(function*()
                {
                    yield this._item;
                }.bind(this)).GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(85900328978)
            
            //--TRIMMABLE-BOUNDARY-START(21475819538)
            /*bool */ Contains(/*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475819538);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._item === null ? value === null : $.$dspc(this._item, $.$$.S.Object, ($t) => $t.Equals$1, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475819538)
            
            //--TRIMMABLE-BOUNDARY-START(90195296274)
            /*int */ IndexOf(/*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195296274);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Contains(value) ? 0 : -1;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195296274)
            
            //--TRIMMABLE-BOUNDARY-START(25770786834)
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770786834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$so.SC.CollectionHelpers.ValidateCopyToArguments(1, array, index);
                array.SetValue$2(this._item, index);
            }
            //--TRIMMABLE-BOUNDARY-END(25770786834)
            
            //--TRIMMABLE-BOUNDARY-START(12885884946)
            /*int */ Add(/*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885884946);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$so.S.SR.NotSupported_ReadOnlyCollection);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885884946)
            
            //--TRIMMABLE-BOUNDARY-START(17180852242)
            /*void */ Clear()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180852242);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$so.S.SR.NotSupported_ReadOnlyCollection);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180852242)
            
            //--TRIMMABLE-BOUNDARY-START(94490263570)
            /*void */ Insert(/*int*/ index, /*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490263570);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$so.S.SR.NotSupported_ReadOnlyCollection);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490263570)
            
            //--TRIMMABLE-BOUNDARY-START(111670132754)
            /*void */ Remove(/*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670132754);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$so.S.SR.NotSupported_ReadOnlyCollection);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111670132754)
            
            //--TRIMMABLE-BOUNDARY-START(115965100050)
            /*void */ RemoveAt(/*int*/ index)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115965100050);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$so.S.SR.NotSupported_ReadOnlyCollection);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115965100050)
            
            //--TRIMMABLE-BOUNDARY-START(38718406657)
            //Generated interface implemetation for System.Collections.IList.this[int].get
            SC$1$IList$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38718406657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38718406657)
            
            //--TRIMMABLE-BOUNDARY-START(73078145025)
            //Generated interface implemetation for System.Collections.IList.this[int].set
            SC$1$IList$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73078145025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(73078145025)
            
            //--TRIMMABLE-BOUNDARY-START(4358668289)
            //Generated interface implemetation for System.Collections.IList.Add(object?)
            SC$1$IList$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358668289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358668289)
            
            //--TRIMMABLE-BOUNDARY-START(12948602881)
            //Generated interface implemetation for System.Collections.IList.Contains(object?)
            SC$1$IList$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12948602881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12948602881)
            
            //--TRIMMABLE-BOUNDARY-START(8653635585)
            //Generated interface implemetation for System.Collections.IList.Clear()
            SC$1$IList$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653635585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8653635585)
            
            //--TRIMMABLE-BOUNDARY-START(30128472065)
            //Generated interface implemetation for System.Collections.IList.IsReadOnly.get
            get SC$1$IList$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55898275841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(30128472065)
            
            //--TRIMMABLE-BOUNDARY-START(21538537473)
            //Generated interface implemetation for System.Collections.IList.IsFixedSize.get
            get SC$1$IList$IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51603308545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsFixedSize;
            }
            //--TRIMMABLE-BOUNDARY-END(21538537473)
            
            //--TRIMMABLE-BOUNDARY-START(43013373953)
            //Generated interface implemetation for System.Collections.IList.IndexOf(object?)
            SC$1$IList$IndexOf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43013373953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IndexOf(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(43013373953)
            
            //--TRIMMABLE-BOUNDARY-START(47308341249)
            //Generated interface implemetation for System.Collections.IList.Insert(int, object?)
            SC$1$IList$Insert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47308341249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Insert(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47308341249)
            
            //--TRIMMABLE-BOUNDARY-START(60193243137)
            //Generated interface implemetation for System.Collections.IList.Remove(object?)
            SC$1$IList$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60193243137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60193243137)
            
            //--TRIMMABLE-BOUNDARY-START(64488210433)
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            SC$1$IList$RemoveAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64488210433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveAt(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(64488210433)
            
            //--TRIMMABLE-BOUNDARY-START(4358078465)
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            SC$1$ICollection$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358078465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358078465)
            
            //--TRIMMABLE-BOUNDARY-START(17242980353)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get SC$1$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653045761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242980353)
            
            //--TRIMMABLE-BOUNDARY-START(34422849537)
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get SC$1$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43012784129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(34422849537)
            
            //--TRIMMABLE-BOUNDARY-START(25832914945)
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get SC$1$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38717816833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(25832914945)
            
            //--TRIMMABLE-BOUNDARY-START(4358340609)
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358340609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358340609)
            
            static $h = 983058;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133144969234),
    {
      "p": 131073,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015427090,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555034642,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 983058,
      "h": 133144969234,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(133144969234),
//--TRIMMABLE-BOUNDARY-START(98785230866),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245623314,
        "f": 50331649
      },
      "n": "IsFixedSize",
      "d": 983058,
      "h": 98785230866,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785230866),
//--TRIMMABLE-BOUNDARY-START(103080198162),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835557906,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 983058,
      "h": 103080198162,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080198162),
//--TRIMMABLE-BOUNDARY-START(30065754130),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655688722,
        "f": 50331649
      },
      "n": "Count",
      "d": 983058,
      "h": 30065754130,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065754130),
//--TRIMMABLE-BOUNDARY-START(107375165458),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425492498,
        "f": 50331649
      },
      "n": "IsSynchronized",
      "d": 983058,
      "h": 107375165458,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375165458),
//--TRIMMABLE-BOUNDARY-START(128850001938),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605361682,
        "f": 50331649
      },
      "n": "SyncRoot",
      "d": 983058,
      "h": 128850001938,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128850001938)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85900328978),
    {
      "r": 63504385,
      "n": "GetEnumerator",
      "d": 983058,
      "h": 85900328978,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900328978),
//--TRIMMABLE-BOUNDARY-START(21475819538),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Contains",
      "d": 983058,
      "h": 21475819538,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475819538),
//--TRIMMABLE-BOUNDARY-START(90195296274),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IndexOf",
      "d": 983058,
      "h": 90195296274,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195296274),
//--TRIMMABLE-BOUNDARY-START(25770786834),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 983058,
      "h": 25770786834,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770786834),
//--TRIMMABLE-BOUNDARY-START(12885884946),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Add",
      "d": 983058,
      "h": 12885884946,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885884946),
//--TRIMMABLE-BOUNDARY-START(17180852242),
    {
      "r": 65537,
      "n": "Clear",
      "d": 983058,
      "h": 17180852242,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180852242),
//--TRIMMABLE-BOUNDARY-START(94490263570),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Insert",
      "d": 983058,
      "h": 94490263570,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490263570),
//--TRIMMABLE-BOUNDARY-START(111670132754),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Remove",
      "d": 983058,
      "h": 111670132754,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670132754),
//--TRIMMABLE-BOUNDARY-START(115965100050),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "d": 983058,
      "h": 115965100050,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115965100050)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295950354),
    {
      "t": 131073,
      "n": "_item",
      "d": 983058,
      "h": 4295950354,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950354)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917650),
    {
      "p": [
        {
          "n": "item",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983058,
      "h": 8590917650,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590917650)
  ],
  "h": 983058
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.IList, $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Specialized.SingleItemReadOnlyList`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Specialized${separator}SingleItemReadOnlyList`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983058)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638418)
        $asm.$cls(`$so.SC$1.TypeDescriptionProviderAttribute`, ($self) => class TypeDescriptionProviderAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8591573010)
            $ctor$2(/*string*/ typeName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591573010);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(typeName, "typeName");
                    this.TypeName = typeName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591573010)
            
            //--TRIMMABLE-BOUNDARY-START(12886540306)
            $ctor$3(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886540306);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(type, "type");
                    this.TypeName = type.AssemblyQualifiedName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886540306)
            
            //--TRIMMABLE-BOUNDARY-START(25771442194)
            /*string*/ TypeName = null;
            //--TRIMMABLE-BOUNDARY-END(25771442194)
            
            static $h = 1638418;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771442194),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476474898,
        "f": 50331649
      },
      "n": "TypeName",
      "d": 1638418,
      "h": 25771442194,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771442194)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591573010),
    {
      "p": [
        {
          "n": "typeName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638418,
      "h": 8591573010,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591573010),
//--TRIMMABLE-BOUNDARY-START(12886540306),
    {
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638418,
      "h": 12886540306,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886540306)
  ],
  "h": 1638418,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ComponentModel.TypeDescriptionProviderAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ComponentModel${separator}TypeDescriptionProviderAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638418)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572882)
        $asm.$cls(`$so.SC$1.TypeConverterAttribute`, ($self) => class TypeConverterAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(30066343954)
            /*TypeConverterAttribute*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(30066343954)
            
            //--TRIMMABLE-BOUNDARY-START(12886474770)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886474770);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ConverterTypeName = $.$$.S.String.Empty;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886474770)
            
            //--TRIMMABLE-BOUNDARY-START(21476409362)
            $ctor$4(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476409362);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(type, "type");
                    this.ConverterTypeName = type.AssemblyQualifiedName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476409362)
            
            //--TRIMMABLE-BOUNDARY-START(17181442066)
            $ctor$3(/*string*/ typeName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181442066);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(typeName, "typeName");
                    this.ConverterTypeName = typeName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181442066)
            
            //--TRIMMABLE-BOUNDARY-START(25771376658)
            /*string*/ ConverterTypeName = null;
            //--TRIMMABLE-BOUNDARY-END(25771376658)
            
            //--TRIMMABLE-BOUNDARY-START(34361311250)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361311250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let other;
                return $.$is(obj, $.$so.SC$1.TypeConverterAttribute, { set $v($v){ other = $v; } }) && other.ConverterTypeName === this.ConverterTypeName;
            }
            //--TRIMMABLE-BOUNDARY-END(34361311250)
            
            //--TRIMMABLE-BOUNDARY-START(47246213138)
            /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246213138);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.String.GetHashCode.call(this.ConverterTypeName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246213138)
            
            //--TRIMMABLE-BOUNDARY-START(12886474770)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886474770)
            
            //--TRIMMABLE-BOUNDARY-START(8591507474)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591507474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(30066343954)
                    this.Default = new $.$so.SC$1.TypeConverterAttribute().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(30066343954)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591507474)
            
            static $h = 1572882;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771376658),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951245842,
        "f": 50331649
      },
      "n": "ConverterTypeName",
      "d": 1572882,
      "h": 25771376658,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771376658)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361311250),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1572882,
      "h": 34361311250,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361311250),
//--TRIMMABLE-BOUNDARY-START(47246213138),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1572882,
      "h": 47246213138,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246213138)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30066343954),
    {
      "t": 1572882,
      "n": "Default",
      "d": 1572882,
      "h": 30066343954,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066343954)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886474770),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1572882,
      "h": 12886474770,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886474770),
//--TRIMMABLE-BOUNDARY-START(21476409362),
    {
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1572882,
      "h": 21476409362,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476409362),
//--TRIMMABLE-BOUNDARY-START(17181442066),
    {
      "p": [
        {
          "n": "typeName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1572882,
      "h": 17181442066,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181442066)
  ],
  "h": 1572882,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 32767,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ComponentModel.TypeConverterAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ComponentModel${separator}TypeConverterAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572882)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900562)
        $asm.$cls(`$so.SWM.ValueSerializerAttribute`, ($self) => class ValueSerializerAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296867858)
            /*Type?*/ _valueSerializerType = null;
            //--TRIMMABLE-BOUNDARY-END(4296867858)
            
            //--TRIMMABLE-BOUNDARY-START(8591835154)
            /*string?*/ _valueSerializerTypeName = null;
            //--TRIMMABLE-BOUNDARY-END(8591835154)
            
            //--TRIMMABLE-BOUNDARY-START(17181769746)
            $ctor$3(/*Type*/ valueSerializerType)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181769746);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._valueSerializerType = valueSerializerType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181769746)
            
            //--TRIMMABLE-BOUNDARY-START(12886802450)
            $ctor$2(/*string*/ valueSerializerTypeName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886802450);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._valueSerializerTypeName = valueSerializerTypeName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886802450)
            
            //--TRIMMABLE-BOUNDARY-START(38656606226)
            /*Type */ get ValueSerializerType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771704338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._valueSerializerType === null && this._valueSerializerTypeName !== null)
                {
                    this._valueSerializerType = $.$$.S.Type.GetType$8(this._valueSerializerTypeName);
                }
                return this._valueSerializerType;
            }
            //--TRIMMABLE-BOUNDARY-END(38656606226)
            
            //--TRIMMABLE-BOUNDARY-START(42951573522)
            /*string */ get ValueSerializerTypeName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361638930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._valueSerializerType !== null)
                {
                    return this._valueSerializerType.AssemblyQualifiedName;
                }
                else 
                {
                    return this._valueSerializerTypeName;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951573522)
            
            static $h = 1900562;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656606226),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771704338,
        "f": 50331649
      },
      "n": "ValueSerializerType",
      "d": 1900562,
      "h": 38656606226,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656606226),
//--TRIMMABLE-BOUNDARY-START(42951573522),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361638930,
        "f": 50331649
      },
      "n": "ValueSerializerTypeName",
      "d": 1900562,
      "h": 42951573522,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951573522)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296867858),
    {
      "t": 188547073,
      "n": "_valueSerializerType",
      "d": 1900562,
      "h": 4296867858,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296867858),
//--TRIMMABLE-BOUNDARY-START(8591835154),
    {
      "t": 1310721,
      "n": "_valueSerializerTypeName",
      "d": 1900562,
      "h": 8591835154,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591835154)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181769746),
    {
      "p": [
        {
          "n": "valueSerializerType",
          "p": 188547073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1900562,
      "h": 17181769746,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181769746),
//--TRIMMABLE-BOUNDARY-START(12886802450),
    {
      "p": [
        {
          "n": "valueSerializerTypeName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1900562,
      "h": 12886802450,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886802450)
  ],
  "h": 1900562,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1244,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 134479873,
      "c": 8724414465,
      "a": [
        {
          "v": "WindowsBase, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Windows.Markup.ValueSerializerAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Windows${separator}Markup${separator}ValueSerializerAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900562)
        
        

        //--TRIMMABLE-BOUNDARY-START(262162)
        $asm.$cls(`$so.SCO.KeyedCollection<,>`, (TKey, TItem) => $asm.$gt(`$so.SCO.KeyedCollection<,>`, [TKey, TItem], ($self) => class KeyedCollection$$$ extends $.$$.SCO.Collection$$(TItem)
        {
            //--TRIMMABLE-BOUNDARY-START(51539869714)
            /*int*/ static DefaultThreshold = 0;
            //--TRIMMABLE-BOUNDARY-END(51539869714)
            
            //--TRIMMABLE-BOUNDARY-START(30065033234)
            /*IEqualityComparer<TKey>*/ comparer = null;
            //--TRIMMABLE-BOUNDARY-END(30065033234)
            
            //--TRIMMABLE-BOUNDARY-START(55834837010)
            /*Dictionary<TKey, TItem>?*/ dict = null;
            //--TRIMMABLE-BOUNDARY-END(55834837010)
            
            //--TRIMMABLE-BOUNDARY-START(111669411858)
            /*int*/ keyCount = 0;
            //--TRIMMABLE-BOUNDARY-END(111669411858)
            
            //--TRIMMABLE-BOUNDARY-START(137439215634)
            /*int*/ threshold = 0;
            //--TRIMMABLE-BOUNDARY-END(137439215634)
            
            //--TRIMMABLE-BOUNDARY-START(4295229458)
            $ctor$3()
            {
                this.$ctor$4(null, 0/*DefaultThreshold*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229458);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229458)
            
            //--TRIMMABLE-BOUNDARY-START(12885164050)
            $ctor$5(/*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$4(comparer, 0/*DefaultThreshold*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885164050);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885164050)
            
            //--TRIMMABLE-BOUNDARY-START(8590196754)
            $ctor$4(/*IEqualityComparer<TKey>?*/ comparer, /*int*/ dictionaryCreationThreshold)
            {
                super.$ctor$2(new ($.$$.SCG.List$$(TItem))().$ctor$1());
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590196754);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (dictionaryCreationThreshold < -1)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("dictionaryCreationThreshold", $.$so.S.SR.ArgumentOutOfRange_InvalidThreshold);
                    }
                    this.comparer = comparer ?? $.$$.SCG.EqualityComparer$$(TKey).Default;
                    this.threshold = dictionaryCreationThreshold === -1 ? 2147483647/*int.MaxValue*/ : dictionaryCreationThreshold;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196754)
            
            //--TRIMMABLE-BOUNDARY-START(107374444562)
            /*List<TItem> */ get Items$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489542674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$is(super.Items, $.$$.SCG.List$$(TItem)), "base.Items is List<TItem>");
                return $.$cast(super.Items, $.$$.SCG.List$$(TItem));
            }
            //--TRIMMABLE-BOUNDARY-END(107374444562)
            
            //--TRIMMABLE-BOUNDARY-START(34360000530)
            /*IEqualityComparer<TKey> */ get Comparer()
            {
                return this.comparer;
            }
            //--TRIMMABLE-BOUNDARY-END(34360000530)
            
            //--TRIMMABLE-BOUNDARY-START(133144248338)
            /*TItem*/ get_Item$1(/*TKey*/ key)
            {
                /*TItem*/ let item;
                if (this.TryGetValue(key, $.$ref(() => item, ($v) => item = $v, TItem)))
                {
                    return item;
                }
                throw new $.$$.SCG.KeyNotFoundException().$ctor$12($.$so.S.SR.Format$6($.$so.S.SR.Arg_KeyNotFoundWithKey, $.$dsp(key, TKey, ($t) => $t.ToString)));
            }
            //--TRIMMABLE-BOUNDARY-END(133144248338)
            
            //--TRIMMABLE-BOUNDARY-START(38654967826)
            /*bool */ Contains$1(/*TKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                if (this.dict !== null)
                {
                    return this.dict.ContainsKey(key);
                }
                let $en2 = this.Items$1.GetEnumerator();
                while ($en2.MoveNext())
                {
                    let item = $en2.Current;
                    {
                        if (this.comparer[`SCG$IEqualityComparer$${TKey.$getFullName('$')}$Equals`](this.GetKeyForItem(item), key))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(38654967826)
            
            //--TRIMMABLE-BOUNDARY-START(141734182930)
            /*bool */ TryGetValue(/*TKey*/ key, /*out TItem*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734182930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                if (this.dict !== null)
                {
                    return this.dict.TryGetValue(key, item);
                }
                let $en4 = this.Items$1.GetEnumerator();
                while ($en4.MoveNext())
                {
                    let itemInItems = $en4.Current;
                    {
                        /*TKey*/ let keyInItems = this.GetKeyForItem(itemInItems);
                        if (keyInItems !== null && this.comparer[`SCG$IEqualityComparer$${TKey.$getFullName('$')}$Equals`](key, keyInItems))
                        {
                            item.$v = itemInItems;
                            return true;
                        }
                    }
                }
                item.$v = $.$default(TItem);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(141734182930)
            
            //--TRIMMABLE-BOUNDARY-START(42949935122)
            /*bool */ ContainsItem(/*TItem*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949935122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TKey*/ let key;
                if ((this.dict === null) || ((key = this.GetKeyForItem(item)) === null))
                {
                    return this.Items$1.Contains(item);
                }
                /*TItem*/ let itemInDict;
                if (this.dict.TryGetValue(key, $.$ref(() => itemInDict, ($v) => itemInDict = $v, TItem)))
                {
                    return $.$$.SCG.EqualityComparer$$(TItem).Default.Equals$2(itemInDict, item);
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(42949935122)
            
            //--TRIMMABLE-BOUNDARY-START(115964379154)
            /*bool */ Remove$1(/*TKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964379154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                if (this.dict !== null)
                {
                    /*TItem*/ let item;
                    return this.dict.TryGetValue(key, $.$ref(() => item, ($v) => item = $v, TItem)) && this.Remove(item);
                }
                for(/*int*/ let i = 0; i < this.Items$1.Count; i++)
                {
                    if (this.comparer[`SCG$IEqualityComparer$${TKey.$getFullName('$')}$Equals`](this.GetKeyForItem(this.Items$1.get_Item(i)), key))
                    {
                        this.RemoveItem(i);
                        return true;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(115964379154)
            
            //--TRIMMABLE-BOUNDARY-START(60129804306)
            /*IDictionary<TKey, TItem>? */ get Dictionary()
            {
                return this.dict;
            }
            //--TRIMMABLE-BOUNDARY-END(60129804306)
            
            //--TRIMMABLE-BOUNDARY-START(21475098642)
            /*void */ ChangeItemKey(/*TItem*/ item, /*TKey*/ newKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.ContainsItem(item))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.Argument_ItemNotExist, "item");
                }
                /*TKey*/ let oldKey = this.GetKeyForItem(item);
                if (!this.comparer[`SCG$IEqualityComparer$${TKey.$getFullName('$')}$Equals`](oldKey, newKey))
                {
                    if (newKey !== null)
                    {
                        this.AddKey(newKey, item);
                    }
                    if (oldKey !== null)
                    {
                        this.RemoveKey(oldKey);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475098642)
            
            //--TRIMMABLE-BOUNDARY-START(25770065938)
            /*void */ ClearItems()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770065938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.ClearItems();
                this.dict?.Clear();
                this.keyCount = 0;
            }
            //--TRIMMABLE-BOUNDARY-END(25770065938)
            
            //--TRIMMABLE-BOUNDARY-START(103079477266)
            /*void */ InsertItem(/*int*/ index, /*TItem*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079477266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TKey*/ let key = this.GetKeyForItem(item);
                if (key !== null)
                {
                    this.AddKey(key, item);
                }
                super.InsertItem(index, item);
            }
            //--TRIMMABLE-BOUNDARY-END(103079477266)
            
            //--TRIMMABLE-BOUNDARY-START(120259346450)
            /*void */ RemoveItem(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259346450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TKey*/ let key = this.GetKeyForItem(this.Items$1.get_Item(index));
                if (key !== null)
                {
                    this.RemoveKey(key);
                }
                super.RemoveItem(index);
            }
            //--TRIMMABLE-BOUNDARY-END(120259346450)
            
            //--TRIMMABLE-BOUNDARY-START(128849281042)
            /*void */ SetItem(/*int*/ index, /*TItem*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849281042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TKey*/ let newKey = this.GetKeyForItem(item);
                /*TKey*/ let oldKey = this.GetKeyForItem(this.Items$1.get_Item(index));
                if (this.comparer[`SCG$IEqualityComparer$${TKey.$getFullName('$')}$Equals`](oldKey, newKey))
                {
                    if (newKey !== null && this.dict !== null)
                    {
                        this.dict.set_Item(newKey, item);
                    }
                }
                else 
                {
                    if (newKey !== null)
                    {
                        this.AddKey(newKey, item);
                    }
                    if (oldKey !== null)
                    {
                        this.RemoveKey(oldKey);
                    }
                }
                super.SetItem(index, item);
            }
            //--TRIMMABLE-BOUNDARY-END(128849281042)
            
            //--TRIMMABLE-BOUNDARY-START(17180131346)
            /*void */ AddKey(/*TKey*/ key, /*TItem*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.dict !== null)
                {
                    this.dict.Add(key, item);
                }
                else if (this.keyCount === this.threshold)
                {
                    this.CreateDictionary();
                    this.dict.Add(key, item);
                }
                else 
                {
                    if (this.Contains$1(key))
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.Format$6($.$so.S.SR.Argument_AddingDuplicate, $.$box(key, TKey)), "key");
                    }
                    this.keyCount++;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180131346)
            
            //--TRIMMABLE-BOUNDARY-START(47244902418)
            /*void */ CreateDictionary()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244902418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.dict = new ($.$$.SCG.Dictionary$$$(TKey, TItem))().$ctor$6(this.comparer);
                let $en7 = this.Items$1.GetEnumerator();
                while ($en7.MoveNext())
                {
                    let item = $en7.Current;
                    {
                        /*TKey*/ let key = this.GetKeyForItem(item);
                        if (key !== null)
                        {
                            this.dict.Add(key, item);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244902418)
            
            //--TRIMMABLE-BOUNDARY-START(124554313746)
            /*void */ RemoveKey(/*TKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554313746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(key !== null, "key shouldn't be null!");
                if (this.dict !== null)
                {
                    this.dict.Remove$1(key);
                }
                else 
                {
                    this.keyCount--;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554313746)
            
            //--TRIMMABLE-BOUNDARY-START(4295229458)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295229458)
            
            static $H = 262162;
            static $h = 262162;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SCO.Collection$$(TItem); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107374444562),
    {
      "p": $.$$.SCG.List$$(TItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 94489542674,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331650
      },
      "n": "Items",
      "o": "@$1",
      "d": this.$h,
      "H": 107374444562,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 538968066
    },
//--TRIMMABLE-BOUNDARY-END(107374444562),
//--TRIMMABLE-BOUNDARY-START(34360000530),
    {
      "p": $.$$.SCG.IEqualityComparer$$(TKey).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68719738898,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Comparer",
      "d": this.$h,
      "H": 34360000530,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360000530),
//--TRIMMABLE-BOUNDARY-START(133144248338),
    {
      "p": TItem?.$h??1638400,
      "i": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "H": 85899608082,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "H": 133144248338,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(133144248338),
//--TRIMMABLE-BOUNDARY-START(60129804306),
    {
      "p": $.$$.SCG.IDictionary$$$(TKey, TItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77309673490,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331652
      },
      "n": "Dictionary",
      "d": this.$h,
      "H": 60129804306,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(60129804306)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38654967826),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        }
      ],
      "n": "Contains",
      "o": "@$1",
      "d": this.$h,
      "H": 38654967826,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654967826),
//--TRIMMABLE-BOUNDARY-START(141734182930),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "item",
          "p": TItem?.$h??1638400,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": this.$h,
      "H": 141734182930,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141734182930),
//--TRIMMABLE-BOUNDARY-START(42949935122),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": TItem?.$h??1638400
        }
      ],
      "n": "ContainsItem",
      "d": this.$h,
      "H": 42949935122,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42949935122),
//--TRIMMABLE-BOUNDARY-START(115964379154),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        }
      ],
      "n": "Remove",
      "o": "@$1",
      "d": this.$h,
      "H": 115964379154,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964379154),
//--TRIMMABLE-BOUNDARY-START(21475098642),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": TItem?.$h??1638400
        },
        {
          "n": "newKey",
          "p": TKey?.$h??1572864
        }
      ],
      "n": "ChangeItemKey",
      "d": this.$h,
      "H": 21475098642,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(21475098642),
//--TRIMMABLE-BOUNDARY-START(25770065938),
    {
      "r": 65537,
      "n": "ClearItems",
      "d": this.$h,
      "H": 25770065938,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770065938),
//--TRIMMABLE-BOUNDARY-START(98784509970),
    {
      "r": TKey?.$h??1572864,
      "p": [
        {
          "n": "item",
          "p": TItem?.$h??1638400
        }
      ],
      "n": "GetKeyForItem",
      "d": this.$h,
      "H": 98784509970,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(98784509970),
//--TRIMMABLE-BOUNDARY-START(103079477266),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "item",
          "p": TItem?.$h??1638400
        }
      ],
      "n": "InsertItem",
      "d": this.$h,
      "H": 103079477266,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(103079477266),
//--TRIMMABLE-BOUNDARY-START(120259346450),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveItem",
      "d": this.$h,
      "H": 120259346450,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(120259346450),
//--TRIMMABLE-BOUNDARY-START(128849281042),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "item",
          "p": TItem?.$h??1638400
        }
      ],
      "n": "SetItem",
      "d": this.$h,
      "H": 128849281042,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(128849281042),
//--TRIMMABLE-BOUNDARY-START(17180131346),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "item",
          "p": TItem?.$h??1638400
        }
      ],
      "n": "AddKey",
      "d": this.$h,
      "H": 17180131346,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180131346),
//--TRIMMABLE-BOUNDARY-START(47244902418),
    {
      "r": 65537,
      "n": "CreateDictionary",
      "d": this.$h,
      "H": 47244902418,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47244902418),
//--TRIMMABLE-BOUNDARY-START(124554313746),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        }
      ],
      "n": "RemoveKey",
      "d": this.$h,
      "H": 124554313746,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124554313746)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51539869714),
    {
      "t": 655361,
      "n": "DefaultThreshold",
      "d": this.$h,
      "H": 51539869714,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51539869714),
//--TRIMMABLE-BOUNDARY-START(30065033234),
    {
      "t": $.$$.SCG.IEqualityComparer$$(TKey).$h,
      "n": "comparer",
      "d": this.$h,
      "H": 30065033234,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065033234),
//--TRIMMABLE-BOUNDARY-START(55834837010),
    {
      "t": $.$$.SCG.Dictionary$$$(TKey, TItem).$h,
      "n": "dict",
      "d": this.$h,
      "H": 55834837010,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55834837010),
//--TRIMMABLE-BOUNDARY-START(111669411858),
    {
      "t": 655361,
      "n": "keyCount",
      "d": this.$h,
      "H": 111669411858,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(111669411858),
//--TRIMMABLE-BOUNDARY-START(137439215634),
    {
      "t": 655361,
      "n": "threshold",
      "d": this.$h,
      "H": 137439215634,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(137439215634)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229458),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 4295229458,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295229458),
//--TRIMMABLE-BOUNDARY-START(12885164050),
    {
      "p": [
        {
          "n": "comparer",
          "p": $.$$.SCG.IEqualityComparer$$(TKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 12885164050,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12885164050),
//--TRIMMABLE-BOUNDARY-START(8590196754),
    {
      "p": [
        {
          "n": "comparer",
          "p": $.$$.SCG.IEqualityComparer$$(TKey).$h
        },
        {
          "n": "dictionaryCreationThreshold",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 8590196754,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590196754)
  ],
  "s": [
    {
      "h": TKey?.$h??1572864,
      "n": "TKey",
      "f": 64
    },
    {
      "h": TItem?.$h??1638400,
      "n": "TItem"
    }
  ],
  "r": 2,
  "H": 262162,
  "h": this.$h,
  "a": [
    {
      "t": 163119105,
      "c": 4458086401
    },
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": null,
          "t": 188547073
        }
      ]
    },
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "Count = {Count}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 134479873,
      "c": 8724414465,
      "a": [
        {
          "v": "mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IList$$(TItem), $.$$.SCG.ICollection$$(TItem), $.$$.SC$1.IList, $.$$.SC$1.ICollection, $.$$.SCG.IReadOnlyList$$(TItem), $.$$.SCG.IReadOnlyCollection$$(TItem), $.$$.SCG.IEnumerable$$(TItem), $.$$.SC$1.IEnumerable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ /*$.$so.SCO.KeyedCollection$$$.KeyedCollectionDebugView*/$.$$.DeletedObject ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.ObjectModel.KeyedCollection<${TKey?.$fullName},${TItem?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}ObjectModel${separator}KeyedCollection$${TKey?.$getFullName(separator)}$${TItem?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(262162)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507346)
        $asm.$cls(`$so.SC$1.PropertyChangingEventHandler`, ($self) => class PropertyChangingEventHandler extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.S.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 1507346;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181376530),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 1441810
        }
      ],
      "n": "Invoke",
      "d": 1507346,
      "h": 17181376530,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181376530),
//--TRIMMABLE-BOUNDARY-START(8591441938),
    {
      "r": 90570753,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 1441810
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 1507346,
      "h": 8591441938,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591441938),
//--TRIMMABLE-BOUNDARY-START(12886409234),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 1507346,
      "h": 12886409234,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886409234)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296474642),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1507346,
      "h": 4296474642,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296474642)
  ],
  "h": 1507346
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ComponentModel.PropertyChangingEventHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ComponentModel${separator}PropertyChangingEventHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507346)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376274)
        $asm.$cls(`$so.SC$1.PropertyChangedEventHandler`, ($self) => class PropertyChangedEventHandler extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.S.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 1376274;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181245458),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 1310738
        }
      ],
      "n": "Invoke",
      "d": 1376274,
      "h": 17181245458,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181245458),
//--TRIMMABLE-BOUNDARY-START(8591310866),
    {
      "r": 90570753,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 1310738
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 1376274,
      "h": 8591310866,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591310866),
//--TRIMMABLE-BOUNDARY-START(12886278162),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 1376274,
      "h": 12886278162,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886278162)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343570),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1376274,
      "h": 4296343570,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343570)
  ],
  "h": 1376274
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ComponentModel.PropertyChangedEventHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ComponentModel${separator}PropertyChangedEventHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376274)
        
        

        //--TRIMMABLE-BOUNDARY-START(851986)
        $asm.$cls(`$so.SCS.NotifyCollectionChangedEventHandler`, ($self) => class NotifyCollectionChangedEventHandler extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.S.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 851986;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180721170),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 786450
        }
      ],
      "n": "Invoke",
      "d": 851986,
      "h": 17180721170,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180721170),
//--TRIMMABLE-BOUNDARY-START(8590786578),
    {
      "r": 90570753,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 786450
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 851986,
      "h": 8590786578,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590786578),
//--TRIMMABLE-BOUNDARY-START(12885753874),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 851986,
      "h": 12885753874,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885753874)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819282),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 851986,
      "h": 4295819282,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819282)
  ],
  "h": 851986
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Specialized.NotifyCollectionChangedEventHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Specialized${separator}NotifyCollectionChangedEventHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(851986)
        
        

        //--TRIMMABLE-BOUNDARY-START(720914)
        $asm.$str(`$so.SCS.NotifyCollectionChangedAction`, ($self) => class NotifyCollectionChangedAction extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Add = 0;
            static Remove = 1;
            static Replace = 2;
            static Move = 3;
            static Reset = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(720914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Remove": 1n,
                    "Replace": 2n,
                    "Move": 3n,
                    "Reset": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295688210)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688210)
            
            //--TRIMMABLE-BOUNDARY-START(4295688210)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295688210)
            
            static $h = 720914;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590655506),
    {
      "t": 720914,
      "n": "Add",
      "d": 720914,
      "h": 8590655506,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590655506),
//--TRIMMABLE-BOUNDARY-START(17180590098),
    {
      "t": 720914,
      "n": "Remove",
      "d": 720914,
      "h": 17180590098,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590098),
//--TRIMMABLE-BOUNDARY-START(21475557394),
    {
      "t": 720914,
      "n": "Replace",
      "d": 720914,
      "h": 21475557394,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475557394),
//--TRIMMABLE-BOUNDARY-START(12885622802),
    {
      "t": 720914,
      "n": "Move",
      "d": 720914,
      "h": 12885622802,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885622802),
//--TRIMMABLE-BOUNDARY-START(25770524690),
    {
      "t": 720914,
      "n": "Reset",
      "d": 720914,
      "h": 25770524690,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770524690)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688210),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720914,
      "h": 4295688210,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688210)
  ],
  "h": 720914
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Specialized.NotifyCollectionChangedAction`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Specialized${separator}NotifyCollectionChangedAction`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720914)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441810)
        $asm.$cls(`$so.SC$1.PropertyChangingEventArgs`, ($self) => class PropertyChangingEventArgs extends $.$$.S.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(8591376402)
            $ctor$2(/*string?*/ propertyName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591376402);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.PropertyName = propertyName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591376402)
            
            //--TRIMMABLE-BOUNDARY-START(21476278290)
            /*string?*/ $PropertyName = null;
            /*string? */ get PropertyName()
            {
                return this.$PropertyName;
            }
             /*string? */ set PropertyName(value)
            {
                this.$PropertyName = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21476278290)
            
            static $h = 1441810;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.EventArgs; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476278290),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181310994,
        "f": 50331777
      },
      "n": "PropertyName",
      "d": 1441810,
      "h": 21476278290,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(21476278290)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591376402),
    {
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1441810,
      "h": 8591376402,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591376402)
  ],
  "h": 1441810
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ComponentModel.PropertyChangingEventArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ComponentModel${separator}PropertyChangingEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441810)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048594)
        $asm.$cls(`$so.SC$1.DataErrorsChangedEventArgs`, ($self) => class DataErrorsChangedEventArgs extends $.$$.S.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(8590983186)
            $ctor$2(/*string?*/ propertyName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590983186);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.PropertyName = propertyName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590983186)
            
            //--TRIMMABLE-BOUNDARY-START(21475885074)
            /*string?*/ $PropertyName = null;
            /*string? */ get PropertyName()
            {
                return this.$PropertyName;
            }
             /*string? */ set PropertyName(value)
            {
                this.$PropertyName = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21475885074)
            
            static $h = 1048594;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.EventArgs; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475885074),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180917778,
        "f": 50331777
      },
      "n": "PropertyName",
      "d": 1048594,
      "h": 21475885074,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(21475885074)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590983186),
    {
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048594,
      "h": 8590983186,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590983186)
  ],
  "h": 1048594
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ComponentModel.DataErrorsChangedEventArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ComponentModel${separator}DataErrorsChangedEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048594)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310738)
        $asm.$cls(`$so.SC$1.PropertyChangedEventArgs`, ($self) => class PropertyChangedEventArgs extends $.$$.S.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(8591245330)
            $ctor$2(/*string?*/ propertyName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591245330);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.PropertyName = propertyName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591245330)
            
            //--TRIMMABLE-BOUNDARY-START(21476147218)
            /*string?*/ $PropertyName = null;
            /*string? */ get PropertyName()
            {
                return this.$PropertyName;
            }
             /*string? */ set PropertyName(value)
            {
                this.$PropertyName = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21476147218)
            
            static $h = 1310738;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.EventArgs; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476147218),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181179922,
        "f": 50331777
      },
      "n": "PropertyName",
      "d": 1310738,
      "h": 21476147218,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(21476147218)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591245330),
    {
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310738,
      "h": 8591245330,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591245330)
  ],
  "h": 1310738
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ComponentModel.PropertyChangedEventArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ComponentModel${separator}PropertyChangedEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310738)
        
        

        //--TRIMMABLE-BOUNDARY-START(786450)
        $asm.$cls(`$so.SCS.NotifyCollectionChangedEventArgs`, ($self) => class NotifyCollectionChangedEventArgs extends $.$$.S.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(4295753746)
            /*NotifyCollectionChangedAction*/ _action = 0;
            //--TRIMMABLE-BOUNDARY-END(4295753746)
            
            //--TRIMMABLE-BOUNDARY-START(8590721042)
            /*IList?*/ _newItems = null;
            //--TRIMMABLE-BOUNDARY-END(8590721042)
            
            //--TRIMMABLE-BOUNDARY-START(17180655634)
            /*IList?*/ _oldItems = null;
            //--TRIMMABLE-BOUNDARY-END(17180655634)
            
            //--TRIMMABLE-BOUNDARY-START(12885688338)
            /*int*/ _newStartingIndex = -1;
            //--TRIMMABLE-BOUNDARY-END(12885688338)
            
            //--TRIMMABLE-BOUNDARY-START(21475622930)
            /*int*/ _oldStartingIndex = -1;
            //--TRIMMABLE-BOUNDARY-END(21475622930)
            
            //--TRIMMABLE-BOUNDARY-START(68720263186)
            $ctor$12(/*NotifyCollectionChangedAction*/ action)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720263186);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (action !== 4/*NotifyCollectionChangedAction.Reset*/)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.Format$6($.$so.S.SR.WrongActionForCtor, $.$box(4/*NotifyCollectionChangedAction.Reset*/, $.$so.SCS.NotifyCollectionChangedAction)), "action");
                    }
                    this._action = action;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68720263186)
            
            //--TRIMMABLE-BOUNDARY-START(64425295890)
            $ctor$11(/*NotifyCollectionChangedAction*/ action, /*object?*/ changedItem)
            {
                this.$ctor$8(action, changedItem, -1);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425295890);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64425295890)
            
            //--TRIMMABLE-BOUNDARY-START(51540394002)
            $ctor$8(/*NotifyCollectionChangedAction*/ action, /*object?*/ changedItem, /*int*/ index)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540394002);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    switch(action)
                    {
                        case 4/*NotifyCollectionChangedAction.Reset*/:
                        if (changedItem !== null)
                        {
                            throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.ResetActionRequiresNullItem, "action");
                        }
                        if (index !== -1)
                        {
                            throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.ResetActionRequiresIndexMinus1, "action");
                        }
                        break;
                        case 0/*NotifyCollectionChangedAction.Add*/:
                        this._newItems = new $.$so.SCS.SingleItemReadOnlyList().$ctor$1(changedItem);
                        this._newStartingIndex = index;
                        break;
                        case 1/*NotifyCollectionChangedAction.Remove*/:
                        this._oldItems = new $.$so.SCS.SingleItemReadOnlyList().$ctor$1(changedItem);
                        this._oldStartingIndex = index;
                        break;
                        default:
                        throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.MustBeResetAddOrRemoveActionForCtor, "action");
                    }
                    this._action = action;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540394002)
            
            //--TRIMMABLE-BOUNDARY-START(42950459410)
            $ctor$6(/*NotifyCollectionChangedAction*/ action, /*IList?*/ changedItems)
            {
                this.$ctor$5(action, changedItems, -1);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950459410);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950459410)
            
            //--TRIMMABLE-BOUNDARY-START(38655492114)
            $ctor$5(/*NotifyCollectionChangedAction*/ action, /*IList?*/ changedItems, /*int*/ startingIndex)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655492114);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    switch(action)
                    {
                        case 4/*NotifyCollectionChangedAction.Reset*/:
                        if (changedItems !== null)
                        {
                            throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.ResetActionRequiresNullItem, "action");
                        }
                        if (startingIndex !== -1)
                        {
                            throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.ResetActionRequiresIndexMinus1, "action");
                        }
                        break;
                        case 0/*NotifyCollectionChangedAction.Add*/:
                        case 1/*NotifyCollectionChangedAction.Remove*/:
                        $.$$.S.ArgumentNullException.ThrowIfNull$2(changedItems, "changedItems");
                        $.$$.S.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.S.Int32, startingIndex, -1, "startingIndex");
                        if (action === 0/*NotifyCollectionChangedAction.Add*/)
                        {
                            this._newItems = new $.$so.SCS.ReadOnlyList().$ctor$1(changedItems);
                            this._newStartingIndex = startingIndex;
                        }
                        else 
                        {
                            this._oldItems = new $.$so.SCS.ReadOnlyList().$ctor$1(changedItems);
                            this._oldStartingIndex = startingIndex;
                        }
                        break;
                        default:
                        throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.MustBeResetAddOrRemoveActionForCtor, "action");
                    }
                    this._action = action;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655492114)
            
            //--TRIMMABLE-BOUNDARY-START(60130328594)
            $ctor$10(/*NotifyCollectionChangedAction*/ action, /*object?*/ newItem, /*object?*/ oldItem)
            {
                this.$ctor$9(action, newItem, oldItem, -1);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130328594);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60130328594)
            
            //--TRIMMABLE-BOUNDARY-START(55835361298)
            $ctor$9(/*NotifyCollectionChangedAction*/ action, /*object?*/ newItem, /*object?*/ oldItem, /*int*/ index)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835361298);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (action !== 2/*NotifyCollectionChangedAction.Replace*/)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.Format$6($.$so.S.SR.WrongActionForCtor, $.$box(2/*NotifyCollectionChangedAction.Replace*/, $.$so.SCS.NotifyCollectionChangedAction)), "action");
                    }
                    this._action = action;
                    this._newItems = new $.$so.SCS.SingleItemReadOnlyList().$ctor$1(newItem);
                    this._oldItems = new $.$so.SCS.SingleItemReadOnlyList().$ctor$1(oldItem);
                    this._newStartingIndex = this._oldStartingIndex = index;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835361298)
            
            //--TRIMMABLE-BOUNDARY-START(30065557522)
            $ctor$3(/*NotifyCollectionChangedAction*/ action, /*IList*/ newItems, /*IList*/ oldItems)
            {
                this.$ctor$2(action, newItems, oldItems, -1);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065557522);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065557522)
            
            //--TRIMMABLE-BOUNDARY-START(25770590226)
            $ctor$2(/*NotifyCollectionChangedAction*/ action, /*IList*/ newItems, /*IList*/ oldItems, /*int*/ startingIndex)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770590226);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (action !== 2/*NotifyCollectionChangedAction.Replace*/)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.Format$6($.$so.S.SR.WrongActionForCtor, $.$box(2/*NotifyCollectionChangedAction.Replace*/, $.$so.SCS.NotifyCollectionChangedAction)), "action");
                    }
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(newItems, "newItems");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(oldItems, "oldItems");
                    this._action = action;
                    this._newItems = new $.$so.SCS.ReadOnlyList().$ctor$1(newItems);
                    this._oldItems = new $.$so.SCS.ReadOnlyList().$ctor$1(oldItems);
                    this._newStartingIndex = this._oldStartingIndex = startingIndex;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590226)
            
            //--TRIMMABLE-BOUNDARY-START(47245426706)
            $ctor$7(/*NotifyCollectionChangedAction*/ action, /*object?*/ changedItem, /*int*/ index, /*int*/ oldIndex)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245426706);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (action !== 3/*NotifyCollectionChangedAction.Move*/)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.Format$6($.$so.S.SR.WrongActionForCtor, $.$box(3/*NotifyCollectionChangedAction.Move*/, $.$so.SCS.NotifyCollectionChangedAction)), "action");
                    }
                    $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, index, "index");
                    this._action = action;
                    this._newItems = this._oldItems = new $.$so.SCS.SingleItemReadOnlyList().$ctor$1(changedItem);
                    this._newStartingIndex = index;
                    this._oldStartingIndex = oldIndex;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245426706)
            
            //--TRIMMABLE-BOUNDARY-START(34360524818)
            $ctor$4(/*NotifyCollectionChangedAction*/ action, /*IList?*/ changedItems, /*int*/ index, /*int*/ oldIndex)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360524818);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (action !== 3/*NotifyCollectionChangedAction.Move*/)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$so.S.SR.Format$6($.$so.S.SR.WrongActionForCtor, $.$box(3/*NotifyCollectionChangedAction.Move*/, $.$so.SCS.NotifyCollectionChangedAction)), "action");
                    }
                    $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, index, "index");
                    this._action = action;
                    this._newItems = this._oldItems = !(changedItems === null) ? new $.$so.SCS.ReadOnlyList().$ctor$1(changedItems) : null;
                    this._newStartingIndex = index;
                    this._oldStartingIndex = oldIndex;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360524818)
            
            //--TRIMMABLE-BOUNDARY-START(73015230482)
            /*NotifyCollectionChangedAction */ get Action()
            {
                return this._action;
            }
            //--TRIMMABLE-BOUNDARY-END(73015230482)
            
            //--TRIMMABLE-BOUNDARY-START(120259870738)
            /*IList? */ get NewItems()
            {
                return this._newItems;
            }
            //--TRIMMABLE-BOUNDARY-END(120259870738)
            
            //--TRIMMABLE-BOUNDARY-START(128849805330)
            /*IList? */ get OldItems()
            {
                return this._oldItems;
            }
            //--TRIMMABLE-BOUNDARY-END(128849805330)
            
            //--TRIMMABLE-BOUNDARY-START(124554838034)
            /*int */ get NewStartingIndex()
            {
                return this._newStartingIndex;
            }
            //--TRIMMABLE-BOUNDARY-END(124554838034)
            
            //--TRIMMABLE-BOUNDARY-START(133144772626)
            /*int */ get OldStartingIndex()
            {
                return this._oldStartingIndex;
            }
            //--TRIMMABLE-BOUNDARY-END(133144772626)
            
            static $h = 786450;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.EventArgs; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015230482),
    {
      "p": 720914,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605165074,
        "f": 50331649
      },
      "n": "Action",
      "d": 786450,
      "h": 73015230482,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015230482),
//--TRIMMABLE-BOUNDARY-START(120259870738),
    {
      "p": 63700993,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195099666,
        "f": 50331649
      },
      "n": "NewItems",
      "d": 786450,
      "h": 120259870738,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259870738),
//--TRIMMABLE-BOUNDARY-START(128849805330),
    {
      "p": 63700993,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374968850,
        "f": 50331649
      },
      "n": "OldItems",
      "d": 786450,
      "h": 128849805330,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849805330),
//--TRIMMABLE-BOUNDARY-START(124554838034),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785034258,
        "f": 50331649
      },
      "n": "NewStartingIndex",
      "d": 786450,
      "h": 124554838034,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124554838034),
//--TRIMMABLE-BOUNDARY-START(133144772626),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964903442,
        "f": 50331649
      },
      "n": "OldStartingIndex",
      "d": 786450,
      "h": 133144772626,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144772626)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295753746),
    {
      "t": 720914,
      "n": "_action",
      "d": 786450,
      "h": 4295753746,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753746),
//--TRIMMABLE-BOUNDARY-START(8590721042),
    {
      "t": 63700993,
      "n": "_newItems",
      "d": 786450,
      "h": 8590721042,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721042),
//--TRIMMABLE-BOUNDARY-START(17180655634),
    {
      "t": 63700993,
      "n": "_oldItems",
      "d": 786450,
      "h": 17180655634,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180655634),
//--TRIMMABLE-BOUNDARY-START(12885688338),
    {
      "t": 655361,
      "n": "_newStartingIndex",
      "d": 786450,
      "h": 12885688338,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688338),
//--TRIMMABLE-BOUNDARY-START(21475622930),
    {
      "t": 655361,
      "n": "_oldStartingIndex",
      "d": 786450,
      "h": 21475622930,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475622930)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(68720263186),
    {
      "p": [
        {
          "n": "action",
          "p": 720914
        }
      ],
      "n": ".ctor",
      "o": "$ctor$12",
      "d": 786450,
      "h": 68720263186,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720263186),
//--TRIMMABLE-BOUNDARY-START(64425295890),
    {
      "p": [
        {
          "n": "action",
          "p": 720914
        },
        {
          "n": "changedItem",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 786450,
      "h": 64425295890,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425295890),
//--TRIMMABLE-BOUNDARY-START(51540394002),
    {
      "p": [
        {
          "n": "action",
          "p": 720914
        },
        {
          "n": "changedItem",
          "p": 131073
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 786450,
      "h": 51540394002,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540394002),
//--TRIMMABLE-BOUNDARY-START(42950459410),
    {
      "p": [
        {
          "n": "action",
          "p": 720914
        },
        {
          "n": "changedItems",
          "p": 63700993
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 786450,
      "h": 42950459410,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950459410),
//--TRIMMABLE-BOUNDARY-START(38655492114),
    {
      "p": [
        {
          "n": "action",
          "p": 720914
        },
        {
          "n": "changedItems",
          "p": 63700993
        },
        {
          "n": "startingIndex",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 786450,
      "h": 38655492114,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655492114),
//--TRIMMABLE-BOUNDARY-START(60130328594),
    {
      "p": [
        {
          "n": "action",
          "p": 720914
        },
        {
          "n": "newItem",
          "p": 131073
        },
        {
          "n": "oldItem",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 786450,
      "h": 60130328594,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130328594),
//--TRIMMABLE-BOUNDARY-START(55835361298),
    {
      "p": [
        {
          "n": "action",
          "p": 720914
        },
        {
          "n": "newItem",
          "p": 131073
        },
        {
          "n": "oldItem",
          "p": 131073
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 786450,
      "h": 55835361298,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835361298),
//--TRIMMABLE-BOUNDARY-START(30065557522),
    {
      "p": [
        {
          "n": "action",
          "p": 720914
        },
        {
          "n": "newItems",
          "p": 63700993
        },
        {
          "n": "oldItems",
          "p": 63700993
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786450,
      "h": 30065557522,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065557522),
//--TRIMMABLE-BOUNDARY-START(25770590226),
    {
      "p": [
        {
          "n": "action",
          "p": 720914
        },
        {
          "n": "newItems",
          "p": 63700993
        },
        {
          "n": "oldItems",
          "p": 63700993
        },
        {
          "n": "startingIndex",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786450,
      "h": 25770590226,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590226),
//--TRIMMABLE-BOUNDARY-START(47245426706),
    {
      "p": [
        {
          "n": "action",
          "p": 720914
        },
        {
          "n": "changedItem",
          "p": 131073
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "oldIndex",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 786450,
      "h": 47245426706,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245426706),
//--TRIMMABLE-BOUNDARY-START(34360524818),
    {
      "p": [
        {
          "n": "action",
          "p": 720914
        },
        {
          "n": "changedItems",
          "p": 63700993
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "oldIndex",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 786450,
      "h": 34360524818,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360524818)
  ],
  "h": 786450
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Specialized.NotifyCollectionChangedEventArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Specialized${separator}NotifyCollectionChangedEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786450)
        
        

        //--TRIMMABLE-BOUNDARY-START(589842)
        $asm.$cls(`$so.SCO.ReadOnlyObservableCollection<>`, (T) => $asm.$gt(`$so.SCO.ReadOnlyObservableCollection<>`, [T], ($self) => class ReadOnlyObservableCollection$$ extends $.$$.SCO.ReadOnlyCollection$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(12885491730)
            $ctor$2(/*ObservableCollection<T>*/ list)
            {
                super.$ctor$1(list);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885491730);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($.$cast(this.Items, $.$so.SCS.INotifyCollectionChanged)).SCS$INotifyCollectionChanged$add_CollectionChanged(new $.$so.SCS.NotifyCollectionChangedEventHandler().$ctor(this, this.HandleCollectionChanged));
                    ($.$cast(this.Items, $.$so.SC$1.INotifyPropertyChanged)).SC$1$INotifyPropertyChanged$add_PropertyChanged(new $.$so.SC$1.PropertyChangedEventHandler().$ctor(this, this.HandlePropertyChanged));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491730)
            
            //--TRIMMABLE-BOUNDARY-START(38655295506)
            /*ReadOnlyObservableCollection<T>*/ static Empty$1 = null;
            //--TRIMMABLE-BOUNDARY-END(38655295506)
            
            //--TRIMMABLE-BOUNDARY-START(98784837650)
            /*NotifyCollectionChangedEventHandler?*/ SCS$INotifyCollectionChanged$add_CollectionChanged(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489870354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_CollectionChanged(value);
            }
            /*NotifyCollectionChangedEventHandler?*/ SCS$INotifyCollectionChanged$remove_CollectionChanged(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374772242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_CollectionChanged(value);
            }
            //--TRIMMABLE-BOUNDARY-END(98784837650)
            
            //--TRIMMABLE-BOUNDARY-START(34360328210)
            /*NotifyCollectionChangedEventHandler?*/ CollectionChanged = null;
            //--TRIMMABLE-BOUNDARY-END(34360328210)
            
            //--TRIMMABLE-BOUNDARY-START(34360328210)
            //--TRIMMABLE-BOUNDARY-START(21475426322)
            add_CollectionChanged(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CollectionChanged = $.$$.S.Delegate.Combine$2(this.CollectionChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475426322)
            
            //--TRIMMABLE-BOUNDARY-START(77310001170)
            remove_CollectionChanged(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CollectionChanged = $.$$.S.Delegate.Remove(this.CollectionChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(77310001170)
            
            //--TRIMMABLE-BOUNDARY-END(34360328210)
            
            //--TRIMMABLE-BOUNDARY-START(60130131986)
            /*void */ OnCollectionChanged(/*NotifyCollectionChangedEventArgs*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130131986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CollectionChanged?.Invoke(this, args);
            }
            //--TRIMMABLE-BOUNDARY-END(60130131986)
            
            //--TRIMMABLE-BOUNDARY-START(120259674130)
            /*PropertyChangedEventHandler?*/ SC$1$INotifyPropertyChanged$add_PropertyChanged(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964706834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(value);
            }
            /*PropertyChangedEventHandler?*/ SC$1$INotifyPropertyChanged$remove_PropertyChanged(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849608722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(value);
            }
            //--TRIMMABLE-BOUNDARY-END(120259674130)
            
            //--TRIMMABLE-BOUNDARY-START(68720066578)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(68720066578)
            
            //--TRIMMABLE-BOUNDARY-START(68720066578)
            //--TRIMMABLE-BOUNDARY-START(30065360914)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065360914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30065360914)
            
            //--TRIMMABLE-BOUNDARY-START(85899935762)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(85899935762)
            
            //--TRIMMABLE-BOUNDARY-END(68720066578)
            
            //--TRIMMABLE-BOUNDARY-START(64425099282)
            /*void */ OnPropertyChanged(/*PropertyChangedEventArgs*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425099282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged?.Invoke(this, args);
            }
            //--TRIMMABLE-BOUNDARY-END(64425099282)
            
            //--TRIMMABLE-BOUNDARY-START(51540197394)
            /*void */ HandleCollectionChanged(/*object?*/ sender, /*NotifyCollectionChangedEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540197394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnCollectionChanged(e);
            }
            //--TRIMMABLE-BOUNDARY-END(51540197394)
            
            //--TRIMMABLE-BOUNDARY-START(55835164690)
            /*void */ HandlePropertyChanged(/*object?*/ sender, /*PropertyChangedEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835164690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnPropertyChanged(e);
            }
            //--TRIMMABLE-BOUNDARY-END(55835164690)
            
            //--TRIMMABLE-BOUNDARY-START(12885557266)
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged
            System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885557266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557266)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.System$ComponentModel$INotifyPropertyChanged$PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(8590524434)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590524434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(38655295506)
                    this.Empty$1 = new ($.$so.SCO.ReadOnlyObservableCollection$$(T))().$ctor$2(new ($.$so.SCO.ObservableCollection$$(T))().$ctor$3());
                    //--TRIMMABLE-BOUNDARY-END(38655295506)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590524434)
            
            static $H = 589842;
            static $h = 589842;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SCO.ReadOnlyCollection$$(T); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655295506),
    {
      "p": this.$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47245230098,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331681
      },
      "n": "Empty",
      "o": "@$1",
      "d": this.$h,
      "H": 38655295506,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 538968097
    },
//--TRIMMABLE-BOUNDARY-END(38655295506)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130131986),
    {
      "r": 65537,
      "p": [
        {
          "n": "args",
          "p": 786450
        }
      ],
      "n": "OnCollectionChanged",
      "d": this.$h,
      "H": 60130131986,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(60130131986),
//--TRIMMABLE-BOUNDARY-START(64425099282),
    {
      "r": 65537,
      "p": [
        {
          "n": "args",
          "p": 1310738
        }
      ],
      "n": "OnPropertyChanged",
      "d": this.$h,
      "H": 64425099282,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(64425099282),
//--TRIMMABLE-BOUNDARY-START(51540197394),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 786450
        }
      ],
      "n": "HandleCollectionChanged",
      "d": this.$h,
      "H": 51540197394,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540197394),
//--TRIMMABLE-BOUNDARY-START(55835164690),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 1310738
        }
      ],
      "n": "HandlePropertyChanged",
      "d": this.$h,
      "H": 55835164690,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55835164690)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885491730),
    {
      "p": [
        {
          "n": "list",
          "p": $.$so.SCO.ObservableCollection$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 12885491730,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885491730)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(98784837650),
    {
      "e": 851986,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 851986
          }
        ],
        "n": "{655378}.add_CollectionChanged",
        "o": "SCS$INotifyCollectionChanged$add_CollectionChanged",
        "d": this.$h,
        "H": 94489870354,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 150994946
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 851986
          }
        ],
        "n": "{655378}.remove_CollectionChanged",
        "o": "SCS$INotifyCollectionChanged$remove_CollectionChanged",
        "d": this.$h,
        "H": 107374772242,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 285212674
      },
      "n": "System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged",
      "o": "System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged",
      "d": this.$h,
      "H": 98784837650,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 8388610
    },
//--TRIMMABLE-BOUNDARY-END(98784837650),
//--TRIMMABLE-BOUNDARY-START(34360328210),
    {
      "e": 851986,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 851986
          }
        ],
        "n": "add_CollectionChanged",
        "d": this.$h,
        "H": 21475426322,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 150995076
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 851986
          }
        ],
        "n": "remove_CollectionChanged",
        "d": this.$h,
        "H": 77310001170,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 285212804
      },
      "n": "CollectionChanged",
      "d": this.$h,
      "H": 34360328210,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 8388740
    },
//--TRIMMABLE-BOUNDARY-END(34360328210),
//--TRIMMABLE-BOUNDARY-START(120259674130),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "{1179666}.add_PropertyChanged",
        "o": "SC$1$INotifyPropertyChanged$add_PropertyChanged",
        "d": this.$h,
        "H": 115964706834,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 150994946
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "{1179666}.remove_PropertyChanged",
        "o": "SC$1$INotifyPropertyChanged$remove_PropertyChanged",
        "d": this.$h,
        "H": 128849608722,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 285212674
      },
      "n": "System.ComponentModel.INotifyPropertyChanged.PropertyChanged",
      "o": "System$ComponentModel$INotifyPropertyChanged$PropertyChanged",
      "d": this.$h,
      "H": 120259674130,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 8388610
    },
//--TRIMMABLE-BOUNDARY-END(120259674130),
//--TRIMMABLE-BOUNDARY-START(68720066578),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": this.$h,
        "H": 30065360914,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 150995076
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": this.$h,
        "H": 85899935762,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 285212804
      },
      "n": "PropertyChanged",
      "d": this.$h,
      "H": 68720066578,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 8388740
    },
//--TRIMMABLE-BOUNDARY-END(68720066578)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 589842,
  "h": this.$h,
  "a": [
    {
      "t": 163119105,
      "c": 4458086401
    },
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": 131090,
          "t": 188547073
        }
      ]
    },
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "Count = {Count}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 134479873,
      "c": 8724414465,
      "a": [
        {
          "v": "WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IList$$(T), $.$$.SCG.ICollection$$(T), $.$$.SC$1.IList, $.$$.SC$1.ICollection, $.$$.SCG.IReadOnlyList$$(T), $.$$.SCG.IReadOnlyCollection$$(T), $.$$.SCG.IEnumerable$$(T), $.$$.SC$1.IEnumerable, $.$so.SCS.INotifyCollectionChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.ObjectModel.ReadOnlyObservableCollection<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}ObjectModel${separator}ReadOnlyObservableCollection$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(589842)
        
        

        //--TRIMMABLE-BOUNDARY-START(458770)
        $asm.$cls(`$so.SCO.ObservableCollection<>`, (T) => $asm.$gt(`$so.SCO.ObservableCollection<>`, [T], ($self) => class ObservableCollection$$ extends $.$$.SCO.Collection$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(8590393362)
            /*SimpleMonitor?*/ _monitor = null;
            //--TRIMMABLE-BOUNDARY-END(8590393362)
            
            //--TRIMMABLE-BOUNDARY-START(4295426066)
            /*int*/ _blockReentrancyCount = 0;
            //--TRIMMABLE-BOUNDARY-END(4295426066)
            
            //--TRIMMABLE-BOUNDARY-START(12885360658)
            $ctor$3()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885360658);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360658)
            
            //--TRIMMABLE-BOUNDARY-START(17180327954)
            $ctor$4(/*IEnumerable<T>*/ collection)
            {
                super.$ctor$2(new ($.$$.SCG.List$$(T))().$ctor$2($.$firstOf(collection, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("collection") })));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180327954);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180327954)
            
            //--TRIMMABLE-BOUNDARY-START(21475295250)
            $ctor$5(/*List<T>*/ list)
            {
                super.$ctor$2(new ($.$$.SCG.List$$(T))().$ctor$2($.$firstOf(list, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("list") })));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475295250);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475295250)
            
            //--TRIMMABLE-BOUNDARY-START(68719935506)
            /*void */ Move(/*int*/ oldIndex, /*int*/ newIndex)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719935506);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.MoveItem(oldIndex, newIndex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719935506)
            
            //--TRIMMABLE-BOUNDARY-START(158914248722)
            /*PropertyChangedEventHandler?*/ SC$1$INotifyPropertyChanged$add_PropertyChanged(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619281426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(value);
            }
            /*PropertyChangedEventHandler?*/ SC$1$INotifyPropertyChanged$remove_PropertyChanged(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504183314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(value);
            }
            //--TRIMMABLE-BOUNDARY-END(158914248722)
            
            //--TRIMMABLE-BOUNDARY-START(55835033618)
            /*NotifyCollectionChangedEventHandler?*/ CollectionChanged = null;
            //--TRIMMABLE-BOUNDARY-END(55835033618)
            
            //--TRIMMABLE-BOUNDARY-START(55835033618)
            //--TRIMMABLE-BOUNDARY-START(30065229842)
            add_CollectionChanged(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CollectionChanged = $.$$.S.Delegate.Combine$2(this.CollectionChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30065229842)
            
            //--TRIMMABLE-BOUNDARY-START(128849477650)
            remove_CollectionChanged(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849477650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CollectionChanged = $.$$.S.Delegate.Remove(this.CollectionChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(128849477650)
            
            //--TRIMMABLE-BOUNDARY-END(55835033618)
            
            //--TRIMMABLE-BOUNDARY-START(51540066322)
            /*void */ ClearItems()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReentrancy();
                super.ClearItems();
                this.OnCountPropertyChanged();
                this.OnIndexerPropertyChanged();
                this.OnCollectionReset();
            }
            //--TRIMMABLE-BOUNDARY-END(51540066322)
            
            //--TRIMMABLE-BOUNDARY-START(141734379538)
            /*void */ RemoveItem(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734379538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReentrancy();
                /*T*/ let removedItem = this.get_Item(index);
                super.RemoveItem(index);
                this.OnCountPropertyChanged();
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged$1(1/*NotifyCollectionChangedAction.Remove*/, $.$box(removedItem, T), index);
            }
            //--TRIMMABLE-BOUNDARY-END(141734379538)
            
            //--TRIMMABLE-BOUNDARY-START(64424968210)
            /*void */ InsertItem(/*int*/ index, /*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReentrancy();
                super.InsertItem(index, item);
                this.OnCountPropertyChanged();
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged$1(0/*NotifyCollectionChangedAction.Add*/, $.$box(item, T), index);
            }
            //--TRIMMABLE-BOUNDARY-END(64424968210)
            
            //--TRIMMABLE-BOUNDARY-START(146029346834)
            /*void */ SetItem(/*int*/ index, /*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029346834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReentrancy();
                /*T*/ let originalItem = this.get_Item(index);
                super.SetItem(index, item);
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged$2(2/*NotifyCollectionChangedAction.Replace*/, $.$box(originalItem, T), $.$box(item, T), index);
            }
            //--TRIMMABLE-BOUNDARY-END(146029346834)
            
            //--TRIMMABLE-BOUNDARY-START(73014902802)
            /*void */ MoveItem(/*int*/ oldIndex, /*int*/ newIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014902802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReentrancy();
                /*T*/ let removedItem = this.get_Item(oldIndex);
                super.RemoveItem(oldIndex);
                super.InsertItem(newIndex, removedItem);
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged(3/*NotifyCollectionChangedAction.Move*/, $.$box(removedItem, T), newIndex, oldIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(73014902802)
            
            //--TRIMMABLE-BOUNDARY-START(111669608466)
            /*void */ OnPropertyChanged(/*PropertyChangedEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged?.Invoke(this, e);
            }
            //--TRIMMABLE-BOUNDARY-END(111669608466)
            
            //--TRIMMABLE-BOUNDARY-START(120259543058)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(120259543058)
            
            //--TRIMMABLE-BOUNDARY-START(120259543058)
            //--TRIMMABLE-BOUNDARY-START(38655164434)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(38655164434)
            
            //--TRIMMABLE-BOUNDARY-START(137439412242)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439412242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(137439412242)
            
            //--TRIMMABLE-BOUNDARY-END(120259543058)
            
            //--TRIMMABLE-BOUNDARY-START(90194771986)
            /*void */ OnCollectionChanged$3(/*NotifyCollectionChangedEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194771986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*NotifyCollectionChangedEventHandler?*/ let handler = this.CollectionChanged;
                if (handler !== null)
                {
                    this._blockReentrancyCount++;
                    try
                    {
                        handler.Invoke(this, e);
                    }
                    finally
                    {
                        {
                            this._blockReentrancyCount--;
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194771986)
            
            //--TRIMMABLE-BOUNDARY-START(42950131730)
            /*IDisposable */ BlockReentrancy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._blockReentrancyCount++;
                return this.EnsureMonitorInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(42950131730)
            
            //--TRIMMABLE-BOUNDARY-START(47245099026)
            /*void */ CheckReentrancy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._blockReentrancyCount > 0)
                {
                    /*NotifyCollectionChangedEventHandler?*/ let handler = this.CollectionChanged;
                    if (handler !== null && !handler.HasSingleTarget)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$so.S.SR.ObservableCollectionReentrancyNotAllowed);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245099026)
            
            //--TRIMMABLE-BOUNDARY-START(98784706578)
            /*void */ OnCountPropertyChanged()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784706578);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.OnPropertyChanged($.$so.SCO.EventArgsCache.CountPropertyChanged);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784706578)
            
            //--TRIMMABLE-BOUNDARY-START(107374641170)
            /*void */ OnIndexerPropertyChanged()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374641170);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.OnPropertyChanged($.$so.SCO.EventArgsCache.IndexerPropertyChanged);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374641170)
            
            //--TRIMMABLE-BOUNDARY-START(81604837394)
            /*void */ OnCollectionChanged$1(/*NotifyCollectionChangedAction*/ action, /*object?*/ item, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604837394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnCollectionChanged$3(new $.$so.SCS.NotifyCollectionChangedEventArgs().$ctor$8(action, item, index));
            }
            //--TRIMMABLE-BOUNDARY-END(81604837394)
            
            //--TRIMMABLE-BOUNDARY-START(77309870098)
            /*void */ OnCollectionChanged(/*NotifyCollectionChangedAction*/ action, /*object?*/ item, /*int*/ index, /*int*/ oldIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnCollectionChanged$3(new $.$so.SCS.NotifyCollectionChangedEventArgs().$ctor$7(action, item, index, oldIndex));
            }
            //--TRIMMABLE-BOUNDARY-END(77309870098)
            
            //--TRIMMABLE-BOUNDARY-START(85899804690)
            /*void */ OnCollectionChanged$2(/*NotifyCollectionChangedAction*/ action, /*object?*/ oldItem, /*object?*/ newItem, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899804690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnCollectionChanged$3(new $.$so.SCS.NotifyCollectionChangedEventArgs().$ctor$9(action, newItem, oldItem, index));
            }
            //--TRIMMABLE-BOUNDARY-END(85899804690)
            
            //--TRIMMABLE-BOUNDARY-START(94489739282)
            /*void */ OnCollectionReset()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489739282);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.OnCollectionChanged$3($.$so.SCO.EventArgsCache.ResetCollectionChanged);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489739282)
            
            //--TRIMMABLE-BOUNDARY-START(60130000914)
            /*SimpleMonitor */ EnsureMonitorInitialized()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130000914);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._monitor ??= new ($.$so.SCO.ObservableCollection$$(T).SimpleMonitor)().$ctor$1(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130000914)
            
            //--TRIMMABLE-BOUNDARY-START(115964575762)
            /*void */ OnSerializing(/*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964575762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureMonitorInitialized();
                this._monitor._busyCount = this._blockReentrancyCount;
            }
            //--TRIMMABLE-BOUNDARY-END(115964575762)
            
            //--TRIMMABLE-BOUNDARY-START(103079673874)
            /*void */ OnDeserialized(/*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._monitor !== null)
                {
                    this._blockReentrancyCount = this._monitor._busyCount;
                    this._monitor._collection = this;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079673874)
            
            //--TRIMMABLE-BOUNDARY-START(524306)
            static $_SimpleMonitor;
            static get SimpleMonitor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$so.SCO.ObservableCollection$$(T);
                return $cls.$_SimpleMonitor ??= $asm.$ncls(`$so.SCO.ObservableCollection<${T?.$fullName}>.SimpleMonitor`, ($self) => class SimpleMonitor extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295491602)
                    /*int*/ _busyCount = 0;
                    //--TRIMMABLE-BOUNDARY-END(4295491602)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590458898)
                    /*ObservableCollection<T>*/ _collection = null;
                    //--TRIMMABLE-BOUNDARY-END(8590458898)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885426194)
                    $ctor$1(/*ObservableCollection<T>*/ collection)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885426194);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.SD.Debug.Assert$4(collection !== null, "collection != null");
                            this._collection = collection;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885426194)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180393490)
                    /*void */ Dispose()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180393490);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._collection._blockReentrancyCount--;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180393490)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    static $H = 524306;
                    static $h = 524306;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180393490),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 524306,
      "H": 17180393490,
      "h": Number(BigInt(524306)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180393490)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295491602),
    {
      "t": 655361,
      "n": "_busyCount",
      "d": 524306,
      "H": 4295491602,
      "h": Number(BigInt(524306)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295491602),
//--TRIMMABLE-BOUNDARY-START(8590458898),
    {
      "t": 458770,
      "n": "_collection",
      "d": 524306,
      "H": 8590458898,
      "h": Number(BigInt(524306)|0x200000000n),
      "f": 4194312,
      "a": [
        {
          "t": 100139009,
          "c": 4395106305
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590458898)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885426194),
    {
      "p": [
        {
          "n": "collection",
          "p": 458770
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524306,
      "H": 12885426194,
      "h": Number(BigInt(524306)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426194)
  ],
  "d": 458770,
  "H": 524306,
  "h": 524306,
  "a": [
    {
      "t": 163119105,
      "c": 4458086401
    },
    {
      "t": 134479873,
      "c": 8724414465,
      "a": [
        {
          "v": "WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35",
          "t": 1310721
        }
      ]
    }
  ]
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.ObjectModel.ObservableCollection<${T?.$fullName}>+SimpleMonitor`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}ObjectModel${separator}ObservableCollection$${T?.$getFullName(separator)}$${separator}SimpleMonitor`; }
                }, $cls, ($v) => $cls.$_SimpleMonitor = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(524306)
            
            //--TRIMMABLE-BOUNDARY-START(8590589970)
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged.add
            SCS$INotifyCollectionChanged$add_CollectionChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590589970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_CollectionChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590589970)
            
            //--TRIMMABLE-BOUNDARY-START(21475491858)
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged.remove
            SCS$INotifyCollectionChanged$remove_CollectionChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475491858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_CollectionChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475491858)
            
            //--TRIMMABLE-BOUNDARY-START(12885557266)
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged
            System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885557266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CollectionChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557266)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.System$ComponentModel$INotifyPropertyChanged$PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //--TRIMMABLE-BOUNDARY-START(12885360658)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885360658)
            
            static $H = 458770;
            static $h = 458770;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SCO.Collection$$(T); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(68719935506),
    {
      "r": 65537,
      "p": [
        {
          "n": "oldIndex",
          "p": 655361
        },
        {
          "n": "newIndex",
          "p": 655361
        }
      ],
      "n": "Move",
      "d": this.$h,
      "H": 68719935506,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719935506),
//--TRIMMABLE-BOUNDARY-START(51540066322),
    {
      "r": 65537,
      "n": "ClearItems",
      "d": this.$h,
      "H": 51540066322,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51540066322),
//--TRIMMABLE-BOUNDARY-START(141734379538),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveItem",
      "d": this.$h,
      "H": 141734379538,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(141734379538),
//--TRIMMABLE-BOUNDARY-START(64424968210),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "item",
          "p": T?.$h??1572864
        }
      ],
      "n": "InsertItem",
      "d": this.$h,
      "H": 64424968210,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(64424968210),
//--TRIMMABLE-BOUNDARY-START(146029346834),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "item",
          "p": T?.$h??1572864
        }
      ],
      "n": "SetItem",
      "d": this.$h,
      "H": 146029346834,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(146029346834),
//--TRIMMABLE-BOUNDARY-START(73014902802),
    {
      "r": 65537,
      "p": [
        {
          "n": "oldIndex",
          "p": 655361
        },
        {
          "n": "newIndex",
          "p": 655361
        }
      ],
      "n": "MoveItem",
      "d": this.$h,
      "H": 73014902802,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(73014902802),
//--TRIMMABLE-BOUNDARY-START(111669608466),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 1310738
        }
      ],
      "n": "OnPropertyChanged",
      "d": this.$h,
      "H": 111669608466,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(111669608466),
//--TRIMMABLE-BOUNDARY-START(90194771986),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 786450
        }
      ],
      "n": "OnCollectionChanged",
      "o": "@$3",
      "d": this.$h,
      "H": 90194771986,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(90194771986),
//--TRIMMABLE-BOUNDARY-START(42950131730),
    {
      "r": 91095041,
      "n": "BlockReentrancy",
      "d": this.$h,
      "H": 42950131730,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(42950131730),
//--TRIMMABLE-BOUNDARY-START(47245099026),
    {
      "r": 65537,
      "n": "CheckReentrancy",
      "d": this.$h,
      "H": 47245099026,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(47245099026),
//--TRIMMABLE-BOUNDARY-START(98784706578),
    {
      "r": 65537,
      "n": "OnCountPropertyChanged",
      "d": this.$h,
      "H": 98784706578,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98784706578),
//--TRIMMABLE-BOUNDARY-START(107374641170),
    {
      "r": 65537,
      "n": "OnIndexerPropertyChanged",
      "d": this.$h,
      "H": 107374641170,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107374641170),
//--TRIMMABLE-BOUNDARY-START(81604837394),
    {
      "r": 65537,
      "p": [
        {
          "n": "action",
          "p": 720914
        },
        {
          "n": "item",
          "p": 131073
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "OnCollectionChanged",
      "o": "@$1",
      "d": this.$h,
      "H": 81604837394,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81604837394),
//--TRIMMABLE-BOUNDARY-START(77309870098),
    {
      "r": 65537,
      "p": [
        {
          "n": "action",
          "p": 720914
        },
        {
          "n": "item",
          "p": 131073
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "oldIndex",
          "p": 655361
        }
      ],
      "n": "OnCollectionChanged",
      "d": this.$h,
      "H": 77309870098,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77309870098),
//--TRIMMABLE-BOUNDARY-START(85899804690),
    {
      "r": 65537,
      "p": [
        {
          "n": "action",
          "p": 720914
        },
        {
          "n": "oldItem",
          "p": 131073
        },
        {
          "n": "newItem",
          "p": 131073
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "OnCollectionChanged",
      "o": "@$2",
      "d": this.$h,
      "H": 85899804690,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85899804690),
//--TRIMMABLE-BOUNDARY-START(94489739282),
    {
      "r": 65537,
      "n": "OnCollectionReset",
      "d": this.$h,
      "H": 94489739282,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94489739282),
//--TRIMMABLE-BOUNDARY-START(60130000914),
    {
      "r": 524306,
      "n": "EnsureMonitorInitialized",
      "d": this.$h,
      "H": 60130000914,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60130000914),
//--TRIMMABLE-BOUNDARY-START(115964575762),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": "OnSerializing",
      "d": this.$h,
      "H": 115964575762,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16777218,
      "a": [
        {
          "t": 158531585,
          "c": 4453498881
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115964575762),
//--TRIMMABLE-BOUNDARY-START(103079673874),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": "OnDeserialized",
      "d": this.$h,
      "H": 103079673874,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16777218,
      "a": [
        {
          "t": 158334977,
          "c": 4453302273
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103079673874)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393362),
    {
      "t": 524306,
      "n": "_monitor",
      "d": this.$h,
      "H": 8590393362,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590393362),
//--TRIMMABLE-BOUNDARY-START(4295426066),
    {
      "t": 655361,
      "n": "_blockReentrancyCount",
      "d": this.$h,
      "H": 4295426066,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306,
      "a": [
        {
          "t": 100139009,
          "c": 4395106305
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295426066)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885360658),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 12885360658,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885360658),
//--TRIMMABLE-BOUNDARY-START(17180327954),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.SCG.IEnumerable$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 17180327954,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180327954),
//--TRIMMABLE-BOUNDARY-START(21475295250),
    {
      "p": [
        {
          "n": "list",
          "p": $.$$.SCG.List$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 21475295250,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475295250)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(158914248722),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "{1179666}.add_PropertyChanged",
        "o": "SC$1$INotifyPropertyChanged$add_PropertyChanged",
        "d": this.$h,
        "H": 154619281426,
        "h": Number(BigInt(this.$h)|0x2400000000n),
        "f": 150994946
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "{1179666}.remove_PropertyChanged",
        "o": "SC$1$INotifyPropertyChanged$remove_PropertyChanged",
        "d": this.$h,
        "H": 167504183314,
        "h": Number(BigInt(this.$h)|0x2700000000n),
        "f": 285212674
      },
      "n": "System.ComponentModel.INotifyPropertyChanged.PropertyChanged",
      "o": "System$ComponentModel$INotifyPropertyChanged$PropertyChanged",
      "d": this.$h,
      "H": 158914248722,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 8388610
    },
//--TRIMMABLE-BOUNDARY-END(158914248722),
//--TRIMMABLE-BOUNDARY-START(55835033618),
    {
      "e": 851986,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 851986
          }
        ],
        "n": "add_CollectionChanged",
        "d": this.$h,
        "H": 30065229842,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 150995073
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 851986
          }
        ],
        "n": "remove_CollectionChanged",
        "d": this.$h,
        "H": 128849477650,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 285212801
      },
      "n": "CollectionChanged",
      "d": this.$h,
      "H": 55835033618,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 8388737
    },
//--TRIMMABLE-BOUNDARY-END(55835033618),
//--TRIMMABLE-BOUNDARY-START(120259543058),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": this.$h,
        "H": 38655164434,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 150995076
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": this.$h,
        "H": 137439412242,
        "h": Number(BigInt(this.$h)|0x2000000000n),
        "f": 285212804
      },
      "n": "PropertyChanged",
      "d": this.$h,
      "H": 120259543058,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 8388740
    },
//--TRIMMABLE-BOUNDARY-END(120259543058)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 458770,
  "h": this.$h,
  "a": [
    {
      "t": 163119105,
      "c": 4458086401
    },
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": 131090,
          "t": 188547073
        }
      ]
    },
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "Count = {Count}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 134479873,
      "c": 8724414465,
      "a": [
        {
          "v": "WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IList$$(T), $.$$.SCG.ICollection$$(T), $.$$.SC$1.IList, $.$$.SC$1.ICollection, $.$$.SCG.IReadOnlyList$$(T), $.$$.SCG.IReadOnlyCollection$$(T), $.$$.SCG.IEnumerable$$(T), $.$$.SC$1.IEnumerable, $.$so.SCS.INotifyCollectionChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$so.SCO.ObservableCollection$$(T).SimpleMonitor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.ObjectModel.ObservableCollection<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}ObjectModel${separator}ObservableCollection$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(458770)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading"));
})();
//--TRIMMABLE-BOUNDARY-END(18)
