
(function ($global, $, $spc, $sc, $sm, $spu, $st, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.ObjectModel", 
    {"h":54281,"f":"System.ObjectModel","v":"1.0.35.0","a":[{"t":96337921,"c":4391305217,"a":[{"v":$.$spc.System.Collections.ObjectModel.ReadOnlyDictionary$$$().$h,"t":142606337}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.ObjectModel","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.ObjectModel","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$so.System.Collections.Specialized.INotifyCollectionChanged", ($self) => class INotifyCollectionChanged
        {
            /*NotifyCollectionChangedEventHandler?*/ $so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged = null;
             $so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged$add(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                this.$so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged = $.$spc.System.Delegate.Combine(this.$so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged, value);
            }
             $so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged$remove(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                this.$so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged = $.$spc.System.Delegate.Remove(this.$so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged, value);
            }
            static $h = 578569;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"e":[{"e":775177,"m":{"r":65537,"p":[{"n":"value","p":775177}],"n":"add_CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$add_CollectionChanged","d":578569,"h":4295545865,"f":257},"r":{"r":65537,"p":[{"n":"value","p":775177}],"n":"remove_CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$remove_CollectionChanged","d":578569,"h":8590513161,"f":257},"n":"CollectionChanged","o":"$so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged","d":578569,"h":12885480457,"f":257}],"h":578569}; }
            static get $fullName() { return `System.Collections.Specialized.INotifyCollectionChanged`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.INotifyDataErrorInfo", ($self) => class INotifyDataErrorInfo
        {
            /*EventHandler<DataErrorsChangedEventArgs>?*/ $so$System$ComponentModel$INotifyDataErrorInfo$ErrorsChanged = null;
             $so$System$ComponentModel$INotifyDataErrorInfo$ErrorsChanged$add(/*EventHandler<DataErrorsChangedEventArgs>?*/ value)
            {
                this.$so$System$ComponentModel$INotifyDataErrorInfo$ErrorsChanged = $.$spc.System.Delegate.Combine(this.$so$System$ComponentModel$INotifyDataErrorInfo$ErrorsChanged, value);
            }
             $so$System$ComponentModel$INotifyDataErrorInfo$ErrorsChanged$remove(/*EventHandler<DataErrorsChangedEventArgs>?*/ value)
            {
                this.$so$System$ComponentModel$INotifyDataErrorInfo$ErrorsChanged = $.$spc.System.Delegate.Remove(this.$so$System$ComponentModel$INotifyDataErrorInfo$ErrorsChanged, value);
            }
            static $h = 1037321;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":8590971913,"f":257},"n":"HasErrors","o":"System$ComponentModel$INotifyDataErrorInfo$HasErrors","d":1037321,"h":4296004617,"f":257}],"m":[{"r":31588353,"p":[{"n":"propertyName","p":1310721}],"n":"GetErrors","o":"System$ComponentModel$INotifyDataErrorInfo$GetErrors","d":1037321,"h":12885939209,"f":257}],"e":[{"e":$.$spc.System.EventHandler$$($.$so.System.ComponentModel.DataErrorsChangedEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$so.System.ComponentModel.DataErrorsChangedEventArgs).$h}],"n":"add_ErrorsChanged","o":"System$ComponentModel$INotifyDataErrorInfo$add_ErrorsChanged","d":1037321,"h":17180906505,"f":257},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$so.System.ComponentModel.DataErrorsChangedEventArgs).$h}],"n":"remove_ErrorsChanged","o":"System$ComponentModel$INotifyDataErrorInfo$remove_ErrorsChanged","d":1037321,"h":21475873801,"f":257},"n":"ErrorsChanged","o":"$so$System$ComponentModel$INotifyDataErrorInfo$ErrorsChanged","d":1037321,"h":25770841097,"f":257}],"h":1037321}; }
            static get $fullName() { return `System.ComponentModel.INotifyDataErrorInfo`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.INotifyPropertyChanged", ($self) => class INotifyPropertyChanged
        {
            /*PropertyChangedEventHandler?*/ $so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged = null;
             $so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged$add(/*PropertyChangedEventHandler?*/ value)
            {
                this.$so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged = $.$spc.System.Delegate.Combine(this.$so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged, value);
            }
             $so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged$remove(/*PropertyChangedEventHandler?*/ value)
            {
                this.$so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged = $.$spc.System.Delegate.Remove(this.$so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged, value);
            }
            static $h = 1102857;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"e":[{"e":1299465,"m":{"r":65537,"p":[{"n":"value","p":1299465}],"n":"add_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$add_PropertyChanged","d":1102857,"h":4296070153,"f":257},"r":{"r":65537,"p":[{"n":"value","p":1299465}],"n":"remove_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$remove_PropertyChanged","d":1102857,"h":8591037449,"f":257},"n":"PropertyChanged","o":"$so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged","d":1102857,"h":12886004745,"f":257}],"h":1102857}; }
            static get $fullName() { return `System.ComponentModel.INotifyPropertyChanged`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.INotifyPropertyChanging", ($self) => class INotifyPropertyChanging
        {
            /*PropertyChangingEventHandler?*/ $so$System$ComponentModel$INotifyPropertyChanging$PropertyChanging = null;
             $so$System$ComponentModel$INotifyPropertyChanging$PropertyChanging$add(/*PropertyChangingEventHandler?*/ value)
            {
                this.$so$System$ComponentModel$INotifyPropertyChanging$PropertyChanging = $.$spc.System.Delegate.Combine(this.$so$System$ComponentModel$INotifyPropertyChanging$PropertyChanging, value);
            }
             $so$System$ComponentModel$INotifyPropertyChanging$PropertyChanging$remove(/*PropertyChangingEventHandler?*/ value)
            {
                this.$so$System$ComponentModel$INotifyPropertyChanging$PropertyChanging = $.$spc.System.Delegate.Remove(this.$so$System$ComponentModel$INotifyPropertyChanging$PropertyChanging, value);
            }
            static $h = 1168393;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"e":[{"e":1430537,"m":{"r":65537,"p":[{"n":"value","p":1430537}],"n":"add_PropertyChanging","o":"System$ComponentModel$INotifyPropertyChanging$add_PropertyChanging","d":1168393,"h":4296135689,"f":257},"r":{"r":65537,"p":[{"n":"value","p":1430537}],"n":"remove_PropertyChanging","o":"System$ComponentModel$INotifyPropertyChanging$remove_PropertyChanging","d":1168393,"h":8591102985,"f":257},"n":"PropertyChanging","o":"$so$System$ComponentModel$INotifyPropertyChanging$PropertyChanging","d":1168393,"h":12886070281,"f":257}],"h":1168393}; }
            static get $fullName() { return `System.ComponentModel.INotifyPropertyChanging`; }
        });
        
        $asm.$cls("$so.System.Reflection.ICustomTypeProvider", ($self) => class ICustomTypeProvider
        {
            static $h = 1627145;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":142606337,"n":"GetCustomType","o":"System$Reflection$ICustomTypeProvider$GetCustomType","d":1627145,"h":4296594441,"f":257}],"h":1627145}; }
            static get $fullName() { return `System.Reflection.ICustomTypeProvider`; }
        });
        
        $asm.$cls("$so.System.Windows.Input.ICommand", ($self) => class ICommand
        {
            /*EventHandler?*/ $so$System$Windows$Input$ICommand$CanExecuteChanged = null;
             $so$System$Windows$Input$ICommand$CanExecuteChanged$add(/*EventHandler?*/ value)
            {
                this.$so$System$Windows$Input$ICommand$CanExecuteChanged = $.$spc.System.Delegate.Combine(this.$so$System$Windows$Input$ICommand$CanExecuteChanged, value);
            }
             $so$System$Windows$Input$ICommand$CanExecuteChanged$remove(/*EventHandler?*/ value)
            {
                this.$so$System$Windows$Input$ICommand$CanExecuteChanged = $.$spc.System.Delegate.Remove(this.$so$System$Windows$Input$ICommand$CanExecuteChanged, value);
            }
            static $h = 1758217;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262145,"p":[{"n":"parameter","p":131073}],"n":"CanExecute","o":"System$Windows$Input$ICommand$CanExecute","d":1758217,"h":17181627401,"f":257},{"r":65537,"p":[{"n":"parameter","p":131073}],"n":"Execute","o":"System$Windows$Input$ICommand$Execute","d":1758217,"h":21476594697,"f":257}],"e":[{"e":46989313,"m":{"r":65537,"p":[{"n":"value","p":46989313}],"n":"add_CanExecuteChanged","o":"System$Windows$Input$ICommand$add_CanExecuteChanged","d":1758217,"h":4296725513,"f":257},"r":{"r":65537,"p":[{"n":"value","p":46989313}],"n":"remove_CanExecuteChanged","o":"System$Windows$Input$ICommand$remove_CanExecuteChanged","d":1758217,"h":8591692809,"f":257},"n":"CanExecuteChanged","o":"$so$System$Windows$Input$ICommand$CanExecuteChanged","d":1758217,"h":12886660105,"f":257}],"h":1758217,"a":[{"t":96272385,"c":4391239681,"a":[{"v":"PresentationCore, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]},{"t":1496073,"c":17181365257,"a":[{"v":"System.Windows.Input.CommandConverter, PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, Custom=null","t":1310721}]},{"t":1823753,"c":17181692937,"a":[{"v":"System.Windows.Input.CommandValueSerializer, PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, Custom=null","t":1310721}]}]}; }
            static get $fullName() { return `System.Windows.Input.ICommand`; }
        });
        
        $asm.$cls("$so.System.Collections.Generic.CollectionDebugView<>", (T) => $asm.$gt("$so.System.Collections.Generic.CollectionDebugView<>", [T], ($self) => class CollectionDebugView$$ extends $.$spc.System.Object
        {
            /*ICollection<T>*/ _collection = null;
            $ctor$1(/*ICollection<T>*/ collection)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                    this._collection = collection;
                }
                return this;
            }
            /*T[] */ get Items()
            {
                /*T[]*/ let items = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this._collection.System$Collections$Generic$ICollection$$$Count], null);
                this._collection.System$Collections$Generic$ICollection$$$CopyTo(items, 0, [T]);
                return items;
            }
            static $h = 185353;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},"n":"Items","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1,"a":[{"t":37355521,"c":4332322817,"a":[{"v":3,"t":37421057}]}]}],"l":[{"t":$.$spc.System.Collections.Generic.ICollection$$(T).$h,"n":"_collection","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2}],"c":[{"p":[{"n":"collection","p":$.$spc.System.Collections.Generic.ICollection$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Collections.Generic.CollectionDebugView<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$so.System.Collections.CollectionHelpers", ($self) => class CollectionHelpers
        {
            static /*void */ ValidateCopyToArguments(/*int*/ sourceCount, /*Array*/ array, /*int*/ index)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(array, "array");
                if ($.$spc.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Arg_NonZeroLowerBound, "array");
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, index, array.length, "index");
                if (((array.length - index) | 0) < sourceCount)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$so.System.SR.Arg_ArrayPlusOffTooSmall);
                }
            }
            static $h = 119817;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"sourceCount","p":655361},{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"ValidateCopyToArguments","d":119817,"h":4295087113,"f":40}],"h":119817}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Collections.CollectionHelpers`; }
        });
        
        $asm.$cls("$so.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$so.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.ObjectModel", $.$so.System.SR.$type.Assembly);
                    $.$so.System.SR.s_resourceManager = temp;
                }
                return $.$so.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$so.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$so.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentOutOfRange_InvalidThreshold()
            {
                return "The specified threshold for creating dictionary is out of range.";
            }
            static /*string */ get Argument_ItemNotExist()
            {
                return "The specified item does not exist in this KeyedCollection.";
            }
            static /*string */ get Argument_AddingDuplicate()
            {
                return "An item with the same key has already been added. Key: {0}";
            }
            static /*string */ FormatArgument_AddingDuplicate(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("An item with the same key has already been added. Key: {0}", arg1);
            }
            static /*string */ get Arg_NonZeroLowerBound()
            {
                return "The lower bound of target array must be zero.";
            }
            static /*string */ get Arg_ArrayPlusOffTooSmall()
            {
                return "Destination array is not long enough to copy all the items in the collection. Check array index and length.";
            }
            static /*string */ get NotSupported_ReadOnlyCollection()
            {
                return "Collection is read-only.";
            }
            static /*string */ get ObservableCollectionReentrancyNotAllowed()
            {
                return "Cannot change ObservableCollection during a CollectionChanged event.";
            }
            static /*string */ get WrongActionForCtor()
            {
                return "Constructor supports only the '{0}' action.";
            }
            static /*string */ FormatWrongActionForCtor(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Constructor supports only the '{0}' action.", arg1);
            }
            static /*string */ get MustBeResetAddOrRemoveActionForCtor()
            {
                return "Constructor only supports either a Reset, Add, or Remove action.";
            }
            static /*string */ get ResetActionRequiresNullItem()
            {
                return "Reset action must be initialized with no changed items.";
            }
            static /*string */ get ResetActionRequiresIndexMinus1()
            {
                return "Reset action must be initialized with index -1.";
            }
            static /*string */ get Arg_RankMultiDimNotSupported()
            {
                return "Only single dimensional arrays are supported for the requested action.";
            }
            static /*string */ get Argument_IncompatibleArrayType()
            {
                return "Target array type is not compatible with the type of items in the collection.";
            }
            static /*string */ get Arg_KeyNotFoundWithKey()
            {
                return "The given key '{0}' was not present in the dictionary.";
            }
            static /*string */ FormatArg_KeyNotFoundWithKey(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The given key '{0}' was not present in the dictionary.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$so.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$so.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$so.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$so.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$so.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$so.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1692681;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1692681}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$so.System.Collections.ObjectModel.EventArgsCache", ($self) => class EventArgsCache
        {
            /*PropertyChangedEventArgs*/ static CountPropertyChanged = null;
            /*PropertyChangedEventArgs*/ static IndexerPropertyChanged = null;
            /*NotifyCollectionChangedEventArgs*/ static ResetCollectionChanged = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.CountPropertyChanged = new $.$so.System.ComponentModel.PropertyChangedEventArgs().$ctor$2("Count");
                }
                {
                    this.IndexerPropertyChanged = new $.$so.System.ComponentModel.PropertyChangedEventArgs().$ctor$2("Item[]");
                }
                {
                    this.ResetCollectionChanged = new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs().$ctor$2(4/*NotifyCollectionChangedAction.Reset*/);
                }
            }
            static $h = 250889;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1233929,"n":"CountPropertyChanged","d":250889,"h":4295218185,"f":40},{"t":1233929,"n":"IndexerPropertyChanged","d":250889,"h":8590185481,"f":40},{"t":709641,"n":"ResetCollectionChanged","d":250889,"h":12885152777,"f":40}],"h":250889}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Collections.ObjectModel.EventArgsCache`; }
        });
        
        $asm.$cls("$so.System.Collections.Specialized.ReadOnlyList", ($self) => class ReadOnlyList extends $.$spc.System.Object
        {
            /*IList*/ _list = null;
            $ctor$1(/*IList*/ list)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(list !== null, "list != null");
                    this._list = list;
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._list.System$Collections$ICollection$Count;
            }
            /*bool */ get IsReadOnly()
            {
                return true;
            }
            /*bool */ get IsFixedSize()
            {
                return true;
            }
            /*bool */ get IsSynchronized()
            {
                return this._list.System$Collections$ICollection$IsSynchronized;
            }
            /*object?*/ get_Item(/*int*/ index)
            {
                return this._list.System$Collections$IList$get_Item(index);
            }
            /*void*/ set_Item(/*int*/ index, /*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*object */ get SyncRoot()
            {
                return this._list.System$Collections$ICollection$SyncRoot;
            }
            /*int */ Add(/*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Clear()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*bool */ Contains(/*object?*/ value)
            {
                return this._list.System$Collections$IList$Contains(value);
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                return this._list.System$Collections$ICollection$CopyTo(array, index);
            }
            /*IEnumerator */ GetEnumerator()
            {
                return this._list.System$Collections$IEnumerable$GetEnumerator();
            }
            /*int */ IndexOf(/*object?*/ value)
            {
                return this._list.System$Collections$IList$IndexOf(value);
            }
            /*void */ Insert(/*int*/ index, /*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Remove(/*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            //Generated interface implemetation for System.Collections.IList.this[int].get
            System$Collections$IList$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.this[int].set
            System$Collections$IList$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Add(object?)
            System$Collections$IList$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Contains(object?)
            System$Collections$IList$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Clear()
            System$Collections$IList$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.IsReadOnly.get
            get System$Collections$IList$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.IList.IsFixedSize.get
            get System$Collections$IList$IsFixedSize()
            {
                return this.IsFixedSize;
            }
            //Generated interface implemetation for System.Collections.IList.IndexOf(object?)
            System$Collections$IList$IndexOf()
            {
                return this.IndexOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Insert(int, object?)
            System$Collections$IList$Insert()
            {
                return this.Insert(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Remove(object?)
            System$Collections$IList$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            System$Collections$IList$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 840713;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180709897,"f":1},"n":"Count","d":840713,"h":12885742601,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770644489,"f":1},"n":"IsReadOnly","d":840713,"h":21475677193,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360579081,"f":1},"n":"IsFixedSize","d":840713,"h":30065611785,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950513673,"f":1},"n":"IsSynchronized","d":840713,"h":38655546377,"f":1},{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":51540448265,"f":1},"s":{"r":0,"d":0,"h":55835415561,"f":1},"n":"Item","o":"@$2","d":840713,"h":47245480969,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":64425350153,"f":1},"n":"SyncRoot","d":840713,"h":60130382857,"f":1}],"m":[{"r":655361,"p":[{"n":"value","p":131073}],"n":"Add","d":840713,"h":68720317449,"f":1},{"r":65537,"n":"Clear","d":840713,"h":73015284745,"f":1},{"r":262145,"p":[{"n":"value","p":131073}],"n":"Contains","d":840713,"h":77310252041,"f":1},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":840713,"h":81605219337,"f":1},{"r":31719425,"n":"GetEnumerator","d":840713,"h":85900186633,"f":1},{"r":655361,"p":[{"n":"value","p":131073}],"n":"IndexOf","d":840713,"h":90195153929,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"Insert","d":840713,"h":94490121225,"f":1},{"r":65537,"p":[{"n":"value","p":131073}],"n":"Remove","d":840713,"h":98785088521,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":840713,"h":103080055817,"f":1}],"l":[{"t":31916033,"n":"_list","d":840713,"h":4295808009,"f":2}],"c":[{"p":[{"n":"list","p":31916033}],"n":".ctor","o":"$ctor$1","d":840713,"h":8590775305,"f":8}],"i":[31916033,31326209,31588353],"h":840713}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.ReadOnlyList`; }
        });
        
        $asm.$cls("$so.System.Collections.Specialized.SingleItemReadOnlyList", ($self) => class SingleItemReadOnlyList extends $.$spc.System.Object
        {
            /*object?*/ _item = null;
            $ctor$1(/*object?*/ item)
            {
                super.$ctor();
                this._item = item;
                return this;
            }
            /*object?*/ get_Item(/*int*/ index)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNotEqual($.$spc.System.Int32, index, 0, "index");
                return this._item;
            }
            /*void*/ set_Item(/*int*/ index, /*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*bool */ get IsFixedSize()
            {
                return true;
            }
            /*bool */ get IsReadOnly()
            {
                return true;
            }
            /*int */ get Count()
            {
                return 1;
            }
            /*bool */ get IsSynchronized()
            {
                return false;
            }
            /*object */ get SyncRoot()
            {
                return this;
            }
            /*IEnumerator */ GetEnumerator()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    yield this._item;
                }.bind(this)).GetEnumerator();
            }
            /*bool */ Contains(/*object?*/ value)
            {
                return this._item === null ? value === null : $.$spc.System.Object.Equals.call(this._item, value);
            }
            /*int */ IndexOf(/*object?*/ value)
            {
                return this.Contains(value) ? 0 : -1;
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                $.$so.System.Collections.CollectionHelpers.ValidateCopyToArguments(1, array, index);
                array.SetValue(this._item, index);
            }
            /*int */ Add(/*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Clear()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Insert(/*int*/ index, /*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Remove(/*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            //Generated interface implemetation for System.Collections.IList.this[int].get
            System$Collections$IList$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.this[int].set
            System$Collections$IList$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Add(object?)
            System$Collections$IList$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Contains(object?)
            System$Collections$IList$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Clear()
            System$Collections$IList$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.IsReadOnly.get
            get System$Collections$IList$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.IList.IsFixedSize.get
            get System$Collections$IList$IsFixedSize()
            {
                return this.IsFixedSize;
            }
            //Generated interface implemetation for System.Collections.IList.IndexOf(object?)
            System$Collections$IList$IndexOf()
            {
                return this.IndexOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Insert(int, object?)
            System$Collections$IList$Insert()
            {
                return this.Insert(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Remove(object?)
            System$Collections$IList$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            System$Collections$IList$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 906249;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180775433,"f":1},"s":{"r":0,"d":0,"h":21475742729,"f":1},"n":"Item","o":"@$2","d":906249,"h":12885808137,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30065677321,"f":1},"n":"IsFixedSize","d":906249,"h":25770710025,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655611913,"f":1},"n":"IsReadOnly","d":906249,"h":34360644617,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47245546505,"f":1},"n":"Count","d":906249,"h":42950579209,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55835481097,"f":1},"n":"IsSynchronized","d":906249,"h":51540513801,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":64425415689,"f":1},"n":"SyncRoot","d":906249,"h":60130448393,"f":1}],"m":[{"r":31719425,"n":"GetEnumerator","d":906249,"h":68720382985,"f":1},{"r":262145,"p":[{"n":"value","p":131073}],"n":"Contains","d":906249,"h":73015350281,"f":1},{"r":655361,"p":[{"n":"value","p":131073}],"n":"IndexOf","d":906249,"h":77310317577,"f":1},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":906249,"h":81605284873,"f":1},{"r":655361,"p":[{"n":"value","p":131073}],"n":"Add","d":906249,"h":85900252169,"f":1},{"r":65537,"n":"Clear","d":906249,"h":90195219465,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"Insert","d":906249,"h":94490186761,"f":1},{"r":65537,"p":[{"n":"value","p":131073}],"n":"Remove","d":906249,"h":98785154057,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":906249,"h":103080121353,"f":1}],"l":[{"t":131073,"n":"_item","d":906249,"h":4295873545,"f":2}],"c":[{"p":[{"n":"item","p":131073}],"n":".ctor","o":"$ctor$1","d":906249,"h":8590840841,"f":1}],"i":[31916033,31326209,31588353],"h":906249}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.SingleItemReadOnlyList`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.TypeDescriptionProviderAttribute", ($self) => class TypeDescriptionProviderAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ typeName)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(typeName, "typeName");
                    this.TypeName = typeName;
                }
                return this;
            }
            $ctor$3(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                    this.TypeName = type.AssemblyQualifiedName;
                }
                return this;
            }
            /*string*/ TypeName = null;
            static $h = 1561609;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21476398089,"f":1},"n":"TypeName","d":1561609,"h":17181430793,"f":1}],"c":[{"p":[{"n":"typeName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1561609,"h":4296528905,"f":1},{"p":[{"n":"type","p":142606337}],"n":".ctor","o":"$ctor$3","d":1561609,"h":8591496201,"f":1}],"h":1561609,"a":[{"t":14614529,"c":21489451009,"a":[{"v":4,"t":14548993}],"n":[{"n":"Inherited","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.TypeDescriptionProviderAttribute`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.TypeConverterAttribute", ($self) => class TypeConverterAttribute extends $.$spc.System.Attribute
        {
            /*TypeConverterAttribute*/ static Default = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this.ConverterTypeName = $.$spc.System.String.Empty;
                }
                return this;
            }
            $ctor$3(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                    this.ConverterTypeName = type.AssemblyQualifiedName;
                }
                return this;
            }
            $ctor$4(/*string*/ typeName)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(typeName, "typeName");
                    this.ConverterTypeName = typeName;
                }
                return this;
            }
            /*string*/ ConverterTypeName = null;
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$so.System.ComponentModel.TypeConverterAttribute, { set $v(v){ other = v; } }) && $.$spc.System.String.op_Equality(other.ConverterTypeName, this.ConverterTypeName);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$so.System.ComponentModel.TypeConverterAttribute.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.String.GetHashCode.call(this.ConverterTypeName);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$so.System.ComponentModel.TypeConverterAttribute.GetHashCode.apply(this, arguments); }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$so.System.ComponentModel.TypeConverterAttribute().$ctor$2();
                }
            }
            static $h = 1496073;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30066267145,"f":1},"n":"ConverterTypeName","d":1496073,"h":25771299849,"f":1}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":1496073,"h":34361234441,"f":32769},{"r":655361,"n":"GetHashCode","d":1496073,"h":38656201737,"f":32769}],"l":[{"t":1496073,"n":"Default","d":1496073,"h":4296463369,"f":33}],"c":[{"n":".ctor","o":"$ctor$2","d":1496073,"h":8591430665,"f":1},{"p":[{"n":"type","p":142606337}],"n":".ctor","o":"$ctor$3","d":1496073,"h":12886397961,"f":1},{"p":[{"n":"typeName","p":1310721}],"n":".ctor","o":"$ctor$4","d":1496073,"h":17181365257,"f":1}],"h":1496073,"a":[{"t":14614529,"c":21489451009,"a":[{"v":32767,"t":14548993}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.TypeConverterAttribute`; }
        });
        
        $asm.$cls("$so.System.Windows.Markup.ValueSerializerAttribute", ($self) => class ValueSerializerAttribute extends $.$spc.System.Attribute
        {
            /*Type?*/ _valueSerializerType = null;
            /*string?*/ _valueSerializerTypeName = null;
            $ctor$2(/*Type*/ valueSerializerType)
            {
                super.$ctor$1();
                {
                    this._valueSerializerType = valueSerializerType;
                }
                return this;
            }
            $ctor$3(/*string*/ valueSerializerTypeName)
            {
                super.$ctor$1();
                {
                    this._valueSerializerTypeName = valueSerializerTypeName;
                }
                return this;
            }
            /*Type */ get ValueSerializerType()
            {
                if ($.$spc.System.Type.op_Equality$1(this._valueSerializerType, null) && $.$spc.System.String.op_Inequality(this._valueSerializerTypeName, null))
                {
                    this._valueSerializerType = $.$spc.System.Type.GetType$3(this._valueSerializerTypeName);
                }
                return this._valueSerializerType;
            }
            /*string */ get ValueSerializerTypeName()
            {
                if ($.$spc.System.Type.op_Inequality$1(this._valueSerializerType, null))
                {
                    return this._valueSerializerType.AssemblyQualifiedName;
                }
                else 
                {
                    return this._valueSerializerTypeName;
                }
            }
            static $h = 1823753;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":25771627529,"f":1},"n":"ValueSerializerType","d":1823753,"h":21476660233,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34361562121,"f":1},"n":"ValueSerializerTypeName","d":1823753,"h":30066594825,"f":1}],"l":[{"t":142606337,"n":"_valueSerializerType","d":1823753,"h":4296791049,"f":2},{"t":1310721,"n":"_valueSerializerTypeName","d":1823753,"h":8591758345,"f":2}],"c":[{"p":[{"n":"valueSerializerType","p":142606337}],"n":".ctor","o":"$ctor$2","d":1823753,"h":12886725641,"f":1},{"p":[{"n":"valueSerializerTypeName","p":1310721}],"n":".ctor","o":"$ctor$3","d":1823753,"h":17181692937,"f":1}],"h":1823753,"a":[{"t":14614529,"c":21489451009,"a":[{"v":1244,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":true,"t":262145}]},{"t":96272385,"c":4391239681,"a":[{"v":"WindowsBase, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Windows.Markup.ValueSerializerAttribute`; }
        });
        
        $asm.$cls("$so.System.Collections.ObjectModel.KeyedCollection<,>", (TKey, TItem) => $asm.$gt("$so.System.Collections.ObjectModel.KeyedCollection<,>", [TKey, TItem], ($self) => class KeyedCollection$$$ extends $.$spc.System.Collections.ObjectModel.Collection$$(TItem)
        {
            /*int*/ static DefaultThreshold = 0;
            /*IEqualityComparer<TKey>*/ comparer = null;
            /*Dictionary<TKey, TItem>?*/ dict = null;
            /*int*/ keyCount = 0;
            /*int*/ threshold = 0;
            $ctor$3()
            {
                this.$ctor$5(null, 0/*DefaultThreshold*/);
                {
                }
                return this;
            }
            $ctor$4(/*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$5(comparer, 0/*DefaultThreshold*/);
                {
                }
                return this;
            }
            $ctor$5(/*IEqualityComparer<TKey>?*/ comparer, /*int*/ dictionaryCreationThreshold)
            {
                super.$ctor$2(new ($.$spc.System.Collections.Generic.List$$(TItem))().$ctor$1());
                {
                    if (dictionaryCreationThreshold < -1)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("dictionaryCreationThreshold", $.$so.System.SR.ArgumentOutOfRange_InvalidThreshold);
                    }
                    this.comparer = comparer ?? $.$spc.System.Collections.Generic.EqualityComparer$$(TKey).Default;
                    this.threshold = dictionaryCreationThreshold === -1 ? 2147483647/*int.MaxValue*/ : dictionaryCreationThreshold;
                }
                return this;
            }
            /*List<TItem> */ get Items$1()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$is(super.Items, $.$spc.System.Collections.Generic.List$$(TItem)), "base.Items is List<TItem>");
                return $.$cast(super.Items, $.$spc.System.Collections.Generic.List$$(TItem));
            }
            /*IEqualityComparer<TKey> */ get Comparer()
            {
                return this.comparer;
            }
            /*TItem*/ get_Item$1(/*TKey*/ key)
            {
                /*TItem*/ let item;
                if (this.TryGetValue(key, $.$ref(() => item, ($v) => item = $v, TItem)))
                {
                    return item;
                }
                throw new $.$spc.System.Collections.Generic.KeyNotFoundException().$ctor$10($.$so.System.SR.Format($.$so.System.SR.Arg_KeyNotFoundWithKey, $.$spc.System.Object.ToString.call(key)));
            }
            /*bool */ Contains$1(/*TKey*/ key)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull($.$box(key, TKey), "key");
                if (this.dict !== null)
                {
                    return this.dict.ContainsKey(key);
                }
                var $en2 = this.Items$1.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        if (this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(this.GetKeyForItem(item), key, [TKey]))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*bool */ TryGetValue(/*TKey*/ key, /*out TItem*/ item)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull($.$box(key, TKey), "key");
                if (this.dict !== null)
                {
                    return this.dict.TryGetValue(key, item);
                }
                var $en2 = this.Items$1.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var itemInItems = $en2.Current;
                    {
                        /*TKey*/ let keyInItems = this.GetKeyForItem(itemInItems);
                        if ($.$box(keyInItems, TKey) !== null && this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(key, keyInItems, [TKey]))
                        {
                            item.$v = itemInItems;
                            return true;
                        }
                    }
                }
                item.$v = $.$default(TItem);
                return false;
            }
            /*bool */ ContainsItem(/*TItem*/ item)
            {
                /*TKey*/ let key;
                if ((this.dict === null) || (($.$box(key = this.GetKeyForItem(item), TKey)) === null))
                {
                    return this.Items$1.Contains(item);
                }
                /*TItem*/ let itemInDict;
                if (this.dict.TryGetValue(key, $.$ref(() => itemInDict, ($v) => itemInDict = $v, TItem)))
                {
                    return $.$spc.System.Collections.Generic.EqualityComparer$$(TItem).Default.Equals$2(itemInDict, item);
                }
                return false;
            }
            /*bool */ Remove$1(/*TKey*/ key)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull($.$box(key, TKey), "key");
                if (this.dict !== null)
                {
                    /*TItem*/ let item;
                    return this.dict.TryGetValue(key, $.$ref(() => item, ($v) => item = $v, TItem)) && this.Remove(item);
                }
                for(/*int*/ let i = 0; i < this.Items$1.Count; i++)
                {
                    if (this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(this.GetKeyForItem(this.Items$1.get_Item(i)), key, [TKey]))
                    {
                        this.RemoveItem(i);
                        return true;
                    }
                }
                return false;
            }
            /*IDictionary<TKey, TItem>? */ get Dictionary()
            {
                return this.dict;
            }
            /*void */ ChangeItemKey(/*TItem*/ item, /*TKey*/ newKey)
            {
                if (!this.ContainsItem(item))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Argument_ItemNotExist, "item");
                }
                /*TKey*/ let oldKey = this.GetKeyForItem(item);
                if (!this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(oldKey, newKey, [TKey]))
                {
                    if ($.$box(newKey, TKey) !== null)
                    {
                        this.AddKey(newKey, item);
                    }
                    if ($.$box(oldKey, TKey) !== null)
                    {
                        this.RemoveKey(oldKey);
                    }
                }
            }
            /*void */ ClearItems()
            {
                super.ClearItems();
                this.dict?.Clear();
                this.keyCount = 0;
            }
            /*void */ InsertItem(/*int*/ index, /*TItem*/ item)
            {
                /*TKey*/ let key = this.GetKeyForItem(item);
                if ($.$box(key, TKey) !== null)
                {
                    this.AddKey(key, item);
                }
                super.InsertItem(index, item);
            }
            /*void */ RemoveItem(/*int*/ index)
            {
                /*TKey*/ let key = this.GetKeyForItem(this.Items$1.get_Item(index));
                if ($.$box(key, TKey) !== null)
                {
                    this.RemoveKey(key);
                }
                super.RemoveItem(index);
            }
            /*void */ SetItem(/*int*/ index, /*TItem*/ item)
            {
                /*TKey*/ let newKey = this.GetKeyForItem(item);
                /*TKey*/ let oldKey = this.GetKeyForItem(this.Items$1.get_Item(index));
                if (this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(oldKey, newKey, [TKey]))
                {
                    if ($.$box(newKey, TKey) !== null && this.dict !== null)
                    {
                        this.dict.set_Item(newKey, item);
                    }
                }
                else 
                {
                    if ($.$box(newKey, TKey) !== null)
                    {
                        this.AddKey(newKey, item);
                    }
                    if ($.$box(oldKey, TKey) !== null)
                    {
                        this.RemoveKey(oldKey);
                    }
                }
                super.SetItem(index, item);
            }
            /*void */ AddKey(/*TKey*/ key, /*TItem*/ item)
            {
                if (this.dict !== null)
                {
                    this.dict.Add(key, item);
                }
                else if (this.keyCount === this.threshold)
                {
                    this.CreateDictionary();
                    this.dict.Add(key, item);
                }
                else 
                {
                    if (this.Contains$1(key))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Format($.$so.System.SR.Argument_AddingDuplicate, $.$box(key, TKey)), "key");
                    }
                    this.keyCount++;
                }
            }
            /*void */ CreateDictionary()
            {
                this.dict = new ($.$spc.System.Collections.Generic.Dictionary$$$(TKey, TItem))().$ctor$3(this.comparer);
                var $en2 = this.Items$1.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        /*TKey*/ let key = this.GetKeyForItem(item);
                        if ($.$box(key, TKey) !== null)
                        {
                            this.dict.Add(key, item);
                        }
                    }
                }
            }
            /*void */ RemoveKey(/*TKey*/ key)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$box(key, TKey) !== null, "key shouldn't be null!");
                if (this.dict !== null)
                {
                    this.dict.Remove(key);
                }
                else 
                {
                    this.keyCount--;
                }
            }
            static $h = 316425;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$spc.System.Collections.Generic.List$$(TItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2},"n":"Items","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2},{"p":$.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":1},"n":"Comparer","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1},{"p":TItem?.$h??1572864,"i":[{"n":"key","p":TKey?.$h??1507328}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":1},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":1},{"p":$.$spc.System.Collections.Generic.IDictionary$$$(TKey, TItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1400000000n),"f":4},"n":"Dictionary","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":4}],"m":[{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328}],"n":"Contains","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":1},{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"item","p":TItem?.$h??1572864,"f":2}],"n":"TryGetValue","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":1},{"r":262145,"p":[{"n":"item","p":TItem?.$h??1572864}],"n":"ContainsItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":2},{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328}],"n":"Remove","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":1},{"r":65537,"p":[{"n":"item","p":TItem?.$h??1572864},{"n":"newKey","p":TKey?.$h??1507328}],"n":"ChangeItemKey","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":4},{"r":65537,"n":"ClearItems","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":32772},{"r":TKey?.$h??1507328,"p":[{"n":"item","p":TItem?.$h??1572864}],"n":"GetKeyForItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":260},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":TItem?.$h??1572864}],"n":"InsertItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":32772},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":32772},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":TItem?.$h??1572864}],"n":"SetItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":32772},{"r":65537,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"item","p":TItem?.$h??1572864}],"n":"AddKey","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":2},{"r":65537,"n":"CreateDictionary","d":this.$h,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":2},{"r":65537,"p":[{"n":"key","p":TKey?.$h??1507328}],"n":"RemoveKey","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":2}],"l":[{"t":655361,"n":"DefaultThreshold","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":34},{"t":$.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h,"n":"comparer","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$(TKey, TItem).$h,"n":"dict","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":655361,"n":"keyCount","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":655361,"n":"threshold","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":4},{"p":[{"n":"comparer","p":$.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":4},{"p":[{"n":"comparer","p":$.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h},{"n":"dictionaryCreationThreshold","p":655361}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":4}],"i":[$.$spc.System.Collections.Generic.IList$$(TItem).$h,$.$spc.System.Collections.Generic.ICollection$$(TItem).$h,31916033,31326209,$.$spc.System.Collections.Generic.IReadOnlyList$$(TItem).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$(TItem).$h,$.$spc.System.Collections.Generic.IEnumerable$$(TItem).$h,31588353],"g":[TKey?.$h??1507328,TItem?.$h??1572864],"s":[{"n":"TKey","f":64},null],"r":2,"h":this.$h,"a":[{"t":118226945,"c":4413194241},{"t":37879809,"c":8627814401,"a":[{"v":null,"t":142606337}]},{"t":37552129,"c":8627486721,"a":[{"v":"Count = {Count}","t":1310721}]},{"t":96272385,"c":4391239681,"a":[{"v":"mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Collections.ObjectModel.Collection$$(TItem); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IList$$(TItem), $.$spc.System.Collections.Generic.ICollection$$(TItem), $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.Generic.IReadOnlyList$$(TItem), $.$spc.System.Collections.Generic.IReadOnlyCollection$$(TItem), $.$spc.System.Collections.Generic.IEnumerable$$(TItem), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.ObjectModel.KeyedCollection<${TKey?.$fullName},${TItem?.$fullName}>`; }
        }));
        
        $asm.$str("$so.System.Collections.Specialized.NotifyCollectionChangedAction", ($self) => class NotifyCollectionChangedAction extends $.$spc.System.Enum
        {
            static Add = 0;
            static Remove = 1;
            static Replace = 2;
            static Move = 3;
            static Reset = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Remove": 1n,
                    "Replace": 2n,
                    "Move": 3n,
                    "Reset": 4n
                };
            }
            static $h = 644105;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":644105,"n":"Add","d":644105,"h":4295611401,"f":33},{"t":644105,"n":"Remove","d":644105,"h":8590578697,"f":33},{"t":644105,"n":"Replace","d":644105,"h":12885545993,"f":33},{"t":644105,"n":"Move","d":644105,"h":17180513289,"f":33},{"t":644105,"n":"Reset","d":644105,"h":21475480585,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":644105,"h":25770447881,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":644105}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Collections.Specialized.NotifyCollectionChangedAction`; }
        });
        
        $asm.$cls("$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs", ($self) => class NotifyCollectionChangedEventArgs extends $.$spc.System.EventArgs
        {
            /*NotifyCollectionChangedAction*/ _action = 0;
            /*IList?*/ _newItems = null;
            /*IList?*/ _oldItems = null;
            /*int*/ _newStartingIndex = -1;
            /*int*/ _oldStartingIndex = -1;
            $ctor$2(/*NotifyCollectionChangedAction*/ action)
            {
                super.$ctor$1();
                {
                    if (action !== 4/*NotifyCollectionChangedAction.Reset*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Format($.$so.System.SR.WrongActionForCtor, $.$box(4/*NotifyCollectionChangedAction.Reset*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    this._action = action;
                }
                return this;
            }
            $ctor$3(/*NotifyCollectionChangedAction*/ action, /*object?*/ changedItem)
            {
                this.$ctor$4(action, changedItem, -1);
                {
                }
                return this;
            }
            $ctor$4(/*NotifyCollectionChangedAction*/ action, /*object?*/ changedItem, /*int*/ index)
            {
                super.$ctor$1();
                {
                    switch(action)
                    {
                        case 4/*NotifyCollectionChangedAction.Reset*/:
                        if (changedItem !== null)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.ResetActionRequiresNullItem, "action");
                        }
                        if (index !== -1)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.ResetActionRequiresIndexMinus1, "action");
                        }
                        break;
                        case 0/*NotifyCollectionChangedAction.Add*/:
                        this._newItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(changedItem);
                        this._newStartingIndex = index;
                        break;
                        case 1/*NotifyCollectionChangedAction.Remove*/:
                        this._oldItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(changedItem);
                        this._oldStartingIndex = index;
                        break;
                        default:
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.MustBeResetAddOrRemoveActionForCtor, "action");
                    }
                    this._action = action;
                }
                return this;
            }
            $ctor$5(/*NotifyCollectionChangedAction*/ action, /*IList?*/ changedItems)
            {
                this.$ctor$6(action, changedItems, -1);
                {
                }
                return this;
            }
            $ctor$6(/*NotifyCollectionChangedAction*/ action, /*IList?*/ changedItems, /*int*/ startingIndex)
            {
                super.$ctor$1();
                {
                    switch(action)
                    {
                        case 4/*NotifyCollectionChangedAction.Reset*/:
                        if (changedItems !== null)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.ResetActionRequiresNullItem, "action");
                        }
                        if (startingIndex !== -1)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.ResetActionRequiresIndexMinus1, "action");
                        }
                        break;
                        case 0/*NotifyCollectionChangedAction.Add*/:
                        case 1/*NotifyCollectionChangedAction.Remove*/:
                        $.$spc.System.ArgumentNullException.ThrowIfNull(changedItems, "changedItems");
                        $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, startingIndex, -1, "startingIndex");
                        if (action === 0/*NotifyCollectionChangedAction.Add*/)
                        {
                            this._newItems = new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(changedItems);
                            this._newStartingIndex = startingIndex;
                        }
                        else 
                        {
                            this._oldItems = new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(changedItems);
                            this._oldStartingIndex = startingIndex;
                        }
                        break;
                        default:
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.MustBeResetAddOrRemoveActionForCtor, "action");
                    }
                    this._action = action;
                }
                return this;
            }
            $ctor$7(/*NotifyCollectionChangedAction*/ action, /*object?*/ newItem, /*object?*/ oldItem)
            {
                this.$ctor$8(action, newItem, oldItem, -1);
                {
                }
                return this;
            }
            $ctor$8(/*NotifyCollectionChangedAction*/ action, /*object?*/ newItem, /*object?*/ oldItem, /*int*/ index)
            {
                super.$ctor$1();
                {
                    if (action !== 2/*NotifyCollectionChangedAction.Replace*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Format($.$so.System.SR.WrongActionForCtor, $.$box(2/*NotifyCollectionChangedAction.Replace*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    this._action = action;
                    this._newItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(newItem);
                    this._oldItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(oldItem);
                    this._newStartingIndex = this._oldStartingIndex = index;
                }
                return this;
            }
            $ctor$9(/*NotifyCollectionChangedAction*/ action, /*IList*/ newItems, /*IList*/ oldItems)
            {
                this.$ctor$10(action, newItems, oldItems, -1);
                {
                }
                return this;
            }
            $ctor$10(/*NotifyCollectionChangedAction*/ action, /*IList*/ newItems, /*IList*/ oldItems, /*int*/ startingIndex)
            {
                super.$ctor$1();
                {
                    if (action !== 2/*NotifyCollectionChangedAction.Replace*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Format($.$so.System.SR.WrongActionForCtor, $.$box(2/*NotifyCollectionChangedAction.Replace*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    $.$spc.System.ArgumentNullException.ThrowIfNull(newItems, "newItems");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(oldItems, "oldItems");
                    this._action = action;
                    this._newItems = new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(newItems);
                    this._oldItems = new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(oldItems);
                    this._newStartingIndex = this._oldStartingIndex = startingIndex;
                }
                return this;
            }
            $ctor$11(/*NotifyCollectionChangedAction*/ action, /*object?*/ changedItem, /*int*/ index, /*int*/ oldIndex)
            {
                super.$ctor$1();
                {
                    if (action !== 3/*NotifyCollectionChangedAction.Move*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Format($.$so.System.SR.WrongActionForCtor, $.$box(3/*NotifyCollectionChangedAction.Move*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                    this._action = action;
                    this._newItems = this._oldItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(changedItem);
                    this._newStartingIndex = index;
                    this._oldStartingIndex = oldIndex;
                }
                return this;
            }
            $ctor$12(/*NotifyCollectionChangedAction*/ action, /*IList?*/ changedItems, /*int*/ index, /*int*/ oldIndex)
            {
                super.$ctor$1();
                {
                    if (action !== 3/*NotifyCollectionChangedAction.Move*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Format($.$so.System.SR.WrongActionForCtor, $.$box(3/*NotifyCollectionChangedAction.Move*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                    this._action = action;
                    this._newItems = this._oldItems = !(changedItems === null) ? new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(changedItems) : null;
                    this._newStartingIndex = index;
                    this._oldStartingIndex = oldIndex;
                }
                return this;
            }
            /*NotifyCollectionChangedAction */ get Action()
            {
                return this._action;
            }
            /*IList? */ get NewItems()
            {
                return this._newItems;
            }
            /*IList? */ get OldItems()
            {
                return this._oldItems;
            }
            /*int */ get NewStartingIndex()
            {
                return this._newStartingIndex;
            }
            /*int */ get OldStartingIndex()
            {
                return this._oldStartingIndex;
            }
            static $h = 709641;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":644105,"g":{"r":0,"d":0,"h":77310120969,"f":1},"n":"Action","d":709641,"h":73015153673,"f":1},{"p":31916033,"g":{"r":0,"d":0,"h":85900055561,"f":1},"n":"NewItems","d":709641,"h":81605088265,"f":1},{"p":31916033,"g":{"r":0,"d":0,"h":94489990153,"f":1},"n":"OldItems","d":709641,"h":90195022857,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103079924745,"f":1},"n":"NewStartingIndex","d":709641,"h":98784957449,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":111669859337,"f":1},"n":"OldStartingIndex","d":709641,"h":107374892041,"f":1}],"l":[{"t":644105,"n":"_action","d":709641,"h":4295676937,"f":2},{"t":31916033,"n":"_newItems","d":709641,"h":8590644233,"f":2},{"t":31916033,"n":"_oldItems","d":709641,"h":12885611529,"f":2},{"t":655361,"n":"_newStartingIndex","d":709641,"h":17180578825,"f":2},{"t":655361,"n":"_oldStartingIndex","d":709641,"h":21475546121,"f":2}],"c":[{"p":[{"n":"action","p":644105}],"n":".ctor","o":"$ctor$2","d":709641,"h":25770513417,"f":1},{"p":[{"n":"action","p":644105},{"n":"changedItem","p":131073}],"n":".ctor","o":"$ctor$3","d":709641,"h":30065480713,"f":1},{"p":[{"n":"action","p":644105},{"n":"changedItem","p":131073},{"n":"index","p":655361}],"n":".ctor","o":"$ctor$4","d":709641,"h":34360448009,"f":1},{"p":[{"n":"action","p":644105},{"n":"changedItems","p":31916033}],"n":".ctor","o":"$ctor$5","d":709641,"h":38655415305,"f":1},{"p":[{"n":"action","p":644105},{"n":"changedItems","p":31916033},{"n":"startingIndex","p":655361}],"n":".ctor","o":"$ctor$6","d":709641,"h":42950382601,"f":1},{"p":[{"n":"action","p":644105},{"n":"newItem","p":131073},{"n":"oldItem","p":131073}],"n":".ctor","o":"$ctor$7","d":709641,"h":47245349897,"f":1},{"p":[{"n":"action","p":644105},{"n":"newItem","p":131073},{"n":"oldItem","p":131073},{"n":"index","p":655361}],"n":".ctor","o":"$ctor$8","d":709641,"h":51540317193,"f":1},{"p":[{"n":"action","p":644105},{"n":"newItems","p":31916033},{"n":"oldItems","p":31916033}],"n":".ctor","o":"$ctor$9","d":709641,"h":55835284489,"f":1},{"p":[{"n":"action","p":644105},{"n":"newItems","p":31916033},{"n":"oldItems","p":31916033},{"n":"startingIndex","p":655361}],"n":".ctor","o":"$ctor$10","d":709641,"h":60130251785,"f":1},{"p":[{"n":"action","p":644105},{"n":"changedItem","p":131073},{"n":"index","p":655361},{"n":"oldIndex","p":655361}],"n":".ctor","o":"$ctor$11","d":709641,"h":64425219081,"f":1},{"p":[{"n":"action","p":644105},{"n":"changedItems","p":31916033},{"n":"index","p":655361},{"n":"oldIndex","p":655361}],"n":".ctor","o":"$ctor$12","d":709641,"h":68720186377,"f":1}],"h":709641}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Collections.Specialized.NotifyCollectionChangedEventArgs`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.DataErrorsChangedEventArgs", ($self) => class DataErrorsChangedEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*string?*/ propertyName)
            {
                super.$ctor$1();
                {
                    this.PropertyName = propertyName;
                }
                return this;
            }
            /*string?*/ PropertyName = null;
            static $h = 971785;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180840969,"f":129},"n":"PropertyName","d":971785,"h":12885873673,"f":129}],"c":[{"p":[{"n":"propertyName","p":1310721}],"n":".ctor","o":"$ctor$2","d":971785,"h":4295939081,"f":1}],"h":971785}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.ComponentModel.DataErrorsChangedEventArgs`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.PropertyChangedEventArgs", ($self) => class PropertyChangedEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*string?*/ propertyName)
            {
                super.$ctor$1();
                {
                    this.PropertyName = propertyName;
                }
                return this;
            }
            /*string?*/ PropertyName = null;
            static $h = 1233929;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181103113,"f":129},"n":"PropertyName","d":1233929,"h":12886135817,"f":129}],"c":[{"p":[{"n":"propertyName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1233929,"h":4296201225,"f":1}],"h":1233929}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.ComponentModel.PropertyChangedEventArgs`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.PropertyChangingEventArgs", ($self) => class PropertyChangingEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*string?*/ propertyName)
            {
                super.$ctor$1();
                {
                    this.PropertyName = propertyName;
                }
                return this;
            }
            /*string?*/ PropertyName = null;
            static $h = 1365001;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181234185,"f":129},"n":"PropertyName","d":1365001,"h":12886266889,"f":129}],"c":[{"p":[{"n":"propertyName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1365001,"h":4296332297,"f":1}],"h":1365001}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.ComponentModel.PropertyChangingEventArgs`; }
        });
        
        $asm.$cls("$so.System.Collections.ObjectModel.ObservableCollection<>", (T) => $asm.$gt("$so.System.Collections.ObjectModel.ObservableCollection<>", [T], ($self) => class ObservableCollection$$ extends $.$spc.System.Collections.ObjectModel.Collection$$(T)
        {
            /*SimpleMonitor?*/ _monitor = null;
            /*int*/ _blockReentrancyCount = 0;
            $ctor$3()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*IEnumerable<T>*/ collection)
            {
                super.$ctor$2(new ($.$spc.System.Collections.Generic.List$$(T))().$ctor$3($.$firstOf(collection, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("collection") })));
                {
                }
                return this;
            }
            $ctor$5(/*List<T>*/ list)
            {
                super.$ctor$2(new ($.$spc.System.Collections.Generic.List$$(T))().$ctor$3($.$firstOf(list, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("list") })));
                {
                }
                return this;
            }
            /*void */ Move(/*int*/ oldIndex, /*int*/ newIndex)
            {
                return this.MoveItem(oldIndex, newIndex);
            }
            /*PropertyChangedEventHandler?*/ $so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged$add(value)
            {
                return this.PropertyChanged$add(value);
            }
            /*PropertyChangedEventHandler?*/ $so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged$remove(value)
            {
                this.PropertyChanged$remove(value);
            }
            /*NotifyCollectionChangedEventHandler?*/ CollectionChanged = null;
             CollectionChanged$add(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                this.CollectionChanged = $.$spc.System.Delegate.Combine(this.CollectionChanged, value);
            }
             CollectionChanged$remove(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                this.CollectionChanged = $.$spc.System.Delegate.Remove(this.CollectionChanged, value);
            }
            /*void */ ClearItems()
            {
                this.CheckReentrancy();
                super.ClearItems();
                this.OnCountPropertyChanged();
                this.OnIndexerPropertyChanged();
                this.OnCollectionReset();
            }
            /*void */ RemoveItem(/*int*/ index)
            {
                this.CheckReentrancy();
                /*T*/ let removedItem = this.get_Item(index);
                super.RemoveItem(index);
                this.OnCountPropertyChanged();
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged$1(1/*NotifyCollectionChangedAction.Remove*/, $.$box(removedItem, T), index);
            }
            /*void */ InsertItem(/*int*/ index, /*T*/ item)
            {
                this.CheckReentrancy();
                super.InsertItem(index, item);
                this.OnCountPropertyChanged();
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged$1(0/*NotifyCollectionChangedAction.Add*/, $.$box(item, T), index);
            }
            /*void */ SetItem(/*int*/ index, /*T*/ item)
            {
                this.CheckReentrancy();
                /*T*/ let originalItem = this.get_Item(index);
                super.SetItem(index, item);
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged$3(2/*NotifyCollectionChangedAction.Replace*/, $.$box(originalItem, T), $.$box(item, T), index);
            }
            /*void */ MoveItem(/*int*/ oldIndex, /*int*/ newIndex)
            {
                this.CheckReentrancy();
                /*T*/ let removedItem = this.get_Item(oldIndex);
                super.RemoveItem(oldIndex);
                super.InsertItem(newIndex, removedItem);
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged$2(3/*NotifyCollectionChangedAction.Move*/, $.$box(removedItem, T), newIndex, oldIndex);
            }
            /*void */ OnPropertyChanged(/*PropertyChangedEventArgs*/ e)
            {
                this.PropertyChanged?.Invoke(this, e);
            }
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
             PropertyChanged$add(/*PropertyChangedEventHandler?*/ value)
            {
                this.PropertyChanged = $.$spc.System.Delegate.Combine(this.PropertyChanged, value);
            }
             PropertyChanged$remove(/*PropertyChangedEventHandler?*/ value)
            {
                this.PropertyChanged = $.$spc.System.Delegate.Remove(this.PropertyChanged, value);
            }
            /*void */ OnCollectionChanged(/*NotifyCollectionChangedEventArgs*/ e)
            {
                /*NotifyCollectionChangedEventHandler?*/ let handler = this.CollectionChanged;
                if (handler !== null)
                {
                    this._blockReentrancyCount++;
                    try
                    {
                        handler.Invoke(this, e);
                    }
                    finally
                    {
                        {
                            this._blockReentrancyCount--;
                        }
                    }
                }
            }
            /*IDisposable */ BlockReentrancy()
            {
                this._blockReentrancyCount++;
                return this.EnsureMonitorInitialized();
            }
            /*void */ CheckReentrancy()
            {
                if (this._blockReentrancyCount > 0)
                {
                    /*NotifyCollectionChangedEventHandler?*/ let handler = this.CollectionChanged;
                    if (handler !== null && !handler.HasSingleTarget)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$so.System.SR.ObservableCollectionReentrancyNotAllowed);
                    }
                }
            }
            /*void */ OnCountPropertyChanged()
            {
                return this.OnPropertyChanged($.$so.System.Collections.ObjectModel.EventArgsCache.CountPropertyChanged);
            }
            /*void */ OnIndexerPropertyChanged()
            {
                return this.OnPropertyChanged($.$so.System.Collections.ObjectModel.EventArgsCache.IndexerPropertyChanged);
            }
            /*void */ OnCollectionChanged$1(/*NotifyCollectionChangedAction*/ action, /*object?*/ item, /*int*/ index)
            {
                this.OnCollectionChanged(new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs().$ctor$4(action, item, index));
            }
            /*void */ OnCollectionChanged$2(/*NotifyCollectionChangedAction*/ action, /*object?*/ item, /*int*/ index, /*int*/ oldIndex)
            {
                this.OnCollectionChanged(new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs().$ctor$11(action, item, index, oldIndex));
            }
            /*void */ OnCollectionChanged$3(/*NotifyCollectionChangedAction*/ action, /*object?*/ oldItem, /*object?*/ newItem, /*int*/ index)
            {
                this.OnCollectionChanged(new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs().$ctor$8(action, newItem, oldItem, index));
            }
            /*void */ OnCollectionReset()
            {
                return this.OnCollectionChanged($.$so.System.Collections.ObjectModel.EventArgsCache.ResetCollectionChanged);
            }
            /*SimpleMonitor */ EnsureMonitorInitialized()
            {
                return this._monitor ??= new ($.$so.System.Collections.ObjectModel.ObservableCollection$$(T).SimpleMonitor)().$ctor$1(this);
            }
            /*void */ OnSerializing(/*StreamingContext*/ context)
            {
                this.EnsureMonitorInitialized();
                this._monitor._busyCount = this._blockReentrancyCount;
            }
            /*void */ OnDeserialized(/*StreamingContext*/ context)
            {
                if (this._monitor !== null)
                {
                    this._blockReentrancyCount = this._monitor._busyCount;
                    this._monitor._collection = this;
                }
            }
            static $_SimpleMonitor;
            static get SimpleMonitor()
            {
                let $cls = $.$so.System.Collections.ObjectModel.ObservableCollection$$(T);
                return $cls.$_SimpleMonitor ??= $asm.$ncls("$so.System.Collections.ObjectModel.ObservableCollection$$.SimpleMonitor", ($self) => class SimpleMonitor extends $.$spc.System.Object
                {
                    /*int*/ _busyCount = 0;
                    /*ObservableCollection<T>*/ _collection = null;
                    $ctor$1(/*ObservableCollection<T>*/ collection)
                    {
                        super.$ctor();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(collection !== null, "collection != null");
                            this._collection = collection;
                        }
                        return this;
                    }
                    /*void */ Dispose()
                    {
                        return this._collection._blockReentrancyCount--;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 447497;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"l":[{"t":655361,"n":"_busyCount","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8},{"t":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).$h,"n":"_collection","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":8,"a":[{"t":66519041,"c":4361486337}]}],"c":[{"p":[{"n":"collection","p":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"i":[57475073],"d":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).$h,"h":this.$h,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]}]}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `System.Collections.ObjectModel.ObservableCollection<${T?.$fullName}>.SimpleMonitor`; }
                }, $cls, ($v) => $cls.$_SimpleMonitor = $v);
            }
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged.add
            System$Collections$Specialized$INotifyCollectionChanged$add_CollectionChanged()
            {
                return this.add_CollectionChanged(...arguments);
            }
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged.remove
            System$Collections$Specialized$INotifyCollectionChanged$remove_CollectionChanged()
            {
                return this.remove_CollectionChanged(...arguments);
            }
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged
            $so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged()
            {
                this.CollectionChanged;
            }
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            $so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                this.$so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged;
            }
            static $h = 381961;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"oldIndex","p":655361},{"n":"newIndex","p":655361}],"n":"Move","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},{"r":65537,"n":"ClearItems","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":32772},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveItem","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":32772},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":T?.$h??1507328}],"n":"InsertItem","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":32772},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":T?.$h??1507328}],"n":"SetItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":32772},{"r":65537,"p":[{"n":"oldIndex","p":655361},{"n":"newIndex","p":655361}],"n":"MoveItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":132},{"r":65537,"p":[{"n":"e","p":1233929}],"n":"OnPropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":132},{"r":65537,"p":[{"n":"e","p":709641}],"n":"OnCollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":132},{"r":57475073,"n":"BlockReentrancy","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":4},{"r":65537,"n":"CheckReentrancy","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":4},{"r":65537,"n":"OnCountPropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":2},{"r":65537,"n":"OnIndexerPropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":2},{"r":65537,"p":[{"n":"action","p":644105},{"n":"item","p":131073},{"n":"index","p":655361}],"n":"OnCollectionChanged","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":2},{"r":65537,"p":[{"n":"action","p":644105},{"n":"item","p":131073},{"n":"index","p":655361},{"n":"oldIndex","p":655361}],"n":"OnCollectionChanged","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":2},{"r":65537,"p":[{"n":"action","p":644105},{"n":"oldItem","p":131073},{"n":"newItem","p":131073},{"n":"index","p":655361}],"n":"OnCollectionChanged","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":2},{"r":65537,"n":"OnCollectionReset","d":this.$h,"h":Number(BigInt(this.$h)|0x1E00000000n),"f":2},{"r":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).SimpleMonitor.$h,"n":"EnsureMonitorInitialized","d":this.$h,"h":Number(BigInt(this.$h)|0x1F00000000n),"f":2},{"r":65537,"p":[{"n":"context","p":114098177}],"n":"OnSerializing","d":this.$h,"h":Number(BigInt(this.$h)|0x2000000000n),"f":2,"a":[{"t":113639425,"c":4408606721}]},{"r":65537,"p":[{"n":"context","p":114098177}],"n":"OnDeserialized","d":this.$h,"h":Number(BigInt(this.$h)|0x2100000000n),"f":2,"a":[{"t":113442817,"c":4408410113}]}],"l":[{"t":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).SimpleMonitor.$h,"n":"_monitor","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":655361,"n":"_blockReentrancyCount","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2,"a":[{"t":66519041,"c":4361486337}]}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":[{"n":"collection","p":$.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},{"p":[{"n":"list","p":$.$spc.System.Collections.Generic.List$$(T).$h}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"e":[{"e":1299465,"m":{"r":65537,"p":[{"n":"value","p":1299465}],"n":"{1102857}.add_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$add_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":2},"r":{"r":65537,"p":[{"n":"value","p":1299465}],"n":"{1102857}.remove_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$remove_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2},"n":"System.ComponentModel.INotifyPropertyChanged.PropertyChanged","o":"$so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2},{"e":775177,"m":{"r":65537,"p":[{"n":"value","p":775177}],"n":"add_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":129},"r":{"r":65537,"p":[{"n":"value","p":775177}],"n":"remove_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":129},"n":"CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":129},{"e":1299465,"m":{"r":65537,"p":[{"n":"value","p":1299465}],"n":"add_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":132},"r":{"r":65537,"p":[{"n":"value","p":1299465}],"n":"remove_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":132},"n":"PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":132}],"i":[$.$spc.System.Collections.Generic.IList$$(T).$h,$.$spc.System.Collections.Generic.ICollection$$(T).$h,31916033,31326209,$.$spc.System.Collections.Generic.IReadOnlyList$$(T).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$spc.System.Collections.Generic.IEnumerable$$(T).$h,31588353,578569,1102857],"g":[T?.$h??1507328],"j":[$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).SimpleMonitor.$h],"r":1,"h":this.$h,"a":[{"t":118226945,"c":4413194241},{"t":37879809,"c":8627814401,"a":[{"v":$.$so.System.Collections.Generic.CollectionDebugView$$().$h,"t":142606337}]},{"t":37552129,"c":8627486721,"a":[{"v":"Count = {Count}","t":1310721}]},{"t":96272385,"c":4391239681,"a":[{"v":"WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Collections.ObjectModel.Collection$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IList$$(T), $.$spc.System.Collections.Generic.ICollection$$(T), $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.Generic.IReadOnlyList$$(T), $.$spc.System.Collections.Generic.IReadOnlyCollection$$(T), $.$spc.System.Collections.Generic.IEnumerable$$(T), $.$spc.System.Collections.IEnumerable, $.$so.System.Collections.Specialized.INotifyCollectionChanged, $.$so.System.ComponentModel.INotifyPropertyChanged ]; }
            static get $fullName() { return `System.Collections.ObjectModel.ObservableCollection<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$so.System.Collections.ObjectModel.ReadOnlyObservableCollection<>", (T) => $asm.$gt("$so.System.Collections.ObjectModel.ReadOnlyObservableCollection<>", [T], ($self) => class ReadOnlyObservableCollection$$ extends $.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$(T)
        {
            $ctor$2(/*ObservableCollection<T>*/ list)
            {
                super.$ctor$1(list);
                {
                    ($.$cast(this.Items, $.$so.System.Collections.Specialized.INotifyCollectionChanged)).$so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged$add(new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventHandler().$ctor(this, this.HandleCollectionChanged));
                    ($.$cast(this.Items, $.$so.System.ComponentModel.INotifyPropertyChanged)).$so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged$add(new $.$so.System.ComponentModel.PropertyChangedEventHandler().$ctor(this, this.HandlePropertyChanged));
                }
                return this;
            }
            /*ReadOnlyObservableCollection<T>*/ static Empty$1 = null;
            /*NotifyCollectionChangedEventHandler?*/ $so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged$add(value)
            {
                return this.CollectionChanged$add(value);
            }
            /*NotifyCollectionChangedEventHandler?*/ $so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged$remove(value)
            {
                this.CollectionChanged$remove(value);
            }
            /*NotifyCollectionChangedEventHandler?*/ CollectionChanged = null;
             CollectionChanged$add(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                this.CollectionChanged = $.$spc.System.Delegate.Combine(this.CollectionChanged, value);
            }
             CollectionChanged$remove(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                this.CollectionChanged = $.$spc.System.Delegate.Remove(this.CollectionChanged, value);
            }
            /*void */ OnCollectionChanged(/*NotifyCollectionChangedEventArgs*/ args)
            {
                this.CollectionChanged?.Invoke(this, args);
            }
            /*PropertyChangedEventHandler?*/ $so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged$add(value)
            {
                return this.PropertyChanged$add(value);
            }
            /*PropertyChangedEventHandler?*/ $so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged$remove(value)
            {
                this.PropertyChanged$remove(value);
            }
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
             PropertyChanged$add(/*PropertyChangedEventHandler?*/ value)
            {
                this.PropertyChanged = $.$spc.System.Delegate.Combine(this.PropertyChanged, value);
            }
             PropertyChanged$remove(/*PropertyChangedEventHandler?*/ value)
            {
                this.PropertyChanged = $.$spc.System.Delegate.Remove(this.PropertyChanged, value);
            }
            /*void */ OnPropertyChanged(/*PropertyChangedEventArgs*/ args)
            {
                this.PropertyChanged?.Invoke(this, args);
            }
            /*void */ HandleCollectionChanged(/*object?*/ sender, /*NotifyCollectionChangedEventArgs*/ e)
            {
                this.OnCollectionChanged(e);
            }
            /*void */ HandlePropertyChanged(/*object?*/ sender, /*PropertyChangedEventArgs*/ e)
            {
                this.OnPropertyChanged(e);
            }
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged
            $so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged()
            {
                this.$so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged;
            }
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            $so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                this.$so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty$1 = new ($.$so.System.Collections.ObjectModel.ReadOnlyObservableCollection$$(T))().$ctor$2(new ($.$so.System.Collections.ObjectModel.ObservableCollection$$(T))().$ctor$3());
                }
            }
            static $h = 513033;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":this.$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":33},"n":"Empty","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":33}],"m":[{"r":65537,"p":[{"n":"args","p":709641}],"n":"OnCollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":132},{"r":65537,"p":[{"n":"args","p":1233929}],"n":"OnPropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":132},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":709641}],"n":"HandleCollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":2},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1233929}],"n":"HandlePropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":2}],"c":[{"p":[{"n":"list","p":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"e":[{"e":775177,"m":{"r":65537,"p":[{"n":"value","p":775177}],"n":"{578569}.add_CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$add_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2},"r":{"r":65537,"p":[{"n":"value","p":775177}],"n":"{578569}.remove_CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$remove_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2},"n":"System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged","o":"$so$System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2},{"e":775177,"m":{"r":65537,"p":[{"n":"value","p":775177}],"n":"add_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":132},"r":{"r":65537,"p":[{"n":"value","p":775177}],"n":"remove_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":132},"n":"CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":132},{"e":1299465,"m":{"r":65537,"p":[{"n":"value","p":1299465}],"n":"{1102857}.add_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$add_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2},"r":{"r":65537,"p":[{"n":"value","p":1299465}],"n":"{1102857}.remove_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$remove_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2},"n":"System.ComponentModel.INotifyPropertyChanged.PropertyChanged","o":"$so$System$ComponentModel$INotifyPropertyChanged$PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2},{"e":1299465,"m":{"r":65537,"p":[{"n":"value","p":1299465}],"n":"add_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":132},"r":{"r":65537,"p":[{"n":"value","p":1299465}],"n":"remove_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":132},"n":"PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":132}],"i":[$.$spc.System.Collections.Generic.IList$$(T).$h,$.$spc.System.Collections.Generic.ICollection$$(T).$h,31916033,31326209,$.$spc.System.Collections.Generic.IReadOnlyList$$(T).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$spc.System.Collections.Generic.IEnumerable$$(T).$h,31588353,578569,1102857],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":118226945,"c":4413194241},{"t":37879809,"c":8627814401,"a":[{"v":$.$so.System.Collections.Generic.CollectionDebugView$$().$h,"t":142606337}]},{"t":37552129,"c":8627486721,"a":[{"v":"Count = {Count}","t":1310721}]},{"t":96272385,"c":4391239681,"a":[{"v":"WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IList$$(T), $.$spc.System.Collections.Generic.ICollection$$(T), $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.Generic.IReadOnlyList$$(T), $.$spc.System.Collections.Generic.IReadOnlyCollection$$(T), $.$spc.System.Collections.Generic.IEnumerable$$(T), $.$spc.System.Collections.IEnumerable, $.$so.System.Collections.Specialized.INotifyCollectionChanged, $.$so.System.ComponentModel.INotifyPropertyChanged ]; }
            static get $fullName() { return `System.Collections.ObjectModel.ReadOnlyObservableCollection<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$so.System.ComponentModel.PropertyChangedEventHandler", ($self) => class PropertyChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender, /**/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 1299465;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1233929}],"n":"Invoke","d":1299465,"h":8591234057,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":1233929},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":1299465,"h":12886201353,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":1299465,"h":17181168649,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1299465,"h":4296266761,"f":1}],"i":[57147393,113377281],"h":1299465}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.ComponentModel.PropertyChangedEventHandler`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.PropertyChangingEventHandler", ($self) => class PropertyChangingEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender, /**/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 1430537;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1365001}],"n":"Invoke","d":1430537,"h":8591365129,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":1365001},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":1430537,"h":12886332425,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":1430537,"h":17181299721,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1430537,"h":4296397833,"f":1}],"i":[57147393,113377281],"h":1430537}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.ComponentModel.PropertyChangingEventHandler`; }
        });
        
        $asm.$cls("$so.System.Collections.Specialized.NotifyCollectionChangedEventHandler", ($self) => class NotifyCollectionChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender, /**/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 775177;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":709641}],"n":"Invoke","d":775177,"h":8590709769,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":709641},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":775177,"h":12885677065,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":775177,"h":17180644361,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":775177,"h":4295742473,"f":1}],"i":[57147393,113377281],"h":775177}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Collections.Specialized.NotifyCollectionChangedEventHandler`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime"))