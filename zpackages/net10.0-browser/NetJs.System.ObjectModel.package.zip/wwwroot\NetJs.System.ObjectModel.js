
(function ($global, $, $spc, $sc, $sm, $spu, $sr, $st) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.ObjectModel", 
    {"h":63363,"f":"System.ObjectModel","v":"1.0.35.0","a":[{"t":96337921,"c":4391305217,"a":[{"v":$.$spc.System.Collections.ObjectModel.ReadOnlyDictionary$$$().$h,"t":142606337}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.ObjectModel","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.ObjectModel","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$so.System.Collections.Specialized.INotifyCollectionChanged", ($self) => class INotifyCollectionChanged
        {
            static $h = 587651;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"e":[{"e":784259,"m":{"r":65537,"p":[{"n":"value","p":784259}],"n":"add_CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$add_CollectionChanged","d":587651,"h":4295554947,"f":257},"r":{"r":65537,"p":[{"n":"value","p":784259}],"n":"remove_CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$remove_CollectionChanged","d":587651,"h":8590522243,"f":257},"n":"CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged","d":587651,"h":12885489539,"f":257}],"h":587651}; }
            static get $fullName() { return `System.Collections.Specialized.INotifyCollectionChanged`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.INotifyDataErrorInfo", ($self) => class INotifyDataErrorInfo
        {
            static $h = 1046403;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":8590980995,"f":257},"n":"HasErrors","o":"System$ComponentModel$INotifyDataErrorInfo$HasErrors","d":1046403,"h":4296013699,"f":257}],"m":[{"r":31653889,"p":[{"n":"propertyName","p":1310721}],"n":"GetErrors","o":"System$ComponentModel$INotifyDataErrorInfo$GetErrors","d":1046403,"h":12885948291,"f":257}],"e":[{"e":$.$spc.System.EventHandler$$($.$so.System.ComponentModel.DataErrorsChangedEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$so.System.ComponentModel.DataErrorsChangedEventArgs).$h}],"n":"add_ErrorsChanged","o":"System$ComponentModel$INotifyDataErrorInfo$add_ErrorsChanged","d":1046403,"h":17180915587,"f":257},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$so.System.ComponentModel.DataErrorsChangedEventArgs).$h}],"n":"remove_ErrorsChanged","o":"System$ComponentModel$INotifyDataErrorInfo$remove_ErrorsChanged","d":1046403,"h":21475882883,"f":257},"n":"ErrorsChanged","o":"System$ComponentModel$INotifyDataErrorInfo$ErrorsChanged","d":1046403,"h":25770850179,"f":257}],"h":1046403}; }
            static get $fullName() { return `System.ComponentModel.INotifyDataErrorInfo`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.INotifyPropertyChanged", ($self) => class INotifyPropertyChanged
        {
            static $h = 1111939;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"e":[{"e":1308547,"m":{"r":65537,"p":[{"n":"value","p":1308547}],"n":"add_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$add_PropertyChanged","d":1111939,"h":4296079235,"f":257},"r":{"r":65537,"p":[{"n":"value","p":1308547}],"n":"remove_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$remove_PropertyChanged","d":1111939,"h":8591046531,"f":257},"n":"PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$PropertyChanged","d":1111939,"h":12886013827,"f":257}],"h":1111939}; }
            static get $fullName() { return `System.ComponentModel.INotifyPropertyChanged`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.INotifyPropertyChanging", ($self) => class INotifyPropertyChanging
        {
            static $h = 1177475;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"e":[{"e":1439619,"m":{"r":65537,"p":[{"n":"value","p":1439619}],"n":"add_PropertyChanging","o":"System$ComponentModel$INotifyPropertyChanging$add_PropertyChanging","d":1177475,"h":4296144771,"f":257},"r":{"r":65537,"p":[{"n":"value","p":1439619}],"n":"remove_PropertyChanging","o":"System$ComponentModel$INotifyPropertyChanging$remove_PropertyChanging","d":1177475,"h":8591112067,"f":257},"n":"PropertyChanging","o":"System$ComponentModel$INotifyPropertyChanging$PropertyChanging","d":1177475,"h":12886079363,"f":257}],"h":1177475}; }
            static get $fullName() { return `System.ComponentModel.INotifyPropertyChanging`; }
        });
        
        $asm.$cls("$so.System.Windows.Input.ICommand", ($self) => class ICommand
        {
            static $h = 1767299;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262145,"p":[{"n":"parameter","p":131073}],"n":"CanExecute","o":"System$Windows$Input$ICommand$CanExecute","d":1767299,"h":17181636483,"f":257},{"r":65537,"p":[{"n":"parameter","p":131073}],"n":"Execute","o":"System$Windows$Input$ICommand$Execute","d":1767299,"h":21476603779,"f":257}],"e":[{"e":47054849,"m":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"add_CanExecuteChanged","o":"System$Windows$Input$ICommand$add_CanExecuteChanged","d":1767299,"h":4296734595,"f":257},"r":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"remove_CanExecuteChanged","o":"System$Windows$Input$ICommand$remove_CanExecuteChanged","d":1767299,"h":8591701891,"f":257},"n":"CanExecuteChanged","o":"System$Windows$Input$ICommand$CanExecuteChanged","d":1767299,"h":12886669187,"f":257}],"h":1767299,"a":[{"t":96272385,"c":4391239681,"a":[{"v":"PresentationCore, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]},{"t":1505155,"c":17181374339,"a":[{"v":"System.Windows.Input.CommandConverter, PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, Custom=null","t":1310721}]},{"t":1832835,"c":17181702019,"a":[{"v":"System.Windows.Input.CommandValueSerializer, PresentationFramework, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, Custom=null","t":1310721}]}]}; }
            static get $fullName() { return `System.Windows.Input.ICommand`; }
        });
        
        $asm.$cls("$so.System.Reflection.ICustomTypeProvider", ($self) => class ICustomTypeProvider
        {
            static $h = 1636227;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":142606337,"n":"GetCustomType","o":"System$Reflection$ICustomTypeProvider$GetCustomType","d":1636227,"h":4296603523,"f":257}],"h":1636227}; }
            static get $fullName() { return `System.Reflection.ICustomTypeProvider`; }
        });
        
        $asm.$cls("$so.System.Collections.CollectionHelpers", ($self) => class CollectionHelpers
        {
            static /*void */ ValidateCopyToArguments(/*int*/ sourceCount, /*Array*/ array, /*int*/ index)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(array, "array");
                if ($.$spc.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Arg_NonZeroLowerBound, "array");
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, index, array.length, "index");
                if (((array.length - index) | 0) < sourceCount)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$so.System.SR.Arg_ArrayPlusOffTooSmall);
                }
            }
            static $h = 128899;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"sourceCount","p":655361},{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"ValidateCopyToArguments","d":128899,"h":4295096195,"f":40}],"h":128899}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Collections.CollectionHelpers`; }
        });
        
        $asm.$cls("$so.System.Collections.Generic.CollectionDebugView<>", (T) => $asm.$gt("$so.System.Collections.Generic.CollectionDebugView<>", [T], ($self) => class CollectionDebugView$$ extends $.$spc.System.Object
        {
            /*ICollection<T>*/ _collection = null;
            $ctor$1(/*ICollection<T>*/ collection)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                    this._collection = collection;
                }
                return this;
            }
            /*T[] */ get Items()
            {
                /*T[]*/ let items = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this._collection.System$Collections$Generic$ICollection$$$Count], null);
                this._collection.System$Collections$Generic$ICollection$$$CopyTo(items, 0, [T]);
                return items;
            }
            static $h = 194435;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},"n":"Items","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1,"a":[{"t":37421057,"c":4332388353,"a":[{"v":3,"t":37486593}]}]}],"l":[{"t":$.$spc.System.Collections.Generic.ICollection$$(T).$h,"n":"_collection","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2}],"c":[{"p":[{"n":"collection","p":$.$spc.System.Collections.Generic.ICollection$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Collections.Generic.CollectionDebugView<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$so.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$so.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.ObjectModel", $.$so.System.SR.$type.Assembly);
                    $.$so.System.SR.s_resourceManager = temp;
                }
                return $.$so.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$so.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$so.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentOutOfRange_InvalidThreshold()
            {
                return "The specified threshold for creating dictionary is out of range.";
            }
            static /*string */ get Argument_ItemNotExist()
            {
                return "The specified item does not exist in this KeyedCollection.";
            }
            static /*string */ get Argument_AddingDuplicate()
            {
                return "An item with the same key has already been added. Key: {0}";
            }
            static /*string */ FormatArgument_AddingDuplicate(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("An item with the same key has already been added. Key: {0}", arg1);
            }
            static /*string */ get Arg_NonZeroLowerBound()
            {
                return "The lower bound of target array must be zero.";
            }
            static /*string */ get Arg_ArrayPlusOffTooSmall()
            {
                return "Destination array is not long enough to copy all the items in the collection. Check array index and length.";
            }
            static /*string */ get NotSupported_ReadOnlyCollection()
            {
                return "Collection is read-only.";
            }
            static /*string */ get ObservableCollectionReentrancyNotAllowed()
            {
                return "Cannot change ObservableCollection during a CollectionChanged event.";
            }
            static /*string */ get WrongActionForCtor()
            {
                return "Constructor supports only the '{0}' action.";
            }
            static /*string */ FormatWrongActionForCtor(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Constructor supports only the '{0}' action.", arg1);
            }
            static /*string */ get MustBeResetAddOrRemoveActionForCtor()
            {
                return "Constructor only supports either a Reset, Add, or Remove action.";
            }
            static /*string */ get ResetActionRequiresNullItem()
            {
                return "Reset action must be initialized with no changed items.";
            }
            static /*string */ get ResetActionRequiresIndexMinus1()
            {
                return "Reset action must be initialized with index -1.";
            }
            static /*string */ get Arg_RankMultiDimNotSupported()
            {
                return "Only single dimensional arrays are supported for the requested action.";
            }
            static /*string */ get Argument_IncompatibleArrayType()
            {
                return "Target array type is not compatible with the type of items in the collection.";
            }
            static /*string */ get Arg_KeyNotFoundWithKey()
            {
                return "The given key '{0}' was not present in the dictionary.";
            }
            static /*string */ FormatArg_KeyNotFoundWithKey(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The given key '{0}' was not present in the dictionary.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$so.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$so.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$so.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$so.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$so.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$so.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$so.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1701763;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1701763}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$so.System.Collections.ObjectModel.EventArgsCache", ($self) => class EventArgsCache
        {
            /*PropertyChangedEventArgs*/ static CountPropertyChanged = null;
            /*PropertyChangedEventArgs*/ static IndexerPropertyChanged = null;
            /*NotifyCollectionChangedEventArgs*/ static ResetCollectionChanged = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.CountPropertyChanged = new $.$so.System.ComponentModel.PropertyChangedEventArgs().$ctor$2("Count");
                }
                {
                    this.IndexerPropertyChanged = new $.$so.System.ComponentModel.PropertyChangedEventArgs().$ctor$2("Item[]");
                }
                {
                    this.ResetCollectionChanged = new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs().$ctor$2(4/*NotifyCollectionChangedAction.Reset*/);
                }
            }
            static $h = 259971;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1243011,"n":"CountPropertyChanged","d":259971,"h":4295227267,"f":40},{"t":1243011,"n":"IndexerPropertyChanged","d":259971,"h":8590194563,"f":40},{"t":718723,"n":"ResetCollectionChanged","d":259971,"h":12885161859,"f":40}],"h":259971}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Collections.ObjectModel.EventArgsCache`; }
        });
        
        $asm.$cls("$so.System.Collections.Specialized.ReadOnlyList", ($self) => class ReadOnlyList extends $.$spc.System.Object
        {
            /*IList*/ _list = null;
            $ctor$1(/*IList*/ list)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(list !== null, "list != null");
                    this._list = list;
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._list.System$Collections$ICollection$Count;
            }
            /*bool */ get IsReadOnly()
            {
                return true;
            }
            /*bool */ get IsFixedSize()
            {
                return true;
            }
            /*bool */ get IsSynchronized()
            {
                return this._list.System$Collections$ICollection$IsSynchronized;
            }
            /*object?*/ get_Item(/*int*/ index)
            {
                return this._list.System$Collections$IList$get_Item(index);
            }
            /*void*/ set_Item(/*int*/ index, /*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*object */ get SyncRoot()
            {
                return this._list.System$Collections$ICollection$SyncRoot;
            }
            /*int */ Add(/*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Clear()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*bool */ Contains(/*object?*/ value)
            {
                return this._list.System$Collections$IList$Contains(value);
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                return this._list.System$Collections$ICollection$CopyTo(array, index);
            }
            /*IEnumerator */ GetEnumerator()
            {
                return this._list.System$Collections$IEnumerable$GetEnumerator();
            }
            /*int */ IndexOf(/*object?*/ value)
            {
                return this._list.System$Collections$IList$IndexOf(value);
            }
            /*void */ Insert(/*int*/ index, /*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Remove(/*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            //Generated interface implemetation for System.Collections.IList.this[int].get
            System$Collections$IList$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.this[int].set
            System$Collections$IList$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Add(object?)
            System$Collections$IList$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Contains(object?)
            System$Collections$IList$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Clear()
            System$Collections$IList$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.IsReadOnly.get
            get System$Collections$IList$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.IList.IsFixedSize.get
            get System$Collections$IList$IsFixedSize()
            {
                return this.IsFixedSize;
            }
            //Generated interface implemetation for System.Collections.IList.IndexOf(object?)
            System$Collections$IList$IndexOf()
            {
                return this.IndexOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Insert(int, object?)
            System$Collections$IList$Insert()
            {
                return this.Insert(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Remove(object?)
            System$Collections$IList$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            System$Collections$IList$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 849795;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180718979,"f":1},"n":"Count","d":849795,"h":12885751683,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770653571,"f":1},"n":"IsReadOnly","d":849795,"h":21475686275,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360588163,"f":1},"n":"IsFixedSize","d":849795,"h":30065620867,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950522755,"f":1},"n":"IsSynchronized","d":849795,"h":38655555459,"f":1},{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":51540457347,"f":1},"s":{"r":0,"d":0,"h":55835424643,"f":1},"n":"Item","o":"@$2","d":849795,"h":47245490051,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":64425359235,"f":1},"n":"SyncRoot","d":849795,"h":60130391939,"f":1}],"m":[{"r":655361,"p":[{"n":"value","p":131073}],"n":"Add","d":849795,"h":68720326531,"f":1},{"r":65537,"n":"Clear","d":849795,"h":73015293827,"f":1},{"r":262145,"p":[{"n":"value","p":131073}],"n":"Contains","d":849795,"h":77310261123,"f":1},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":849795,"h":81605228419,"f":1},{"r":31784961,"n":"GetEnumerator","d":849795,"h":85900195715,"f":1},{"r":655361,"p":[{"n":"value","p":131073}],"n":"IndexOf","d":849795,"h":90195163011,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"Insert","d":849795,"h":94490130307,"f":1},{"r":65537,"p":[{"n":"value","p":131073}],"n":"Remove","d":849795,"h":98785097603,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":849795,"h":103080064899,"f":1}],"l":[{"t":31981569,"n":"_list","d":849795,"h":4295817091,"f":2}],"c":[{"p":[{"n":"list","p":31981569}],"n":".ctor","o":"$ctor$1","d":849795,"h":8590784387,"f":8}],"i":[31981569,31391745,31653889],"h":849795}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.ReadOnlyList`; }
        });
        
        $asm.$cls("$so.System.Collections.Specialized.SingleItemReadOnlyList", ($self) => class SingleItemReadOnlyList extends $.$spc.System.Object
        {
            /*object?*/ _item = null;
            $ctor$1(/*object?*/ item)
            {
                super.$ctor();
                this._item = item;
                return this;
            }
            /*object?*/ get_Item(/*int*/ index)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNotEqual($.$spc.System.Int32, index, 0, "index");
                return this._item;
            }
            /*void*/ set_Item(/*int*/ index, /*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*bool */ get IsFixedSize()
            {
                return true;
            }
            /*bool */ get IsReadOnly()
            {
                return true;
            }
            /*int */ get Count()
            {
                return 1;
            }
            /*bool */ get IsSynchronized()
            {
                return false;
            }
            /*object */ get SyncRoot()
            {
                return this;
            }
            /*IEnumerator */ GetEnumerator()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    yield this._item;
                }.bind(this)).GetEnumerator();
            }
            /*bool */ Contains(/*object?*/ value)
            {
                return this._item === null ? value === null : $.$spc.System.Object.Equals.call(this._item, value);
            }
            /*int */ IndexOf(/*object?*/ value)
            {
                return this.Contains(value) ? 0 : -1;
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                $.$so.System.Collections.CollectionHelpers.ValidateCopyToArguments(1, array, index);
                array.SetValue(this._item, index);
            }
            /*int */ Add(/*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Clear()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Insert(/*int*/ index, /*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ Remove(/*object?*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$so.System.SR.NotSupported_ReadOnlyCollection);
            }
            //Generated interface implemetation for System.Collections.IList.this[int].get
            System$Collections$IList$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.this[int].set
            System$Collections$IList$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Add(object?)
            System$Collections$IList$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Contains(object?)
            System$Collections$IList$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Clear()
            System$Collections$IList$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.IsReadOnly.get
            get System$Collections$IList$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.IList.IsFixedSize.get
            get System$Collections$IList$IsFixedSize()
            {
                return this.IsFixedSize;
            }
            //Generated interface implemetation for System.Collections.IList.IndexOf(object?)
            System$Collections$IList$IndexOf()
            {
                return this.IndexOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Insert(int, object?)
            System$Collections$IList$Insert()
            {
                return this.Insert(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.Remove(object?)
            System$Collections$IList$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            System$Collections$IList$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 915331;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180784515,"f":1},"s":{"r":0,"d":0,"h":21475751811,"f":1},"n":"Item","o":"@$2","d":915331,"h":12885817219,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30065686403,"f":1},"n":"IsFixedSize","d":915331,"h":25770719107,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655620995,"f":1},"n":"IsReadOnly","d":915331,"h":34360653699,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47245555587,"f":1},"n":"Count","d":915331,"h":42950588291,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55835490179,"f":1},"n":"IsSynchronized","d":915331,"h":51540522883,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":64425424771,"f":1},"n":"SyncRoot","d":915331,"h":60130457475,"f":1}],"m":[{"r":31784961,"n":"GetEnumerator","d":915331,"h":68720392067,"f":1},{"r":262145,"p":[{"n":"value","p":131073}],"n":"Contains","d":915331,"h":73015359363,"f":1},{"r":655361,"p":[{"n":"value","p":131073}],"n":"IndexOf","d":915331,"h":77310326659,"f":1},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":915331,"h":81605293955,"f":1},{"r":655361,"p":[{"n":"value","p":131073}],"n":"Add","d":915331,"h":85900261251,"f":1},{"r":65537,"n":"Clear","d":915331,"h":90195228547,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"Insert","d":915331,"h":94490195843,"f":1},{"r":65537,"p":[{"n":"value","p":131073}],"n":"Remove","d":915331,"h":98785163139,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":915331,"h":103080130435,"f":1}],"l":[{"t":131073,"n":"_item","d":915331,"h":4295882627,"f":2}],"c":[{"p":[{"n":"item","p":131073}],"n":".ctor","o":"$ctor$1","d":915331,"h":8590849923,"f":1}],"i":[31981569,31391745,31653889],"h":915331}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.SingleItemReadOnlyList`; }
        });
        
        $asm.$cls("$so.System.Windows.Markup.ValueSerializerAttribute", ($self) => class ValueSerializerAttribute extends $.$spc.System.Attribute
        {
            /*Type?*/ _valueSerializerType = null;
            /*string?*/ _valueSerializerTypeName = null;
            $ctor$2(/*Type*/ valueSerializerType)
            {
                super.$ctor$1();
                {
                    this._valueSerializerType = valueSerializerType;
                }
                return this;
            }
            $ctor$3(/*string*/ valueSerializerTypeName)
            {
                super.$ctor$1();
                {
                    this._valueSerializerTypeName = valueSerializerTypeName;
                }
                return this;
            }
            /*Type */ get ValueSerializerType()
            {
                if ($.$spc.System.Type.op_Equality$1(this._valueSerializerType, null) && $.$spc.System.String.op_Inequality(this._valueSerializerTypeName, null))
                {
                    this._valueSerializerType = $.$spc.System.Type.GetType$3(this._valueSerializerTypeName);
                }
                return this._valueSerializerType;
            }
            /*string */ get ValueSerializerTypeName()
            {
                if ($.$spc.System.Type.op_Inequality$1(this._valueSerializerType, null))
                {
                    return this._valueSerializerType.AssemblyQualifiedName;
                }
                else 
                {
                    return this._valueSerializerTypeName;
                }
            }
            static $h = 1832835;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":25771636611,"f":1},"n":"ValueSerializerType","d":1832835,"h":21476669315,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34361571203,"f":1},"n":"ValueSerializerTypeName","d":1832835,"h":30066603907,"f":1}],"l":[{"t":142606337,"n":"_valueSerializerType","d":1832835,"h":4296800131,"f":2},{"t":1310721,"n":"_valueSerializerTypeName","d":1832835,"h":8591767427,"f":2}],"c":[{"p":[{"n":"valueSerializerType","p":142606337}],"n":".ctor","o":"$ctor$2","d":1832835,"h":12886734723,"f":1},{"p":[{"n":"valueSerializerTypeName","p":1310721}],"n":".ctor","o":"$ctor$3","d":1832835,"h":17181702019,"f":1}],"h":1832835,"a":[{"t":14680065,"c":21489516545,"a":[{"v":1244,"t":14614529}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":true,"t":262145}]},{"t":96272385,"c":4391239681,"a":[{"v":"WindowsBase, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Windows.Markup.ValueSerializerAttribute`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.TypeDescriptionProviderAttribute", ($self) => class TypeDescriptionProviderAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ typeName)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(typeName, "typeName");
                    this.TypeName = typeName;
                }
                return this;
            }
            $ctor$3(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                    this.TypeName = type.AssemblyQualifiedName;
                }
                return this;
            }
            /*string*/ TypeName = null;
            static $h = 1570691;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21476407171,"f":1},"n":"TypeName","d":1570691,"h":17181439875,"f":1}],"c":[{"p":[{"n":"typeName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1570691,"h":4296537987,"f":1},{"p":[{"n":"type","p":142606337}],"n":".ctor","o":"$ctor$3","d":1570691,"h":8591505283,"f":1}],"h":1570691,"a":[{"t":14680065,"c":21489516545,"a":[{"v":4,"t":14614529}],"n":[{"n":"Inherited","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.TypeDescriptionProviderAttribute`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.TypeConverterAttribute", ($self) => class TypeConverterAttribute extends $.$spc.System.Attribute
        {
            /*TypeConverterAttribute*/ static Default = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this.ConverterTypeName = $.$spc.System.String.Empty;
                }
                return this;
            }
            $ctor$3(/*Type*/ type)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                    this.ConverterTypeName = type.AssemblyQualifiedName;
                }
                return this;
            }
            $ctor$4(/*string*/ typeName)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(typeName, "typeName");
                    this.ConverterTypeName = typeName;
                }
                return this;
            }
            /*string*/ ConverterTypeName = null;
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$so.System.ComponentModel.TypeConverterAttribute, { set $v(v){ other = v; } }) && $.$spc.System.String.op_Equality(other.ConverterTypeName, this.ConverterTypeName);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$so.System.ComponentModel.TypeConverterAttribute.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.String.GetHashCode.call(this.ConverterTypeName);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$so.System.ComponentModel.TypeConverterAttribute.GetHashCode.apply(this, arguments); }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$so.System.ComponentModel.TypeConverterAttribute().$ctor$2();
                }
            }
            static $h = 1505155;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30066276227,"f":1},"n":"ConverterTypeName","d":1505155,"h":25771308931,"f":1}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":1505155,"h":34361243523,"f":32769},{"r":655361,"n":"GetHashCode","d":1505155,"h":38656210819,"f":32769}],"l":[{"t":1505155,"n":"Default","d":1505155,"h":4296472451,"f":33}],"c":[{"n":".ctor","o":"$ctor$2","d":1505155,"h":8591439747,"f":1},{"p":[{"n":"type","p":142606337}],"n":".ctor","o":"$ctor$3","d":1505155,"h":12886407043,"f":1},{"p":[{"n":"typeName","p":1310721}],"n":".ctor","o":"$ctor$4","d":1505155,"h":17181374339,"f":1}],"h":1505155,"a":[{"t":14680065,"c":21489516545,"a":[{"v":32767,"t":14614529}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.TypeConverterAttribute`; }
        });
        
        $asm.$cls("$so.System.Collections.ObjectModel.KeyedCollection<,>", (TKey, TItem) => $asm.$gt("$so.System.Collections.ObjectModel.KeyedCollection<,>", [TKey, TItem], ($self) => class KeyedCollection$$$ extends $.$spc.System.Collections.ObjectModel.Collection$$(TItem)
        {
            /*int*/ static DefaultThreshold = 0;
            /*IEqualityComparer<TKey>*/ comparer = null;
            /*Dictionary<TKey, TItem>?*/ dict = null;
            /*int*/ keyCount = 0;
            /*int*/ threshold = 0;
            $ctor$3()
            {
                this.$ctor$5(null, 0/*DefaultThreshold*/);
                {
                }
                return this;
            }
            $ctor$4(/*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$5(comparer, 0/*DefaultThreshold*/);
                {
                }
                return this;
            }
            $ctor$5(/*IEqualityComparer<TKey>?*/ comparer, /*int*/ dictionaryCreationThreshold)
            {
                super.$ctor$2(new ($.$spc.System.Collections.Generic.List$$(TItem))().$ctor$1());
                {
                    if (dictionaryCreationThreshold < -1)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("dictionaryCreationThreshold", $.$so.System.SR.ArgumentOutOfRange_InvalidThreshold);
                    }
                    this.comparer = comparer ?? $.$spc.System.Collections.Generic.EqualityComparer$$(TKey).Default;
                    this.threshold = dictionaryCreationThreshold === -1 ? 2147483647/*int.MaxValue*/ : dictionaryCreationThreshold;
                }
                return this;
            }
            /*List<TItem> */ get Items$1()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$is(super.Items, $.$spc.System.Collections.Generic.List$$(TItem)), "base.Items is List<TItem>");
                return $.$cast(super.Items, $.$spc.System.Collections.Generic.List$$(TItem));
            }
            /*IEqualityComparer<TKey> */ get Comparer()
            {
                return this.comparer;
            }
            /*TItem*/ get_Item$1(/*TKey*/ key)
            {
                /*TItem*/ let item;
                if (this.TryGetValue(key, $.$ref(() => item, ($v) => item = $v, TItem)))
                {
                    return item;
                }
                throw new $.$spc.System.Collections.Generic.KeyNotFoundException().$ctor$10($.$so.System.SR.Format($.$so.System.SR.Arg_KeyNotFoundWithKey, $.$spc.System.Object.ToString.call(key)));
            }
            /*bool */ Contains$1(/*TKey*/ key)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull($.$box(key, TKey), "key");
                if (this.dict !== null)
                {
                    return this.dict.ContainsKey(key);
                }
                var $en2 = this.Items$1.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        if (this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(this.GetKeyForItem(item), key, [TKey]))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*bool */ TryGetValue(/*TKey*/ key, /*out TItem*/ item)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull($.$box(key, TKey), "key");
                if (this.dict !== null)
                {
                    return this.dict.TryGetValue(key, item);
                }
                var $en2 = this.Items$1.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var itemInItems = $en2.Current;
                    {
                        /*TKey*/ let keyInItems = this.GetKeyForItem(itemInItems);
                        if ($.$box(keyInItems, TKey) !== null && this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(key, keyInItems, [TKey]))
                        {
                            item.$v = itemInItems;
                            return true;
                        }
                    }
                }
                item.$v = $.$default(TItem);
                return false;
            }
            /*bool */ ContainsItem(/*TItem*/ item)
            {
                /*TKey*/ let key;
                if ((this.dict === null) || (($.$box(key = this.GetKeyForItem(item), TKey)) === null))
                {
                    return this.Items$1.Contains(item);
                }
                /*TItem*/ let itemInDict;
                if (this.dict.TryGetValue(key, $.$ref(() => itemInDict, ($v) => itemInDict = $v, TItem)))
                {
                    return $.$spc.System.Collections.Generic.EqualityComparer$$(TItem).Default.Equals$2(itemInDict, item);
                }
                return false;
            }
            /*bool */ Remove$1(/*TKey*/ key)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull($.$box(key, TKey), "key");
                if (this.dict !== null)
                {
                    /*TItem*/ let item;
                    return this.dict.TryGetValue(key, $.$ref(() => item, ($v) => item = $v, TItem)) && this.Remove(item);
                }
                for(/*int*/ let i = 0; i < this.Items$1.Count; i++)
                {
                    if (this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(this.GetKeyForItem(this.Items$1.get_Item(i)), key, [TKey]))
                    {
                        this.RemoveItem(i);
                        return true;
                    }
                }
                return false;
            }
            /*IDictionary<TKey, TItem>? */ get Dictionary()
            {
                return this.dict;
            }
            /*void */ ChangeItemKey(/*TItem*/ item, /*TKey*/ newKey)
            {
                if (!this.ContainsItem(item))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Argument_ItemNotExist, "item");
                }
                /*TKey*/ let oldKey = this.GetKeyForItem(item);
                if (!this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(oldKey, newKey, [TKey]))
                {
                    if ($.$box(newKey, TKey) !== null)
                    {
                        this.AddKey(newKey, item);
                    }
                    if ($.$box(oldKey, TKey) !== null)
                    {
                        this.RemoveKey(oldKey);
                    }
                }
            }
            /*void */ ClearItems()
            {
                super.ClearItems();
                this.dict?.Clear();
                this.keyCount = 0;
            }
            /*void */ InsertItem(/*int*/ index, /*TItem*/ item)
            {
                /*TKey*/ let key = this.GetKeyForItem(item);
                if ($.$box(key, TKey) !== null)
                {
                    this.AddKey(key, item);
                }
                super.InsertItem(index, item);
            }
            /*void */ RemoveItem(/*int*/ index)
            {
                /*TKey*/ let key = this.GetKeyForItem(this.Items$1.get_Item(index));
                if ($.$box(key, TKey) !== null)
                {
                    this.RemoveKey(key);
                }
                super.RemoveItem(index);
            }
            /*void */ SetItem(/*int*/ index, /*TItem*/ item)
            {
                /*TKey*/ let newKey = this.GetKeyForItem(item);
                /*TKey*/ let oldKey = this.GetKeyForItem(this.Items$1.get_Item(index));
                if (this.comparer.System$Collections$Generic$IEqualityComparer$$$Equals(oldKey, newKey, [TKey]))
                {
                    if ($.$box(newKey, TKey) !== null && this.dict !== null)
                    {
                        this.dict.set_Item(newKey, item);
                    }
                }
                else 
                {
                    if ($.$box(newKey, TKey) !== null)
                    {
                        this.AddKey(newKey, item);
                    }
                    if ($.$box(oldKey, TKey) !== null)
                    {
                        this.RemoveKey(oldKey);
                    }
                }
                super.SetItem(index, item);
            }
            /*void */ AddKey(/*TKey*/ key, /*TItem*/ item)
            {
                if (this.dict !== null)
                {
                    this.dict.Add(key, item);
                }
                else if (this.keyCount === this.threshold)
                {
                    this.CreateDictionary();
                    this.dict.Add(key, item);
                }
                else 
                {
                    if (this.Contains$1(key))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Format($.$so.System.SR.Argument_AddingDuplicate, $.$box(key, TKey)), "key");
                    }
                    this.keyCount++;
                }
            }
            /*void */ CreateDictionary()
            {
                this.dict = new ($.$spc.System.Collections.Generic.Dictionary$$$(TKey, TItem))().$ctor$3(this.comparer);
                var $en2 = this.Items$1.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        /*TKey*/ let key = this.GetKeyForItem(item);
                        if ($.$box(key, TKey) !== null)
                        {
                            this.dict.Add(key, item);
                        }
                    }
                }
            }
            /*void */ RemoveKey(/*TKey*/ key)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$box(key, TKey) !== null, "key shouldn't be null!");
                if (this.dict !== null)
                {
                    this.dict.Remove(key);
                }
                else 
                {
                    this.keyCount--;
                }
            }
            static $h = 325507;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$spc.System.Collections.Generic.List$$(TItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2},"n":"Items","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2},{"p":$.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":1},"n":"Comparer","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1},{"p":TItem?.$h??1572864,"i":[{"n":"key","p":TKey?.$h??1507328}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":1},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":1},{"p":$.$spc.System.Collections.Generic.IDictionary$$$(TKey, TItem).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1400000000n),"f":4},"n":"Dictionary","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":4}],"m":[{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328}],"n":"Contains","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":1},{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"item","p":TItem?.$h??1572864,"f":2}],"n":"TryGetValue","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":1},{"r":262145,"p":[{"n":"item","p":TItem?.$h??1572864}],"n":"ContainsItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":2},{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328}],"n":"Remove","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":1},{"r":65537,"p":[{"n":"item","p":TItem?.$h??1572864},{"n":"newKey","p":TKey?.$h??1507328}],"n":"ChangeItemKey","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":4},{"r":65537,"n":"ClearItems","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":32772},{"r":TKey?.$h??1507328,"p":[{"n":"item","p":TItem?.$h??1572864}],"n":"GetKeyForItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":260},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":TItem?.$h??1572864}],"n":"InsertItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":32772},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":32772},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":TItem?.$h??1572864}],"n":"SetItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":32772},{"r":65537,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"item","p":TItem?.$h??1572864}],"n":"AddKey","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":2},{"r":65537,"n":"CreateDictionary","d":this.$h,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":2},{"r":65537,"p":[{"n":"key","p":TKey?.$h??1507328}],"n":"RemoveKey","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":2}],"l":[{"t":655361,"n":"DefaultThreshold","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":34},{"t":$.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h,"n":"comparer","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$(TKey, TItem).$h,"n":"dict","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":655361,"n":"keyCount","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":655361,"n":"threshold","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":4},{"p":[{"n":"comparer","p":$.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":4},{"p":[{"n":"comparer","p":$.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h},{"n":"dictionaryCreationThreshold","p":655361}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":4}],"i":[$.$spc.System.Collections.Generic.IList$$(TItem).$h,$.$spc.System.Collections.Generic.ICollection$$(TItem).$h,31981569,31391745,$.$spc.System.Collections.Generic.IReadOnlyList$$(TItem).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$(TItem).$h,$.$spc.System.Collections.Generic.IEnumerable$$(TItem).$h,31653889],"g":[TKey?.$h??1507328,TItem?.$h??1572864],"s":[{"n":"TKey","f":64},null],"r":2,"h":this.$h,"a":[{"t":118226945,"c":4413194241},{"t":37945345,"c":8627879937,"a":[{"v":null,"t":142606337}]},{"t":37617665,"c":8627552257,"a":[{"v":"Count = {Count}","t":1310721}]},{"t":96272385,"c":4391239681,"a":[{"v":"mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Collections.ObjectModel.Collection$$(TItem); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IList$$(TItem), $.$spc.System.Collections.Generic.ICollection$$(TItem), $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.Generic.IReadOnlyList$$(TItem), $.$spc.System.Collections.Generic.IReadOnlyCollection$$(TItem), $.$spc.System.Collections.Generic.IEnumerable$$(TItem), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.ObjectModel.KeyedCollection<${TKey?.$fullName},${TItem?.$fullName}>`; }
        }));
        
        $asm.$cls("$so.System.ComponentModel.PropertyChangedEventHandler", ($self) => class PropertyChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 1308547;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1243011}],"n":"Invoke","d":1308547,"h":8591243139,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":1243011},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":1308547,"h":12886210435,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1308547,"h":17181177731,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1308547,"h":4296275843,"f":1}],"i":[57212929,113377281],"h":1308547}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.ComponentModel.PropertyChangedEventHandler`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.PropertyChangingEventHandler", ($self) => class PropertyChangingEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 1439619;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1374083}],"n":"Invoke","d":1439619,"h":8591374211,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":1374083},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":1439619,"h":12886341507,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1439619,"h":17181308803,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1439619,"h":4296406915,"f":1}],"i":[57212929,113377281],"h":1439619}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.ComponentModel.PropertyChangingEventHandler`; }
        });
        
        $asm.$cls("$so.System.Collections.Specialized.NotifyCollectionChangedEventHandler", ($self) => class NotifyCollectionChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 784259;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":718723}],"n":"Invoke","d":784259,"h":8590718851,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":718723},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":784259,"h":12885686147,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":784259,"h":17180653443,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":784259,"h":4295751555,"f":1}],"i":[57212929,113377281],"h":784259}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Collections.Specialized.NotifyCollectionChangedEventHandler`; }
        });
        
        $asm.$str("$so.System.Collections.Specialized.NotifyCollectionChangedAction", ($self) => class NotifyCollectionChangedAction extends $.$spc.System.Enum
        {
            static Add = 0;
            static Remove = 1;
            static Replace = 2;
            static Move = 3;
            static Reset = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Remove": 1n,
                    "Replace": 2n,
                    "Move": 3n,
                    "Reset": 4n
                };
            }
            static $h = 653187;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":653187,"n":"Add","d":653187,"h":4295620483,"f":33},{"t":653187,"n":"Remove","d":653187,"h":8590587779,"f":33},{"t":653187,"n":"Replace","d":653187,"h":12885555075,"f":33},{"t":653187,"n":"Move","d":653187,"h":17180522371,"f":33},{"t":653187,"n":"Reset","d":653187,"h":21475489667,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":653187,"h":25770456963,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":653187}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Collections.Specialized.NotifyCollectionChangedAction`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.DataErrorsChangedEventArgs", ($self) => class DataErrorsChangedEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*string?*/ propertyName)
            {
                super.$ctor$1();
                {
                    this.PropertyName = propertyName;
                }
                return this;
            }
            /*string?*/ PropertyName = null;
            static $h = 980867;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180850051,"f":129},"n":"PropertyName","d":980867,"h":12885882755,"f":129}],"c":[{"p":[{"n":"propertyName","p":1310721}],"n":".ctor","o":"$ctor$2","d":980867,"h":4295948163,"f":1}],"h":980867}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.ComponentModel.DataErrorsChangedEventArgs`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.PropertyChangedEventArgs", ($self) => class PropertyChangedEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*string?*/ propertyName)
            {
                super.$ctor$1();
                {
                    this.PropertyName = propertyName;
                }
                return this;
            }
            /*string?*/ PropertyName = null;
            static $h = 1243011;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181112195,"f":129},"n":"PropertyName","d":1243011,"h":12886144899,"f":129}],"c":[{"p":[{"n":"propertyName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1243011,"h":4296210307,"f":1}],"h":1243011}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.ComponentModel.PropertyChangedEventArgs`; }
        });
        
        $asm.$cls("$so.System.ComponentModel.PropertyChangingEventArgs", ($self) => class PropertyChangingEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*string?*/ propertyName)
            {
                super.$ctor$1();
                {
                    this.PropertyName = propertyName;
                }
                return this;
            }
            /*string?*/ PropertyName = null;
            static $h = 1374083;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181243267,"f":129},"n":"PropertyName","d":1374083,"h":12886275971,"f":129}],"c":[{"p":[{"n":"propertyName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1374083,"h":4296341379,"f":1}],"h":1374083}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.ComponentModel.PropertyChangingEventArgs`; }
        });
        
        $asm.$cls("$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs", ($self) => class NotifyCollectionChangedEventArgs extends $.$spc.System.EventArgs
        {
            /*NotifyCollectionChangedAction*/ _action = 0;
            /*IList?*/ _newItems = null;
            /*IList?*/ _oldItems = null;
            /*int*/ _newStartingIndex = -1;
            /*int*/ _oldStartingIndex = -1;
            $ctor$2(/*NotifyCollectionChangedAction*/ action)
            {
                super.$ctor$1();
                {
                    if (action !== 4/*NotifyCollectionChangedAction.Reset*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Format($.$so.System.SR.WrongActionForCtor, $.$box(4/*NotifyCollectionChangedAction.Reset*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    this._action = action;
                }
                return this;
            }
            $ctor$3(/*NotifyCollectionChangedAction*/ action, /*object?*/ changedItem)
            {
                this.$ctor$4(action, changedItem, -1);
                {
                }
                return this;
            }
            $ctor$4(/*NotifyCollectionChangedAction*/ action, /*object?*/ changedItem, /*int*/ index)
            {
                super.$ctor$1();
                {
                    switch(action)
                    {
                        case 4/*NotifyCollectionChangedAction.Reset*/:
                        if (changedItem !== null)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.ResetActionRequiresNullItem, "action");
                        }
                        if (index !== -1)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.ResetActionRequiresIndexMinus1, "action");
                        }
                        break;
                        case 0/*NotifyCollectionChangedAction.Add*/:
                        this._newItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(changedItem);
                        this._newStartingIndex = index;
                        break;
                        case 1/*NotifyCollectionChangedAction.Remove*/:
                        this._oldItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(changedItem);
                        this._oldStartingIndex = index;
                        break;
                        default:
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.MustBeResetAddOrRemoveActionForCtor, "action");
                    }
                    this._action = action;
                }
                return this;
            }
            $ctor$5(/*NotifyCollectionChangedAction*/ action, /*IList?*/ changedItems)
            {
                this.$ctor$6(action, changedItems, -1);
                {
                }
                return this;
            }
            $ctor$6(/*NotifyCollectionChangedAction*/ action, /*IList?*/ changedItems, /*int*/ startingIndex)
            {
                super.$ctor$1();
                {
                    switch(action)
                    {
                        case 4/*NotifyCollectionChangedAction.Reset*/:
                        if (changedItems !== null)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.ResetActionRequiresNullItem, "action");
                        }
                        if (startingIndex !== -1)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.ResetActionRequiresIndexMinus1, "action");
                        }
                        break;
                        case 0/*NotifyCollectionChangedAction.Add*/:
                        case 1/*NotifyCollectionChangedAction.Remove*/:
                        $.$spc.System.ArgumentNullException.ThrowIfNull(changedItems, "changedItems");
                        $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, startingIndex, -1, "startingIndex");
                        if (action === 0/*NotifyCollectionChangedAction.Add*/)
                        {
                            this._newItems = new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(changedItems);
                            this._newStartingIndex = startingIndex;
                        }
                        else 
                        {
                            this._oldItems = new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(changedItems);
                            this._oldStartingIndex = startingIndex;
                        }
                        break;
                        default:
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.MustBeResetAddOrRemoveActionForCtor, "action");
                    }
                    this._action = action;
                }
                return this;
            }
            $ctor$7(/*NotifyCollectionChangedAction*/ action, /*object?*/ newItem, /*object?*/ oldItem)
            {
                this.$ctor$8(action, newItem, oldItem, -1);
                {
                }
                return this;
            }
            $ctor$8(/*NotifyCollectionChangedAction*/ action, /*object?*/ newItem, /*object?*/ oldItem, /*int*/ index)
            {
                super.$ctor$1();
                {
                    if (action !== 2/*NotifyCollectionChangedAction.Replace*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Format($.$so.System.SR.WrongActionForCtor, $.$box(2/*NotifyCollectionChangedAction.Replace*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    this._action = action;
                    this._newItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(newItem);
                    this._oldItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(oldItem);
                    this._newStartingIndex = this._oldStartingIndex = index;
                }
                return this;
            }
            $ctor$9(/*NotifyCollectionChangedAction*/ action, /*IList*/ newItems, /*IList*/ oldItems)
            {
                this.$ctor$10(action, newItems, oldItems, -1);
                {
                }
                return this;
            }
            $ctor$10(/*NotifyCollectionChangedAction*/ action, /*IList*/ newItems, /*IList*/ oldItems, /*int*/ startingIndex)
            {
                super.$ctor$1();
                {
                    if (action !== 2/*NotifyCollectionChangedAction.Replace*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Format($.$so.System.SR.WrongActionForCtor, $.$box(2/*NotifyCollectionChangedAction.Replace*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    $.$spc.System.ArgumentNullException.ThrowIfNull(newItems, "newItems");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(oldItems, "oldItems");
                    this._action = action;
                    this._newItems = new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(newItems);
                    this._oldItems = new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(oldItems);
                    this._newStartingIndex = this._oldStartingIndex = startingIndex;
                }
                return this;
            }
            $ctor$11(/*NotifyCollectionChangedAction*/ action, /*object?*/ changedItem, /*int*/ index, /*int*/ oldIndex)
            {
                super.$ctor$1();
                {
                    if (action !== 3/*NotifyCollectionChangedAction.Move*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Format($.$so.System.SR.WrongActionForCtor, $.$box(3/*NotifyCollectionChangedAction.Move*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                    this._action = action;
                    this._newItems = this._oldItems = new $.$so.System.Collections.Specialized.SingleItemReadOnlyList().$ctor$1(changedItem);
                    this._newStartingIndex = index;
                    this._oldStartingIndex = oldIndex;
                }
                return this;
            }
            $ctor$12(/*NotifyCollectionChangedAction*/ action, /*IList?*/ changedItems, /*int*/ index, /*int*/ oldIndex)
            {
                super.$ctor$1();
                {
                    if (action !== 3/*NotifyCollectionChangedAction.Move*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$so.System.SR.Format($.$so.System.SR.WrongActionForCtor, $.$box(3/*NotifyCollectionChangedAction.Move*/, $.$so.System.Collections.Specialized.NotifyCollectionChangedAction)), "action");
                    }
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                    this._action = action;
                    this._newItems = this._oldItems = !(changedItems === null) ? new $.$so.System.Collections.Specialized.ReadOnlyList().$ctor$1(changedItems) : null;
                    this._newStartingIndex = index;
                    this._oldStartingIndex = oldIndex;
                }
                return this;
            }
            /*NotifyCollectionChangedAction */ get Action()
            {
                return this._action;
            }
            /*IList? */ get NewItems()
            {
                return this._newItems;
            }
            /*IList? */ get OldItems()
            {
                return this._oldItems;
            }
            /*int */ get NewStartingIndex()
            {
                return this._newStartingIndex;
            }
            /*int */ get OldStartingIndex()
            {
                return this._oldStartingIndex;
            }
            static $h = 718723;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":653187,"g":{"r":0,"d":0,"h":77310130051,"f":1},"n":"Action","d":718723,"h":73015162755,"f":1},{"p":31981569,"g":{"r":0,"d":0,"h":85900064643,"f":1},"n":"NewItems","d":718723,"h":81605097347,"f":1},{"p":31981569,"g":{"r":0,"d":0,"h":94489999235,"f":1},"n":"OldItems","d":718723,"h":90195031939,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103079933827,"f":1},"n":"NewStartingIndex","d":718723,"h":98784966531,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":111669868419,"f":1},"n":"OldStartingIndex","d":718723,"h":107374901123,"f":1}],"l":[{"t":653187,"n":"_action","d":718723,"h":4295686019,"f":2},{"t":31981569,"n":"_newItems","d":718723,"h":8590653315,"f":2},{"t":31981569,"n":"_oldItems","d":718723,"h":12885620611,"f":2},{"t":655361,"n":"_newStartingIndex","d":718723,"h":17180587907,"f":2},{"t":655361,"n":"_oldStartingIndex","d":718723,"h":21475555203,"f":2}],"c":[{"p":[{"n":"action","p":653187}],"n":".ctor","o":"$ctor$2","d":718723,"h":25770522499,"f":1},{"p":[{"n":"action","p":653187},{"n":"changedItem","p":131073}],"n":".ctor","o":"$ctor$3","d":718723,"h":30065489795,"f":1},{"p":[{"n":"action","p":653187},{"n":"changedItem","p":131073},{"n":"index","p":655361}],"n":".ctor","o":"$ctor$4","d":718723,"h":34360457091,"f":1},{"p":[{"n":"action","p":653187},{"n":"changedItems","p":31981569}],"n":".ctor","o":"$ctor$5","d":718723,"h":38655424387,"f":1},{"p":[{"n":"action","p":653187},{"n":"changedItems","p":31981569},{"n":"startingIndex","p":655361}],"n":".ctor","o":"$ctor$6","d":718723,"h":42950391683,"f":1},{"p":[{"n":"action","p":653187},{"n":"newItem","p":131073},{"n":"oldItem","p":131073}],"n":".ctor","o":"$ctor$7","d":718723,"h":47245358979,"f":1},{"p":[{"n":"action","p":653187},{"n":"newItem","p":131073},{"n":"oldItem","p":131073},{"n":"index","p":655361}],"n":".ctor","o":"$ctor$8","d":718723,"h":51540326275,"f":1},{"p":[{"n":"action","p":653187},{"n":"newItems","p":31981569},{"n":"oldItems","p":31981569}],"n":".ctor","o":"$ctor$9","d":718723,"h":55835293571,"f":1},{"p":[{"n":"action","p":653187},{"n":"newItems","p":31981569},{"n":"oldItems","p":31981569},{"n":"startingIndex","p":655361}],"n":".ctor","o":"$ctor$10","d":718723,"h":60130260867,"f":1},{"p":[{"n":"action","p":653187},{"n":"changedItem","p":131073},{"n":"index","p":655361},{"n":"oldIndex","p":655361}],"n":".ctor","o":"$ctor$11","d":718723,"h":64425228163,"f":1},{"p":[{"n":"action","p":653187},{"n":"changedItems","p":31981569},{"n":"index","p":655361},{"n":"oldIndex","p":655361}],"n":".ctor","o":"$ctor$12","d":718723,"h":68720195459,"f":1}],"h":718723}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Collections.Specialized.NotifyCollectionChangedEventArgs`; }
        });
        
        $asm.$cls("$so.System.Collections.ObjectModel.ReadOnlyObservableCollection<>", (T) => $asm.$gt("$so.System.Collections.ObjectModel.ReadOnlyObservableCollection<>", [T], ($self) => class ReadOnlyObservableCollection$$ extends $.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$(T)
        {
            $ctor$2(/*ObservableCollection<T>*/ list)
            {
                super.$ctor$1(list);
                {
                    ($.$cast(this.Items, $.$so.System.Collections.Specialized.INotifyCollectionChanged)).System$Collections$Specialized$INotifyCollectionChanged$add_CollectionChanged(new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventHandler().$ctor(this, this.HandleCollectionChanged));
                    ($.$cast(this.Items, $.$so.System.ComponentModel.INotifyPropertyChanged)).System$ComponentModel$INotifyPropertyChanged$add_PropertyChanged(new $.$so.System.ComponentModel.PropertyChangedEventHandler().$ctor(this, this.HandlePropertyChanged));
                }
                return this;
            }
            /*ReadOnlyObservableCollection<T>*/ static Empty$1 = null;
            /*NotifyCollectionChangedEventHandler?*/ add_System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged(value)
            {
                return this.add_CollectionChanged(value);
            }
            /*NotifyCollectionChangedEventHandler?*/ remove_System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged(value)
            {
                this.remove_CollectionChanged(value);
            }
            /*NotifyCollectionChangedEventHandler?*/ CollectionChanged = null;
            add_CollectionChanged(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                this.CollectionChanged = $.$spc.System.Delegate.Combine(this.CollectionChanged, value);
            }
            remove_CollectionChanged(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                this.CollectionChanged = $.$spc.System.Delegate.Remove(this.CollectionChanged, value);
            }
            /*void */ OnCollectionChanged(/*NotifyCollectionChangedEventArgs*/ args)
            {
                this.CollectionChanged?.Invoke(this, args);
            }
            /*PropertyChangedEventHandler?*/ add_System$ComponentModel$INotifyPropertyChanged$PropertyChanged(value)
            {
                return this.add_PropertyChanged(value);
            }
            /*PropertyChangedEventHandler?*/ remove_System$ComponentModel$INotifyPropertyChanged$PropertyChanged(value)
            {
                this.remove_PropertyChanged(value);
            }
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                this.PropertyChanged = $.$spc.System.Delegate.Combine(this.PropertyChanged, value);
            }
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                this.PropertyChanged = $.$spc.System.Delegate.Remove(this.PropertyChanged, value);
            }
            /*void */ OnPropertyChanged(/*PropertyChangedEventArgs*/ args)
            {
                this.PropertyChanged?.Invoke(this, args);
            }
            /*void */ HandleCollectionChanged(/*object?*/ sender, /*NotifyCollectionChangedEventArgs*/ e)
            {
                this.OnCollectionChanged(e);
            }
            /*void */ HandlePropertyChanged(/*object?*/ sender, /*PropertyChangedEventArgs*/ e)
            {
                this.OnPropertyChanged(e);
            }
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged
            System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged()
            {
                this.System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged;
            }
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                this.System$ComponentModel$INotifyPropertyChanged$PropertyChanged;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty$1 = new ($.$so.System.Collections.ObjectModel.ReadOnlyObservableCollection$$(T))().$ctor$2(new ($.$so.System.Collections.ObjectModel.ObservableCollection$$(T))().$ctor$3());
                }
            }
            static $h = 522115;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":this.$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":33},"n":"Empty","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":33}],"m":[{"r":65537,"p":[{"n":"args","p":718723}],"n":"OnCollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":132},{"r":65537,"p":[{"n":"args","p":1243011}],"n":"OnPropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":132},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":718723}],"n":"HandleCollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":2},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1243011}],"n":"HandlePropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":2}],"c":[{"p":[{"n":"list","p":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"e":[{"e":784259,"m":{"r":65537,"p":[{"n":"value","p":784259}],"n":"{587651}.add_CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$add_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2},"r":{"r":65537,"p":[{"n":"value","p":784259}],"n":"{587651}.remove_CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$remove_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2},"n":"System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged","o":"System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2},{"e":784259,"m":{"r":65537,"p":[{"n":"value","p":784259}],"n":"add_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":132},"r":{"r":65537,"p":[{"n":"value","p":784259}],"n":"remove_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":132},"n":"CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":132},{"e":1308547,"m":{"r":65537,"p":[{"n":"value","p":1308547}],"n":"{1111939}.add_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$add_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2},"r":{"r":65537,"p":[{"n":"value","p":1308547}],"n":"{1111939}.remove_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$remove_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2},"n":"System.ComponentModel.INotifyPropertyChanged.PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2},{"e":1308547,"m":{"r":65537,"p":[{"n":"value","p":1308547}],"n":"add_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":132},"r":{"r":65537,"p":[{"n":"value","p":1308547}],"n":"remove_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":132},"n":"PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":132}],"i":[$.$spc.System.Collections.Generic.IList$$(T).$h,$.$spc.System.Collections.Generic.ICollection$$(T).$h,31981569,31391745,$.$spc.System.Collections.Generic.IReadOnlyList$$(T).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$spc.System.Collections.Generic.IEnumerable$$(T).$h,31653889,587651,1111939],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":118226945,"c":4413194241},{"t":37945345,"c":8627879937,"a":[{"v":$.$so.System.Collections.Generic.CollectionDebugView$$().$h,"t":142606337}]},{"t":37617665,"c":8627552257,"a":[{"v":"Count = {Count}","t":1310721}]},{"t":96272385,"c":4391239681,"a":[{"v":"WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IList$$(T), $.$spc.System.Collections.Generic.ICollection$$(T), $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.Generic.IReadOnlyList$$(T), $.$spc.System.Collections.Generic.IReadOnlyCollection$$(T), $.$spc.System.Collections.Generic.IEnumerable$$(T), $.$spc.System.Collections.IEnumerable, $.$so.System.Collections.Specialized.INotifyCollectionChanged, $.$so.System.ComponentModel.INotifyPropertyChanged ]; }
            static get $fullName() { return `System.Collections.ObjectModel.ReadOnlyObservableCollection<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$so.System.Collections.ObjectModel.ObservableCollection<>", (T) => $asm.$gt("$so.System.Collections.ObjectModel.ObservableCollection<>", [T], ($self) => class ObservableCollection$$ extends $.$spc.System.Collections.ObjectModel.Collection$$(T)
        {
            /*SimpleMonitor?*/ _monitor = null;
            /*int*/ _blockReentrancyCount = 0;
            $ctor$3()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$4(/*IEnumerable<T>*/ collection)
            {
                super.$ctor$2(new ($.$spc.System.Collections.Generic.List$$(T))().$ctor$3($.$firstOf(collection, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("collection") })));
                {
                }
                return this;
            }
            $ctor$5(/*List<T>*/ list)
            {
                super.$ctor$2(new ($.$spc.System.Collections.Generic.List$$(T))().$ctor$3($.$firstOf(list, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("list") })));
                {
                }
                return this;
            }
            /*void */ Move(/*int*/ oldIndex, /*int*/ newIndex)
            {
                return this.MoveItem(oldIndex, newIndex);
            }
            /*PropertyChangedEventHandler?*/ add_System$ComponentModel$INotifyPropertyChanged$PropertyChanged(value)
            {
                return this.add_PropertyChanged(value);
            }
            /*PropertyChangedEventHandler?*/ remove_System$ComponentModel$INotifyPropertyChanged$PropertyChanged(value)
            {
                this.remove_PropertyChanged(value);
            }
            /*NotifyCollectionChangedEventHandler?*/ CollectionChanged = null;
            add_CollectionChanged(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                this.CollectionChanged = $.$spc.System.Delegate.Combine(this.CollectionChanged, value);
            }
            remove_CollectionChanged(/*NotifyCollectionChangedEventHandler?*/ value)
            {
                this.CollectionChanged = $.$spc.System.Delegate.Remove(this.CollectionChanged, value);
            }
            /*void */ ClearItems()
            {
                this.CheckReentrancy();
                super.ClearItems();
                this.OnCountPropertyChanged();
                this.OnIndexerPropertyChanged();
                this.OnCollectionReset();
            }
            /*void */ RemoveItem(/*int*/ index)
            {
                this.CheckReentrancy();
                /*T*/ let removedItem = this.get_Item(index);
                super.RemoveItem(index);
                this.OnCountPropertyChanged();
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged$1(1/*NotifyCollectionChangedAction.Remove*/, $.$box(removedItem, T), index);
            }
            /*void */ InsertItem(/*int*/ index, /*T*/ item)
            {
                this.CheckReentrancy();
                super.InsertItem(index, item);
                this.OnCountPropertyChanged();
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged$1(0/*NotifyCollectionChangedAction.Add*/, $.$box(item, T), index);
            }
            /*void */ SetItem(/*int*/ index, /*T*/ item)
            {
                this.CheckReentrancy();
                /*T*/ let originalItem = this.get_Item(index);
                super.SetItem(index, item);
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged$3(2/*NotifyCollectionChangedAction.Replace*/, $.$box(originalItem, T), $.$box(item, T), index);
            }
            /*void */ MoveItem(/*int*/ oldIndex, /*int*/ newIndex)
            {
                this.CheckReentrancy();
                /*T*/ let removedItem = this.get_Item(oldIndex);
                super.RemoveItem(oldIndex);
                super.InsertItem(newIndex, removedItem);
                this.OnIndexerPropertyChanged();
                this.OnCollectionChanged$2(3/*NotifyCollectionChangedAction.Move*/, $.$box(removedItem, T), newIndex, oldIndex);
            }
            /*void */ OnPropertyChanged(/*PropertyChangedEventArgs*/ e)
            {
                this.PropertyChanged?.Invoke(this, e);
            }
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                this.PropertyChanged = $.$spc.System.Delegate.Combine(this.PropertyChanged, value);
            }
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                this.PropertyChanged = $.$spc.System.Delegate.Remove(this.PropertyChanged, value);
            }
            /*void */ OnCollectionChanged(/*NotifyCollectionChangedEventArgs*/ e)
            {
                /*NotifyCollectionChangedEventHandler?*/ let handler = this.CollectionChanged;
                if (handler !== null)
                {
                    this._blockReentrancyCount++;
                    try
                    {
                        handler.Invoke(this, e);
                    }
                    finally
                    {
                        {
                            this._blockReentrancyCount--;
                        }
                    }
                }
            }
            /*IDisposable */ BlockReentrancy()
            {
                this._blockReentrancyCount++;
                return this.EnsureMonitorInitialized();
            }
            /*void */ CheckReentrancy()
            {
                if (this._blockReentrancyCount > 0)
                {
                    /*NotifyCollectionChangedEventHandler?*/ let handler = this.CollectionChanged;
                    if (handler !== null && !handler.HasSingleTarget)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$so.System.SR.ObservableCollectionReentrancyNotAllowed);
                    }
                }
            }
            /*void */ OnCountPropertyChanged()
            {
                return this.OnPropertyChanged($.$so.System.Collections.ObjectModel.EventArgsCache.CountPropertyChanged);
            }
            /*void */ OnIndexerPropertyChanged()
            {
                return this.OnPropertyChanged($.$so.System.Collections.ObjectModel.EventArgsCache.IndexerPropertyChanged);
            }
            /*void */ OnCollectionChanged$1(/*NotifyCollectionChangedAction*/ action, /*object?*/ item, /*int*/ index)
            {
                this.OnCollectionChanged(new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs().$ctor$4(action, item, index));
            }
            /*void */ OnCollectionChanged$2(/*NotifyCollectionChangedAction*/ action, /*object?*/ item, /*int*/ index, /*int*/ oldIndex)
            {
                this.OnCollectionChanged(new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs().$ctor$11(action, item, index, oldIndex));
            }
            /*void */ OnCollectionChanged$3(/*NotifyCollectionChangedAction*/ action, /*object?*/ oldItem, /*object?*/ newItem, /*int*/ index)
            {
                this.OnCollectionChanged(new $.$so.System.Collections.Specialized.NotifyCollectionChangedEventArgs().$ctor$8(action, newItem, oldItem, index));
            }
            /*void */ OnCollectionReset()
            {
                return this.OnCollectionChanged($.$so.System.Collections.ObjectModel.EventArgsCache.ResetCollectionChanged);
            }
            /*SimpleMonitor */ EnsureMonitorInitialized()
            {
                return this._monitor ??= new ($.$so.System.Collections.ObjectModel.ObservableCollection$$(T).SimpleMonitor)().$ctor$1(this);
            }
            /*void */ OnSerializing(/*StreamingContext*/ context)
            {
                this.EnsureMonitorInitialized();
                this._monitor._busyCount = this._blockReentrancyCount;
            }
            /*void */ OnDeserialized(/*StreamingContext*/ context)
            {
                if (this._monitor !== null)
                {
                    this._blockReentrancyCount = this._monitor._busyCount;
                    this._monitor._collection = this;
                }
            }
            static $_SimpleMonitor;
            static get SimpleMonitor()
            {
                let $cls = $.$so.System.Collections.ObjectModel.ObservableCollection$$(T);
                return $cls.$_SimpleMonitor ??= $asm.$ncls("$so.System.Collections.ObjectModel.ObservableCollection$$.SimpleMonitor", ($self) => class SimpleMonitor extends $.$spc.System.Object
                {
                    /*int*/ _busyCount = 0;
                    /*ObservableCollection<T>*/ _collection = null;
                    $ctor$1(/*ObservableCollection<T>*/ collection)
                    {
                        super.$ctor();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(collection !== null, "collection != null");
                            this._collection = collection;
                        }
                        return this;
                    }
                    /*void */ Dispose()
                    {
                        return this._collection._blockReentrancyCount--;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 456579;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"l":[{"t":655361,"n":"_busyCount","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8},{"t":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).$h,"n":"_collection","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":8,"a":[{"t":66519041,"c":4361486337}]}],"c":[{"p":[{"n":"collection","p":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"i":[57540609],"d":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).$h,"h":this.$h,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]}]}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `System.Collections.ObjectModel.ObservableCollection<${T?.$fullName}>.SimpleMonitor`; }
                }, $cls, ($v) => $cls.$_SimpleMonitor = $v);
            }
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged.add
            System$Collections$Specialized$INotifyCollectionChanged$add_CollectionChanged()
            {
                return this.add_CollectionChanged(...arguments);
            }
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged.remove
            System$Collections$Specialized$INotifyCollectionChanged$remove_CollectionChanged()
            {
                return this.remove_CollectionChanged(...arguments);
            }
            //Generated interface implemetation for System.Collections.Specialized.INotifyCollectionChanged.CollectionChanged
            System$Collections$Specialized$INotifyCollectionChanged$CollectionChanged()
            {
                this.CollectionChanged;
            }
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                this.System$ComponentModel$INotifyPropertyChanged$PropertyChanged;
            }
            static $h = 391043;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"oldIndex","p":655361},{"n":"newIndex","p":655361}],"n":"Move","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},{"r":65537,"n":"ClearItems","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":32772},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveItem","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":32772},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":T?.$h??1507328}],"n":"InsertItem","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":32772},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":T?.$h??1507328}],"n":"SetItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":32772},{"r":65537,"p":[{"n":"oldIndex","p":655361},{"n":"newIndex","p":655361}],"n":"MoveItem","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":132},{"r":65537,"p":[{"n":"e","p":1243011}],"n":"OnPropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":132},{"r":65537,"p":[{"n":"e","p":718723}],"n":"OnCollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":132},{"r":57540609,"n":"BlockReentrancy","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":4},{"r":65537,"n":"CheckReentrancy","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":4},{"r":65537,"n":"OnCountPropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":2},{"r":65537,"n":"OnIndexerPropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":2},{"r":65537,"p":[{"n":"action","p":653187},{"n":"item","p":131073},{"n":"index","p":655361}],"n":"OnCollectionChanged","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":2},{"r":65537,"p":[{"n":"action","p":653187},{"n":"item","p":131073},{"n":"index","p":655361},{"n":"oldIndex","p":655361}],"n":"OnCollectionChanged","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":2},{"r":65537,"p":[{"n":"action","p":653187},{"n":"oldItem","p":131073},{"n":"newItem","p":131073},{"n":"index","p":655361}],"n":"OnCollectionChanged","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":2},{"r":65537,"n":"OnCollectionReset","d":this.$h,"h":Number(BigInt(this.$h)|0x1E00000000n),"f":2},{"r":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).SimpleMonitor.$h,"n":"EnsureMonitorInitialized","d":this.$h,"h":Number(BigInt(this.$h)|0x1F00000000n),"f":2},{"r":65537,"p":[{"n":"context","p":114098177}],"n":"OnSerializing","d":this.$h,"h":Number(BigInt(this.$h)|0x2000000000n),"f":2,"a":[{"t":113639425,"c":4408606721}]},{"r":65537,"p":[{"n":"context","p":114098177}],"n":"OnDeserialized","d":this.$h,"h":Number(BigInt(this.$h)|0x2100000000n),"f":2,"a":[{"t":113442817,"c":4408410113}]}],"l":[{"t":$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).SimpleMonitor.$h,"n":"_monitor","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":655361,"n":"_blockReentrancyCount","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2,"a":[{"t":66519041,"c":4361486337}]}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":[{"n":"collection","p":$.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},{"p":[{"n":"list","p":$.$spc.System.Collections.Generic.List$$(T).$h}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"e":[{"e":1308547,"m":{"r":65537,"p":[{"n":"value","p":1308547}],"n":"{1111939}.add_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$add_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":2},"r":{"r":65537,"p":[{"n":"value","p":1308547}],"n":"{1111939}.remove_PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$remove_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2},"n":"System.ComponentModel.INotifyPropertyChanged.PropertyChanged","o":"System$ComponentModel$INotifyPropertyChanged$PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2},{"e":784259,"m":{"r":65537,"p":[{"n":"value","p":784259}],"n":"add_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":129},"r":{"r":65537,"p":[{"n":"value","p":784259}],"n":"remove_CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":129},"n":"CollectionChanged","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":129},{"e":1308547,"m":{"r":65537,"p":[{"n":"value","p":1308547}],"n":"add_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":132},"r":{"r":65537,"p":[{"n":"value","p":1308547}],"n":"remove_PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":132},"n":"PropertyChanged","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":132}],"i":[$.$spc.System.Collections.Generic.IList$$(T).$h,$.$spc.System.Collections.Generic.ICollection$$(T).$h,31981569,31391745,$.$spc.System.Collections.Generic.IReadOnlyList$$(T).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$spc.System.Collections.Generic.IEnumerable$$(T).$h,31653889,587651,1111939],"g":[T?.$h??1507328],"j":[$.$so.System.Collections.ObjectModel.ObservableCollection$$(T).SimpleMonitor.$h],"r":1,"h":this.$h,"a":[{"t":118226945,"c":4413194241},{"t":37945345,"c":8627879937,"a":[{"v":$.$so.System.Collections.Generic.CollectionDebugView$$().$h,"t":142606337}]},{"t":37617665,"c":8627552257,"a":[{"v":"Count = {Count}","t":1310721}]},{"t":96272385,"c":4391239681,"a":[{"v":"WindowsBase, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Collections.ObjectModel.Collection$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IList$$(T), $.$spc.System.Collections.Generic.ICollection$$(T), $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.Generic.IReadOnlyList$$(T), $.$spc.System.Collections.Generic.IReadOnlyCollection$$(T), $.$spc.System.Collections.Generic.IEnumerable$$(T), $.$spc.System.Collections.IEnumerable, $.$so.System.Collections.Specialized.INotifyCollectionChanged, $.$so.System.ComponentModel.INotifyPropertyChanged ]; }
            static get $fullName() { return `System.Collections.ObjectModel.ObservableCollection<${T?.$fullName}>`; }
        }));
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading"))