
//--TRIMMABLE-BOUNDARY-START(2)
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Private.Uri", 
    {
  "h": 2,
  "f": "System.Private.Uri",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Private.Uri",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Private.Uri",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2621442)
        $asm.$cls("$spu.System.UriParser", ($self) => class UriParser extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(292060397570)
            /*string */ get SchemeName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671771138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._scheme;
            }
            //--TRIMMABLE-BOUNDARY-END(292060397570)
            
            //--TRIMMABLE-BOUNDARY-START(47247261698)
            /*int */ get DefaultPort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901967362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._port;
            }
            //--TRIMMABLE-BOUNDARY-END(47247261698)
            
            //--TRIMMABLE-BOUNDARY-START(296355364866)
            /*UriSyntaxFlags*/ static SchemeOnlyFlags = 16;
            //--TRIMMABLE-BOUNDARY-END(296355364866)
            
            //--TRIMMABLE-BOUNDARY-START(25772425218)
            $ctor$1()
            {
                this.$ctor$2(16/*SchemeOnlyFlags*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772425218);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772425218)
            
            //--TRIMMABLE-BOUNDARY-START(266290593794)
            /*UriParser */ OnNewUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266290593794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(266290593794)
            
            //--TRIMMABLE-BOUNDARY-START(270585561090)
            /*void */ OnRegister(/*string*/ schemeName, /*int*/ defaultPort)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270585561090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(270585561090)
            
            //--TRIMMABLE-BOUNDARY-START(150326476802)
            /*void */ InitializeAndValidate(/*Uri*/ uri, /*out UriFormatException?*/ parsingError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326476802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (uri._syntax === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (!$.$$.System.Object.ReferenceEquals(uri._syntax, this))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_UserDrivenParsing, $.$$.System.Object.GetType.call(uri._syntax)));
                }
                $.$$.System.Diagnostics.Debug.Assert$2($.$spu.System.Uri.Flags.$z === $.$$.System.UInt64.$z, "sizeof(Uri.Flags) == sizeof(ulong)");
                /*ulong*/ let previous = $.$$.System.Threading.Interlocked.Or$3($.$$.System.Runtime.CompilerServices.Unsafe.As($.$spu.System.Uri.Flags, $.$$.System.UInt64, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => uri._flags, ($v) => uri._flags = $v, null)), 72057594037927936n);
                if (($.$cast(previous, $.$spu.System.Uri.Flags) & 72057594037927936n) !== 0n)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_InitializeCalledAlreadyOrTooLate);
                }
                parsingError.$v = uri.ParseMinimal();
            }
            //--TRIMMABLE-BOUNDARY-END(150326476802)
            
            //--TRIMMABLE-BOUNDARY-START(279175495682)
            /*string? */ Resolve(/*Uri*/ baseUri, /*Uri?*/ relativeUri, /*out UriFormatException?*/ parsingError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279175495682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (baseUri.UserDrivenParsing)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_UserDrivenParsing, $.$$.System.Object.GetType.call(this)));
                }
                if (!baseUri.IsAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*string?*/ let newUriString = null;
                /*bool*/ let userEscaped = false;
                parsingError.$v = null;
                /*Uri?*/ let result = $.$spu.System.Uri.ResolveHelper(baseUri, relativeUri, $.$ref(() => newUriString, ($v) => newUriString = $v, $.$$.System.String), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => userEscaped, ($v) => userEscaped = $v, null));
                if ($.$spu.System.Uri.op_Inequality(result, null))
                {
                    return result.OriginalString;
                }
                return newUriString;
            }
            //--TRIMMABLE-BOUNDARY-END(279175495682)
            
            //--TRIMMABLE-BOUNDARY-START(184686215170)
            /*bool */ IsBaseOf(/*Uri*/ baseUri, /*Uri*/ relativeUri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184686215170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return baseUri.IsBaseOfHelper(relativeUri);
            }
            //--TRIMMABLE-BOUNDARY-END(184686215170)
            
            //--TRIMMABLE-BOUNDARY-START(115966738434)
            /*string */ GetComponents(/*Uri*/ uri, /*UriComponents*/ components, /*UriFormat*/ format)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966738434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((components & -2147483648/*UriComponents.SerializationInfoString*/) !== 0) && components !== -2147483648/*UriComponents.SerializationInfoString*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("components", $.$box(components, $.$spu.System.UriComponents), $.$spu.System.SR.net_uri_NotJustSerialization);
                }
                if ((format & ~3/*UriFormat.SafeUnescaped*/) !== 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("format");
                }
                if (uri.UserDrivenParsing)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_UserDrivenParsing, $.$$.System.Object.GetType.call(this)));
                }
                if (!uri.IsAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (uri.DisablePathAndQueryCanonicalization && (components & (16/*UriComponents.Path*/ | 32/*UriComponents.Query*/)) !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_GetComponentsCalledWhenCanonicalizationDisabled);
                }
                return uri.GetComponentsHelper(components, format);
            }
            //--TRIMMABLE-BOUNDARY-END(115966738434)
            
            //--TRIMMABLE-BOUNDARY-START(201866084354)
            /*bool */ IsWellFormedOriginalString(/*Uri*/ uri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201866084354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return uri.InternalIsWellFormedOriginalString();
            }
            //--TRIMMABLE-BOUNDARY-END(201866084354)
            
            //--TRIMMABLE-BOUNDARY-START(274880528386)
            static /*void */ Register(/*UriParser*/ uriParser, /*string*/ schemeName, /*int*/ defaultPort)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274880528386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uriParser, "uriParser");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(schemeName, "schemeName");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfEqual($.$$.System.Int32, schemeName.length, 1, "schemeName.Length");
                if (!$.$spu.System.Uri.CheckSchemeName(schemeName))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("schemeName");
                }
                if ((defaultPort >>> 0) > 65535 && defaultPort !== -1)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("defaultPort");
                }
                schemeName = $.$$.System.String.ToLowerInvariant.call(schemeName);
                $.$spu.System.UriParser.FetchSyntax(uriParser, schemeName, defaultPort);
            }
            //--TRIMMABLE-BOUNDARY-END(274880528386)
            
            //--TRIMMABLE-BOUNDARY-START(193276149762)
            static /*bool */ IsKnownScheme(/*string*/ schemeName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193276149762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(schemeName, "schemeName");
                if (!$.$spu.System.Uri.CheckSchemeName(schemeName))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("schemeName");
                }
                /*UriParser?*/ let syntax = $.$spu.System.UriParser.GetSyntax($.$$.System.String.ToLowerInvariant.call(schemeName));
                return syntax !== null && syntax.NotAny(65536/*UriSyntaxFlags.V1_UnknownUri*/);
            }
            //--TRIMMABLE-BOUNDARY-END(193276149762)
            
            //--TRIMMABLE-BOUNDARY-START(141736542210)
            /*UriParser*/ static HttpUri = null;
            //--TRIMMABLE-BOUNDARY-END(141736542210)
            
            //--TRIMMABLE-BOUNDARY-START(133146607618)
            /*UriParser*/ static HttpsUri = null;
            //--TRIMMABLE-BOUNDARY-END(133146607618)
            
            //--TRIMMABLE-BOUNDARY-START(339305037826)
            /*UriParser*/ static WsUri = null;
            //--TRIMMABLE-BOUNDARY-END(339305037826)
            
            //--TRIMMABLE-BOUNDARY-START(335010070530)
            /*UriParser*/ static WssUri = null;
            //--TRIMMABLE-BOUNDARY-END(335010070530)
            
            //--TRIMMABLE-BOUNDARY-START(77312032770)
            /*UriParser*/ static FtpUri = null;
            //--TRIMMABLE-BOUNDARY-END(77312032770)
            
            //--TRIMMABLE-BOUNDARY-START(60132163586)
            /*UriParser*/ static FileUri = null;
            //--TRIMMABLE-BOUNDARY-END(60132163586)
            
            //--TRIMMABLE-BOUNDARY-START(313535234050)
            /*UriParser*/ static UnixFileUri = null;
            //--TRIMMABLE-BOUNDARY-END(313535234050)
            
            //--TRIMMABLE-BOUNDARY-START(128851640322)
            /*UriParser*/ static GopherUri = null;
            //--TRIMMABLE-BOUNDARY-END(128851640322)
            
            //--TRIMMABLE-BOUNDARY-START(253405691906)
            /*UriParser*/ static NntpUri = null;
            //--TRIMMABLE-BOUNDARY-END(253405691906)
            
            //--TRIMMABLE-BOUNDARY-START(244815757314)
            /*UriParser*/ static NewsUri = null;
            //--TRIMMABLE-BOUNDARY-END(244815757314)
            
            //--TRIMMABLE-BOUNDARY-START(219045953538)
            /*UriParser*/ static MailToUri = null;
            //--TRIMMABLE-BOUNDARY-END(219045953538)
            
            //--TRIMMABLE-BOUNDARY-START(322125168642)
            /*UriParser*/ static UuidUri = null;
            //--TRIMMABLE-BOUNDARY-END(322125168642)
            
            //--TRIMMABLE-BOUNDARY-START(304945299458)
            /*UriParser*/ static TelnetUri = null;
            //--TRIMMABLE-BOUNDARY-END(304945299458)
            
            //--TRIMMABLE-BOUNDARY-START(210456018946)
            /*UriParser*/ static LdapUri = null;
            //--TRIMMABLE-BOUNDARY-END(210456018946)
            
            //--TRIMMABLE-BOUNDARY-START(236225822722)
            /*UriParser*/ static NetTcpUri = null;
            //--TRIMMABLE-BOUNDARY-END(236225822722)
            
            //--TRIMMABLE-BOUNDARY-START(227635888130)
            /*UriParser*/ static NetPipeUri = null;
            //--TRIMMABLE-BOUNDARY-END(227635888130)
            
            //--TRIMMABLE-BOUNDARY-START(330715103234)
            /*UriParser*/ static VsMacrosUri = null;
            //--TRIMMABLE-BOUNDARY-END(330715103234)
            
            //--TRIMMABLE-BOUNDARY-START(283470462978)
            /*Hashtable*/ static s_table = null;
            //--TRIMMABLE-BOUNDARY-END(283470462978)
            
            //--TRIMMABLE-BOUNDARY-START(287765430274)
            /*Hashtable*/ static s_tempTable = null;
            //--TRIMMABLE-BOUNDARY-END(287765430274)
            
            //--TRIMMABLE-BOUNDARY-START(4297588738)
            /*UriSyntaxFlags*/ _flags = 0;
            //--TRIMMABLE-BOUNDARY-END(4297588738)
            
            //--TRIMMABLE-BOUNDARY-START(8592556034)
            /*int*/ _port = 0;
            //--TRIMMABLE-BOUNDARY-END(8592556034)
            
            //--TRIMMABLE-BOUNDARY-START(12887523330)
            /*string*/ _scheme = null;
            //--TRIMMABLE-BOUNDARY-END(12887523330)
            
            //--TRIMMABLE-BOUNDARY-START(257700659202)
            /*int*/ static NoDefaultPort = -1;
            //--TRIMMABLE-BOUNDARY-END(257700659202)
            
            //--TRIMMABLE-BOUNDARY-START(34362359810)
            /*int*/ static c_InitialTableSize = 25;
            //--TRIMMABLE-BOUNDARY-END(34362359810)
            
            //--TRIMMABLE-BOUNDARY-START(2686978)
            static $_BuiltInUriParser;
            static get BuiltInUriParser()
            {
                let $cls = $.$spu.System.UriParser;
                return $cls.$_BuiltInUriParser ??= $asm.$ncls("$spu.System.UriParser.BuiltInUriParser", ($self) => class BuiltInUriParser extends $.$spu.System.UriParser
                {
                    //--TRIMMABLE-BOUNDARY-START(4297654274)
                    $ctor$3(/*string*/ lwrCaseScheme, /*int*/ defaultPort, /*UriSyntaxFlags*/ syntaxFlags)
                    {
                        super.$ctor$2(syntaxFlags | 131072/*UriSyntaxFlags.SimpleUserSyntax*/);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297654274);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._scheme = lwrCaseScheme;
                            this._port = defaultPort;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297654274)
                    
                    static $h = 2686978;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 2621442,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297654274),
    {
      "p": [
        {
          "n": "lwrCaseScheme",
          "p": 1310721
        },
        {
          "n": "defaultPort",
          "p": 655361
        },
        {
          "n": "syntaxFlags",
          "p": 2818050
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2686978,
      "h": 4297654274,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297654274)
  ],
  "d": 2621442,
  "h": 2686978
}; }
                    static get $b() { return $.$spu.System.UriParser; }
                    static get $fullName() { return `System.UriParser.BuiltInUriParser`; }
                }, $cls, ($v) => $cls.$_BuiltInUriParser = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2686978)
            
            //--TRIMMABLE-BOUNDARY-START(68722098178)
            /*UriSyntaxFlags */ get Flags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491901954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._flags;
            }
            //--TRIMMABLE-BOUNDARY-END(68722098178)
            
            //--TRIMMABLE-BOUNDARY-START(261995626498)
            /*bool */ NotAny(/*UriSyntaxFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261995626498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsFullMatch(flags, 0/*UriSyntaxFlags.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(261995626498)
            
            //--TRIMMABLE-BOUNDARY-START(146031509506)
            /*bool */ InFact(/*UriSyntaxFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031509506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !this.IsFullMatch(flags, 0/*UriSyntaxFlags.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(146031509506)
            
            //--TRIMMABLE-BOUNDARY-START(180391247874)
            /*bool */ IsAllSet(/*UriSyntaxFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391247874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsFullMatch(flags, flags);
            }
            //--TRIMMABLE-BOUNDARY-END(180391247874)
            
            //--TRIMMABLE-BOUNDARY-START(188981182466)
            /*bool */ IsFullMatch(/*UriSyntaxFlags*/ flags, /*UriSyntaxFlags*/ expected)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188981182466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._flags & flags) === expected;
            }
            //--TRIMMABLE-BOUNDARY-END(188981182466)
            
            //--TRIMMABLE-BOUNDARY-START(30067392514)
            $ctor$2(/*UriSyntaxFlags*/ flags)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067392514);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._flags = flags;
                    this._scheme = $.$$.System.String.Empty;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30067392514)
            
            //--TRIMMABLE-BOUNDARY-START(51542228994)
            static /*void */ FetchSyntax(/*UriParser*/ syntax, /*string*/ lwrCaseSchemeName, /*int*/ defaultPort)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542228994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (syntax.SchemeName.length !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_NeedFreshParser, syntax.SchemeName));
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$spu.System.UriParser.s_table)
                    {
                        syntax._flags &= ~65536/*UriSyntaxFlags.V1_UnknownUri*/;
                        /*UriParser?*/ let oldSyntax = $.$cast($.$spu.System.UriParser.s_table.get_Item(lwrCaseSchemeName), $.$spu.System.UriParser);
                        if (oldSyntax !== null)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_AlreadyRegistered, oldSyntax.SchemeName));
                        }
                        oldSyntax = $.$cast($.$spu.System.UriParser.s_tempTable.get_Item(syntax.SchemeName), $.$spu.System.UriParser);
                        if (oldSyntax !== null)
                        {
                            lwrCaseSchemeName = oldSyntax._scheme;
                            $.$spu.System.UriParser.s_tempTable.Remove(lwrCaseSchemeName);
                        }
                        syntax.OnRegister(lwrCaseSchemeName, defaultPort);
                        syntax._scheme = lwrCaseSchemeName;
                        syntax.CheckSetIsSimpleFlag();
                        syntax._port = defaultPort;
                        $.$spu.System.UriParser.s_table.set_Item(syntax.SchemeName, syntax);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$spu.System.UriParser.s_table)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51542228994)
            
            //--TRIMMABLE-BOUNDARY-START(38657327106)
            /*int*/ static c_MaxCapacity = 512;
            //--TRIMMABLE-BOUNDARY-END(38657327106)
            
            //--TRIMMABLE-BOUNDARY-START(64427130882)
            static /*UriParser */ FindOrFetchAsUnknownV1Syntax(/*string*/ lwrCaseScheme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427130882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*UriParser?*/ let syntax = $.$cast($.$spu.System.UriParser.s_table.get_Item(lwrCaseScheme), $.$spu.System.UriParser);
                if (syntax !== null)
                {
                    return syntax;
                }
                syntax = $.$cast($.$spu.System.UriParser.s_tempTable.get_Item(lwrCaseScheme), $.$spu.System.UriParser);
                if (syntax !== null)
                {
                    return syntax;
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$spu.System.UriParser.s_table)
                    {
                        if ($.$spu.System.UriParser.s_tempTable.Count >= 512/*c_MaxCapacity*/)
                        {
                            $.$spu.System.UriParser.s_tempTable = new $.$$.System.Collections.Hashtable().$ctor$16(25/*c_InitialTableSize*/);
                        }
                        syntax = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3(lwrCaseScheme, -1/*NoDefaultPort*/, 351342590/*UnknownV1SyntaxFlags*/);
                        $.$spu.System.UriParser.s_tempTable.set_Item(lwrCaseScheme, syntax);
                        return syntax;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$spu.System.UriParser.s_table)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64427130882)
            
            //--TRIMMABLE-BOUNDARY-START(120261705730)
            static /*UriParser? */ GetSyntax(/*string*/ lwrCaseScheme)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120261705730);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$cast(($.$spu.System.UriParser.s_table.get_Item(lwrCaseScheme) ?? $.$spu.System.UriParser.s_tempTable.get_Item(lwrCaseScheme)), $.$spu.System.UriParser);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120261705730)
            
            //--TRIMMABLE-BOUNDARY-START(197571117058)
            /*bool */ get IsSimple()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081836546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InFact(131072/*UriSyntaxFlags.SimpleUserSyntax*/);
            }
            //--TRIMMABLE-BOUNDARY-END(197571117058)
            
            //--TRIMMABLE-BOUNDARY-START(42952294402)
            /*void */ CheckSetIsSimpleFlag()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952294402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let type = $.$$.System.Object.GetType.call(this);
                if ($.$$.System.Type.op_Equality$1(type, $.$spu.System.GenericUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.HttpStyleUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.FtpStyleUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.FileStyleUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.NewsStyleUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.GopherStyleUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.NetPipeStyleUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.NetTcpStyleUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.LdapStyleUriParser.$type))
                {
                    this._flags |= 131072/*UriSyntaxFlags.SimpleUserSyntax*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42952294402)
            
            //--TRIMMABLE-BOUNDARY-START(167506345986)
            /*UriParser */ InternalOnNewUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167506345986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*UriParser*/ let effectiveParser = this.OnNewUri();
                if (this !== effectiveParser)
                {
                    effectiveParser._scheme = this._scheme;
                    effectiveParser._port = this._port;
                    effectiveParser._flags = this._flags;
                }
                return effectiveParser;
            }
            //--TRIMMABLE-BOUNDARY-END(167506345986)
            
            //--TRIMMABLE-BOUNDARY-START(176096280578)
            /*void */ InternalValidate(/*Uri*/ thisUri, /*out UriFormatException?*/ parsingError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096280578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                thisUri.DebugAssertInCtor();
                this.InitializeAndValidate(thisUri, parsingError);
                $.$$.System.Diagnostics.Debug.Assert$2($.$spu.System.Uri.Flags.$z === $.$$.System.UInt64.$z, "sizeof(Uri.Flags) == sizeof(ulong)");
                $.$$.System.Threading.Interlocked.Or$3($.$$.System.Runtime.CompilerServices.Unsafe.As($.$spu.System.Uri.Flags, $.$$.System.UInt64, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => thisUri._flags, ($v) => thisUri._flags = $v, null)), 72057594037927936n);
            }
            //--TRIMMABLE-BOUNDARY-END(176096280578)
            
            //--TRIMMABLE-BOUNDARY-START(171801313282)
            /*string? */ InternalResolve(/*Uri*/ thisBaseUri, /*Uri*/ uriLink, /*out UriFormatException?*/ parsingError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801313282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Resolve(thisBaseUri, uriLink, parsingError);
            }
            //--TRIMMABLE-BOUNDARY-END(171801313282)
            
            //--TRIMMABLE-BOUNDARY-START(158916411394)
            /*bool */ InternalIsBaseOf(/*Uri*/ thisBaseUri, /*Uri*/ uriLink)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158916411394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsBaseOf(thisBaseUri, uriLink);
            }
            //--TRIMMABLE-BOUNDARY-END(158916411394)
            
            //--TRIMMABLE-BOUNDARY-START(154621444098)
            /*string */ InternalGetComponents(/*Uri*/ thisUri, /*UriComponents*/ uriComponents, /*UriFormat*/ uriFormat)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621444098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetComponents(thisUri, uriComponents, uriFormat);
            }
            //--TRIMMABLE-BOUNDARY-END(154621444098)
            
            //--TRIMMABLE-BOUNDARY-START(163211378690)
            /*bool */ InternalIsWellFormedOriginalString(/*Uri*/ thisUri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211378690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsWellFormedOriginalString(thisUri);
            }
            //--TRIMMABLE-BOUNDARY-END(163211378690)
            
            //--TRIMMABLE-BOUNDARY-START(317830201346)
            /*UriSyntaxFlags*/ static UnknownV1SyntaxFlags = 351342590;
            //--TRIMMABLE-BOUNDARY-END(317830201346)
            
            //--TRIMMABLE-BOUNDARY-START(137441574914)
            /*UriSyntaxFlags*/ static HttpSyntaxFlags = 367005565;
            //--TRIMMABLE-BOUNDARY-END(137441574914)
            
            //--TRIMMABLE-BOUNDARY-START(73017065474)
            /*UriSyntaxFlags*/ static FtpSyntaxFlags = 367005533;
            //--TRIMMABLE-BOUNDARY-END(73017065474)
            
            //--TRIMMABLE-BOUNDARY-START(55837196290)
            /*UriSyntaxFlags*/ static FileSyntaxFlags = 401616881;
            //--TRIMMABLE-BOUNDARY-END(55837196290)
            
            //--TRIMMABLE-BOUNDARY-START(309240266754)
            /*UriSyntaxFlags*/ static UnixFileSyntaxFlags = 397422577;
            //--TRIMMABLE-BOUNDARY-END(309240266754)
            
            //--TRIMMABLE-BOUNDARY-START(326420135938)
            /*UriSyntaxFlags*/ static VsmacrosSyntaxFlags = 399519697;
            //--TRIMMABLE-BOUNDARY-END(326420135938)
            
            //--TRIMMABLE-BOUNDARY-START(124556673026)
            /*UriSyntaxFlags*/ static GopherSyntaxFlags = 337645405;
            //--TRIMMABLE-BOUNDARY-END(124556673026)
            
            //--TRIMMABLE-BOUNDARY-START(240520790018)
            /*UriSyntaxFlags*/ static NewsSyntaxFlags = 268435536;
            //--TRIMMABLE-BOUNDARY-END(240520790018)
            
            //--TRIMMABLE-BOUNDARY-START(249110724610)
            /*UriSyntaxFlags*/ static NntpSyntaxFlags = 337645405;
            //--TRIMMABLE-BOUNDARY-END(249110724610)
            
            //--TRIMMABLE-BOUNDARY-START(300650332162)
            /*UriSyntaxFlags*/ static TelnetSyntaxFlags = 337645405;
            //--TRIMMABLE-BOUNDARY-END(300650332162)
            
            //--TRIMMABLE-BOUNDARY-START(206161051650)
            /*UriSyntaxFlags*/ static LdapSyntaxFlags = 337645565;
            //--TRIMMABLE-BOUNDARY-END(206161051650)
            
            //--TRIMMABLE-BOUNDARY-START(214750986242)
            /*UriSyntaxFlags*/ static MailtoSyntaxFlags = 335564796;
            //--TRIMMABLE-BOUNDARY-END(214750986242)
            
            //--TRIMMABLE-BOUNDARY-START(223340920834)
            /*UriSyntaxFlags*/ static NetPipeSyntaxFlags = 400559729;
            //--TRIMMABLE-BOUNDARY-END(223340920834)
            
            //--TRIMMABLE-BOUNDARY-START(231930855426)
            /*UriSyntaxFlags*/ static NetTcpSyntaxFlags = 400559737;
            //--TRIMMABLE-BOUNDARY-END(231930855426)
            
            //--TRIMMABLE-BOUNDARY-START(21477457922)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(141736542210)
                    this.HttpUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("http", 80, 367005565/*HttpSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(141736542210)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133146607618)
                    this.HttpsUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("https", 443, $.$spu.System.UriParser.HttpUri._flags);
                    //--TRIMMABLE-BOUNDARY-END(133146607618)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339305037826)
                    this.WsUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("ws", 80, 367005565/*HttpSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(339305037826)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335010070530)
                    this.WssUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("wss", 443, 367005565/*HttpSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(335010070530)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77312032770)
                    this.FtpUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("ftp", 21, 367005533/*FtpSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(77312032770)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60132163586)
                    this.FileUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("file", -1/*NoDefaultPort*/, 401616881/*FileSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(60132163586)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313535234050)
                    this.UnixFileUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("file", -1/*NoDefaultPort*/, 397422577/*UnixFileSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(313535234050)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128851640322)
                    this.GopherUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("gopher", 70, 337645405/*GopherSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(128851640322)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253405691906)
                    this.NntpUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("nntp", 119, 337645405/*NntpSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(253405691906)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244815757314)
                    this.NewsUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("news", -1/*NoDefaultPort*/, 268435536/*NewsSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(244815757314)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219045953538)
                    this.MailToUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("mailto", 25, 335564796/*MailtoSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(219045953538)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322125168642)
                    this.UuidUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("uuid", -1/*NoDefaultPort*/, $.$spu.System.UriParser.NewsUri._flags);
                    //--TRIMMABLE-BOUNDARY-END(322125168642)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304945299458)
                    this.TelnetUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("telnet", 23, 337645405/*TelnetSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(304945299458)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210456018946)
                    this.LdapUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("ldap", 389, 337645565/*LdapSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(210456018946)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236225822722)
                    this.NetTcpUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("net.tcp", 808, 400559737/*NetTcpSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(236225822722)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227635888130)
                    this.NetPipeUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("net.pipe", -1/*NoDefaultPort*/, 400559729/*NetPipeSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(227635888130)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330715103234)
                    this.VsMacrosUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("vsmacros", -1/*NoDefaultPort*/, 399519697/*VsmacrosSyntaxFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(330715103234)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283470462978)
                    this.s_table = (() =>
                    {
                        //new $.$$.System.Collections.Hashtable()
                        const $t1 = $.$$.System.Collections.Hashtable;
                        const $i1 = new $t1();
                        $i1.$ctor$16(16);
                        $i1.Add($.$spu.System.UriParser.HttpUri.SchemeName, $.$spu.System.UriParser.HttpUri);
                        $i1.Add($.$spu.System.UriParser.HttpsUri.SchemeName, $.$spu.System.UriParser.HttpsUri);
                        $i1.Add($.$spu.System.UriParser.WsUri.SchemeName, $.$spu.System.UriParser.WsUri);
                        $i1.Add($.$spu.System.UriParser.WssUri.SchemeName, $.$spu.System.UriParser.WssUri);
                        $i1.Add($.$spu.System.UriParser.FtpUri.SchemeName, $.$spu.System.UriParser.FtpUri);
                        $i1.Add($.$spu.System.UriParser.FileUri.SchemeName, $.$spu.System.UriParser.FileUri);
                        $i1.Add($.$spu.System.UriParser.GopherUri.SchemeName, $.$spu.System.UriParser.GopherUri);
                        $i1.Add($.$spu.System.UriParser.NntpUri.SchemeName, $.$spu.System.UriParser.NntpUri);
                        $i1.Add($.$spu.System.UriParser.NewsUri.SchemeName, $.$spu.System.UriParser.NewsUri);
                        $i1.Add($.$spu.System.UriParser.MailToUri.SchemeName, $.$spu.System.UriParser.MailToUri);
                        $i1.Add($.$spu.System.UriParser.UuidUri.SchemeName, $.$spu.System.UriParser.UuidUri);
                        $i1.Add($.$spu.System.UriParser.TelnetUri.SchemeName, $.$spu.System.UriParser.TelnetUri);
                        $i1.Add($.$spu.System.UriParser.LdapUri.SchemeName, $.$spu.System.UriParser.LdapUri);
                        $i1.Add($.$spu.System.UriParser.NetTcpUri.SchemeName, $.$spu.System.UriParser.NetTcpUri);
                        $i1.Add($.$spu.System.UriParser.NetPipeUri.SchemeName, $.$spu.System.UriParser.NetPipeUri);
                        $i1.Add($.$spu.System.UriParser.VsMacrosUri.SchemeName, $.$spu.System.UriParser.VsMacrosUri);
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(283470462978)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287765430274)
                    this.s_tempTable = new $.$$.System.Collections.Hashtable().$ctor$16(25/*c_InitialTableSize*/);
                    //--TRIMMABLE-BOUNDARY-END(287765430274)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477457922)
            
            static $h = 2621442;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(292060397570),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671771138,
        "f": 50331656
      },
      "n": "SchemeName",
      "d": 2621442,
      "h": 292060397570,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(292060397570),
//--TRIMMABLE-BOUNDARY-START(47247261698),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901967362,
        "f": 50331656
      },
      "n": "DefaultPort",
      "d": 2621442,
      "h": 47247261698,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(47247261698),
//--TRIMMABLE-BOUNDARY-START(68722098178),
    {
      "p": 2818050,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491901954,
        "f": 50331656
      },
      "n": "Flags",
      "d": 2621442,
      "h": 68722098178,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(68722098178),
//--TRIMMABLE-BOUNDARY-START(197571117058),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081836546,
        "f": 50331656
      },
      "n": "IsSimple",
      "d": 2621442,
      "h": 197571117058,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(197571117058)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(266290593794),
    {
      "r": 2621442,
      "n": "OnNewUri",
      "d": 2621442,
      "h": 266290593794,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(266290593794),
//--TRIMMABLE-BOUNDARY-START(270585561090),
    {
      "r": 65537,
      "p": [
        {
          "n": "schemeName",
          "p": 1310721
        },
        {
          "n": "defaultPort",
          "p": 655361
        }
      ],
      "n": "OnRegister",
      "d": 2621442,
      "h": 270585561090,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(270585561090),
//--TRIMMABLE-BOUNDARY-START(150326476802),
    {
      "r": 65537,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        },
        {
          "n": "parsingError",
          "p": 2359298,
          "f": 2
        }
      ],
      "n": "InitializeAndValidate",
      "d": 2621442,
      "h": 150326476802,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(150326476802),
//--TRIMMABLE-BOUNDARY-START(279175495682),
    {
      "r": 1310721,
      "p": [
        {
          "n": "baseUri",
          "p": 1703938
        },
        {
          "n": "relativeUri",
          "p": 1703938
        },
        {
          "n": "parsingError",
          "p": 2359298,
          "f": 2
        }
      ],
      "n": "Resolve",
      "d": 2621442,
      "h": 279175495682,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(279175495682),
//--TRIMMABLE-BOUNDARY-START(184686215170),
    {
      "r": 262145,
      "p": [
        {
          "n": "baseUri",
          "p": 1703938
        },
        {
          "n": "relativeUri",
          "p": 1703938
        }
      ],
      "n": "IsBaseOf",
      "d": 2621442,
      "h": 184686215170,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(184686215170),
//--TRIMMABLE-BOUNDARY-START(115966738434),
    {
      "r": 1310721,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        },
        {
          "n": "components",
          "p": 2162690
        },
        {
          "n": "format",
          "p": 2293762
        }
      ],
      "n": "GetComponents",
      "d": 2621442,
      "h": 115966738434,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(115966738434),
//--TRIMMABLE-BOUNDARY-START(201866084354),
    {
      "r": 262145,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        }
      ],
      "n": "IsWellFormedOriginalString",
      "d": 2621442,
      "h": 201866084354,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(201866084354),
//--TRIMMABLE-BOUNDARY-START(274880528386),
    {
      "r": 65537,
      "p": [
        {
          "n": "uriParser",
          "p": 2621442
        },
        {
          "n": "schemeName",
          "p": 1310721
        },
        {
          "n": "defaultPort",
          "p": 655361
        }
      ],
      "n": "Register",
      "d": 2621442,
      "h": 274880528386,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(274880528386),
//--TRIMMABLE-BOUNDARY-START(193276149762),
    {
      "r": 262145,
      "p": [
        {
          "n": "schemeName",
          "p": 1310721
        }
      ],
      "n": "IsKnownScheme",
      "d": 2621442,
      "h": 193276149762,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(193276149762),
//--TRIMMABLE-BOUNDARY-START(261995626498),
    {
      "r": 262145,
      "p": [
        {
          "n": "flags",
          "p": 2818050
        }
      ],
      "n": "NotAny",
      "d": 2621442,
      "h": 261995626498,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(261995626498),
//--TRIMMABLE-BOUNDARY-START(146031509506),
    {
      "r": 262145,
      "p": [
        {
          "n": "flags",
          "p": 2818050
        }
      ],
      "n": "InFact",
      "d": 2621442,
      "h": 146031509506,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(146031509506),
//--TRIMMABLE-BOUNDARY-START(180391247874),
    {
      "r": 262145,
      "p": [
        {
          "n": "flags",
          "p": 2818050
        }
      ],
      "n": "IsAllSet",
      "d": 2621442,
      "h": 180391247874,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(180391247874),
//--TRIMMABLE-BOUNDARY-START(188981182466),
    {
      "r": 262145,
      "p": [
        {
          "n": "flags",
          "p": 2818050
        },
        {
          "n": "expected",
          "p": 2818050
        }
      ],
      "n": "IsFullMatch",
      "d": 2621442,
      "h": 188981182466,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(188981182466),
//--TRIMMABLE-BOUNDARY-START(51542228994),
    {
      "r": 65537,
      "p": [
        {
          "n": "syntax",
          "p": 2621442
        },
        {
          "n": "lwrCaseSchemeName",
          "p": 1310721
        },
        {
          "n": "defaultPort",
          "p": 655361
        }
      ],
      "n": "FetchSyntax",
      "d": 2621442,
      "h": 51542228994,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51542228994),
//--TRIMMABLE-BOUNDARY-START(64427130882),
    {
      "r": 2621442,
      "p": [
        {
          "n": "lwrCaseScheme",
          "p": 1310721
        }
      ],
      "n": "FindOrFetchAsUnknownV1Syntax",
      "d": 2621442,
      "h": 64427130882,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(64427130882),
//--TRIMMABLE-BOUNDARY-START(120261705730),
    {
      "r": 2621442,
      "p": [
        {
          "n": "lwrCaseScheme",
          "p": 1310721
        }
      ],
      "n": "GetSyntax",
      "d": 2621442,
      "h": 120261705730,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(120261705730),
//--TRIMMABLE-BOUNDARY-START(42952294402),
    {
      "r": 65537,
      "n": "CheckSetIsSimpleFlag",
      "d": 2621442,
      "h": 42952294402,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(42952294402),
//--TRIMMABLE-BOUNDARY-START(167506345986),
    {
      "r": 2621442,
      "n": "InternalOnNewUri",
      "d": 2621442,
      "h": 167506345986,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(167506345986),
//--TRIMMABLE-BOUNDARY-START(176096280578),
    {
      "r": 65537,
      "p": [
        {
          "n": "thisUri",
          "p": 1703938
        },
        {
          "n": "parsingError",
          "p": 2359298,
          "f": 2
        }
      ],
      "n": "InternalValidate",
      "d": 2621442,
      "h": 176096280578,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(176096280578),
//--TRIMMABLE-BOUNDARY-START(171801313282),
    {
      "r": 1310721,
      "p": [
        {
          "n": "thisBaseUri",
          "p": 1703938
        },
        {
          "n": "uriLink",
          "p": 1703938
        },
        {
          "n": "parsingError",
          "p": 2359298,
          "f": 2
        }
      ],
      "n": "InternalResolve",
      "d": 2621442,
      "h": 171801313282,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(171801313282),
//--TRIMMABLE-BOUNDARY-START(158916411394),
    {
      "r": 262145,
      "p": [
        {
          "n": "thisBaseUri",
          "p": 1703938
        },
        {
          "n": "uriLink",
          "p": 1703938
        }
      ],
      "n": "InternalIsBaseOf",
      "d": 2621442,
      "h": 158916411394,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(158916411394),
//--TRIMMABLE-BOUNDARY-START(154621444098),
    {
      "r": 1310721,
      "p": [
        {
          "n": "thisUri",
          "p": 1703938
        },
        {
          "n": "uriComponents",
          "p": 2162690
        },
        {
          "n": "uriFormat",
          "p": 2293762
        }
      ],
      "n": "InternalGetComponents",
      "d": 2621442,
      "h": 154621444098,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(154621444098),
//--TRIMMABLE-BOUNDARY-START(163211378690),
    {
      "r": 262145,
      "p": [
        {
          "n": "thisUri",
          "p": 1703938
        }
      ],
      "n": "InternalIsWellFormedOriginalString",
      "d": 2621442,
      "h": 163211378690,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(163211378690)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(296355364866),
    {
      "t": 2818050,
      "n": "SchemeOnlyFlags",
      "d": 2621442,
      "h": 296355364866,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(296355364866),
//--TRIMMABLE-BOUNDARY-START(141736542210),
    {
      "t": 2621442,
      "n": "HttpUri",
      "d": 2621442,
      "h": 141736542210,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141736542210),
//--TRIMMABLE-BOUNDARY-START(133146607618),
    {
      "t": 2621442,
      "n": "HttpsUri",
      "d": 2621442,
      "h": 133146607618,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133146607618),
//--TRIMMABLE-BOUNDARY-START(339305037826),
    {
      "t": 2621442,
      "n": "WsUri",
      "d": 2621442,
      "h": 339305037826,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339305037826),
//--TRIMMABLE-BOUNDARY-START(335010070530),
    {
      "t": 2621442,
      "n": "WssUri",
      "d": 2621442,
      "h": 335010070530,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335010070530),
//--TRIMMABLE-BOUNDARY-START(77312032770),
    {
      "t": 2621442,
      "n": "FtpUri",
      "d": 2621442,
      "h": 77312032770,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77312032770),
//--TRIMMABLE-BOUNDARY-START(60132163586),
    {
      "t": 2621442,
      "n": "FileUri",
      "d": 2621442,
      "h": 60132163586,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60132163586),
//--TRIMMABLE-BOUNDARY-START(313535234050),
    {
      "t": 2621442,
      "n": "UnixFileUri",
      "d": 2621442,
      "h": 313535234050,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313535234050),
//--TRIMMABLE-BOUNDARY-START(128851640322),
    {
      "t": 2621442,
      "n": "GopherUri",
      "d": 2621442,
      "h": 128851640322,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128851640322),
//--TRIMMABLE-BOUNDARY-START(253405691906),
    {
      "t": 2621442,
      "n": "NntpUri",
      "d": 2621442,
      "h": 253405691906,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253405691906),
//--TRIMMABLE-BOUNDARY-START(244815757314),
    {
      "t": 2621442,
      "n": "NewsUri",
      "d": 2621442,
      "h": 244815757314,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244815757314),
//--TRIMMABLE-BOUNDARY-START(219045953538),
    {
      "t": 2621442,
      "n": "MailToUri",
      "d": 2621442,
      "h": 219045953538,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219045953538),
//--TRIMMABLE-BOUNDARY-START(322125168642),
    {
      "t": 2621442,
      "n": "UuidUri",
      "d": 2621442,
      "h": 322125168642,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322125168642),
//--TRIMMABLE-BOUNDARY-START(304945299458),
    {
      "t": 2621442,
      "n": "TelnetUri",
      "d": 2621442,
      "h": 304945299458,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304945299458),
//--TRIMMABLE-BOUNDARY-START(210456018946),
    {
      "t": 2621442,
      "n": "LdapUri",
      "d": 2621442,
      "h": 210456018946,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210456018946),
//--TRIMMABLE-BOUNDARY-START(236225822722),
    {
      "t": 2621442,
      "n": "NetTcpUri",
      "d": 2621442,
      "h": 236225822722,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236225822722),
//--TRIMMABLE-BOUNDARY-START(227635888130),
    {
      "t": 2621442,
      "n": "NetPipeUri",
      "d": 2621442,
      "h": 227635888130,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227635888130),
//--TRIMMABLE-BOUNDARY-START(330715103234),
    {
      "t": 2621442,
      "n": "VsMacrosUri",
      "d": 2621442,
      "h": 330715103234,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330715103234),
//--TRIMMABLE-BOUNDARY-START(283470462978),
    {
      "t": 61931521,
      "n": "s_table",
      "d": 2621442,
      "h": 283470462978,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(283470462978),
//--TRIMMABLE-BOUNDARY-START(287765430274),
    {
      "t": 61931521,
      "n": "s_tempTable",
      "d": 2621442,
      "h": 287765430274,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(287765430274),
//--TRIMMABLE-BOUNDARY-START(4297588738),
    {
      "t": 2818050,
      "n": "_flags",
      "d": 2621442,
      "h": 4297588738,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297588738),
//--TRIMMABLE-BOUNDARY-START(8592556034),
    {
      "t": 655361,
      "n": "_port",
      "d": 2621442,
      "h": 8592556034,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592556034),
//--TRIMMABLE-BOUNDARY-START(12887523330),
    {
      "t": 1310721,
      "n": "_scheme",
      "d": 2621442,
      "h": 12887523330,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887523330),
//--TRIMMABLE-BOUNDARY-START(257700659202),
    {
      "t": 655361,
      "n": "NoDefaultPort",
      "d": 2621442,
      "h": 257700659202,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257700659202),
//--TRIMMABLE-BOUNDARY-START(34362359810),
    {
      "t": 655361,
      "n": "c_InitialTableSize",
      "d": 2621442,
      "h": 34362359810,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34362359810),
//--TRIMMABLE-BOUNDARY-START(38657327106),
    {
      "t": 655361,
      "n": "c_MaxCapacity",
      "d": 2621442,
      "h": 38657327106,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38657327106),
//--TRIMMABLE-BOUNDARY-START(317830201346),
    {
      "t": 2818050,
      "n": "UnknownV1SyntaxFlags",
      "d": 2621442,
      "h": 317830201346,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(317830201346),
//--TRIMMABLE-BOUNDARY-START(137441574914),
    {
      "t": 2818050,
      "n": "HttpSyntaxFlags",
      "d": 2621442,
      "h": 137441574914,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(137441574914),
//--TRIMMABLE-BOUNDARY-START(73017065474),
    {
      "t": 2818050,
      "n": "FtpSyntaxFlags",
      "d": 2621442,
      "h": 73017065474,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73017065474),
//--TRIMMABLE-BOUNDARY-START(55837196290),
    {
      "t": 2818050,
      "n": "FileSyntaxFlags",
      "d": 2621442,
      "h": 55837196290,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55837196290),
//--TRIMMABLE-BOUNDARY-START(309240266754),
    {
      "t": 2818050,
      "n": "UnixFileSyntaxFlags",
      "d": 2621442,
      "h": 309240266754,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(309240266754),
//--TRIMMABLE-BOUNDARY-START(326420135938),
    {
      "t": 2818050,
      "n": "VsmacrosSyntaxFlags",
      "d": 2621442,
      "h": 326420135938,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(326420135938),
//--TRIMMABLE-BOUNDARY-START(124556673026),
    {
      "t": 2818050,
      "n": "GopherSyntaxFlags",
      "d": 2621442,
      "h": 124556673026,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(124556673026),
//--TRIMMABLE-BOUNDARY-START(240520790018),
    {
      "t": 2818050,
      "n": "NewsSyntaxFlags",
      "d": 2621442,
      "h": 240520790018,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(240520790018),
//--TRIMMABLE-BOUNDARY-START(249110724610),
    {
      "t": 2818050,
      "n": "NntpSyntaxFlags",
      "d": 2621442,
      "h": 249110724610,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(249110724610),
//--TRIMMABLE-BOUNDARY-START(300650332162),
    {
      "t": 2818050,
      "n": "TelnetSyntaxFlags",
      "d": 2621442,
      "h": 300650332162,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(300650332162),
//--TRIMMABLE-BOUNDARY-START(206161051650),
    {
      "t": 2818050,
      "n": "LdapSyntaxFlags",
      "d": 2621442,
      "h": 206161051650,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(206161051650),
//--TRIMMABLE-BOUNDARY-START(214750986242),
    {
      "t": 2818050,
      "n": "MailtoSyntaxFlags",
      "d": 2621442,
      "h": 214750986242,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(214750986242),
//--TRIMMABLE-BOUNDARY-START(223340920834),
    {
      "t": 2818050,
      "n": "NetPipeSyntaxFlags",
      "d": 2621442,
      "h": 223340920834,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(223340920834),
//--TRIMMABLE-BOUNDARY-START(231930855426),
    {
      "t": 2818050,
      "n": "NetTcpSyntaxFlags",
      "d": 2621442,
      "h": 231930855426,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(231930855426)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772425218),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2621442,
      "h": 25772425218,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(25772425218),
//--TRIMMABLE-BOUNDARY-START(30067392514),
    {
      "p": [
        {
          "n": "flags",
          "p": 2818050
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2621442,
      "h": 30067392514,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30067392514)
  ],
  "j": [2686978
  ],
  "h": 2621442
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.UriParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2621442)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245186)
        $asm.$cls("$spu.System.Obsoletions", ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382253334530)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382253334530)
            
            //--TRIMMABLE-BOUNDARY-START(433792942082)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433792942082)
            
            //--TRIMMABLE-BOUNDARY-START(429497974786)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429497974786)
            
            //--TRIMMABLE-BOUNDARY-START(266289217538)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266289217538)
            
            //--TRIMMABLE-BOUNDARY-START(261994250242)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261994250242)
            
            //--TRIMMABLE-BOUNDARY-START(77310656514)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77310656514)
            
            //--TRIMMABLE-BOUNDARY-START(73015689218)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73015689218)
            
            //--TRIMMABLE-BOUNDARY-START(94490525698)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94490525698)
            
            //--TRIMMABLE-BOUNDARY-START(90195558402)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90195558402)
            
            //--TRIMMABLE-BOUNDARY-START(214749609986)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214749609986)
            
            //--TRIMMABLE-BOUNDARY-START(210454642690)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210454642690)
            
            //--TRIMMABLE-BOUNDARY-START(442382876674)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442382876674)
            
            //--TRIMMABLE-BOUNDARY-START(446677843970)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446677843970)
            
            //--TRIMMABLE-BOUNDARY-START(438087909378)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438087909378)
            
            //--TRIMMABLE-BOUNDARY-START(146030133250)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146030133250)
            
            //--TRIMMABLE-BOUNDARY-START(141735165954)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141735165954)
            
            //--TRIMMABLE-BOUNDARY-START(120260329474)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120260329474)
            
            //--TRIMMABLE-BOUNDARY-START(115965362178)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115965362178)
            
            //--TRIMMABLE-BOUNDARY-START(51540852738)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51540852738)
            
            //--TRIMMABLE-BOUNDARY-START(47245885442)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47245885442)
            
            //--TRIMMABLE-BOUNDARY-START(326418759682)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326418759682)
            
            //--TRIMMABLE-BOUNDARY-START(322123792386)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322123792386)
            
            //--TRIMMABLE-BOUNDARY-START(60130787330)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60130787330)
            
            //--TRIMMABLE-BOUNDARY-START(55835820034)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55835820034)
            
            //--TRIMMABLE-BOUNDARY-START(85900591106)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85900591106)
            
            //--TRIMMABLE-BOUNDARY-START(81605623810)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81605623810)
            
            //--TRIMMABLE-BOUNDARY-START(197569740802)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197569740802)
            
            //--TRIMMABLE-BOUNDARY-START(193274773506)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193274773506)
            
            //--TRIMMABLE-BOUNDARY-START(489627516930)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489627516930)
            
            //--TRIMMABLE-BOUNDARY-START(485332549634)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485332549634)
            
            //--TRIMMABLE-BOUNDARY-START(163210002434)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163210002434)
            
            //--TRIMMABLE-BOUNDARY-START(158915035138)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158915035138)
            
            //--TRIMMABLE-BOUNDARY-START(206159675394)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206159675394)
            
            //--TRIMMABLE-BOUNDARY-START(201864708098)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201864708098)
            
            //--TRIMMABLE-BOUNDARY-START(399433203714)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399433203714)
            
            //--TRIMMABLE-BOUNDARY-START(395138236418)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395138236418)
            
            //--TRIMMABLE-BOUNDARY-START(300648955906)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300648955906)
            
            //--TRIMMABLE-BOUNDARY-START(296353988610)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296353988610)
            
            //--TRIMMABLE-BOUNDARY-START(377958367234)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377958367234)
            
            //--TRIMMABLE-BOUNDARY-START(373663399938)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373663399938)
            
            //--TRIMMABLE-BOUNDARY-START(231929479170)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231929479170)
            
            //--TRIMMABLE-BOUNDARY-START(227634511874)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227634511874)
            
            //--TRIMMABLE-BOUNDARY-START(154620067842)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154620067842)
            
            //--TRIMMABLE-BOUNDARY-START(150325100546)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150325100546)
            
            //--TRIMMABLE-BOUNDARY-START(352188563458)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352188563458)
            
            //--TRIMMABLE-BOUNDARY-START(347893596162)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347893596162)
            
            //--TRIMMABLE-BOUNDARY-START(360778498050)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360778498050)
            
            //--TRIMMABLE-BOUNDARY-START(356483530754)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356483530754)
            
            //--TRIMMABLE-BOUNDARY-START(17181114370)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17181114370)
            
            //--TRIMMABLE-BOUNDARY-START(12886147074)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12886147074)
            
            //--TRIMMABLE-BOUNDARY-START(408023138306)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408023138306)
            
            //--TRIMMABLE-BOUNDARY-START(403728171010)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403728171010)
            
            //--TRIMMABLE-BOUNDARY-START(498217451522)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498217451522)
            
            //--TRIMMABLE-BOUNDARY-START(493922484226)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493922484226)
            
            //--TRIMMABLE-BOUNDARY-START(283469086722)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283469086722)
            
            //--TRIMMABLE-BOUNDARY-START(279174119426)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279174119426)
            
            //--TRIMMABLE-BOUNDARY-START(506807386114)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506807386114)
            
            //--TRIMMABLE-BOUNDARY-START(502512418818)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502512418818)
            
            //--TRIMMABLE-BOUNDARY-START(274879152130)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274879152130)
            
            //--TRIMMABLE-BOUNDARY-START(270584184834)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270584184834)
            
            //--TRIMMABLE-BOUNDARY-START(481037582338)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481037582338)
            
            //--TRIMMABLE-BOUNDARY-START(476742615042)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476742615042)
            
            //--TRIMMABLE-BOUNDARY-START(128850264066)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128850264066)
            
            //--TRIMMABLE-BOUNDARY-START(124555296770)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124555296770)
            
            //--TRIMMABLE-BOUNDARY-START(111670394882)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111670394882)
            
            //--TRIMMABLE-BOUNDARY-START(107375427586)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107375427586)
            
            //--TRIMMABLE-BOUNDARY-START(335008694274)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335008694274)
            
            //--TRIMMABLE-BOUNDARY-START(330713726978)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330713726978)
            
            //--TRIMMABLE-BOUNDARY-START(68720721922)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68720721922)
            
            //--TRIMMABLE-BOUNDARY-START(64425754626)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64425754626)
            
            //--TRIMMABLE-BOUNDARY-START(390843269122)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390843269122)
            
            //--TRIMMABLE-BOUNDARY-START(386548301826)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386548301826)
            
            //--TRIMMABLE-BOUNDARY-START(309238890498)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309238890498)
            
            //--TRIMMABLE-BOUNDARY-START(304943923202)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304943923202)
            
            //--TRIMMABLE-BOUNDARY-START(42950918146)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42950918146)
            
            //--TRIMMABLE-BOUNDARY-START(38655950850)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38655950850)
            
            //--TRIMMABLE-BOUNDARY-START(416613072898)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416613072898)
            
            //--TRIMMABLE-BOUNDARY-START(412318105602)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412318105602)
            
            //--TRIMMABLE-BOUNDARY-START(472447647746)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472447647746)
            
            //--TRIMMABLE-BOUNDARY-START(468152680450)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468152680450)
            
            //--TRIMMABLE-BOUNDARY-START(188979806210)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188979806210)
            
            //--TRIMMABLE-BOUNDARY-START(184684838914)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184684838914)
            
            //--TRIMMABLE-BOUNDARY-START(171799937026)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171799937026)
            
            //--TRIMMABLE-BOUNDARY-START(167504969730)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167504969730)
            
            //--TRIMMABLE-BOUNDARY-START(180389871618)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180389871618)
            
            //--TRIMMABLE-BOUNDARY-START(176094904322)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176094904322)
            
            //--TRIMMABLE-BOUNDARY-START(34360983554)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34360983554)
            
            //--TRIMMABLE-BOUNDARY-START(30066016258)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30066016258)
            
            //--TRIMMABLE-BOUNDARY-START(137440198658)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137440198658)
            
            //--TRIMMABLE-BOUNDARY-START(133145231362)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133145231362)
            
            //--TRIMMABLE-BOUNDARY-START(103080460290)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103080460290)
            
            //--TRIMMABLE-BOUNDARY-START(98785492994)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98785492994)
            
            //--TRIMMABLE-BOUNDARY-START(523987255298)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523987255298)
            
            //--TRIMMABLE-BOUNDARY-START(519692288002)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519692288002)
            
            //--TRIMMABLE-BOUNDARY-START(369368432642)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369368432642)
            
            //--TRIMMABLE-BOUNDARY-START(365073465346)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365073465346)
            
            //--TRIMMABLE-BOUNDARY-START(223339544578)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223339544578)
            
            //--TRIMMABLE-BOUNDARY-START(219044577282)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219044577282)
            
            //--TRIMMABLE-BOUNDARY-START(249109348354)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249109348354)
            
            //--TRIMMABLE-BOUNDARY-START(236224446466)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236224446466)
            
            //--TRIMMABLE-BOUNDARY-START(244814381058)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244814381058)
            
            //--TRIMMABLE-BOUNDARY-START(240519413762)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240519413762)
            
            //--TRIMMABLE-BOUNDARY-START(317828825090)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317828825090)
            
            //--TRIMMABLE-BOUNDARY-START(313533857794)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313533857794)
            
            //--TRIMMABLE-BOUNDARY-START(8591179778)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8591179778)
            
            //--TRIMMABLE-BOUNDARY-START(4296212482)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4296212482)
            
            //--TRIMMABLE-BOUNDARY-START(455267778562)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455267778562)
            
            //--TRIMMABLE-BOUNDARY-START(450972811266)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450972811266)
            
            //--TRIMMABLE-BOUNDARY-START(25771048962)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25771048962)
            
            //--TRIMMABLE-BOUNDARY-START(21476081666)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21476081666)
            
            //--TRIMMABLE-BOUNDARY-START(257699282946)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257699282946)
            
            //--TRIMMABLE-BOUNDARY-START(253404315650)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253404315650)
            
            //--TRIMMABLE-BOUNDARY-START(515397320706)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515397320706)
            
            //--TRIMMABLE-BOUNDARY-START(511102353410)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511102353410)
            
            //--TRIMMABLE-BOUNDARY-START(463857713154)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463857713154)
            
            //--TRIMMABLE-BOUNDARY-START(459562745858)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459562745858)
            
            //--TRIMMABLE-BOUNDARY-START(425203007490)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425203007490)
            
            //--TRIMMABLE-BOUNDARY-START(420908040194)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420908040194)
            
            //--TRIMMABLE-BOUNDARY-START(343598628866)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343598628866)
            
            //--TRIMMABLE-BOUNDARY-START(339303661570)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339303661570)
            
            //--TRIMMABLE-BOUNDARY-START(292059021314)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292059021314)
            
            //--TRIMMABLE-BOUNDARY-START(287764054018)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287764054018)
            
            //--TRIMMABLE-BOUNDARY-START(532577189890)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532577189890)
            
            //--TRIMMABLE-BOUNDARY-START(528282222594)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528282222594)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382253334530)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382253334530)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433792942082)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433792942082)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429497974786)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429497974786)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266289217538)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266289217538)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261994250242)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261994250242)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310656514)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77310656514)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015689218)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73015689218)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94490525698)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94490525698)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90195558402)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90195558402)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214749609986)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214749609986)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210454642690)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210454642690)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442382876674)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442382876674)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446677843970)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446677843970)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438087909378)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438087909378)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146030133250)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146030133250)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141735165954)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141735165954)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120260329474)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120260329474)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115965362178)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115965362178)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540852738)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51540852738)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245885442)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47245885442)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326418759682)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326418759682)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322123792386)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322123792386)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130787330)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60130787330)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835820034)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55835820034)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85900591106)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85900591106)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81605623810)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81605623810)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197569740802)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197569740802)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193274773506)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193274773506)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489627516930)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489627516930)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485332549634)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485332549634)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163210002434)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163210002434)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158915035138)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158915035138)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206159675394)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206159675394)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201864708098)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201864708098)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399433203714)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399433203714)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395138236418)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395138236418)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300648955906)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300648955906)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296353988610)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296353988610)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377958367234)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377958367234)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373663399938)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373663399938)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231929479170)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231929479170)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227634511874)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227634511874)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154620067842)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154620067842)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150325100546)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150325100546)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352188563458)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352188563458)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347893596162)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347893596162)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360778498050)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360778498050)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356483530754)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356483530754)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181114370)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17181114370)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886147074)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12886147074)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408023138306)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408023138306)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403728171010)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403728171010)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498217451522)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498217451522)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493922484226)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493922484226)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283469086722)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283469086722)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279174119426)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279174119426)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506807386114)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506807386114)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502512418818)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502512418818)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274879152130)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274879152130)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270584184834)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270584184834)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481037582338)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481037582338)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476742615042)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476742615042)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128850264066)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128850264066)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124555296770)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124555296770)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111670394882)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111670394882)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107375427586)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107375427586)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335008694274)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335008694274)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330713726978)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330713726978)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720721922)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68720721922)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425754626)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64425754626)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390843269122)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390843269122)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386548301826)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386548301826)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309238890498)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309238890498)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304943923202)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304943923202)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950918146)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42950918146)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655950850)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38655950850)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416613072898)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416613072898)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412318105602)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412318105602)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472447647746)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472447647746)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468152680450)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468152680450)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188979806210)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188979806210)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184684838914)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184684838914)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171799937026)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171799937026)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167504969730)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167504969730)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180389871618)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180389871618)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176094904322)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176094904322)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360983554)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34360983554)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30066016258)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30066016258)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137440198658)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137440198658)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133145231362)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133145231362)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103080460290)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103080460290)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98785492994)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98785492994)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523987255298)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523987255298)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519692288002)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519692288002)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369368432642)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369368432642)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365073465346)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365073465346)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223339544578)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223339544578)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219044577282)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219044577282)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249109348354)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249109348354)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236224446466)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236224446466)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244814381058)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244814381058)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240519413762)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240519413762)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317828825090)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317828825090)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313533857794)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313533857794)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591179778)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8591179778)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4296212482)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4296212482)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455267778562)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455267778562)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450972811266)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450972811266)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25771048962)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25771048962)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476081666)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21476081666)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257699282946)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257699282946)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253404315650)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253404315650)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515397320706)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515397320706)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511102353410)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511102353410)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463857713154)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463857713154)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459562745858)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459562745858)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425203007490)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425203007490)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420908040194)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420908040194)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343598628866)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343598628866)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339303661570)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339303661570)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292059021314)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292059021314)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287764054018)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287764054018)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532577189890)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532577189890)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528282222594)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528282222594)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 1245186;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(382253334530),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 1245186,
      "h": 382253334530,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382253334530),
//--TRIMMABLE-BOUNDARY-START(433792942082),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 1245186,
      "h": 433792942082,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433792942082),
//--TRIMMABLE-BOUNDARY-START(429497974786),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 1245186,
      "h": 429497974786,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429497974786),
//--TRIMMABLE-BOUNDARY-START(266289217538),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 1245186,
      "h": 266289217538,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266289217538),
//--TRIMMABLE-BOUNDARY-START(261994250242),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 1245186,
      "h": 261994250242,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261994250242),
//--TRIMMABLE-BOUNDARY-START(77310656514),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 1245186,
      "h": 77310656514,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77310656514),
//--TRIMMABLE-BOUNDARY-START(73015689218),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 1245186,
      "h": 73015689218,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73015689218),
//--TRIMMABLE-BOUNDARY-START(94490525698),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 1245186,
      "h": 94490525698,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94490525698),
//--TRIMMABLE-BOUNDARY-START(90195558402),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 1245186,
      "h": 90195558402,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90195558402),
//--TRIMMABLE-BOUNDARY-START(214749609986),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 1245186,
      "h": 214749609986,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214749609986),
//--TRIMMABLE-BOUNDARY-START(210454642690),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 1245186,
      "h": 210454642690,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210454642690),
//--TRIMMABLE-BOUNDARY-START(442382876674),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 1245186,
      "h": 442382876674,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442382876674),
//--TRIMMABLE-BOUNDARY-START(446677843970),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 1245186,
      "h": 446677843970,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446677843970),
//--TRIMMABLE-BOUNDARY-START(438087909378),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 1245186,
      "h": 438087909378,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438087909378),
//--TRIMMABLE-BOUNDARY-START(146030133250),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 1245186,
      "h": 146030133250,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146030133250),
//--TRIMMABLE-BOUNDARY-START(141735165954),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 1245186,
      "h": 141735165954,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141735165954),
//--TRIMMABLE-BOUNDARY-START(120260329474),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 1245186,
      "h": 120260329474,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120260329474),
//--TRIMMABLE-BOUNDARY-START(115965362178),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 1245186,
      "h": 115965362178,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115965362178),
//--TRIMMABLE-BOUNDARY-START(51540852738),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 1245186,
      "h": 51540852738,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51540852738),
//--TRIMMABLE-BOUNDARY-START(47245885442),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 1245186,
      "h": 47245885442,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47245885442),
//--TRIMMABLE-BOUNDARY-START(326418759682),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 1245186,
      "h": 326418759682,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326418759682),
//--TRIMMABLE-BOUNDARY-START(322123792386),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 1245186,
      "h": 322123792386,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322123792386),
//--TRIMMABLE-BOUNDARY-START(60130787330),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 1245186,
      "h": 60130787330,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60130787330),
//--TRIMMABLE-BOUNDARY-START(55835820034),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 1245186,
      "h": 55835820034,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55835820034),
//--TRIMMABLE-BOUNDARY-START(85900591106),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 1245186,
      "h": 85900591106,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85900591106),
//--TRIMMABLE-BOUNDARY-START(81605623810),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 1245186,
      "h": 81605623810,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81605623810),
//--TRIMMABLE-BOUNDARY-START(197569740802),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 1245186,
      "h": 197569740802,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197569740802),
//--TRIMMABLE-BOUNDARY-START(193274773506),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 1245186,
      "h": 193274773506,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193274773506),
//--TRIMMABLE-BOUNDARY-START(489627516930),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 1245186,
      "h": 489627516930,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489627516930),
//--TRIMMABLE-BOUNDARY-START(485332549634),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 1245186,
      "h": 485332549634,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485332549634),
//--TRIMMABLE-BOUNDARY-START(163210002434),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 1245186,
      "h": 163210002434,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163210002434),
//--TRIMMABLE-BOUNDARY-START(158915035138),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 1245186,
      "h": 158915035138,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158915035138),
//--TRIMMABLE-BOUNDARY-START(206159675394),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 1245186,
      "h": 206159675394,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206159675394),
//--TRIMMABLE-BOUNDARY-START(201864708098),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 1245186,
      "h": 201864708098,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201864708098),
//--TRIMMABLE-BOUNDARY-START(399433203714),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 1245186,
      "h": 399433203714,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399433203714),
//--TRIMMABLE-BOUNDARY-START(395138236418),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 1245186,
      "h": 395138236418,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395138236418),
//--TRIMMABLE-BOUNDARY-START(300648955906),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 1245186,
      "h": 300648955906,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300648955906),
//--TRIMMABLE-BOUNDARY-START(296353988610),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 1245186,
      "h": 296353988610,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296353988610),
//--TRIMMABLE-BOUNDARY-START(377958367234),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 1245186,
      "h": 377958367234,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377958367234),
//--TRIMMABLE-BOUNDARY-START(373663399938),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 1245186,
      "h": 373663399938,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373663399938),
//--TRIMMABLE-BOUNDARY-START(231929479170),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 1245186,
      "h": 231929479170,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231929479170),
//--TRIMMABLE-BOUNDARY-START(227634511874),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 1245186,
      "h": 227634511874,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227634511874),
//--TRIMMABLE-BOUNDARY-START(154620067842),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 1245186,
      "h": 154620067842,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154620067842),
//--TRIMMABLE-BOUNDARY-START(150325100546),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 1245186,
      "h": 150325100546,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150325100546),
//--TRIMMABLE-BOUNDARY-START(352188563458),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 1245186,
      "h": 352188563458,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352188563458),
//--TRIMMABLE-BOUNDARY-START(347893596162),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 1245186,
      "h": 347893596162,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347893596162),
//--TRIMMABLE-BOUNDARY-START(360778498050),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 1245186,
      "h": 360778498050,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360778498050),
//--TRIMMABLE-BOUNDARY-START(356483530754),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 1245186,
      "h": 356483530754,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356483530754),
//--TRIMMABLE-BOUNDARY-START(17181114370),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 1245186,
      "h": 17181114370,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17181114370),
//--TRIMMABLE-BOUNDARY-START(12886147074),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 1245186,
      "h": 12886147074,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12886147074),
//--TRIMMABLE-BOUNDARY-START(408023138306),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 1245186,
      "h": 408023138306,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408023138306),
//--TRIMMABLE-BOUNDARY-START(403728171010),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 1245186,
      "h": 403728171010,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403728171010),
//--TRIMMABLE-BOUNDARY-START(498217451522),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 1245186,
      "h": 498217451522,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498217451522),
//--TRIMMABLE-BOUNDARY-START(493922484226),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 1245186,
      "h": 493922484226,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493922484226),
//--TRIMMABLE-BOUNDARY-START(283469086722),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 1245186,
      "h": 283469086722,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283469086722),
//--TRIMMABLE-BOUNDARY-START(279174119426),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 1245186,
      "h": 279174119426,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279174119426),
//--TRIMMABLE-BOUNDARY-START(506807386114),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 1245186,
      "h": 506807386114,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506807386114),
//--TRIMMABLE-BOUNDARY-START(502512418818),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 1245186,
      "h": 502512418818,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502512418818),
//--TRIMMABLE-BOUNDARY-START(274879152130),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 1245186,
      "h": 274879152130,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274879152130),
//--TRIMMABLE-BOUNDARY-START(270584184834),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 1245186,
      "h": 270584184834,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270584184834),
//--TRIMMABLE-BOUNDARY-START(481037582338),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 1245186,
      "h": 481037582338,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481037582338),
//--TRIMMABLE-BOUNDARY-START(476742615042),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 1245186,
      "h": 476742615042,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476742615042),
//--TRIMMABLE-BOUNDARY-START(128850264066),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 1245186,
      "h": 128850264066,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128850264066),
//--TRIMMABLE-BOUNDARY-START(124555296770),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 1245186,
      "h": 124555296770,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124555296770),
//--TRIMMABLE-BOUNDARY-START(111670394882),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 1245186,
      "h": 111670394882,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111670394882),
//--TRIMMABLE-BOUNDARY-START(107375427586),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 1245186,
      "h": 107375427586,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107375427586),
//--TRIMMABLE-BOUNDARY-START(335008694274),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 1245186,
      "h": 335008694274,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335008694274),
//--TRIMMABLE-BOUNDARY-START(330713726978),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 1245186,
      "h": 330713726978,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330713726978),
//--TRIMMABLE-BOUNDARY-START(68720721922),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 1245186,
      "h": 68720721922,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68720721922),
//--TRIMMABLE-BOUNDARY-START(64425754626),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 1245186,
      "h": 64425754626,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64425754626),
//--TRIMMABLE-BOUNDARY-START(390843269122),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 1245186,
      "h": 390843269122,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390843269122),
//--TRIMMABLE-BOUNDARY-START(386548301826),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 1245186,
      "h": 386548301826,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386548301826),
//--TRIMMABLE-BOUNDARY-START(309238890498),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 1245186,
      "h": 309238890498,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309238890498),
//--TRIMMABLE-BOUNDARY-START(304943923202),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 1245186,
      "h": 304943923202,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304943923202),
//--TRIMMABLE-BOUNDARY-START(42950918146),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 1245186,
      "h": 42950918146,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42950918146),
//--TRIMMABLE-BOUNDARY-START(38655950850),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 1245186,
      "h": 38655950850,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38655950850),
//--TRIMMABLE-BOUNDARY-START(416613072898),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 1245186,
      "h": 416613072898,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416613072898),
//--TRIMMABLE-BOUNDARY-START(412318105602),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 1245186,
      "h": 412318105602,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412318105602),
//--TRIMMABLE-BOUNDARY-START(472447647746),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 1245186,
      "h": 472447647746,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472447647746),
//--TRIMMABLE-BOUNDARY-START(468152680450),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 1245186,
      "h": 468152680450,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468152680450),
//--TRIMMABLE-BOUNDARY-START(188979806210),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 1245186,
      "h": 188979806210,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188979806210),
//--TRIMMABLE-BOUNDARY-START(184684838914),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 1245186,
      "h": 184684838914,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184684838914),
//--TRIMMABLE-BOUNDARY-START(171799937026),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 1245186,
      "h": 171799937026,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171799937026),
//--TRIMMABLE-BOUNDARY-START(167504969730),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 1245186,
      "h": 167504969730,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167504969730),
//--TRIMMABLE-BOUNDARY-START(180389871618),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 1245186,
      "h": 180389871618,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180389871618),
//--TRIMMABLE-BOUNDARY-START(176094904322),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 1245186,
      "h": 176094904322,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176094904322),
//--TRIMMABLE-BOUNDARY-START(34360983554),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 1245186,
      "h": 34360983554,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360983554),
//--TRIMMABLE-BOUNDARY-START(30066016258),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 1245186,
      "h": 30066016258,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30066016258),
//--TRIMMABLE-BOUNDARY-START(137440198658),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 1245186,
      "h": 137440198658,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137440198658),
//--TRIMMABLE-BOUNDARY-START(133145231362),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 1245186,
      "h": 133145231362,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133145231362),
//--TRIMMABLE-BOUNDARY-START(103080460290),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 1245186,
      "h": 103080460290,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103080460290),
//--TRIMMABLE-BOUNDARY-START(98785492994),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 1245186,
      "h": 98785492994,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98785492994),
//--TRIMMABLE-BOUNDARY-START(523987255298),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 1245186,
      "h": 523987255298,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523987255298),
//--TRIMMABLE-BOUNDARY-START(519692288002),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 1245186,
      "h": 519692288002,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519692288002),
//--TRIMMABLE-BOUNDARY-START(369368432642),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 1245186,
      "h": 369368432642,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369368432642),
//--TRIMMABLE-BOUNDARY-START(365073465346),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 1245186,
      "h": 365073465346,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365073465346),
//--TRIMMABLE-BOUNDARY-START(223339544578),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 1245186,
      "h": 223339544578,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223339544578),
//--TRIMMABLE-BOUNDARY-START(219044577282),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 1245186,
      "h": 219044577282,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219044577282),
//--TRIMMABLE-BOUNDARY-START(249109348354),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 1245186,
      "h": 249109348354,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249109348354),
//--TRIMMABLE-BOUNDARY-START(236224446466),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 1245186,
      "h": 236224446466,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236224446466),
//--TRIMMABLE-BOUNDARY-START(244814381058),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 1245186,
      "h": 244814381058,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244814381058),
//--TRIMMABLE-BOUNDARY-START(240519413762),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 1245186,
      "h": 240519413762,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240519413762),
//--TRIMMABLE-BOUNDARY-START(317828825090),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 1245186,
      "h": 317828825090,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317828825090),
//--TRIMMABLE-BOUNDARY-START(313533857794),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 1245186,
      "h": 313533857794,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313533857794),
//--TRIMMABLE-BOUNDARY-START(8591179778),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 1245186,
      "h": 8591179778,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8591179778),
//--TRIMMABLE-BOUNDARY-START(4296212482),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 1245186,
      "h": 4296212482,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4296212482),
//--TRIMMABLE-BOUNDARY-START(455267778562),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 1245186,
      "h": 455267778562,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455267778562),
//--TRIMMABLE-BOUNDARY-START(450972811266),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 1245186,
      "h": 450972811266,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450972811266),
//--TRIMMABLE-BOUNDARY-START(25771048962),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 1245186,
      "h": 25771048962,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25771048962),
//--TRIMMABLE-BOUNDARY-START(21476081666),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 1245186,
      "h": 21476081666,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21476081666),
//--TRIMMABLE-BOUNDARY-START(257699282946),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 1245186,
      "h": 257699282946,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257699282946),
//--TRIMMABLE-BOUNDARY-START(253404315650),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 1245186,
      "h": 253404315650,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253404315650),
//--TRIMMABLE-BOUNDARY-START(515397320706),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 1245186,
      "h": 515397320706,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515397320706),
//--TRIMMABLE-BOUNDARY-START(511102353410),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 1245186,
      "h": 511102353410,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511102353410),
//--TRIMMABLE-BOUNDARY-START(463857713154),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 1245186,
      "h": 463857713154,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463857713154),
//--TRIMMABLE-BOUNDARY-START(459562745858),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 1245186,
      "h": 459562745858,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459562745858),
//--TRIMMABLE-BOUNDARY-START(425203007490),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 1245186,
      "h": 425203007490,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425203007490),
//--TRIMMABLE-BOUNDARY-START(420908040194),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 1245186,
      "h": 420908040194,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420908040194),
//--TRIMMABLE-BOUNDARY-START(343598628866),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 1245186,
      "h": 343598628866,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343598628866),
//--TRIMMABLE-BOUNDARY-START(339303661570),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 1245186,
      "h": 339303661570,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339303661570),
//--TRIMMABLE-BOUNDARY-START(292059021314),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 1245186,
      "h": 292059021314,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292059021314),
//--TRIMMABLE-BOUNDARY-START(287764054018),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 1245186,
      "h": 287764054018,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287764054018),
//--TRIMMABLE-BOUNDARY-START(532577189890),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 1245186,
      "h": 532577189890,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532577189890),
//--TRIMMABLE-BOUNDARY-START(528282222594),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 1245186,
      "h": 528282222594,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528282222594)
  ],
  "h": 1245186
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245186)
        
        
        //--TRIMMABLE-BOUNDARY-START(786434)
        $asm.$cls("$spu.System.IriHelper", ($self) => class IriHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4295753730)
            static /*bool */ CheckIriUnicodeRange(/*char*/ unicode, /*bool*/ isQuery)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295753730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spu.System.IriHelper.IsInInclusiveRange(unicode, /*\u00A0*/ 160, /*\uD7FF*/ 55295) || $.$spu.System.IriHelper.IsInInclusiveRange(unicode, /*\uF900*/ 63744, /*\uFDCF*/ 64975) || $.$spu.System.IriHelper.IsInInclusiveRange(unicode, /*\uFDF0*/ 65008, /*\uFFEF*/ 65519) || (isQuery && $.$spu.System.IriHelper.IsInInclusiveRange(unicode, /*\uE000*/ 57344, /*\uF8FF*/ 63743));
            }
            //--TRIMMABLE-BOUNDARY-END(4295753730)
            
            //--TRIMMABLE-BOUNDARY-START(8590721026)
            static /*bool */ CheckIriUnicodeRange$1(/*char*/ highSurr, /*char*/ lowSurr, /*out bool*/ isSurrogatePair, /*bool*/ isQuery)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590721026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Char.IsHighSurrogate(highSurr), "char.IsHighSurrogate(highSurr)");
                /*Rune*/ let rune;
                if ($.$$.System.Text.Rune.TryCreate(highSurr, lowSurr, $.$ref(() => rune, ($v) => rune = $v, $.$$.System.Text.Rune)))
                {
                    isSurrogatePair.$v = true;
                    return ((rune.Value & 65535) < 65534) && (((((rune.Value - 917504) | 0)) >>> 0) >= (((921600 - 917504) | 0))) && (isQuery || rune.Value < 983040);
                }
                isSurrogatePair.$v = false;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721026)
            
            //--TRIMMABLE-BOUNDARY-START(12885688322)
            static /*bool */ CheckIriUnicodeRange$2(/*uint*/ value, /*bool*/ isQuery)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value <= 65535)
                {
                    return $.$spu.System.IriHelper.IsInInclusiveRange(value, /*\u00A0*/ 160, /*\uD7FF*/ 55295) || $.$spu.System.IriHelper.IsInInclusiveRange(value, /*\uF900*/ 63744, /*\uFDCF*/ 64975) || $.$spu.System.IriHelper.IsInInclusiveRange(value, /*\uFDF0*/ 65008, /*\uFFEF*/ 65519) || (isQuery && $.$spu.System.IriHelper.IsInInclusiveRange(value, /*\uE000*/ 57344, /*\uF8FF*/ 63743));
                }
                else 
                {
                    return ((value & 65535) < 65534) && !$.$spu.System.IriHelper.IsInInclusiveRange(value, 917504, 921599) && (isQuery || value < 983040);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885688322)
            
            //--TRIMMABLE-BOUNDARY-START(25770590210)
            static /*bool */ IsInInclusiveRange(/*uint*/ value, /*uint*/ min, /*uint*/ max)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770590210);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ((((value - min) >>> 0)) >>> 0) <= ((((max - min) >>> 0)) >>> 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770590210)
            
            //--TRIMMABLE-BOUNDARY-START(17180655618)
            static /*bool */ CheckIsReserved(/*char*/ ch, /*UriComponents*/ component)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((127/*UriComponents.AbsoluteUri*/ & component) === 0)
                {
                    return component === 0 && $.$spu.System.UriHelper.IsGenDelim(ch);
                }
                return $.$$.System.String.Contains$1.call(";/?:@&=+$,#[]!'()*"/*UriHelper.RFC3986ReservedMarks*/, ch);
            }
            //--TRIMMABLE-BOUNDARY-END(17180655618)
            
            //--TRIMMABLE-BOUNDARY-START(21475622914)
            static /*string */ EscapeUnescapeIri(/*char**/ pInput, /*int*/ start, /*int*/ end, /*UriComponents*/ component)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475622914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(end >= 0 && start >= 0 && start <= end, "end >= 0 && start >= 0 && start <= end");
                /*int*/ let size = ((end - start) | 0);
                /*var*/ let dest = size <= 512/*Uri.StackallocThreshold*/ ? new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*Uri.StackallocThreshold*/, null)) : new $.$spu.System.Text.ValueStringBuilder().$ctor$3(size);
                /*Span<byte>*/ let maxUtf8EncodedSpan = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 4, null);
                for(/*int*/ let i = start; i < end; ++i)
                {
                    /*char*/ let ch = pInput.GetAt(i);
                    if (ch === /*%*/ 37)
                    {
                        if (((end - i) | 0) > 2)
                        {
                            ch = $.$spu.System.UriHelper.DecodeHexChars(pInput.GetAt(((i + 1) | 0)), pInput.GetAt(((i + 2) | 0)));
                            if (ch === /*\uFFFF*/ 65535 || ch === /*%*/ 37 || $.$spu.System.IriHelper.CheckIsReserved(ch, component) || $.$spu.System.UriHelper.IsNotSafeForUnescape(ch))
                            {
                                dest.Append$1(pInput.GetAt(i++));
                                dest.Append$1(pInput.GetAt(i++));
                                dest.Append$1(pInput.GetAt(i));
                                continue;
                            }
                            else if (ch <= /*\u007F*/ 127)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(ch < 255, "Expecting ASCII character.");
                                dest.Append$1(ch);
                                i += 2;
                                continue;
                            }
                            else 
                            {
                                /*int*/ let charactersRead = $.$spu.System.PercentEncodingHelper.UnescapePercentEncodedUTF8Sequence(pInput.Add(i), ((end - i) | 0), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null), component === 32/*UriComponents.Query*/, true);
                                $.$$.System.Diagnostics.Debug.Assert$2(charactersRead > 0, "charactersRead > 0");
                                i += ((charactersRead - 1) | 0);
                            }
                        }
                        else 
                        {
                            dest.Append$1(pInput.GetAt(i));
                        }
                    }
                    else if (ch > /*\u007F*/ 127)
                    {
                        /*bool*/ let isInIriUnicodeRange;
                        /*bool*/ let surrogatePair = false;
                        /*char*/ let ch2 = /*\u0000*/ 0;
                        if (($.$$.System.Char.IsHighSurrogate(ch)) && (((i + 1) | 0) < end))
                        {
                            ch2 = pInput.GetAt(((i + 1) | 0));
                            isInIriUnicodeRange = $.$spu.System.IriHelper.CheckIriUnicodeRange$1(ch, ch2, $.$ref(() => surrogatePair, ($v) => surrogatePair = $v, $.$$.System.Boolean), component === 32/*UriComponents.Query*/);
                        }
                        else 
                        {
                            isInIriUnicodeRange = $.$spu.System.IriHelper.CheckIriUnicodeRange(ch, component === 32/*UriComponents.Query*/);
                        }
                        if (isInIriUnicodeRange)
                        {
                            dest.Append$1(ch);
                            if (surrogatePair)
                            {
                                dest.Append$1(ch2);
                            }
                        }
                        else 
                        {
                            /*Rune*/ let rune;
                            if (surrogatePair)
                            {
                                rune = new $.$$.System.Text.Rune().$ctor$3(ch, ch2);
                            }
                            else if (!$.$$.System.Text.Rune.TryCreate$1(ch, $.$ref(() => rune, ($v) => rune = $v, $.$$.System.Text.Rune)))
                            {
                                rune = $.$$.System.Text.Rune.ReplacementChar;
                            }
                            /*int*/ let bytesWritten = rune.EncodeToUtf8(maxUtf8EncodedSpan);
                            /*ReadOnlySpan<byte>*/ let encodedBytes = $.$$.System.Span$$($.$$.System.Byte).op_Implicit(maxUtf8EncodedSpan.Slice(0, bytesWritten));
                            var $en5 = encodedBytes.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var b = $en5.Current.$v;
                                {
                                    $.$spu.System.UriHelper.PercentEncodeByte(b, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null));
                                }
                            }
                        }
                        if (surrogatePair)
                        {
                            i++;
                        }
                    }
                    else 
                    {
                        dest.Append$1(pInput.GetAt(i));
                    }
                }
                return $.$spu.System.Text.ValueStringBuilder.ToString.call(dest);
            }
            //--TRIMMABLE-BOUNDARY-END(21475622914)
            
            static $h = 786434;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295753730),
    {
      "r": 262145,
      "p": [
        {
          "n": "unicode",
          "p": 458753
        },
        {
          "n": "isQuery",
          "p": 262145
        }
      ],
      "n": "CheckIriUnicodeRange",
      "d": 786434,
      "h": 4295753730,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295753730),
//--TRIMMABLE-BOUNDARY-START(8590721026),
    {
      "r": 262145,
      "p": [
        {
          "n": "highSurr",
          "p": 458753
        },
        {
          "n": "lowSurr",
          "p": 458753
        },
        {
          "n": "isSurrogatePair",
          "p": 262145,
          "f": 2
        },
        {
          "n": "isQuery",
          "p": 262145
        }
      ],
      "n": "CheckIriUnicodeRange",
      "o": "@$1",
      "d": 786434,
      "h": 8590721026,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590721026),
//--TRIMMABLE-BOUNDARY-START(12885688322),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 720897
        },
        {
          "n": "isQuery",
          "p": 262145
        }
      ],
      "n": "CheckIriUnicodeRange",
      "o": "@$2",
      "d": 786434,
      "h": 12885688322,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885688322),
//--TRIMMABLE-BOUNDARY-START(25770590210),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 720897
        },
        {
          "n": "min",
          "p": 720897
        },
        {
          "n": "max",
          "p": 720897
        }
      ],
      "n": "IsInInclusiveRange",
      "d": 786434,
      "h": 25770590210,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770590210),
//--TRIMMABLE-BOUNDARY-START(17180655618),
    {
      "r": 262145,
      "p": [
        {
          "n": "ch",
          "p": 458753
        },
        {
          "n": "component",
          "p": 2162690
        }
      ],
      "n": "CheckIsReserved",
      "d": 786434,
      "h": 17180655618,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180655618),
//--TRIMMABLE-BOUNDARY-START(21475622914),
    {
      "r": 1310721,
      "p": [
        {
          "n": "pInput",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        },
        {
          "n": "component",
          "p": 2162690
        }
      ],
      "n": "EscapeUnescapeIri",
      "d": 786434,
      "h": 21475622914,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21475622914)
  ],
  "h": 786434
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IriHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786434)
        
        
        //--TRIMMABLE-BOUNDARY-START(983042)
        $asm.$cls("$spu.System.Net.IPv6AddressHelper", ($self) => class IPv6AddressHelper
        {
            //--TRIMMABLE-BOUNDARY-START(8590917634)
            /*int*/ static Hex = 16;
            //--TRIMMABLE-BOUNDARY-END(8590917634)
            
            //--TRIMMABLE-BOUNDARY-START(30065754114)
            /*int*/ static NumberOfLabels = 8;
            //--TRIMMABLE-BOUNDARY-END(30065754114)
            
            //--TRIMMABLE-BOUNDARY-START(4295950338)
            static /*(int longestSequenceStart, int longestSequenceLength) */ FindCompressionRange(/*ReadOnlySpan<ushort>*/ numbers)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let longestSequenceLength = 0, longestSequenceStart = -1, currentSequenceLength = 0;
                for(/*int*/ let i = 0; i < numbers.Length; i++)
                {
                    if (numbers.get_Item(i).$v === 0)
                    {
                        currentSequenceLength++;
                        if (currentSequenceLength > longestSequenceLength)
                        {
                            longestSequenceLength = currentSequenceLength;
                            longestSequenceStart = ((((i - currentSequenceLength) | 0) + 1) | 0);
                        }
                    }
                    else 
                    {
                        currentSequenceLength = 0;
                    }
                }
                return longestSequenceLength > 1 ? new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(longestSequenceStart, ((longestSequenceStart + longestSequenceLength) | 0)) : new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(-1, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(4295950338)
            
            //--TRIMMABLE-BOUNDARY-START(42950656002)
            static /*bool */ ShouldHaveIpv4Embedded(/*ReadOnlySpan<ushort>*/ numbers)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (numbers.get_Item(0).$v === 0 && numbers.get_Item(1).$v === 0 && numbers.get_Item(2).$v === 0 && numbers.get_Item(3).$v === 0 && numbers.get_Item(6).$v !== 0)
                {
                    if (numbers.get_Item(4).$v === 0 && (numbers.get_Item(5).$v === 0 || numbers.get_Item(5).$v === 65535))
                    {
                        return true;
                    }
                    else if (numbers.get_Item(4).$v === 65535 && numbers.get_Item(5).$v === 0)
                    {
                        return true;
                    }
                }
                return numbers.get_Item(4).$v === 0 && numbers.get_Item(5).$v === 24318;
            }
            //--TRIMMABLE-BOUNDARY-END(42950656002)
            
            //--TRIMMABLE-BOUNDARY-START(25770786818)
            static /*bool */ IsValidStrict(TChar, /*TChar**/ name, /*int*/ start, /*int*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770786818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let sequenceCount = 0;
                /*int*/ let sequenceLength = 0;
                /*bool*/ let haveCompressor = false;
                /*bool*/ let haveIPv4Address = false;
                /*bool*/ let expectingNumber = true;
                /*int*/ let lastSequence = 1;
                /*bool*/ let needsClosingBracket = false;
                if (start < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(start), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*[*/ 91)))
                {
                    start++;
                    needsClosingBracket = true;
                    $.$$.System.Diagnostics.Debug.Assert$2(start < end, "start < end");
                }
                if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(start), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58)) && (((start + 1) | 0) >= end || TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(name.GetAt(((start + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58))))
                {
                    return false;
                }
                /*int*/ let i;
                for(i = start; i < end; ++i)
                {
                    /*int*/ let currentCh = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i));
                    if ($.$spu.System.HexConverter.IsHexChar(currentCh))
                    {
                        ++sequenceLength;
                        expectingNumber = false;
                    }
                    else 
                    {
                        if (sequenceLength > 4)
                        {
                            return false;
                        }
                        if (sequenceLength !== 0)
                        {
                            ++sequenceCount;
                            lastSequence = ((i - sequenceLength) | 0);
                            sequenceLength = 0;
                        }
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? currentCh)
                            {
                                case /*%*/ 37:
                                while(((i + 1) | 0) < end)
                                {
                                    i++;
                                    if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(i), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)))
                                    {
                                        $switchJumpState1 = /*]*/ 93; /*goto case ']'*/
                                        continue $switchJumpStart1;
                                    }
                                    else if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(i), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*/*/ 47)))
                                    {
                                        $switchJumpState1 = /*/*/ 47; /*goto case '/'*/
                                        continue $switchJumpStart1;
                                    }
                                }
                                break;
                                case /*]*/ 93:
                                if (!needsClosingBracket)
                                {
                                    return false;
                                }
                                needsClosingBracket = false;
                                if (((i + 1) | 0) < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(name.GetAt(((i + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58)))
                                {
                                    return false;
                                }
                                if (((i + 3) | 0) < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i + 2) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*0*/ 48)) && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i + 3) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*x*/ 120)))
                                {
                                    i += 4;
                                    for(; i < end; i++)
                                    {
                                        /*int*/ let ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i));
                                        if (!$.$spu.System.HexConverter.IsHexChar(ch))
                                        {
                                            return false;
                                        }
                                    }
                                }
                                else 
                                {
                                    i += 2;
                                    for(; i < end; i++)
                                    {
                                        if (!$.$$.System.Char.IsAsciiDigit($.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i))))
                                        {
                                            return false;
                                        }
                                    }
                                }
                                continue;
                                case /*:*/ 58:
                                if ((i > 0) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i - 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58))))
                                {
                                    if (haveCompressor)
                                    {
                                        return false;
                                    }
                                    haveCompressor = true;
                                    expectingNumber = false;
                                }
                                else 
                                {
                                    expectingNumber = true;
                                }
                                break;
                                case /*/*/ 47:
                                return false;
                                case /*.*/ 46:
                                if (haveIPv4Address)
                                {
                                    return false;
                                }
                                i = end;
                                if (!$.$spu.System.Net.IPv4AddressHelper.IsValid(TChar, name, lastSequence, $.$ref(() => i, ($v) => i = $v, $.$$.System.Int32), true, false, false))
                                {
                                    return false;
                                }
                                ++sequenceCount;
                                lastSequence = ((i - sequenceLength) | 0);
                                sequenceLength = 0;
                                haveIPv4Address = true;
                                --i;
                                break;
                                default:
                                return false;
                            }
                            break;
                        }
                        sequenceLength = 0;
                    }
                }
                if (sequenceLength !== 0)
                {
                    if (sequenceLength > 4)
                    {
                        return false;
                    }
                    ++sequenceCount;
                }
                /*int*/ let ExpectedSequenceCount = 8;
                return !expectingNumber && (haveCompressor ? (sequenceCount < ExpectedSequenceCount) : (sequenceCount === ExpectedSequenceCount)) && !needsClosingBracket;
            }
            //--TRIMMABLE-BOUNDARY-END(25770786818)
            
            //--TRIMMABLE-BOUNDARY-START(34360721410)
            static /*void */ Parse(TChar, /*ReadOnlySpan<TChar>*/ address, /*scoped Span<ushort>*/ numbers, /*out ReadOnlySpan<TChar>*/ scopeId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360721410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let number = 0;
                /*int*/ let currentCh;
                /*int*/ let index = 0;
                /*int*/ let compressorIndex = -1;
                /*bool*/ let numberIsValid = true;
                scopeId.$v = $.$$.System.ReadOnlySpan$$(TChar).Empty;
                for(/*int*/ let i = (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(0).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*[*/ 91)) ? 1 : 0); i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)); )
                {
                    currentCh = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, address.get_Item(i).$v);
                    switch(currentCh)
                    {
                        case /*%*/ 37:
                        if (numberIsValid)
                        {
                            numbers.get_Item(index++).$v = $.$cast(number, $.$$.System.UInt16);
                            numberIsValid = false;
                        }
                        /*int*/ let scopeStart = i;
                        for(++i; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)) && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*/*/ 47)); ++i)
                        {
                        }
                        scopeId.$v = address.Slice(scopeStart, ((i - scopeStart) | 0));
                        for(; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)); ++i)
                        {
                        }
                        break;
                        case /*:*/ 58:
                        numbers.get_Item(index++).$v = $.$cast(number, $.$$.System.UInt16);
                        number = 0;
                        ++i;
                        if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58)))
                        {
                            compressorIndex = index;
                            ++i;
                        }
                        else if ((compressorIndex < 0) && (index < 6))
                        {
                            break;
                        }
                        for(/*int*/ let j = i; j < address.Length && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*%*/ 37))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*/*/ 47))) && (j < ((i + 4) | 0)); ++j)
                        {
                            if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*.*/ 46)))
                            {
                                while(j < address.Length && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*/*/ 47))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*%*/ 37))))
                                {
                                    ++j;
                                }
                                /*int*/ let ipv4Address = $.$spu.System.Net.IPv4AddressHelper.ParseHostNumber(TChar, address, i, j);
                                numbers.get_Item(index++).$v = $.$cast((ipv4Address >> 16), $.$$.System.UInt16);
                                numbers.get_Item(index++).$v = $.$cast((ipv4Address & 65535), $.$$.System.UInt16);
                                i = j;
                                number = 0;
                                numberIsValid = false;
                                break;
                            }
                        }
                        break;
                        case /*/*/ 47:
                        if (numberIsValid)
                        {
                            numbers.get_Item(index++).$v = $.$cast(number, $.$$.System.UInt16);
                            numberIsValid = false;
                        }
                        for(++i; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)); i++)
                        {
                        }
                        break;
                        default:
                        /*int*/ let characterValue = $.$spu.System.HexConverter.FromChar(currentCh);
                        number = ((((number * 16/*IPv6AddressHelper.Hex*/) | 0) + characterValue) | 0);
                        i++;
                        break;
                    }
                }
                if (numberIsValid)
                {
                    numbers.get_Item(index++).$v = $.$cast(number, $.$$.System.UInt16);
                }
                if (compressorIndex > 0)
                {
                    /*int*/ let toIndex = ((8/*NumberOfLabels*/ - 1) | 0);
                    /*int*/ let fromIndex = ((index - 1) | 0);
                    if (fromIndex !== toIndex)
                    {
                        for(/*int*/ let i = ((index - compressorIndex) | 0); i > 0; --i)
                        {
                            numbers.get_Item(toIndex--).$v = numbers.get_Item(fromIndex).$v;
                            numbers.get_Item(fromIndex--).$v = 0;
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360721410)
            
            //--TRIMMABLE-BOUNDARY-START(38655688706)
            static /*string */ ParseCanonicalName(/*ReadOnlySpan<char>*/ str, /*ref bool*/ isLoopback, /*out ReadOnlySpan<char>*/ scopeId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655688706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Span<ushort>*/ let numbers = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.UInt16, 8/*NumberOfLabels*/, null);
                numbers.Clear();
                $.$spu.System.Net.IPv6AddressHelper.Parse($.$$.System.Char, str, numbers, scopeId);
                isLoopback.$v = $.$spu.System.Net.IPv6AddressHelper.IsLoopback($.$$.System.Span$$($.$$.System.UInt16).op_Implicit(numbers));
                const { Item1: rangeStart, Item2: rangeEnd } = $.$spu.System.Net.IPv6AddressHelper.FindCompressionRange($.$$.System.Span$$($.$$.System.UInt16).op_Implicit(numbers));
                /*bool*/ let ipv4Embedded = $.$spu.System.Net.IPv6AddressHelper.ShouldHaveIpv4Embedded($.$$.System.Span$$($.$$.System.UInt16).op_Implicit(numbers));
                /*Span<char>*/ let stackSpace = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 48, null);
                stackSpace.get_Item(0).$v = /*[*/ 91;
                /*int*/ let pos = 1;
                /*int*/ let charsWritten;
                /*bool*/ let success;
                for(/*int*/ let i = 0; i < 8/*NumberOfLabels*/; i++)
                {
                    if (ipv4Embedded && i === (((8/*NumberOfLabels*/ - 2) | 0)))
                    {
                        stackSpace.get_Item(pos++).$v = /*:*/ 58;
                        success = $.$$.System.Int32.TryFormat$1.call((numbers.get_Item(i).$v >>> 8), stackSpace.Slice$1(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                        $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                        pos += charsWritten;
                        stackSpace.get_Item(pos++).$v = /*.*/ 46;
                        success = $.$$.System.Int32.TryFormat$1.call((numbers.get_Item(i).$v & 255), stackSpace.Slice$1(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                        $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                        pos += charsWritten;
                        stackSpace.get_Item(pos++).$v = /*.*/ 46;
                        success = $.$$.System.Int32.TryFormat$1.call((numbers.get_Item(((i + 1) | 0)).$v >>> 8), stackSpace.Slice$1(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                        $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                        pos += charsWritten;
                        stackSpace.get_Item(pos++).$v = /*.*/ 46;
                        success = $.$$.System.Int32.TryFormat$1.call((numbers.get_Item(((i + 1) | 0)).$v & 255), stackSpace.Slice$1(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                        $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                        pos += charsWritten;
                        break;
                    }
                    if (rangeStart === i)
                    {
                        stackSpace.get_Item(pos++).$v = /*:*/ 58;
                    }
                    if (rangeStart <= i && rangeEnd === 8/*NumberOfLabels*/)
                    {
                        stackSpace.get_Item(pos++).$v = /*:*/ 58;
                        break;
                    }
                    if (rangeStart <= i && i < rangeEnd)
                    {
                        continue;
                    }
                    if (i !== 0)
                    {
                        stackSpace.get_Item(pos++).$v = /*:*/ 58;
                    }
                    success = $.$$.System.UInt16.TryFormat$1.call(numbers.get_Item(i).$v, stackSpace.Slice$1(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), $.$$.System.String.op_Implicit("x"), null);
                    $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                    pos += charsWritten;
                }
                stackSpace.get_Item(pos++).$v = /*]*/ 93;
                return $.$$.System.String.Create$2($.$$.System.Span$$($.$$.System.Char).op_Implicit(stackSpace.Slice(0, pos)));
            }
            //--TRIMMABLE-BOUNDARY-END(38655688706)
            
            //--TRIMMABLE-BOUNDARY-START(17180852226)
            static /*bool */ IsLoopback(/*ReadOnlySpan<ushort>*/ numbers)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180852226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ((numbers.get_Item(0).$v === 0) && (numbers.get_Item(1).$v === 0) && (numbers.get_Item(2).$v === 0) && (numbers.get_Item(3).$v === 0) && (numbers.get_Item(4).$v === 0)) && (((numbers.get_Item(5).$v === 0) && (numbers.get_Item(6).$v === 0) && (numbers.get_Item(7).$v === 1)) || (((numbers.get_Item(6).$v === 32512) && (numbers.get_Item(7).$v === 1)) && ((numbers.get_Item(5).$v === 0) || (numbers.get_Item(5).$v === 65535))));
            }
            //--TRIMMABLE-BOUNDARY-END(17180852226)
            
            //--TRIMMABLE-BOUNDARY-START(12885884930)
            static /*bool */ InternalIsValid(/*char**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ validateStrictAddress)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885884930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let sequenceCount = 0;
                /*int*/ let sequenceLength = 0;
                /*bool*/ let haveCompressor = false;
                /*bool*/ let haveIPv4Address = false;
                /*bool*/ let havePrefix = false;
                /*bool*/ let expectingNumber = true;
                /*int*/ let lastSequence = 1;
                if (name.GetAt(start) === /*:*/ 58 && (((start + 1) | 0) >= end.$v || name.GetAt(((start + 1) | 0)) !== /*:*/ 58))
                {
                    return false;
                }
                /*int*/ let i;
                for(i = start; i < end.$v; ++i)
                {
                    if (havePrefix ? $.$$.System.Char.IsAsciiDigit(name.GetAt(i)) : $.$$.System.Char.IsAsciiHexDigit(name.GetAt(i)))
                    {
                        ++sequenceLength;
                        expectingNumber = false;
                    }
                    else 
                    {
                        if (sequenceLength > 4)
                        {
                            return false;
                        }
                        if (sequenceLength !== 0)
                        {
                            ++sequenceCount;
                            lastSequence = ((i - sequenceLength) | 0);
                        }
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            let $switch1 = $switchJumpState1 ?? (name.get_Item(i).$v);
                            switch($switch1)
                            {
                                case /*%*/ 37:
                                while(true)
                                {
                                    if (++i === end.$v)
                                    {
                                        return false;
                                    }
                                    if (name.GetAt(i) === /*]*/ 93)
                                    {
                                        $switchJumpState1 = /*]*/ 93; /*goto case ']'*/
                                        continue $switchJumpStart1;
                                    }
                                    else if (name.GetAt(i) === /*/*/ 47)
                                    {
                                        $switchJumpState1 = /*/*/ 47; /*goto case '/'*/
                                        continue $switchJumpStart1;
                                    }
                                }
                                case /*]*/ 93:
                                start = i;
                                i = end.$v;
                                continue;
                                case /*:*/ 58:
                                if ((i > 0) && (name.GetAt(((i - 1) | 0)) === /*:*/ 58))
                                {
                                    if (haveCompressor)
                                    {
                                        return false;
                                    }
                                    haveCompressor = true;
                                    expectingNumber = false;
                                }
                                else 
                                {
                                    expectingNumber = true;
                                }
                                break;
                                case /*/*/ 47:
                                if (validateStrictAddress)
                                {
                                    return false;
                                }
                                if ((sequenceCount === 0) || havePrefix)
                                {
                                    return false;
                                }
                                havePrefix = true;
                                expectingNumber = true;
                                break;
                                case /*.*/ 46:
                                if (haveIPv4Address)
                                {
                                    return false;
                                }
                                i = end.$v;
                                if (!$.$spu.System.Net.IPv4AddressHelper.IsValid($.$$.System.Char, name, lastSequence, $.$ref(() => i, ($v) => i = $v, $.$$.System.Int32), true, false, false))
                                {
                                    return false;
                                }
                                ++sequenceCount;
                                haveIPv4Address = true;
                                --i;
                                break;
                                default:
                                return false;
                            }
                            break;
                        }
                        sequenceLength = 0;
                    }
                }
                if (havePrefix && ((sequenceLength < 1) || (sequenceLength > 2)))
                {
                    return false;
                }
                /*int*/ let expectedSequenceCount = ((8 + (havePrefix ? 1 : 0)) | 0);
                if (!expectingNumber && (sequenceLength <= 4) && (haveCompressor ? (sequenceCount < expectedSequenceCount) : (sequenceCount === expectedSequenceCount)))
                {
                    if (i === ((end.$v + 1) | 0))
                    {
                        end.$v = ((start + 1) | 0);
                        return true;
                    }
                    return false;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(12885884930)
            
            //--TRIMMABLE-BOUNDARY-START(21475819522)
            static /*bool */ IsValid(/*char**/ name, /*int*/ start, /*ref int*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spu.System.Net.IPv6AddressHelper.InternalIsValid(name, start, end, false);
            }
            //--TRIMMABLE-BOUNDARY-END(21475819522)
            
            static $h = 983042;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295950338),
    {
      "r": $.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32).$h,
      "p": [
        {
          "n": "numbers",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.UInt16).$h
        }
      ],
      "n": "FindCompressionRange",
      "d": 983042,
      "h": 4295950338,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295950338),
//--TRIMMABLE-BOUNDARY-START(42950656002),
    {
      "r": 262145,
      "p": [
        {
          "n": "numbers",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.UInt16).$h
        }
      ],
      "n": "ShouldHaveIpv4Embedded",
      "d": 983042,
      "h": 42950656002,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42950656002),
//--TRIMMABLE-BOUNDARY-START(25770786818),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": (TChar) => $.$typePointer(TChar).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        }
      ],
      "g": [
        "TChar"
      ],
      "n": "IsValidStrict",
      "d": 983042,
      "h": 25770786818,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(25770786818),
//--TRIMMABLE-BOUNDARY-START(34360721410),
    {
      "r": 65537,
      "p": [
        {
          "n": "address",
          "p": (TChar) => $.$$.System.ReadOnlySpan$$(TChar).$h
        },
        {
          "n": "numbers",
          "p": $.$$.System.Span$$($.$$.System.UInt16).$h
        },
        {
          "n": "scopeId",
          "p": (TChar) => $.$$.System.ReadOnlySpan$$(TChar).$h,
          "f": 2
        }
      ],
      "g": [
        "TChar"
      ],
      "n": "Parse",
      "d": 983042,
      "h": 34360721410,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(34360721410),
//--TRIMMABLE-BOUNDARY-START(38655688706),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "isLoopback",
          "p": 262145,
          "f": 4
        },
        {
          "n": "scopeId",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
          "f": 2
        }
      ],
      "n": "ParseCanonicalName",
      "d": 983042,
      "h": 38655688706,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38655688706),
//--TRIMMABLE-BOUNDARY-START(17180852226),
    {
      "r": 262145,
      "p": [
        {
          "n": "numbers",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.UInt16).$h
        }
      ],
      "n": "IsLoopback",
      "d": 983042,
      "h": 17180852226,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180852226),
//--TRIMMABLE-BOUNDARY-START(12885884930),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361,
          "f": 4
        },
        {
          "n": "validateStrictAddress",
          "p": 262145
        }
      ],
      "n": "InternalIsValid",
      "d": 983042,
      "h": 12885884930,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885884930),
//--TRIMMABLE-BOUNDARY-START(21475819522),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "IsValid",
      "d": 983042,
      "h": 21475819522,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21475819522)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590917634),
    {
      "t": 655361,
      "n": "Hex",
      "d": 983042,
      "h": 8590917634,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590917634),
//--TRIMMABLE-BOUNDARY-START(30065754114),
    {
      "t": 655361,
      "n": "NumberOfLabels",
      "d": 983042,
      "h": 30065754114,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30065754114)
  ],
  "h": 983042
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.IPv6AddressHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983042)
        
        
        //--TRIMMABLE-BOUNDARY-START(131074)
        $asm.$cls("$spu.System.DomainNameHelper", ($self) => class DomainNameHelper
        {
            //--TRIMMABLE-BOUNDARY-START(12885032962)
            /*string*/ static IriDotCharacters = null;
            //--TRIMMABLE-BOUNDARY-END(12885032962)
            
            //--TRIMMABLE-BOUNDARY-START(47244771330)
            /*SearchValues<char>*/ static s_unsafeForNormalizedHostChars = null;
            //--TRIMMABLE-BOUNDARY-END(47244771330)
            
            //--TRIMMABLE-BOUNDARY-START(51539738626)
            /*SearchValues<char>*/ static s_validChars = null;
            //--TRIMMABLE-BOUNDARY-END(51539738626)
            
            //--TRIMMABLE-BOUNDARY-START(42949804034)
            /*SearchValues<char>*/ static s_iriInvalidChars = null;
            //--TRIMMABLE-BOUNDARY-END(42949804034)
            
            //--TRIMMABLE-BOUNDARY-START(34359869442)
            /*SearchValues<char>*/ static s_asciiLetterUpperOrColonChars = null;
            //--TRIMMABLE-BOUNDARY-END(34359869442)
            
            //--TRIMMABLE-BOUNDARY-START(38654836738)
            /*IdnMapping*/ static s_idnMapping = null;
            //--TRIMMABLE-BOUNDARY-END(38654836738)
            
            //--TRIMMABLE-BOUNDARY-START(21474967554)
            /*string*/ static Localhost = null;
            //--TRIMMABLE-BOUNDARY-END(21474967554)
            
            //--TRIMMABLE-BOUNDARY-START(25769934850)
            /*string*/ static Loopback = null;
            //--TRIMMABLE-BOUNDARY-END(25769934850)
            
            //--TRIMMABLE-BOUNDARY-START(30064902146)
            static /*string */ ParseCanonicalName(/*string*/ str, /*int*/ start, /*int*/ end, /*ref bool*/ loopback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let index = $.$$.System.MemoryExtensions.LastIndexOfAny($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$1(str, start, ((end - start) | 0)), $.$spu.System.DomainNameHelper.s_asciiLetterUpperOrColonChars);
                if (index >= 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!$.$$.System.MemoryExtensions.Contains$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$1(str, start, index), /*:*/ 58), "A colon should appear at most once, and must never be followed by letters.");
                    if ($.$$.System.String.get_Chars.call(str, ((start + index) | 0)) === /*:*/ 58)
                    {
                        end = ((start + index) | 0);
                        index = $.$$.System.MemoryExtensions.IndexOfAnyInRange($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$1(str, start, index), /*A*/ 65, /*Z*/ 90);
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$2(index === -1 || $.$$.System.Char.IsAsciiLetterUpper($.$$.System.String.get_Chars.call(str, ((start + index) | 0))), "index == -1 || char.IsAsciiLetterUpper(str[start + index])");
                /*ReadOnlySpan<char>*/ let span = $.$$.System.MemoryExtensions.AsSpan$1(str, start, ((end - start) | 0));
                if (index >= 0)
                {
                    if ($.$$.System.MemoryExtensions.Equals$2(span, $.$$.System.String.op_Implicit("localhost"/*Localhost*/), 5/*StringComparison.OrdinalIgnoreCase*/) || $.$$.System.MemoryExtensions.Equals$2(span, $.$$.System.String.op_Implicit("loopback"/*Loopback*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        loopback.$v = true;
                        return "localhost"/*Localhost*/;
                    }
                    return $.$spu.System.UriHelper.SpanToLowerInvariantString(span);
                }
                if ((span === "localhost"/*Localhost*/) || (span === "loopback"/*Loopback*/))
                {
                    loopback.$v = true;
                    return "localhost"/*Localhost*/;
                }
                return $.$$.System.String.Substring.call(str, start, ((end - start) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(30064902146)
            
            //--TRIMMABLE-BOUNDARY-START(17180000258)
            static /*bool */ IsValid(/*ReadOnlySpan<char>*/ hostname, /*bool*/ iri, /*bool*/ notImplicitFile, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let invalidCharOrDelimiterIndex = iri ? $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, hostname, $.$spu.System.DomainNameHelper.s_iriInvalidChars) : $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, hostname, $.$spu.System.DomainNameHelper.s_validChars);
                if (invalidCharOrDelimiterIndex >= 0)
                {
                    /*char*/ let c = hostname.get_Item(invalidCharOrDelimiterIndex).$v;
                    if ((c === /*/*/ 47) || (c === /*\\*/ 92) || (notImplicitFile && (((c === /*:*/ 58) || (c === /*?*/ 63)) || (c === /*#*/ 35))))
                    {
                        hostname = hostname.Slice(0, invalidCharOrDelimiterIndex);
                    }
                    else 
                    {
                        length.$v = 0;
                        return false;
                    }
                }
                length.$v = hostname.Length;
                if (length.$v === 0)
                {
                    return false;
                }
                while(true)
                {
                    /*char*/ let firstChar = hostname.get_Item(0).$v;
                    if ((!iri || firstChar < 160) && !$.$$.System.Char.IsAsciiLetterOrDigit(firstChar))
                    {
                        return false;
                    }
                    /*int*/ let dotIndex = iri ? $.$$.System.MemoryExtensions.IndexOfAny$4($.$$.System.Char, hostname, $.$$.System.String.op_Implicit(".\u3002\uFF0E\uFF61"/*IriDotCharacters*/)) : $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, hostname, /*.*/ 46);
                    /*int*/ let labelLength = dotIndex < 0 ? hostname.Length : dotIndex;
                    if (iri)
                    {
                        /*ReadOnlySpan<char>*/ let label = hostname.Slice(0, labelLength);
                        if (!$.$$.System.Text.Ascii.IsValid$3(label))
                        {
                            labelLength += 4;
                            var $en5 = label.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var c = $en5.Current.$v;
                                {
                                    if (c > 255)
                                    {
                                        labelLength++;
                                    }
                                }
                            }
                        }
                    }
                    if (!$.$spu.System.IriHelper.IsInInclusiveRange((labelLength >>> 0), 1, 63))
                    {
                        return false;
                    }
                    if (dotIndex < 0)
                    {
                        return true;
                    }
                    hostname = hostname.Slice$1(((dotIndex + 1) | 0));
                    if (hostname.IsEmpty)
                    {
                        return true;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180000258)
            
            //--TRIMMABLE-BOUNDARY-START(8590065666)
            static /*string */ IdnEquivalent(/*string*/ hostname)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Text.Ascii.IsValid$3($.$$.System.String.op_Implicit(hostname)))
                {
                    return $.$$.System.String.ToLowerInvariant.call(hostname);
                }
                /*string*/ let bidiStrippedHost = $.$spu.System.UriHelper.StripBidiControlCharacters($.$$.System.String.op_Implicit(hostname), hostname);
                try
                {
                    /*string*/ let asciiForm = $.$spu.System.DomainNameHelper.s_idnMapping.GetAscii$2(bidiStrippedHost);
                    if ($.$$.System.MemoryExtensions.ContainsAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(asciiForm), $.$spu.System.DomainNameHelper.s_unsafeForNormalizedHostChars))
                    {
                        throw new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadUnicodeHostForIdn);
                    }
                    return asciiForm;
                }
                catch($e)
                {
                    throw new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadUnicodeHostForIdn);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590065666)
            
            //--TRIMMABLE-BOUNDARY-START(55834705922)
            static /*bool */ TryGetUnicodeEquivalent(/*string*/ hostname, /*ref ValueStringBuilder*/ dest)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834705922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Object.ReferenceEquals(hostname, $.$spu.System.UriHelper.StripBidiControlCharacters($.$$.System.String.op_Implicit(hostname), hostname)), "ReferenceEquals(hostname, UriHelper.StripBidiControlCharacters(hostname, hostname))");
                for(/*int*/ let i = 0; i < hostname.length; i++)
                {
                    if (i !== 0)
                    {
                        dest.$v.Append$1(/*.*/ 46);
                    }
                    /*ReadOnlySpan<char>*/ let label = $.$$.System.MemoryExtensions.AsSpan$2(hostname, i);
                    /*int*/ let dotIndex = $.$$.System.MemoryExtensions.IndexOfAny$4($.$$.System.Char, label, $.$$.System.String.op_Implicit(".\u3002\uFF0E\uFF61"/*IriDotCharacters*/));
                    if (dotIndex >= 0)
                    {
                        label = label.Slice(0, dotIndex);
                    }
                    if (!$.$$.System.Text.Ascii.IsValid$3(label))
                    {
                        try
                        {
                            /*string*/ let asciiForm = $.$spu.System.DomainNameHelper.s_idnMapping.GetAscii(hostname, i, label.Length);
                            dest.$v.Append$3($.$spu.System.DomainNameHelper.s_idnMapping.GetUnicode$2(asciiForm));
                        }
                        catch($e)
                        {
                            return false;
                        }
                    }
                    else 
                    {
                        /*bool*/ let aceValid = false;
                        if ($.$$.System.MemoryExtensions.StartsWith(label, $.$$.System.String.op_Implicit("xn--"), 4/*StringComparison.Ordinal*/))
                        {
                            try
                            {
                                dest.$v.Append$3($.$spu.System.DomainNameHelper.s_idnMapping.GetUnicode(hostname, i, label.Length));
                                aceValid = true;
                            }
                            catch($e)
                            {
                            }
                        }
                        if (!aceValid)
                        {
                            /*int*/ let charsWritten = $.$$.System.MemoryExtensions.ToLowerInvariant(label, dest.$v.AppendSpan(label.Length));
                            $.$$.System.Diagnostics.Debug.Assert$2(charsWritten === label.Length, "charsWritten == label.Length");
                        }
                    }
                    i += label.Length;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(55834705922)
            
            //--TRIMMABLE-BOUNDARY-START(4295098370)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885032962)
                    this.IriDotCharacters = ".\u3002\uFF0E\uFF61";
                    //--TRIMMABLE-BOUNDARY-END(12885032962)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244771330)
                    this.s_unsafeForNormalizedHostChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("\\/?@#:[]"));
                    //--TRIMMABLE-BOUNDARY-END(47244771330)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539738626)
                    this.s_validChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz."));
                    //--TRIMMABLE-BOUNDARY-END(51539738626)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949804034)
                    this.s_iriInvalidChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\u0008\t\n\u000B\u000C\r\u000E\u000F" + "\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001A\u001B\u001C\u001D\u001E\u001F" + " !\"#$%&'()*+,/:;<=>?@[\\]^`{|}~\u007F" + "\u0080\u0081\u0082\u0083\u0084\u0085\u0086\u0087\u0088\u0089\u008A\u008B\u008C\u008D\u008E\u008F" + "\u0090\u0091\u0092\u0093\u0094\u0095\u0096\u0097\u0098\u0099\u009A\u009B\u009C\u009D\u009E\u009F"));
                    //--TRIMMABLE-BOUNDARY-END(42949804034)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359869442)
                    this.s_asciiLetterUpperOrColonChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("ABCDEFGHIJKLMNOPQRSTUVWXYZ:"));
                    //--TRIMMABLE-BOUNDARY-END(34359869442)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654836738)
                    this.s_idnMapping = new $.$$.System.Globalization.IdnMapping().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(38654836738)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474967554)
                    this.Localhost = "localhost";
                    //--TRIMMABLE-BOUNDARY-END(21474967554)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25769934850)
                    this.Loopback = "loopback";
                    //--TRIMMABLE-BOUNDARY-END(25769934850)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295098370)
            
            static $h = 131074;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064902146),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        },
        {
          "n": "loopback",
          "p": 262145,
          "f": 4
        }
      ],
      "n": "ParseCanonicalName",
      "d": 131074,
      "h": 30064902146,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30064902146),
//--TRIMMABLE-BOUNDARY-START(17180000258),
    {
      "r": 262145,
      "p": [
        {
          "n": "hostname",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "iri",
          "p": 262145
        },
        {
          "n": "notImplicitFile",
          "p": 262145
        },
        {
          "n": "length",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "IsValid",
      "d": 131074,
      "h": 17180000258,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180000258),
//--TRIMMABLE-BOUNDARY-START(8590065666),
    {
      "r": 1310721,
      "p": [
        {
          "n": "hostname",
          "p": 1310721
        }
      ],
      "n": "IdnEquivalent",
      "d": 131074,
      "h": 8590065666,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590065666),
//--TRIMMABLE-BOUNDARY-START(55834705922),
    {
      "r": 262145,
      "p": [
        {
          "n": "hostname",
          "p": 1310721
        },
        {
          "n": "dest",
          "p": 1507330,
          "f": 4
        }
      ],
      "n": "TryGetUnicodeEquivalent",
      "d": 131074,
      "h": 55834705922,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55834705922)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885032962),
    {
      "t": 1310721,
      "n": "IriDotCharacters",
      "d": 131074,
      "h": 12885032962,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885032962),
//--TRIMMABLE-BOUNDARY-START(47244771330),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "s_unsafeForNormalizedHostChars",
      "d": 131074,
      "h": 47244771330,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47244771330),
//--TRIMMABLE-BOUNDARY-START(51539738626),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "s_validChars",
      "d": 131074,
      "h": 51539738626,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51539738626),
//--TRIMMABLE-BOUNDARY-START(42949804034),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "s_iriInvalidChars",
      "d": 131074,
      "h": 42949804034,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42949804034),
//--TRIMMABLE-BOUNDARY-START(34359869442),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "s_asciiLetterUpperOrColonChars",
      "d": 131074,
      "h": 34359869442,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34359869442),
//--TRIMMABLE-BOUNDARY-START(38654836738),
    {
      "t": 86114305,
      "n": "s_idnMapping",
      "d": 131074,
      "h": 38654836738,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38654836738),
//--TRIMMABLE-BOUNDARY-START(21474967554),
    {
      "t": 1310721,
      "n": "Localhost",
      "d": 131074,
      "h": 21474967554,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21474967554),
//--TRIMMABLE-BOUNDARY-START(25769934850),
    {
      "t": 1310721,
      "n": "Loopback",
      "d": 131074,
      "h": 25769934850,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25769934850)
  ],
  "h": 131074
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.DomainNameHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131074)
        
        
        //--TRIMMABLE-BOUNDARY-START(917506)
        $asm.$cls("$spu.System.Net.IPv4AddressHelper", ($self) => class IPv4AddressHelper
        {
            //--TRIMMABLE-BOUNDARY-START(12885819394)
            /*long*/ static Invalid = -1n;
            //--TRIMMABLE-BOUNDARY-END(12885819394)
            
            //--TRIMMABLE-BOUNDARY-START(25770721282)
            /*long*/ static MaxIPv4Value = 4294967295n;
            //--TRIMMABLE-BOUNDARY-END(25770721282)
            
            //--TRIMMABLE-BOUNDARY-START(34360655874)
            /*int*/ static Octal = 8;
            //--TRIMMABLE-BOUNDARY-END(34360655874)
            
            //--TRIMMABLE-BOUNDARY-START(4295884802)
            /*int*/ static Decimal = 10;
            //--TRIMMABLE-BOUNDARY-END(4295884802)
            
            //--TRIMMABLE-BOUNDARY-START(8590852098)
            /*int*/ static Hex = 16;
            //--TRIMMABLE-BOUNDARY-END(8590852098)
            
            //--TRIMMABLE-BOUNDARY-START(30065688578)
            /*int*/ static NumberOfLabels = 4;
            //--TRIMMABLE-BOUNDARY-END(30065688578)
            
            //--TRIMMABLE-BOUNDARY-START(51540525058)
            static /*ushort */ ToUShort(TChar, /*TChar*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                return $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) ? $.$cast($.$box(value, TChar), $.$$.System.Char) : $.$cast($.$box(value, TChar), $.$$.System.Byte);
            }
            //--TRIMMABLE-BOUNDARY-END(51540525058)
            
            //--TRIMMABLE-BOUNDARY-START(42950590466)
            static /*int */ ParseHostNumber(TChar, /*ReadOnlySpan<TChar>*/ str, /*int*/ start, /*int*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950590466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*Span<byte>*/ let numbers = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 4/*NumberOfLabels*/, null);
                for(/*int*/ let i = 0; i < numbers.Length; ++i)
                {
                    /*int*/ let b = 0;
                    /*int*/ let ch;
                    for(; (start < end) && (ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, str.get_Item(start).$v)) !== /*.*/ 46 && ch !== /*:*/ 58; ++start)
                    {
                        b = (((((((b * 10) | 0)) + ch) | 0) - /*0*/ 48) | 0);
                    }
                    numbers.get_Item(i).$v = $.$cast(b, $.$$.System.Byte);
                    ++start;
                }
                return $.$$.System.Buffers.Binary.BinaryPrimitives.ReadInt32BigEndian($.$$.System.Span$$($.$$.System.Byte).op_Implicit(numbers));
            }
            //--TRIMMABLE-BOUNDARY-END(42950590466)
            
            //--TRIMMABLE-BOUNDARY-START(17180786690)
            static /*bool */ IsValid(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ allowIPv6, /*bool*/ notImplicitFile, /*bool*/ unknownScheme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180786690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (allowIPv6 || unknownScheme)
                {
                    return $.$spu.System.Net.IPv4AddressHelper.IsValidCanonical(TChar, name, start, end, allowIPv6, notImplicitFile);
                }
                else 
                {
                    return $.$spu.System.Net.IPv4AddressHelper.ParseNonCanonical(TChar, name, start, end, notImplicitFile) !== -1n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180786690)
            
            //--TRIMMABLE-BOUNDARY-START(21475753986)
            static /*bool */ IsValidCanonical(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ allowIPv6, /*bool*/ notImplicitFile)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475753986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let dots = 0;
                /*long*/ let number = 0n;
                /*bool*/ let haveNumber = false;
                /*bool*/ let firstCharIsZero = false;
                while(start < end.$v)
                {
                    /*int*/ let ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(start));
                    if (allowIPv6)
                    {
                        if (ch === /*]*/ 93 || ch === /*/*/ 47 || ch === /*%*/ 37)
                        {
                            break;
                        }
                    }
                    else if (ch === /*/*/ 47 || ch === /*\\*/ 92 || (notImplicitFile && (ch === /*:*/ 58 || ch === /*?*/ 63 || ch === /*#*/ 35)))
                    {
                        break;
                    }
                    /*uint*/ let parsedCharacter = ((((ch - /*0*/ 48) | 0)) >>> 0);
                    if (parsedCharacter < 10/*IPv4AddressHelper.Decimal*/)
                    {
                        if (!haveNumber && parsedCharacter === 0)
                        {
                            if ((((start + 1) | 0) < end.$v) && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((start + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*0*/ 48)))
                            {
                                return false;
                            }
                            firstCharIsZero = true;
                        }
                        haveNumber = true;
                        number = number * BigInt(10/*IPv4AddressHelper.Decimal*/) + BigInt(parsedCharacter);
                        if (number > BigInt(255/*byte.MaxValue*/))
                        {
                            return false;
                        }
                    }
                    else if (ch === /*.*/ 46)
                    {
                        if (!haveNumber || (number > 0n && firstCharIsZero))
                        {
                            return false;
                        }
                        ++dots;
                        haveNumber = false;
                        number = 0n;
                        firstCharIsZero = false;
                    }
                    else 
                    {
                        return false;
                    }
                    ++start;
                }
                /*bool*/ let res = (dots === 3) && haveNumber;
                if (res)
                {
                    end.$v = start;
                }
                return res;
            }
            //--TRIMMABLE-BOUNDARY-END(21475753986)
            
            //--TRIMMABLE-BOUNDARY-START(47245557762)
            static /*long */ ParseNonCanonical(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ notImplicitFile)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245557762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let numberBase = 10/*IPv4AddressHelper.Decimal*/;
                /*int*/ let ch = 0;
                /*Span<long>*/ let parts = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Int64, 3, null);
                /*long*/ let currentValue = 0n;
                /*bool*/ let atLeastOneChar = false;
                /*int*/ let dotCount = 0;
                /*int*/ let current = start;
                for(; current < end.$v; current++)
                {
                    ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                    currentValue = 0n;
                    numberBase = 10/*IPv4AddressHelper.Decimal*/;
                    if (ch === /*0*/ 48)
                    {
                        current++;
                        atLeastOneChar = true;
                        if (current < end.$v)
                        {
                            ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                            if (ch === /*x*/ 120 || ch === /*X*/ 88)
                            {
                                numberBase = 16/*IPv4AddressHelper.Hex*/;
                                current++;
                                atLeastOneChar = false;
                            }
                            else 
                            {
                                numberBase = 8/*IPv4AddressHelper.Octal*/;
                            }
                        }
                    }
                    for(; current < end.$v; current++)
                    {
                        ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                        /*int*/ let digitValue = $.$spu.System.HexConverter.FromChar(ch);
                        if (digitValue >= numberBase)
                        {
                            break;
                        }
                        currentValue = (currentValue * BigInt(numberBase)) + BigInt(digitValue);
                        if (currentValue > 4294967295n)
                        {
                            return -1n;
                        }
                        atLeastOneChar = true;
                    }
                    if (current < end.$v && ch === /*.*/ 46)
                    {
                        if (dotCount >= 3 || !atLeastOneChar || currentValue > 255n)
                        {
                            return -1n;
                        }
                        parts.get_Item(dotCount).$v = currentValue;
                        dotCount++;
                        atLeastOneChar = false;
                        continue;
                    }
                    break;
                }
                if (!atLeastOneChar)
                {
                    return -1n;
                }
                else if (current >= end.$v)
                {
                }
                else if (ch === /*/*/ 47 || ch === /*\\*/ 92 || (notImplicitFile && (ch === /*:*/ 58 || ch === /*?*/ 63 || ch === /*#*/ 35)))
                {
                    end.$v = current;
                }
                else 
                {
                    return -1n;
                }
                switch(dotCount)
                {
                    case 0:
                    return currentValue;
                    case 1:
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    if (currentValue > 16777215n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | currentValue;
                    case 2:
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(1).$v <= 255n, "parts[1] <= 0xFF");
                    if (currentValue > 65535n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | (BigInt.asIntN(64, parts.get_Item(1).$v << 16n)) | currentValue;
                    case 3:
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(1).$v <= 255n, "parts[1] <= 0xFF");
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(2).$v <= 255n, "parts[2] <= 0xFF");
                    if (currentValue > 255n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | (BigInt.asIntN(64, parts.get_Item(1).$v << 16n)) | (BigInt.asIntN(64, parts.get_Item(2).$v << 8n)) | currentValue;
                    default:
                    return -1n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245557762)
            
            //--TRIMMABLE-BOUNDARY-START(38655623170)
            static /*string */ ParseCanonicalName(/*string*/ str, /*int*/ start, /*int*/ end, /*ref bool*/ isLoopback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655623170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let changedEnd = end;
                /*long*/ let result;
                {
                    /*fixed*/ 
                    {
                        /*char**/ let ipString = $.$$.System.String.GetPinnableReference.call(str);
                        result = $.$spu.System.Net.IPv4AddressHelper.ParseNonCanonical($.$$.System.Char, ipString, start, $.$ref(() => changedEnd, ($v) => changedEnd = $v, $.$$.System.Int32), true);
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$4(result !== -1n, `Failed to parse after already validated: ${str}`);
                /*Span<byte>*/ let numbers = $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), [$.$cast((result >> 24n), $.$$.System.Byte), $.$cast((result >> 16n), $.$$.System.Byte), $.$cast((result >> 8n), $.$$.System.Byte), $.$cast((result), $.$$.System.Byte)], null, null));
                isLoopback.$v = numbers.get_Item(0).$v === 127;
                /*Span<char>*/ let stackSpace = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, ((((4/*NumberOfLabels*/ * 3) | 0) + 3) | 0), null);
                /*int*/ let totalChars = 0, charsWritten;
                for(/*int*/ let i = 0; i < ((4/*NumberOfLabels*/ - 1) | 0); i++)
                {
                    $.$$.System.Byte.TryFormat$1.call(numbers.get_Item(i).$v, stackSpace.Slice$1(totalChars), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                    /*int*/ let periodPos = ((totalChars + charsWritten) | 0);
                    stackSpace.get_Item(periodPos).$v = /*.*/ 46;
                    totalChars = ((periodPos + 1) | 0);
                }
                $.$$.System.Byte.TryFormat$1.call(numbers.get_Item(3).$v, stackSpace.Slice$1(totalChars), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                return $.$$.System.String.Create$2($.$$.System.Span$$($.$$.System.Char).op_Implicit(stackSpace.Slice(0, ((totalChars + charsWritten) | 0))));
            }
            //--TRIMMABLE-BOUNDARY-END(38655623170)
            
            static $h = 917506;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540525058),
    {
      "r": 589825,
      "p": [
        {
          "n": "value",
          "p": (TChar) => TChar.$h
        }
      ],
      "g": [
        "TChar"
      ],
      "n": "ToUShort",
      "d": 917506,
      "h": 51540525058,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(51540525058),
//--TRIMMABLE-BOUNDARY-START(42950590466),
    {
      "r": 655361,
      "p": [
        {
          "n": "str",
          "p": (TChar) => $.$$.System.ReadOnlySpan$$(TChar).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        }
      ],
      "g": [
        "TChar"
      ],
      "n": "ParseHostNumber",
      "d": 917506,
      "h": 42950590466,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(42950590466),
//--TRIMMABLE-BOUNDARY-START(17180786690),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": (TChar) => $.$typePointer(TChar).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361,
          "f": 4
        },
        {
          "n": "allowIPv6",
          "p": 262145
        },
        {
          "n": "notImplicitFile",
          "p": 262145
        },
        {
          "n": "unknownScheme",
          "p": 262145
        }
      ],
      "g": [
        "TChar"
      ],
      "n": "IsValid",
      "d": 917506,
      "h": 17180786690,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(17180786690),
//--TRIMMABLE-BOUNDARY-START(21475753986),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": (TChar) => $.$typePointer(TChar).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361,
          "f": 4
        },
        {
          "n": "allowIPv6",
          "p": 262145
        },
        {
          "n": "notImplicitFile",
          "p": 262145
        }
      ],
      "g": [
        "TChar"
      ],
      "n": "IsValidCanonical",
      "d": 917506,
      "h": 21475753986,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(21475753986),
//--TRIMMABLE-BOUNDARY-START(47245557762),
    {
      "r": 917505,
      "p": [
        {
          "n": "name",
          "p": (TChar) => $.$typePointer(TChar).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361,
          "f": 4
        },
        {
          "n": "notImplicitFile",
          "p": 262145
        }
      ],
      "g": [
        "TChar"
      ],
      "n": "ParseNonCanonical",
      "d": 917506,
      "h": 47245557762,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(47245557762),
//--TRIMMABLE-BOUNDARY-START(38655623170),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        },
        {
          "n": "isLoopback",
          "p": 262145,
          "f": 4
        }
      ],
      "n": "ParseCanonicalName",
      "d": 917506,
      "h": 38655623170,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38655623170)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885819394),
    {
      "t": 917505,
      "n": "Invalid",
      "d": 917506,
      "h": 12885819394,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885819394),
//--TRIMMABLE-BOUNDARY-START(25770721282),
    {
      "t": 917505,
      "n": "MaxIPv4Value",
      "d": 917506,
      "h": 25770721282,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25770721282),
//--TRIMMABLE-BOUNDARY-START(34360655874),
    {
      "t": 655361,
      "n": "Octal",
      "d": 917506,
      "h": 34360655874,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34360655874),
//--TRIMMABLE-BOUNDARY-START(4295884802),
    {
      "t": 655361,
      "n": "Decimal",
      "d": 917506,
      "h": 4295884802,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295884802),
//--TRIMMABLE-BOUNDARY-START(8590852098),
    {
      "t": 655361,
      "n": "Hex",
      "d": 917506,
      "h": 8590852098,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590852098),
//--TRIMMABLE-BOUNDARY-START(30065688578),
    {
      "t": 655361,
      "n": "NumberOfLabels",
      "d": 917506,
      "h": 30065688578,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30065688578)
  ],
  "h": 917506
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.IPv4AddressHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917506)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572866)
        $asm.$cls("$spu.System.UncNameHelper", ($self) => class UncNameHelper
        {
            //--TRIMMABLE-BOUNDARY-START(8591507458)
            /*int*/ static MaximumInternetNameLength = 256;
            //--TRIMMABLE-BOUNDARY-END(8591507458)
            
            //--TRIMMABLE-BOUNDARY-START(12886474754)
            static /*string */ ParseCanonicalName(/*string*/ str, /*int*/ start, /*int*/ end, /*ref bool*/ loopback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886474754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spu.System.DomainNameHelper.ParseCanonicalName(str, start, end, loopback);
            }
            //--TRIMMABLE-BOUNDARY-END(12886474754)
            
            //--TRIMMABLE-BOUNDARY-START(4296540162)
            static /*bool */ IsValid(/*char**/ name, /*int*/ start, /*ref int*/ returnedEnd, /*bool*/ notImplicitFile)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let end = returnedEnd.$v;
                if (start === end)
                {
                    return false;
                }
                /*bool*/ let validShortName = false;
                /*int*/ let i = start;
                for(; i < end; ++i)
                {
                    if (name.GetAt(i) === /*/*/ 47 || name.GetAt(i) === /*\\*/ 92 || (notImplicitFile && (name.GetAt(i) === /*:*/ 58 || name.GetAt(i) === /*?*/ 63 || name.GetAt(i) === /*#*/ 35)))
                    {
                        end = i;
                        break;
                    }
                    else if (name.GetAt(i) === /*.*/ 46)
                    {
                        ++i;
                        break;
                    }
                    if ($.$$.System.Char.IsLetter(name.GetAt(i)) || name.GetAt(i) === /*-*/ 45 || name.GetAt(i) === /*_*/ 95)
                    {
                        validShortName = true;
                    }
                    else if (!$.$$.System.Char.IsAsciiDigit(name.GetAt(i)))
                    {
                        return false;
                    }
                }
                if (!validShortName)
                {
                    return false;
                }
                for(; i < end; ++i)
                {
                    if (name.GetAt(i) === /*/*/ 47 || name.GetAt(i) === /*\\*/ 92 || (notImplicitFile && (name.GetAt(i) === /*:*/ 58 || name.GetAt(i) === /*?*/ 63 || name.GetAt(i) === /*#*/ 35)))
                    {
                        end = i;
                        break;
                    }
                    else if (name.GetAt(i) === /*.*/ 46)
                    {
                        if (!validShortName || ((((i - 1) | 0)) >= start && name.GetAt(((i - 1) | 0)) === /*.*/ 46))
                        {
                            return false;
                        }
                        validShortName = false;
                    }
                    else if (name.GetAt(i) === /*-*/ 45 || name.GetAt(i) === /*_*/ 95)
                    {
                        if (!validShortName)
                        {
                            return false;
                        }
                    }
                    else if ($.$$.System.Char.IsLetter(name.GetAt(i)) || $.$$.System.Char.IsAsciiDigit(name.GetAt(i)))
                    {
                        if (!validShortName)
                        {
                            validShortName = true;
                        }
                    }
                    else 
                    {
                        return false;
                    }
                }
                if ((((i - 1) | 0)) >= start && name.GetAt(((i - 1) | 0)) === /*.*/ 46)
                {
                    validShortName = true;
                }
                if (!validShortName)
                {
                    return false;
                }
                returnedEnd.$v = end;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540162)
            
            static $h = 1572866;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886474754),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        },
        {
          "n": "loopback",
          "p": 262145,
          "f": 4
        }
      ],
      "n": "ParseCanonicalName",
      "d": 1572866,
      "h": 12886474754,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886474754),
//--TRIMMABLE-BOUNDARY-START(4296540162),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "returnedEnd",
          "p": 655361,
          "f": 4
        },
        {
          "n": "notImplicitFile",
          "p": 262145
        }
      ],
      "n": "IsValid",
      "d": 1572866,
      "h": 4296540162,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296540162)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591507458),
    {
      "t": 655361,
      "n": "MaximumInternetNameLength",
      "d": 1572866,
      "h": 8591507458,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591507458)
  ],
  "h": 1572866
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.UncNameHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572866)
        
        
        //--TRIMMABLE-BOUNDARY-START(2097154)
        $asm.$cls("$spu.System.UriBuilder", ($self) => class UriBuilder extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361835522)
            /*string*/ _scheme = null;
            //--TRIMMABLE-BOUNDARY-END(34361835522)
            
            //--TRIMMABLE-BOUNDARY-START(42951770114)
            /*string*/ _username = null;
            //--TRIMMABLE-BOUNDARY-END(42951770114)
            
            //--TRIMMABLE-BOUNDARY-START(17181966338)
            /*string*/ _password = null;
            //--TRIMMABLE-BOUNDARY-END(17181966338)
            
            //--TRIMMABLE-BOUNDARY-START(12886999042)
            /*string*/ _host = null;
            //--TRIMMABLE-BOUNDARY-END(12886999042)
            
            //--TRIMMABLE-BOUNDARY-START(25771900930)
            /*int*/ _port = -1;
            //--TRIMMABLE-BOUNDARY-END(25771900930)
            
            //--TRIMMABLE-BOUNDARY-START(21476933634)
            /*string*/ _path = null;
            //--TRIMMABLE-BOUNDARY-END(21476933634)
            
            //--TRIMMABLE-BOUNDARY-START(30066868226)
            /*string*/ _query = null;
            //--TRIMMABLE-BOUNDARY-END(30066868226)
            
            //--TRIMMABLE-BOUNDARY-START(8592031746)
            /*string*/ _fragment = null;
            //--TRIMMABLE-BOUNDARY-END(8592031746)
            
            //--TRIMMABLE-BOUNDARY-START(4297064450)
            /*bool*/ _changed = true;
            //--TRIMMABLE-BOUNDARY-END(4297064450)
            
            //--TRIMMABLE-BOUNDARY-START(38656802818)
            /*Uri?*/ _uri = null;
            //--TRIMMABLE-BOUNDARY-END(38656802818)
            
            //--TRIMMABLE-BOUNDARY-START(51541704706)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541704706);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51541704706)
            
            //--TRIMMABLE-BOUNDARY-START(73016541186)
            $ctor$6(/*string*/ uri)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73016541186);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._uri = new $.$spu.System.Uri().$ctor$3(uri, 0/*UriKind.RelativeOrAbsolute*/);
                    if (!this._uri.IsAbsoluteUri)
                    {
                        this._uri = new $.$spu.System.Uri().$ctor$5($.$spu.System.Uri.UriSchemeHttp + $.$spu.System.Uri.SchemeDelimiter + uri);
                    }
                    this.SetFieldsFromUri();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73016541186)
            
            //--TRIMMABLE-BOUNDARY-START(77311508482)
            $ctor$7(/*Uri*/ uri)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77311508482);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                    this._uri = uri;
                    this.SetFieldsFromUri();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77311508482)
            
            //--TRIMMABLE-BOUNDARY-START(68721573890)
            $ctor$5(/*string?*/ schemeName, /*string?*/ hostName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721573890);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Scheme = schemeName;
                    this.Host = hostName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68721573890)
            
            //--TRIMMABLE-BOUNDARY-START(64426606594)
            $ctor$4(/*string?*/ scheme, /*string?*/ host, /*int*/ portNumber)
            {
                this.$ctor$5(scheme, host);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426606594);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Port = portNumber;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64426606594)
            
            //--TRIMMABLE-BOUNDARY-START(60131639298)
            $ctor$3(/*string?*/ scheme, /*string?*/ host, /*int*/ port, /*string?*/ pathValue)
            {
                this.$ctor$4(scheme, host, port);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131639298);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Path = pathValue;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60131639298)
            
            //--TRIMMABLE-BOUNDARY-START(55836672002)
            $ctor$2(/*string?*/ scheme, /*string?*/ host, /*int*/ port, /*string?*/ path, /*string?*/ extraValue)
            {
                this.$ctor$3(scheme, host, port, path);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836672002);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!$.$$.System.String.IsNullOrEmpty(extraValue))
                    {
                        if ($.$$.System.String.get_Chars.call(extraValue, 0) === /*#*/ 35)
                        {
                            this._fragment = extraValue;
                        }
                        else if ($.$$.System.String.get_Chars.call(extraValue, 0) === /*?*/ 63)
                        {
                            /*int*/ let fragmentIndex = $.$$.System.String.IndexOf$3.call(extraValue, /*#*/ 35);
                            if (fragmentIndex === -1)
                            {
                                this._query = extraValue;
                            }
                            else 
                            {
                                this._query = $.$$.System.String.Substring.call(extraValue, 0, fragmentIndex);
                                this._fragment = $.$$.System.String.Substring$1.call(extraValue, fragmentIndex);
                            }
                        }
                        else 
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$spu.System.SR.Argument_ExtraNotValid, "extraValue");
                        }
                        if (this._query.length === 1)
                        {
                            this._query = $.$$.System.String.Empty;
                        }
                        if (this._fragment.length === 1)
                        {
                            this._fragment = $.$$.System.String.Empty;
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55836672002)
            
            //--TRIMMABLE-BOUNDARY-START(201865560066)
            /*string */ get Scheme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325952514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._scheme;
            }
            /*string */ set Scheme(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261995102210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value ??= $.$$.System.String.Empty;
                if (value.length !== 0)
                {
                    if (!$.$spu.System.Uri.CheckSchemeName(value))
                    {
                        /*int*/ let index = $.$$.System.String.IndexOf$3.call(value, /*:*/ 58);
                        if (index !== -1)
                        {
                            value = $.$$.System.String.Substring.call(value, 0, index);
                        }
                        if (!$.$spu.System.Uri.CheckSchemeName(value))
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$spu.System.SR.net_uri_BadScheme, "value");
                        }
                    }
                    value = $.$$.System.String.ToLowerInvariant.call(value);
                }
                this._scheme = value;
                this._changed = true;
            }
            //--TRIMMABLE-BOUNDARY-END(201865560066)
            
            //--TRIMMABLE-BOUNDARY-START(287764905986)
            /*string */ get UserName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505821698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._username;
            }
            /*string */ set UserName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270585036802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._username = value ?? $.$$.System.String.Empty;
                this._changed = true;
            }
            //--TRIMMABLE-BOUNDARY-END(287764905986)
            
            //--TRIMMABLE-BOUNDARY-START(180390723586)
            /*string */ get Password()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966214146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._password;
            }
            /*string */ set Password(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635363842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._password = value ?? $.$$.System.String.Empty;
                this._changed = true;
            }
            //--TRIMMABLE-BOUNDARY-END(180390723586)
            
            //--TRIMMABLE-BOUNDARY-START(176095756290)
            /*string */ get Host()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376279554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._host;
            }
            /*string */ set Host(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045429250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.String.IsNullOrEmpty(value) && $.$$.System.String.Contains$1.call(value, /*:*/ 58) && $.$$.System.String.get_Chars.call(value, 0) !== /*[*/ 91)
                {
                    value = "[" + value + "]";
                }
                this._host = value ?? $.$$.System.String.Empty;
                this._changed = true;
            }
            //--TRIMMABLE-BOUNDARY-END(176095756290)
            
            //--TRIMMABLE-BOUNDARY-START(188980658178)
            /*int */ get Port()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146083330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._port;
            }
            /*int */ set Port(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815233026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, value, -1, "value");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, value, 65535, "value");
                this._port = value;
                this._changed = true;
            }
            //--TRIMMABLE-BOUNDARY-END(188980658178)
            
            //--TRIMMABLE-BOUNDARY-START(184685690882)
            /*string */ get Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556148738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._path;
            }
            /*string */ set Path(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225298434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._path = $.$$.System.String.IsNullOrEmpty(value) ? "/" : $.$spu.System.Uri.InternalEscapeString($.$$.System.String.Replace.call(value, /*\\*/ 92, /*/*/ 47));
                this._changed = true;
            }
            //--TRIMMABLE-BOUNDARY-END(184685690882)
            
            //--TRIMMABLE-BOUNDARY-START(193275625474)
            /*string */ get Query()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736017922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._query;
            }
            /*string */ set Query(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405167618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.String.IsNullOrEmpty(value) && $.$$.System.String.get_Chars.call(value, 0) !== /*?*/ 63)
                {
                    value = /*?*/ 63 + value;
                }
                this._query = value ?? $.$$.System.String.Empty;
                this._changed = true;
            }
            //--TRIMMABLE-BOUNDARY-END(193275625474)
            
            //--TRIMMABLE-BOUNDARY-START(90196410370)
            /*string */ get Fragment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786344962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._fragment;
            }
            /*string */ set Fragment(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455494658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.String.IsNullOrEmpty(value) && $.$$.System.String.get_Chars.call(value, 0) !== /*#*/ 35)
                {
                    value = /*#*/ 35 + value;
                }
                this._fragment = value ?? $.$$.System.String.Empty;
                this._changed = true;
            }
            //--TRIMMABLE-BOUNDARY-END(90196410370)
            
            //--TRIMMABLE-BOUNDARY-START(283469938690)
            /*Uri */ get Uri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915887106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._changed)
                {
                    this._uri = new $.$spu.System.Uri().$ctor$5($.$spu.System.UriBuilder.ToString.call(this));
                    this.SetFieldsFromUri();
                    this._changed = false;
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._uri === null), "_uri is not null");
                }
                return this._uri;
            }
            //--TRIMMABLE-BOUNDARY-END(283469938690)
            
            //--TRIMMABLE-BOUNDARY-START(85901443074)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ rparam)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85901443074);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !(rparam === null) && $.$spu.System.Uri.Equals$1.call(this.Uri, $.$$.System.Object.ToString.call(rparam));
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$spu.System.UriBuilder.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(85901443074)
            
            //--TRIMMABLE-BOUNDARY-START(171800788994)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171800788994);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$spu.System.Uri.GetHashCode.call(this.Uri);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$spu.System.UriBuilder.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(171800788994)
            
            //--TRIMMABLE-BOUNDARY-START(197570592770)
            /*SearchValues<char>*/ static s_userInfoReservedChars = null;
            //--TRIMMABLE-BOUNDARY-END(197570592770)
            
            //--TRIMMABLE-BOUNDARY-START(81606475778)
            static /*string */ EncodeUserInfo(/*string*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606475778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.MemoryExtensions.ContainsAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(input), $.$spu.System.UriBuilder.s_userInfoReservedChars))
                {
                    return input;
                }
                return $.$$.System.String.Replace$2.call($.$$.System.String.Replace$2.call($.$$.System.String.Replace$2.call($.$$.System.String.Replace$2.call($.$$.System.String.Replace$2.call(input, "/", "%2F", 4/*StringComparison.Ordinal*/), "\\", "%5C", 4/*StringComparison.Ordinal*/), "?", "%3F", 4/*StringComparison.Ordinal*/), "#", "%23", 4/*StringComparison.Ordinal*/), "@", "%40", 4/*StringComparison.Ordinal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(81606475778)
            
            //--TRIMMABLE-BOUNDARY-START(274880004098)
            /*void */ SetFieldsFromUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274880004098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(this._uri === null), "_uri is not null");
                this._scheme = this._uri.Scheme;
                this._host = this._uri.Host;
                this._port = this._uri.Port;
                this._path = this._uri.AbsolutePath;
                this._query = this._uri.Query;
                this._fragment = this._uri.Fragment;
                /*string*/ let userInfo = this._uri.UserInfo;
                if (userInfo.length > 0)
                {
                    /*int*/ let index = $.$$.System.String.IndexOf$3.call(userInfo, /*:*/ 58);
                    if (index !== -1)
                    {
                        this._password = $.$$.System.String.Substring$1.call(userInfo, ((index + 1) | 0));
                        this._username = $.$$.System.String.Substring.call(userInfo, 0, index);
                    }
                    else 
                    {
                        this._username = userInfo;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(274880004098)
            
            //--TRIMMABLE-BOUNDARY-START(279174971394)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174971394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.UserName.length === 0 && this.Password.length !== 0)
                {
                    throw new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadUserPassword);
                }
                /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*Uri.StackallocThreshold*/, null));
                /*string*/ let scheme = this.Scheme;
                /*string*/ let host = this.Host;
                if (scheme.length !== 0)
                {
                    /*UriParser?*/ let syntax = $.$spu.System.UriParser.GetSyntax(scheme);
                    /*string*/ let schemeDelimiter;
                    if (syntax === null)
                    {
                        schemeDelimiter = host.length === 0 ? ":" : $.$spu.System.Uri.SchemeDelimiter;
                    }
                    else 
                    {
                        schemeDelimiter = syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/) || (host.length !== 0 && syntax.NotAny(16384/*UriSyntaxFlags.MailToLikeUri*/) && syntax.InFact(2/*UriSyntaxFlags.OptionalAuthority*/)) ? $.$spu.System.Uri.SchemeDelimiter : ":";
                    }
                    vsb.Append$3(scheme);
                    vsb.Append$3(schemeDelimiter);
                }
                /*string*/ let username = $.$spu.System.UriBuilder.EncodeUserInfo(this.UserName);
                if (username.length !== 0)
                {
                    vsb.Append$3(username);
                    /*string*/ let password = $.$spu.System.UriBuilder.EncodeUserInfo(this.Password);
                    if (password.length !== 0)
                    {
                        vsb.Append$1(/*:*/ 58);
                        vsb.Append$3(password);
                    }
                    vsb.Append$1(/*@*/ 64);
                }
                if (host.length !== 0)
                {
                    vsb.Append$3(host);
                    if (this._port !== -1)
                    {
                        vsb.Append$1(/*:*/ 58);
                        /*int*/ let MaxUshortLength = 5;
                        /*int*/ let charsWritten;
                        /*bool*/ let success = $.$$.System.Int32.TryFormat$1.call(this._port, vsb.AppendSpan(MaxUshortLength), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                        $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                        vsb.Length -= ((MaxUshortLength - charsWritten) | 0);
                    }
                }
                /*var*/ let path = this.Path;
                if (path.length !== 0)
                {
                    if (!$.$$.System.String.StartsWith.call(path, /*/*/ 47) && host.length !== 0)
                    {
                        vsb.Append$1(/*/*/ 47);
                    }
                    vsb.Append$3(path);
                }
                vsb.Append$3(this.Query);
                vsb.Append$3(this.Fragment);
                return $.$spu.System.Text.ValueStringBuilder.ToString.call(vsb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spu.System.UriBuilder.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(279174971394)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34361835522)
                this._scheme = "http";
                //--TRIMMABLE-BOUNDARY-END(34361835522)
                
                //--TRIMMABLE-BOUNDARY-START(42951770114)
                this._username = $.$$.System.String.Empty;
                //--TRIMMABLE-BOUNDARY-END(42951770114)
                
                //--TRIMMABLE-BOUNDARY-START(17181966338)
                this._password = $.$$.System.String.Empty;
                //--TRIMMABLE-BOUNDARY-END(17181966338)
                
                //--TRIMMABLE-BOUNDARY-START(12886999042)
                this._host = "localhost";
                //--TRIMMABLE-BOUNDARY-END(12886999042)
                
                //--TRIMMABLE-BOUNDARY-START(21476933634)
                this._path = "/";
                //--TRIMMABLE-BOUNDARY-END(21476933634)
                
                //--TRIMMABLE-BOUNDARY-START(30066868226)
                this._query = $.$$.System.String.Empty;
                //--TRIMMABLE-BOUNDARY-END(30066868226)
                
                //--TRIMMABLE-BOUNDARY-START(8592031746)
                this._fragment = $.$$.System.String.Empty;
                //--TRIMMABLE-BOUNDARY-END(8592031746)
                
            }
            //--TRIMMABLE-BOUNDARY-START(47246737410)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(197570592770)
                    this.s_userInfoReservedChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("/\\?#@"));
                    //--TRIMMABLE-BOUNDARY-END(197570592770)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246737410)
            
            static $h = 2097154;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(201865560066),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325952514,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261995102210,
        "f": 83886081
      },
      "n": "Scheme",
      "d": 2097154,
      "h": 201865560066,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201865560066),
//--TRIMMABLE-BOUNDARY-START(287764905986),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505821698,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270585036802,
        "f": 83886081
      },
      "n": "UserName",
      "d": 2097154,
      "h": 287764905986,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287764905986),
//--TRIMMABLE-BOUNDARY-START(180390723586),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966214146,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227635363842,
        "f": 83886081
      },
      "n": "Password",
      "d": 2097154,
      "h": 180390723586,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180390723586),
//--TRIMMABLE-BOUNDARY-START(176095756290),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376279554,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219045429250,
        "f": 83886081
      },
      "n": "Host",
      "d": 2097154,
      "h": 176095756290,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176095756290),
//--TRIMMABLE-BOUNDARY-START(188980658178),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133146083330,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244815233026,
        "f": 83886081
      },
      "n": "Port",
      "d": 2097154,
      "h": 188980658178,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188980658178),
//--TRIMMABLE-BOUNDARY-START(184685690882),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124556148738,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236225298434,
        "f": 83886081
      },
      "n": "Path",
      "d": 2097154,
      "h": 184685690882,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184685690882),
//--TRIMMABLE-BOUNDARY-START(193275625474),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141736017922,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253405167618,
        "f": 83886081
      },
      "n": "Query",
      "d": 2097154,
      "h": 193275625474,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193275625474),
//--TRIMMABLE-BOUNDARY-START(90196410370),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786344962,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210455494658,
        "f": 83886081
      },
      "n": "Fragment",
      "d": 2097154,
      "h": 90196410370,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196410370),
//--TRIMMABLE-BOUNDARY-START(283469938690),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915887106,
        "f": 50331649
      },
      "n": "Uri",
      "d": 2097154,
      "h": 283469938690,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(283469938690)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85901443074),
    {
      "r": 262145,
      "p": [
        {
          "n": "rparam",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2097154,
      "h": 85901443074,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901443074),
//--TRIMMABLE-BOUNDARY-START(171800788994),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2097154,
      "h": 171800788994,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171800788994),
//--TRIMMABLE-BOUNDARY-START(81606475778),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": 1310721
        }
      ],
      "n": "EncodeUserInfo",
      "d": 2097154,
      "h": 81606475778,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81606475778),
//--TRIMMABLE-BOUNDARY-START(274880004098),
    {
      "r": 65537,
      "n": "SetFieldsFromUri",
      "d": 2097154,
      "h": 274880004098,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(274880004098),
//--TRIMMABLE-BOUNDARY-START(279174971394),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2097154,
      "h": 279174971394,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(279174971394)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361835522),
    {
      "t": 1310721,
      "n": "_scheme",
      "d": 2097154,
      "h": 34361835522,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361835522),
//--TRIMMABLE-BOUNDARY-START(42951770114),
    {
      "t": 1310721,
      "n": "_username",
      "d": 2097154,
      "h": 42951770114,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42951770114),
//--TRIMMABLE-BOUNDARY-START(17181966338),
    {
      "t": 1310721,
      "n": "_password",
      "d": 2097154,
      "h": 17181966338,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181966338),
//--TRIMMABLE-BOUNDARY-START(12886999042),
    {
      "t": 1310721,
      "n": "_host",
      "d": 2097154,
      "h": 12886999042,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886999042),
//--TRIMMABLE-BOUNDARY-START(25771900930),
    {
      "t": 655361,
      "n": "_port",
      "d": 2097154,
      "h": 25771900930,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771900930),
//--TRIMMABLE-BOUNDARY-START(21476933634),
    {
      "t": 1310721,
      "n": "_path",
      "d": 2097154,
      "h": 21476933634,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476933634),
//--TRIMMABLE-BOUNDARY-START(30066868226),
    {
      "t": 1310721,
      "n": "_query",
      "d": 2097154,
      "h": 30066868226,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066868226),
//--TRIMMABLE-BOUNDARY-START(8592031746),
    {
      "t": 1310721,
      "n": "_fragment",
      "d": 2097154,
      "h": 8592031746,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592031746),
//--TRIMMABLE-BOUNDARY-START(4297064450),
    {
      "t": 262145,
      "n": "_changed",
      "d": 2097154,
      "h": 4297064450,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297064450),
//--TRIMMABLE-BOUNDARY-START(38656802818),
    {
      "t": 1703938,
      "n": "_uri",
      "d": 2097154,
      "h": 38656802818,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656802818),
//--TRIMMABLE-BOUNDARY-START(197570592770),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "s_userInfoReservedChars",
      "d": 2097154,
      "h": 197570592770,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(197570592770)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51541704706),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2097154,
      "h": 51541704706,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541704706),
//--TRIMMABLE-BOUNDARY-START(73016541186),
    {
      "p": [
        {
          "n": "uri",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2097154,
      "h": 73016541186,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016541186),
//--TRIMMABLE-BOUNDARY-START(77311508482),
    {
      "p": [
        {
          "n": "uri",
          "p": 1703938
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 2097154,
      "h": 77311508482,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311508482),
//--TRIMMABLE-BOUNDARY-START(68721573890),
    {
      "p": [
        {
          "n": "schemeName",
          "p": 1310721
        },
        {
          "n": "hostName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2097154,
      "h": 68721573890,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721573890),
//--TRIMMABLE-BOUNDARY-START(64426606594),
    {
      "p": [
        {
          "n": "scheme",
          "p": 1310721
        },
        {
          "n": "host",
          "p": 1310721
        },
        {
          "n": "portNumber",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2097154,
      "h": 64426606594,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426606594),
//--TRIMMABLE-BOUNDARY-START(60131639298),
    {
      "p": [
        {
          "n": "scheme",
          "p": 1310721
        },
        {
          "n": "host",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "pathValue",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2097154,
      "h": 60131639298,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131639298),
//--TRIMMABLE-BOUNDARY-START(55836672002),
    {
      "p": [
        {
          "n": "scheme",
          "p": 1310721
        },
        {
          "n": "host",
          "p": 1310721
        },
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "extraValue",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2097154,
      "h": 55836672002,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836672002)
  ],
  "h": 2097154
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.UriBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097154)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441794)
        $asm.$cls("$spu.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(459562942466)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(459562942466)
            
            //--TRIMMABLE-BOUNDARY-START(450973007874)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(450973007874)
            
            //--TRIMMABLE-BOUNDARY-START(455267975170)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303858178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$spu.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Private.Uri", $.$spu.System.SR.$type.Assembly);
                    $.$spu.System.SR.s_resourceManager = temp;
                }
                return $.$spu.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(455267975170)
            
            //--TRIMMABLE-BOUNDARY-START(25771245570)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735362562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spu.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472447844354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$spu.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(25771245570)
            
            //--TRIMMABLE-BOUNDARY-START(12886343682)
            static /*string */ get Argument_AddingDuplicate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965558786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An item with the same key has already been added. Key: {0}";
            }
            //--TRIMMABLE-BOUNDARY-END(12886343682)
            
            //--TRIMMABLE-BOUNDARY-START(68720918530)
            static /*string */ FormatArgument_AddingDuplicate(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720918530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("An item with the same key has already been added. Key: {0}", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(68720918530)
            
            //--TRIMMABLE-BOUNDARY-START(365073661954)
            static /*string */ get net_uri_BadAuthority()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505166338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid URI: The Authority/Host could not be parsed.";
            }
            //--TRIMMABLE-BOUNDARY-END(365073661954)
            
            //--TRIMMABLE-BOUNDARY-START(369368629250)
            static /*string */ get net_uri_BadAuthorityTerminator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095100930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid URI: The Authority/Host cannot end with a backslash character ('\\\\').";
            }
            //--TRIMMABLE-BOUNDARY-END(369368629250)
            
            //--TRIMMABLE-BOUNDARY-START(373663596546)
            static /*string */ get net_uri_BadFormat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685035522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid URI: The format of the URI could not be determined.";
            }
            //--TRIMMABLE-BOUNDARY-END(373663596546)
            
            //--TRIMMABLE-BOUNDARY-START(425203204098)
            static /*string */ get net_uri_NeedFreshParser()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764250626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The URI parser instance passed into 'uriParser' parameter is already registered with the scheme name '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(425203204098)
            
            //--TRIMMABLE-BOUNDARY-START(90195755010)
            static /*string */ Formatnet_uri_NeedFreshParser(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195755010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The URI parser instance passed into 'uriParser' parameter is already registered with the scheme name '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(90195755010)
            
            //--TRIMMABLE-BOUNDARY-START(360778694658)
            static /*string */ get net_uri_AlreadyRegistered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915231746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A URI scheme name '{0}' already has a registered custom parser.";
            }
            //--TRIMMABLE-BOUNDARY-END(360778694658)
            
            //--TRIMMABLE-BOUNDARY-START(81605820418)
            static /*string */ Formatnet_uri_AlreadyRegistered(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605820418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("A URI scheme name '{0}' already has a registered custom parser.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81605820418)
            
            //--TRIMMABLE-BOUNDARY-START(377958563842)
            static /*string */ get net_uri_BadHostName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274970114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid URI: The hostname could not be parsed.";
            }
            //--TRIMMABLE-BOUNDARY-END(377958563842)
            
            //--TRIMMABLE-BOUNDARY-START(382253531138)
            static /*string */ get net_uri_BadPort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864904706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid URI: Invalid port specified.";
            }
            //--TRIMMABLE-BOUNDARY-END(382253531138)
            
            //--TRIMMABLE-BOUNDARY-START(386548498434)
            static /*string */ get net_uri_BadScheme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454839298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid URI: The URI scheme is not valid.";
            }
            //--TRIMMABLE-BOUNDARY-END(386548498434)
            
            //--TRIMMABLE-BOUNDARY-START(395138433026)
            static /*string */ get net_uri_BadUserPassword()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634708482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid URI: The username:password construct is badly formed.";
            }
            //--TRIMMABLE-BOUNDARY-END(395138433026)
            
            //--TRIMMABLE-BOUNDARY-START(399433400322)
            static /*string */ get net_uri_CannotCreateRelative()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224643074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A relative URI cannot be created because the 'uriString' parameter represents an absolute URI.";
            }
            //--TRIMMABLE-BOUNDARY-END(399433400322)
            
            //--TRIMMABLE-BOUNDARY-START(442383073282)
            static /*string */ get net_uri_SchemeLimit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123988994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid URI: The Uri scheme is too long.";
            }
            //--TRIMMABLE-BOUNDARY-END(442383073282)
            
            //--TRIMMABLE-BOUNDARY-START(403728367618)
            static /*string */ get net_uri_EmptyUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814577666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid URI: The URI is empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(403728367618)
            
            //--TRIMMABLE-BOUNDARY-START(416613269506)
            static /*string */ get net_uri_InvalidUriKind()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584381442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The value '{0}' passed for the UriKind parameter is invalid.";
            }
            //--TRIMMABLE-BOUNDARY-END(416613269506)
            
            //--TRIMMABLE-BOUNDARY-START(85900787714)
            static /*string */ Formatnet_uri_InvalidUriKind(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900787714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The value '{0}' passed for the UriKind parameter is invalid.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(85900787714)
            
            //--TRIMMABLE-BOUNDARY-START(420908236802)
            static /*string */ get net_uri_MustRootedPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174316034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid URI: A Dos path must be rooted, for example, 'c:\\\\'.";
            }
            //--TRIMMABLE-BOUNDARY-END(420908236802)
            
            //--TRIMMABLE-BOUNDARY-START(429498171394)
            static /*string */ get net_uri_NotAbsolute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354185218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This operation is not supported for a relative URI.";
            }
            //--TRIMMABLE-BOUNDARY-END(429498171394)
            
            //--TRIMMABLE-BOUNDARY-START(438088105986)
            static /*string */ get net_uri_PortOutOfRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313534054402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A derived type '{0}' has reported an invalid value for the Uri port '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(438088105986)
            
            //--TRIMMABLE-BOUNDARY-START(94490722306)
            static /*string */ Formatnet_uri_PortOutOfRange(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490722306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("A derived type '{0}' has reported an invalid value for the Uri port '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(94490722306)
            
            //--TRIMMABLE-BOUNDARY-START(446678040578)
            static /*string */ get net_uri_UserDrivenParsing()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713923586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A derived type '{0}' is responsible for parsing this Uri instance. The base implementation must not be used.";
            }
            //--TRIMMABLE-BOUNDARY-END(446678040578)
            
            //--TRIMMABLE-BOUNDARY-START(98785689602)
            static /*string */ Formatnet_uri_UserDrivenParsing(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785689602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("A derived type '{0}' is responsible for parsing this Uri instance. The base implementation must not be used.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(98785689602)
            
            //--TRIMMABLE-BOUNDARY-START(433793138690)
            static /*string */ get net_uri_NotJustSerialization()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304944119810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "UriComponents.SerializationInfoString must not be combined with other UriComponents.";
            }
            //--TRIMMABLE-BOUNDARY-END(433793138690)
            
            //--TRIMMABLE-BOUNDARY-START(390843465730)
            static /*string */ get net_uri_BadUnicodeHostForIdn()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044773890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An invalid Unicode character by IDN standards was specified in the host.";
            }
            //--TRIMMABLE-BOUNDARY-END(390843465730)
            
            //--TRIMMABLE-BOUNDARY-START(17181310978)
            static /*string */ get Argument_ExtraNotValid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555493378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Extra portion of URI not valid.";
            }
            //--TRIMMABLE-BOUNDARY-END(17181310978)
            
            //--TRIMMABLE-BOUNDARY-START(21476278274)
            static /*string */ get Argument_InvalidUriSubcomponent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145427970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The subcomponent, {0}, of this uri is not valid.";
            }
            //--TRIMMABLE-BOUNDARY-END(21476278274)
            
            //--TRIMMABLE-BOUNDARY-START(73015885826)
            static /*string */ FormatArgument_InvalidUriSubcomponent(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015885826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The subcomponent, {0}, of this uri is not valid.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(73015885826)
            
            //--TRIMMABLE-BOUNDARY-START(8591376386)
            static /*string */ get Arg_KeyNotFoundWithKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375624194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The given key '{0}' was not present in the dictionary.";
            }
            //--TRIMMABLE-BOUNDARY-END(8591376386)
            
            //--TRIMMABLE-BOUNDARY-START(64425951234)
            static /*string */ FormatArg_KeyNotFoundWithKey(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425951234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The given key '{0}' was not present in the dictionary.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(64425951234)
            
            //--TRIMMABLE-BOUNDARY-START(356483727362)
            static /*string */ get InvalidNullArgument()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325297154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Null is not a valid value for {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(356483727362)
            
            //--TRIMMABLE-BOUNDARY-START(77310853122)
            static /*string */ FormatInvalidNullArgument(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310853122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Null is not a valid value for {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(77310853122)
            
            //--TRIMMABLE-BOUNDARY-START(412318302210)
            static /*string */ get net_uri_InitializeCalledAlreadyOrTooLate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994446850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "UriParser's base InitializeAndValidate may only be called once on a single Uri instance and only from an override of InitializeAndValidate.";
            }
            //--TRIMMABLE-BOUNDARY-END(412318302210)
            
            //--TRIMMABLE-BOUNDARY-START(408023334914)
            static /*string */ get net_uri_GetComponentsCalledWhenCanonicalizationDisabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404512258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "GetComponents() may not be used for Path/Query on a Uri instance created with UriCreationOptions.DangerousDisablePathAndQueryCanonicalization.";
            }
            //--TRIMMABLE-BOUNDARY-END(408023334914)
            
            //--TRIMMABLE-BOUNDARY-START(463857909762)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(463857909762)
            
            //--TRIMMABLE-BOUNDARY-START(352188760066)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(352188760066);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(352188760066)
            
            //--TRIMMABLE-BOUNDARY-START(476742811650)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(476742811650);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$spu.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(476742811650)
            
            //--TRIMMABLE-BOUNDARY-START(347893792770)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893792770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$spu.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(347893792770)
            
            //--TRIMMABLE-BOUNDARY-START(343598825474)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343598825474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$spu.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(343598825474)
            
            //--TRIMMABLE-BOUNDARY-START(55836016642)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836016642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(55836016642)
            
            //--TRIMMABLE-BOUNDARY-START(51541049346)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541049346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(51541049346)
            
            //--TRIMMABLE-BOUNDARY-START(47246082050)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246082050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(47246082050)
            
            //--TRIMMABLE-BOUNDARY-START(60130983938)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130983938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$spu.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(60130983938)
            
            //--TRIMMABLE-BOUNDARY-START(38656147458)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656147458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38656147458)
            
            //--TRIMMABLE-BOUNDARY-START(34361180162)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361180162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34361180162)
            
            //--TRIMMABLE-BOUNDARY-START(30066212866)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066212866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30066212866)
            
            //--TRIMMABLE-BOUNDARY-START(42951114754)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951114754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$spu.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42951114754)
            
            //--TRIMMABLE-BOUNDARY-START(4296409090)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(463857909762)
                    this.s_usingResourceKeys = $.$spu.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(463857909762)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296409090)
            
            static $h = 1441794;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 1441794
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441794)
        
        
        //--TRIMMABLE-BOUNDARY-START(524290)
        $asm.$cls("$spu.System.HexConverter", ($self) => class HexConverter
        {
            //--TRIMMABLE-BOUNDARY-START(589826)
            static $_Casing;
            static get Casing()
            {
                let $cls = $.$spu.System.HexConverter;
                return $cls.$_Casing ??= $asm.$nstr("$spu.System.HexConverter.Casing", ($self) => class Casing extends $.$$.System.Enum
                {
                    static Upper = 0;
                    static Lower = 8224;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(589826);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "Upper": 0n,
                            "Lower": 8224n
                        };
                    }
                    static $h = 589826;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$$.System.UInt32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 720897,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885491714),
    {
      "t": 589826,
      "n": "Upper",
      "d": 589826,
      "h": 12885491714,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885491714),
//--TRIMMABLE-BOUNDARY-START(8590524418),
    {
      "t": 589826,
      "n": "Lower",
      "d": 589826,
      "h": 8590524418,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590524418)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557122),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589826,
      "h": 4295557122,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557122)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "d": 524290,
  "h": 589826
}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.HexConverter.Casing`; }
                }, $cls, ($v) => $cls.$_Casing = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(589826)
            
            //--TRIMMABLE-BOUNDARY-START(60130066434)
            static /*void */ ToBytesBuffer(/*byte*/ value, /*Span<byte>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130066434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast(packedResult, $.$$.System.Byte);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$$.System.Byte);
            }
            //--TRIMMABLE-BOUNDARY-END(60130066434)
            
            //--TRIMMABLE-BOUNDARY-START(68720001026)
            static /*void */ ToCharsBuffer(/*byte*/ value, /*Span<char>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720001026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast((packedResult & 255), $.$$.System.Char);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$$.System.Char);
            }
            //--TRIMMABLE-BOUNDARY-END(68720001026)
            
            //--TRIMMABLE-BOUNDARY-START(21475360770)
            static /*void */ EncodeToUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ utf8Destination, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(utf8Destination.Length >= (((source.Length * 2) | 0)), "utf8Destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$spu.System.HexConverter.ToBytesBuffer(source.get_Item(pos).$v, utf8Destination, ((pos * 2) | 0), casing);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475360770)
            
            //--TRIMMABLE-BOUNDARY-START(17180393474)
            static /*void */ EncodeToUtf16(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180393474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(destination.Length >= (((source.Length * 2) | 0)), "destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$spu.System.HexConverter.ToCharsBuffer(source.get_Item(pos).$v, destination, ((pos * 2) | 0), casing);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180393474)
            
            //--TRIMMABLE-BOUNDARY-START(77309935618)
            static /*string */ ToString$1(/*ReadOnlySpan<byte>*/ bytes, /*Casing*/ casing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309935618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SpanCasingPair*/ let args = (() =>
                {
                    //new $.$spu.System.HexConverter.SpanCasingPair()
                    const $t1 = $.$spu.System.HexConverter.SpanCasingPair;
                    const $i1 = new $t1();
                    $i1.Bytes = bytes;
                    $i1.Casing = casing;
                    return $i1;
                })();
                return $.$$.System.String.Create$10($.$spu.System.HexConverter.SpanCasingPair, ((bytes.Length * 2) | 0), args.Clone(), new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$spu.System.HexConverter.SpanCasingPair))().$ctor($.$spu.System.HexConverter, /*static*/ (/**/ chars, /*args*/ args) =>
                {
                    return $.$spu.System.HexConverter.EncodeToUtf16(args.Bytes, chars, args.Casing);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "chars",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "args",
      "p": 655362
    }
  ],
  "n": "",
  "d": 524290,
  "h": 0,
  "f": 17825826
}));
            }
            //--TRIMMABLE-BOUNDARY-END(77309935618)
            
            //--TRIMMABLE-BOUNDARY-START(655362)
            static $_SpanCasingPair;
            static get SpanCasingPair()
            {
                let $cls = $.$spu.System.HexConverter;
                return $cls.$_SpanCasingPair ??= $asm.$nstr("$spu.System.HexConverter.SpanCasingPair", ($self) => class SpanCasingPair extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(17180524546)
                    /*ReadOnlySpan<byte>*/ Bytes;
                    //--TRIMMABLE-BOUNDARY-END(17180524546)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475491842)
                    /*Casing*/ Casing = 0;
                    //--TRIMMABLE-BOUNDARY-END(21475491842)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557250)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885557250)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Bytes = this.Bytes.Clone();
                        copy.Casing = this.Casing;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Bytes = $.$default($.$$.System.ReadOnlySpan$$($.$$.System.Byte));
                    }
                    static $h = 655362;
                    static $z = 9;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180524546),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065426434,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245295618,
        "f": 83886081
      },
      "n": "Bytes",
      "d": 655362,
      "h": 17180524546,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180524546),
//--TRIMMABLE-BOUNDARY-START(21475491842),
    {
      "p": 589826,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655361026,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835230210,
        "f": 83886081
      },
      "n": "Casing",
      "d": 655362,
      "h": 21475491842,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475491842)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885557250),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655362,
      "h": 12885557250,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557250)
  ],
  "d": 524290,
  "h": 655362
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.HexConverter.SpanCasingPair`; }
                }, $cls, ($v) => $cls.$_SpanCasingPair = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655362)
            
            //--TRIMMABLE-BOUNDARY-START(73014968322)
            static /*char */ ToCharUpper(/*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014968322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*A*/ 65 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$$.System.Char);
            }
            //--TRIMMABLE-BOUNDARY-END(73014968322)
            
            //--TRIMMABLE-BOUNDARY-START(64425033730)
            static /*char */ ToCharLower(/*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425033730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*a*/ 97 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$$.System.Char);
            }
            //--TRIMMABLE-BOUNDARY-END(64425033730)
            
            //--TRIMMABLE-BOUNDARY-START(94489804802)
            static /*bool */ TryDecodeFromUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489804802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spu.System.HexConverter.TryDecodeFromUtf8_Scalar(utf8Source, destination, bytesProcessed);
            }
            //--TRIMMABLE-BOUNDARY-END(94489804802)
            
            //--TRIMMABLE-BOUNDARY-START(85899870210)
            static /*bool */ TryDecodeFromUtf16(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899870210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spu.System.HexConverter.TryDecodeFromUtf16_Scalar(source, destination, charsProcessed);
            }
            //--TRIMMABLE-BOUNDARY-END(85899870210)
            
            //--TRIMMABLE-BOUNDARY-START(90194837506)
            static /*bool */ TryDecodeFromUtf8_Scalar(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194837506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2((utf8Source.Length % 2) === 0, "Un-even number of characters provided");
                $.$$.System.Diagnostics.Debug.Assert$2(($.trunc(utf8Source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$spu.System.HexConverter.FromChar(utf8Source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$spu.System.HexConverter.FromChar(utf8Source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$$.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                bytesProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            //--TRIMMABLE-BOUNDARY-END(90194837506)
            
            //--TRIMMABLE-BOUNDARY-START(81604902914)
            static /*bool */ TryDecodeFromUtf16_Scalar(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604902914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2((source.Length % 2) === 0, "Un-even number of characters provided");
                $.$$.System.Diagnostics.Debug.Assert$2(($.trunc(source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$spu.System.HexConverter.FromChar(source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$spu.System.HexConverter.FromChar(source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$$.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                charsProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            //--TRIMMABLE-BOUNDARY-END(81604902914)
            
            //--TRIMMABLE-BOUNDARY-START(25770328066)
            static /*int */ FromChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770328066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (c >= $.$spu.System.HexConverter.CharToHexLookup.Length) ? 255 : $.$spu.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            //--TRIMMABLE-BOUNDARY-END(25770328066)
            
            //--TRIMMABLE-BOUNDARY-START(34360262658)
            static /*int */ FromUpperChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (c > 71) ? 255 : $.$spu.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            //--TRIMMABLE-BOUNDARY-END(34360262658)
            
            //--TRIMMABLE-BOUNDARY-START(30065295362)
            static /*int */ FromLowerChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065295362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((((c - /*0*/ 48) | 0)) >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                {
                    return ((c - /*0*/ 48) | 0);
                }
                if (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97))
                {
                    return ((((c - /*a*/ 97) | 0) + 10) | 0);
                }
                return 255;
            }
            //--TRIMMABLE-BOUNDARY-END(30065295362)
            
            //--TRIMMABLE-BOUNDARY-START(47245164546)
            static /*bool */ IsHexChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245164546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (IntPtr.Size == 8) { ... }
                return $.$spu.System.HexConverter.FromChar(c) !== 255;
            }
            //--TRIMMABLE-BOUNDARY-END(47245164546)
            
            //--TRIMMABLE-BOUNDARY-START(55835099138)
            static /*bool */ IsHexUpperChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835099138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*A*/ 65) | 0)) >>> 0) <= (/*F*/ 70 - /*A*/ 65));
            }
            //--TRIMMABLE-BOUNDARY-END(55835099138)
            
            //--TRIMMABLE-BOUNDARY-START(51540131842)
            static /*bool */ IsHexLowerChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540131842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97));
            }
            //--TRIMMABLE-BOUNDARY-END(51540131842)
            
            //--TRIMMABLE-BOUNDARY-START(12885426178)
            static /*ReadOnlySpan<byte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([ 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255 ]);
            }
            //--TRIMMABLE-BOUNDARY-END(12885426178)
            
            static $h = 524290;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885426178),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950197250,
        "f": 50331681
      },
      "n": "CharToHexLookup",
      "d": 524290,
      "h": 12885426178,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(12885426178)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130066434),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        },
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "startingIndex",
          "p": 655361,
          "f": 65,
          "v": 0
        },
        {
          "n": "casing",
          "p": 589826,
          "f": 65,
          "v": 0
        }
      ],
      "n": "ToBytesBuffer",
      "d": 524290,
      "h": 60130066434,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130066434),
//--TRIMMABLE-BOUNDARY-START(68720001026),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        },
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "startingIndex",
          "p": 655361,
          "f": 65,
          "v": 0
        },
        {
          "n": "casing",
          "p": 589826,
          "f": 65,
          "v": 0
        }
      ],
      "n": "ToCharsBuffer",
      "d": 524290,
      "h": 68720001026,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68720001026),
//--TRIMMABLE-BOUNDARY-START(21475360770),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "utf8Destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "casing",
          "p": 589826,
          "f": 65,
          "v": 0
        }
      ],
      "n": "EncodeToUtf8",
      "d": 524290,
      "h": 21475360770,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475360770),
//--TRIMMABLE-BOUNDARY-START(17180393474),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "casing",
          "p": 589826,
          "f": 65,
          "v": 0
        }
      ],
      "n": "EncodeToUtf16",
      "d": 524290,
      "h": 17180393474,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180393474),
//--TRIMMABLE-BOUNDARY-START(77309935618),
    {
      "r": 1310721,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "casing",
          "p": 589826,
          "f": 65,
          "v": 0
        }
      ],
      "n": "ToString",
      "o": "@$1",
      "d": 524290,
      "h": 77309935618,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77309935618),
//--TRIMMABLE-BOUNDARY-START(73014968322),
    {
      "r": 458753,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "ToCharUpper",
      "d": 524290,
      "h": 73014968322,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73014968322),
//--TRIMMABLE-BOUNDARY-START(64425033730),
    {
      "r": 458753,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "ToCharLower",
      "d": 524290,
      "h": 64425033730,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64425033730),
//--TRIMMABLE-BOUNDARY-START(94489804802),
    {
      "r": 262145,
      "p": [
        {
          "n": "utf8Source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "bytesProcessed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecodeFromUtf8",
      "d": 524290,
      "h": 94489804802,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94489804802),
//--TRIMMABLE-BOUNDARY-START(85899870210),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "charsProcessed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecodeFromUtf16",
      "d": 524290,
      "h": 85899870210,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85899870210),
//--TRIMMABLE-BOUNDARY-START(90194837506),
    {
      "r": 262145,
      "p": [
        {
          "n": "utf8Source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "bytesProcessed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecodeFromUtf8_Scalar",
      "d": 524290,
      "h": 90194837506,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90194837506),
//--TRIMMABLE-BOUNDARY-START(81604902914),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "charsProcessed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecodeFromUtf16_Scalar",
      "d": 524290,
      "h": 81604902914,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604902914),
//--TRIMMABLE-BOUNDARY-START(25770328066),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "FromChar",
      "d": 524290,
      "h": 25770328066,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770328066),
//--TRIMMABLE-BOUNDARY-START(34360262658),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "FromUpperChar",
      "d": 524290,
      "h": 34360262658,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360262658),
//--TRIMMABLE-BOUNDARY-START(30065295362),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "FromLowerChar",
      "d": 524290,
      "h": 30065295362,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065295362),
//--TRIMMABLE-BOUNDARY-START(47245164546),
    {
      "r": 262145,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "IsHexChar",
      "d": 524290,
      "h": 47245164546,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245164546),
//--TRIMMABLE-BOUNDARY-START(55835099138),
    {
      "r": 262145,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "IsHexUpperChar",
      "d": 524290,
      "h": 55835099138,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835099138),
//--TRIMMABLE-BOUNDARY-START(51540131842),
    {
      "r": 262145,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "IsHexLowerChar",
      "d": 524290,
      "h": 51540131842,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540131842)
  ],
  "j": [589826,655362
  ],
  "h": 524290
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.HexConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524290)
        
        
        //--TRIMMABLE-BOUNDARY-START(2424834)
        $asm.$cls("$spu.System.UriHelper", ($self) => class UriHelper
        {
            //--TRIMMABLE-BOUNDARY-START(73016868866)
            static /*string */ SpanToLowerInvariantString(/*ReadOnlySpan<char>*/ span)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016868866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Create$10($.$$.System.ReadOnlySpan$$($.$$.System.Char), span.Length, span, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.ReadOnlySpan$$($.$$.System.Char)))().$ctor($.$spu.System.UriHelper, /*static*/ (/*buffer*/ buffer, /*span*/ span) =>
                {
                    /*int*/ let charsWritten = $.$$.System.MemoryExtensions.ToLowerInvariant(span, buffer);
                    $.$$.System.Diagnostics.Debug.Assert$2(charsWritten === buffer.Length, "charsWritten == buffer.Length");
                }, {
  "r": 65537,
  "p": [
    {
      "n": "buffer",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "span",
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
    }
  ],
  "n": "",
  "d": 2424834,
  "h": 0,
  "f": 17825826
}));
            }
            //--TRIMMABLE-BOUNDARY-END(73016868866)
            
            //--TRIMMABLE-BOUNDARY-START(55836999682)
            static /*string */ NormalizeAndConcat(/*string?*/ start, /*ReadOnlySpan<char>*/ toNormalize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836999682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*Uri.StackallocThreshold*/, null));
                /*int*/ let charsWritten;
                while(!$.$$.System.StringNormalizationExtensions.TryNormalize(toNormalize, vsb.RawChars, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), 1/*NormalizationForm.FormC*/))
                {
                    vsb.EnsureCapacity(((vsb.Capacity + 1) | 0));
                }
                /*string*/ let result = $.$$.System.String.Concat$8($.$$.System.String.op_Implicit(start), $.$$.System.Span$$($.$$.System.Char).op_Implicit(vsb.RawChars.Slice(0, charsWritten)));
                vsb.Dispose();
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(55836999682)
            
            //--TRIMMABLE-BOUNDARY-START(85901770754)
            static /*bool */ TestForSubPath(/*char**/ selfPtr, /*int*/ selfLength, /*char**/ otherPtr, /*int*/ otherLength, /*bool*/ ignoreCase)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901770754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let i = 0;
                /*char*/ let chSelf;
                /*char*/ let chOther;
                /*bool*/ let AllSameBeforeSlash = true;
                for(; i < selfLength && i < otherLength; ++i)
                {
                    chSelf = (selfPtr.Add(i)).$v;
                    chOther = (otherPtr.Add(i)).$v;
                    if (chSelf === /*?*/ 63 || chSelf === /*#*/ 35)
                    {
                        return true;
                    }
                    if (chSelf === /*/*/ 47)
                    {
                        if (chOther !== /*/*/ 47)
                        {
                            return false;
                        }
                        if (!AllSameBeforeSlash)
                        {
                            return false;
                        }
                        AllSameBeforeSlash = true;
                        continue;
                    }
                    if (chOther === /*?*/ 63 || chOther === /*#*/ 35)
                    {
                        break;
                    }
                    if (!ignoreCase)
                    {
                        if (chSelf !== chOther)
                        {
                            AllSameBeforeSlash = false;
                        }
                    }
                    else 
                    {
                        if ($.$$.System.Char.ToLowerInvariant(chSelf) !== $.$$.System.Char.ToLowerInvariant(chOther))
                        {
                            AllSameBeforeSlash = false;
                        }
                    }
                }
                for(; i < selfLength; ++i)
                {
                    if ((chSelf = (selfPtr.Add(i)).$v) === /*?*/ 63 || chSelf === /*#*/ 35)
                    {
                        return true;
                    }
                    if (chSelf === /*/*/ 47)
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(85901770754)
            
            //--TRIMMABLE-BOUNDARY-START(90196738050)
            static /*bool */ TryEscapeDataString(/*ReadOnlySpan<char>*/ charsToEscape, /*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196738050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < charsToEscape.Length)
                {
                    charsWritten.$v = 0;
                    return false;
                }
                /*int*/ let indexOfFirstToEscape = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, charsToEscape, $.$spu.System.UriHelper.Unreserved);
                if (indexOfFirstToEscape < 0)
                {
                    charsToEscape.CopyTo(destination);
                    charsWritten.$v = charsToEscape.Length;
                    return true;
                }
                /*scoped ValueStringBuilder*/ let vsb;
                /*bool*/ let overlapped = $.$$.System.MemoryExtensions.Overlaps$1($.$$.System.Char, charsToEscape, $.$$.System.Span$$($.$$.System.Char).op_Implicit(destination));
                if (overlapped)
                {
                    vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*Uri.StackallocThreshold*/, null));
                    vsb.EnsureCapacity(charsToEscape.Length);
                }
                else 
                {
                    vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4(destination.Slice$1(indexOfFirstToEscape));
                }
                $.$spu.System.UriHelper.EscapeStringToBuilder(charsToEscape.Slice$1(indexOfFirstToEscape), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), $.$spu.System.UriHelper.Unreserved, false);
                /*int*/ let newLength = $.$checked(indexOfFirstToEscape + vsb.Length, 1);
                $.$$.System.Diagnostics.Debug.Assert$2(newLength > charsToEscape.Length, "newLength > charsToEscape.Length");
                if (destination.Length >= newLength)
                {
                    charsToEscape.Slice(0, indexOfFirstToEscape).CopyTo(destination);
                    if (overlapped)
                    {
                        vsb.AsSpan().CopyTo(destination.Slice$1(indexOfFirstToEscape));
                        vsb.Dispose();
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.MemoryExtensions.Overlaps$1($.$$.System.Char, $.$$.System.Span$$($.$$.System.Char).op_Implicit(vsb.RawChars), $.$$.System.Span$$($.$$.System.Char).op_Implicit(destination)), "vsb.RawChars.Overlaps(destination)");
                    }
                    charsWritten.$v = newLength;
                    return true;
                }
                vsb.Dispose();
                charsWritten.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(90196738050)
            
            //--TRIMMABLE-BOUNDARY-START(30067195906)
            static /*string */ EscapeString$2(/*string*/ stringToEscape, /*bool*/ checkExistingEscaped, /*SearchValues<char>*/ noEscape)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067195906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(stringToEscape, "stringToEscape");
                return $.$spu.System.UriHelper.EscapeString($.$$.System.String.op_Implicit(stringToEscape), checkExistingEscaped, noEscape, stringToEscape);
            }
            //--TRIMMABLE-BOUNDARY-END(30067195906)
            
            //--TRIMMABLE-BOUNDARY-START(21477261314)
            static /*string */ EscapeString(/*ReadOnlySpan<char>*/ charsToEscape, /*bool*/ checkExistingEscaped, /*SearchValues<char>*/ noEscape, /*string?*/ backingString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477261314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!noEscape.Contains(/*%*/ 37), "Need to treat % specially; it should be part of any escaped set");
                $.$$.System.Diagnostics.Debug.Assert$2(backingString === null || backingString.length === charsToEscape.Length, "backingString is null || backingString.Length == charsToEscape.Length");
                /*int*/ let indexOfFirstToEscape = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, charsToEscape, noEscape);
                if (indexOfFirstToEscape < 0)
                {
                    return backingString ?? $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(charsToEscape);
                }
                /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*Uri.StackallocThreshold*/, null));
                vsb.EnsureCapacity(charsToEscape.Length);
                $.$spu.System.UriHelper.EscapeStringToBuilder(charsToEscape.Slice$1(indexOfFirstToEscape), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), noEscape, checkExistingEscaped);
                /*string*/ let result = $.$$.System.String.Concat$8(charsToEscape.Slice(0, indexOfFirstToEscape), vsb.AsSpan());
                vsb.Dispose();
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(21477261314)
            
            //--TRIMMABLE-BOUNDARY-START(25772228610)
            static /*void */ EscapeString$1(/*scoped ReadOnlySpan<char>*/ stringToEscape, /*ref ValueStringBuilder*/ dest, /*bool*/ checkExistingEscaped, /*SearchValues<char>*/ noEscape)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772228610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!noEscape.Contains(/*%*/ 37), "Need to treat % specially; it should be part of any escaped set");
                /*int*/ let indexOfFirstToEscape = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, stringToEscape, noEscape);
                if (indexOfFirstToEscape < 0)
                {
                    dest.$v.Append$2(stringToEscape);
                }
                else 
                {
                    dest.$v.Append$2(stringToEscape.Slice(0, indexOfFirstToEscape));
                    $.$spu.System.UriHelper.EscapeStringToBuilder(stringToEscape.Slice$1(indexOfFirstToEscape), dest, noEscape, checkExistingEscaped);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772228610)
            
            //--TRIMMABLE-BOUNDARY-START(34362163202)
            static /*void */ EscapeStringToBuilder(/*scoped ReadOnlySpan<char>*/ stringToEscape, /*ref ValueStringBuilder*/ vsb, /*SearchValues<char>*/ noEscape, /*bool*/ checkExistingEscaped)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362163202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!stringToEscape.IsEmpty && !noEscape.Contains(stringToEscape.get_Item(0).$v), "!stringToEscape.IsEmpty && !noEscape.Contains(stringToEscape[0])");
                /*Span<byte>*/ let utf8Bytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 4, null);
                while(!stringToEscape.IsEmpty)
                {
                    /*char*/ let c = stringToEscape.get_Item(0).$v;
                    if (!$.$$.System.Char.IsAscii(c))
                    {
                        /*Rune*/ let r;
                        /*int*/ let charsConsumed;
                        if ($.$$.System.Text.Rune.DecodeFromUtf16(stringToEscape, $.$ref(() => r, ($v) => r = $v, $.$$.System.Text.Rune), $.$ref(() => charsConsumed, ($v) => charsConsumed = $v, $.$$.System.Int32)) !== 0/*OperationStatus.Done*/)
                        {
                            r = $.$$.System.Text.Rune.ReplacementChar;
                        }
                        let e;
                        $.$$.System.Diagnostics.Debug.Assert$2((e = $.$$.System.MemoryExtensions.EnumerateRunes(stringToEscape), e != null && true) && e.MoveNext() && $.$$.System.Text.Rune.op_Equality(e.Current, r), "stringToEscape.EnumerateRunes() is { } e && e.MoveNext() && e.Current == r");
                        $.$$.System.Diagnostics.Debug.Assert$2((charsConsumed === 1) || (charsConsumed === 2), "charsConsumed is 1 or 2");
                        stringToEscape = stringToEscape.Slice$1(charsConsumed);
                        /*int*/ let bytesWritten;
                        r.TryEncodeToUtf8(utf8Bytes, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32));
                        var $en4 = utf8Bytes.Slice(0, bytesWritten).GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var b = $en4.Current.$v;
                            {
                                $.$spu.System.UriHelper.PercentEncodeByte(b, vsb);
                            }
                        }
                        continue;
                    }
                    if (!noEscape.Contains(c))
                    {
                        if (c === /*%*/ 37 && checkExistingEscaped)
                        {
                            if (stringToEscape.Length > 2 && $.$$.System.Char.IsAsciiHexDigit(stringToEscape.get_Item(1).$v) && $.$$.System.Char.IsAsciiHexDigit(stringToEscape.get_Item(2).$v))
                            {
                                vsb.$v.Append$1(/*%*/ 37);
                                vsb.$v.Append$1(stringToEscape.get_Item(1).$v);
                                vsb.$v.Append$1(stringToEscape.get_Item(2).$v);
                                stringToEscape = stringToEscape.Slice$1(3);
                                continue;
                            }
                        }
                        $.$spu.System.UriHelper.PercentEncodeByte($.$cast(c, $.$$.System.Byte), vsb);
                        stringToEscape = stringToEscape.Slice$1(1);
                        continue;
                    }
                    /*int*/ let charsToCopy = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, stringToEscape, noEscape);
                    if (charsToCopy < 0)
                    {
                        charsToCopy = stringToEscape.Length;
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(charsToCopy > 0, "charsToCopy > 0");
                    vsb.$v.Append$2(stringToEscape.Slice(0, charsToCopy));
                    stringToEscape = stringToEscape.Slice$1(charsToCopy);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34362163202)
            
            //--TRIMMABLE-BOUNDARY-START(107376607234)
            static /*char[] */ UnescapeString$3(/*string*/ input, /*int*/ start, /*int*/ end, /*char[]*/ dest, /*ref int*/ destPosition, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376607234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*fixed*/ 
                {
                    /*char**/ let pStr = $.$$.System.String.GetPinnableReference.call(input);
                    return $.$spu.System.UriHelper.UnescapeString(pStr, start, end, dest, destPosition, rsvd1, rsvd2, rsvd3, unescapeMode, syntax, isQuery);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107376607234)
            
            //--TRIMMABLE-BOUNDARY-START(94491705346)
            static /*char[] */ UnescapeString(/*char**/ pStr, /*int*/ start, /*int*/ end, /*char[]*/ dest, /*ref int*/ destPosition, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491705346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ValueStringBuilder*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$3(dest.length);
                vsb.Append$2($.$$.System.Span$$($.$$.System.Char).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, dest, 0, destPosition.$v)));
                $.$spu.System.UriHelper.UnescapeString$1(pStr, start, end, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), rsvd1, rsvd2, rsvd3, unescapeMode, syntax, isQuery);
                if (vsb.Length > dest.length)
                {
                    dest = vsb.AsSpan().ToArray();
                }
                else 
                {
                    vsb.AsSpan$3(destPosition.$v).TryCopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, dest, destPosition.$v));
                }
                destPosition.$v = vsb.Length;
                vsb.Dispose();
                return dest;
            }
            //--TRIMMABLE-BOUNDARY-END(94491705346)
            
            //--TRIMMABLE-BOUNDARY-START(111671574530)
            static /*void */ UnescapeString$4(/*string*/ input, /*int*/ start, /*int*/ end, /*ref ValueStringBuilder*/ dest, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671574530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*fixed*/ 
                {
                    /*char**/ let pStr = $.$$.System.String.GetPinnableReference.call(input);
                    $.$spu.System.UriHelper.UnescapeString$1(pStr, start, end, dest, rsvd1, rsvd2, rsvd3, unescapeMode, syntax, isQuery);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111671574530)
            
            //--TRIMMABLE-BOUNDARY-START(103081639938)
            static /*void */ UnescapeString$2(/*scoped ReadOnlySpan<char>*/ input, /*scoped ref ValueStringBuilder*/ dest, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081639938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*fixed*/ 
                {
                    /*char**/ let pStr = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Char, input);
                    $.$spu.System.UriHelper.UnescapeString$1(pStr, 0, input.Length, dest, rsvd1, rsvd2, rsvd3, unescapeMode, syntax, isQuery);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103081639938)
            
            //--TRIMMABLE-BOUNDARY-START(98786672642)
            static /*void */ UnescapeString$1(/*char**/ pStr, /*int*/ start, /*int*/ end, /*ref ValueStringBuilder*/ dest, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786672642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((unescapeMode & 3/*UnescapeMode.EscapeUnescape*/) === 0/*UnescapeMode.CopyOnly*/)
                {
                    dest.$v.Append$2(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pStr.Add(start), ((end - start) | 0)));
                    return;
                }
                /*bool*/ let escapeReserved = false;
                /*bool*/ let iriParsing = $.$spu.System.Uri.IriParsingStatic(syntax) && ((unescapeMode & 3/*UnescapeMode.EscapeUnescape*/) === 3/*UnescapeMode.EscapeUnescape*/);
                for(/*int*/ let next = start; next < end; )
                {
                    /*char*/ let ch = 0;
                    for(; next < end; ++next)
                    {
                        if ((ch = pStr.GetAt(next)) === /*%*/ 37)
                        {
                            if ((unescapeMode & 2/*UnescapeMode.Unescape*/) === 0)
                            {
                                escapeReserved = true;
                            }
                            else if (((next + 2) | 0) < end)
                            {
                                ch = $.$spu.System.UriHelper.DecodeHexChars(pStr.GetAt(((next + 1) | 0)), pStr.GetAt(((next + 2) | 0)));
                                if (unescapeMode >= 8/*UnescapeMode.UnescapeAll*/)
                                {
                                    if (ch === /*\uFFFF*/ 65535)
                                    {
                                        continue;
                                    }
                                }
                                else if (ch === /*\uFFFF*/ 65535)
                                {
                                    if ((unescapeMode & 1/*UnescapeMode.Escape*/) !== 0)
                                    {
                                        escapeReserved = true;
                                    }
                                    else 
                                    {
                                        continue;
                                    }
                                }
                                else if (ch === /*%*/ 37)
                                {
                                    next += 2;
                                    continue;
                                }
                                else if (ch === rsvd1 || ch === rsvd2 || ch === rsvd3)
                                {
                                    next += 2;
                                    continue;
                                }
                                else if ((unescapeMode & 4/*UnescapeMode.V1ToStringFlag*/) === 0 && $.$spu.System.UriHelper.IsNotSafeForUnescape(ch))
                                {
                                    next += 2;
                                    continue;
                                }
                                else if (iriParsing && ((ch <= /*\u009F*/ 159 && $.$spu.System.UriHelper.IsNotSafeForUnescape(ch)) || (ch > /*\u009F*/ 159 && !$.$spu.System.IriHelper.CheckIriUnicodeRange(ch, isQuery))))
                                {
                                    next += 2;
                                    continue;
                                }
                                break;
                            }
                            else if (unescapeMode >= 8/*UnescapeMode.UnescapeAll*/)
                            {
                                continue;
                            }
                            else 
                            {
                                escapeReserved = true;
                            }
                            break;
                        }
                        else if ((unescapeMode & (2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/)) === (2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/))
                        {
                            continue;
                        }
                        else if ((unescapeMode & 1/*UnescapeMode.Escape*/) !== 0)
                        {
                            if (ch === rsvd1 || ch === rsvd2 || ch === rsvd3)
                            {
                                escapeReserved = true;
                                break;
                            }
                            else if ((unescapeMode & 4/*UnescapeMode.V1ToStringFlag*/) === 0 && (ch <= /*\u001F*/ 31 || (ch >= /*\u007F*/ 127 && ch <= /*\u009F*/ 159)))
                            {
                                escapeReserved = true;
                                break;
                            }
                        }
                    }
                    while(start < next)
                    {
                        dest.$v.Append$1(pStr.GetAt(start++));
                    }
                    if (next !== end)
                    {
                        if (escapeReserved)
                        {
                            $.$spu.System.UriHelper.PercentEncodeByte($.$cast(pStr.GetAt(next), $.$$.System.Byte), dest);
                            escapeReserved = false;
                            next++;
                        }
                        else if (ch <= 127)
                        {
                            dest.$v.Append$1(ch);
                            next += 3;
                        }
                        else 
                        {
                            /*int*/ let charactersRead = $.$spu.System.PercentEncodingHelper.UnescapePercentEncodedUTF8Sequence(pStr.Add(next), ((end - next) | 0), dest, isQuery, iriParsing);
                            $.$$.System.Diagnostics.Debug.Assert$2(charactersRead > 0, "charactersRead > 0");
                            next += charactersRead;
                        }
                        start = next;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98786672642)
            
            //--TRIMMABLE-BOUNDARY-START(60131966978)
            static /*void */ PercentEncodeByte(/*byte*/ b, /*ref ValueStringBuilder*/ to)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131966978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                to.$v.Append$1(/*%*/ 37);
                $.$spu.System.HexConverter.ToCharsBuffer(b, to.$v.AppendSpan(2), 0, 0/*HexConverter.Casing.Upper*/);
            }
            //--TRIMMABLE-BOUNDARY-END(60131966978)
            
            //--TRIMMABLE-BOUNDARY-START(17182294018)
            static /*char */ DecodeHexChars(/*int*/ first, /*int*/ second)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182294018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let a = $.$spu.System.HexConverter.FromChar(first);
                /*int*/ let b = $.$spu.System.HexConverter.FromChar(second);
                if ((a | b) === 255)
                {
                    return /*\uFFFF*/ 65535;
                }
                return $.$cast(((a << 4) | b), $.$$.System.Char);
            }
            //--TRIMMABLE-BOUNDARY-END(17182294018)
            
            //--TRIMMABLE-BOUNDARY-START(64426934274)
            /*string*/ static RFC3986ReservedMarks = null;
            //--TRIMMABLE-BOUNDARY-END(64426934274)
            
            //--TRIMMABLE-BOUNDARY-START(8592359426)
            /*string*/ static AdditionalUnsafeToUnescape = null;
            //--TRIMMABLE-BOUNDARY-END(8592359426)
            
            //--TRIMMABLE-BOUNDARY-START(51542032386)
            static /*bool */ IsNotSafeForUnescape(/*char*/ ch)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542032386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (ch <= /*\u001F*/ 31 || (ch >= /*\u007F*/ 127 && ch <= /*\u009F*/ 159))
                {
                    return true;
                }
                /*string*/ let NotSafeForUnescape = ";/?:@&=+$,#[]!'()*"/*RFC3986ReservedMarks*/ + "%\\#"/*AdditionalUnsafeToUnescape*/;
                return $.$$.System.String.Contains$1.call(NotSafeForUnescape, ch);
            }
            //--TRIMMABLE-BOUNDARY-END(51542032386)
            
            //--TRIMMABLE-BOUNDARY-START(115966541826)
            /*SearchValues<char>*/ static Unreserved = null;
            //--TRIMMABLE-BOUNDARY-END(115966541826)
            
            //--TRIMMABLE-BOUNDARY-START(120261509122)
            /*SearchValues<char>*/ static UnreservedReserved = null;
            //--TRIMMABLE-BOUNDARY-END(120261509122)
            
            //--TRIMMABLE-BOUNDARY-START(124556476418)
            /*SearchValues<char>*/ static UnreservedReservedExceptHash = null;
            //--TRIMMABLE-BOUNDARY-END(124556476418)
            
            //--TRIMMABLE-BOUNDARY-START(128851443714)
            /*SearchValues<char>*/ static UnreservedReservedExceptQuestionMarkHash = null;
            //--TRIMMABLE-BOUNDARY-END(128851443714)
            
            //--TRIMMABLE-BOUNDARY-START(42952097794)
            static /*bool */ IsGenDelim(/*char*/ ch)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952097794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (ch === /*:*/ 58 || ch === /*/*/ 47 || ch === /*?*/ 63 || ch === /*#*/ 35 || ch === /*[*/ 91 || ch === /*]*/ 93 || ch === /*@*/ 64);
            }
            //--TRIMMABLE-BOUNDARY-END(42952097794)
            
            //--TRIMMABLE-BOUNDARY-START(68721901570)
            /*char[]*/ static s_WSchars = null;
            //--TRIMMABLE-BOUNDARY-END(68721901570)
            
            //--TRIMMABLE-BOUNDARY-START(47247065090)
            static /*bool */ IsLWS(/*char*/ ch)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247065090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (ch <= /* */ 32) && (ch === /* */ 32 || ch === /*\n*/ 10 || ch === /*\r*/ 13 || ch === /*\t*/ 9);
            }
            //--TRIMMABLE-BOUNDARY-END(47247065090)
            
            //--TRIMMABLE-BOUNDARY-START(38657130498)
            static /*bool */ IsBidiControlCharacter(/*char*/ ch)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657130498);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Char.IsBetween(ch, /*\u200E*/ 8206, /*\u202E*/ 8238) && !$.$$.System.Char.IsBetween(ch, /*\u2010*/ 8208, /*\u2029*/ 8233);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38657130498)
            
            //--TRIMMABLE-BOUNDARY-START(77311836162)
            static /*string */ StripBidiControlCharacters(/*ReadOnlySpan<char>*/ strToClean, /*string?*/ backingString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311836162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(backingString === null || strToClean.Length === backingString.length, "backingString is null || strToClean.Length == backingString.Length");
                /*string?*/ let stripped;
                if ($.$spu.System.UriHelper.StripBidiControlCharacters$1(strToClean, $.$ref(() => stripped, ($v) => stripped = $v, $.$$.System.String)))
                {
                    return stripped;
                }
                return backingString ?? $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(strToClean);
            }
            //--TRIMMABLE-BOUNDARY-END(77311836162)
            
            //--TRIMMABLE-BOUNDARY-START(81606803458)
            static /*bool */ StripBidiControlCharacters$1(/*ReadOnlySpan<char>*/ strToClean, /*out string?*/ stripped)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606803458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let charsToRemove = 0;
                /*int*/ let indexOfPossibleCharToRemove = $.$$.System.MemoryExtensions.IndexOfAnyInRange($.$$.System.Char, strToClean, /*\u200E*/ 8206, /*\u202E*/ 8238);
                if (indexOfPossibleCharToRemove >= 0)
                {
                    var $en3 = strToClean.Slice$1(indexOfPossibleCharToRemove).GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var c = $en3.Current.$v;
                        {
                            if ($.$spu.System.UriHelper.IsBidiControlCharacter(c))
                            {
                                charsToRemove++;
                            }
                        }
                    }
                }
                if (charsToRemove === 0)
                {
                    stripped.$v = null;
                    return false;
                }
                stripped.$v = $.$$.System.String.Create$10($.$$.System.ReadOnlySpan$$($.$$.System.Char), ((strToClean.Length - charsToRemove) | 0), strToClean, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.ReadOnlySpan$$($.$$.System.Char)))().$ctor($.$spu.System.UriHelper, /*static*/ (/*buffer*/ buffer, /*strToClean*/ strToClean) =>
                {
                    /*int*/ let destIndex = 0;
                    var $en3 = strToClean.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var c = $en3.Current.$v;
                        {
                            if (!$.$spu.System.UriHelper.IsBidiControlCharacter(c))
                            {
                                buffer.get_Item(destIndex++).$v = c;
                            }
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(buffer.Length === destIndex, "buffer.Length == destIndex");
                }, {
  "r": 65537,
  "p": [
    {
      "n": "buffer",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "strToClean",
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
    }
  ],
  "n": "",
  "d": 2424834,
  "h": 0,
  "f": 17825826
}));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(81606803458)
            
            //--TRIMMABLE-BOUNDARY-START(12887326722)
            static /*int */ Compress(/*Span<char>*/ span, /*bool*/ convertPathSlashes, /*bool*/ canonicalizeAsFilePath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887326722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (span.IsEmpty)
                {
                    return 0;
                }
                if (convertPathSlashes)
                {
                    $.$$.System.MemoryExtensions.Replace$3($.$$.System.Char, span, /*\\*/ 92, /*/*/ 47);
                }
                /*ValueListBuilder<(int Start, int Length)>*/ let removedSegments = new ($.$spu.System.Collections.Generic.ValueListBuilder$$($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32)))();
                /*int*/ let slashCount = 0;
                /*int*/ let lastSlash = 0;
                /*int*/ let dotCount = 0;
                /*int*/ let removeSegments = 0;
                for(/*int*/ let i = ((span.Length - 1) | 0); i >= 0; i--)
                {
                    /*char*/ let ch = span.get_Item(i).$v;
                    if (ch === /*/*/ 47)
                    {
                        ++slashCount;
                    }
                    else 
                    {
                        if (slashCount > 1)
                        {
                            lastSlash = ((i + 1) | 0);
                        }
                        slashCount = 0;
                    }
                    if (ch === /*.*/ 46)
                    {
                        ++dotCount;
                        continue;
                    }
                    else if (dotCount !== 0)
                    {
                        /*bool*/ let skipSegment = canonicalizeAsFilePath && (dotCount > 2 || ch !== /*/*/ 47);
                        if (!skipSegment && ch === /*/*/ 47)
                        {
                            if ((lastSlash === ((((i + dotCount) | 0) + 1) | 0) || (lastSlash === 0 && ((((i + dotCount) | 0) + 1) | 0) === span.Length)) && (dotCount <= 2))
                            {
                                removedSegments.Append$1(new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(((i + 1) | 0), ((dotCount + (lastSlash === 0 ? 0 : 1)) | 0)));
                                lastSlash = i;
                                if (dotCount === 2)
                                {
                                    ++removeSegments;
                                }
                                dotCount = 0;
                                continue;
                            }
                        }
                        dotCount = 0;
                    }
                    if (ch === /*/*/ 47)
                    {
                        if (removeSegments !== 0)
                        {
                            removeSegments--;
                            removedSegments.Append$1(new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(((i + 1) | 0), ((lastSlash - i) | 0)));
                        }
                        lastSlash = i;
                    }
                }
                if (canonicalizeAsFilePath)
                {
                    if (slashCount <= 1)
                    {
                        if (removeSegments !== 0 && span.get_Item(0).$v !== /*/*/ 47)
                        {
                            removedSegments.Append$1(new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(0, ((lastSlash + 1) | 0)));
                        }
                        else if (dotCount !== 0)
                        {
                            if (lastSlash === dotCount || (lastSlash === 0 && dotCount === span.Length))
                            {
                                removedSegments.Append$1(new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(0, ((dotCount + (lastSlash === 0 ? 0 : 1)) | 0)));
                            }
                        }
                    }
                }
                if (removedSegments.Length === 0)
                {
                    return span.Length;
                }
                /*int*/ let writeOffset = removedSegments.get_Item$1(removedSegments.Length - 1).$v.Item1;
                /*int*/ let readOffset = writeOffset;
                for(/*int*/ let i = ((removedSegments.Length - 1) | 0); i >= 0; i--)
                {
                    const { Item1: start, Item2: length } = removedSegments.get_Item$1(i).$v;
                    $.$$.System.Diagnostics.Debug.Assert$2(start >= readOffset && length > 0 && ((start + length) | 0) <= span.Length, "start >= readOffset && length > 0 && start + length <= span.Length");
                    if (readOffset !== start)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(readOffset > writeOffset, "readOffset > writeOffset");
                        /*int*/ let segmentLength = ((start - readOffset) | 0);
                        span.Slice(readOffset, segmentLength).CopyTo(span.Slice$1(writeOffset));
                        writeOffset += segmentLength;
                    }
                    readOffset = ((start + length) | 0);
                }
                if (readOffset !== span.Length)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(readOffset > writeOffset, "readOffset > writeOffset");
                    span.Slice$1(readOffset).CopyTo(span.Slice$1(writeOffset));
                    writeOffset += ((span.Length - readOffset) | 0);
                }
                removedSegments.Dispose();
                return writeOffset;
            }
            //--TRIMMABLE-BOUNDARY-END(12887326722)
            
            //--TRIMMABLE-BOUNDARY-START(4297392130)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(64426934274)
                    this.RFC3986ReservedMarks = ";/?:@&=+$,#[]!'()*";
                    //--TRIMMABLE-BOUNDARY-END(64426934274)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8592359426)
                    this.AdditionalUnsafeToUnescape = "%\\#";
                    //--TRIMMABLE-BOUNDARY-END(8592359426)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115966541826)
                    this.Unreserved = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz~"));
                    //--TRIMMABLE-BOUNDARY-END(115966541826)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120261509122)
                    this.UnreservedReserved = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("!#$&'()*+,-./0123456789:;=?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]_abcdefghijklmnopqrstuvwxyz~"));
                    //--TRIMMABLE-BOUNDARY-END(120261509122)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124556476418)
                    this.UnreservedReservedExceptHash = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("!$&'()*+,-./0123456789:;=?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]_abcdefghijklmnopqrstuvwxyz~"));
                    //--TRIMMABLE-BOUNDARY-END(124556476418)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128851443714)
                    this.UnreservedReservedExceptQuestionMarkHash = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("!$&'()*+,-./0123456789:;=@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]_abcdefghijklmnopqrstuvwxyz~"));
                    //--TRIMMABLE-BOUNDARY-END(128851443714)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68721901570)
                    this.s_WSchars = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/* */ 32, /*\n*/ 10, /*\r*/ 13, /*\t*/ 9], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(68721901570)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297392130)
            
            static $h = 2424834;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(73016868866),
    {
      "r": 1310721,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "SpanToLowerInvariantString",
      "d": 2424834,
      "h": 73016868866,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73016868866),
//--TRIMMABLE-BOUNDARY-START(55836999682),
    {
      "r": 1310721,
      "p": [
        {
          "n": "start",
          "p": 1310721
        },
        {
          "n": "toNormalize",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "NormalizeAndConcat",
      "d": 2424834,
      "h": 55836999682,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55836999682),
//--TRIMMABLE-BOUNDARY-START(85901770754),
    {
      "r": 262145,
      "p": [
        {
          "n": "selfPtr",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "selfLength",
          "p": 655361
        },
        {
          "n": "otherPtr",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "otherLength",
          "p": 655361
        },
        {
          "n": "ignoreCase",
          "p": 262145
        }
      ],
      "n": "TestForSubPath",
      "d": 2424834,
      "h": 85901770754,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(85901770754),
//--TRIMMABLE-BOUNDARY-START(90196738050),
    {
      "r": 262145,
      "p": [
        {
          "n": "charsToEscape",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryEscapeDataString",
      "d": 2424834,
      "h": 90196738050,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90196738050),
//--TRIMMABLE-BOUNDARY-START(30067195906),
    {
      "r": 1310721,
      "p": [
        {
          "n": "stringToEscape",
          "p": 1310721
        },
        {
          "n": "checkExistingEscaped",
          "p": 262145
        },
        {
          "n": "noEscape",
          "p": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h
        }
      ],
      "n": "EscapeString",
      "o": "@$2",
      "d": 2424834,
      "h": 30067195906,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067195906),
//--TRIMMABLE-BOUNDARY-START(21477261314),
    {
      "r": 1310721,
      "p": [
        {
          "n": "charsToEscape",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "checkExistingEscaped",
          "p": 262145
        },
        {
          "n": "noEscape",
          "p": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h
        },
        {
          "n": "backingString",
          "p": 1310721
        }
      ],
      "n": "EscapeString",
      "d": 2424834,
      "h": 21477261314,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477261314),
//--TRIMMABLE-BOUNDARY-START(25772228610),
    {
      "r": 65537,
      "p": [
        {
          "n": "stringToEscape",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "dest",
          "p": 1507330,
          "f": 4
        },
        {
          "n": "checkExistingEscaped",
          "p": 262145
        },
        {
          "n": "noEscape",
          "p": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h
        }
      ],
      "n": "EscapeString",
      "o": "@$1",
      "d": 2424834,
      "h": 25772228610,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25772228610),
//--TRIMMABLE-BOUNDARY-START(34362163202),
    {
      "r": 65537,
      "p": [
        {
          "n": "stringToEscape",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "vsb",
          "p": 1507330,
          "f": 4
        },
        {
          "n": "noEscape",
          "p": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h
        },
        {
          "n": "checkExistingEscaped",
          "p": 262145
        }
      ],
      "n": "EscapeStringToBuilder",
      "d": 2424834,
      "h": 34362163202,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34362163202),
//--TRIMMABLE-BOUNDARY-START(107376607234),
    {
      "r": $.$typeArray($.$$.System.Char).$h,
      "p": [
        {
          "n": "input",
          "p": 1310721
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        },
        {
          "n": "dest",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "destPosition",
          "p": 655361,
          "f": 4
        },
        {
          "n": "rsvd1",
          "p": 458753
        },
        {
          "n": "rsvd2",
          "p": 458753
        },
        {
          "n": "rsvd3",
          "p": 458753
        },
        {
          "n": "unescapeMode",
          "p": 1638402
        },
        {
          "n": "syntax",
          "p": 2621442
        },
        {
          "n": "isQuery",
          "p": 262145
        }
      ],
      "n": "UnescapeString",
      "o": "@$3",
      "d": 2424834,
      "h": 107376607234,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(107376607234),
//--TRIMMABLE-BOUNDARY-START(94491705346),
    {
      "r": $.$typeArray($.$$.System.Char).$h,
      "p": [
        {
          "n": "pStr",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        },
        {
          "n": "dest",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "destPosition",
          "p": 655361,
          "f": 4
        },
        {
          "n": "rsvd1",
          "p": 458753
        },
        {
          "n": "rsvd2",
          "p": 458753
        },
        {
          "n": "rsvd3",
          "p": 458753
        },
        {
          "n": "unescapeMode",
          "p": 1638402
        },
        {
          "n": "syntax",
          "p": 2621442
        },
        {
          "n": "isQuery",
          "p": 262145
        }
      ],
      "n": "UnescapeString",
      "d": 2424834,
      "h": 94491705346,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(94491705346),
//--TRIMMABLE-BOUNDARY-START(111671574530),
    {
      "r": 65537,
      "p": [
        {
          "n": "input",
          "p": 1310721
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        },
        {
          "n": "dest",
          "p": 1507330,
          "f": 4
        },
        {
          "n": "rsvd1",
          "p": 458753
        },
        {
          "n": "rsvd2",
          "p": 458753
        },
        {
          "n": "rsvd3",
          "p": 458753
        },
        {
          "n": "unescapeMode",
          "p": 1638402
        },
        {
          "n": "syntax",
          "p": 2621442
        },
        {
          "n": "isQuery",
          "p": 262145
        }
      ],
      "n": "UnescapeString",
      "o": "@$4",
      "d": 2424834,
      "h": 111671574530,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(111671574530),
//--TRIMMABLE-BOUNDARY-START(103081639938),
    {
      "r": 65537,
      "p": [
        {
          "n": "input",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "dest",
          "p": 1507330,
          "f": 4
        },
        {
          "n": "rsvd1",
          "p": 458753
        },
        {
          "n": "rsvd2",
          "p": 458753
        },
        {
          "n": "rsvd3",
          "p": 458753
        },
        {
          "n": "unescapeMode",
          "p": 1638402
        },
        {
          "n": "syntax",
          "p": 2621442
        },
        {
          "n": "isQuery",
          "p": 262145
        }
      ],
      "n": "UnescapeString",
      "o": "@$2",
      "d": 2424834,
      "h": 103081639938,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(103081639938),
//--TRIMMABLE-BOUNDARY-START(98786672642),
    {
      "r": 65537,
      "p": [
        {
          "n": "pStr",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        },
        {
          "n": "dest",
          "p": 1507330,
          "f": 4
        },
        {
          "n": "rsvd1",
          "p": 458753
        },
        {
          "n": "rsvd2",
          "p": 458753
        },
        {
          "n": "rsvd3",
          "p": 458753
        },
        {
          "n": "unescapeMode",
          "p": 1638402
        },
        {
          "n": "syntax",
          "p": 2621442
        },
        {
          "n": "isQuery",
          "p": 262145
        }
      ],
      "n": "UnescapeString",
      "o": "@$1",
      "d": 2424834,
      "h": 98786672642,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(98786672642),
//--TRIMMABLE-BOUNDARY-START(60131966978),
    {
      "r": 65537,
      "p": [
        {
          "n": "b",
          "p": 393217
        },
        {
          "n": "to",
          "p": 1507330,
          "f": 4
        }
      ],
      "n": "PercentEncodeByte",
      "d": 2424834,
      "h": 60131966978,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(60131966978),
//--TRIMMABLE-BOUNDARY-START(17182294018),
    {
      "r": 458753,
      "p": [
        {
          "n": "first",
          "p": 655361
        },
        {
          "n": "second",
          "p": 655361
        }
      ],
      "n": "DecodeHexChars",
      "d": 2424834,
      "h": 17182294018,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17182294018),
//--TRIMMABLE-BOUNDARY-START(51542032386),
    {
      "r": 262145,
      "p": [
        {
          "n": "ch",
          "p": 458753
        }
      ],
      "n": "IsNotSafeForUnescape",
      "d": 2424834,
      "h": 51542032386,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51542032386),
//--TRIMMABLE-BOUNDARY-START(42952097794),
    {
      "r": 262145,
      "p": [
        {
          "n": "ch",
          "p": 458753
        }
      ],
      "n": "IsGenDelim",
      "d": 2424834,
      "h": 42952097794,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42952097794),
//--TRIMMABLE-BOUNDARY-START(47247065090),
    {
      "r": 262145,
      "p": [
        {
          "n": "ch",
          "p": 458753
        }
      ],
      "n": "IsLWS",
      "d": 2424834,
      "h": 47247065090,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47247065090),
//--TRIMMABLE-BOUNDARY-START(38657130498),
    {
      "r": 262145,
      "p": [
        {
          "n": "ch",
          "p": 458753
        }
      ],
      "n": "IsBidiControlCharacter",
      "d": 2424834,
      "h": 38657130498,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38657130498),
//--TRIMMABLE-BOUNDARY-START(77311836162),
    {
      "r": 1310721,
      "p": [
        {
          "n": "strToClean",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "backingString",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "StripBidiControlCharacters",
      "d": 2424834,
      "h": 77311836162,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77311836162),
//--TRIMMABLE-BOUNDARY-START(81606803458),
    {
      "r": 262145,
      "p": [
        {
          "n": "strToClean",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "stripped",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "StripBidiControlCharacters",
      "o": "@$1",
      "d": 2424834,
      "h": 81606803458,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81606803458),
//--TRIMMABLE-BOUNDARY-START(12887326722),
    {
      "r": 655361,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "convertPathSlashes",
          "p": 262145
        },
        {
          "n": "canonicalizeAsFilePath",
          "p": 262145
        }
      ],
      "n": "Compress",
      "d": 2424834,
      "h": 12887326722,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887326722)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64426934274),
    {
      "t": 1310721,
      "n": "RFC3986ReservedMarks",
      "d": 2424834,
      "h": 64426934274,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64426934274),
//--TRIMMABLE-BOUNDARY-START(8592359426),
    {
      "t": 1310721,
      "n": "AdditionalUnsafeToUnescape",
      "d": 2424834,
      "h": 8592359426,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8592359426),
//--TRIMMABLE-BOUNDARY-START(115966541826),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "Unreserved",
      "d": 2424834,
      "h": 115966541826,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115966541826),
//--TRIMMABLE-BOUNDARY-START(120261509122),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "UnreservedReserved",
      "d": 2424834,
      "h": 120261509122,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120261509122),
//--TRIMMABLE-BOUNDARY-START(124556476418),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "UnreservedReservedExceptHash",
      "d": 2424834,
      "h": 124556476418,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124556476418),
//--TRIMMABLE-BOUNDARY-START(128851443714),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "UnreservedReservedExceptQuestionMarkHash",
      "d": 2424834,
      "h": 128851443714,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128851443714),
//--TRIMMABLE-BOUNDARY-START(68721901570),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "s_WSchars",
      "d": 2424834,
      "h": 68721901570,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68721901570)
  ],
  "h": 2424834
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.UriHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424834)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376258)
        $asm.$cls("$spu.System.PercentEncodingHelper", ($self) => class PercentEncodingHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4296343554)
            static /*int */ UnescapePercentEncodedUTF8Sequence(/*char**/ input, /*int*/ length, /*ref ValueStringBuilder*/ dest, /*bool*/ isQuery, /*bool*/ iriParsing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let fourByteBuffer;
                /*int*/ let bytesLeftInBuffer;
                /*int*/ let totalCharsConsumed;
                /*int*/ let charsToCopy;
                /*int*/ let bytesConsumed;
                /*uint*/ let value;
                /*uint*/ let second;
                /*uint*/ let temp;
                /*int*/ let i;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(length >= 3, "length >= 3");
                            $.$$.System.Diagnostics.Debug.Assert$2(input.GetAt(0) === /*%*/ 37, "input[0] == '%'");
                            $.$$.System.Diagnostics.Debug.Assert$2($.$spu.System.UriHelper.DecodeHexChars(input.GetAt(1), input.GetAt(2)) !== /*\uFFFF*/ 65535, "UriHelper.DecodeHexChars(input[1], input[2]) != Uri.c_DummyChar");
                            $.$$.System.Diagnostics.Debug.Assert$2($.$spu.System.UriHelper.DecodeHexChars(input.GetAt(1), input.GetAt(2)) >= 128, "UriHelper.DecodeHexChars(input[1], input[2]) >= 128");
                            fourByteBuffer = 0;
                            bytesLeftInBuffer = 0;
                            totalCharsConsumed = 0;
                            charsToCopy = 0;
                            bytesConsumed = 0;
                        }
                        case 1: /*RefillBuffer*/
                        i = ((totalCharsConsumed + (((bytesLeftInBuffer * 3) | 0))) | 0);
                        case 2: /*ReadByteFromInput*/
                        if (((((length - i) | 0)) >>> 0) <= 2 || input.GetAt(i) !== /*%*/ 37)
                        {
                            $gotoJumpState1 = 5; /*goto NoMoreOrInvalidInput*/
                            continue $gotoJumpStart1;
                        }
                        value = input.GetAt(((i + 1) | 0));
                        if ($.$cast(((BigInt(value - /*A*/ 65)) & BigInt(~32)), $.$$.System.UInt32) <= (/*F*/ 70 - /*A*/ 65))
                        {
                            value = (((((value | 32) - /*a*/ 97) >>> 0) + 10) >>> 0);
                        }
                        else if ((((value - /*8*/ 56) >>> 0)) <= (/*9*/ 57 - /*8*/ 56))
                        {
                            value -= /*0*/ 48;
                        }
                        else 
                        {
                            $gotoJumpState1 = 5; /*goto NoMoreOrInvalidInput*/
                            continue $gotoJumpStart1;
                        }
                        second = ((input.GetAt(((i + 2) | 0)) - /*0*/ 48) >>> 0);
                        if (second <= 9)
                        {
                        }
                        else if ($.$cast(((BigInt(second - (/*A*/ 65 - /*0*/ 48))) & BigInt(~32)), $.$$.System.UInt32) <= (/*F*/ 70 - /*A*/ 65))
                        {
                            second = ((((((((second + /*0*/ 48) >>> 0)) | 32) - /*a*/ 97) >>> 0) + 10) >>> 0);
                        }
                        else 
                        {
                            $gotoJumpState1 = 5; /*goto NoMoreOrInvalidInput*/
                            continue $gotoJumpStart1;
                        }
                        value = ((value << 4) >>> 0) | second;
                        $.$$.System.Diagnostics.Debug.Assert$2(value >= 128, "value >= 128");
                        if ($.$$.System.BitConverter.IsLittleEndian)
                        {
                            fourByteBuffer = (fourByteBuffer >>> 8) | ((value << 24) >>> 0);
                        }
                        else 
                        {
                            fourByteBuffer = ((fourByteBuffer << 8) >>> 0) | value;
                        }
                        if (++bytesLeftInBuffer !== 4)
                        {
                            i += 3;
                            $gotoJumpState1 = 2; /*goto ReadByteFromInput*/
                            continue $gotoJumpStart1;
                        }
                        case 3: /*DecodeRune*/
                        $.$$.System.Diagnostics.Debug.Assert$2(totalCharsConsumed % 3 === 0, "totalCharsConsumed % 3 == 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(bytesLeftInBuffer === 2 || bytesLeftInBuffer === 3 || bytesLeftInBuffer === 4, "bytesLeftInBuffer == 2 || bytesLeftInBuffer == 3 || bytesLeftInBuffer == 4");
                        $.$$.System.Diagnostics.Debug.Assert$2((fourByteBuffer & ($.$$.System.BitConverter.IsLittleEndian ? 128 : 2147483648)) !== 0, "(fourByteBuffer & (BitConverter.IsLittleEndian ? 0x00000080 : 0x80000000)) != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2((BigInt(fourByteBuffer) & (BigInt($.$$.System.BitConverter.IsLittleEndian ? 32768 : 8388608))) !== 0n, "(fourByteBuffer & (BitConverter.IsLittleEndian ? 0x00008000 : 0x00800000)) != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(bytesLeftInBuffer < 3 || (BigInt(fourByteBuffer) & (BigInt($.$$.System.BitConverter.IsLittleEndian ? 8388608 : 32768))) !== 0n, "bytesLeftInBuffer < 3 || (fourByteBuffer & (BitConverter.IsLittleEndian ? 0x00800000 : 0x00008000)) != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(bytesLeftInBuffer < 4 || (fourByteBuffer & ($.$$.System.BitConverter.IsLittleEndian ? 2147483648 : 128)) !== 0, "bytesLeftInBuffer < 4 || (fourByteBuffer & (BitConverter.IsLittleEndian ? 0x80000000 : 0x00000080)) != 0");
                        temp = fourByteBuffer;
                        /*Rune*/ let rune;
                        if ($.$$.System.Text.Rune.DecodeFromUtf8(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$5($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.UInt32, () => temp, ($v) => temp = $v, null), bytesLeftInBuffer), $.$ref(() => rune, ($v) => rune = $v, $.$$.System.Text.Rune), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.System.Int32)) === 0/*OperationStatus.Done*/)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$4(bytesConsumed >= 2, `Rune.DecodeFromUtf8 consumed ${bytesConsumed} bytes, likely indicating input was modified concurrently during UnescapePercentEncodedUTF8Sequence's execution`);
                            if (!iriParsing || $.$spu.System.IriHelper.CheckIriUnicodeRange$2((rune.Value >>> 0), isQuery))
                            {
                                if (charsToCopy !== 0)
                                {
                                    dest.$v.Append$2(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(input.Add(totalCharsConsumed).Add(-charsToCopy), charsToCopy));
                                    charsToCopy = 0;
                                }
                                dest.$v.Append$4(rune);
                                $gotoJumpState1 = 4; /*goto AfterDecodeRune*/
                                continue $gotoJumpStart1;
                            }
                        }
                        else 
                        {
                            $.$$.System.Diagnostics.Debug.Assert$4(bytesConsumed > 0, `Rune.DecodeFromUtf8 consumed ${bytesConsumed} bytes when decoding ${bytesLeftInBuffer} bytes`);
                        }
                        charsToCopy += ((bytesConsumed * 3) | 0);
                        case 4: /*AfterDecodeRune*/
                        bytesLeftInBuffer -= bytesConsumed;
                        totalCharsConsumed += ((bytesConsumed * 3) | 0);
                        $gotoJumpState1 = 1; /*goto RefillBuffer*/
                        continue $gotoJumpStart1;
                        case 5: /*NoMoreOrInvalidInput*/
                        $.$$.System.Diagnostics.Debug.Assert$2(bytesLeftInBuffer < 4, "bytesLeftInBuffer < 4");
                        if (bytesLeftInBuffer > 1)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(bytesLeftInBuffer === 2 || bytesLeftInBuffer === 3, "bytesLeftInBuffer == 2 || bytesLeftInBuffer == 3");
                            if (bytesConsumed === 1)
                            {
                                if ($.$$.System.BitConverter.IsLittleEndian)
                                {
                                    fourByteBuffer >>= 8;
                                }
                                else 
                                {
                                    fourByteBuffer <<= 8;
                                }
                            }
                            else 
                            {
                                if ($.$$.System.BitConverter.IsLittleEndian)
                                {
                                    fourByteBuffer >>= (((32 - (bytesLeftInBuffer << 3)) | 0));
                                }
                                else 
                                {
                                    fourByteBuffer <<= (((32 - (bytesLeftInBuffer << 3)) | 0));
                                }
                            }
                            $gotoJumpState1 = 3; /*goto DecodeRune*/
                            continue $gotoJumpStart1;
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(bytesLeftInBuffer === 0 || bytesLeftInBuffer === 1, "bytesLeftInBuffer == 0 || bytesLeftInBuffer == 1");
                        if ((bytesLeftInBuffer | charsToCopy) === 0)
                        {
                            return totalCharsConsumed;
                        }
                        bytesLeftInBuffer *= 3;
                        dest.$v.Append$2(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(input.Add(totalCharsConsumed).Add(-charsToCopy), ((charsToCopy + bytesLeftInBuffer) | 0)));
                        return ((totalCharsConsumed + bytesLeftInBuffer) | 0);
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296343554)
            
            static $h = 1376258;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296343554),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "dest",
          "p": 1507330,
          "f": 4
        },
        {
          "n": "isQuery",
          "p": 262145
        },
        {
          "n": "iriParsing",
          "p": 262145
        }
      ],
      "n": "UnescapePercentEncodedUTF8Sequence",
      "d": 1376258,
      "h": 4296343554,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296343554)
  ],
  "h": 1376258
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.PercentEncodingHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376258)
        
        
        //--TRIMMABLE-BOUNDARY-START(1703938)
        $asm.$cls("$spu.System.Uri", ($self) => class Uri extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(184685297666)
            /*void */ CreateThis(/*string?*/ uri, /*bool*/ dontEscape, /*UriKind*/ uriKind, /*in UriCreationOptions*/ creationOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685297666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.DebugAssertInCtor();
                if (uriKind < 0/*UriKind.RelativeOrAbsolute*/ || uriKind > 2/*UriKind.Relative*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_InvalidUriKind, $.$box(uriKind, $.$spu.System.UriKind)));
                }
                this._string = uri ?? $.$$.System.String.Empty;
                $.$$.System.Diagnostics.Debug.Assert$2(this._originalUnicodeString === null && this._info === null && this._syntax === null && this._flags === 0n, "_originalUnicodeString is null && _info is null && _syntax is null && _flags == Flags.Zero");
                if (dontEscape)
                {
                    this._flags |= 34359738368n;
                }
                if (creationOptions.$v.DangerousDisablePathAndQueryCanonicalization)
                {
                    this._flags |= 36028797018963968n;
                }
                /*ParsingError*/ let err = $.$spu.System.Uri.ParseScheme(this._string, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => this._flags, ($v) => this._flags = $v, null), $.$ref(() => this._syntax, ($v) => this._syntax = $v, $.$spu.System.UriParser));
                /*UriFormatException?*/ let e;
                this.InitializeUri(err, uriKind, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException));
                if (e !== null)
                {
                    throw e;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184685297666)
            
            //--TRIMMABLE-BOUNDARY-START(687196471298)
            /*void */ InitializeUri(/*ParsingError*/ err, /*UriKind*/ uriKind, /*out UriFormatException?*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(687196471298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.DebugAssertInCtor();
                if (err === 0/*ParsingError.None*/)
                {
                    if (this.IsImplicitFile)
                    {
                        if (this.NotAny(8796093022208n) && uriKind !== 1/*UriKind.Absolute*/ && ((uriKind === 2/*UriKind.Relative*/ || (this._string.length >= 2 && ($.$$.System.String.get_Chars.call(this._string, 0) !== /*\\*/ 92 || $.$$.System.String.get_Chars.call(this._string, 1) !== /*\\*/ 92))) || (!$.$$.System.OperatingSystem.IsWindows() && this.InFact(18014398509481984n))))
                        {
                            this._syntax = null;
                            this._flags &= 34359738368n;
                            e.$v = null;
                            return;
                        }
                        else if (uriKind === 2/*UriKind.Relative*/ && this.InFact(8796093022208n))
                        {
                            this._syntax = null;
                            this._flags &= 34359738368n;
                            e.$v = null;
                            return;
                        }
                    }
                }
                else if (err > 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                {
                    this._string = null;
                    e.$v = $.$spu.System.Uri.GetException(err);
                    return;
                }
                /*bool*/ let hasUnicode = false;
                if (this.IriParsing && $.$spu.System.Uri.CheckForUnicodeOrEscapedUnreserved(this._string))
                {
                    this._flags |= 562949953421312n;
                    hasUnicode = true;
                    this._originalUnicodeString = this._string;
                }
                if (this._syntax !== null)
                {
                    if (this._syntax.IsSimple)
                    {
                        if ((err = this.PrivateParseMinimal()) !== 0/*ParsingError.None*/)
                        {
                            if (uriKind !== 1/*UriKind.Absolute*/ && err <= 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                            {
                                this._syntax = null;
                                e.$v = null;
                                this._flags &= 34359738368n;
                                return;
                            }
                            else 
                            {
                                e.$v = $.$spu.System.Uri.GetException(err);
                            }
                        }
                        else if (uriKind === 2/*UriKind.Relative*/)
                        {
                            e.$v = $.$spu.System.Uri.GetException(12/*ParsingError.CannotCreateRelative*/);
                        }
                        else 
                        {
                            e.$v = null;
                        }
                        if (hasUnicode)
                        {
                            try
                            {
                                this.EnsureParseRemaining();
                            }
                            catch(ex)
                            {
                                e.$v = ex;
                                return;
                            }
                        }
                    }
                    else 
                    {
                        this._syntax = this._syntax.InternalOnNewUri();
                        this._flags |= 1099511627776n;
                        this._syntax.InternalValidate(this, e);
                        if (e.$v !== null)
                        {
                            if (uriKind !== 1/*UriKind.Absolute*/ && err !== 0/*ParsingError.None*/ && err <= 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                            {
                                this._syntax = null;
                                e.$v = null;
                                this._flags &= 34359738368n;
                            }
                        }
                        else 
                        {
                            if (err !== 0/*ParsingError.None*/ || this.InFact(4398046511104n))
                            {
                                this._flags = 1099511627776n | (this._flags & 34359738368n);
                            }
                            else if (uriKind === 2/*UriKind.Relative*/)
                            {
                                e.$v = $.$spu.System.Uri.GetException(12/*ParsingError.CannotCreateRelative*/);
                            }
                            if (hasUnicode)
                            {
                                try
                                {
                                    this.EnsureParseRemaining();
                                }
                                catch(ex)
                                {
                                    e.$v = ex;
                                    return;
                                }
                            }
                        }
                    }
                }
                else if (err !== 0/*ParsingError.None*/ && uriKind !== 1/*UriKind.Absolute*/ && err <= 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                {
                    e.$v = null;
                    this._flags &= (34359738368n | 562949953421312n);
                    if (hasUnicode)
                    {
                        this._string = this.EscapeUnescapeIri(this._originalUnicodeString, 0, this._originalUnicodeString.length, $.$cast(0, $.$spu.System.UriComponents));
                    }
                }
                else 
                {
                    this._string = null;
                    e.$v = $.$spu.System.Uri.GetException(err);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(687196471298)
            
            //--TRIMMABLE-BOUNDARY-START(893354901506)
            /*SearchValues<char>*/ static s_asciiOtherThanPercent = null;
            //--TRIMMABLE-BOUNDARY-END(893354901506)
            
            //--TRIMMABLE-BOUNDARY-START(137440657410)
            static /*bool */ CheckForUnicodeOrEscapedUnreserved(/*string*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440657410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let i = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(data), $.$spu.System.Uri.s_asciiOtherThanPercent);
                if (i >= 0)
                {
                    for(; i < data.length; i++)
                    {
                        /*char*/ let c = $.$$.System.String.get_Chars.call(data, i);
                        if (c === /*%*/ 37)
                        {
                            if (((((i + 2) | 0)) >>> 0) < (data.length >>> 0))
                            {
                                /*char*/ let value = $.$spu.System.UriHelper.DecodeHexChars($.$$.System.String.get_Chars.call(data, ((i + 1) | 0)), $.$$.System.String.get_Chars.call(data, ((i + 2) | 0)));
                                if (!$.$$.System.Char.IsAscii(value) || $.$spu.System.UriHelper.Unreserved.Contains(value))
                                {
                                    return true;
                                }
                                i += 2;
                            }
                        }
                        else if (c > 127)
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(137440657410)
            
            //--TRIMMABLE-BOUNDARY-START(966369345538)
            static /*bool */ TryCreate(/*string?*/ uriString, /*UriKind*/ uriKind, /*out Uri?*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(966369345538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (uriString === null)
                {
                    result.$v = null;
                    return false;
                }
                /*UriFormatException?*/ let e = null;
                let $v2 = new $.$spu.System.UriCreationOptions();
                result.$v = $.$spu.System.Uri.CreateHelper(uriString, false, uriKind, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException), $.$ref(() => $v2, ($v) => $v2 = $v));
                result.$v?.DebugSetLeftCtor();
                return e === null && $.$spu.System.Uri.op_Inequality(result.$v, null);
            }
            //--TRIMMABLE-BOUNDARY-END(966369345538)
            
            //--TRIMMABLE-BOUNDARY-START(970664312834)
            static /*bool */ TryCreate$1(/*string?*/ uriString, /*in UriCreationOptions*/ creationOptions, /*out Uri?*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(970664312834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (uriString === null)
                {
                    result.$v = null;
                    return false;
                }
                /*UriFormatException?*/ let e = null;
                result.$v = $.$spu.System.Uri.CreateHelper(uriString, false, 1/*UriKind.Absolute*/, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException), creationOptions);
                result.$v?.DebugSetLeftCtor();
                return e === null && $.$spu.System.Uri.op_Inequality(result.$v, null);
            }
            //--TRIMMABLE-BOUNDARY-END(970664312834)
            
            //--TRIMMABLE-BOUNDARY-START(974959280130)
            static /*bool */ TryCreate$2(/*Uri?*/ baseUri, /*string?*/ relativeUri, /*out Uri?*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(974959280130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Uri?*/ let relativeLink;
                if ($.$spu.System.Uri.TryCreate(relativeUri, 0/*UriKind.RelativeOrAbsolute*/, $.$ref(() => relativeLink, ($v) => relativeLink = $v, $.$spu.System.Uri)))
                {
                    if (!relativeLink.IsAbsoluteUri)
                    {
                        return $.$spu.System.Uri.TryCreate$3(baseUri, relativeLink, result);
                    }
                    result.$v = relativeLink;
                    return true;
                }
                result.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(974959280130)
            
            //--TRIMMABLE-BOUNDARY-START(979254247426)
            static /*bool */ TryCreate$3(/*Uri?*/ baseUri, /*Uri?*/ relativeUri, /*out Uri?*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(979254247426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                result.$v = null;
                if (baseUri === null || relativeUri === null)
                {
                    return false;
                }
                if (baseUri.IsNotAbsoluteUri)
                {
                    return false;
                }
                /*UriFormatException?*/ let e = null;
                /*string?*/ let newUriString = null;
                /*bool*/ let dontEscape;
                if (baseUri.Syntax.IsSimple)
                {
                    dontEscape = relativeUri.UserEscaped;
                    result.$v = $.$spu.System.Uri.ResolveHelper(baseUri, relativeUri, $.$ref(() => newUriString, ($v) => newUriString = $v, $.$$.System.String), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => dontEscape, ($v) => dontEscape = $v, null));
                }
                else 
                {
                    dontEscape = false;
                    newUriString = baseUri.Syntax.InternalResolve(baseUri, relativeUri, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException));
                    if (e !== null)
                    {
                        return false;
                    }
                }
                let $v2 = new $.$spu.System.UriCreationOptions();
                result.$v ??= $.$spu.System.Uri.CreateHelper(newUriString, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException), $.$ref(() => $v2, ($v) => $v2 = $v));
                result.$v?.DebugSetLeftCtor();
                return e === null && $.$spu.System.Uri.op_Inequality(result.$v, null) && result.$v.IsAbsoluteUri;
            }
            //--TRIMMABLE-BOUNDARY-END(979254247426)
            
            //--TRIMMABLE-BOUNDARY-START(592707190786)
            /*string */ GetComponents(/*UriComponents*/ components, /*UriFormat*/ format)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592707190786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.DisablePathAndQueryCanonicalization && (components & (16/*UriComponents.Path*/ | 32/*UriComponents.Query*/)) !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_GetComponentsCalledWhenCanonicalizationDisabled);
                }
                return this.InternalGetComponents(components, format);
            }
            //--TRIMMABLE-BOUNDARY-END(592707190786)
            
            //--TRIMMABLE-BOUNDARY-START(700081373186)
            /*string */ InternalGetComponents(/*UriComponents*/ components, /*UriFormat*/ format)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(700081373186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((components & -2147483648/*UriComponents.SerializationInfoString*/) !== 0) && components !== -2147483648/*UriComponents.SerializationInfoString*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("components", $.$box(components, $.$spu.System.UriComponents), $.$spu.System.SR.net_uri_NotJustSerialization);
                }
                if ((format & ~3/*UriFormat.SafeUnescaped*/) !== 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("format");
                }
                if (this.IsNotAbsoluteUri)
                {
                    if (components === -2147483648/*UriComponents.SerializationInfoString*/)
                    {
                        return this.GetRelativeSerializationString(format);
                    }
                    else 
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                    }
                }
                if (this.Syntax.IsSimple)
                {
                    return this.GetComponentsHelper(components, format);
                }
                return this.Syntax.InternalGetComponents(this, components, format);
            }
            //--TRIMMABLE-BOUNDARY-END(700081373186)
            
            //--TRIMMABLE-BOUNDARY-START(163210461186)
            static /*int */ Compare(/*Uri?*/ uri1, /*Uri?*/ uri2, /*UriComponents*/ partsToCompare, /*UriFormat*/ compareFormat, /*StringComparison*/ comparisonType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210461186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (uri1 === null)
                {
                    if (uri2 === null)
                    {
                        return 0;
                    }
                    return -1;
                }
                if (uri2 === null)
                {
                    return 1;
                }
                if (!uri1.IsAbsoluteUri || !uri2.IsAbsoluteUri)
                {
                    return uri1.IsAbsoluteUri ? 1 : uri2.IsAbsoluteUri ? -1 : $.$$.System.String.Compare$8(uri1.OriginalString, uri2.OriginalString, comparisonType);
                }
                return $.$$.System.String.Compare$8(uri1.GetParts(partsToCompare, compareFormat), uri2.GetParts(partsToCompare, compareFormat), comparisonType);
            }
            //--TRIMMABLE-BOUNDARY-END(163210461186)
            
            //--TRIMMABLE-BOUNDARY-START(794570653698)
            /*bool */ IsWellFormedOriginalString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(794570653698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri || this.Syntax.IsSimple)
                {
                    return this.InternalIsWellFormedOriginalString();
                }
                return this.Syntax.InternalIsWellFormedOriginalString(this);
            }
            //--TRIMMABLE-BOUNDARY-END(794570653698)
            
            //--TRIMMABLE-BOUNDARY-START(798865620994)
            static /*bool */ IsWellFormedUriString(/*string?*/ uriString, /*UriKind*/ uriKind)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(798865620994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Uri?*/ let result;
                if (!$.$spu.System.Uri.TryCreate(uriString, uriKind, $.$ref(() => result, ($v) => result = $v, $.$spu.System.Uri)))
                {
                    return false;
                }
                return result.IsWellFormedOriginalString();
            }
            //--TRIMMABLE-BOUNDARY-END(798865620994)
            
            //--TRIMMABLE-BOUNDARY-START(704376340482)
            /*bool */ InternalIsWellFormedOriginalString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(704376340482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.UserDrivenParsing)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_UserDrivenParsing, $.$$.System.Object.GetType.call(this)));
                }
                /*fixed*/ 
                {
                    /*char**/ let str = $.$$.System.String.GetPinnableReference.call(this._string);
                    /*int*/ let idx = 0;
                    if (!this.IsAbsoluteUri)
                    {
                        if ($.$spu.System.Uri.CheckForColonInFirstPathSegment(this._string))
                        {
                            return false;
                        }
                        return (this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), this._string.length, /*\uFFFE*/ 65534) & (16/*Check.BackslashInPath*/ | 1/*Check.EscapedCanonical*/)) === 1/*Check.EscapedCanonical*/;
                    }
                    if (this.IsImplicitFile)
                    {
                        return false;
                    }
                    this.EnsureParseRemaining();
                    /*Flags*/ let nonCanonical = (this._flags & (8064n | 16888498602639360n));
                    if ((nonCanonical & (1125899906842624n | 2251799813685248n | 4503599627370496n | 9007199254740992n)) !== 0n)
                    {
                        if ((nonCanonical & (128n | 1125899906842624n)) === (128n | 1125899906842624n))
                        {
                            nonCanonical &= ~(128n | 1125899906842624n);
                        }
                        if ((nonCanonical & (1024n | 2251799813685248n)) === (1024n | 2251799813685248n))
                        {
                            nonCanonical &= ~(1024n | 2251799813685248n);
                        }
                        if ((nonCanonical & (2048n | 4503599627370496n)) === (2048n | 4503599627370496n))
                        {
                            nonCanonical &= ~(2048n | 4503599627370496n);
                        }
                        if ((nonCanonical & (4096n | 9007199254740992n)) === (4096n | 9007199254740992n))
                        {
                            nonCanonical &= ~(4096n | 9007199254740992n);
                        }
                    }
                    if ((nonCanonical & 8064n & (128n | 1024n | 2048n | 4096n)) !== 0n)
                    {
                        return false;
                    }
                    if (this.InFact(68719476736n))
                    {
                        idx = ((((this._info.Offset.Scheme + this._syntax.SchemeName.length) | 0) + 2) | 0);
                        if (idx >= this._info.Offset.User || $.$$.System.String.get_Chars.call(this._string, ((idx - 1) | 0)) === /*\\*/ 92 || $.$$.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92)
                        {
                            return false;
                        }
                        if (this.InFact(17592186044416n | 8796093022208n))
                        {
                            while(++idx < this._info.Offset.User && ($.$$.System.String.get_Chars.call(this._string, idx) === /*/*/ 47 || $.$$.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92))
                            {
                                return false;
                            }
                        }
                    }
                    if (this.InFact(16384n) && this._info.Offset.Query > this._info.Offset.Path)
                    {
                        return false;
                    }
                    if (this.InFact(32768n))
                    {
                        return false;
                    }
                    if (this.IsDosPath && $.$$.System.String.get_Chars.call(this._string, ((((this._info.Offset.Path + this.SecuredPathIndex) | 0) - 1) | 0)) === /*|*/ 124)
                    {
                        return false;
                    }
                    if ((this._flags & 2199023255552n) === 0n && this.HostType !== 4294967296n)
                    {
                        idx = this._info.Offset.User;
                        /*Check*/ let result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), this._info.Offset.Path, /*/*/ 47);
                        if (((result & (32/*Check.ReservedFound*/ | 16/*Check.BackslashInPath*/ | 1/*Check.EscapedCanonical*/)) !== 1/*Check.EscapedCanonical*/) && (!this.IriParsing || (result & (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) !== (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                        {
                            return false;
                        }
                    }
                    if ((this._flags & (1n | 68719476736n)) === (1n | 68719476736n))
                    {
                        idx = this._syntax.SchemeName.length;
                        while(str.GetAt(idx++) !== /*:*/ 58)
                        {
                        }
                        if (((idx + 1) | 0) >= this._string.length || str.GetAt(idx) !== /*/*/ 47 || str.GetAt(((idx + 1) | 0)) !== /*/*/ 47)
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(704376340482)
            
            //--TRIMMABLE-BOUNDARY-START(1013613985794)
            static /*string */ UnescapeDataString$2(/*string*/ stringToUnescape)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1013613985794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(stringToUnescape, "stringToUnescape");
                return $.$spu.System.Uri.UnescapeDataString($.$$.System.String.op_Implicit(stringToUnescape), stringToUnescape);
            }
            //--TRIMMABLE-BOUNDARY-END(1013613985794)
            
            //--TRIMMABLE-BOUNDARY-START(1009319018498)
            static /*string */ UnescapeDataString$1(/*ReadOnlySpan<char>*/ charsToUnescape)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1009319018498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spu.System.Uri.UnescapeDataString(charsToUnescape, null);
            }
            //--TRIMMABLE-BOUNDARY-END(1009319018498)
            
            //--TRIMMABLE-BOUNDARY-START(1005024051202)
            static /*string */ UnescapeDataString(/*ReadOnlySpan<char>*/ charsToUnescape, /*string?*/ backingString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1005024051202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(backingString === null || backingString.length === charsToUnescape.Length, "backingString is null || backingString.Length == charsToUnescape.Length");
                /*int*/ let indexOfFirstToUnescape = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, charsToUnescape, /*%*/ 37);
                if (indexOfFirstToUnescape < 0)
                {
                    return backingString ?? $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(charsToUnescape);
                }
                /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                vsb.EnsureCapacity(((charsToUnescape.Length - indexOfFirstToUnescape) | 0));
                $.$spu.System.UriHelper.UnescapeString$2(charsToUnescape.Slice$1(indexOfFirstToUnescape), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, null, false);
                /*string*/ let result = $.$$.System.String.Concat$8(charsToUnescape.Slice(0, indexOfFirstToUnescape), vsb.AsSpan());
                vsb.Dispose();
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(1005024051202)
            
            //--TRIMMABLE-BOUNDARY-START(996434116610)
            static /*bool */ TryUnescapeDataString(/*ReadOnlySpan<char>*/ charsToUnescape, /*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(996434116610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let indexOfFirstToUnescape = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, charsToUnescape, /*%*/ 37);
                if (indexOfFirstToUnescape < 0)
                {
                    if (charsToUnescape.TryCopyTo(destination))
                    {
                        charsWritten.$v = charsToUnescape.Length;
                        return true;
                    }
                    charsWritten.$v = 0;
                    return false;
                }
                /*scoped ValueStringBuilder*/ let vsb;
                /*bool*/ let overlapped = $.$$.System.MemoryExtensions.Overlaps$1($.$$.System.Char, charsToUnescape, $.$$.System.Span$$($.$$.System.Char).op_Implicit(destination)) && !$.$$.System.Runtime.CompilerServices.Unsafe.AreSame($.$$.System.Char, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Char, charsToUnescape), $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, destination));
                if (overlapped)
                {
                    vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                    vsb.EnsureCapacity(((charsToUnescape.Length - indexOfFirstToUnescape) | 0));
                }
                else 
                {
                    vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4(destination.Slice$1(indexOfFirstToUnescape));
                }
                $.$spu.System.UriHelper.UnescapeString$2(charsToUnescape.Slice$1(indexOfFirstToUnescape), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, null, false);
                /*int*/ let newLength = ((indexOfFirstToUnescape + vsb.Length) | 0);
                $.$$.System.Diagnostics.Debug.Assert$2(newLength <= charsToUnescape.Length, "newLength <= charsToUnescape.Length");
                if (destination.Length >= newLength)
                {
                    charsToUnescape.Slice(0, indexOfFirstToUnescape).CopyTo(destination);
                    if (overlapped)
                    {
                        vsb.AsSpan().CopyTo(destination.Slice$1(indexOfFirstToUnescape));
                        vsb.Dispose();
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.MemoryExtensions.Overlaps$1($.$$.System.Char, $.$$.System.Span$$($.$$.System.Char).op_Implicit(vsb.RawChars), $.$$.System.Span$$($.$$.System.Char).op_Implicit(destination)), "vsb.RawChars.Overlaps(destination)");
                    }
                    charsWritten.$v = newLength;
                    return true;
                }
                vsb.Dispose();
                charsWritten.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(996434116610)
            
            //--TRIMMABLE-BOUNDARY-START(261994708994)
            static /*string */ EscapeUriString(/*string*/ stringToEscape)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(261994708994);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$spu.System.UriHelper.EscapeString$2(stringToEscape, false, $.$spu.System.UriHelper.UnreservedReserved);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(261994708994)
            
            //--TRIMMABLE-BOUNDARY-START(249109807106)
            static /*string */ EscapeDataString$1(/*string*/ stringToEscape)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(249109807106);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$spu.System.UriHelper.EscapeString$2(stringToEscape, false, $.$spu.System.UriHelper.Unreserved);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249109807106)
            
            //--TRIMMABLE-BOUNDARY-START(244814839810)
            static /*string */ EscapeDataString(/*ReadOnlySpan<char>*/ charsToEscape)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(244814839810);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$spu.System.UriHelper.EscapeString(charsToEscape, false, $.$spu.System.UriHelper.Unreserved, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244814839810)
            
            //--TRIMMABLE-BOUNDARY-START(983549214722)
            static /*bool */ TryEscapeDataString(/*ReadOnlySpan<char>*/ charsToEscape, /*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(983549214722);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$spu.System.UriHelper.TryEscapeDataString(charsToEscape, destination, charsWritten);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(983549214722)
            
            //--TRIMMABLE-BOUNDARY-START(257699741698)
            /*string */ EscapeUnescapeIri(/*string*/ input, /*int*/ start, /*int*/ end, /*UriComponents*/ component)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699741698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*fixed*/ 
                {
                    /*char**/ let pInput = $.$$.System.String.GetPinnableReference.call(input);
                    return $.$spu.System.IriHelper.EscapeUnescapeIri(pInput, start, end, component);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257699741698)
            
            //--TRIMMABLE-BOUNDARY-START(85901049858)
            $ctor$9(/*Flags*/ flags, /*UriParser?*/ uriParser, /*string*/ uri)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85901049858);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._flags = flags;
                    this._syntax = uriParser;
                    this._string = uri;
                    if (uriParser === null)
                    {
                        this.DebugSetLeftCtor();
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(85901049858)
            
            //--TRIMMABLE-BOUNDARY-START(171800395778)
            static /*Uri? */ CreateHelper(/*string*/ uriString, /*bool*/ dontEscape, /*UriKind*/ uriKind, /*ref UriFormatException?*/ e, /*in UriCreationOptions*/ creationOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800395778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (uriKind < 0/*UriKind.RelativeOrAbsolute*/ || uriKind > 2/*UriKind.Relative*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_InvalidUriKind, $.$box(uriKind, $.$spu.System.UriKind)));
                }
                /*UriParser?*/ let syntax = null;
                /*Flags*/ let flags = 0n;
                /*ParsingError*/ let err = $.$spu.System.Uri.ParseScheme(uriString, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => flags, ($v) => flags = $v, null), $.$ref(() => syntax, ($v) => syntax = $v, $.$spu.System.UriParser));
                if (dontEscape)
                {
                    flags |= 34359738368n;
                }
                if (creationOptions.$v.DangerousDisablePathAndQueryCanonicalization)
                {
                    flags |= 36028797018963968n;
                }
                if (err !== 0/*ParsingError.None*/)
                {
                    if (uriKind !== 1/*UriKind.Absolute*/ && err <= 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                    {
                        return new $.$spu.System.Uri().$ctor$9((flags & 34359738368n), null, uriString);
                    }
                    return null;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(syntax !== null, "syntax != null");
                /*Uri*/ let result = new $.$spu.System.Uri().$ctor$9(flags, syntax, uriString);
                try
                {
                    result.InitializeUri(err, uriKind, e);
                    if (e.$v === null)
                    {
                        result.DebugSetLeftCtor();
                        return result;
                    }
                    return null;
                }
                catch(ee)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!syntax.IsSimple, "A UriPraser threw on InitializeAndValidate.");
                    e.$v = ee;
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171800395778)
            
            //--TRIMMABLE-BOUNDARY-START(889059934210)
            static /*Uri? */ ResolveHelper(/*Uri*/ baseUri, /*Uri?*/ relativeUri, /*ref string?*/ newUriString, /*ref bool*/ userEscaped)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(889059934210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!baseUri.IsNotAbsoluteUri && !baseUri.UserDrivenParsing, "Uri::ResolveHelper()|baseUri is not Absolute or is controlled by User Parser.");
                /*string*/ let relativeStr;
                if (!(relativeUri === null))
                {
                    if (relativeUri.IsAbsoluteUri)
                    {
                        return relativeUri;
                    }
                    relativeStr = relativeUri.OriginalString;
                    userEscaped.$v = relativeUri.UserEscaped;
                }
                else 
                {
                    relativeStr = $.$$.System.String.Empty;
                }
                if (relativeStr.length > 0 && ($.$spu.System.UriHelper.IsLWS($.$$.System.String.get_Chars.call(relativeStr, 0)) || $.$spu.System.UriHelper.IsLWS($.$$.System.String.get_Chars.call(relativeStr, ((relativeStr.length - 1) | 0)))))
                {
                    relativeStr = $.$$.System.String.Trim$2.call(relativeStr, $.$spu.System.UriHelper.s_WSchars);
                }
                if (relativeStr.length === 0)
                {
                    newUriString.$v = baseUri.GetParts(127/*UriComponents.AbsoluteUri*/, baseUri.UserEscaped ? 1/*UriFormat.UriEscaped*/ : 3/*UriFormat.SafeUnescaped*/);
                    return null;
                }
                if ($.$$.System.String.get_Chars.call(relativeStr, 0) === /*#*/ 35 && !baseUri.IsImplicitFile && baseUri.Syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/))
                {
                    newUriString.$v = baseUri.GetParts(127/*UriComponents.AbsoluteUri*/ & ~64/*UriComponents.Fragment*/, 1/*UriFormat.UriEscaped*/) + relativeStr;
                    return null;
                }
                if ($.$$.System.String.get_Chars.call(relativeStr, 0) === /*?*/ 63 && !baseUri.IsImplicitFile && baseUri.Syntax.InFact(32/*UriSyntaxFlags.MayHaveQuery*/))
                {
                    newUriString.$v = baseUri.GetParts(127/*UriComponents.AbsoluteUri*/ & ~32/*UriComponents.Query*/ & ~64/*UriComponents.Fragment*/, 1/*UriFormat.UriEscaped*/) + relativeStr;
                    return null;
                }
                if (relativeStr.length >= 3 && ($.$$.System.String.get_Chars.call(relativeStr, 1) === /*:*/ 58 || $.$$.System.String.get_Chars.call(relativeStr, 1) === /*|*/ 124) && $.$$.System.Char.IsAsciiLetter($.$$.System.String.get_Chars.call(relativeStr, 0)) && ($.$$.System.String.get_Chars.call(relativeStr, 2) === /*\\*/ 92 || $.$$.System.String.get_Chars.call(relativeStr, 2) === /*/*/ 47))
                {
                    if (baseUri.IsImplicitFile)
                    {
                        newUriString.$v = relativeStr;
                        return null;
                    }
                    else if (baseUri.Syntax.InFact(1048576/*UriSyntaxFlags.AllowDOSPath*/))
                    {
                        /*string*/ let prefix;
                        if (baseUri.InFact(68719476736n))
                        {
                            prefix = baseUri.Syntax.InFact(2097152/*UriSyntaxFlags.PathIsRooted*/) ? ":///" : "://";
                        }
                        else 
                        {
                            prefix = baseUri.Syntax.InFact(2097152/*UriSyntaxFlags.PathIsRooted*/) ? ":/" : ":";
                        }
                        newUriString.$v = baseUri.Scheme + prefix + relativeStr;
                        return null;
                    }
                }
                $.$spu.System.Uri.GetCombinedString(baseUri, relativeStr, userEscaped.$v, newUriString);
                if ($.$$.System.Object.ReferenceEquals(newUriString.$v, baseUri._string))
                {
                    return baseUri;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(889059934210)
            
            //--TRIMMABLE-BOUNDARY-START(639951831042)
            /*string */ GetRelativeSerializationString(/*UriFormat*/ format)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(639951831042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (format === 1/*UriFormat.UriEscaped*/)
                {
                    return $.$spu.System.UriHelper.EscapeString$2(this._string, true, $.$spu.System.UriHelper.UnreservedReserved);
                }
                else if (format === 2/*UriFormat.Unescaped*/)
                {
                    return $.$spu.System.Uri.UnescapeDataString$2(this._string);
                }
                else if (format === 3/*UriFormat.SafeUnescaped*/)
                {
                    if (this._string.length === 0)
                    {
                        return $.$$.System.String.Empty;
                    }
                    /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                    $.$spu.System.UriHelper.UnescapeString$2($.$$.System.String.op_Implicit(this._string), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 3/*UnescapeMode.EscapeUnescape*/, null, false);
                    return $.$spu.System.Text.ValueStringBuilder.ToString.call(vsb);
                }
                else 
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("format");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(639951831042)
            
            //--TRIMMABLE-BOUNDARY-START(597002158082)
            /*string */ GetComponentsHelper(/*UriComponents*/ uriComponents, /*UriFormat*/ uriFormat)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(597002158082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (uriComponents === 1/*UriComponents.Scheme*/)
                {
                    return this._syntax.SchemeName;
                }
                if ((uriComponents & -2147483648/*UriComponents.SerializationInfoString*/) !== 0)
                {
                    uriComponents |= 127/*UriComponents.AbsoluteUri*/;
                }
                this.EnsureParseRemaining();
                if ((uriComponents & 256/*UriComponents.NormalizedHost*/) !== 0)
                {
                    uriComponents |= 4/*UriComponents.Host*/;
                }
                if ((uriComponents & 4/*UriComponents.Host*/) !== 0)
                {
                    this.EnsureHostString(true);
                }
                if (uriComponents === 8/*UriComponents.Port*/ || uriComponents === 128/*UriComponents.StrongPort*/)
                {
                    if (((this._flags & 549755813888n) !== 0n) || (uriComponents === 128/*UriComponents.StrongPort*/ && this._syntax.DefaultPort !== -1/*UriParser.NoDefaultPort*/))
                    {
                        return $.$$.System.UInt16.ToString$1.call(this._info.Offset.PortValue, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    }
                    return $.$$.System.String.Empty;
                }
                if ((uriComponents & 128/*UriComponents.StrongPort*/) !== 0)
                {
                    uriComponents |= 8/*UriComponents.Port*/;
                }
                if (uriComponents === 4/*UriComponents.Host*/ && (uriFormat === 1/*UriFormat.UriEscaped*/ || ((this._flags & (4n | 256n)) === 0n)))
                {
                    this.EnsureHostString(false);
                    return this._info.Host;
                }
                switch(uriFormat)
                {
                    case 1/*UriFormat.UriEscaped*/:
                    return this.GetEscapedParts(uriComponents);
                    case 32767/*V1ToStringUnescape*/:
                    case 3/*UriFormat.SafeUnescaped*/:
                    case 2/*UriFormat.Unescaped*/:
                    return this.GetUnescapedParts(uriComponents, uriFormat);
                    default:
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("uriFormat");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(597002158082)
            
            //--TRIMMABLE-BOUNDARY-START(725851176962)
            /*bool */ IsBaseOf(/*Uri*/ uri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(725851176962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                if (!this.IsAbsoluteUri)
                {
                    return false;
                }
                if (this.Syntax.IsSimple)
                {
                    return this.IsBaseOfHelper(uri);
                }
                return this.Syntax.InternalIsBaseOf(this, uri);
            }
            //--TRIMMABLE-BOUNDARY-END(725851176962)
            
            //--TRIMMABLE-BOUNDARY-START(730146144258)
            /*bool */ IsBaseOfHelper(/*Uri*/ uriLink)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(730146144258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*UriComponents*/ let ComponentsToCompare = 127/*UriComponents.AbsoluteUri*/ & ~64/*UriComponents.Fragment*/ & ~2/*UriComponents.UserInfo*/;
                if (!this.IsAbsoluteUri || this.UserDrivenParsing)
                {
                    return false;
                }
                if (!uriLink.IsAbsoluteUri)
                {
                    /*string?*/ let newUriString = null;
                    /*bool*/ let dontEscape = false;
                    uriLink = $.$spu.System.Uri.ResolveHelper(this, uriLink, $.$ref(() => newUriString, ($v) => newUriString = $v, $.$$.System.String), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => dontEscape, ($v) => dontEscape = $v, null));
                    if (uriLink === null)
                    {
                        /*UriFormatException?*/ let e = null;
                        let $v4 = new $.$spu.System.UriCreationOptions();
                        uriLink = $.$spu.System.Uri.CreateHelper(newUriString, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException), $.$ref(() => $v4, ($v) => $v4 = $v));
                        if (e !== null)
                        {
                            return false;
                        }
                    }
                }
                if ($.$$.System.String.op_Inequality(this.Syntax.SchemeName, uriLink.Syntax.SchemeName))
                {
                    return false;
                }
                /*string*/ let self = this.GetParts(ComponentsToCompare, 3/*UriFormat.SafeUnescaped*/);
                /*string*/ let other = uriLink.GetParts(ComponentsToCompare, 3/*UriFormat.SafeUnescaped*/);
                {
                    /*fixed*/ 
                    {
                        /*char**/ let selfPtr = $.$$.System.String.GetPinnableReference.call(self);
                        /*fixed*/ 
                        {
                            /*char**/ let otherPtr = $.$$.System.String.GetPinnableReference.call(other);
                            return $.$spu.System.UriHelper.TestForSubPath(selfPtr, self.length, otherPtr, other.length, this.IsUncOrDosPath || uriLink.IsUncOrDosPath);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(730146144258)
            
            //--TRIMMABLE-BOUNDARY-START(188980264962)
            /*void */ CreateThisFromUri(/*Uri*/ otherUri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980264962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.DebugAssertInCtor();
                this._flags = otherUri._flags;
                if (this.InFact(140737488355328n))
                {
                    this._info = otherUri._info;
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!this.InFact(562949953421312n) || otherUri.IsNotAbsoluteUri, "!InFact(Flags.HasUnicode) || otherUri.IsNotAbsoluteUri");
                    this._info = null;
                    if (this.InFact(70368744177664n))
                    {
                        this._flags &= ~(70368744177664n | 140737488355328n | 4294967295n);
                        /*int*/ let portIndex = otherUri._info.Offset.Path;
                        if (this.InFact(549755813888n))
                        {
                            while($.$$.System.String.get_Chars.call(otherUri._string, portIndex) !== /*:*/ 58 && portIndex > otherUri._info.Offset.Host)
                            {
                                portIndex--;
                            }
                            if ($.$$.System.String.get_Chars.call(otherUri._string, portIndex) !== /*:*/ 58)
                            {
                                $.$$.System.Diagnostics.Debug.Fail$1("Uri failed to locate custom port at index: " + portIndex);
                                portIndex = otherUri._info.Offset.Path;
                            }
                        }
                        this._flags |= $.$cast(portIndex, $.$spu.System.Uri.Flags);
                    }
                }
                this._syntax = otherUri._syntax;
                this._string = otherUri._string;
                this._originalUnicodeString = otherUri._originalUnicodeString;
            }
            //--TRIMMABLE-BOUNDARY-END(188980264962)
            
            //--TRIMMABLE-BOUNDARY-START(1022203920386)
            /*string*/ static UriSchemeFile = null;
            //--TRIMMABLE-BOUNDARY-END(1022203920386)
            
            //--TRIMMABLE-BOUNDARY-START(1026498887682)
            /*string*/ static UriSchemeFtp = null;
            //--TRIMMABLE-BOUNDARY-END(1026498887682)
            
            //--TRIMMABLE-BOUNDARY-START(1069448560642)
            /*string*/ static UriSchemeSftp = null;
            //--TRIMMABLE-BOUNDARY-END(1069448560642)
            
            //--TRIMMABLE-BOUNDARY-START(1030793854978)
            /*string*/ static UriSchemeFtps = null;
            //--TRIMMABLE-BOUNDARY-END(1030793854978)
            
            //--TRIMMABLE-BOUNDARY-START(1035088822274)
            /*string*/ static UriSchemeGopher = null;
            //--TRIMMABLE-BOUNDARY-END(1035088822274)
            
            //--TRIMMABLE-BOUNDARY-START(1039383789570)
            /*string*/ static UriSchemeHttp = null;
            //--TRIMMABLE-BOUNDARY-END(1039383789570)
            
            //--TRIMMABLE-BOUNDARY-START(1043678756866)
            /*string*/ static UriSchemeHttps = null;
            //--TRIMMABLE-BOUNDARY-END(1043678756866)
            
            //--TRIMMABLE-BOUNDARY-START(1082333462530)
            /*string*/ static UriSchemeWs = null;
            //--TRIMMABLE-BOUNDARY-END(1082333462530)
            
            //--TRIMMABLE-BOUNDARY-START(1086628429826)
            /*string*/ static UriSchemeWss = null;
            //--TRIMMABLE-BOUNDARY-END(1086628429826)
            
            //--TRIMMABLE-BOUNDARY-START(1047973724162)
            /*string*/ static UriSchemeMailto = null;
            //--TRIMMABLE-BOUNDARY-END(1047973724162)
            
            //--TRIMMABLE-BOUNDARY-START(1060858626050)
            /*string*/ static UriSchemeNews = null;
            //--TRIMMABLE-BOUNDARY-END(1060858626050)
            
            //--TRIMMABLE-BOUNDARY-START(1065153593346)
            /*string*/ static UriSchemeNntp = null;
            //--TRIMMABLE-BOUNDARY-END(1065153593346)
            
            //--TRIMMABLE-BOUNDARY-START(1073743527938)
            /*string*/ static UriSchemeSsh = null;
            //--TRIMMABLE-BOUNDARY-END(1073743527938)
            
            //--TRIMMABLE-BOUNDARY-START(1078038495234)
            /*string*/ static UriSchemeTelnet = null;
            //--TRIMMABLE-BOUNDARY-END(1078038495234)
            
            //--TRIMMABLE-BOUNDARY-START(1056563658754)
            /*string*/ static UriSchemeNetTcp = null;
            //--TRIMMABLE-BOUNDARY-END(1056563658754)
            
            //--TRIMMABLE-BOUNDARY-START(1052268691458)
            /*string*/ static UriSchemeNetPipe = null;
            //--TRIMMABLE-BOUNDARY-END(1052268691458)
            
            //--TRIMMABLE-BOUNDARY-START(910534770690)
            /*string*/ static SchemeDelimiter = null;
            //--TRIMMABLE-BOUNDARY-END(910534770690)
            
            //--TRIMMABLE-BOUNDARY-START(914829737986)
            /*int*/ static SchemeLengthLimit = 1024;
            //--TRIMMABLE-BOUNDARY-END(914829737986)
            
            //--TRIMMABLE-BOUNDARY-START(927714639874)
            /*int*/ static StackallocThreshold = 512;
            //--TRIMMABLE-BOUNDARY-END(927714639874)
            
            //--TRIMMABLE-BOUNDARY-START(17181573122)
            /*string*/ _string = null;
            //--TRIMMABLE-BOUNDARY-END(17181573122)
            
            //--TRIMMABLE-BOUNDARY-START(12886605826)
            /*string*/ _originalUnicodeString = null;
            //--TRIMMABLE-BOUNDARY-END(12886605826)
            
            //--TRIMMABLE-BOUNDARY-START(21476540418)
            /*UriParser*/ _syntax = null;
            //--TRIMMABLE-BOUNDARY-END(21476540418)
            
            //--TRIMMABLE-BOUNDARY-START(4296671234)
            /*Flags*/ _flags = 0n;
            //--TRIMMABLE-BOUNDARY-END(4296671234)
            
            //--TRIMMABLE-BOUNDARY-START(8591638530)
            /*UriInfo*/ _info = null;
            //--TRIMMABLE-BOUNDARY-END(8591638530)
            
            //--TRIMMABLE-BOUNDARY-START(1835010)
            static $_Flags;
            static get Flags()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_Flags ??= $asm.$nstr("$spu.System.Uri.Flags", ($self) => class Flags extends $.$$.System.Enum
                {
                    static Zero = 0n;
                    static SchemeNotCanonical = 1n;
                    static UserNotCanonical = 2n;
                    static HostNotCanonical = 4n;
                    static PortNotCanonical = 8n;
                    static PathNotCanonical = 16n;
                    static QueryNotCanonical = 32n;
                    static FragmentNotCanonical = 64n;
                    static CannotDisplayCanonical = 127n;
                    static E_UserNotCanonical = 128n;
                    static E_HostNotCanonical = 256n;
                    static E_PortNotCanonical = 512n;
                    static E_PathNotCanonical = 1024n;
                    static E_QueryNotCanonical = 2048n;
                    static E_FragmentNotCanonical = 4096n;
                    static E_CannotDisplayCanonical = 8064n;
                    static ShouldBeCompressed = 8192n;
                    static FirstSlashAbsent = 16384n;
                    static BackslashInPath = 32768n;
                    static IndexMask = 4294967295n;
                    static HostTypeMask = 30064771072n;
                    static HostNotParsed = 0n;
                    static IPv6HostType = 4294967296n;
                    static IPv4HostType = 8589934592n;
                    static DnsHostType = 12884901888n;
                    static UncHostType = 17179869184n;
                    static BasicHostType = 21474836480n;
                    static UnusedHostType = 25769803776n;
                    static UnknownHostType = 30064771072n;
                    static UserEscaped = 34359738368n;
                    static AuthorityFound = 68719476736n;
                    static HasUserInfo = 137438953472n;
                    static LoopbackHost = 274877906944n;
                    static NotDefaultPort = 549755813888n;
                    static UserDrivenParsing = 1099511627776n;
                    static CanonicalDnsHost = 2199023255552n;
                    static ErrorOrParsingRecursion = 4398046511104n;
                    static DosPath = 8796093022208n;
                    static UncPath = 17592186044416n;
                    static ImplicitFile = 35184372088832n;
                    static MinimalUriInfoSet = 70368744177664n;
                    static AllUriInfoSet = 140737488355328n;
                    static IdnHost = 281474976710656n;
                    static HasUnicode = 562949953421312n;
                    static UserIriCanonical = 1125899906842624n;
                    static PathIriCanonical = 2251799813685248n;
                    static QueryIriCanonical = 4503599627370496n;
                    static FragmentIriCanonical = 9007199254740992n;
                    static IriCanonical = 16888498602639360n;
                    static UnixPath = 18014398509481984n;
                    static DisablePathAndQueryCanonicalization = 36028797018963968n;
                    static CustomParser_ParseMinimalAlreadyCalled = 72057594037927936n;
                    static Debug_LeftConstructor = 144115188075855872n;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(1835010);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "Zero": 0n,
                            "SchemeNotCanonical": 1n,
                            "UserNotCanonical": 2n,
                            "HostNotCanonical": 4n,
                            "PortNotCanonical": 8n,
                            "PathNotCanonical": 16n,
                            "QueryNotCanonical": 32n,
                            "FragmentNotCanonical": 64n,
                            "CannotDisplayCanonical": 127n,
                            "E_UserNotCanonical": 128n,
                            "E_HostNotCanonical": 256n,
                            "E_PortNotCanonical": 512n,
                            "E_PathNotCanonical": 1024n,
                            "E_QueryNotCanonical": 2048n,
                            "E_FragmentNotCanonical": 4096n,
                            "E_CannotDisplayCanonical": 8064n,
                            "ShouldBeCompressed": 8192n,
                            "FirstSlashAbsent": 16384n,
                            "BackslashInPath": 32768n,
                            "IndexMask": 4294967295n,
                            "HostTypeMask": 30064771072n,
                            "HostNotParsed": 0n,
                            "IPv6HostType": 4294967296n,
                            "IPv4HostType": 8589934592n,
                            "DnsHostType": 12884901888n,
                            "UncHostType": 17179869184n,
                            "BasicHostType": 21474836480n,
                            "UnusedHostType": 25769803776n,
                            "UnknownHostType": 30064771072n,
                            "UserEscaped": 34359738368n,
                            "AuthorityFound": 68719476736n,
                            "HasUserInfo": 137438953472n,
                            "LoopbackHost": 274877906944n,
                            "NotDefaultPort": 549755813888n,
                            "UserDrivenParsing": 1099511627776n,
                            "CanonicalDnsHost": 2199023255552n,
                            "ErrorOrParsingRecursion": 4398046511104n,
                            "DosPath": 8796093022208n,
                            "UncPath": 17592186044416n,
                            "ImplicitFile": 35184372088832n,
                            "MinimalUriInfoSet": 70368744177664n,
                            "AllUriInfoSet": 140737488355328n,
                            "IdnHost": 281474976710656n,
                            "HasUnicode": 562949953421312n,
                            "UserIriCanonical": 1125899906842624n,
                            "PathIriCanonical": 2251799813685248n,
                            "QueryIriCanonical": 4503599627370496n,
                            "FragmentIriCanonical": 9007199254740992n,
                            "IriCanonical": 16888498602639360n,
                            "UnixPath": 18014398509481984n,
                            "DisablePathAndQueryCanonicalization": 36028797018963968n,
                            "CustomParser_ParseMinimalAlreadyCalled": 72057594037927936n,
                            "Debug_LeftConstructor": 144115188075855872n
                        };
                    }
                    static $h = 1835010;
                    static $z = 8;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.UInt64; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 983041,
  "l": [
//--TRIMMABLE-BOUNDARY-START(231930068994),
    {
      "t": 1835010,
      "n": "Zero",
      "d": 1835010,
      "h": 231930068994,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(231930068994),
//--TRIMMABLE-BOUNDARY-START(184685428738),
    {
      "t": 1835010,
      "n": "SchemeNotCanonical",
      "d": 1835010,
      "h": 184685428738,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(184685428738),
//--TRIMMABLE-BOUNDARY-START(227635101698),
    {
      "t": 1835010,
      "n": "UserNotCanonical",
      "d": 1835010,
      "h": 227635101698,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(227635101698),
//--TRIMMABLE-BOUNDARY-START(111670984706),
    {
      "t": 1835010,
      "n": "HostNotCanonical",
      "d": 1835010,
      "h": 111670984706,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111670984706),
//--TRIMMABLE-BOUNDARY-START(171800526850),
    {
      "t": 1835010,
      "n": "PortNotCanonical",
      "d": 1835010,
      "h": 171800526850,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171800526850),
//--TRIMMABLE-BOUNDARY-START(167505559554),
    {
      "t": 1835010,
      "n": "PathNotCanonical",
      "d": 1835010,
      "h": 167505559554,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167505559554),
//--TRIMMABLE-BOUNDARY-START(180390461442),
    {
      "t": 1835010,
      "n": "QueryNotCanonical",
      "d": 1835010,
      "h": 180390461442,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180390461442),
//--TRIMMABLE-BOUNDARY-START(98786082818),
    {
      "t": 1835010,
      "n": "FragmentNotCanonical",
      "d": 1835010,
      "h": 98786082818,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98786082818),
//--TRIMMABLE-BOUNDARY-START(25771638786),
    {
      "t": 1835010,
      "n": "CannotDisplayCanonical",
      "d": 1835010,
      "h": 25771638786,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771638786),
//--TRIMMABLE-BOUNDARY-START(81606213634),
    {
      "t": 1835010,
      "n": "E_UserNotCanonical",
      "d": 1835010,
      "h": 81606213634,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81606213634),
//--TRIMMABLE-BOUNDARY-START(64426344450),
    {
      "t": 1835010,
      "n": "E_HostNotCanonical",
      "d": 1835010,
      "h": 64426344450,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64426344450),
//--TRIMMABLE-BOUNDARY-START(73016279042),
    {
      "t": 1835010,
      "n": "E_PortNotCanonical",
      "d": 1835010,
      "h": 73016279042,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73016279042),
//--TRIMMABLE-BOUNDARY-START(68721311746),
    {
      "t": 1835010,
      "n": "E_PathNotCanonical",
      "d": 1835010,
      "h": 68721311746,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68721311746),
//--TRIMMABLE-BOUNDARY-START(77311246338),
    {
      "t": 1835010,
      "n": "E_QueryNotCanonical",
      "d": 1835010,
      "h": 77311246338,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77311246338),
//--TRIMMABLE-BOUNDARY-START(60131377154),
    {
      "t": 1835010,
      "n": "E_FragmentNotCanonical",
      "d": 1835010,
      "h": 60131377154,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60131377154),
//--TRIMMABLE-BOUNDARY-START(55836409858),
    {
      "t": 1835010,
      "n": "E_CannotDisplayCanonical",
      "d": 1835010,
      "h": 55836409858,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836409858),
//--TRIMMABLE-BOUNDARY-START(188980396034),
    {
      "t": 1835010,
      "n": "ShouldBeCompressed",
      "d": 1835010,
      "h": 188980396034,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(188980396034),
//--TRIMMABLE-BOUNDARY-START(90196148226),
    {
      "t": 1835010,
      "n": "FirstSlashAbsent",
      "d": 1835010,
      "h": 90196148226,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90196148226),
//--TRIMMABLE-BOUNDARY-START(17181704194),
    {
      "t": 1835010,
      "n": "BackslashInPath",
      "d": 1835010,
      "h": 17181704194,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181704194),
//--TRIMMABLE-BOUNDARY-START(133145821186),
    {
      "t": 1835010,
      "n": "IndexMask",
      "d": 1835010,
      "h": 133145821186,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133145821186),
//--TRIMMABLE-BOUNDARY-START(120260919298),
    {
      "t": 1835010,
      "n": "HostTypeMask",
      "d": 1835010,
      "h": 120260919298,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120260919298),
//--TRIMMABLE-BOUNDARY-START(115965952002),
    {
      "t": 1835010,
      "n": "HostNotParsed",
      "d": 1835010,
      "h": 115965952002,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115965952002),
//--TRIMMABLE-BOUNDARY-START(141735755778),
    {
      "t": 1835010,
      "n": "IPv6HostType",
      "d": 1835010,
      "h": 141735755778,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141735755778),
//--TRIMMABLE-BOUNDARY-START(137440788482),
    {
      "t": 1835010,
      "n": "IPv4HostType",
      "d": 1835010,
      "h": 137440788482,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137440788482),
//--TRIMMABLE-BOUNDARY-START(47246475266),
    {
      "t": 1835010,
      "n": "DnsHostType",
      "d": 1835010,
      "h": 47246475266,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246475266),
//--TRIMMABLE-BOUNDARY-START(193275363330),
    {
      "t": 1835010,
      "n": "UncHostType",
      "d": 1835010,
      "h": 193275363330,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(193275363330),
//--TRIMMABLE-BOUNDARY-START(21476671490),
    {
      "t": 1835010,
      "n": "BasicHostType",
      "d": 1835010,
      "h": 21476671490,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476671490),
//--TRIMMABLE-BOUNDARY-START(210455232514),
    {
      "t": 1835010,
      "n": "UnusedHostType",
      "d": 1835010,
      "h": 210455232514,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(210455232514),
//--TRIMMABLE-BOUNDARY-START(206160265218),
    {
      "t": 1835010,
      "n": "UnknownHostType",
      "d": 1835010,
      "h": 206160265218,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(206160265218),
//--TRIMMABLE-BOUNDARY-START(219045167106),
    {
      "t": 1835010,
      "n": "UserEscaped",
      "d": 1835010,
      "h": 219045167106,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(219045167106),
//--TRIMMABLE-BOUNDARY-START(12886736898),
    {
      "t": 1835010,
      "n": "AuthorityFound",
      "d": 1835010,
      "h": 12886736898,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886736898),
//--TRIMMABLE-BOUNDARY-START(107376017410),
    {
      "t": 1835010,
      "n": "HasUserInfo",
      "d": 1835010,
      "h": 107376017410,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107376017410),
//--TRIMMABLE-BOUNDARY-START(150325690370),
    {
      "t": 1835010,
      "n": "LoopbackHost",
      "d": 1835010,
      "h": 150325690370,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150325690370),
//--TRIMMABLE-BOUNDARY-START(158915624962),
    {
      "t": 1835010,
      "n": "NotDefaultPort",
      "d": 1835010,
      "h": 158915624962,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158915624962),
//--TRIMMABLE-BOUNDARY-START(214750199810),
    {
      "t": 1835010,
      "n": "UserDrivenParsing",
      "d": 1835010,
      "h": 214750199810,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(214750199810),
//--TRIMMABLE-BOUNDARY-START(30066606082),
    {
      "t": 1835010,
      "n": "CanonicalDnsHost",
      "d": 1835010,
      "h": 30066606082,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066606082),
//--TRIMMABLE-BOUNDARY-START(85901180930),
    {
      "t": 1835010,
      "n": "ErrorOrParsingRecursion",
      "d": 1835010,
      "h": 85901180930,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85901180930),
//--TRIMMABLE-BOUNDARY-START(51541442562),
    {
      "t": 1835010,
      "n": "DosPath",
      "d": 1835010,
      "h": 51541442562,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541442562),
//--TRIMMABLE-BOUNDARY-START(197570330626),
    {
      "t": 1835010,
      "n": "UncPath",
      "d": 1835010,
      "h": 197570330626,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(197570330626),
//--TRIMMABLE-BOUNDARY-START(128850853890),
    {
      "t": 1835010,
      "n": "ImplicitFile",
      "d": 1835010,
      "h": 128850853890,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128850853890),
//--TRIMMABLE-BOUNDARY-START(154620657666),
    {
      "t": 1835010,
      "n": "MinimalUriInfoSet",
      "d": 1835010,
      "h": 154620657666,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154620657666),
//--TRIMMABLE-BOUNDARY-START(8591769602),
    {
      "t": 1835010,
      "n": "AllUriInfoSet",
      "d": 1835010,
      "h": 8591769602,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591769602),
//--TRIMMABLE-BOUNDARY-START(124555886594),
    {
      "t": 1835010,
      "n": "IdnHost",
      "d": 1835010,
      "h": 124555886594,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124555886594),
//--TRIMMABLE-BOUNDARY-START(103081050114),
    {
      "t": 1835010,
      "n": "HasUnicode",
      "d": 1835010,
      "h": 103081050114,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103081050114),
//--TRIMMABLE-BOUNDARY-START(223340134402),
    {
      "t": 1835010,
      "n": "UserIriCanonical",
      "d": 1835010,
      "h": 223340134402,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(223340134402),
//--TRIMMABLE-BOUNDARY-START(163210592258),
    {
      "t": 1835010,
      "n": "PathIriCanonical",
      "d": 1835010,
      "h": 163210592258,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163210592258),
//--TRIMMABLE-BOUNDARY-START(176095494146),
    {
      "t": 1835010,
      "n": "QueryIriCanonical",
      "d": 1835010,
      "h": 176095494146,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176095494146),
//--TRIMMABLE-BOUNDARY-START(94491115522),
    {
      "t": 1835010,
      "n": "FragmentIriCanonical",
      "d": 1835010,
      "h": 94491115522,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94491115522),
//--TRIMMABLE-BOUNDARY-START(146030723074),
    {
      "t": 1835010,
      "n": "IriCanonical",
      "d": 1835010,
      "h": 146030723074,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146030723074),
//--TRIMMABLE-BOUNDARY-START(201865297922),
    {
      "t": 1835010,
      "n": "UnixPath",
      "d": 1835010,
      "h": 201865297922,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(201865297922),
//--TRIMMABLE-BOUNDARY-START(42951507970),
    {
      "t": 1835010,
      "n": "DisablePathAndQueryCanonicalization",
      "d": 1835010,
      "h": 42951507970,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951507970),
//--TRIMMABLE-BOUNDARY-START(34361573378),
    {
      "t": 1835010,
      "n": "CustomParser_ParseMinimalAlreadyCalled",
      "d": 1835010,
      "h": 34361573378,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361573378),
//--TRIMMABLE-BOUNDARY-START(38656540674),
    {
      "t": 1835010,
      "n": "Debug_LeftConstructor",
      "d": 1835010,
      "h": 38656540674,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656540674)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802306),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1835010,
      "h": 4296802306,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296802306)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "d": 1703938,
  "h": 1835010,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Uri.Flags`; }
                }, $cls, ($v) => $cls.$_Flags = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1835010)
            
            //--TRIMMABLE-BOUNDARY-START(206160134146)
            /*void */ DebugSetLeftCtor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160134146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._flags |= 144115188075855872n;
                this.AssertInvariants();
            }
            //--TRIMMABLE-BOUNDARY-END(206160134146)
            
            //--TRIMMABLE-BOUNDARY-START(98785951746)
            /*void */ AssertInvariants()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785951746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this.InFact(70368744177664n) === (!(this._info === null)), "InFact(Flags.MinimalUriInfoSet) == (_info is not null)");
                let info;
                if ($.$is(this._info, $.$spu.System.Uri.UriInfo, { set $v(v){ info = v; } }))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this.IsAbsoluteUri, "IsAbsoluteUri");
                    /*Offset*/ let offset = info.Offset;
                    $.$$.System.Diagnostics.Debug.Assert$2(offset.Scheme >= 0, "offset.Scheme >= 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(offset.User >= 0 && offset.User >= offset.Scheme, "offset.User >= 0 && offset.User >= offset.Scheme");
                    $.$$.System.Diagnostics.Debug.Assert$2(offset.Host >= 0 && offset.Host >= offset.User, "offset.Host >= 0 && offset.Host >= offset.User");
                    $.$$.System.Diagnostics.Debug.Assert$2(offset.Path >= 0, "offset.Path >= 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(offset.End >= 0 && offset.End >= offset.Path, "offset.End >= 0 && offset.End >= offset.Path");
                    if (this.InFact(140737488355328n))
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(offset.Path >= offset.Host, "offset.Path >= offset.Host");
                        $.$$.System.Diagnostics.Debug.Assert$2(offset.Query >= 0 && offset.Query >= offset.Path, "offset.Query >= 0 && offset.Query >= offset.Path");
                        $.$$.System.Diagnostics.Debug.Assert$2(offset.Fragment >= 0 && offset.Fragment >= offset.Query, "offset.Fragment >= 0 && offset.Fragment >= offset.Query");
                        $.$$.System.Diagnostics.Debug.Assert$2(offset.End >= offset.Fragment && offset.End <= this._string.length, "offset.End >= offset.Fragment && offset.End <= _string.Length");
                    }
                    else 
                    {
                        if (!this.InFact(562949953421312n))
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(offset.Path >= offset.Host, "offset.Path >= offset.Host");
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(offset.Query === 0, "offset.Query == 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(offset.Fragment === 0, "offset.Fragment == 0");
                    }
                }
                else 
                {
                    if (this.IsAbsoluteUri && this.IriParsing)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Text.Ascii.IsValid$3($.$$.System.String.op_Implicit(this._string)), "Ascii.IsValid(_string)");
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785951746)
            
            //--TRIMMABLE-BOUNDARY-START(201865166850)
            /*void */ DebugAssertInCtor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865166850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2((this._flags & 144115188075855872n) === 0n, "(_flags & Flags.Debug_LeftConstructor) == 0");
            }
            //--TRIMMABLE-BOUNDARY-END(201865166850)
            
            //--TRIMMABLE-BOUNDARY-START(2031618)
            static $_UriInfo;
            static get UriInfo()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_UriInfo ??= $asm.$ncls("$spu.System.Uri.UriInfo", ($self) => class UriInfo extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(34361769986)
                    /*Offset*/ Offset;
                    //--TRIMMABLE-BOUNDARY-END(34361769986)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951704578)
                    /*string?*/ String = null;
                    //--TRIMMABLE-BOUNDARY-END(42951704578)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476868098)
                    /*string?*/ Host = null;
                    //--TRIMMABLE-BOUNDARY-END(21476868098)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771835394)
                    /*string?*/ IdnHost = null;
                    //--TRIMMABLE-BOUNDARY-END(25771835394)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656737282)
                    /*string?*/ PathAndQuery = null;
                    //--TRIMMABLE-BOUNDARY-END(38656737282)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296998914)
                    /*MoreInfo?*/ _moreInfo = null;
                    //--TRIMMABLE-BOUNDARY-END(4296998914)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066802690)
                    /*MoreInfo */ get MoreInfo()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181900802);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._moreInfo === null)
                        {
                            $.$$.System.Threading.Interlocked.CompareExchange$14($.$spu.System.Uri.MoreInfo, $.$ref(() => this._moreInfo, ($v) => this._moreInfo = $v, $.$spu.System.Uri.MoreInfo), new $.$spu.System.Uri.MoreInfo().$ctor$1(), null);
                        }
                        return this._moreInfo;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066802690)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591966210)
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591966210)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(34361769986)
                        this.Offset = $.$default($.$spu.System.Uri.Offset);
                        //--TRIMMABLE-BOUNDARY-END(34361769986)
                        
                    }
                    static $h = 2031618;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066802690),
    {
      "p": 1900546,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181900802,
        "f": 50331649
      },
      "n": "MoreInfo",
      "d": 2031618,
      "h": 30066802690,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066802690)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361769986),
    {
      "t": 1966082,
      "n": "Offset",
      "d": 2031618,
      "h": 34361769986,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(34361769986),
//--TRIMMABLE-BOUNDARY-START(42951704578),
    {
      "t": 1310721,
      "n": "String",
      "d": 2031618,
      "h": 42951704578,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(42951704578),
//--TRIMMABLE-BOUNDARY-START(21476868098),
    {
      "t": 1310721,
      "n": "Host",
      "d": 2031618,
      "h": 21476868098,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(21476868098),
//--TRIMMABLE-BOUNDARY-START(25771835394),
    {
      "t": 1310721,
      "n": "IdnHost",
      "d": 2031618,
      "h": 25771835394,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(25771835394),
//--TRIMMABLE-BOUNDARY-START(38656737282),
    {
      "t": 1310721,
      "n": "PathAndQuery",
      "d": 2031618,
      "h": 38656737282,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(38656737282),
//--TRIMMABLE-BOUNDARY-START(4296998914),
    {
      "t": 1900546,
      "n": "_moreInfo",
      "d": 2031618,
      "h": 4296998914,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(4296998914)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591966210),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2031618,
      "h": 8591966210,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591966210)
  ],
  "d": 1703938,
  "h": 2031618
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Uri.UriInfo`; }
                }, $cls, ($v) => $cls.$_UriInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2031618)
            
            //--TRIMMABLE-BOUNDARY-START(1966082)
            static $_Offset;
            static get Offset()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_Offset ??= $asm.$nstr("$spu.System.Uri.Offset", ($self) => class Offset extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(34361704450)
                    /*int*/  get Scheme() { return this.$getField(0, $.$$.System.Int32); }
                    /*int*/  set Scheme(value) { this.$setField(0, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(34361704450)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656671746)
                    /*int*/  get User() { return this.$getField(4, $.$$.System.Int32); }
                    /*int*/  set User(value) { this.$setField(4, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(38656671746)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181835266)
                    /*int*/  get Host() { return this.$getField(8, $.$$.System.Int32); }
                    /*int*/  set Host(value) { this.$setField(8, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(17181835266)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771769858)
                    /*ushort*/  get PortValue() { return this.$getField(12, $.$$.System.UInt16); }
                    /*ushort*/  set PortValue(value) { this.$setField(12, $.$$.System.UInt16, value); }
                    //--TRIMMABLE-BOUNDARY-END(25771769858)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476802562)
                    /*int*/  get Path() { return this.$getField(14, $.$$.System.Int32); }
                    /*int*/  set Path(value) { this.$setField(14, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(21476802562)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066737154)
                    /*int*/  get Query() { return this.$getField(18, $.$$.System.Int32); }
                    /*int*/  set Query(value) { this.$setField(18, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(30066737154)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886867970)
                    /*int*/  get Fragment() { return this.$getField(22, $.$$.System.Int32); }
                    /*int*/  set Fragment(value) { this.$setField(22, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(12886867970)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591900674)
                    /*int*/  get End() { return this.$getField(26, $.$$.System.Int32); }
                    /*int*/  set End(value) { this.$setField(26, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(8591900674)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296933378)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296933378)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Scheme = this.Scheme;
                        copy.User = this.User;
                        copy.Host = this.Host;
                        copy.PortValue = this.PortValue;
                        copy.Path = this.Path;
                        copy.Query = this.Query;
                        copy.Fragment = this.Fragment;
                        copy.End = this.End;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(34361704450)
                        this.Scheme = 0;
                        //--TRIMMABLE-BOUNDARY-END(34361704450)
                        
                        //--TRIMMABLE-BOUNDARY-START(38656671746)
                        this.User = 0;
                        //--TRIMMABLE-BOUNDARY-END(38656671746)
                        
                        //--TRIMMABLE-BOUNDARY-START(17181835266)
                        this.Host = 0;
                        //--TRIMMABLE-BOUNDARY-END(17181835266)
                        
                        //--TRIMMABLE-BOUNDARY-START(25771769858)
                        this.PortValue = 0;
                        //--TRIMMABLE-BOUNDARY-END(25771769858)
                        
                        //--TRIMMABLE-BOUNDARY-START(21476802562)
                        this.Path = 0;
                        //--TRIMMABLE-BOUNDARY-END(21476802562)
                        
                        //--TRIMMABLE-BOUNDARY-START(30066737154)
                        this.Query = 0;
                        //--TRIMMABLE-BOUNDARY-END(30066737154)
                        
                        //--TRIMMABLE-BOUNDARY-START(12886867970)
                        this.Fragment = 0;
                        //--TRIMMABLE-BOUNDARY-END(12886867970)
                        
                        //--TRIMMABLE-BOUNDARY-START(8591900674)
                        this.End = 0;
                        //--TRIMMABLE-BOUNDARY-END(8591900674)
                        
                    }
                    static $h = 1966082;
                    static $z = 30;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361704450),
    {
      "t": 655361,
      "n": "Scheme",
      "d": 1966082,
      "h": 34361704450,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(34361704450),
//--TRIMMABLE-BOUNDARY-START(38656671746),
    {
      "t": 655361,
      "n": "User",
      "d": 1966082,
      "h": 38656671746,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(38656671746),
//--TRIMMABLE-BOUNDARY-START(17181835266),
    {
      "t": 655361,
      "n": "Host",
      "d": 1966082,
      "h": 17181835266,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17181835266),
//--TRIMMABLE-BOUNDARY-START(25771769858),
    {
      "t": 589825,
      "n": "PortValue",
      "d": 1966082,
      "h": 25771769858,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(25771769858),
//--TRIMMABLE-BOUNDARY-START(21476802562),
    {
      "t": 655361,
      "n": "Path",
      "d": 1966082,
      "h": 21476802562,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(21476802562),
//--TRIMMABLE-BOUNDARY-START(30066737154),
    {
      "t": 655361,
      "n": "Query",
      "d": 1966082,
      "h": 30066737154,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(30066737154),
//--TRIMMABLE-BOUNDARY-START(12886867970),
    {
      "t": 655361,
      "n": "Fragment",
      "d": 1966082,
      "h": 12886867970,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12886867970),
//--TRIMMABLE-BOUNDARY-START(8591900674),
    {
      "t": 655361,
      "n": "End",
      "d": 1966082,
      "h": 8591900674,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8591900674)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296933378),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1966082,
      "h": 4296933378,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296933378)
  ],
  "d": 1703938,
  "h": 1966082
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Uri.Offset`; }
                }, $cls, ($v) => $cls.$_Offset = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1966082)
            
            //--TRIMMABLE-BOUNDARY-START(1900546)
            static $_MoreInfo;
            static get MoreInfo()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_MoreInfo ??= $asm.$ncls("$spu.System.Uri.MoreInfo", ($self) => class MoreInfo extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(17181769730)
                    /*string?*/ Path = null;
                    //--TRIMMABLE-BOUNDARY-END(17181769730)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476737026)
                    /*string?*/ Query = null;
                    //--TRIMMABLE-BOUNDARY-END(21476737026)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886802434)
                    /*string?*/ Fragment = null;
                    //--TRIMMABLE-BOUNDARY-END(12886802434)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591835138)
                    /*string?*/ AbsoluteUri = null;
                    //--TRIMMABLE-BOUNDARY-END(8591835138)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771704322)
                    /*string?*/ RemoteUrl = null;
                    //--TRIMMABLE-BOUNDARY-END(25771704322)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066671618)
                    /*string?*/ ScopeId = null;
                    //--TRIMMABLE-BOUNDARY-END(30066671618)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296867842)
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296867842)
                    
                    static $h = 1900546;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181769730),
    {
      "t": 1310721,
      "n": "Path",
      "d": 1900546,
      "h": 17181769730,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17181769730),
//--TRIMMABLE-BOUNDARY-START(21476737026),
    {
      "t": 1310721,
      "n": "Query",
      "d": 1900546,
      "h": 21476737026,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(21476737026),
//--TRIMMABLE-BOUNDARY-START(12886802434),
    {
      "t": 1310721,
      "n": "Fragment",
      "d": 1900546,
      "h": 12886802434,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12886802434),
//--TRIMMABLE-BOUNDARY-START(8591835138),
    {
      "t": 1310721,
      "n": "AbsoluteUri",
      "d": 1900546,
      "h": 8591835138,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8591835138),
//--TRIMMABLE-BOUNDARY-START(25771704322),
    {
      "t": 1310721,
      "n": "RemoteUrl",
      "d": 1900546,
      "h": 25771704322,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(25771704322),
//--TRIMMABLE-BOUNDARY-START(30066671618),
    {
      "t": 1310721,
      "n": "ScopeId",
      "d": 1900546,
      "h": 30066671618,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(30066671618)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296867842),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1900546,
      "h": 4296867842,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296867842)
  ],
  "d": 1703938,
  "h": 1900546
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Uri.MoreInfo`; }
                }, $cls, ($v) => $cls.$_MoreInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1900546)
            
            //--TRIMMABLE-BOUNDARY-START(691491438594)
            /*void */ InterlockedSetFlags(/*Flags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(691491438594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._syntax !== null, "_syntax != null");
                if (this._syntax.IsSimple)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$spu.System.Uri.Flags.$z === $.$$.System.UInt64.$z, "sizeof(Flags) == sizeof(ulong)");
                    $.$$.System.Threading.Interlocked.Or$3($.$$.System.Runtime.CompilerServices.Unsafe.As($.$spu.System.Uri.Flags, $.$$.System.UInt64, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => this._flags, ($v) => this._flags = $v, null)), flags);
                }
                else 
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._info)
                        {
                            this._flags |= flags;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._info)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(691491438594)
            
            //--TRIMMABLE-BOUNDARY-START(760210915330)
            /*bool */ get IsImplicitFile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416613531650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._flags & 35184372088832n) !== 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(760210915330)
            
            //--TRIMMABLE-BOUNDARY-START(781685751810)
            /*bool */ get IsUncOrDosPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450973270018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._flags & (17592186044416n | 8796093022208n)) !== 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(781685751810)
            
            //--TRIMMABLE-BOUNDARY-START(738736078850)
            /*bool */ get IsDosPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399433662466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._flags & 8796093022208n) !== 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(738736078850)
            
            //--TRIMMABLE-BOUNDARY-START(785980719106)
            /*bool */ get IsUncPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459563204610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._flags & 17592186044416n) !== 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(785980719106)
            
            //--TRIMMABLE-BOUNDARY-START(790275686402)
            /*bool */ get IsUnixPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468153139202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._flags & 18014398509481984n) !== 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(790275686402)
            
            //--TRIMMABLE-BOUNDARY-START(674311569410)
            /*Flags */ get HostType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483989506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._flags & 30064771072n;
            }
            //--TRIMMABLE-BOUNDARY-END(674311569410)
            
            //--TRIMMABLE-BOUNDARY-START(944894509058)
            /*UriParser */ get Syntax()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554052485122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._syntax;
            }
            //--TRIMMABLE-BOUNDARY-END(944894509058)
            
            //--TRIMMABLE-BOUNDARY-START(768800849922)
            /*bool */ get IsNotAbsoluteUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433793400834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._syntax === null;
            }
            //--TRIMMABLE-BOUNDARY-END(768800849922)
            
            //--TRIMMABLE-BOUNDARY-START(708671307778)
            /*bool */ get IriParsing()
            {
                return $.$spu.System.Uri.IriParsingStatic(this._syntax);
            }
            //--TRIMMABLE-BOUNDARY-END(708671307778)
            
            //--TRIMMABLE-BOUNDARY-START(712966275074)
            static /*bool */ IriParsingStatic(/*UriParser?*/ syntax)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(712966275074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return syntax === null || syntax.InFact(268435456/*UriSyntaxFlags.AllowIriParsing*/);
            }
            //--TRIMMABLE-BOUNDARY-END(712966275074)
            
            //--TRIMMABLE-BOUNDARY-START(210455101442)
            /*bool */ get DisablePathAndQueryCanonicalization()
            {
                return (this._flags & 36028797018963968n) !== 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(210455101442)
            
            //--TRIMMABLE-BOUNDARY-START(1090923397122)
            /*bool */ get UserDrivenParsing()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(562642419714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._flags & 1099511627776n) !== 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(1090923397122)
            
            //--TRIMMABLE-BOUNDARY-START(919124705282)
            /*int */ get SecuredPathIndex()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536872615938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsDosPath)
                {
                    /*char*/ let ch = $.$$.System.String.get_Chars.call(this._string, this._info.Offset.Path);
                    return (ch === /*/*/ 47 || ch === /*\\*/ 92) ? 3 : 2;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(919124705282)
            
            //--TRIMMABLE-BOUNDARY-START(816045490178)
            /*bool */ NotAny(/*Flags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(816045490178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._flags & flags) === 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(816045490178)
            
            //--TRIMMABLE-BOUNDARY-START(682901504002)
            /*bool */ InFact(/*Flags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(682901504002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._flags & flags) !== 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(682901504002)
            
            //--TRIMMABLE-BOUNDARY-START(940599541762)
            static /*bool */ StaticNotAny(/*Flags*/ allFlags, /*Flags*/ checkFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(940599541762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (allFlags & checkFlags) === 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(940599541762)
            
            //--TRIMMABLE-BOUNDARY-START(932009607170)
            static /*bool */ StaticInFact(/*Flags*/ allFlags, /*Flags*/ checkFlags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(932009607170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (allFlags & checkFlags) !== 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(932009607170)
            
            //--TRIMMABLE-BOUNDARY-START(227634970626)
            /*UriInfo */ EnsureUriInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634970626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Flags*/ let cF = this._flags;
                if ((cF & 70368744177664n) === 0n)
                {
                    this.CreateUriInfo(cF);
                    this.AssertInvariants();
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this._info !== null && (this._flags & 70368744177664n) !== 0n, "_info != null && (_flags & Flags.MinimalUriInfoSet) != 0");
                return this._info;
            }
            //--TRIMMABLE-BOUNDARY-END(227634970626)
            
            //--TRIMMABLE-BOUNDARY-START(223340003330)
            /*void */ EnsureParseRemaining()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340003330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((this._flags & 140737488355328n) === 0n)
                {
                    this.ParseRemaining();
                    this.AssertInvariants();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223340003330)
            
            //--TRIMMABLE-BOUNDARY-START(219045036034)
            /*void */ EnsureHostString(/*bool*/ allowDnsOptimization)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045036034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*UriInfo*/ let info = this.EnsureUriInfo();
                if (info.Host === null)
                {
                    if (allowDnsOptimization && this.InFact(2199023255552n))
                    {
                        return;
                    }
                    this.CreateHostString();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219045036034)
            
            //--TRIMMABLE-BOUNDARY-START(68721180674)
            $ctor$5(/*string*/ uriString)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721180674);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(uriString, "uriString");
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(uriString, false, 1/*UriKind.Absolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68721180674)
            
            //--TRIMMABLE-BOUNDARY-START(55836278786)
            $ctor$2(/*string*/ uriString, /*bool*/ dontEscape)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836278786);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(uriString, "uriString");
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(uriString, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55836278786)
            
            //--TRIMMABLE-BOUNDARY-START(73016147970)
            $ctor$6(/*Uri*/ baseUri, /*string?*/ relativeUri, /*bool*/ dontEscape)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73016147970);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseUri, "baseUri");
                    if (!baseUri.IsAbsoluteUri)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("baseUri");
                    }
                    this.CreateUri(baseUri, relativeUri, dontEscape);
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73016147970)
            
            //--TRIMMABLE-BOUNDARY-START(60131246082)
            $ctor$3(/*string*/ uriString, /*UriKind*/ uriKind)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131246082);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(uriString, "uriString");
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(uriString, false, uriKind, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60131246082)
            
            //--TRIMMABLE-BOUNDARY-START(64426213378)
            $ctor$4(/*string*/ uriString, /*in UriCreationOptions*/ creationOptions)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426213378);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(uriString, "uriString");
                    this.CreateThis(uriString, false, 1/*UriKind.Absolute*/, creationOptions);
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64426213378)
            
            //--TRIMMABLE-BOUNDARY-START(77311115266)
            $ctor$7(/*Uri*/ baseUri, /*string?*/ relativeUri)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77311115266);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseUri, "baseUri");
                    if (!baseUri.IsAbsoluteUri)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("baseUri");
                    }
                    this.CreateUri(baseUri, relativeUri, false);
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77311115266)
            
            //--TRIMMABLE-BOUNDARY-START(51541311490)
            $ctor$1(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541311490);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*string?*/ let uriString = serializationInfo.GetString("AbsoluteUri");
                    if (uriString.length !== 0)
                    {
                        let $v1 = new $.$spu.System.UriCreationOptions();
                        this.CreateThis(uriString, false, 1/*UriKind.Absolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                        this.DebugSetLeftCtor();
                        return this;
                    }
                    uriString = serializationInfo.GetString("RelativeUri");
                    if (uriString === null)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$spu.System.SR.Format$6($.$spu.System.SR.InvalidNullArgument, "RelativeUri"), "serializationInfo");
                    }
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(uriString, false, 2/*UriKind.Relative*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51541311490)
            
            //--TRIMMABLE-BOUNDARY-START(957779410946)
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(957779410946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.GetObjectData(serializationInfo, streamingContext);
            }
            //--TRIMMABLE-BOUNDARY-END(957779410946)
            
            //--TRIMMABLE-BOUNDARY-START(631361896450)
            /*void */ GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(631361896450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsAbsoluteUri)
                {
                    serializationInfo.AddValue$10("AbsoluteUri", this.GetParts(-2147483648/*UriComponents.SerializationInfoString*/, 1/*UriFormat.UriEscaped*/));
                }
                else 
                {
                    serializationInfo.AddValue$10("AbsoluteUri", $.$$.System.String.Empty);
                    serializationInfo.AddValue$10("RelativeUri", this.GetParts(-2147483648/*UriComponents.SerializationInfoString*/, 1/*UriFormat.UriEscaped*/));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(631361896450)
            
            //--TRIMMABLE-BOUNDARY-START(193275232258)
            /*void */ CreateUri(/*Uri*/ baseUri, /*string?*/ relativeUri, /*bool*/ dontEscape)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275232258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.DebugAssertInCtor();
                let $v1 = new $.$spu.System.UriCreationOptions();
                this.CreateThis(relativeUri, dontEscape, 0/*UriKind.RelativeOrAbsolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                if (baseUri.Syntax.IsSimple)
                {
                    /*Uri?*/ let uriResult = $.$spu.System.Uri.ResolveHelper(baseUri, this, $.$ref(() => relativeUri, ($v) => relativeUri = $v, $.$$.System.String), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => dontEscape, ($v) => dontEscape = $v, null));
                    if ($.$spu.System.Uri.op_Inequality(uriResult, null))
                    {
                        if (!$.$$.System.Object.ReferenceEquals(this, uriResult))
                        {
                            this.CreateThisFromUri(uriResult);
                        }
                        return;
                    }
                }
                else 
                {
                    dontEscape = false;
                    /*UriFormatException?*/ let e;
                    relativeUri = baseUri.Syntax.InternalResolve(baseUri, this, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException));
                    if (e !== null)
                    {
                        throw e;
                    }
                }
                this._flags = 0n;
                this._info = null;
                this._syntax = null;
                this._originalUnicodeString = null;
                let $v2 = new $.$spu.System.UriCreationOptions();
                this.CreateThis(relativeUri, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => $v2, ($v) => $v2 = $v));
            }
            //--TRIMMABLE-BOUNDARY-END(193275232258)
            
            //--TRIMMABLE-BOUNDARY-START(81606082562)
            $ctor$8(/*Uri*/ baseUri, /*Uri*/ relativeUri)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81606082562);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseUri, "baseUri");
                    if (!baseUri.IsAbsoluteUri)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("baseUri");
                    }
                    this.CreateThisFromUri(relativeUri);
                    /*string?*/ let newUriString = null;
                    /*bool*/ let dontEscape;
                    if (baseUri.Syntax.IsSimple)
                    {
                        dontEscape = this.InFact(34359738368n);
                        /*Uri?*/ let resolvedRelativeUri = $.$spu.System.Uri.ResolveHelper(baseUri, this, $.$ref(() => newUriString, ($v) => newUriString = $v, $.$$.System.String), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => dontEscape, ($v) => dontEscape = $v, null));
                        if ($.$spu.System.Uri.op_Inequality(resolvedRelativeUri, null))
                        {
                            if (!$.$$.System.Object.ReferenceEquals(this, resolvedRelativeUri))
                            {
                                this.CreateThisFromUri(resolvedRelativeUri);
                            }
                            this.DebugSetLeftCtor();
                            return this;
                        }
                    }
                    else 
                    {
                        dontEscape = false;
                        /*UriFormatException?*/ let e;
                        newUriString = baseUri.Syntax.InternalResolve(baseUri, this, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException));
                        if (e !== null)
                        {
                            throw e;
                        }
                    }
                    this._flags = 0n;
                    this._info = null;
                    this._syntax = null;
                    this._originalUnicodeString = null;
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(newUriString, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81606082562)
            
            //--TRIMMABLE-BOUNDARY-START(588412223490)
            static /*void */ GetCombinedString(/*Uri*/ baseUri, /*string*/ relativeStr, /*bool*/ dontEscape, /*ref string?*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(588412223490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let i = 0; i < relativeStr.length; ++i)
                {
                    if ($.$$.System.String.get_Chars.call(relativeStr, i) === /*/*/ 47 || $.$$.System.String.get_Chars.call(relativeStr, i) === /*\\*/ 92 || $.$$.System.String.get_Chars.call(relativeStr, i) === /*?*/ 63 || $.$$.System.String.get_Chars.call(relativeStr, i) === /*#*/ 35)
                    {
                        break;
                    }
                    else if ($.$$.System.String.get_Chars.call(relativeStr, i) === /*:*/ 58)
                    {
                        if (i < 2)
                        {
                            break;
                        }
                        /*ParsingError*/ let error = 0/*ParsingError.None*/;
                        /*UriParser?*/ let syntax = $.$spu.System.Uri.CheckSchemeSyntax($.$$.System.MemoryExtensions.AsSpan$1(relativeStr, 0, i), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.ParsingError, () => error, ($v) => error = $v, null));
                        if (error === 0/*ParsingError.None*/)
                        {
                            if (baseUri.Syntax === syntax)
                            {
                                if (((i + 1) | 0) < relativeStr.length)
                                {
                                    relativeStr = $.$$.System.String.Substring$1.call(relativeStr, ((i + 1) | 0));
                                }
                                else 
                                {
                                    relativeStr = $.$$.System.String.Empty;
                                }
                            }
                            else 
                            {
                                result.$v = relativeStr;
                                return;
                            }
                        }
                        break;
                    }
                }
                if (relativeStr.length === 0)
                {
                    result.$v = baseUri.OriginalString;
                }
                else 
                {
                    result.$v = $.$spu.System.Uri.CombineUri(baseUri, relativeStr, dontEscape ? 1/*UriFormat.UriEscaped*/ : 3/*UriFormat.SafeUnescaped*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(588412223490)
            
            //--TRIMMABLE-BOUNDARY-START(605592092674)
            static /*UriFormatException? */ GetException(/*ParsingError*/ err)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(605592092674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(err)
                {
                    case 0/*ParsingError.None*/:
                    return null;
                    case 1/*ParsingError.BadFormat*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadFormat);
                    case 2/*ParsingError.BadScheme*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadScheme);
                    case 3/*ParsingError.BadAuthority*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadAuthority);
                    case 4/*ParsingError.EmptyUriString*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_EmptyUri);
                    case 6/*ParsingError.SchemeLimit*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_SchemeLimit);
                    case 7/*ParsingError.MustRootedPath*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_MustRootedPath);
                    case 8/*ParsingError.BadHostName*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadHostName);
                    case 9/*ParsingError.NonEmptyHost*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadFormat);
                    case 10/*ParsingError.BadPort*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadPort);
                    case 11/*ParsingError.BadAuthorityTerminator*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadAuthorityTerminator);
                    case 12/*ParsingError.CannotCreateRelative*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_CannotCreateRelative);
                    default:
                    break;
                }
                return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadFormat);
            }
            //--TRIMMABLE-BOUNDARY-END(605592092674)
            
            //--TRIMMABLE-BOUNDARY-START(90196017154)
            /*string */ get AbsolutePath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174578178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*string*/ let path = this.PrivateAbsolutePath;
                if (this.IsDosPath && $.$$.System.String.get_Chars.call(path, 0) === /*/*/ 47)
                {
                    path = $.$$.System.String.Substring$1.call(path, 1);
                }
                return path;
            }
            //--TRIMMABLE-BOUNDARY-END(90196017154)
            
            //--TRIMMABLE-BOUNDARY-START(867585097730)
            /*string */ get PrivateAbsolutePath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511102812162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this.IsAbsoluteUri, "IsAbsoluteUri");
                /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                return info.Path ??= this.GetParts(16/*UriComponents.Path*/ | 1073741824/*UriComponents.KeepDelimiter*/, 1/*UriFormat.UriEscaped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(867585097730)
            
            //--TRIMMABLE-BOUNDARY-START(94490984450)
            /*string */ get AbsoluteUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764512770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._syntax === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                return info.AbsoluteUri ??= this.GetParts(127/*UriComponents.AbsoluteUri*/, 1/*UriFormat.UriEscaped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(94490984450)
            
            //--TRIMMABLE-BOUNDARY-START(803160588290)
            /*string */ get LocalPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476743073794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.GetLocalPath();
            }
            //--TRIMMABLE-BOUNDARY-END(803160588290)
            
            //--TRIMMABLE-BOUNDARY-START(103080919042)
            /*string */ get Authority()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354447362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.GetParts(4/*UriComponents.Host*/ | 8/*UriComponents.Port*/, 1/*UriFormat.UriEscaped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(103080919042)
            
            //--TRIMMABLE-BOUNDARY-START(670016602114)
            /*UriHostNameType */ get HostNameType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347894054914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (this._syntax.IsSimple)
                {
                    this.EnsureUriInfo();
                }
                else 
                {
                    this.EnsureHostString(false);
                }
                switch(this.HostType)
                {
                    case 12884901888n:
                    return 2/*UriHostNameType.Dns*/;
                    case 8589934592n:
                    return 3/*UriHostNameType.IPv4*/;
                    case 4294967296n:
                    return 4/*UriHostNameType.IPv6*/;
                    case 21474836480n:
                    return 1/*UriHostNameType.Basic*/;
                    case 17179869184n:
                    return 1/*UriHostNameType.Basic*/;
                    case 30064771072n:
                    return 0/*UriHostNameType.Unknown*/;
                    default:
                    break;
                }
                return 0/*UriHostNameType.Unknown*/;
            }
            //--TRIMMABLE-BOUNDARY-END(670016602114)
            
            //--TRIMMABLE-BOUNDARY-START(734441111554)
            /*bool */ get IsDefaultPort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390843727874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (this._syntax.IsSimple)
                {
                    this.EnsureUriInfo();
                }
                else 
                {
                    this.EnsureHostString(false);
                }
                return this.NotAny(549755813888n);
            }
            //--TRIMMABLE-BOUNDARY-END(734441111554)
            
            //--TRIMMABLE-BOUNDARY-START(747326013442)
            /*bool */ get IsFile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408023597058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this._syntax.SchemeName === $.$spu.System.Uri.UriSchemeFile;
            }
            //--TRIMMABLE-BOUNDARY-END(747326013442)
            
            //--TRIMMABLE-BOUNDARY-START(764505882626)
            /*bool */ get IsLoopback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425203466242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                this.EnsureHostString(false);
                return this.InFact(274877906944n);
            }
            //--TRIMMABLE-BOUNDARY-END(764505882626)
            
            //--TRIMMABLE-BOUNDARY-START(854700195842)
            /*string */ get PathAndQuery()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493922942978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*UriInfo*/ let info = this.EnsureUriInfo();
                if (info.PathAndQuery === null)
                {
                    /*string*/ let result = this.GetParts(48/*UriComponents.PathAndQuery*/, 1/*UriFormat.UriEscaped*/);
                    if (this.IsDosPath && $.$$.System.String.get_Chars.call(result, 0) === /*/*/ 47)
                    {
                        result = $.$$.System.String.Substring$1.call(result, 1);
                    }
                    info.PathAndQuery = result;
                }
                return info.PathAndQuery;
            }
            //--TRIMMABLE-BOUNDARY-END(854700195842)
            
            //--TRIMMABLE-BOUNDARY-START(923419672578)
            /*string[] */ get Segments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545462550530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*string[]*/ let segments;
                /*string*/ let path = this.PrivateAbsolutePath;
                if (path.length === 0)
                {
                    segments = $.$$.System.Array.Empty($.$$.System.String);
                }
                else 
                {
                    /*var*/ let pathSegments = new ($.$spu.System.Collections.Generic.ValueListBuilder$$($.$$.System.String))().$ctor$3(4);
                    /*int*/ let current = 0;
                    while(current < path.length)
                    {
                        /*int*/ let next = $.$$.System.String.IndexOf$1.call(path, /*/*/ 47, current);
                        if (next === -1)
                        {
                            next = ((path.length - 1) | 0);
                        }
                        pathSegments.Append$1($.$$.System.String.Substring.call(path, current, (((((next - current) | 0)) + 1) | 0)));
                        current = ((next + 1) | 0);
                    }
                    segments = pathSegments.AsSpan().ToArray();
                    pathSegments.Dispose();
                }
                return segments;
            }
            //--TRIMMABLE-BOUNDARY-END(923419672578)
            
            //--TRIMMABLE-BOUNDARY-START(777390784514)
            /*bool */ get IsUnc()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442383335426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.IsUncPath;
            }
            //--TRIMMABLE-BOUNDARY-END(777390784514)
            
            //--TRIMMABLE-BOUNDARY-START(665721634818)
            /*string */ get Host()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339304120322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.GetParts(4/*UriComponents.Host*/, 1/*UriFormat.UriEscaped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(665721634818)
            
            //--TRIMMABLE-BOUNDARY-START(936304574466)
            static /*bool */ StaticIsFile(/*UriParser*/ syntax)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(936304574466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/);
            }
            //--TRIMMABLE-BOUNDARY-END(936304574466)
            
            //--TRIMMABLE-BOUNDARY-START(627066929154)
            /*string */ GetLocalPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(627066929154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureParseRemaining();
                if (this.IsUncOrDosPath)
                {
                    this.EnsureHostString(false);
                    $.$$.System.Diagnostics.Debug.Assert$2(this._info !== null, "_info != null");
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Inequality(this._info.Host, null), "_info.Host != null");
                    /*int*/ let start;
                    if (this.NotAny(4n | 16n | 8192n))
                    {
                        start = this.IsUncPath ? ((this._info.Offset.Host - 2) | 0) : this._info.Offset.Path;
                        /*string*/ let str = (this.IsImplicitFile && this._info.Offset.Host === (this.IsDosPath ? 0 : 2) && this._info.Offset.Query === this._info.Offset.End) ? this._string : (this.IsDosPath && ($.$$.System.String.get_Chars.call(this._string, start) === /*/*/ 47 || $.$$.System.String.get_Chars.call(this._string, start) === /*\\*/ 92)) ? $.$$.System.String.Substring.call(this._string, ((start + 1) | 0), ((((this._info.Offset.Query - start) | 0) - 1) | 0)) : $.$$.System.String.Substring.call(this._string, start, ((this._info.Offset.Query - start) | 0));
                        if (this.IsDosPath && $.$$.System.String.get_Chars.call(str, 1) === /*|*/ 124)
                        {
                            str = $.$$.System.String.Remove.call(str, 1, 1);
                            str = $.$$.System.String.Insert.call(str, 1, ":");
                        }
                        str = $.$$.System.String.Replace.call(str, /*/*/ 47, /*\\*/ 92);
                        return str;
                    }
                    /*char[]*/ let result;
                    /*int*/ let count = 0;
                    start = this._info.Offset.Path;
                    /*string*/ let host = this._info.Host;
                    result = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [((((((host.length + 3) | 0) + this._info.Offset.Fragment) | 0) - this._info.Offset.Path) | 0)], null);
                    if (this.IsUncPath)
                    {
                        $.$$.System.Array.$WriteT1.call(result, /*\\*/ 92, 0);
                        $.$$.System.Array.$WriteT1.call(result, /*\\*/ 92, 1);
                        count = 2;
                        $.$spu.System.UriHelper.UnescapeString$3(host, 0, host.length, result, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 0/*UnescapeMode.CopyOnly*/, this._syntax, false);
                    }
                    else 
                    {
                        if ($.$$.System.String.get_Chars.call(this._string, start) === /*/*/ 47 || $.$$.System.String.get_Chars.call(this._string, start) === /*\\*/ 92)
                        {
                            ++start;
                        }
                    }
                    /*int*/ let pathStart = count;
                    /*UnescapeMode*/ let mode = (this.InFact(16n) && !this.IsImplicitFile) ? (2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/) : 0/*UnescapeMode.CopyOnly*/;
                    $.$spu.System.UriHelper.UnescapeString$3(this._string, start, this._info.Offset.Query, result, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, mode, this._syntax, true);
                    if ($.$$.System.Array.$ReadT1.call(result, 1) === /*|*/ 124)
                    {
                        $.$$.System.Array.$WriteT1.call(result, /*:*/ 58, 1);
                    }
                    if (this.InFact(8192n))
                    {
                        $.$spu.System.Uri.Compress(result, this.IsDosPath ? ((pathStart + 2) | 0) : pathStart, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32), this._syntax);
                    }
                    /*Span<char>*/ let slashSpan = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, result, 0, count);
                    $.$$.System.MemoryExtensions.Replace$3($.$$.System.Char, slashSpan, /*/*/ 47, /*\\*/ 92);
                    return $.$$.System.String.Create$1(result, 0, count);
                }
                else 
                {
                    return this.GetUnescapedParts(16/*UriComponents.Path*/ | 1073741824/*UriComponents.KeepDelimiter*/, 2/*UriFormat.Unescaped*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(627066929154)
            
            //--TRIMMABLE-BOUNDARY-START(863290130434)
            /*int */ get Port()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502512877570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (this._syntax.IsSimple)
                {
                    this.EnsureUriInfo();
                }
                else 
                {
                    this.EnsureHostString(false);
                }
                if (this.InFact(549755813888n))
                {
                    return $.$cast(this._info.Offset.PortValue, $.$$.System.Int32);
                }
                return this._syntax.DefaultPort;
            }
            //--TRIMMABLE-BOUNDARY-END(863290130434)
            
            //--TRIMMABLE-BOUNDARY-START(876175032322)
            /*string */ get Query()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519692746754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                return info.Query ??= this.GetParts(32/*UriComponents.Query*/ | 1073741824/*UriComponents.KeepDelimiter*/, 1/*UriFormat.UriEscaped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(876175032322)
            
            //--TRIMMABLE-BOUNDARY-START(266289676290)
            /*string */ get Fragment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322124251138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                return info.Fragment ??= this.GetParts(64/*UriComponents.Fragment*/ | 1073741824/*UriComponents.KeepDelimiter*/, 1/*UriFormat.UriEscaped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(266289676290)
            
            //--TRIMMABLE-BOUNDARY-START(906239803394)
            /*string */ get Scheme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528282681346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this._syntax.SchemeName;
            }
            //--TRIMMABLE-BOUNDARY-END(906239803394)
            
            //--TRIMMABLE-BOUNDARY-START(828930392066)
            /*string */ get OriginalString()
            {
                return this._originalUnicodeString ?? this._string;
            }
            //--TRIMMABLE-BOUNDARY-END(828930392066)
            
            //--TRIMMABLE-BOUNDARY-START(214750068738)
            /*string */ get DnsSafeHost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313534316546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                this.EnsureHostString(false);
                /*Flags*/ let hostType = this.HostType;
                if (hostType === 4294967296n || (hostType === 21474836480n && this.InFact(4n | 256n)))
                {
                    return this.IdnHost;
                }
                else 
                {
                    return this._info.Host;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214750068738)
            
            //--TRIMMABLE-BOUNDARY-START(678606536706)
            /*string */ get IdnHost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365073924098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if ((this._info?.IdnHost ?? null) === null)
                {
                    this.EnsureHostString(false);
                    /*string*/ let host = this._info.Host;
                    /*Flags*/ let hostType = this.HostType;
                    if (hostType === 12884901888n)
                    {
                        host = $.$spu.System.DomainNameHelper.IdnEquivalent(host);
                    }
                    else if (hostType === 4294967296n)
                    {
                        let scopeId;
                        host = $.$is((this._info._moreInfo?.ScopeId ?? null), $.$$.System.String, { set $v(v){ scopeId = v; } }) ? $.$$.System.String.Concat$8($.$$.System.MemoryExtensions.AsSpan$1(host, 1, ((host.length - 2) | 0)), $.$$.System.String.op_Implicit(scopeId)) : $.$$.System.String.Substring.call(host, 1, ((host.length - 2) | 0));
                    }
                    else if (hostType === 21474836480n && this.InFact(4n | 256n))
                    {
                        /*var*/ let dest = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                        $.$spu.System.UriHelper.UnescapeString$4(host, 0, host.length, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, this._syntax, false);
                        host = $.$spu.System.Text.ValueStringBuilder.ToString.call(dest);
                    }
                    this._info.IdnHost = host;
                }
                return this._info.IdnHost;
            }
            //--TRIMMABLE-BOUNDARY-END(678606536706)
            
            //--TRIMMABLE-BOUNDARY-START(717261242370)
            /*bool */ get IsAbsoluteUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382253793282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._syntax !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(717261242370)
            
            //--TRIMMABLE-BOUNDARY-START(1095218364418)
            /*bool */ get UserEscaped()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(571232354306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InFact(34359738368n);
            }
            //--TRIMMABLE-BOUNDARY-END(1095218364418)
            
            //--TRIMMABLE-BOUNDARY-START(1099513331714)
            /*string */ get UserInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(579822288898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.GetParts(2/*UriComponents.UserInfo*/, 1/*UriFormat.UriEscaped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1099513331714)
            
            //--TRIMMABLE-BOUNDARY-START(141735624706)
            static /*UriHostNameType */ CheckHostName(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735624706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(name))
                {
                    return 0/*UriHostNameType.Unknown*/;
                }
                /*int*/ let end = name.length;
                {
                    /*fixed*/ 
                    {
                        /*char**/ let fixedName = $.$$.System.String.GetPinnableReference.call(name);
                        if ($.$$.System.String.StartsWith.call(name, /*[*/ 91) && $.$$.System.String.EndsWith.call(name, /*]*/ 93))
                        {
                            if ($.$spu.System.Net.IPv6AddressHelper.IsValid(fixedName, 1, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32)) && end === name.length)
                            {
                                return 4/*UriHostNameType.IPv6*/;
                            }
                        }
                        end = name.length;
                        if ($.$spu.System.Net.IPv4AddressHelper.IsValid($.$$.System.Char, fixedName, 0, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32), false, false, false) && end === name.length)
                        {
                            return 3/*UriHostNameType.IPv4*/;
                        }
                    }
                    /*int*/ let length;
                    if ($.$spu.System.DomainNameHelper.IsValid($.$$.System.String.op_Implicit(name), false, false, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)) && length === name.length)
                    {
                        return 2/*UriHostNameType.Dns*/;
                    }
                    if ($.$spu.System.DomainNameHelper.IsValid($.$$.System.String.op_Implicit(name), true, false, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)) && length === name.length)
                    {
                        return 2/*UriHostNameType.Dns*/;
                    }
                    end = ((name.length + 2) | 0);
                    name = "[" + name + "]";
                    /*fixed*/ 
                    {
                        /*char**/ let newFixedName = $.$$.System.String.GetPinnableReference.call(name);
                        if ($.$spu.System.Net.IPv6AddressHelper.IsValid(newFixedName, 1, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32)) && end === name.length)
                        {
                            return 4/*UriHostNameType.IPv6*/;
                        }
                    }
                }
                return 0/*UriHostNameType.Unknown*/;
            }
            //--TRIMMABLE-BOUNDARY-END(141735624706)
            
            //--TRIMMABLE-BOUNDARY-START(618476994562)
            /*string */ GetLeftPart(/*UriPartial*/ part)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(618476994562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                this.EnsureUriInfo();
                /*UriComponents*/ let NonPathPart = (1/*UriComponents.Scheme*/ | 2/*UriComponents.UserInfo*/ | 4/*UriComponents.Host*/ | 8/*UriComponents.Port*/);
                switch(part)
                {
                    case 0/*UriPartial.Scheme*/:
                    return this.GetParts(1/*UriComponents.Scheme*/ | 1073741824/*UriComponents.KeepDelimiter*/, 1/*UriFormat.UriEscaped*/);
                    case 1/*UriPartial.Authority*/:
                    if (this.NotAny(68719476736n) || this.IsDosPath)
                    {
                        return $.$$.System.String.Empty;
                    }
                    return this.GetParts(NonPathPart, 1/*UriFormat.UriEscaped*/);
                    case 2/*UriPartial.Path*/:
                    return this.GetParts(NonPathPart | 16/*UriComponents.Path*/, 1/*UriFormat.UriEscaped*/);
                    case 3/*UriPartial.Query*/:
                    return this.GetParts(NonPathPart | 16/*UriComponents.Path*/ | 32/*UriComponents.Query*/, 1/*UriFormat.UriEscaped*/);
                }
                throw new $.$$.System.ArgumentException().$ctor$13($.$spu.System.SR.Format$6($.$spu.System.SR.Argument_InvalidUriSubcomponent, $.$box(part, $.$spu.System.UriPartial)), "part");
            }
            //--TRIMMABLE-BOUNDARY-END(618476994562)
            
            //--TRIMMABLE-BOUNDARY-START(657131700226)
            static /*string */ HexEscape(/*char*/ character)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(657131700226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Char, character, /*\u00FF*/ 255, "character");
                return $.$$.System.String.Create$10($.$$.System.Byte, 3, $.$cast(character, $.$$.System.Byte), new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.Byte))().$ctor(this,  (/*Span<char>*/ chars, /*byte*/ b) =>
                {
                    chars.get_Item(0).$v = /*%*/ 37;
                    $.$spu.System.HexConverter.ToCharsBuffer(b, chars, 1, 0/*HexConverter.Casing.Upper*/);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "chars",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "b",
      "p": 393217
    }
  ],
  "n": "",
  "d": 1703938,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(657131700226)
            
            //--TRIMMABLE-BOUNDARY-START(661426667522)
            static /*char */ HexUnescape(/*string*/ pattern, /*ref int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(661426667522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index.$v, "index");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual($.$$.System.Int32, index.$v, pattern.length, "index");
                if (($.$$.System.String.get_Chars.call(pattern, index.$v) === /*%*/ 37) && (((pattern.length - index.$v) | 0) >= 3))
                {
                    /*char*/ let ret = $.$spu.System.UriHelper.DecodeHexChars($.$$.System.String.get_Chars.call(pattern, ((index.$v + 1) | 0)), $.$$.System.String.get_Chars.call(pattern, ((index.$v + 2) | 0)));
                    if (ret !== /*\uFFFF*/ 65535)
                    {
                        index.$v += 3;
                        return ret;
                    }
                }
                return $.$$.System.String.get_Chars.call(pattern, index.$v++);
            }
            //--TRIMMABLE-BOUNDARY-END(661426667522)
            
            //--TRIMMABLE-BOUNDARY-START(755915948034)
            static /*bool */ IsHexEncoding(/*string*/ pattern, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(755915948034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (((pattern.length - index) | 0)) >= 3 && $.$$.System.String.get_Chars.call(pattern, index) === /*%*/ 37 && $.$$.System.Char.IsAsciiHexDigit($.$$.System.String.get_Chars.call(pattern, ((index + 1) | 0))) && $.$$.System.Char.IsAsciiHexDigit($.$$.System.String.get_Chars.call(pattern, ((index + 2) | 0)));
            }
            //--TRIMMABLE-BOUNDARY-END(755915948034)
            
            //--TRIMMABLE-BOUNDARY-START(897649868802)
            /*SearchValues<char>*/ static s_schemeChars = null;
            //--TRIMMABLE-BOUNDARY-END(897649868802)
            
            //--TRIMMABLE-BOUNDARY-START(146030592002)
            static /*bool */ CheckSchemeName(/*string?*/ schemeName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146030592002);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !$.$$.System.String.IsNullOrEmpty(schemeName) && $.$$.System.Char.IsAsciiLetter($.$$.System.String.get_Chars.call(schemeName, 0)) && !$.$$.System.MemoryExtensions.ContainsAnyExcept($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(schemeName), $.$spu.System.Uri.s_schemeChars);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146030592002)
            
            //--TRIMMABLE-BOUNDARY-START(751620980738)
            static /*bool */ IsHexDigit(/*char*/ character)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(751620980738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Char.IsAsciiHexDigit(character);
            }
            //--TRIMMABLE-BOUNDARY-END(751620980738)
            
            //--TRIMMABLE-BOUNDARY-START(270584643586)
            static /*int */ FromHex(/*char*/ digit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584643586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let result = $.$spu.System.HexConverter.FromChar(digit);
                if (result === 255)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13(null, "digit");
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(270584643586)
            
            //--TRIMMABLE-BOUNDARY-START(609887059970)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(609887059970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsNotAbsoluteUri)
                {
                    return $.$$.System.String.GetHashCode.call(this.OriginalString);
                }
                else 
                {
                    /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                    /*UriComponents*/ let components = 61/*UriComponents.HttpRequestUrl*/;
                    if (this._syntax.InFact(16384/*UriSyntaxFlags.MailToLikeUri*/))
                    {
                        components |= 2/*UriComponents.UserInfo*/;
                    }
                    /*string*/ let remoteUrl = info.RemoteUrl ??= this.GetParts(components, 3/*UriFormat.SafeUnescaped*/);
                    if (this.IsUncOrDosPath)
                    {
                        return $.$$.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(remoteUrl);
                    }
                    else 
                    {
                        return $.$$.System.String.GetHashCode.call(remoteUrl);
                    }
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$spu.System.Uri.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(609887059970)
            
            //--TRIMMABLE-BOUNDARY-START(1103808299010)
            /*UriFormat*/ static V1ToStringUnescape = 32767;
            //--TRIMMABLE-BOUNDARY-END(1103808299010)
            
            //--TRIMMABLE-BOUNDARY-START(962074378242)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(962074378242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._syntax === null)
                {
                    return this._string;
                }
                this.EnsureUriInfo();
                return this._info.String ??= this._syntax.IsSimple ? this.GetComponentsHelper(127/*UriComponents.AbsoluteUri*/, 32767/*V1ToStringUnescape*/) : this.GetParts(127/*UriComponents.AbsoluteUri*/, 3/*UriFormat.SafeUnescaped*/);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spu.System.Uri.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(962074378242)
            
            //--TRIMMABLE-BOUNDARY-START(987844182018)
            /*bool */ TryFormat(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(987844182018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<char>*/ let result;
                if (this._syntax === null)
                {
                    result = $.$$.System.String.op_Implicit(this._string);
                }
                else 
                {
                    this.EnsureUriInfo();
                    if (!(this._info.String === null))
                    {
                        result = $.$$.System.String.op_Implicit(this._info.String);
                    }
                    else 
                    {
                        /*UriFormat*/ let uriFormat = 32767/*V1ToStringUnescape*/;
                        if (!this._syntax.IsSimple)
                        {
                            if (this.IsNotAbsoluteUri)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                            }
                            if (this.UserDrivenParsing)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_UserDrivenParsing, $.$$.System.Object.GetType.call(this)));
                            }
                            if (this.DisablePathAndQueryCanonicalization)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_GetComponentsCalledWhenCanonicalizationDisabled);
                            }
                            uriFormat = 3/*UriFormat.SafeUnescaped*/;
                        }
                        this.EnsureParseRemaining();
                        this.EnsureHostString(true);
                        /*ushort*/ let nonCanonical = $.$cast(($.$cast(this._flags, $.$$.System.UInt16) & $.$cast(127n, $.$$.System.UInt16)), $.$$.System.UInt16);
                        if (((this._flags & (8192n | 16384n | 32768n)) !== 0n) || (this.IsDosPath && $.$$.System.String.get_Chars.call(this._string, ((((this._info.Offset.Path + this.SecuredPathIndex) | 0) - 1) | 0)) === /*|*/ 124))
                        {
                            nonCanonical |= $.$cast(16n, $.$$.System.UInt16);
                        }
                        if (($.$cast(127/*UriComponents.AbsoluteUri*/, $.$$.System.UInt16) & nonCanonical) !== 0)
                        {
                            return this.TryRecreateParts(destination, charsWritten, 127/*UriComponents.AbsoluteUri*/, nonCanonical, uriFormat);
                        }
                        result = $.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Scheme, ((this._info.Offset.End - this._info.Offset.Scheme) | 0));
                    }
                }
                if (result.TryCopyTo(destination))
                {
                    charsWritten.$v = result.Length;
                    return true;
                }
                charsWritten.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(987844182018)
            
            //--TRIMMABLE-BOUNDARY-START(953484443650)
            /*bool */ System$ISpanFormattable$TryFormat(/*Span<char>*/ destination, /*out int*/ charsWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(953484443650);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.TryFormat(destination, charsWritten);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(953484443650)
            
            //--TRIMMABLE-BOUNDARY-START(949189476354)
            /*string */ System$IFormattable$ToString(/*string?*/ format, /*IFormatProvider?*/ formatProvider)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(949189476354);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$spu.System.Uri.ToString.call(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(949189476354)
            
            //--TRIMMABLE-BOUNDARY-START(820340457474)
            static /*bool */ op_Equality(/*Uri?*/ uri1, /*Uri?*/ uri2)
            {
                if ($.$$.System.Object.ReferenceEquals(uri1, uri2))
                {
                    return true;
                }
                if (uri1 === null || uri2 === null)
                {
                    return false;
                }
                return uri1.Equals$2(uri2);
            }
            //--TRIMMABLE-BOUNDARY-END(820340457474)
            
            //--TRIMMABLE-BOUNDARY-START(824635424770)
            static /*bool */ op_Inequality(/*Uri?*/ uri1, /*Uri?*/ uri2)
            {
                if ($.$$.System.Object.ReferenceEquals(uri1, uri2))
                {
                    return false;
                }
                if (uri1 === null || uri2 === null)
                {
                    return true;
                }
                return !uri1.Equals$2(uri2);
            }
            //--TRIMMABLE-BOUNDARY-END(824635424770)
            
            //--TRIMMABLE-BOUNDARY-START(231929937922)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ comparand)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929937922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (comparand === null)
                {
                    return false;
                }
                if ($.$$.System.Object.ReferenceEquals(this, comparand))
                {
                    return true;
                }
                /*Uri?*/ let other = $.$as(comparand, $.$spu.System.Uri);
                if (other === null)
                {
                    if (this.DisablePathAndQueryCanonicalization)
                    {
                        return false;
                    }
                    let s;
                    if (!($.$is(comparand, $.$$.System.String, { set $v(v){ s = v; } })))
                    {
                        return false;
                    }
                    if ($.$$.System.Object.ReferenceEquals(s, this.OriginalString))
                    {
                        return true;
                    }
                    if (!$.$spu.System.Uri.TryCreate(s, 0/*UriKind.RelativeOrAbsolute*/, $.$ref(() => other, ($v) => other = $v, $.$spu.System.Uri)))
                    {
                        return false;
                    }
                }
                return this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$spu.System.Uri.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(231929937922)
            
            //--TRIMMABLE-BOUNDARY-START(236224905218)
            /*bool */ Equals$2(/*Uri?*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224905218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (other === null)
                {
                    return false;
                }
                if ($.$$.System.Object.ReferenceEquals(this, other))
                {
                    return true;
                }
                if (this.DisablePathAndQueryCanonicalization !== other.DisablePathAndQueryCanonicalization)
                {
                    return false;
                }
                if ($.$$.System.Object.ReferenceEquals(this.OriginalString, other.OriginalString))
                {
                    return true;
                }
                if (this.IsAbsoluteUri !== other.IsAbsoluteUri)
                {
                    return false;
                }
                if (this.IsNotAbsoluteUri)
                {
                    return $.$$.System.String.Equals$5.call(this.OriginalString, other.OriginalString);
                }
                if (this.NotAny(140737488355328n) || other.NotAny(140737488355328n))
                {
                    if ($.$$.System.String.Equals$2(this._string, other._string, this.IsUncOrDosPath ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                    {
                        return true;
                    }
                }
                this.EnsureUriInfo();
                other.EnsureUriInfo();
                if (!this.UserDrivenParsing && !other.UserDrivenParsing && this.Syntax.IsSimple && other.Syntax.IsSimple)
                {
                    if (this.InFact(2199023255552n) && other.InFact(2199023255552n))
                    {
                        /*int*/ let i1 = this._info.Offset.Host;
                        /*int*/ let end1 = this._info.Offset.Path;
                        /*int*/ let i2 = other._info.Offset.Host;
                        /*int*/ let end2 = other._info.Offset.Path;
                        /*string*/ let str = other._string;
                        if (((end1 - i1) | 0) > ((end2 - i2) | 0))
                        {
                            end1 = ((((i1 + end2) | 0) - i2) | 0);
                        }
                        while(i1 < end1)
                        {
                            if ($.$$.System.String.get_Chars.call(this._string, i1) !== $.$$.System.String.get_Chars.call(str, i2))
                            {
                                return false;
                            }
                            if ($.$$.System.String.get_Chars.call(str, i2) === /*:*/ 58)
                            {
                                break;
                            }
                            ++i1;
                            ++i2;
                        }
                        if (i1 < this._info.Offset.Path && $.$$.System.String.get_Chars.call(this._string, i1) !== /*:*/ 58)
                        {
                            return false;
                        }
                        if (i2 < end2 && $.$$.System.String.get_Chars.call(str, i2) !== /*:*/ 58)
                        {
                            return false;
                        }
                    }
                    else 
                    {
                        this.EnsureHostString(false);
                        other.EnsureHostString(false);
                        if (!$.$$.System.String.Equals$5.call(this._info.Host, other._info.Host))
                        {
                            return false;
                        }
                    }
                    if (this.Port !== other.Port)
                    {
                        return false;
                    }
                }
                /*MoreInfo*/ let selfInfo = this._info.MoreInfo;
                /*MoreInfo*/ let otherInfo = other._info.MoreInfo;
                /*UriComponents*/ let components = 61/*UriComponents.HttpRequestUrl*/;
                if (this._syntax.InFact(16384/*UriSyntaxFlags.MailToLikeUri*/))
                {
                    if (!other._syntax.InFact(16384/*UriSyntaxFlags.MailToLikeUri*/))
                    {
                        return false;
                    }
                    components |= 2/*UriComponents.UserInfo*/;
                }
                /*string*/ let selfUrl = selfInfo.RemoteUrl ??= this.GetParts(components, 3/*UriFormat.SafeUnescaped*/);
                /*string*/ let otherUrl = otherInfo.RemoteUrl ??= other.GetParts(components, 3/*UriFormat.SafeUnescaped*/);
                return $.$$.System.String.Equals$2(selfUrl, otherUrl, this.IsUncOrDosPath ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(236224905218)
            
            //--TRIMMABLE-BOUNDARY-START(811750522882)
            /*Uri */ MakeRelativeUri(/*Uri*/ uri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(811750522882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                if (this.IsNotAbsoluteUri || uri.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (($.$$.System.String.op_Equality(this.Scheme, uri.Scheme)) && ($.$$.System.String.op_Equality(this.Host, uri.Host)) && (this.Port === uri.Port))
                {
                    /*string*/ let otherPath = uri.AbsolutePath;
                    /*string*/ let relativeUriString = $.$spu.System.Uri.PathDifference(this.AbsolutePath, otherPath, !this.IsUncOrDosPath);
                    if ($.$spu.System.Uri.CheckForColonInFirstPathSegment(relativeUriString) && !(uri.IsDosPath && $.$$.System.String.Equals$4.call(otherPath, relativeUriString, 4/*StringComparison.Ordinal*/)))
                    {
                        relativeUriString = "./" + relativeUriString;
                    }
                    relativeUriString += uri.GetParts(32/*UriComponents.Query*/ | 64/*UriComponents.Fragment*/, 1/*UriFormat.UriEscaped*/);
                    return new $.$spu.System.Uri().$ctor$3(relativeUriString, 2/*UriKind.Relative*/);
                }
                return uri;
            }
            //--TRIMMABLE-BOUNDARY-END(811750522882)
            
            //--TRIMMABLE-BOUNDARY-START(901944836098)
            /*SearchValues<char>*/ static s_segmentSeparatorChars = null;
            //--TRIMMABLE-BOUNDARY-END(901944836098)
            
            //--TRIMMABLE-BOUNDARY-START(133145690114)
            static /*bool */ CheckForColonInFirstPathSegment(/*string*/ uriString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145690114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let index = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(uriString), $.$spu.System.Uri.s_segmentSeparatorChars);
                return (index >>> 0) < (uriString.length >>> 0) && $.$$.System.String.get_Chars.call(uriString, index) === /*:*/ 58;
            }
            //--TRIMMABLE-BOUNDARY-END(133145690114)
            
            //--TRIMMABLE-BOUNDARY-START(695786405890)
            static /*string */ InternalEscapeString(/*string*/ rawString)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(695786405890);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return rawString === null ? $.$$.System.String.Empty : $.$spu.System.UriHelper.EscapeString$2(rawString, true, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(695786405890)
            
            //--TRIMMABLE-BOUNDARY-START(846110261250)
            static /*ParsingError */ ParseScheme(/*string*/ uriString, /*ref Flags*/ flags, /*ref UriParser?*/ syntax)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(846110261250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2((flags.$v & 144115188075855872n) === 0n, "(flags & Flags.Debug_LeftConstructor) == 0");
                /*int*/ let length = uriString.length;
                if (length === 0)
                {
                    return 4/*ParsingError.EmptyUriString*/;
                }
                if ($.$$.System.String.StartsWith$2.call(uriString, "https:", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    syntax.$v = $.$spu.System.UriParser.HttpsUri;
                    flags.$v |= $.$cast(6n, $.$spu.System.Uri.Flags);
                }
                else if ($.$$.System.String.StartsWith$2.call(uriString, "http:", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    syntax.$v = $.$spu.System.UriParser.HttpUri;
                    flags.$v |= $.$cast(5n, $.$spu.System.Uri.Flags);
                }
                else 
                {
                    /*ParsingError*/ let err = 0/*ParsingError.None*/;
                    /*int*/ let idx = $.$spu.System.Uri.ParseSchemeCheckImplicitFile(uriString, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.ParsingError, () => err, ($v) => err = $v, null), flags, syntax);
                    $.$$.System.Diagnostics.Debug.Assert$2((err === 0) === (!(syntax.$v === null)), "(err is ParsingError.None) == (syntax is not null)");
                    if (err !== 0/*ParsingError.None*/)
                    {
                        return err;
                    }
                    flags.$v |= $.$cast(idx, $.$spu.System.Uri.Flags);
                }
                return 0/*ParsingError.None*/;
            }
            //--TRIMMABLE-BOUNDARY-END(846110261250)
            
            //--TRIMMABLE-BOUNDARY-START(837520326658)
            /*UriFormatException? */ ParseMinimal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(837520326658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._syntax !== null && !this._syntax.IsSimple, "_syntax != null && !_syntax.IsSimple");
                $.$$.System.Diagnostics.Debug.Assert$2((this._flags & 72057594037927936n) !== 0n, "(_flags & Flags.CustomParser_ParseMinimalAlreadyCalled) != 0");
                this.DebugAssertInCtor();
                /*ParsingError*/ let result = this.PrivateParseMinimal();
                if (result === 0/*ParsingError.None*/)
                {
                    return null;
                }
                this._flags |= 4398046511104n;
                return $.$spu.System.Uri.GetException(result);
            }
            //--TRIMMABLE-BOUNDARY-END(837520326658)
            
            //--TRIMMABLE-BOUNDARY-START(871880065026)
            /*ParsingError */ PrivateParseMinimal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(871880065026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._syntax !== null, "_syntax != null");
                this.DebugAssertInCtor();
                /*int*/ let idx = $.$cast((this._flags & 4294967295n), $.$$.System.Int32);
                /*int*/ let length = this._string.length;
                this._flags &= ~(4294967295n | 1099511627776n);
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Object.ReferenceEquals(this._string, this.OriginalString), "ReferenceEquals(_string, OriginalString)");
                /*fixed*/ 
                {
                    /*char**/ let pUriString = $.$$.System.String.GetPinnableReference.call(this._string);
                    if (length > idx && $.$spu.System.UriHelper.IsLWS(pUriString.GetAt(((length - 1) | 0))))
                    {
                        --length;
                        while(length !== idx && $.$spu.System.UriHelper.IsLWS(pUriString.GetAt(--length)))
                        {
                        }
                        ++length;
                    }
                    if (!$.$$.System.OperatingSystem.IsWindows() && this.InFact(18014398509481984n))
                    {
                        this._flags |= 21474836480n;
                        this._flags |= $.$cast(idx, $.$spu.System.Uri.Flags);
                        return 0/*ParsingError.None*/;
                    }
                    if (this._syntax.IsAllSet(128/*UriSyntaxFlags.AllowEmptyHost*/ | 1048576/*UriSyntaxFlags.AllowDOSPath*/) && this.NotAny(35184372088832n) && (((idx + 1) | 0) < length))
                    {
                        /*char*/ let c;
                        /*int*/ let i = idx;
                        for(; i < length; ++i)
                        {
                            if (!((c = pUriString.GetAt(i)) === /*\\*/ 92 || c === /*/*/ 47))
                            {
                                break;
                            }
                        }
                        if (this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/) || ((i - idx) | 0) <= 3)
                        {
                            if (((i - idx) | 0) >= 2)
                            {
                                this._flags |= 68719476736n;
                            }
                            if (((i + 1) | 0) < length && ((c = pUriString.GetAt(((i + 1) | 0))) === /*:*/ 58 || c === /*|*/ 124) && $.$$.System.Char.IsAsciiLetter(pUriString.GetAt(i)))
                            {
                                if (((i + 2) | 0) >= length || ((c = pUriString.GetAt(((i + 2) | 0))) !== /*\\*/ 92 && c !== /*/*/ 47))
                                {
                                    if (this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/))
                                    {
                                        return 7/*ParsingError.MustRootedPath*/;
                                    }
                                }
                                else 
                                {
                                    this._flags |= 8796093022208n;
                                    if (this._syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/))
                                    {
                                        this._flags |= 68719476736n;
                                    }
                                    if (i !== idx && ((i - idx) | 0) !== 2)
                                    {
                                        idx = ((i - 1) | 0);
                                    }
                                    else 
                                    {
                                        idx = i;
                                    }
                                }
                            }
                            else if (this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/) && (((i - idx) | 0) >= 2 && ((i - idx) | 0) !== 3 && i < length && pUriString.GetAt(i) !== /*?*/ 63 && pUriString.GetAt(i) !== /*#*/ 35))
                            {
                                this._flags |= 17592186044416n;
                                idx = i;
                            }
                            else if (!$.$$.System.OperatingSystem.IsWindows() && this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/) && pUriString.GetAt(((i - 1) | 0)) === /*/*/ 47 && ((i - idx) | 0) === 3)
                            {
                                this._syntax = $.$spu.System.UriParser.UnixFileUri;
                                this._flags |= 18014398509481984n | 68719476736n;
                                idx += 2;
                            }
                        }
                    }
                    if ((this._flags & (17592186044416n | 8796093022208n | 18014398509481984n)) !== 0n)
                    {
                    }
                    else if ((((idx + 2) | 0)) <= length)
                    {
                        /*char*/ let first = pUriString.GetAt(idx);
                        /*char*/ let second = pUriString.GetAt(((idx + 1) | 0));
                        if (this._syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/))
                        {
                            if ((first === /*/*/ 47 || first === /*\\*/ 92) && (second === /*/*/ 47 || second === /*\\*/ 92))
                            {
                                this._flags |= 68719476736n;
                                idx += 2;
                            }
                            else 
                            {
                                return 3/*ParsingError.BadAuthority*/;
                            }
                        }
                        else if (this._syntax.InFact(2/*UriSyntaxFlags.OptionalAuthority*/) && (this.InFact(68719476736n) || (first === /*/*/ 47 && second === /*/*/ 47)))
                        {
                            this._flags |= 68719476736n;
                            idx += 2;
                        }
                        else if (this._syntax.NotAny(16384/*UriSyntaxFlags.MailToLikeUri*/))
                        {
                            if (this.InFact(562949953421312n))
                            {
                                this._string = $.$$.System.String.Substring.call(this._string, 0, idx);
                            }
                            this._flags |= ($.$cast(idx, $.$spu.System.Uri.Flags) | 30064771072n);
                            return 0/*ParsingError.None*/;
                        }
                    }
                    else if (this._syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/))
                    {
                        return 3/*ParsingError.BadAuthority*/;
                    }
                    else if (this._syntax.NotAny(16384/*UriSyntaxFlags.MailToLikeUri*/))
                    {
                        if (this.InFact(562949953421312n))
                        {
                            this._string = $.$$.System.String.Substring.call(this._string, 0, idx);
                        }
                        this._flags |= ($.$cast(idx, $.$spu.System.Uri.Flags) | 30064771072n);
                        return 0/*ParsingError.None*/;
                    }
                    if (this.InFact(8796093022208n))
                    {
                        this._flags |= (((this._flags & 68719476736n) !== 0n) ? 21474836480n : 30064771072n);
                        this._flags |= $.$cast(idx, $.$spu.System.Uri.Flags);
                        return 0/*ParsingError.None*/;
                    }
                    {
                        /*ParsingError*/ let err = 0/*ParsingError.None*/;
                        /*string?*/ let newHost = null;
                        idx = this.CheckAuthorityHelper(pUriString, idx, length, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.ParsingError, () => err, ($v) => err = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => this._flags, ($v) => this._flags = $v, null), this._syntax, $.$ref(() => newHost, ($v) => newHost = $v, $.$$.System.String));
                        if (err !== 0/*ParsingError.None*/)
                        {
                            return err;
                        }
                        if (idx < length)
                        {
                            /*char*/ let hostTerminator = pUriString.GetAt(idx);
                            if (hostTerminator === /*\\*/ 92 && this.NotAny(35184372088832n) && this._syntax.NotAny(1048576/*UriSyntaxFlags.AllowDOSPath*/))
                            {
                                return 11/*ParsingError.BadAuthorityTerminator*/;
                            }
                            else if (!$.$$.System.OperatingSystem.IsWindows() && hostTerminator === /*/*/ 47 && this.NotAny(35184372088832n) && this.InFact(17592186044416n) && this._syntax === $.$spu.System.UriParser.FileUri)
                            {
                                this._syntax = $.$spu.System.UriParser.UnixFileUri;
                            }
                        }
                        if (!(newHost === null))
                        {
                            this._string = newHost;
                        }
                    }
                    this._flags |= $.$cast(idx, $.$spu.System.Uri.Flags);
                }
                return 0/*ParsingError.None*/;
            }
            //--TRIMMABLE-BOUNDARY-END(871880065026)
            
            //--TRIMMABLE-BOUNDARY-START(197570199554)
            /*void */ CreateUriInfo(/*Flags*/ cF)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570199554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*UriInfo*/ let info;
                /*int*/ let idx;
                /*bool*/ let notCanonicalScheme;
                /*bool*/ let notEmpty;
                /*Flags*/ let current;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            info = new $.$spu.System.Uri.UriInfo().$ctor$1();
                            info.Offset.End = this._string.length;
                            if (this.UserDrivenParsing)
                            {
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            notCanonicalScheme = false;
                            if ((cF & 35184372088832n) !== 0n)
                            {
                                idx = 0;
                                while($.$spu.System.UriHelper.IsLWS($.$$.System.String.get_Chars.call(this._string, idx)))
                                {
                                    ++idx;
                                    ++info.Offset.Scheme;
                                }
                                if ($.$spu.System.Uri.StaticInFact(cF, 17592186044416n))
                                {
                                    idx += 2;
                                    /*int*/ let end = $.$cast((cF & 4294967295n), $.$$.System.Int32);
                                    while(idx < end && ($.$$.System.String.get_Chars.call(this._string, idx) === /*/*/ 47 || $.$$.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92))
                                    {
                                        ++idx;
                                    }
                                }
                            }
                            else 
                            {
                                idx = this._syntax.SchemeName.length;
                                while($.$$.System.String.get_Chars.call(this._string, idx++) !== /*:*/ 58)
                                {
                                    ++info.Offset.Scheme;
                                }
                                if ((cF & 68719476736n) !== 0n)
                                {
                                    if ($.$$.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92 || $.$$.System.String.get_Chars.call(this._string, ((idx + 1) | 0)) === /*\\*/ 92)
                                    {
                                        notCanonicalScheme = true;
                                    }
                                    idx += 2;
                                    if ((cF & (17592186044416n | 8796093022208n)) !== 0n)
                                    {
                                        /*int*/ let end = $.$cast((cF & 4294967295n), $.$$.System.Int32);
                                        while(idx < end && ($.$$.System.String.get_Chars.call(this._string, idx) === /*/*/ 47 || $.$$.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92))
                                        {
                                            notCanonicalScheme = true;
                                            ++idx;
                                        }
                                    }
                                }
                            }
                            if (this._syntax.DefaultPort !== -1/*UriParser.NoDefaultPort*/)
                            {
                                info.Offset.PortValue = $.$cast(this._syntax.DefaultPort, $.$$.System.UInt16);
                            }
                            if ((cF & 30064771072n) === 30064771072n || $.$spu.System.Uri.StaticInFact(cF, 8796093022208n))
                            {
                                info.Offset.User = $.$cast((cF & 4294967295n), $.$$.System.Int32);
                                info.Offset.Host = info.Offset.User;
                                info.Offset.Path = info.Offset.User;
                                cF &= ~4294967295n;
                                if (notCanonicalScheme)
                                {
                                    cF |= 1n;
                                }
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            info.Offset.User = idx;
                            if (this.HostType === 21474836480n)
                            {
                                info.Offset.Host = idx;
                                info.Offset.Path = $.$cast((cF & 4294967295n), $.$$.System.Int32);
                                cF &= ~4294967295n;
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            if ((cF & 137438953472n) !== 0n)
                            {
                                while($.$$.System.String.get_Chars.call(this._string, idx) !== /*@*/ 64)
                                {
                                    ++idx;
                                }
                                ++idx;
                                info.Offset.Host = idx;
                            }
                            else 
                            {
                                info.Offset.Host = idx;
                            }
                            idx = $.$cast((cF & 4294967295n), $.$$.System.Int32);
                            cF &= ~4294967295n;
                            if (notCanonicalScheme)
                            {
                                cF |= 1n;
                            }
                            info.Offset.Path = idx;
                            notEmpty = false;
                            if ((cF & 562949953421312n) !== 0n)
                            {
                                info.Offset.End = this._originalUnicodeString.length;
                            }
                            if (idx < info.Offset.End)
                            {
                                /*fixed*/ 
                                {
                                    /*char**/ let userString = $.$$.System.String.GetPinnableReference.call(this.OriginalString);
                                    if (userString.GetAt(idx) === /*:*/ 58)
                                    {
                                        /*int*/ let port = 0;
                                        if (++idx < info.Offset.End)
                                        {
                                            port = userString.GetAt(idx) - /*0*/ 48;
                                            if ((port >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                                            {
                                                notEmpty = true;
                                                if (port === 0)
                                                {
                                                    cF |= (8n | 512n);
                                                }
                                                for(++idx; idx < info.Offset.End; ++idx)
                                                {
                                                    /*int*/ let val = userString.GetAt(idx) - /*0*/ 48;
                                                    if ((val >>> 0) > (/*9*/ 57 - /*0*/ 48))
                                                    {
                                                        break;
                                                    }
                                                    port = (((((port * 10) | 0) + val) | 0));
                                                }
                                            }
                                        }
                                        if (notEmpty && this._syntax.DefaultPort !== port)
                                        {
                                            info.Offset.PortValue = $.$cast(port, $.$$.System.UInt16);
                                            cF |= 549755813888n;
                                        }
                                        else 
                                        {
                                            cF |= (8n | 512n);
                                        }
                                        info.Offset.Path = idx;
                                    }
                                }
                            }
                        }
                        case 1: /*Done*/
                        cF |= 70368744177664n;
                        $.$$.System.Threading.Interlocked.CompareExchange$14($.$spu.System.Uri.UriInfo, $.$ref(() => this._info, ($v) => this._info = $v, $.$spu.System.Uri.UriInfo), info, null);
                        current = this._flags;
                        while((current & 70368744177664n) === 0n)
                        {
                            /*Flags*/ let oldValue = $.$$.System.Threading.Interlocked.CompareExchange$14($.$spu.System.Uri.Flags, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => this._flags, ($v) => this._flags = $v, null), (current & ~4294967295n) | cF, current);
                            if (oldValue === current)
                            {
                                return;
                            }
                            current = oldValue;
                        }
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197570199554)
            
            //--TRIMMABLE-BOUNDARY-START(176095363074)
            /*void */ CreateHostString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095363074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._syntax.IsSimple)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._info)
                        {
                            if (this.NotAny(4398046511104n))
                            {
                                this._flags |= 4398046511104n;
                                this.GetHostViaCustomSyntax();
                                this._flags &= ~4398046511104n;
                                return;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._info)
                    }
                }
                /*Flags*/ let flags = this._flags;
                /*string*/ let host = $.$spu.System.Uri.CreateHostStringHelper(this._string, this._info.Offset.Host, this._info.Offset.Path, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => flags, ($v) => flags = $v, null), this._info);
                if (host.length !== 0)
                {
                    if (this.HostType === 21474836480n)
                    {
                        /*int*/ let idx = 0;
                        /*Check*/ let result;
                        /*fixed*/ 
                        {
                            /*char**/ let pHost = $.$$.System.String.GetPinnableReference.call(host);
                            result = this.CheckCanonical(pHost, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), host.length, /*\uFFFF*/ 65535);
                        }
                        if ((result & 2/*Check.DisplayCanonical*/) === 0)
                        {
                            if (this.NotAny(35184372088832n) || (result & 32/*Check.ReservedFound*/) !== 0)
                            {
                                flags |= 4n;
                            }
                        }
                        if (this.InFact(35184372088832n) && (result & (32/*Check.ReservedFound*/ | 1/*Check.EscapedCanonical*/)) !== 0)
                        {
                            result &= ~1/*Check.EscapedCanonical*/;
                        }
                        if ((result & (1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/)) !== 1/*Check.EscapedCanonical*/)
                        {
                            flags |= 256n;
                            if (this.NotAny(34359738368n))
                            {
                                host = $.$spu.System.UriHelper.EscapeString$2(host, !this.IsImplicitFile, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
                            }
                            else 
                            {
                            }
                        }
                    }
                    else if (this.NotAny(2199023255552n))
                    {
                        if (!((this._info._moreInfo?.ScopeId ?? null) === null))
                        {
                            flags |= (4n | 256n);
                        }
                        else 
                        {
                            for(/*int*/ let i = 0; i < host.length; ++i)
                            {
                                if ((((this._info.Offset.Host + i) | 0)) >= this._info.Offset.End || $.$$.System.String.get_Chars.call(host, i) !== $.$$.System.String.get_Chars.call(this._string, ((this._info.Offset.Host + i) | 0)))
                                {
                                    flags |= (4n | 256n);
                                    break;
                                }
                            }
                        }
                    }
                }
                this._info.Host = host;
                this.InterlockedSetFlags(flags);
            }
            //--TRIMMABLE-BOUNDARY-END(176095363074)
            
            //--TRIMMABLE-BOUNDARY-START(180390330370)
            static /*string */ CreateHostStringHelper(/*string*/ str, /*int*/ idx, /*int*/ end, /*ref Flags*/ flags, /*UriInfo*/ info)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390330370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let loopback = false;
                /*string*/ let host;
                let $switch1 = flags.$v & 30064771072n;
                switch($switch1)
                {
                    case 12884901888n:
                    host = $.$spu.System.DomainNameHelper.ParseCanonicalName(str, idx, end, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => loopback, ($v) => loopback = $v, null));
                    break;
                    case 4294967296n:
                    /*ReadOnlySpan<char>*/ let scopeIdSpan;
                    host = $.$spu.System.Net.IPv6AddressHelper.ParseCanonicalName($.$$.System.MemoryExtensions.AsSpan$2(str, idx), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => loopback, ($v) => loopback = $v, null), $.$ref(() => scopeIdSpan, ($v) => scopeIdSpan = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Char)));
                    if (!scopeIdSpan.IsEmpty)
                    {
                        info.MoreInfo.ScopeId = $.$$.System.String.Create$7(scopeIdSpan);
                    }
                    break;
                    case 8589934592n:
                    host = $.$spu.System.Net.IPv4AddressHelper.ParseCanonicalName(str, idx, end, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => loopback, ($v) => loopback = $v, null));
                    break;
                    case 17179869184n:
                    host = $.$spu.System.UncNameHelper.ParseCanonicalName(str, idx, end, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => loopback, ($v) => loopback = $v, null));
                    break;
                    case 21474836480n:
                    if ($.$spu.System.Uri.StaticInFact(flags.$v, 8796093022208n))
                    {
                        host = $.$$.System.String.Empty;
                    }
                    else 
                    {
                        host = $.$$.System.String.Substring.call(str, idx, ((end - idx) | 0));
                    }
                    if (host.length === 0)
                    {
                        loopback = true;
                    }
                    break;
                    case 30064771072n:
                    host = $.$$.System.String.Empty;
                    break;
                    default:
                    throw $.$spu.System.Uri.GetException(8/*ParsingError.BadHostName*/);
                }
                if (loopback)
                {
                    flags.$v |= 274877906944n;
                }
                return host;
            }
            //--TRIMMABLE-BOUNDARY-END(180390330370)
            
            //--TRIMMABLE-BOUNDARY-START(614182027266)
            /*void */ GetHostViaCustomSyntax()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(614182027266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Inequality(this._info.Host, null))
                {
                    return;
                }
                /*string*/ let host = this._syntax.InternalGetComponents(this, 4/*UriComponents.Host*/, 1/*UriFormat.UriEscaped*/);
                if (this._info.Host === null)
                {
                    /*ParsingError*/ let err = 0/*ParsingError.None*/;
                    /*Flags*/ let flags = this._flags & ~30064771072n;
                    /*fixed*/ 
                    {
                        /*char**/ let pHost = $.$$.System.String.GetPinnableReference.call(host);
                        /*string?*/ let newHost = null;
                        if (this.CheckAuthorityHelper(pHost, 0, host.length, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.ParsingError, () => err, ($v) => err = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => flags, ($v) => flags = $v, null), this._syntax, $.$ref(() => newHost, ($v) => newHost = $v, $.$$.System.String)) !== host.length)
                        {
                            flags &= ~30064771072n;
                            flags |= 30064771072n;
                        }
                    }
                    if (err !== 0/*ParsingError.None*/ || (flags & 30064771072n) === 30064771072n)
                    {
                        this._flags = (this._flags & ~30064771072n) | 21474836480n;
                    }
                    else 
                    {
                        host = $.$spu.System.Uri.CreateHostStringHelper(host, 0, host.length, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => flags, ($v) => flags = $v, null), this._info);
                        for(/*int*/ let i = 0; i < host.length; ++i)
                        {
                            if ((((this._info.Offset.Host + i) | 0)) >= this._info.Offset.End || $.$$.System.String.get_Chars.call(host, i) !== $.$$.System.String.get_Chars.call(this._string, ((this._info.Offset.Host + i) | 0)))
                            {
                                this._flags |= (4n | 256n);
                                break;
                            }
                        }
                        this._flags = (this._flags & ~30064771072n) | (flags & 30064771072n);
                    }
                }
                /*string*/ let portStr = this._syntax.InternalGetComponents(this, 128/*UriComponents.StrongPort*/, 1/*UriFormat.UriEscaped*/);
                /*int*/ let port = 0;
                if ($.$$.System.String.IsNullOrEmpty(portStr))
                {
                    this._flags &= ~549755813888n;
                    this._flags |= (8n | 512n);
                    this._info.Offset.PortValue = 0;
                }
                else 
                {
                    for(/*int*/ let idx = 0; idx < portStr.length; ++idx)
                    {
                        /*int*/ let val = $.$$.System.String.get_Chars.call(portStr, idx) - /*0*/ 48;
                        if (val < 0 || val > 9 || (port = (((((port * 10) | 0) + val) | 0))) > 65535)
                        {
                            throw new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.Format$5($.$spu.System.SR.net_uri_PortOutOfRange, $.$$.System.Object.GetType.call(this._syntax), portStr));
                        }
                    }
                    if (port !== this._info.Offset.PortValue)
                    {
                        if (port === this._syntax.DefaultPort)
                        {
                            this._flags &= ~549755813888n;
                        }
                        else 
                        {
                            this._flags |= 549755813888n;
                        }
                        this._flags |= (8n | 512n);
                        this._info.Offset.PortValue = $.$cast(port, $.$$.System.UInt16);
                    }
                }
                this._info.Host = host;
            }
            //--TRIMMABLE-BOUNDARY-END(614182027266)
            
            //--TRIMMABLE-BOUNDARY-START(635656863746)
            /*string */ GetParts(/*UriComponents*/ uriParts, /*UriFormat*/ formatAs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(635656863746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InternalGetComponents(uriParts, formatAs);
            }
            //--TRIMMABLE-BOUNDARY-END(635656863746)
            
            //--TRIMMABLE-BOUNDARY-START(601297125378)
            /*string */ GetEscapedParts(/*UriComponents*/ uriParts)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(601297125378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._info !== null && (this._flags & 70368744177664n) !== 0n, "_info != null && (_flags & Flags.MinimalUriInfoSet) != 0");
                /*ushort*/ let nonCanonical = $.$cast((($.$cast(this._flags, $.$$.System.UInt16) & (($.$cast(127n, $.$$.System.UInt16) << 7) >>> 0)) >> 6), $.$$.System.UInt16);
                if (this.InFact(1n))
                {
                    nonCanonical |= $.$cast(1n, $.$$.System.UInt16);
                }
                if ((uriParts & 16/*UriComponents.Path*/) !== 0)
                {
                    if (this.InFact(8192n | 16384n | 32768n))
                    {
                        nonCanonical |= $.$cast(16n, $.$$.System.UInt16);
                    }
                    else if (this.IsDosPath && $.$$.System.String.get_Chars.call(this._string, ((((this._info.Offset.Path + this.SecuredPathIndex) | 0) - 1) | 0)) === /*|*/ 124)
                    {
                        nonCanonical |= $.$cast(16n, $.$$.System.UInt16);
                    }
                }
                if (($.$cast(uriParts, $.$$.System.UInt16) & nonCanonical) === 0)
                {
                    /*string?*/ let ret = this.GetUriPartsFromUserString(uriParts);
                    if (!(ret === null))
                    {
                        return ret;
                    }
                }
                return this.RecreateParts(uriParts, nonCanonical, 1/*UriFormat.UriEscaped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(601297125378)
            
            //--TRIMMABLE-BOUNDARY-START(644246798338)
            /*string */ GetUnescapedParts(/*UriComponents*/ uriParts, /*UriFormat*/ formatAs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(644246798338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._info !== null && (this._flags & 70368744177664n) !== 0n, "_info != null && (_flags & Flags.MinimalUriInfoSet) != 0");
                /*ushort*/ let nonCanonical = $.$cast(($.$cast(this._flags, $.$$.System.UInt16) & $.$cast(127n, $.$$.System.UInt16)), $.$$.System.UInt16);
                if ((uriParts & 16/*UriComponents.Path*/) !== 0)
                {
                    if ((this._flags & (8192n | 16384n | 32768n)) !== 0n)
                    {
                        nonCanonical |= $.$cast(16n, $.$$.System.UInt16);
                    }
                    else if (this.IsDosPath && $.$$.System.String.get_Chars.call(this._string, ((((this._info.Offset.Path + this.SecuredPathIndex) | 0) - 1) | 0)) === /*|*/ 124)
                    {
                        nonCanonical |= $.$cast(16n, $.$$.System.UInt16);
                    }
                }
                if (($.$cast(uriParts, $.$$.System.UInt16) & nonCanonical) === 0)
                {
                    /*string?*/ let ret = this.GetUriPartsFromUserString(uriParts);
                    if (!(ret === null))
                    {
                        return ret;
                    }
                }
                return this.RecreateParts(uriParts, nonCanonical, formatAs);
            }
            //--TRIMMABLE-BOUNDARY-END(644246798338)
            
            //--TRIMMABLE-BOUNDARY-START(880469999618)
            /*string */ RecreateParts(/*UriComponents*/ parts, /*ushort*/ nonCanonical, /*UriFormat*/ formatAs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(880469999618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureHostString(false);
                /*string*/ let str = this._string;
                /*var*/ let dest = str.length <= 512/*StackallocThreshold*/ ? new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null)) : new $.$spu.System.Text.ValueStringBuilder().$ctor$3(str.length);
                /*scoped ReadOnlySpan<char>*/ let result = this.RecreateParts$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null), str, parts, nonCanonical, formatAs);
                /*string*/ let s = $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(result);
                dest.Dispose();
                return s;
            }
            //--TRIMMABLE-BOUNDARY-END(880469999618)
            
            //--TRIMMABLE-BOUNDARY-START(992139149314)
            /*bool */ TryRecreateParts(/*scoped Span<char>*/ span, /*out int*/ charsWritten, /*UriComponents*/ parts, /*ushort*/ nonCanonical, /*UriFormat*/ formatAs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(992139149314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureHostString(false);
                /*string*/ let str = this._string;
                /*var*/ let dest = str.length <= 512/*StackallocThreshold*/ ? new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null)) : new $.$spu.System.Text.ValueStringBuilder().$ctor$3(str.length);
                /*scoped ReadOnlySpan<char>*/ let result = this.RecreateParts$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null), str, parts, nonCanonical, formatAs);
                /*bool*/ let copied = result.TryCopyTo(span);
                charsWritten.$v = copied ? result.Length : 0;
                dest.Dispose();
                return copied;
            }
            //--TRIMMABLE-BOUNDARY-END(992139149314)
            
            //--TRIMMABLE-BOUNDARY-START(884764966914)
            /*ReadOnlySpan<char> */ RecreateParts$1(/*scoped ref ValueStringBuilder*/ dest, /*string*/ str, /*UriComponents*/ parts, /*ushort*/ nonCanonical, /*UriFormat*/ formatAs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(884764966914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(this.InFact(140737488355328n), "InFact(Flags.AllUriInfoSet)");
                            if ((parts & 1/*UriComponents.Scheme*/) !== 0)
                            {
                                dest.$v.Append$3(this._syntax.SchemeName);
                                if (parts !== 1/*UriComponents.Scheme*/)
                                {
                                    dest.$v.Append$1(/*:*/ 58);
                                    if (this.InFact(68719476736n))
                                    {
                                        dest.$v.Append$1(/*/*/ 47);
                                        dest.$v.Append$1(/*/*/ 47);
                                    }
                                }
                            }
                            if ((parts & 2/*UriComponents.UserInfo*/) !== 0 && this.InFact(137438953472n))
                            {
                                /*ReadOnlySpan<char>*/ let slice = $.$$.System.MemoryExtensions.AsSpan$1(str, this._info.Offset.User, ((this._info.Offset.Host - this._info.Offset.User) | 0));
                                if ((nonCanonical & $.$cast(2/*UriComponents.UserInfo*/, $.$$.System.UInt16)) !== 0)
                                {
                                    switch(formatAs)
                                    {
                                        case 1/*UriFormat.UriEscaped*/:
                                        if (this.NotAny(34359738368n))
                                        {
                                            $.$spu.System.UriHelper.EscapeString$1(slice, dest, true, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
                                        }
                                        else 
                                        {
                                            dest.$v.Append$2(slice);
                                        }
                                        break;
                                        case 3/*UriFormat.SafeUnescaped*/:
                                        let $t3 = slice;
                                        $.$spu.System.UriHelper.UnescapeString$2($t3.Slice(0, $t3.Length - 1), dest, /*@*/ 64, /*/*/ 47, /*\\*/ 92, this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/, this._syntax, false);
                                        dest.$v.Append$1(/*@*/ 64);
                                        break;
                                        case 2/*UriFormat.Unescaped*/:
                                        $.$spu.System.UriHelper.UnescapeString$2(slice, dest, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, this._syntax, false);
                                        break;
                                        default:
                                        dest.$v.Append$2(slice);
                                        break;
                                    }
                                }
                                else 
                                {
                                    dest.$v.Append$2(slice);
                                }
                                if (parts === 2/*UriComponents.UserInfo*/)
                                {
                                    dest.$v.Length--;
                                }
                            }
                            if ((parts & 4/*UriComponents.Host*/) !== 0)
                            {
                                /*string*/ let host = this._info.Host;
                                if (host.length !== 0)
                                {
                                    /*UnescapeMode*/ let mode;
                                    if (formatAs !== 1/*UriFormat.UriEscaped*/ && this.HostType === 21474836480n && (nonCanonical & $.$cast(4/*UriComponents.Host*/, $.$$.System.UInt16)) !== 0)
                                    {
                                        mode = formatAs === 2/*UriFormat.Unescaped*/ ? (2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/) : (this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/);
                                    }
                                    else 
                                    {
                                        mode = 0/*UnescapeMode.CopyOnly*/;
                                    }
                                    /*var*/ let hostBuilder = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                                    if ((parts & 256/*UriComponents.NormalizedHost*/) !== 0)
                                    {
                                        host = $.$spu.System.UriHelper.StripBidiControlCharacters($.$$.System.String.op_Implicit(host), host);
                                        if (!$.$spu.System.DomainNameHelper.TryGetUnicodeEquivalent(host, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => hostBuilder, ($v) => hostBuilder = $v, null)))
                                        {
                                            hostBuilder.Length = 0;
                                        }
                                    }
                                    $.$spu.System.UriHelper.UnescapeString$2(hostBuilder.Length === 0 ? $.$$.System.String.op_Implicit(host) : hostBuilder.AsSpan(), dest, /*/*/ 47, /*?*/ 63, /*#*/ 35, mode, this._syntax, false);
                                    hostBuilder.Dispose();
                                    let scopeId;
                                    if ((parts & -2147483648/*UriComponents.SerializationInfoString*/) !== 0 && this.HostType === 4294967296n && $.$is((this._info._moreInfo?.ScopeId ?? null), $.$$.System.String, { set $v(v){ scopeId = v; } }))
                                    {
                                        dest.$v.Length--;
                                        dest.$v.Append$3(scopeId);
                                        dest.$v.Append$1(/*]*/ 93);
                                    }
                                }
                            }
                            if ((parts & 8/*UriComponents.Port*/) !== 0 && (this.InFact(549755813888n) || ((parts & 128/*UriComponents.StrongPort*/) !== 0 && this._syntax.DefaultPort !== -1/*UriParser.NoDefaultPort*/)))
                            {
                                dest.$v.Append$1(/*:*/ 58);
                                /*int*/ let MaxUshortLength = 5;
                                /*int*/ let charsWritten;
                                /*bool*/ let success = $.$$.System.UInt16.TryFormat$1.call(this._info.Offset.PortValue, dest.$v.AppendSpan(MaxUshortLength), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                                $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                                dest.$v.Length -= ((MaxUshortLength - charsWritten) | 0);
                            }
                            if ((parts & 16/*UriComponents.Path*/) !== 0)
                            {
                                this.GetCanonicalPath(dest, formatAs);
                                if (parts === 16/*UriComponents.Path*/)
                                {
                                    /*int*/ let offset;
                                    if (this.InFact(68719476736n) && dest.$v.Length !== 0 && dest.$v.get_Item$1(0).$v === /*/*/ 47)
                                    {
                                        offset = 1;
                                    }
                                    else 
                                    {
                                        offset = 0;
                                    }
                                    return dest.$v.AsSpan$3(offset);
                                }
                            }
                            if ((parts & 32/*UriComponents.Query*/) !== 0 && this._info.Offset.Query < this._info.Offset.Fragment)
                            {
                                /*int*/ let offset = (((this._info.Offset.Query + 1) | 0));
                                if (parts !== 32/*UriComponents.Query*/)
                                {
                                    dest.$v.Append$1(/*?*/ 63);
                                }
                                /*UnescapeMode*/ let mode = 0/*UnescapeMode.CopyOnly*/;
                                if ((nonCanonical & $.$cast(32/*UriComponents.Query*/, $.$$.System.UInt16)) !== 0)
                                {
                                    if (formatAs === 1/*UriFormat.UriEscaped*/)
                                    {
                                        if (this.NotAny(34359738368n))
                                        {
                                            $.$spu.System.UriHelper.EscapeString$1($.$$.System.MemoryExtensions.AsSpan$1(str, offset, ((this._info.Offset.Fragment - offset) | 0)), dest, true, $.$spu.System.UriHelper.UnreservedReservedExceptHash);
                                            $gotoJumpState1 = 1; /*goto AfterQuery*/
                                            continue $gotoJumpStart1;
                                        }
                                    }
                                    else 
                                    {
                                        mode = (() =>
                                        {
                                            if (formatAs === 32767/*V1ToStringUnescape*/)
                                            {
                                                return (this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/) | 4/*UnescapeMode.V1ToStringFlag*/;
                                            }
                                            if (formatAs === 2/*UriFormat.Unescaped*/)
                                            {
                                                return 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/;
                                            }
                                            return this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/;
                                        })();
                                    }
                                }
                                $.$spu.System.UriHelper.UnescapeString$4(str, offset, this._info.Offset.Fragment, dest, /*#*/ 35, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, mode, this._syntax, true);
                            }
                        }
                        case 1: /*AfterQuery*/
                        if ((parts & 64/*UriComponents.Fragment*/) !== 0 && this._info.Offset.Fragment < this._info.Offset.End)
                        {
                            /*int*/ let offset = ((this._info.Offset.Fragment + 1) | 0);
                            if (parts !== 64/*UriComponents.Fragment*/)
                            {
                                dest.$v.Append$1(/*#*/ 35);
                            }
                            /*UnescapeMode*/ let mode = 0/*UnescapeMode.CopyOnly*/;
                            if ((nonCanonical & $.$cast(64/*UriComponents.Fragment*/, $.$$.System.UInt16)) !== 0)
                            {
                                if (formatAs === 1/*UriFormat.UriEscaped*/)
                                {
                                    if (this.NotAny(34359738368n))
                                    {
                                        $.$spu.System.UriHelper.EscapeString$1($.$$.System.MemoryExtensions.AsSpan$1(str, offset, ((this._info.Offset.End - offset) | 0)), dest, true, $.$spu.System.UriHelper.UnreservedReserved);
                                        $gotoJumpState1 = 2; /*goto AfterFragment*/
                                        continue $gotoJumpStart1;
                                    }
                                }
                                else 
                                {
                                    mode = (() =>
                                    {
                                        if (formatAs === 32767/*V1ToStringUnescape*/)
                                        {
                                            return (this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/) | 4/*UnescapeMode.V1ToStringFlag*/;
                                        }
                                        if (formatAs === 2/*UriFormat.Unescaped*/)
                                        {
                                            return 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/;
                                        }
                                        return this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/;
                                    })();
                                }
                            }
                            $.$spu.System.UriHelper.UnescapeString$4(str, offset, this._info.Offset.End, dest, /*#*/ 35, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, mode, this._syntax, false);
                        }
                        case 2: /*AfterFragment*/
                        return dest.$v.AsSpan();
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(884764966914)
            
            //--TRIMMABLE-BOUNDARY-START(648541765634)
            /*string? */ GetUriPartsFromUserString(/*UriComponents*/ uriParts)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(648541765634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let delimiterAwareIdx;
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    let $switch1 = $switchJumpState1 ?? (uriParts & ~1073741824/*UriComponents.KeepDelimiter*/);
                    switch($switch1)
                    {
                        case 1/*UriComponents.Scheme*/ | 4/*UriComponents.Host*/ | 8/*UriComponents.Port*/:
                        if (!this.InFact(137438953472n))
                        {
                            return $.$$.System.String.Substring.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.Path - this._info.Offset.Scheme) | 0));
                        }
                        return $.$$.System.String.Concat$8($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Scheme, ((this._info.Offset.User - this._info.Offset.Scheme) | 0)), $.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Host, ((this._info.Offset.Path - this._info.Offset.Host) | 0)));
                        case 132/*UriComponents.HostAndPort*/:
                        if (!this.InFact(137438953472n))
                        {
                            $switchJumpState1 = 134/*UriComponents.StrongAuthority*/; /*goto case UriComponents.StrongAuthority*/
                            continue $switchJumpStart1;
                        }
                        if (this.InFact(549755813888n) || this._syntax.DefaultPort === -1/*UriParser.NoDefaultPort*/)
                        {
                            return $.$$.System.String.Substring.call(this._string, this._info.Offset.Host, ((this._info.Offset.Path - this._info.Offset.Host) | 0));
                        }
                        return $.$$.System.String.Concat$7($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Host, ((this._info.Offset.Path - this._info.Offset.Host) | 0)), $.$$.System.String.op_Implicit(":"), $.$$.System.String.op_Implicit($.$$.System.UInt16.ToString$1.call(this._info.Offset.PortValue, $.$$.System.Globalization.CultureInfo.InvariantCulture)));
                        case 127/*UriComponents.AbsoluteUri*/:
                        if (this._info.Offset.Scheme === 0 && this._info.Offset.End === this._string.length)
                        {
                            return this._string;
                        }
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.End - this._info.Offset.Scheme) | 0));
                        case 61/*UriComponents.HttpRequestUrl*/:
                        if (this.InFact(137438953472n))
                        {
                            return $.$$.System.String.Concat$8($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Scheme, ((this._info.Offset.User - this._info.Offset.Scheme) | 0)), $.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Host, ((this._info.Offset.Fragment - this._info.Offset.Host) | 0)));
                        }
                        if (this._info.Offset.Scheme === 0 && this._info.Offset.Fragment === this._string.length)
                        {
                            return this._string;
                        }
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.Fragment - this._info.Offset.Scheme) | 0));
                        case 13/*UriComponents.SchemeAndServer*/ | 2/*UriComponents.UserInfo*/:
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.Path - this._info.Offset.Scheme) | 0));
                        case (127/*UriComponents.AbsoluteUri*/ & ~64/*UriComponents.Fragment*/):
                        if (this._info.Offset.Scheme === 0 && this._info.Offset.Fragment === this._string.length)
                        {
                            return this._string;
                        }
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.Fragment - this._info.Offset.Scheme) | 0));
                        case 1/*UriComponents.Scheme*/:
                        if (uriParts !== 1/*UriComponents.Scheme*/)
                        {
                            return $.$$.System.String.Substring.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.User - this._info.Offset.Scheme) | 0));
                        }
                        return this._syntax.SchemeName;
                        case 4/*UriComponents.Host*/:
                        /*int*/ let idx = this._info.Offset.Path;
                        if (this.InFact(549755813888n | 8n))
                        {
                            while($.$$.System.String.get_Chars.call(this._string, --idx) !== /*:*/ 58)
                            {
                            }
                        }
                        return (((idx - this._info.Offset.Host) | 0) === 0) ? $.$$.System.String.Empty : $.$$.System.String.Substring.call(this._string, this._info.Offset.Host, ((idx - this._info.Offset.Host) | 0));
                        case 16/*UriComponents.Path*/:
                        if (uriParts === 16/*UriComponents.Path*/ && this.InFact(68719476736n) && this._info.Offset.End > this._info.Offset.Path && $.$$.System.String.get_Chars.call(this._string, this._info.Offset.Path) === /*/*/ 47)
                        {
                            delimiterAwareIdx = ((this._info.Offset.Path + 1) | 0);
                        }
                        else 
                        {
                            delimiterAwareIdx = this._info.Offset.Path;
                        }
                        if (delimiterAwareIdx >= this._info.Offset.Query)
                        {
                            return $.$$.System.String.Empty;
                        }
                        return $.$$.System.String.Substring.call(this._string, delimiterAwareIdx, ((this._info.Offset.Query - delimiterAwareIdx) | 0));
                        case 32/*UriComponents.Query*/:
                        if (uriParts === 32/*UriComponents.Query*/)
                        {
                            delimiterAwareIdx = ((this._info.Offset.Query + 1) | 0);
                        }
                        else 
                        {
                            delimiterAwareIdx = this._info.Offset.Query;
                        }
                        if (delimiterAwareIdx >= this._info.Offset.Fragment)
                        {
                            return $.$$.System.String.Empty;
                        }
                        return $.$$.System.String.Substring.call(this._string, delimiterAwareIdx, ((this._info.Offset.Fragment - delimiterAwareIdx) | 0));
                        case 64/*UriComponents.Fragment*/:
                        if (uriParts === 64/*UriComponents.Fragment*/)
                        {
                            delimiterAwareIdx = ((this._info.Offset.Fragment + 1) | 0);
                        }
                        else 
                        {
                            delimiterAwareIdx = this._info.Offset.Fragment;
                        }
                        if (delimiterAwareIdx >= this._info.Offset.End)
                        {
                            return $.$$.System.String.Empty;
                        }
                        return $.$$.System.String.Substring.call(this._string, delimiterAwareIdx, ((this._info.Offset.End - delimiterAwareIdx) | 0));
                        case 2/*UriComponents.UserInfo*/ | 4/*UriComponents.Host*/ | 8/*UriComponents.Port*/:
                        return (((this._info.Offset.Path - this._info.Offset.User) | 0) === 0) ? $.$$.System.String.Empty : $.$$.System.String.Substring.call(this._string, this._info.Offset.User, ((this._info.Offset.Path - this._info.Offset.User) | 0));
                        case 134/*UriComponents.StrongAuthority*/:
                        if (this.InFact(549755813888n) || this._syntax.DefaultPort === -1/*UriParser.NoDefaultPort*/)
                        {
                            $switchJumpState1 = 2/*UriComponents.UserInfo*/ | 4/*UriComponents.Host*/ | 8/*UriComponents.Port*/; /*goto case UriComponents.UserInfo | UriComponents.Host | UriComponents.Port*/
                            continue $switchJumpStart1;
                        }
                        return $.$$.System.String.Concat$7($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.User, ((this._info.Offset.Path - this._info.Offset.User) | 0)), $.$$.System.String.op_Implicit(":"), $.$$.System.String.op_Implicit($.$$.System.UInt16.ToString$1.call(this._info.Offset.PortValue, $.$$.System.Globalization.CultureInfo.InvariantCulture)));
                        case 48/*UriComponents.PathAndQuery*/:
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.Path, ((this._info.Offset.Fragment - this._info.Offset.Path) | 0));
                        case 61/*UriComponents.HttpRequestUrl*/ | 64/*UriComponents.Fragment*/:
                        if (this.InFact(137438953472n))
                        {
                            return $.$$.System.String.Concat$8($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Scheme, ((this._info.Offset.User - this._info.Offset.Scheme) | 0)), $.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Host, ((this._info.Offset.End - this._info.Offset.Host) | 0)));
                        }
                        if (this._info.Offset.Scheme === 0 && this._info.Offset.End === this._string.length)
                        {
                            return this._string;
                        }
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.End - this._info.Offset.Scheme) | 0));
                        case 48/*UriComponents.PathAndQuery*/ | 64/*UriComponents.Fragment*/:
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.Path, ((this._info.Offset.End - this._info.Offset.Path) | 0));
                        case 2/*UriComponents.UserInfo*/:
                        if (this.NotAny(137438953472n))
                        {
                            return $.$$.System.String.Empty;
                        }
                        if (uriParts === 2/*UriComponents.UserInfo*/)
                        {
                            delimiterAwareIdx = ((this._info.Offset.Host - 1) | 0);
                        }
                        else 
                        {
                            delimiterAwareIdx = this._info.Offset.Host;
                        }
                        if (this._info.Offset.User >= delimiterAwareIdx)
                        {
                            return $.$$.System.String.Empty;
                        }
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.User, ((delimiterAwareIdx - this._info.Offset.User) | 0));
                        default:
                        return null;
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(648541765634)
            
            //--TRIMMABLE-BOUNDARY-START(622771961858)
            static /*void */ GetLengthWithoutTrailingSpaces(/*string*/ str, /*ref int*/ length, /*int*/ idx)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(622771961858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let local = length.$v;
                while(local > idx && $.$spu.System.UriHelper.IsLWS($.$$.System.String.get_Chars.call(str, ((local - 1) | 0))))
                {
                    --local;
                }
                length.$v = local;
            }
            //--TRIMMABLE-BOUNDARY-END(622771961858)
            
            //--TRIMMABLE-BOUNDARY-START(841815293954)
            /*void */ ParseRemaining()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(841815293954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Flags*/ let cF;
                /*bool*/ let buildIriStringFromPath;
                /*int*/ let origIdx;
                /*int*/ let idx;
                /*int*/ let length;
                /*Check*/ let result;
                /*UriSyntaxFlags*/ let syntaxFlags;
                /*bool*/ let nonCanonical;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            this.EnsureUriInfo();
                            cF = 0n;
                            if (this.UserDrivenParsing)
                            {
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            buildIriStringFromPath = this.InFact(562949953421312n);
                            idx = this._info.Offset.Scheme;
                            length = this._string.length;
                            result = 0/*Check.None*/;
                            syntaxFlags = this._syntax.Flags;
                            /*fixed*/ 
                            {
                                /*char**/ let str = $.$$.System.String.GetPinnableReference.call(this._string);
                                $.$spu.System.Uri.GetLengthWithoutTrailingSpaces(this._string, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32), idx);
                                if (this.IsImplicitFile)
                                {
                                    cF |= 1n;
                                }
                                else 
                                {
                                    /*int*/ let i;
                                    /*string*/ let schemeName = this._syntax.SchemeName;
                                    for(i = 0; i < schemeName.length; ++i)
                                    {
                                        if ($.$$.System.String.get_Chars.call(schemeName, i) !== str.GetAt(((idx + i) | 0)))
                                        {
                                            cF |= 1n;
                                        }
                                    }
                                    if (((this._flags & 68719476736n) !== 0n) && (((((idx + i) | 0) + 3) | 0) >= length || str.GetAt(((((idx + i) | 0) + 1) | 0)) !== /*/*/ 47 || str.GetAt(((((idx + i) | 0) + 2) | 0)) !== /*/*/ 47))
                                    {
                                        cF |= 1n;
                                    }
                                }
                                if ((this._flags & 137438953472n) !== 0n)
                                {
                                    idx = this._info.Offset.User;
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), this._info.Offset.Host, /*@*/ 64);
                                    if ((result & 2/*Check.DisplayCanonical*/) === 0)
                                    {
                                        cF |= 2n;
                                    }
                                    if ((result & (1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/)) !== 1/*Check.EscapedCanonical*/)
                                    {
                                        cF |= 128n;
                                    }
                                    if (this.IriParsing && ((result & (2/*Check.DisplayCanonical*/ | 1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) === (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                                    {
                                        cF |= 1125899906842624n;
                                    }
                                }
                            }
                            idx = this._info.Offset.Path;
                            origIdx = this._info.Offset.Path;
                            if (buildIriStringFromPath)
                            {
                                this.DebugAssertInCtor();
                                if (this.IsFile && !this.IsUncPath)
                                {
                                    if (this.IsImplicitFile)
                                    {
                                        this._string = $.$$.System.String.Empty;
                                    }
                                    else 
                                    {
                                        this._string = this._syntax.SchemeName + $.$spu.System.Uri.SchemeDelimiter;
                                    }
                                    this._info.Offset.Scheme = 0;
                                    this._info.Offset.User = this._string.length;
                                    this._info.Offset.Host = this._string.length;
                                }
                                this._info.Offset.Path = this._string.length;
                                idx = this._info.Offset.Path;
                            }
                            if (this.DisablePathAndQueryCanonicalization)
                            {
                                if (buildIriStringFromPath)
                                {
                                    this.DebugAssertInCtor();
                                    this._string = $.$$.System.String.Concat$8($.$$.System.String.op_Implicit(this._string), $.$$.System.MemoryExtensions.AsSpan$2(this._originalUnicodeString, origIdx));
                                }
                                /*string*/ let str = this._string;
                                if (this.IsImplicitFile || (syntaxFlags & 32/*UriSyntaxFlags.MayHaveQuery*/) === 0)
                                {
                                    idx = str.length;
                                }
                                else 
                                {
                                    idx = $.$$.System.String.IndexOf$3.call(str, /*?*/ 63);
                                    if (idx === -1)
                                    {
                                        idx = str.length;
                                    }
                                }
                                this._info.Offset.Query = idx;
                                this._info.Offset.Fragment = str.length;
                                this._info.Offset.End = str.length;
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            if (buildIriStringFromPath)
                            {
                                this.DebugAssertInCtor();
                                /*int*/ let offset = origIdx;
                                if (this.IsImplicitFile || ((syntaxFlags & (32/*UriSyntaxFlags.MayHaveQuery*/ | 64/*UriSyntaxFlags.MayHaveFragment*/)) === 0))
                                {
                                    origIdx = this._originalUnicodeString.length;
                                }
                                else 
                                {
                                    /*ReadOnlySpan<char>*/ let span = $.$$.System.MemoryExtensions.AsSpan$2(this._originalUnicodeString, origIdx);
                                    /*int*/ let index;
                                    if (this._syntax.InFact(32/*UriSyntaxFlags.MayHaveQuery*/))
                                    {
                                        if (this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/))
                                        {
                                            index = $.$$.System.MemoryExtensions.IndexOfAny$8($.$$.System.Char, span, /*?*/ 63, /*#*/ 35);
                                        }
                                        else 
                                        {
                                            index = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, span, /*?*/ 63);
                                        }
                                    }
                                    else 
                                    {
                                        $.$$.System.Diagnostics.Debug.Assert$2(this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/), "_syntax.InFact(UriSyntaxFlags.MayHaveFragment)");
                                        index = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, span, /*#*/ 35);
                                    }
                                    origIdx = index === -1 ? this._originalUnicodeString.length : (((index + origIdx) | 0));
                                }
                                this._string += this.EscapeUnescapeIri(this._originalUnicodeString, offset, origIdx, 16/*UriComponents.Path*/);
                                length = this._string.length;
                                if ($.$$.System.String.op_Equality(this._string, this._originalUnicodeString))
                                {
                                    $.$spu.System.Uri.GetLengthWithoutTrailingSpaces(this._string, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32), idx);
                                }
                            }
                            /*fixed*/ 
                            {
                                /*char**/ let str = $.$$.System.String.GetPinnableReference.call(this._string);
                                if (this.IsImplicitFile || ((syntaxFlags & (32/*UriSyntaxFlags.MayHaveQuery*/ | 64/*UriSyntaxFlags.MayHaveFragment*/)) === 0))
                                {
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), length, /*\uFFFF*/ 65535);
                                }
                                else 
                                {
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), length, (((syntaxFlags & 32/*UriSyntaxFlags.MayHaveQuery*/) !== 0) ? /*?*/ 63 : this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/) ? /*#*/ 35 : /*\uFFFE*/ 65534));
                                }
                                if (((this._flags & 68719476736n) !== 0n) && ((syntaxFlags & 2097152/*UriSyntaxFlags.PathIsRooted*/) !== 0) && (this._info.Offset.Path === length || (str.GetAt(this._info.Offset.Path) !== /*/*/ 47 && str.GetAt(this._info.Offset.Path) !== /*\\*/ 92)))
                                {
                                    cF |= 16384n;
                                }
                            }
                            nonCanonical = false;
                            if (this.IsDosPath || (((this._flags & 68719476736n) !== 0n) && (((syntaxFlags & (8388608/*UriSyntaxFlags.CompressPath*/ | 4194304/*UriSyntaxFlags.ConvertPathSlashes*/)) !== 0) || this._syntax.InFact(33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/))))
                            {
                                if (((result & 128/*Check.DotSlashEscaped*/) !== 0) && this._syntax.InFact(33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/))
                                {
                                    cF |= (1024n | 16n);
                                    nonCanonical = true;
                                }
                                if (((syntaxFlags & (4194304/*UriSyntaxFlags.ConvertPathSlashes*/)) !== 0) && (result & 16/*Check.BackslashInPath*/) !== 0)
                                {
                                    cF |= (1024n | 16n);
                                    nonCanonical = true;
                                }
                                if (((syntaxFlags & (8388608/*UriSyntaxFlags.CompressPath*/)) !== 0) && ((cF & 1024n) !== 0n || (result & 4/*Check.DotSlashAttn*/) !== 0))
                                {
                                    cF |= 8192n;
                                }
                                if ((result & 16/*Check.BackslashInPath*/) !== 0)
                                {
                                    cF |= 32768n;
                                }
                            }
                            else if ((result & 16/*Check.BackslashInPath*/) !== 0)
                            {
                                cF |= 1024n;
                                nonCanonical = true;
                            }
                            if ((result & 2/*Check.DisplayCanonical*/) === 0)
                            {
                                if (((this._flags & 35184372088832n) === 0n) || ((this._flags & 34359738368n) !== 0n) || (result & 32/*Check.ReservedFound*/) !== 0)
                                {
                                    cF |= 16n;
                                    nonCanonical = true;
                                }
                            }
                            if (((this._flags & 35184372088832n) !== 0n) && (result & (32/*Check.ReservedFound*/ | 1/*Check.EscapedCanonical*/)) !== 0)
                            {
                                result &= ~1/*Check.EscapedCanonical*/;
                            }
                            if ((result & 1/*Check.EscapedCanonical*/) === 0)
                            {
                                cF |= 1024n;
                            }
                            if (this.IriParsing && !nonCanonical && ((result & (2/*Check.DisplayCanonical*/ | 1/*Check.EscapedCanonical*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) === (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                            {
                                cF |= 2251799813685248n;
                            }
                            if (buildIriStringFromPath)
                            {
                                this.DebugAssertInCtor();
                                /*int*/ let offset = origIdx;
                                if (origIdx < this._originalUnicodeString.length && $.$$.System.String.get_Chars.call(this._originalUnicodeString, origIdx) === /*?*/ 63)
                                {
                                    if ((syntaxFlags & (64/*UriSyntaxFlags.MayHaveFragment*/)) !== 0)
                                    {
                                        ++origIdx;
                                        /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$2(this._originalUnicodeString, origIdx), /*#*/ 35);
                                        origIdx = index === -1 ? this._originalUnicodeString.length : (((index + origIdx) | 0));
                                    }
                                    else 
                                    {
                                        origIdx = this._originalUnicodeString.length;
                                    }
                                    this._string += this.EscapeUnescapeIri(this._originalUnicodeString, offset, origIdx, 32/*UriComponents.Query*/);
                                    length = this._string.length;
                                    if ($.$$.System.String.op_Equality(this._string, this._originalUnicodeString))
                                    {
                                        $.$spu.System.Uri.GetLengthWithoutTrailingSpaces(this._string, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32), idx);
                                    }
                                }
                            }
                            this._info.Offset.Query = idx;
                            /*fixed*/ 
                            {
                                /*char**/ let str = $.$$.System.String.GetPinnableReference.call(this._string);
                                if (idx < length && str.GetAt(idx) === /*?*/ 63)
                                {
                                    ++idx;
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), length, ((syntaxFlags & (64/*UriSyntaxFlags.MayHaveFragment*/)) !== 0) ? /*#*/ 35 : /*\uFFFE*/ 65534);
                                    if ((result & 2/*Check.DisplayCanonical*/) === 0)
                                    {
                                        cF |= 32n;
                                    }
                                    if ((result & (1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/)) !== 1/*Check.EscapedCanonical*/)
                                    {
                                        cF |= 2048n;
                                    }
                                    if (this.IriParsing && ((result & (2/*Check.DisplayCanonical*/ | 1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) === (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                                    {
                                        cF |= 4503599627370496n;
                                    }
                                }
                            }
                            if (buildIriStringFromPath)
                            {
                                this.DebugAssertInCtor();
                                /*int*/ let offset = origIdx;
                                if (origIdx < this._originalUnicodeString.length && $.$$.System.String.get_Chars.call(this._originalUnicodeString, origIdx) === /*#*/ 35)
                                {
                                    origIdx = this._originalUnicodeString.length;
                                    this._string += this.EscapeUnescapeIri(this._originalUnicodeString, offset, origIdx, 64/*UriComponents.Fragment*/);
                                    length = this._string.length;
                                    $.$spu.System.Uri.GetLengthWithoutTrailingSpaces(this._string, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32), idx);
                                }
                            }
                            this._info.Offset.Fragment = idx;
                            /*fixed*/ 
                            {
                                /*char**/ let str = $.$$.System.String.GetPinnableReference.call(this._string);
                                if (idx < length && str.GetAt(idx) === /*#*/ 35)
                                {
                                    ++idx;
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), length, /*\uFFFE*/ 65534);
                                    if ((result & 2/*Check.DisplayCanonical*/) === 0)
                                    {
                                        cF |= 64n;
                                    }
                                    if ((result & (1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/)) !== 1/*Check.EscapedCanonical*/)
                                    {
                                        cF |= 4096n;
                                    }
                                    if (this.IriParsing && ((result & (2/*Check.DisplayCanonical*/ | 1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) === (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                                    {
                                        cF |= 9007199254740992n;
                                    }
                                }
                            }
                            this._info.Offset.End = idx;
                        }
                        case 1: /*Done*/
                        cF |= 140737488355328n;
                        this.InterlockedSetFlags(cF);
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(841815293954)
            
            //--TRIMMABLE-BOUNDARY-START(850405228546)
            static /*int */ ParseSchemeCheckImplicitFile(/*string*/ uriString, /*ref ParsingError*/ err, /*ref Flags*/ flags, /*ref UriParser?*/ syntax)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(850405228546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(err.$v === 0/*ParsingError.None*/, "err == ParsingError.None");
                $.$$.System.Diagnostics.Debug.Assert$2((flags.$v & 144115188075855872n) === 0n, "(flags & Flags.Debug_LeftConstructor) == 0");
                /*int*/ let i = 0;
                while((i >>> 0) < (uriString.length >>> 0) && $.$spu.System.UriHelper.IsLWS($.$$.System.String.get_Chars.call(uriString, i)))
                {
                    i++;
                }
                if (!$.$$.System.OperatingSystem.IsWindows() && (i >>> 0) < (uriString.length >>> 0) && $.$$.System.String.get_Chars.call(uriString, i) === /*/*/ 47 && (((((i + 1) | 0)) >>> 0) >= (uriString.length >>> 0) || !(($.$$.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*/*/ 47) || ($.$$.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*\\*/ 92))))
                {
                    flags.$v |= (18014398509481984n | 35184372088832n | 68719476736n);
                    syntax.$v = $.$spu.System.UriParser.UnixFileUri;
                    return i;
                }
                /*int*/ let colonOffset = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$2(uriString, i), /*:*/ 58);
                if (((((i + 2) | 0)) >>> 0) >= (uriString.length >>> 0) || colonOffset === 0 || (i >>> 0) >= (uriString.length >>> 0) || ((((i + 1) | 0)) >>> 0) >= (uriString.length >>> 0))
                {
                    err.$v = 1/*ParsingError.BadFormat*/;
                    return 0;
                }
                if (($.$$.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*:*/ 58) || ($.$$.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*|*/ 124))
                {
                    if ($.$$.System.Char.IsAsciiLetter($.$$.System.String.get_Chars.call(uriString, i)))
                    {
                        if (($.$$.System.String.get_Chars.call(uriString, ((i + 2) | 0)) === /*\\*/ 92) || ($.$$.System.String.get_Chars.call(uriString, ((i + 2) | 0)) === /*/*/ 47))
                        {
                            flags.$v |= (8796093022208n | 35184372088832n | 68719476736n);
                            syntax.$v = $.$spu.System.UriParser.FileUri;
                            return i;
                        }
                        err.$v = 7/*ParsingError.MustRootedPath*/;
                        return 0;
                    }
                    err.$v = $.$$.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*:*/ 58 ? 2/*ParsingError.BadScheme*/ : 1/*ParsingError.BadFormat*/;
                    return 0;
                }
                else if (($.$$.System.String.get_Chars.call(uriString, i) === /*/*/ 47) || ($.$$.System.String.get_Chars.call(uriString, i) === /*\\*/ 92))
                {
                    if (($.$$.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*\\*/ 92) || ($.$$.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*/*/ 47))
                    {
                        flags.$v |= (17592186044416n | 35184372088832n | 68719476736n);
                        syntax.$v = $.$spu.System.UriParser.FileUri;
                        i += 2;
                        while((i >>> 0) < (uriString.length >>> 0) && ($.$$.System.String.get_Chars.call(uriString, i) === /*/*/ 47) || ($.$$.System.String.get_Chars.call(uriString, i) === /*\\*/ 92))
                        {
                            i++;
                        }
                        return i;
                    }
                    err.$v = 1/*ParsingError.BadFormat*/;
                    return 0;
                }
                if (colonOffset < 0)
                {
                    err.$v = 1/*ParsingError.BadFormat*/;
                    return 0;
                }
                syntax.$v = $.$spu.System.Uri.CheckSchemeSyntax($.$$.System.MemoryExtensions.AsSpan$1(uriString, i, colonOffset), err);
                if (syntax.$v === null)
                {
                    return 0;
                }
                return ((((i + colonOffset) | 0) + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(850405228546)
            
            //--TRIMMABLE-BOUNDARY-START(150325559298)
            static /*UriParser? */ CheckSchemeSyntax(/*ReadOnlySpan<char>*/ scheme, /*ref ParsingError*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325559298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(error.$v === 0/*ParsingError.None*/, "error == ParsingError.None");
                let $switch1 = scheme.Length;
                switch($switch1)
                {
                    case 2:
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("ws"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.WsUri;
                    }
                    break;
                    case 3:
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("wss"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.WssUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("ftp"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.FtpUri;
                    }
                    break;
                    case 4:
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("http"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.HttpUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("file"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.FileUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("uuid"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.UuidUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("nntp"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.NntpUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("ldap"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.LdapUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("news"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.NewsUri;
                    }
                    break;
                    case 5:
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("https"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.HttpsUri;
                    }
                    break;
                    case 6:
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("mailto"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.MailToUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("gopher"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.GopherUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("telnet"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.TelnetUri;
                    }
                    break;
                    case 7:
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("net.tcp"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.NetTcpUri;
                    }
                    break;
                    case 8:
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("net.pipe"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.NetPipeUri;
                    }
                    break;
                }
                if (scheme.Length === 0 || !$.$$.System.Char.IsAsciiLetter(scheme.get_Item(0).$v) || $.$$.System.MemoryExtensions.ContainsAnyExcept($.$$.System.Char, scheme, $.$spu.System.Uri.s_schemeChars))
                {
                    error.$v = 2/*ParsingError.BadScheme*/;
                    return null;
                }
                if (scheme.Length > 1024/*SchemeLengthLimit*/)
                {
                    error.$v = 6/*ParsingError.SchemeLimit*/;
                    return null;
                }
                return $.$spu.System.UriParser.FindOrFetchAsUnknownV1Syntax($.$spu.System.UriHelper.SpanToLowerInvariantString(scheme));
            }
            //--TRIMMABLE-BOUNDARY-END(150325559298)
            
            //--TRIMMABLE-BOUNDARY-START(120260788226)
            /*int */ CheckAuthorityHelper(/*char**/ pString, /*int*/ idx, /*int*/ length, /*ref ParsingError*/ err, /*ref Flags*/ flags, /*UriParser*/ syntax, /*ref string?*/ newHost)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260788226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2((this._flags & 144115188075855872n) === 0n || (!this._syntax.IsSimple && $.$$.System.Threading.Monitor.IsEntered(this._info)), "(_flags & Flags.Debug_LeftConstructor) == 0 || (!_syntax.IsSimple && Monitor.IsEntered(_info))");
                /*int*/ let end = length;
                /*char*/ let ch;
                /*int*/ let startInput = idx;
                /*int*/ let start = idx;
                newHost.$v = null;
                /*bool*/ let hasUnicode = ((flags.$v & 562949953421312n) !== 0n);
                /*UriSyntaxFlags*/ let syntaxFlags = syntax.Flags;
                $.$$.System.Diagnostics.Debug.Assert$2((this._flags & 137438953472n) === 0n && (this._flags & 30064771072n) === 0n, "(_flags & Flags.HasUserInfo) == 0 && (_flags & Flags.HostTypeMask) == 0");
                if (hasUnicode)
                {
                    newHost.$v = $.$$.System.String.Substring.call(this._originalUnicodeString, 0, startInput);
                }
                if (idx === length || ((ch = pString.GetAt(idx)) === /*/*/ 47 || (ch === /*\\*/ 92 && $.$spu.System.Uri.StaticIsFile(syntax)) || ch === /*#*/ 35 || ch === /*?*/ 63))
                {
                    if (syntax.InFact(128/*UriSyntaxFlags.AllowEmptyHost*/))
                    {
                        flags.$v &= ~17592186044416n;
                        if ($.$spu.System.Uri.StaticInFact(flags.$v, 35184372088832n))
                        {
                            err.$v = 8/*ParsingError.BadHostName*/;
                        }
                        else 
                        {
                            flags.$v |= 21474836480n;
                        }
                    }
                    else 
                    {
                        err.$v = 8/*ParsingError.BadHostName*/;
                    }
                    return idx;
                }
                if ((syntaxFlags & 4/*UriSyntaxFlags.MayHaveUserInfo*/) !== 0)
                {
                    for(; start < end; ++start)
                    {
                        if (start === ((end - 1) | 0) || pString.GetAt(start) === /*?*/ 63 || pString.GetAt(start) === /*#*/ 35 || pString.GetAt(start) === /*\\*/ 92 || pString.GetAt(start) === /*/*/ 47)
                        {
                            start = idx;
                            break;
                        }
                        else if (pString.GetAt(start) === /*@*/ 64)
                        {
                            flags.$v |= 137438953472n;
                            if (hasUnicode)
                            {
                                newHost.$v += $.$spu.System.IriHelper.EscapeUnescapeIri(pString, startInput, ((start + 1) | 0), 2/*UriComponents.UserInfo*/);
                            }
                            ++start;
                            ch = pString.GetAt(start);
                            break;
                        }
                    }
                }
                /*int*/ let domainNameLength;
                if (ch === /*[*/ 91 && syntax.InFact(2048/*UriSyntaxFlags.AllowIPv6Host*/) && $.$spu.System.Net.IPv6AddressHelper.IsValid(pString, ((start + 1) | 0), $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32)))
                {
                    flags.$v |= 4294967296n;
                    if (hasUnicode)
                    {
                        newHost.$v = $.$$.System.String.Concat$8($.$$.System.String.op_Implicit(newHost.$v), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(start), ((end - start) | 0)));
                    }
                }
                else if ($.$$.System.Char.IsAsciiDigit(ch) && syntax.InFact(1024/*UriSyntaxFlags.AllowIPv4Host*/) && $.$spu.System.Net.IPv4AddressHelper.IsValid($.$$.System.Char, pString, start, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32), false, $.$spu.System.Uri.StaticNotAny(flags.$v, 35184372088832n), syntax.InFact(65536/*UriSyntaxFlags.V1_UnknownUri*/)))
                {
                    flags.$v |= 8589934592n;
                    if (hasUnicode)
                    {
                        newHost.$v = $.$$.System.String.Concat$8($.$$.System.String.op_Implicit(newHost.$v), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(start), ((end - start) | 0)));
                    }
                }
                else if (((syntaxFlags & 512/*UriSyntaxFlags.AllowDnsHost*/) !== 0) && !$.$spu.System.Uri.IriParsingStatic(syntax) && $.$spu.System.DomainNameHelper.IsValid(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(start), ((end - start) | 0)), false, $.$spu.System.Uri.StaticNotAny(flags.$v, 35184372088832n), $.$ref(() => domainNameLength, ($v) => domainNameLength = $v, $.$$.System.Int32)))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!hasUnicode, "!hasUnicode");
                    end = ((start + domainNameLength) | 0);
                    flags.$v |= 12884901888n;
                    if (!$.$$.System.MemoryExtensions.ContainsAnyInRange($.$$.System.Char, new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(start), domainNameLength), /*A*/ 65, /*Z*/ 90))
                    {
                        flags.$v |= 2199023255552n;
                    }
                }
                else if (((syntaxFlags & 512/*UriSyntaxFlags.AllowDnsHost*/) !== 0) && (hasUnicode || syntax.InFact(67108864/*UriSyntaxFlags.AllowIdn*/)) && $.$spu.System.DomainNameHelper.IsValid(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(start), ((end - start) | 0)), true, $.$spu.System.Uri.StaticNotAny(flags.$v, 35184372088832n), $.$ref(() => domainNameLength, ($v) => domainNameLength = $v, $.$$.System.Int32)))
                {
                    end = ((start + domainNameLength) | 0);
                    $.$spu.System.Uri.CheckAuthorityHelperHandleDnsIri(pString, start, end, hasUnicode, flags, newHost, err);
                }
                else if ((syntaxFlags & 256/*UriSyntaxFlags.AllowUncHost*/) !== 0)
                {
                    if ($.$spu.System.UncNameHelper.IsValid(pString, start, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32), $.$spu.System.Uri.StaticNotAny(flags.$v, 35184372088832n)))
                    {
                        if (((end - start) | 0) <= 256/*UncNameHelper.MaximumInternetNameLength*/)
                        {
                            flags.$v |= 17179869184n;
                            if (hasUnicode)
                            {
                                newHost.$v = $.$$.System.String.Concat$8($.$$.System.String.op_Implicit(newHost.$v), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(start), ((end - start) | 0)));
                            }
                        }
                    }
                }
                if (end < length && pString.GetAt(end) === /*\\*/ 92 && (flags.$v & 30064771072n) !== 0n && !$.$spu.System.Uri.StaticIsFile(syntax))
                {
                    if (syntax.InFact(65536/*UriSyntaxFlags.V1_UnknownUri*/))
                    {
                        err.$v = 8/*ParsingError.BadHostName*/;
                        flags.$v |= 30064771072n;
                        return end;
                    }
                    flags.$v &= ~30064771072n;
                }
                else if (end < length && pString.GetAt(end) === /*:*/ 58)
                {
                    if (syntax.InFact(8/*UriSyntaxFlags.MayHavePort*/))
                    {
                        /*int*/ let port = 0;
                        /*int*/ let startPort = end;
                        for(idx = ((end + 1) | 0); idx < length; ++idx)
                        {
                            /*int*/ let val = pString.GetAt(idx) - /*0*/ 48;
                            if ((val >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                            {
                                if ((port = (((((port * 10) | 0) + val) | 0))) > 65535)
                                {
                                    break;
                                }
                            }
                            else if (val === (/*/*/ 47 - /*0*/ 48) || val === (/*?*/ 63 - /*0*/ 48) || val === (/*#*/ 35 - /*0*/ 48))
                            {
                                break;
                            }
                            else 
                            {
                                if (syntax.InFact(4096/*UriSyntaxFlags.AllowAnyOtherHost*/) && syntax.NotAny(65536/*UriSyntaxFlags.V1_UnknownUri*/))
                                {
                                    flags.$v &= ~30064771072n;
                                    break;
                                }
                                else 
                                {
                                    err.$v = 10/*ParsingError.BadPort*/;
                                    return idx;
                                }
                            }
                        }
                        if (port > 65535)
                        {
                            if (syntax.InFact(4096/*UriSyntaxFlags.AllowAnyOtherHost*/))
                            {
                                flags.$v &= ~30064771072n;
                            }
                            else 
                            {
                                err.$v = 10/*ParsingError.BadPort*/;
                                return idx;
                            }
                        }
                        if (hasUnicode)
                        {
                            newHost.$v = $.$$.System.String.Concat$8($.$$.System.String.op_Implicit(newHost.$v), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(startPort), ((idx - startPort) | 0)));
                        }
                    }
                    else 
                    {
                        flags.$v &= ~30064771072n;
                    }
                }
                if ((flags.$v & 30064771072n) === 0n)
                {
                    flags.$v &= ~137438953472n;
                    if (syntax.InFact(4096/*UriSyntaxFlags.AllowAnyOtherHost*/))
                    {
                        flags.$v |= 21474836480n;
                        for(end = idx; end < length; ++end)
                        {
                            if (pString.GetAt(end) === /*/*/ 47 || (pString.GetAt(end) === /*?*/ 63 || pString.GetAt(end) === /*#*/ 35))
                            {
                                break;
                            }
                        }
                        if (hasUnicode)
                        {
                            try
                            {
                                newHost.$v = $.$spu.System.UriHelper.NormalizeAndConcat(newHost.$v, new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(startInput), ((end - startInput) | 0)));
                            }
                            catch($e)
                            {
                                err.$v = 8/*ParsingError.BadHostName*/;
                            }
                        }
                    }
                    else 
                    {
                        if (syntax.InFact(65536/*UriSyntaxFlags.V1_UnknownUri*/))
                        {
                            /*bool*/ let dotFound = false;
                            /*int*/ let startOtherHost = idx;
                            for(end = idx; end < length; ++end)
                            {
                                if (dotFound && (pString.GetAt(end) === /*/*/ 47 || pString.GetAt(end) === /*?*/ 63 || pString.GetAt(end) === /*#*/ 35))
                                {
                                    break;
                                }
                                else if (end < (((idx + 2) | 0)) && pString.GetAt(end) === /*.*/ 46)
                                {
                                    dotFound = true;
                                }
                                else 
                                {
                                    err.$v = 8/*ParsingError.BadHostName*/;
                                    flags.$v |= 30064771072n;
                                    return idx;
                                }
                            }
                            flags.$v |= 21474836480n;
                            if (hasUnicode)
                            {
                                try
                                {
                                    newHost.$v = $.$spu.System.UriHelper.NormalizeAndConcat(newHost.$v, new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(startOtherHost), ((end - startOtherHost) | 0)));
                                }
                                catch($e)
                                {
                                    err.$v = 1/*ParsingError.BadFormat*/;
                                    return idx;
                                }
                            }
                        }
                        else if (syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/) || (syntax.InFact(16384/*UriSyntaxFlags.MailToLikeUri*/)))
                        {
                            err.$v = 8/*ParsingError.BadHostName*/;
                            flags.$v |= 30064771072n;
                            return idx;
                        }
                    }
                }
                return end;
            }
            //--TRIMMABLE-BOUNDARY-END(120260788226)
            
            //--TRIMMABLE-BOUNDARY-START(124555755522)
            static /*void */ CheckAuthorityHelperHandleDnsIri(/*char**/ pString, /*int*/ start, /*int*/ end, /*bool*/ hasUnicode, /*ref Flags*/ flags, /*ref string?*/ newHost, /*ref ParsingError*/ err)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555755522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                flags.$v |= 12884901888n;
                if (hasUnicode)
                {
                    /*ReadOnlySpan<char>*/ let host = new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(start), ((end - start) | 0));
                    /*string?*/ let stripped;
                    if ($.$spu.System.UriHelper.StripBidiControlCharacters$1(host, $.$ref(() => stripped, ($v) => stripped = $v, $.$$.System.String)))
                    {
                        host = $.$$.System.String.op_Implicit(stripped);
                    }
                    try
                    {
                        newHost.$v = $.$spu.System.UriHelper.NormalizeAndConcat(newHost.$v, host);
                    }
                    catch($e)
                    {
                        err.$v = 8/*ParsingError.BadHostName*/;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124555755522)
            
            //--TRIMMABLE-BOUNDARY-START(107375886338)
            /*char*/ static c_DummyChar = /*\uFFFF*/ 65535;
            //--TRIMMABLE-BOUNDARY-END(107375886338)
            
            //--TRIMMABLE-BOUNDARY-START(111670853634)
            /*char*/ static c_EOL = /*\uFFFE*/ 65534;
            //--TRIMMABLE-BOUNDARY-END(111670853634)
            
            //--TRIMMABLE-BOUNDARY-START(1769474)
            static $_Check;
            static get Check()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_Check ??= $asm.$nstr("$spu.System.Uri.Check", ($self) => class Check extends $.$$.System.Enum
                {
                    static None = 0;
                    static EscapedCanonical = 1;
                    static DisplayCanonical = 2;
                    static DotSlashAttn = 4;
                    static DotSlashEscaped = 128;
                    static BackslashInPath = 16;
                    static ReservedFound = 32;
                    static NotIriCanonical = 64;
                    static FoundNonAscii = 8;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(1769474);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "EscapedCanonical": 1n,
                            "DisplayCanonical": 2n,
                            "DotSlashAttn": 4n,
                            "DotSlashEscaped": 128n,
                            "BackslashInPath": 16n,
                            "ReservedFound": 32n,
                            "NotIriCanonical": 64n,
                            "FoundNonAscii": 8n
                        };
                    }
                    static $h = 1769474;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361507842),
    {
      "t": 1769474,
      "n": "None",
      "d": 1769474,
      "h": 34361507842,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361507842),
//--TRIMMABLE-BOUNDARY-START(25771573250),
    {
      "t": 1769474,
      "n": "EscapedCanonical",
      "d": 1769474,
      "h": 25771573250,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771573250),
//--TRIMMABLE-BOUNDARY-START(12886671362),
    {
      "t": 1769474,
      "n": "DisplayCanonical",
      "d": 1769474,
      "h": 12886671362,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886671362),
//--TRIMMABLE-BOUNDARY-START(17181638658),
    {
      "t": 1769474,
      "n": "DotSlashAttn",
      "d": 1769474,
      "h": 17181638658,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181638658),
//--TRIMMABLE-BOUNDARY-START(21476605954),
    {
      "t": 1769474,
      "n": "DotSlashEscaped",
      "d": 1769474,
      "h": 21476605954,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476605954),
//--TRIMMABLE-BOUNDARY-START(8591704066),
    {
      "t": 1769474,
      "n": "BackslashInPath",
      "d": 1769474,
      "h": 8591704066,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591704066),
//--TRIMMABLE-BOUNDARY-START(42951442434),
    {
      "t": 1769474,
      "n": "ReservedFound",
      "d": 1769474,
      "h": 42951442434,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951442434),
//--TRIMMABLE-BOUNDARY-START(38656475138),
    {
      "t": 1769474,
      "n": "NotIriCanonical",
      "d": 1769474,
      "h": 38656475138,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656475138),
//--TRIMMABLE-BOUNDARY-START(30066540546),
    {
      "t": 1769474,
      "n": "FoundNonAscii",
      "d": 1769474,
      "h": 30066540546,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066540546)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296736770),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1769474,
      "h": 4296736770,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296736770)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "d": 1703938,
  "h": 1769474,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Uri.Check`; }
                }, $cls, ($v) => $cls.$_Check = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1769474)
            
            //--TRIMMABLE-BOUNDARY-START(128850722818)
            /*Check */ CheckCanonical(/*char**/ str, /*ref int*/ idx, /*int*/ end, /*char*/ delim)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850722818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Check*/ let res = 0/*Check.None*/;
                /*bool*/ let needsEscaping = false;
                /*bool*/ let foundEscaping = false;
                /*bool*/ let iriParsing = this.IriParsing;
                /*char*/ let c;
                /*int*/ let i = idx.$v;
                for(; i < end; ++i)
                {
                    c = str.GetAt(i);
                    if (c <= /*\u001F*/ 31 || (c >= /*\u007F*/ 127 && c <= /*\u009F*/ 159))
                    {
                        needsEscaping = true;
                        foundEscaping = true;
                        res |= 32/*Check.ReservedFound*/;
                    }
                    else if (c > /*~*/ 126)
                    {
                        if (iriParsing)
                        {
                            /*bool*/ let valid = false;
                            res |= 8/*Check.FoundNonAscii*/;
                            if ($.$$.System.Char.IsHighSurrogate(c))
                            {
                                if ((((i + 1) | 0)) < end)
                                {
                                    valid = $.$spu.System.IriHelper.CheckIriUnicodeRange$1(c, str.GetAt(((i + 1) | 0)), $.$discardRef(), true);
                                }
                            }
                            else 
                            {
                                valid = $.$spu.System.IriHelper.CheckIriUnicodeRange(c, true);
                            }
                            if (!valid)
                            {
                                res |= 64/*Check.NotIriCanonical*/;
                            }
                        }
                        if (!needsEscaping)
                        {
                            needsEscaping = true;
                        }
                    }
                    else if (c === delim)
                    {
                        break;
                    }
                    else if (delim === /*?*/ 63 && c === /*#*/ 35 && (this._syntax !== null && this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/)))
                    {
                        break;
                    }
                    else if (c === /*?*/ 63)
                    {
                        if (this.IsImplicitFile || (this._syntax !== null && !this._syntax.InFact(32/*UriSyntaxFlags.MayHaveQuery*/) && delim !== /*\uFFFE*/ 65534))
                        {
                            res |= 32/*Check.ReservedFound*/;
                            foundEscaping = true;
                            needsEscaping = true;
                        }
                    }
                    else if (c === /*#*/ 35)
                    {
                        needsEscaping = true;
                        if (this.IsImplicitFile || (this._syntax !== null && !this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/)))
                        {
                            res |= 32/*Check.ReservedFound*/;
                            foundEscaping = true;
                        }
                    }
                    else if (c === /*/*/ 47 || c === /*\\*/ 92)
                    {
                        if ((res & 16/*Check.BackslashInPath*/) === 0 && c === /*\\*/ 92)
                        {
                            res |= 16/*Check.BackslashInPath*/;
                        }
                        if ((res & 4/*Check.DotSlashAttn*/) === 0 && ((i + 1) | 0) !== end && (str.GetAt(((i + 1) | 0)) === /*/*/ 47 || str.GetAt(((i + 1) | 0)) === /*\\*/ 92))
                        {
                            res |= 4/*Check.DotSlashAttn*/;
                        }
                    }
                    else if (c === /*.*/ 46)
                    {
                        if ((res & 4/*Check.DotSlashAttn*/) === 0 && ((i + 1) | 0) === end || str.GetAt(((i + 1) | 0)) === /*.*/ 46 || str.GetAt(((i + 1) | 0)) === /*/*/ 47 || str.GetAt(((i + 1) | 0)) === /*\\*/ 92 || str.GetAt(((i + 1) | 0)) === /*?*/ 63 || str.GetAt(((i + 1) | 0)) === /*#*/ 35)
                        {
                            res |= 4/*Check.DotSlashAttn*/;
                        }
                    }
                    else if ((c <= /*\"*/ 34 && c !== /*!*/ 33) || (c >= /*[*/ 91 && c <= /*^*/ 94) || c === /*>*/ 62 || c === /*<*/ 60 || c === /*`*/ 96)
                    {
                        if (!needsEscaping)
                        {
                            needsEscaping = true;
                        }
                        if ((this._flags & 562949953421312n) !== 0n)
                        {
                            res |= 64/*Check.NotIriCanonical*/;
                        }
                    }
                    else if (c >= /*{*/ 123 && c <= /*}*/ 125)
                    {
                        needsEscaping = true;
                    }
                    else if (c === /*%*/ 37)
                    {
                        if (!foundEscaping)
                        {
                            foundEscaping = true;
                        }
                        if (((i + 2) | 0) < end && (c = $.$spu.System.UriHelper.DecodeHexChars(str.GetAt(((i + 1) | 0)), str.GetAt(((i + 2) | 0)))) !== /*\uFFFF*/ 65535)
                        {
                            if (c === /*.*/ 46 || c === /*/*/ 47 || c === /*\\*/ 92)
                            {
                                res |= 128/*Check.DotSlashEscaped*/;
                            }
                            i += 2;
                            continue;
                        }
                        if (!needsEscaping)
                        {
                            needsEscaping = true;
                        }
                    }
                }
                if (foundEscaping)
                {
                    if (!needsEscaping)
                    {
                        res |= 1/*Check.EscapedCanonical*/;
                    }
                }
                else 
                {
                    res |= 2/*Check.DisplayCanonical*/;
                    if (!needsEscaping)
                    {
                        res |= 1/*Check.EscapedCanonical*/;
                    }
                }
                idx.$v = i;
                return res;
            }
            //--TRIMMABLE-BOUNDARY-END(128850722818)
            
            //--TRIMMABLE-BOUNDARY-START(584117256194)
            /*void */ GetCanonicalPath(/*ref ValueStringBuilder*/ dest, /*UriFormat*/ formatAs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584117256194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.InFact(16384n))
                {
                    dest.$v.Append$1(/*/*/ 47);
                }
                if (this._info.Offset.Path === this._info.Offset.Query)
                {
                    return;
                }
                /*int*/ let start = dest.$v.Length;
                /*int*/ let dosPathIdx = this.SecuredPathIndex;
                if (formatAs === 1/*UriFormat.UriEscaped*/)
                {
                    if (this.InFact(8192n))
                    {
                        dest.$v.Append$2($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Path, ((this._info.Offset.Query - this._info.Offset.Path) | 0)));
                        if (this._syntax.InFact(33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/) && this.InFact(16n) && !this.IsImplicitFile)
                        {
                            /*fixed*/ 
                            {
                                /*char**/ let pdest = dest.$v.GetPinnableReference();
                                /*int*/ let end = dest.$v.Length;
                                $.$spu.System.Uri.UnescapeOnly(pdest, start, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32), /*.*/ 46, /*/*/ 47, this._syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/) ? /*\\*/ 92 : /*\uFFFF*/ 65535);
                                dest.$v.Length = end;
                            }
                        }
                    }
                    else 
                    {
                        if (this.InFact(1024n) && this.NotAny(34359738368n))
                        {
                            /*ReadOnlySpan<char>*/ let str = $.$$.System.String.op_Implicit(this._string);
                            if (dosPathIdx !== 0 && str.get_Item(((((dosPathIdx + this._info.Offset.Path) | 0) - 1) | 0)).$v === /*|*/ 124)
                            {
                                /*char[]*/ let chars = str.ToArray();
                                $.$$.System.Array.$WriteT1.call(chars, /*:*/ 58, ((((dosPathIdx + this._info.Offset.Path) | 0) - 1) | 0));
                                str = $.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1(chars);
                            }
                            $.$spu.System.UriHelper.EscapeString$1(str.Slice(this._info.Offset.Path, ((this._info.Offset.Query - this._info.Offset.Path) | 0)), dest, !this.IsImplicitFile, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
                        }
                        else 
                        {
                            dest.$v.Append$2($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Path, ((this._info.Offset.Query - this._info.Offset.Path) | 0)));
                        }
                    }
                    if (!$.$$.System.OperatingSystem.IsWindows() && this.InFact(32768n) && this._syntax.NotAny(4194304/*UriSyntaxFlags.ConvertPathSlashes*/) && this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/) && !this.IsImplicitFile)
                    {
                        /*var*/ let copy = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                        copy.Append$2(dest.$v.AsSpan$2(start, ((dest.$v.Length - start) | 0)));
                        dest.$v.Length = start;
                        $.$spu.System.UriHelper.EscapeString$1(copy.AsSpan(), dest, true, $.$spu.System.UriHelper.UnreservedReserved);
                        start = dest.$v.Length;
                        copy.Dispose();
                    }
                }
                else 
                {
                    dest.$v.Append$2($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Path, ((this._info.Offset.Query - this._info.Offset.Path) | 0)));
                    if (this.InFact(8192n))
                    {
                        if (this._syntax.InFact(33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/) && this.InFact(16n) && !this.IsImplicitFile)
                        {
                            /*fixed*/ 
                            {
                                /*char**/ let pdest = dest.$v.GetPinnableReference();
                                /*int*/ let end = dest.$v.Length;
                                $.$spu.System.Uri.UnescapeOnly(pdest, start, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32), /*.*/ 46, /*/*/ 47, this._syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/) ? /*\\*/ 92 : /*\uFFFF*/ 65535);
                                dest.$v.Length = end;
                            }
                        }
                    }
                }
                /*int*/ let offset = ((start + dosPathIdx) | 0);
                if (dosPathIdx !== 0 && dest.$v.get_Item$1(((offset - 1) | 0)).$v === /*|*/ 124)
                {
                    dest.$v.get_Item$1(((offset - 1) | 0)).$v = /*:*/ 58;
                }
                if (this.InFact(8192n) && ((dest.$v.Length - offset) | 0) > 0)
                {
                    dest.$v.Length = ((offset + $.$spu.System.UriHelper.Compress(dest.$v.RawChars.Slice(offset, ((dest.$v.Length - offset) | 0)), this._syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/), this._syntax.InFact(16777216/*UriSyntaxFlags.CanonicalizeAsFilePath*/))) | 0);
                    if (dest.$v.get_Item$1(start).$v === /*\\*/ 92)
                    {
                        dest.$v.get_Item$1(start).$v = /*/*/ 47;
                    }
                    if (formatAs === 1/*UriFormat.UriEscaped*/ && this.NotAny(34359738368n) && this.InFact(1024n))
                    {
                        /*var*/ let copy = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                        copy.Append$2(dest.$v.AsSpan$2(start, ((dest.$v.Length - start) | 0)));
                        dest.$v.Length = start;
                        $.$spu.System.UriHelper.EscapeString$1(copy.AsSpan(), dest, !this.IsImplicitFile, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
                        start = dest.$v.Length;
                        copy.Dispose();
                    }
                }
                if (formatAs !== 1/*UriFormat.UriEscaped*/ && this.InFact(16n))
                {
                    /*UnescapeMode*/ let mode;
                    switch(formatAs)
                    {
                        case 32767/*V1ToStringUnescape*/:
                        mode = (this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/) | 4/*UnescapeMode.V1ToStringFlag*/;
                        if (this.IsImplicitFile)
                        {
                            mode &= ~2/*UnescapeMode.Unescape*/;
                        }
                        break;
                        case 2/*UriFormat.Unescaped*/:
                        mode = this.IsImplicitFile ? 0/*UnescapeMode.CopyOnly*/ : 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/;
                        break;
                        default:
                        mode = this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/;
                        if (this.IsImplicitFile)
                        {
                            mode &= ~2/*UnescapeMode.Unescape*/;
                        }
                        break;
                    }
                    if (mode !== 0/*UnescapeMode.CopyOnly*/)
                    {
                        /*var*/ let copy = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                        copy.Append$2(dest.$v.AsSpan$2(start, ((dest.$v.Length - start) | 0)));
                        dest.$v.Length = start;
                        /*fixed*/ 
                        {
                            /*char**/ let pCopy = copy.GetPinnableReference();
                            $.$spu.System.UriHelper.UnescapeString$1(pCopy, 0, copy.Length, dest, /*?*/ 63, /*#*/ 35, /*\uFFFF*/ 65535, mode, this._syntax, false);
                        }
                        copy.Dispose();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(584117256194)
            
            //--TRIMMABLE-BOUNDARY-START(1017908953090)
            static /*void */ UnescapeOnly(/*char**/ pch, /*int*/ start, /*ref int*/ end, /*char*/ ch1, /*char*/ ch2, /*char*/ ch3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1017908953090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*char**/ let pend;
                /*char**/ let pnew;
                /*char*/ let ch;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            if (((end.$v - start) | 0) < 3)
                            {
                                return;
                            }
                            pend = pch.Add(end.$v).Add(-2);
                            pch = pch.Add(start);
                            pnew = null;
                        }
                        case 1: /*over*/
                        if ($.$$.NetJs.RefOrPointer.Compare(pch, pend) >= 0)
                        {
                            $gotoJumpState1 = 3; /*goto done*/
                            continue $gotoJumpStart1;
                        }
                        if ((() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v !== /*%*/ 37)
                        {
                            $gotoJumpState1 = 1; /*goto over*/
                            continue $gotoJumpStart1;
                        }
                        ch = $.$spu.System.UriHelper.DecodeHexChars((() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v, (() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v);
                        if (!(ch === ch1 || ch === ch2 || ch === ch3))
                        {
                            $gotoJumpState1 = 1; /*goto over*/
                            continue $gotoJumpStart1;
                        }
                        pnew = pch.Add(-2);
                        (pnew.Add(-1)).$v = ch;
                        case 2: /*over_new*/
                        if ($.$$.NetJs.RefOrPointer.Compare(pch, pend) >= 0)
                        {
                            $gotoJumpState1 = 3; /*goto done*/
                            continue $gotoJumpStart1;
                        }
                        if (((() =>
                        {
                            var $old = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $old;
                        })().$v = (() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v) !== /*%*/ 37)
                        {
                            $gotoJumpState1 = 2; /*goto over_new*/
                            continue $gotoJumpStart1;
                        }
                        ch = $.$spu.System.UriHelper.DecodeHexChars(((() =>
                        {
                            var $old = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $old;
                        })().$v = (() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v), ((() =>
                        {
                            var $old = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $old;
                        })().$v = (() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v));
                        if (!(ch === ch1 || ch === ch2 || ch === ch3))
                        {
                            $gotoJumpState1 = 2; /*goto over_new*/
                            continue $gotoJumpStart1;
                        }
                        pnew = pnew.Add(-2);
                        (pnew.Add(-1)).$v = ch;
                        $gotoJumpState1 = 2; /*goto over_new*/
                        continue $gotoJumpStart1;
                        case 3: /*done*/
                        pend = pend.Add(2);
                        if (pnew === null)
                        {
                            return;
                        }
                        if ($.$$.NetJs.RefOrPointer.Compare(pch, pend) == 0)
                        {
                            end.$v -= $.$cast((pch.Subtract(pnew)), $.$$.System.Int32);
                            return;
                        }
                        (() =>
                        {
                            var $old = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $old;
                        })().$v = (() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v;
                        if ($.$$.NetJs.RefOrPointer.Compare(pch, pend) == 0)
                        {
                            end.$v -= $.$cast((pch.Subtract(pnew)), $.$$.System.Int32);
                            return;
                        }
                        (() =>
                        {
                            var $old = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $old;
                        })().$v = (() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v;
                        end.$v -= $.$cast((pch.Subtract(pnew)), $.$$.System.Int32);
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(1017908953090)
            
            //--TRIMMABLE-BOUNDARY-START(167505428482)
            static /*void */ Compress(/*char[]*/ dest, /*int*/ start, /*ref int*/ destLength, /*UriParser*/ syntax)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505428482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                destLength.$v = ((start + $.$spu.System.UriHelper.Compress($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, dest, start, ((destLength.$v - start) | 0)), syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/), syntax.InFact(16777216/*UriSyntaxFlags.CanonicalizeAsFilePath*/))) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(167505428482)
            
            //--TRIMMABLE-BOUNDARY-START(158915493890)
            static /*string */ CombineUri(/*Uri*/ basePart, /*string*/ relativePart, /*UriFormat*/ uriFormat)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915493890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*char*/ let c1 = $.$$.System.String.get_Chars.call(relativePart, 0);
                if (basePart.IsDosPath && (c1 === /*/*/ 47 || c1 === /*\\*/ 92) && (relativePart.length === 1 || ($.$$.System.String.get_Chars.call(relativePart, 1) !== /*/*/ 47 && $.$$.System.String.get_Chars.call(relativePart, 1) !== /*\\*/ 92)))
                {
                    /*int*/ let idx = $.$$.System.String.IndexOf$3.call(basePart.OriginalString, /*:*/ 58);
                    if (basePart.IsImplicitFile)
                    {
                        return $.$$.System.String.Concat$8($.$$.System.MemoryExtensions.AsSpan$1(basePart.OriginalString, 0, ((idx + 1) | 0)), $.$$.System.String.op_Implicit(relativePart));
                    }
                    idx = $.$$.System.String.IndexOf$1.call(basePart.OriginalString, /*:*/ 58, ((idx + 1) | 0));
                    return $.$$.System.String.Concat$8($.$$.System.MemoryExtensions.AsSpan$1(basePart.OriginalString, 0, ((idx + 1) | 0)), $.$$.System.String.op_Implicit(relativePart));
                }
                if ($.$spu.System.Uri.StaticIsFile(basePart.Syntax))
                {
                    if (c1 === /*\\*/ 92 || c1 === /*/*/ 47)
                    {
                        if (relativePart.length >= 2 && ($.$$.System.String.get_Chars.call(relativePart, 1) === /*\\*/ 92 || $.$$.System.String.get_Chars.call(relativePart, 1) === /*/*/ 47))
                        {
                            return basePart.IsImplicitFile ? relativePart : "file:" + relativePart;
                        }
                        if (basePart.IsUnc)
                        {
                            /*ReadOnlySpan<char>*/ let share = $.$$.System.String.op_Implicit(basePart.GetParts(16/*UriComponents.Path*/ | 1073741824/*UriComponents.KeepDelimiter*/, 2/*UriFormat.Unescaped*/));
                            /*int*/ let i = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, share.Slice$1(1), /*/*/ 47);
                            if (i >= 0)
                            {
                                share = share.Slice(0, ((i + 1) | 0));
                            }
                            if (basePart.IsImplicitFile)
                            {
                                return $.$$.System.String.Concat$6($.$$.System.String.op_Implicit("\\\\"), $.$$.System.String.op_Implicit(basePart.GetParts(4/*UriComponents.Host*/, 2/*UriFormat.Unescaped*/)), share, $.$$.System.String.op_Implicit(relativePart));
                            }
                            return $.$$.System.String.Concat$6($.$$.System.String.op_Implicit("file://"), $.$$.System.String.op_Implicit(basePart.GetParts(4/*UriComponents.Host*/, uriFormat)), share, $.$$.System.String.op_Implicit(relativePart));
                        }
                        return "file://" + relativePart;
                    }
                }
                /*bool*/ let convBackSlashes = basePart.Syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/);
                /*string?*/ let left;
                if (c1 === /*/*/ 47 || (c1 === /*\\*/ 92 && convBackSlashes))
                {
                    if (relativePart.length >= 2 && $.$$.System.String.get_Chars.call(relativePart, 1) === /*/*/ 47)
                    {
                        return basePart.Scheme + /*:*/ 58 + relativePart;
                    }
                    if (basePart.HostType === 4294967296n)
                    {
                        left = `${basePart.GetParts(1/*UriComponents.Scheme*/ | 2/*UriComponents.UserInfo*/, uriFormat)}[${basePart.DnsSafeHost}]${basePart.GetParts(1073741824/*UriComponents.KeepDelimiter*/ | 8/*UriComponents.Port*/, uriFormat)}`;
                    }
                    else 
                    {
                        left = basePart.GetParts(13/*UriComponents.SchemeAndServer*/ | 2/*UriComponents.UserInfo*/, uriFormat);
                    }
                    return convBackSlashes && c1 === /*\\*/ 92 ? $.$$.System.String.Concat$7($.$$.System.String.op_Implicit(left), $.$$.System.String.op_Implicit("/"), $.$$.System.MemoryExtensions.AsSpan$2(relativePart, 1)) : left + relativePart;
                }
                left = basePart.GetParts(16/*UriComponents.Path*/ | 1073741824/*UriComponents.KeepDelimiter*/, basePart.IsImplicitFile ? 2/*UriFormat.Unescaped*/ : uriFormat);
                /*int*/ let length = left.length;
                /*char[]*/ let path = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [((length + relativePart.length) | 0)], null);
                if (length > 0)
                {
                    $.$$.System.String.CopyTo.call(left, 0, path, 0, length);
                    while(length > 0)
                    {
                        if ($.$$.System.Array.$ReadT1.call(path, --length) === /*/*/ 47)
                        {
                            ++length;
                            break;
                        }
                    }
                }
                $.$$.System.String.CopyTo.call(relativePart, 0, path, length, relativePart.length);
                c1 = basePart.Syntax.InFact(32/*UriSyntaxFlags.MayHaveQuery*/) ? /*?*/ 63 : /*\uFFFF*/ 65535;
                /*char*/ let c2 = (!basePart.IsImplicitFile && basePart.Syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/)) ? /*#*/ 35 : /*\uFFFF*/ 65535;
                /*ReadOnlySpan<char>*/ let extra = $.$$.System.String.op_Implicit($.$$.System.String.Empty);
                if (!(c1 === /*\uFFFF*/ 65535 && c2 === /*\uFFFF*/ 65535))
                {
                    /*int*/ let i = 0;
                    for(; i < relativePart.length; ++i)
                    {
                        if ($.$$.System.Array.$ReadT1.call(path, ((length + i) | 0)) === c1 || $.$$.System.Array.$ReadT1.call(path, ((length + i) | 0)) === c2)
                        {
                            break;
                        }
                    }
                    if (i === 0)
                    {
                        extra = $.$$.System.String.op_Implicit(relativePart);
                    }
                    else if (i < relativePart.length)
                    {
                        extra = $.$$.System.MemoryExtensions.AsSpan$2(relativePart, i);
                    }
                    length += i;
                }
                else 
                {
                    length += relativePart.length;
                }
                if (basePart.HostType === 4294967296n)
                {
                    if (basePart.IsImplicitFile)
                    {
                        left = "\\\\[" + basePart.DnsSafeHost + /*]*/ 93;
                    }
                    else 
                    {
                        left = basePart.GetParts(1/*UriComponents.Scheme*/ | 2/*UriComponents.UserInfo*/, uriFormat) + /*[*/ 91 + basePart.DnsSafeHost + /*]*/ 93 + basePart.GetParts(1073741824/*UriComponents.KeepDelimiter*/ | 8/*UriComponents.Port*/, uriFormat);
                    }
                }
                else 
                {
                    if (basePart.IsImplicitFile)
                    {
                        if (basePart.IsDosPath)
                        {
                            $.$spu.System.Uri.Compress(path, 3, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32), basePart.Syntax);
                            return $.$$.System.String.Concat$8($.$$.System.Span$$($.$$.System.Char).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, path, 1, ((length - 1) | 0))), extra);
                        }
                        else if (!$.$$.System.OperatingSystem.IsWindows() && basePart.IsUnixPath)
                        {
                            left = basePart.GetParts(4/*UriComponents.Host*/, 2/*UriFormat.Unescaped*/);
                        }
                        else 
                        {
                            left = "\\\\" + basePart.GetParts(4/*UriComponents.Host*/, 2/*UriFormat.Unescaped*/);
                        }
                    }
                    else 
                    {
                        left = basePart.GetParts(13/*UriComponents.SchemeAndServer*/ | 2/*UriComponents.UserInfo*/, uriFormat);
                    }
                }
                $.$spu.System.Uri.Compress(path, basePart.SecuredPathIndex, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32), basePart.Syntax);
                return $.$$.System.String.Concat$7($.$$.System.String.op_Implicit(left), $.$$.System.Span$$($.$$.System.Char).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, path, 0, length)), extra);
            }
            //--TRIMMABLE-BOUNDARY-END(158915493890)
            
            //--TRIMMABLE-BOUNDARY-START(858995163138)
            static /*string */ PathDifference(/*string*/ path1, /*string*/ path2, /*bool*/ compareCase)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(858995163138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let i;
                /*int*/ let si = -1;
                for(i = 0; (i < path1.length) && (i < path2.length); ++i)
                {
                    if (($.$$.System.String.get_Chars.call(path1, i) !== $.$$.System.String.get_Chars.call(path2, i)) && (compareCase || ($.$$.System.Char.ToLowerInvariant($.$$.System.String.get_Chars.call(path1, i)) !== $.$$.System.Char.ToLowerInvariant($.$$.System.String.get_Chars.call(path2, i)))))
                    {
                        break;
                    }
                    else if ($.$$.System.String.get_Chars.call(path1, i) === /*/*/ 47)
                    {
                        si = i;
                    }
                }
                if (i === 0)
                {
                    return path2;
                }
                if ((i === path1.length) && (i === path2.length))
                {
                    return $.$$.System.String.Empty;
                }
                /*StringBuilder*/ let relPath = new $.$$.System.Text.StringBuilder().$ctor$1();
                for(; i < path1.length; ++i)
                {
                    if ($.$$.System.String.get_Chars.call(path1, i) === /*/*/ 47)
                    {
                        relPath.Append$19("../");
                    }
                }
                if (relPath.Length === 0 && ((path2.length - 1) | 0) === si)
                {
                    return "./";
                }
                return $.$$.System.Text.StringBuilder.ToString.call(relPath.Append$15($.$$.System.MemoryExtensions.AsSpan$2(path2, ((si + 1) | 0))));
            }
            //--TRIMMABLE-BOUNDARY-END(858995163138)
            
            //--TRIMMABLE-BOUNDARY-START(807455555586)
            /*string */ MakeRelative(/*Uri*/ toUri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(807455555586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(toUri, "toUri");
                if (this.IsNotAbsoluteUri || toUri.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (($.$$.System.String.op_Equality(this.Scheme, toUri.Scheme)) && ($.$$.System.String.op_Equality(this.Host, toUri.Host)) && (this.Port === toUri.Port))
                {
                    return $.$spu.System.Uri.PathDifference(this.AbsolutePath, toUri.AbsolutePath, !this.IsUncOrDosPath);
                }
                return $.$spu.System.Uri.ToString.call(toUri);
            }
            //--TRIMMABLE-BOUNDARY-END(807455555586)
            
            //--TRIMMABLE-BOUNDARY-START(115965820930)
            /*void */ Canonicalize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965820930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(115965820930)
            
            //--TRIMMABLE-BOUNDARY-START(833225359362)
            /*void */ Parse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(833225359362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(833225359362)
            
            //--TRIMMABLE-BOUNDARY-START(240519872514)
            /*void */ Escape()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519872514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(240519872514)
            
            //--TRIMMABLE-BOUNDARY-START(1000729083906)
            /*string */ Unescape(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1000729083906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*char[]*/ let dest = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [path.length], null);
                /*int*/ let count = 0;
                dest = $.$spu.System.UriHelper.UnescapeString$3(path, 0, path.length, dest, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, null, false);
                return $.$$.System.String.Create$1(dest, 0, count);
            }
            //--TRIMMABLE-BOUNDARY-END(1000729083906)
            
            //--TRIMMABLE-BOUNDARY-START(253404774402)
            static /*string */ EscapeString(/*string?*/ str)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(253404774402);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return str === null ? $.$$.System.String.Empty : $.$spu.System.UriHelper.EscapeString$2(str, true, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253404774402)
            
            //--TRIMMABLE-BOUNDARY-START(154620526594)
            /*void */ CheckSecurity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620526594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(154620526594)
            
            //--TRIMMABLE-BOUNDARY-START(773095817218)
            /*bool */ IsReservedCharacter(/*char*/ character)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(773095817218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (character === /*;*/ 59) || (character === /*/*/ 47) || (character === /*:*/ 58) || (character === /*@*/ 64) || (character === /*&*/ 38) || (character === /*=*/ 61) || (character === /*+*/ 43) || (character === /*$*/ 36) || (character === /*,*/ 44);
            }
            //--TRIMMABLE-BOUNDARY-END(773095817218)
            
            //--TRIMMABLE-BOUNDARY-START(743031046146)
            static /*bool */ IsExcludedCharacter(/*char*/ character)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(743031046146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (character <= 32) || (character >= 127) || (character === /*<*/ 60) || (character === /*>*/ 62) || (character === /*#*/ 35) || (character === /*%*/ 37) || (character === /*\"*/ 34) || (character === /*{*/ 123) || (character === /*}*/ 125) || (character === /*|*/ 124) || (character === /*\\*/ 92) || (character === /*^*/ 94) || (character === /*[*/ 91) || (character === /*]*/ 93) || (character === /*`*/ 96);
            }
            //--TRIMMABLE-BOUNDARY-END(743031046146)
            
            //--TRIMMABLE-BOUNDARY-START(721556209666)
            /*bool */ IsBadFileSystemCharacter(/*char*/ character)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(721556209666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (character < 32) || (character === /*;*/ 59) || (character === /*/*/ 47) || (character === /*?*/ 63) || (character === /*:*/ 58) || (character === /*&*/ 38) || (character === /*=*/ 61) || (character === /*,*/ 44) || (character === /***/ 42) || (character === /*<*/ 60) || (character === /*>*/ 62) || (character === /*\"*/ 34) || (character === /*|*/ 124) || (character === /*\\*/ 92) || (character === /*^*/ 94);
            }
            //--TRIMMABLE-BOUNDARY-END(721556209666)
            
            //--TRIMMABLE-BOUNDARY-START(652836732930)
            /*bool */ get HasAuthority()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714185730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InFact(68719476736n);
            }
            //--TRIMMABLE-BOUNDARY-END(652836732930)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<System.Uri>.Equals(System.Uri?)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12886605826)
                this._originalUnicodeString = null;
                //--TRIMMABLE-BOUNDARY-END(12886605826)
                
                //--TRIMMABLE-BOUNDARY-START(21476540418)
                this._syntax = null;
                //--TRIMMABLE-BOUNDARY-END(21476540418)
                
                //--TRIMMABLE-BOUNDARY-START(8591638530)
                this._info = null;
                //--TRIMMABLE-BOUNDARY-END(8591638530)
                
            }
            //--TRIMMABLE-BOUNDARY-START(47246344194)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(893354901506)
                    this.s_asciiOtherThanPercent = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\u0008\t\n\u000B\u000C\r\u000E\u000F" + "\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001A\u001B\u001C\u001D\u001E\u001F" + " !\"#$" + "&'()*+,-./" + "0123456789:;<=>?" + "@ABCDEFGHIJKLMNO" + "PQRSTUVWXYZ[\\]^_" + "`abcdefghijklmno" + "pqrstuvwxyz{|}~\u007F"));
                    //--TRIMMABLE-BOUNDARY-END(893354901506)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1022203920386)
                    this.UriSchemeFile = $.$spu.System.UriParser.FileUri.SchemeName;
                    //--TRIMMABLE-BOUNDARY-END(1022203920386)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1026498887682)
                    this.UriSchemeFtp = $.$spu.System.UriParser.FtpUri.SchemeName;
                    //--TRIMMABLE-BOUNDARY-END(1026498887682)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1069448560642)
                    this.UriSchemeSftp = "sftp";
                    //--TRIMMABLE-BOUNDARY-END(1069448560642)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1030793854978)
                    this.UriSchemeFtps = "ftps";
                    //--TRIMMABLE-BOUNDARY-END(1030793854978)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1035088822274)
                    this.UriSchemeGopher = $.$spu.System.UriParser.GopherUri.SchemeName;
                    //--TRIMMABLE-BOUNDARY-END(1035088822274)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1039383789570)
                    this.UriSchemeHttp = $.$spu.System.UriParser.HttpUri.SchemeName;
                    //--TRIMMABLE-BOUNDARY-END(1039383789570)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1043678756866)
                    this.UriSchemeHttps = $.$spu.System.UriParser.HttpsUri.SchemeName;
                    //--TRIMMABLE-BOUNDARY-END(1043678756866)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1082333462530)
                    this.UriSchemeWs = $.$spu.System.UriParser.WsUri.SchemeName;
                    //--TRIMMABLE-BOUNDARY-END(1082333462530)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1086628429826)
                    this.UriSchemeWss = $.$spu.System.UriParser.WssUri.SchemeName;
                    //--TRIMMABLE-BOUNDARY-END(1086628429826)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1047973724162)
                    this.UriSchemeMailto = $.$spu.System.UriParser.MailToUri.SchemeName;
                    //--TRIMMABLE-BOUNDARY-END(1047973724162)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1060858626050)
                    this.UriSchemeNews = $.$spu.System.UriParser.NewsUri.SchemeName;
                    //--TRIMMABLE-BOUNDARY-END(1060858626050)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1065153593346)
                    this.UriSchemeNntp = $.$spu.System.UriParser.NntpUri.SchemeName;
                    //--TRIMMABLE-BOUNDARY-END(1065153593346)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1073743527938)
                    this.UriSchemeSsh = "ssh";
                    //--TRIMMABLE-BOUNDARY-END(1073743527938)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1078038495234)
                    this.UriSchemeTelnet = $.$spu.System.UriParser.TelnetUri.SchemeName;
                    //--TRIMMABLE-BOUNDARY-END(1078038495234)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1056563658754)
                    this.UriSchemeNetTcp = $.$spu.System.UriParser.NetTcpUri.SchemeName;
                    //--TRIMMABLE-BOUNDARY-END(1056563658754)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(1052268691458)
                    this.UriSchemeNetPipe = $.$spu.System.UriParser.NetPipeUri.SchemeName;
                    //--TRIMMABLE-BOUNDARY-END(1052268691458)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(910534770690)
                    this.SchemeDelimiter = "://";
                    //--TRIMMABLE-BOUNDARY-END(910534770690)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(897649868802)
                    this.s_schemeChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("+-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"));
                    //--TRIMMABLE-BOUNDARY-END(897649868802)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(901944836098)
                    this.s_segmentSeparatorChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit(":\\/?#"));
                    //--TRIMMABLE-BOUNDARY-END(901944836098)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246344194)
            
            static $h = 1703938;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(760210915330),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 416613531650,
        "f": 50331650
      },
      "n": "IsImplicitFile",
      "d": 1703938,
      "h": 760210915330,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(760210915330),
//--TRIMMABLE-BOUNDARY-START(781685751810),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 450973270018,
        "f": 50331650
      },
      "n": "IsUncOrDosPath",
      "d": 1703938,
      "h": 781685751810,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(781685751810),
//--TRIMMABLE-BOUNDARY-START(738736078850),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 399433662466,
        "f": 50331650
      },
      "n": "IsDosPath",
      "d": 1703938,
      "h": 738736078850,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(738736078850),
//--TRIMMABLE-BOUNDARY-START(785980719106),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 459563204610,
        "f": 50331650
      },
      "n": "IsUncPath",
      "d": 1703938,
      "h": 785980719106,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(785980719106),
//--TRIMMABLE-BOUNDARY-START(790275686402),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 468153139202,
        "f": 50331650
      },
      "n": "IsUnixPath",
      "d": 1703938,
      "h": 790275686402,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(790275686402),
//--TRIMMABLE-BOUNDARY-START(674311569410),
    {
      "p": 1835010,
      "g": {
        "r": 0,
        "d": 0,
        "h": 356483989506,
        "f": 50331650
      },
      "n": "HostType",
      "d": 1703938,
      "h": 674311569410,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(674311569410),
//--TRIMMABLE-BOUNDARY-START(944894509058),
    {
      "p": 2621442,
      "g": {
        "r": 0,
        "d": 0,
        "h": 554052485122,
        "f": 50331650
      },
      "n": "Syntax",
      "d": 1703938,
      "h": 944894509058,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(944894509058),
//--TRIMMABLE-BOUNDARY-START(768800849922),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 433793400834,
        "f": 50331650
      },
      "n": "IsNotAbsoluteUri",
      "d": 1703938,
      "h": 768800849922,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(768800849922),
//--TRIMMABLE-BOUNDARY-START(708671307778),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 373663858690,
        "f": 50331650
      },
      "n": "IriParsing",
      "d": 1703938,
      "h": 708671307778,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(708671307778),
//--TRIMMABLE-BOUNDARY-START(210455101442),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304944381954,
        "f": 50331656
      },
      "n": "DisablePathAndQueryCanonicalization",
      "d": 1703938,
      "h": 210455101442,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(210455101442),
//--TRIMMABLE-BOUNDARY-START(1090923397122),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 562642419714,
        "f": 50331656
      },
      "n": "UserDrivenParsing",
      "d": 1703938,
      "h": 1090923397122,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(1090923397122),
//--TRIMMABLE-BOUNDARY-START(919124705282),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 536872615938,
        "f": 50331650
      },
      "n": "SecuredPathIndex",
      "d": 1703938,
      "h": 919124705282,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(919124705282),
//--TRIMMABLE-BOUNDARY-START(90196017154),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279174578178,
        "f": 50331649
      },
      "n": "AbsolutePath",
      "d": 1703938,
      "h": 90196017154,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196017154),
//--TRIMMABLE-BOUNDARY-START(867585097730),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 511102812162,
        "f": 50331650
      },
      "n": "PrivateAbsolutePath",
      "d": 1703938,
      "h": 867585097730,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(867585097730),
//--TRIMMABLE-BOUNDARY-START(94490984450),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287764512770,
        "f": 50331649
      },
      "n": "AbsoluteUri",
      "d": 1703938,
      "h": 94490984450,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490984450),
//--TRIMMABLE-BOUNDARY-START(803160588290),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 476743073794,
        "f": 50331649
      },
      "n": "LocalPath",
      "d": 1703938,
      "h": 803160588290,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(803160588290),
//--TRIMMABLE-BOUNDARY-START(103080919042),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296354447362,
        "f": 50331649
      },
      "n": "Authority",
      "d": 1703938,
      "h": 103080919042,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080919042),
//--TRIMMABLE-BOUNDARY-START(670016602114),
    {
      "p": 2490370,
      "g": {
        "r": 0,
        "d": 0,
        "h": 347894054914,
        "f": 50331649
      },
      "n": "HostNameType",
      "d": 1703938,
      "h": 670016602114,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(670016602114),
//--TRIMMABLE-BOUNDARY-START(734441111554),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 390843727874,
        "f": 50331649
      },
      "n": "IsDefaultPort",
      "d": 1703938,
      "h": 734441111554,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(734441111554),
//--TRIMMABLE-BOUNDARY-START(747326013442),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 408023597058,
        "f": 50331649
      },
      "n": "IsFile",
      "d": 1703938,
      "h": 747326013442,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(747326013442),
//--TRIMMABLE-BOUNDARY-START(764505882626),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 425203466242,
        "f": 50331649
      },
      "n": "IsLoopback",
      "d": 1703938,
      "h": 764505882626,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(764505882626),
//--TRIMMABLE-BOUNDARY-START(854700195842),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 493922942978,
        "f": 50331649
      },
      "n": "PathAndQuery",
      "d": 1703938,
      "h": 854700195842,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(854700195842),
//--TRIMMABLE-BOUNDARY-START(923419672578),
    {
      "p": $.$typeArray($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 545462550530,
        "f": 50331649
      },
      "n": "Segments",
      "d": 1703938,
      "h": 923419672578,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(923419672578),
//--TRIMMABLE-BOUNDARY-START(777390784514),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 442383335426,
        "f": 50331649
      },
      "n": "IsUnc",
      "d": 1703938,
      "h": 777390784514,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(777390784514),
//--TRIMMABLE-BOUNDARY-START(665721634818),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 339304120322,
        "f": 50331649
      },
      "n": "Host",
      "d": 1703938,
      "h": 665721634818,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(665721634818),
//--TRIMMABLE-BOUNDARY-START(863290130434),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 502512877570,
        "f": 50331649
      },
      "n": "Port",
      "d": 1703938,
      "h": 863290130434,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(863290130434),
//--TRIMMABLE-BOUNDARY-START(876175032322),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 519692746754,
        "f": 50331649
      },
      "n": "Query",
      "d": 1703938,
      "h": 876175032322,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(876175032322),
//--TRIMMABLE-BOUNDARY-START(266289676290),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 322124251138,
        "f": 50331649
      },
      "n": "Fragment",
      "d": 1703938,
      "h": 266289676290,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(266289676290),
//--TRIMMABLE-BOUNDARY-START(906239803394),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 528282681346,
        "f": 50331649
      },
      "n": "Scheme",
      "d": 1703938,
      "h": 906239803394,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(906239803394),
//--TRIMMABLE-BOUNDARY-START(828930392066),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 485333008386,
        "f": 50331649
      },
      "n": "OriginalString",
      "d": 1703938,
      "h": 828930392066,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(828930392066),
//--TRIMMABLE-BOUNDARY-START(214750068738),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313534316546,
        "f": 50331649
      },
      "n": "DnsSafeHost",
      "d": 1703938,
      "h": 214750068738,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214750068738),
//--TRIMMABLE-BOUNDARY-START(678606536706),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 365073924098,
        "f": 50331649
      },
      "n": "IdnHost",
      "d": 1703938,
      "h": 678606536706,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(678606536706),
//--TRIMMABLE-BOUNDARY-START(717261242370),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 382253793282,
        "f": 50331649
      },
      "n": "IsAbsoluteUri",
      "d": 1703938,
      "h": 717261242370,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(717261242370),
//--TRIMMABLE-BOUNDARY-START(1095218364418),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 571232354306,
        "f": 50331649
      },
      "n": "UserEscaped",
      "d": 1703938,
      "h": 1095218364418,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1095218364418),
//--TRIMMABLE-BOUNDARY-START(1099513331714),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 579822288898,
        "f": 50331649
      },
      "n": "UserInfo",
      "d": 1703938,
      "h": 1099513331714,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1099513331714),
//--TRIMMABLE-BOUNDARY-START(652836732930),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 330714185730,
        "f": 50331656
      },
      "n": "HasAuthority",
      "d": 1703938,
      "h": 652836732930,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(652836732930)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(184685297666),
    {
      "r": 65537,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "dontEscape",
          "p": 262145
        },
        {
          "n": "uriKind",
          "p": 2555906
        },
        {
          "n": "creationOptions",
          "p": 2228226,
          "f": 73
        }
      ],
      "n": "CreateThis",
      "d": 1703938,
      "h": 184685297666,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(184685297666),
//--TRIMMABLE-BOUNDARY-START(687196471298),
    {
      "r": 65537,
      "p": [
        {
          "n": "err",
          "p": 1310722
        },
        {
          "n": "uriKind",
          "p": 2555906
        },
        {
          "n": "e",
          "p": 2359298,
          "f": 2
        }
      ],
      "n": "InitializeUri",
      "d": 1703938,
      "h": 687196471298,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(687196471298),
//--TRIMMABLE-BOUNDARY-START(137440657410),
    {
      "r": 262145,
      "p": [
        {
          "n": "data",
          "p": 1310721
        }
      ],
      "n": "CheckForUnicodeOrEscapedUnreserved",
      "d": 1703938,
      "h": 137440657410,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(137440657410),
//--TRIMMABLE-BOUNDARY-START(966369345538),
    {
      "r": 262145,
      "p": [
        {
          "n": "uriString",
          "p": 1310721
        },
        {
          "n": "uriKind",
          "p": 2555906
        },
        {
          "n": "result",
          "p": 1703938,
          "f": 2
        }
      ],
      "n": "TryCreate",
      "d": 1703938,
      "h": 966369345538,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(966369345538),
//--TRIMMABLE-BOUNDARY-START(970664312834),
    {
      "r": 262145,
      "p": [
        {
          "n": "uriString",
          "p": 1310721
        },
        {
          "n": "creationOptions",
          "p": 2228226,
          "f": 8
        },
        {
          "n": "result",
          "p": 1703938,
          "f": 2
        }
      ],
      "n": "TryCreate",
      "o": "@$1",
      "d": 1703938,
      "h": 970664312834,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(970664312834),
//--TRIMMABLE-BOUNDARY-START(974959280130),
    {
      "r": 262145,
      "p": [
        {
          "n": "baseUri",
          "p": 1703938
        },
        {
          "n": "relativeUri",
          "p": 1310721
        },
        {
          "n": "result",
          "p": 1703938,
          "f": 2
        }
      ],
      "n": "TryCreate",
      "o": "@$2",
      "d": 1703938,
      "h": 974959280130,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(974959280130),
//--TRIMMABLE-BOUNDARY-START(979254247426),
    {
      "r": 262145,
      "p": [
        {
          "n": "baseUri",
          "p": 1703938
        },
        {
          "n": "relativeUri",
          "p": 1703938
        },
        {
          "n": "result",
          "p": 1703938,
          "f": 2
        }
      ],
      "n": "TryCreate",
      "o": "@$3",
      "d": 1703938,
      "h": 979254247426,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(979254247426),
//--TRIMMABLE-BOUNDARY-START(592707190786),
    {
      "r": 1310721,
      "p": [
        {
          "n": "components",
          "p": 2162690
        },
        {
          "n": "format",
          "p": 2293762
        }
      ],
      "n": "GetComponents",
      "d": 1703938,
      "h": 592707190786,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(592707190786),
//--TRIMMABLE-BOUNDARY-START(700081373186),
    {
      "r": 1310721,
      "p": [
        {
          "n": "components",
          "p": 2162690
        },
        {
          "n": "format",
          "p": 2293762
        }
      ],
      "n": "InternalGetComponents",
      "d": 1703938,
      "h": 700081373186,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(700081373186),
//--TRIMMABLE-BOUNDARY-START(163210461186),
    {
      "r": 655361,
      "p": [
        {
          "n": "uri1",
          "p": 1703938
        },
        {
          "n": "uri2",
          "p": 1703938
        },
        {
          "n": "partsToCompare",
          "p": 2162690
        },
        {
          "n": "compareFormat",
          "p": 2293762
        },
        {
          "n": "comparisonType",
          "p": 163577857
        }
      ],
      "n": "Compare",
      "d": 1703938,
      "h": 163210461186,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(163210461186),
//--TRIMMABLE-BOUNDARY-START(794570653698),
    {
      "r": 262145,
      "n": "IsWellFormedOriginalString",
      "d": 1703938,
      "h": 794570653698,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(794570653698),
//--TRIMMABLE-BOUNDARY-START(798865620994),
    {
      "r": 262145,
      "p": [
        {
          "n": "uriString",
          "p": 1310721
        },
        {
          "n": "uriKind",
          "p": 2555906
        }
      ],
      "n": "IsWellFormedUriString",
      "d": 1703938,
      "h": 798865620994,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(798865620994),
//--TRIMMABLE-BOUNDARY-START(704376340482),
    {
      "r": 262145,
      "n": "InternalIsWellFormedOriginalString",
      "d": 1703938,
      "h": 704376340482,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(704376340482),
//--TRIMMABLE-BOUNDARY-START(1013613985794),
    {
      "r": 1310721,
      "p": [
        {
          "n": "stringToUnescape",
          "p": 1310721
        }
      ],
      "n": "UnescapeDataString",
      "o": "@$2",
      "d": 1703938,
      "h": 1013613985794,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(1013613985794),
//--TRIMMABLE-BOUNDARY-START(1009319018498),
    {
      "r": 1310721,
      "p": [
        {
          "n": "charsToUnescape",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "UnescapeDataString",
      "o": "@$1",
      "d": 1703938,
      "h": 1009319018498,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(1009319018498),
//--TRIMMABLE-BOUNDARY-START(1005024051202),
    {
      "r": 1310721,
      "p": [
        {
          "n": "charsToUnescape",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "backingString",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "UnescapeDataString",
      "d": 1703938,
      "h": 1005024051202,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(1005024051202),
//--TRIMMABLE-BOUNDARY-START(996434116610),
    {
      "r": 262145,
      "p": [
        {
          "n": "charsToUnescape",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryUnescapeDataString",
      "d": 1703938,
      "h": 996434116610,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(996434116610),
//--TRIMMABLE-BOUNDARY-START(261994708994),
    {
      "r": 1310721,
      "p": [
        {
          "n": "stringToEscape",
          "p": 1310721
        }
      ],
      "n": "EscapeUriString",
      "d": 1703938,
      "h": 261994708994,
      "f": 16777249,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0013",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(261994708994),
//--TRIMMABLE-BOUNDARY-START(249109807106),
    {
      "r": 1310721,
      "p": [
        {
          "n": "stringToEscape",
          "p": 1310721
        }
      ],
      "n": "EscapeDataString",
      "o": "@$1",
      "d": 1703938,
      "h": 249109807106,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(249109807106),
//--TRIMMABLE-BOUNDARY-START(244814839810),
    {
      "r": 1310721,
      "p": [
        {
          "n": "charsToEscape",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "EscapeDataString",
      "d": 1703938,
      "h": 244814839810,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(244814839810),
//--TRIMMABLE-BOUNDARY-START(983549214722),
    {
      "r": 262145,
      "p": [
        {
          "n": "charsToEscape",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryEscapeDataString",
      "d": 1703938,
      "h": 983549214722,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(983549214722),
//--TRIMMABLE-BOUNDARY-START(257699741698),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": 1310721
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        },
        {
          "n": "component",
          "p": 2162690
        }
      ],
      "n": "EscapeUnescapeIri",
      "d": 1703938,
      "h": 257699741698,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(257699741698),
//--TRIMMABLE-BOUNDARY-START(171800395778),
    {
      "r": 1703938,
      "p": [
        {
          "n": "uriString",
          "p": 1310721
        },
        {
          "n": "dontEscape",
          "p": 262145
        },
        {
          "n": "uriKind",
          "p": 2555906
        },
        {
          "n": "e",
          "p": 2359298,
          "f": 4
        },
        {
          "n": "creationOptions",
          "p": 2228226,
          "f": 73
        }
      ],
      "n": "CreateHelper",
      "d": 1703938,
      "h": 171800395778,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(171800395778),
//--TRIMMABLE-BOUNDARY-START(889059934210),
    {
      "r": 1703938,
      "p": [
        {
          "n": "baseUri",
          "p": 1703938
        },
        {
          "n": "relativeUri",
          "p": 1703938
        },
        {
          "n": "newUriString",
          "p": 1310721,
          "f": 4
        },
        {
          "n": "userEscaped",
          "p": 262145,
          "f": 4
        }
      ],
      "n": "ResolveHelper",
      "d": 1703938,
      "h": 889059934210,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(889059934210),
//--TRIMMABLE-BOUNDARY-START(639951831042),
    {
      "r": 1310721,
      "p": [
        {
          "n": "format",
          "p": 2293762
        }
      ],
      "n": "GetRelativeSerializationString",
      "d": 1703938,
      "h": 639951831042,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(639951831042),
//--TRIMMABLE-BOUNDARY-START(597002158082),
    {
      "r": 1310721,
      "p": [
        {
          "n": "uriComponents",
          "p": 2162690
        },
        {
          "n": "uriFormat",
          "p": 2293762
        }
      ],
      "n": "GetComponentsHelper",
      "d": 1703938,
      "h": 597002158082,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(597002158082),
//--TRIMMABLE-BOUNDARY-START(725851176962),
    {
      "r": 262145,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        }
      ],
      "n": "IsBaseOf",
      "d": 1703938,
      "h": 725851176962,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(725851176962),
//--TRIMMABLE-BOUNDARY-START(730146144258),
    {
      "r": 262145,
      "p": [
        {
          "n": "uriLink",
          "p": 1703938
        }
      ],
      "n": "IsBaseOfHelper",
      "d": 1703938,
      "h": 730146144258,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(730146144258),
//--TRIMMABLE-BOUNDARY-START(188980264962),
    {
      "r": 65537,
      "p": [
        {
          "n": "otherUri",
          "p": 1703938
        }
      ],
      "n": "CreateThisFromUri",
      "d": 1703938,
      "h": 188980264962,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(188980264962),
//--TRIMMABLE-BOUNDARY-START(206160134146),
    {
      "r": 65537,
      "n": "DebugSetLeftCtor",
      "d": 1703938,
      "h": 206160134146,
      "f": 16777218,
      "a": [
        {
          "t": 68747265,
          "c": 8658681857,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206160134146),
//--TRIMMABLE-BOUNDARY-START(98785951746),
    {
      "r": 65537,
      "n": "AssertInvariants",
      "d": 1703938,
      "h": 98785951746,
      "f": 16777218,
      "a": [
        {
          "t": 68747265,
          "c": 8658681857,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98785951746),
//--TRIMMABLE-BOUNDARY-START(201865166850),
    {
      "r": 65537,
      "n": "DebugAssertInCtor",
      "d": 1703938,
      "h": 201865166850,
      "f": 16777224,
      "a": [
        {
          "t": 68747265,
          "c": 8658681857,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201865166850),
//--TRIMMABLE-BOUNDARY-START(691491438594),
    {
      "r": 65537,
      "p": [
        {
          "n": "flags",
          "p": 1835010
        }
      ],
      "n": "InterlockedSetFlags",
      "d": 1703938,
      "h": 691491438594,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(691491438594),
//--TRIMMABLE-BOUNDARY-START(712966275074),
    {
      "r": 262145,
      "p": [
        {
          "n": "syntax",
          "p": 2621442
        }
      ],
      "n": "IriParsingStatic",
      "d": 1703938,
      "h": 712966275074,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(712966275074),
//--TRIMMABLE-BOUNDARY-START(816045490178),
    {
      "r": 262145,
      "p": [
        {
          "n": "flags",
          "p": 1835010
        }
      ],
      "n": "NotAny",
      "d": 1703938,
      "h": 816045490178,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(816045490178),
//--TRIMMABLE-BOUNDARY-START(682901504002),
    {
      "r": 262145,
      "p": [
        {
          "n": "flags",
          "p": 1835010
        }
      ],
      "n": "InFact",
      "d": 1703938,
      "h": 682901504002,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(682901504002),
//--TRIMMABLE-BOUNDARY-START(940599541762),
    {
      "r": 262145,
      "p": [
        {
          "n": "allFlags",
          "p": 1835010
        },
        {
          "n": "checkFlags",
          "p": 1835010
        }
      ],
      "n": "StaticNotAny",
      "d": 1703938,
      "h": 940599541762,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(940599541762),
//--TRIMMABLE-BOUNDARY-START(932009607170),
    {
      "r": 262145,
      "p": [
        {
          "n": "allFlags",
          "p": 1835010
        },
        {
          "n": "checkFlags",
          "p": 1835010
        }
      ],
      "n": "StaticInFact",
      "d": 1703938,
      "h": 932009607170,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(932009607170),
//--TRIMMABLE-BOUNDARY-START(227634970626),
    {
      "r": 2031618,
      "n": "EnsureUriInfo",
      "d": 1703938,
      "h": 227634970626,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(227634970626),
//--TRIMMABLE-BOUNDARY-START(223340003330),
    {
      "r": 65537,
      "n": "EnsureParseRemaining",
      "d": 1703938,
      "h": 223340003330,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223340003330),
//--TRIMMABLE-BOUNDARY-START(219045036034),
    {
      "r": 65537,
      "p": [
        {
          "n": "allowDnsOptimization",
          "p": 262145
        }
      ],
      "n": "EnsureHostString",
      "d": 1703938,
      "h": 219045036034,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(219045036034),
//--TRIMMABLE-BOUNDARY-START(631361896450),
    {
      "r": 65537,
      "p": [
        {
          "n": "serializationInfo",
          "p": 158072833
        },
        {
          "n": "streamingContext",
          "p": 158203905
        }
      ],
      "n": "GetObjectData",
      "d": 1703938,
      "h": 631361896450,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(631361896450),
//--TRIMMABLE-BOUNDARY-START(193275232258),
    {
      "r": 65537,
      "p": [
        {
          "n": "baseUri",
          "p": 1703938
        },
        {
          "n": "relativeUri",
          "p": 1310721
        },
        {
          "n": "dontEscape",
          "p": 262145
        }
      ],
      "n": "CreateUri",
      "d": 1703938,
      "h": 193275232258,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(193275232258),
//--TRIMMABLE-BOUNDARY-START(588412223490),
    {
      "r": 65537,
      "p": [
        {
          "n": "baseUri",
          "p": 1703938
        },
        {
          "n": "relativeStr",
          "p": 1310721
        },
        {
          "n": "dontEscape",
          "p": 262145
        },
        {
          "n": "result",
          "p": 1310721,
          "f": 4
        }
      ],
      "n": "GetCombinedString",
      "d": 1703938,
      "h": 588412223490,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(588412223490),
//--TRIMMABLE-BOUNDARY-START(605592092674),
    {
      "r": 2359298,
      "p": [
        {
          "n": "err",
          "p": 1310722
        }
      ],
      "n": "GetException",
      "d": 1703938,
      "h": 605592092674,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(605592092674),
//--TRIMMABLE-BOUNDARY-START(936304574466),
    {
      "r": 262145,
      "p": [
        {
          "n": "syntax",
          "p": 2621442
        }
      ],
      "n": "StaticIsFile",
      "d": 1703938,
      "h": 936304574466,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(936304574466),
//--TRIMMABLE-BOUNDARY-START(627066929154),
    {
      "r": 1310721,
      "n": "GetLocalPath",
      "d": 1703938,
      "h": 627066929154,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(627066929154),
//--TRIMMABLE-BOUNDARY-START(141735624706),
    {
      "r": 2490370,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "CheckHostName",
      "d": 1703938,
      "h": 141735624706,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(141735624706),
//--TRIMMABLE-BOUNDARY-START(618476994562),
    {
      "r": 1310721,
      "p": [
        {
          "n": "part",
          "p": 2752514
        }
      ],
      "n": "GetLeftPart",
      "d": 1703938,
      "h": 618476994562,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(618476994562),
//--TRIMMABLE-BOUNDARY-START(657131700226),
    {
      "r": 1310721,
      "p": [
        {
          "n": "character",
          "p": 458753
        }
      ],
      "n": "HexEscape",
      "d": 1703938,
      "h": 657131700226,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(657131700226),
//--TRIMMABLE-BOUNDARY-START(661426667522),
    {
      "r": 458753,
      "p": [
        {
          "n": "pattern",
          "p": 1310721
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "HexUnescape",
      "d": 1703938,
      "h": 661426667522,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(661426667522),
//--TRIMMABLE-BOUNDARY-START(755915948034),
    {
      "r": 262145,
      "p": [
        {
          "n": "pattern",
          "p": 1310721
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "IsHexEncoding",
      "d": 1703938,
      "h": 755915948034,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(755915948034),
//--TRIMMABLE-BOUNDARY-START(146030592002),
    {
      "r": 262145,
      "p": [
        {
          "n": "schemeName",
          "p": 1310721
        }
      ],
      "n": "CheckSchemeName",
      "d": 1703938,
      "h": 146030592002,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(146030592002),
//--TRIMMABLE-BOUNDARY-START(751620980738),
    {
      "r": 262145,
      "p": [
        {
          "n": "character",
          "p": 458753
        }
      ],
      "n": "IsHexDigit",
      "d": 1703938,
      "h": 751620980738,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(751620980738),
//--TRIMMABLE-BOUNDARY-START(270584643586),
    {
      "r": 655361,
      "p": [
        {
          "n": "digit",
          "p": 458753
        }
      ],
      "n": "FromHex",
      "d": 1703938,
      "h": 270584643586,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(270584643586),
//--TRIMMABLE-BOUNDARY-START(609887059970),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1703938,
      "h": 609887059970,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(609887059970),
//--TRIMMABLE-BOUNDARY-START(962074378242),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1703938,
      "h": 962074378242,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(962074378242),
//--TRIMMABLE-BOUNDARY-START(987844182018),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryFormat",
      "d": 1703938,
      "h": 987844182018,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(987844182018),
//--TRIMMABLE-BOUNDARY-START(231929937922),
    {
      "r": 262145,
      "p": [
        {
          "n": "comparand",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1703938,
      "h": 231929937922,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(231929937922),
//--TRIMMABLE-BOUNDARY-START(236224905218),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1703938
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1703938,
      "h": 236224905218,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(236224905218),
//--TRIMMABLE-BOUNDARY-START(811750522882),
    {
      "r": 1703938,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        }
      ],
      "n": "MakeRelativeUri",
      "d": 1703938,
      "h": 811750522882,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(811750522882),
//--TRIMMABLE-BOUNDARY-START(133145690114),
    {
      "r": 262145,
      "p": [
        {
          "n": "uriString",
          "p": 1310721
        }
      ],
      "n": "CheckForColonInFirstPathSegment",
      "d": 1703938,
      "h": 133145690114,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(133145690114),
//--TRIMMABLE-BOUNDARY-START(695786405890),
    {
      "r": 1310721,
      "p": [
        {
          "n": "rawString",
          "p": 1310721
        }
      ],
      "n": "InternalEscapeString",
      "d": 1703938,
      "h": 695786405890,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(695786405890),
//--TRIMMABLE-BOUNDARY-START(846110261250),
    {
      "r": 1310722,
      "p": [
        {
          "n": "uriString",
          "p": 1310721
        },
        {
          "n": "flags",
          "p": 1835010,
          "f": 4
        },
        {
          "n": "syntax",
          "p": 2621442,
          "f": 4
        }
      ],
      "n": "ParseScheme",
      "d": 1703938,
      "h": 846110261250,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(846110261250),
//--TRIMMABLE-BOUNDARY-START(837520326658),
    {
      "r": 2359298,
      "n": "ParseMinimal",
      "d": 1703938,
      "h": 837520326658,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(837520326658),
//--TRIMMABLE-BOUNDARY-START(871880065026),
    {
      "r": 1310722,
      "n": "PrivateParseMinimal",
      "d": 1703938,
      "h": 871880065026,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(871880065026),
//--TRIMMABLE-BOUNDARY-START(197570199554),
    {
      "r": 65537,
      "p": [
        {
          "n": "cF",
          "p": 1835010
        }
      ],
      "n": "CreateUriInfo",
      "d": 1703938,
      "h": 197570199554,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(197570199554),
//--TRIMMABLE-BOUNDARY-START(176095363074),
    {
      "r": 65537,
      "n": "CreateHostString",
      "d": 1703938,
      "h": 176095363074,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176095363074),
//--TRIMMABLE-BOUNDARY-START(180390330370),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        },
        {
          "n": "idx",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        },
        {
          "n": "flags",
          "p": 1835010,
          "f": 4
        },
        {
          "n": "info",
          "p": 2031618
        }
      ],
      "n": "CreateHostStringHelper",
      "d": 1703938,
      "h": 180390330370,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(180390330370),
//--TRIMMABLE-BOUNDARY-START(614182027266),
    {
      "r": 65537,
      "n": "GetHostViaCustomSyntax",
      "d": 1703938,
      "h": 614182027266,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(614182027266),
//--TRIMMABLE-BOUNDARY-START(635656863746),
    {
      "r": 1310721,
      "p": [
        {
          "n": "uriParts",
          "p": 2162690
        },
        {
          "n": "formatAs",
          "p": 2293762
        }
      ],
      "n": "GetParts",
      "d": 1703938,
      "h": 635656863746,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(635656863746),
//--TRIMMABLE-BOUNDARY-START(601297125378),
    {
      "r": 1310721,
      "p": [
        {
          "n": "uriParts",
          "p": 2162690
        }
      ],
      "n": "GetEscapedParts",
      "d": 1703938,
      "h": 601297125378,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(601297125378),
//--TRIMMABLE-BOUNDARY-START(644246798338),
    {
      "r": 1310721,
      "p": [
        {
          "n": "uriParts",
          "p": 2162690
        },
        {
          "n": "formatAs",
          "p": 2293762
        }
      ],
      "n": "GetUnescapedParts",
      "d": 1703938,
      "h": 644246798338,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(644246798338),
//--TRIMMABLE-BOUNDARY-START(880469999618),
    {
      "r": 1310721,
      "p": [
        {
          "n": "parts",
          "p": 2162690
        },
        {
          "n": "nonCanonical",
          "p": 589825
        },
        {
          "n": "formatAs",
          "p": 2293762
        }
      ],
      "n": "RecreateParts",
      "d": 1703938,
      "h": 880469999618,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(880469999618),
//--TRIMMABLE-BOUNDARY-START(992139149314),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "parts",
          "p": 2162690
        },
        {
          "n": "nonCanonical",
          "p": 589825
        },
        {
          "n": "formatAs",
          "p": 2293762
        }
      ],
      "n": "TryRecreateParts",
      "d": 1703938,
      "h": 992139149314,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(992139149314),
//--TRIMMABLE-BOUNDARY-START(884764966914),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "dest",
          "p": 1507330,
          "f": 4
        },
        {
          "n": "str",
          "p": 1310721
        },
        {
          "n": "parts",
          "p": 2162690
        },
        {
          "n": "nonCanonical",
          "p": 589825
        },
        {
          "n": "formatAs",
          "p": 2293762
        }
      ],
      "n": "RecreateParts",
      "o": "@$1",
      "d": 1703938,
      "h": 884764966914,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(884764966914),
//--TRIMMABLE-BOUNDARY-START(648541765634),
    {
      "r": 1310721,
      "p": [
        {
          "n": "uriParts",
          "p": 2162690
        }
      ],
      "n": "GetUriPartsFromUserString",
      "d": 1703938,
      "h": 648541765634,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(648541765634),
//--TRIMMABLE-BOUNDARY-START(622771961858),
    {
      "r": 65537,
      "p": [
        {
          "n": "str",
          "p": 1310721
        },
        {
          "n": "length",
          "p": 655361,
          "f": 4
        },
        {
          "n": "idx",
          "p": 655361
        }
      ],
      "n": "GetLengthWithoutTrailingSpaces",
      "d": 1703938,
      "h": 622771961858,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(622771961858),
//--TRIMMABLE-BOUNDARY-START(841815293954),
    {
      "r": 65537,
      "n": "ParseRemaining",
      "d": 1703938,
      "h": 841815293954,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(841815293954),
//--TRIMMABLE-BOUNDARY-START(850405228546),
    {
      "r": 655361,
      "p": [
        {
          "n": "uriString",
          "p": 1310721
        },
        {
          "n": "err",
          "p": 1310722,
          "f": 4
        },
        {
          "n": "flags",
          "p": 1835010,
          "f": 4
        },
        {
          "n": "syntax",
          "p": 2621442,
          "f": 4
        }
      ],
      "n": "ParseSchemeCheckImplicitFile",
      "d": 1703938,
      "h": 850405228546,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(850405228546),
//--TRIMMABLE-BOUNDARY-START(150325559298),
    {
      "r": 2621442,
      "p": [
        {
          "n": "scheme",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "error",
          "p": 1310722,
          "f": 4
        }
      ],
      "n": "CheckSchemeSyntax",
      "d": 1703938,
      "h": 150325559298,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(150325559298),
//--TRIMMABLE-BOUNDARY-START(120260788226),
    {
      "r": 655361,
      "p": [
        {
          "n": "pString",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "idx",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "err",
          "p": 1310722,
          "f": 4
        },
        {
          "n": "flags",
          "p": 1835010,
          "f": 4
        },
        {
          "n": "syntax",
          "p": 2621442
        },
        {
          "n": "newHost",
          "p": 1310721,
          "f": 4
        }
      ],
      "n": "CheckAuthorityHelper",
      "d": 1703938,
      "h": 120260788226,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120260788226),
//--TRIMMABLE-BOUNDARY-START(124555755522),
    {
      "r": 65537,
      "p": [
        {
          "n": "pString",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        },
        {
          "n": "hasUnicode",
          "p": 262145
        },
        {
          "n": "flags",
          "p": 1835010,
          "f": 4
        },
        {
          "n": "newHost",
          "p": 1310721,
          "f": 4
        },
        {
          "n": "err",
          "p": 1310722,
          "f": 4
        }
      ],
      "n": "CheckAuthorityHelperHandleDnsIri",
      "d": 1703938,
      "h": 124555755522,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(124555755522),
//--TRIMMABLE-BOUNDARY-START(128850722818),
    {
      "r": 1769474,
      "p": [
        {
          "n": "str",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "idx",
          "p": 655361,
          "f": 4
        },
        {
          "n": "end",
          "p": 655361
        },
        {
          "n": "delim",
          "p": 458753
        }
      ],
      "n": "CheckCanonical",
      "d": 1703938,
      "h": 128850722818,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128850722818),
//--TRIMMABLE-BOUNDARY-START(584117256194),
    {
      "r": 65537,
      "p": [
        {
          "n": "dest",
          "p": 1507330,
          "f": 4
        },
        {
          "n": "formatAs",
          "p": 2293762
        }
      ],
      "n": "GetCanonicalPath",
      "d": 1703938,
      "h": 584117256194,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(584117256194),
//--TRIMMABLE-BOUNDARY-START(1017908953090),
    {
      "r": 65537,
      "p": [
        {
          "n": "pch",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361,
          "f": 4
        },
        {
          "n": "ch1",
          "p": 458753
        },
        {
          "n": "ch2",
          "p": 458753
        },
        {
          "n": "ch3",
          "p": 458753
        }
      ],
      "n": "UnescapeOnly",
      "d": 1703938,
      "h": 1017908953090,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(1017908953090),
//--TRIMMABLE-BOUNDARY-START(167505428482),
    {
      "r": 65537,
      "p": [
        {
          "n": "dest",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "destLength",
          "p": 655361,
          "f": 4
        },
        {
          "n": "syntax",
          "p": 2621442
        }
      ],
      "n": "Compress",
      "d": 1703938,
      "h": 167505428482,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(167505428482),
//--TRIMMABLE-BOUNDARY-START(158915493890),
    {
      "r": 1310721,
      "p": [
        {
          "n": "basePart",
          "p": 1703938
        },
        {
          "n": "relativePart",
          "p": 1310721
        },
        {
          "n": "uriFormat",
          "p": 2293762
        }
      ],
      "n": "CombineUri",
      "d": 1703938,
      "h": 158915493890,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(158915493890),
//--TRIMMABLE-BOUNDARY-START(858995163138),
    {
      "r": 1310721,
      "p": [
        {
          "n": "path1",
          "p": 1310721
        },
        {
          "n": "path2",
          "p": 1310721
        },
        {
          "n": "compareCase",
          "p": 262145
        }
      ],
      "n": "PathDifference",
      "d": 1703938,
      "h": 858995163138,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(858995163138),
//--TRIMMABLE-BOUNDARY-START(807455555586),
    {
      "r": 1310721,
      "p": [
        {
          "n": "toUri",
          "p": 1703938
        }
      ],
      "n": "MakeRelative",
      "d": 1703938,
      "h": 807455555586,
      "f": 16777217,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "Uri.MakeRelative has been deprecated. Use MakeRelativeUri(Uri uri) instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(807455555586),
//--TRIMMABLE-BOUNDARY-START(115965820930),
    {
      "r": 65537,
      "n": "Canonicalize",
      "d": 1703938,
      "h": 115965820930,
      "f": 16777348,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "Uri.Canonicalize has been deprecated and is not supported.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115965820930),
//--TRIMMABLE-BOUNDARY-START(833225359362),
    {
      "r": 65537,
      "n": "Parse",
      "d": 1703938,
      "h": 833225359362,
      "f": 16777348,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "Uri.Parse has been deprecated and is not supported.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(833225359362),
//--TRIMMABLE-BOUNDARY-START(240519872514),
    {
      "r": 65537,
      "n": "Escape",
      "d": 1703938,
      "h": 240519872514,
      "f": 16777348,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "Uri.Escape has been deprecated and is not supported.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(240519872514),
//--TRIMMABLE-BOUNDARY-START(1000729083906),
    {
      "r": 1310721,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "Unescape",
      "d": 1703938,
      "h": 1000729083906,
      "f": 16777348,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "Uri.Unescape has been deprecated. Use GetComponents() or Uri.UnescapeDataString() to unescape a Uri component or a string.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(1000729083906),
//--TRIMMABLE-BOUNDARY-START(253404774402),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        }
      ],
      "n": "EscapeString",
      "d": 1703938,
      "h": 253404774402,
      "f": 16777252,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "Uri.EscapeString has been deprecated. Use GetComponents() or Uri.EscapeDataString to escape a Uri component or a string.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253404774402),
//--TRIMMABLE-BOUNDARY-START(154620526594),
    {
      "r": 65537,
      "n": "CheckSecurity",
      "d": 1703938,
      "h": 154620526594,
      "f": 16777348,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "Uri.CheckSecurity has been deprecated and is not supported.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154620526594),
//--TRIMMABLE-BOUNDARY-START(773095817218),
    {
      "r": 262145,
      "p": [
        {
          "n": "character",
          "p": 458753
        }
      ],
      "n": "IsReservedCharacter",
      "d": 1703938,
      "h": 773095817218,
      "f": 16777348,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "Uri.IsReservedCharacter has been deprecated and is not supported.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(773095817218),
//--TRIMMABLE-BOUNDARY-START(743031046146),
    {
      "r": 262145,
      "p": [
        {
          "n": "character",
          "p": 458753
        }
      ],
      "n": "IsExcludedCharacter",
      "d": 1703938,
      "h": 743031046146,
      "f": 16777252,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "Uri.IsExcludedCharacter has been deprecated and is not supported.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(743031046146),
//--TRIMMABLE-BOUNDARY-START(721556209666),
    {
      "r": 262145,
      "p": [
        {
          "n": "character",
          "p": 458753
        }
      ],
      "n": "IsBadFileSystemCharacter",
      "d": 1703938,
      "h": 721556209666,
      "f": 16777348,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "Uri.IsBadFileSystemCharacter has been deprecated and is not supported.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(721556209666)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(893354901506),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "s_asciiOtherThanPercent",
      "d": 1703938,
      "h": 893354901506,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(893354901506),
//--TRIMMABLE-BOUNDARY-START(1022203920386),
    {
      "t": 1310721,
      "n": "UriSchemeFile",
      "d": 1703938,
      "h": 1022203920386,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1022203920386),
//--TRIMMABLE-BOUNDARY-START(1026498887682),
    {
      "t": 1310721,
      "n": "UriSchemeFtp",
      "d": 1703938,
      "h": 1026498887682,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1026498887682),
//--TRIMMABLE-BOUNDARY-START(1069448560642),
    {
      "t": 1310721,
      "n": "UriSchemeSftp",
      "d": 1703938,
      "h": 1069448560642,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1069448560642),
//--TRIMMABLE-BOUNDARY-START(1030793854978),
    {
      "t": 1310721,
      "n": "UriSchemeFtps",
      "d": 1703938,
      "h": 1030793854978,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1030793854978),
//--TRIMMABLE-BOUNDARY-START(1035088822274),
    {
      "t": 1310721,
      "n": "UriSchemeGopher",
      "d": 1703938,
      "h": 1035088822274,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1035088822274),
//--TRIMMABLE-BOUNDARY-START(1039383789570),
    {
      "t": 1310721,
      "n": "UriSchemeHttp",
      "d": 1703938,
      "h": 1039383789570,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1039383789570),
//--TRIMMABLE-BOUNDARY-START(1043678756866),
    {
      "t": 1310721,
      "n": "UriSchemeHttps",
      "d": 1703938,
      "h": 1043678756866,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1043678756866),
//--TRIMMABLE-BOUNDARY-START(1082333462530),
    {
      "t": 1310721,
      "n": "UriSchemeWs",
      "d": 1703938,
      "h": 1082333462530,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1082333462530),
//--TRIMMABLE-BOUNDARY-START(1086628429826),
    {
      "t": 1310721,
      "n": "UriSchemeWss",
      "d": 1703938,
      "h": 1086628429826,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1086628429826),
//--TRIMMABLE-BOUNDARY-START(1047973724162),
    {
      "t": 1310721,
      "n": "UriSchemeMailto",
      "d": 1703938,
      "h": 1047973724162,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1047973724162),
//--TRIMMABLE-BOUNDARY-START(1060858626050),
    {
      "t": 1310721,
      "n": "UriSchemeNews",
      "d": 1703938,
      "h": 1060858626050,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1060858626050),
//--TRIMMABLE-BOUNDARY-START(1065153593346),
    {
      "t": 1310721,
      "n": "UriSchemeNntp",
      "d": 1703938,
      "h": 1065153593346,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1065153593346),
//--TRIMMABLE-BOUNDARY-START(1073743527938),
    {
      "t": 1310721,
      "n": "UriSchemeSsh",
      "d": 1703938,
      "h": 1073743527938,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1073743527938),
//--TRIMMABLE-BOUNDARY-START(1078038495234),
    {
      "t": 1310721,
      "n": "UriSchemeTelnet",
      "d": 1703938,
      "h": 1078038495234,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1078038495234),
//--TRIMMABLE-BOUNDARY-START(1056563658754),
    {
      "t": 1310721,
      "n": "UriSchemeNetTcp",
      "d": 1703938,
      "h": 1056563658754,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1056563658754),
//--TRIMMABLE-BOUNDARY-START(1052268691458),
    {
      "t": 1310721,
      "n": "UriSchemeNetPipe",
      "d": 1703938,
      "h": 1052268691458,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1052268691458),
//--TRIMMABLE-BOUNDARY-START(910534770690),
    {
      "t": 1310721,
      "n": "SchemeDelimiter",
      "d": 1703938,
      "h": 910534770690,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(910534770690),
//--TRIMMABLE-BOUNDARY-START(914829737986),
    {
      "t": 655361,
      "n": "SchemeLengthLimit",
      "d": 1703938,
      "h": 914829737986,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(914829737986),
//--TRIMMABLE-BOUNDARY-START(927714639874),
    {
      "t": 655361,
      "n": "StackallocThreshold",
      "d": 1703938,
      "h": 927714639874,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(927714639874),
//--TRIMMABLE-BOUNDARY-START(17181573122),
    {
      "t": 1310721,
      "n": "_string",
      "d": 1703938,
      "h": 17181573122,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181573122),
//--TRIMMABLE-BOUNDARY-START(12886605826),
    {
      "t": 1310721,
      "n": "_originalUnicodeString",
      "d": 1703938,
      "h": 12886605826,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886605826),
//--TRIMMABLE-BOUNDARY-START(21476540418),
    {
      "t": 2621442,
      "n": "_syntax",
      "d": 1703938,
      "h": 21476540418,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21476540418),
//--TRIMMABLE-BOUNDARY-START(4296671234),
    {
      "t": 1835010,
      "n": "_flags",
      "d": 1703938,
      "h": 4296671234,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4296671234),
//--TRIMMABLE-BOUNDARY-START(8591638530),
    {
      "t": 2031618,
      "n": "_info",
      "d": 1703938,
      "h": 8591638530,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591638530),
//--TRIMMABLE-BOUNDARY-START(897649868802),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "s_schemeChars",
      "d": 1703938,
      "h": 897649868802,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(897649868802),
//--TRIMMABLE-BOUNDARY-START(1103808299010),
    {
      "t": 2293762,
      "n": "V1ToStringUnescape",
      "d": 1703938,
      "h": 1103808299010,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(1103808299010),
//--TRIMMABLE-BOUNDARY-START(901944836098),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "s_segmentSeparatorChars",
      "d": 1703938,
      "h": 901944836098,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(901944836098),
//--TRIMMABLE-BOUNDARY-START(107375886338),
    {
      "t": 458753,
      "n": "c_DummyChar",
      "d": 1703938,
      "h": 107375886338,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107375886338),
//--TRIMMABLE-BOUNDARY-START(111670853634),
    {
      "t": 458753,
      "n": "c_EOL",
      "d": 1703938,
      "h": 111670853634,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111670853634)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(85901049858),
    {
      "p": [
        {
          "n": "flags",
          "p": 1835010
        },
        {
          "n": "uriParser",
          "p": 2621442
        },
        {
          "n": "uri",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 1703938,
      "h": 85901049858,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85901049858),
//--TRIMMABLE-BOUNDARY-START(68721180674),
    {
      "p": [
        {
          "n": "uriString",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1703938,
      "h": 68721180674,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721180674),
//--TRIMMABLE-BOUNDARY-START(55836278786),
    {
      "p": [
        {
          "n": "uriString",
          "p": 1310721
        },
        {
          "n": "dontEscape",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1703938,
      "h": 55836278786,
      "f": 16777217,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "This constructor has been deprecated; the dontEscape parameter is always false. Use Uri(string) instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836278786),
//--TRIMMABLE-BOUNDARY-START(73016147970),
    {
      "p": [
        {
          "n": "baseUri",
          "p": 1703938
        },
        {
          "n": "relativeUri",
          "p": 1310721
        },
        {
          "n": "dontEscape",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1703938,
      "h": 73016147970,
      "f": 16777217,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "This constructor has been deprecated; the dontEscape parameter is always false. Use Uri(Uri, string) instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73016147970),
//--TRIMMABLE-BOUNDARY-START(60131246082),
    {
      "p": [
        {
          "n": "uriString",
          "p": 1310721
        },
        {
          "n": "uriKind",
          "p": 2555906
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1703938,
      "h": 60131246082,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131246082),
//--TRIMMABLE-BOUNDARY-START(64426213378),
    {
      "p": [
        {
          "n": "uriString",
          "p": 1310721
        },
        {
          "n": "creationOptions",
          "p": 2228226,
          "f": 8
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1703938,
      "h": 64426213378,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426213378),
//--TRIMMABLE-BOUNDARY-START(77311115266),
    {
      "p": [
        {
          "n": "baseUri",
          "p": 1703938
        },
        {
          "n": "relativeUri",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1703938,
      "h": 77311115266,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311115266),
//--TRIMMABLE-BOUNDARY-START(51541311490),
    {
      "p": [
        {
          "n": "serializationInfo",
          "p": 158072833
        },
        {
          "n": "streamingContext",
          "p": 158203905
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1703938,
      "h": 51541311490,
      "f": 16777220,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0051",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541311490),
//--TRIMMABLE-BOUNDARY-START(81606082562),
    {
      "p": [
        {
          "n": "baseUri",
          "p": 1703938
        },
        {
          "n": "relativeUri",
          "p": 1703938
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1703938,
      "h": 81606082562,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81606082562)
  ],
  "i": [96600065,90505217,$.$$.System.IEquatable$$($.$spu.System.Uri).$h,157483009
  ],
  "j": [1835010,2031618,1966082,1900546,1769474
  ],
  "h": 1703938,
  "a": [
    {
      "t": 162332673,
      "c": 4457299969
    },
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IEquatable$$($.$spu.System.Uri), $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Uri`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703938)
        
        
        //--TRIMMABLE-BOUNDARY-START(720898)
        $asm.$cls("$spu.System.HttpStyleUriParser", ($self) => class HttpStyleUriParser extends $.$spu.System.UriParser
        {
            //--TRIMMABLE-BOUNDARY-START(4295688194)
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.HttpUri.Flags);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295688194);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688194)
            
            static $h = 720898;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2621442,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688194),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720898,
      "h": 4295688194,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688194)
  ],
  "h": 720898
}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.HttpStyleUriParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720898)
        
        
        //--TRIMMABLE-BOUNDARY-START(2228226)
        $asm.$str("$spu.System.UriCreationOptions", ($self) => class UriCreationOptions extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4297195522)
            /*bool*/  get _disablePathAndQueryCanonicalization() { return this.$getField(0, 1); }
            /*bool*/  set _disablePathAndQueryCanonicalization(value) { this.$setField(0, 1, value); }
            //--TRIMMABLE-BOUNDARY-END(4297195522)
            
            //--TRIMMABLE-BOUNDARY-START(12887130114)
            /*bool */ get DangerousDisablePathAndQueryCanonicalization()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477064706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._disablePathAndQueryCanonicalization;
            }
            /*bool */ set DangerousDisablePathAndQueryCanonicalization(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066999298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._disablePathAndQueryCanonicalization = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12887130114)
            
            //--TRIMMABLE-BOUNDARY-START(8592162818)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592162818)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._disablePathAndQueryCanonicalization = this._disablePathAndQueryCanonicalization;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4297195522)
                this._disablePathAndQueryCanonicalization = false;
                //--TRIMMABLE-BOUNDARY-END(4297195522)
                
            }
            static $h = 2228226;
            static $z = 1;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887130114),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477064706,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066999298,
        "f": 83886081
      },
      "n": "DangerousDisablePathAndQueryCanonicalization",
      "d": 2228226,
      "h": 12887130114,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12887130114)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297195522),
    {
      "t": 262145,
      "n": "_disablePathAndQueryCanonicalization",
      "d": 2228226,
      "h": 4297195522,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297195522)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592162818),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2228226,
      "h": 8592162818,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592162818)
  ],
  "h": 2228226
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.UriCreationOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228226)
        
        
        //--TRIMMABLE-BOUNDARY-START(262146)
        $asm.$cls("$spu.System.FtpStyleUriParser", ($self) => class FtpStyleUriParser extends $.$spu.System.UriParser
        {
            //--TRIMMABLE-BOUNDARY-START(4295229442)
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.FtpUri.Flags);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229442);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229442)
            
            static $h = 262146;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2621442,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229442),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262146,
      "h": 4295229442,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229442)
  ],
  "h": 262146
}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.FtpStyleUriParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262146)
        
        
        //--TRIMMABLE-BOUNDARY-START(327682)
        $asm.$cls("$spu.System.GenericUriParser", ($self) => class GenericUriParser extends $.$spu.System.UriParser
        {
            //--TRIMMABLE-BOUNDARY-START(4295294978)
            $ctor$3(/*GenericUriParserOptions*/ options)
            {
                super.$ctor$2($.$spu.System.GenericUriParser.MapGenericParserOptions(options));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295294978);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295294978)
            
            //--TRIMMABLE-BOUNDARY-START(12885229570)
            static /*UriSyntaxFlags */ MapGenericParserOptions(/*GenericUriParserOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*UriSyntaxFlags*/ let flags = 65015677/*DefaultGenericUriParserFlags*/;
                if ((options & 1/*GenericUriParserOptions.GenericAuthority*/) !== 0)
                {
                    flags &= ~(4/*UriSyntaxFlags.MayHaveUserInfo*/ | 8/*UriSyntaxFlags.MayHavePort*/ | 256/*UriSyntaxFlags.AllowUncHost*/ | 3584/*UriSyntaxFlags.AllowAnInternetHost*/);
                    flags |= 4096/*UriSyntaxFlags.AllowAnyOtherHost*/;
                }
                if ((options & 2/*GenericUriParserOptions.AllowEmptyAuthority*/) !== 0)
                {
                    flags |= 128/*UriSyntaxFlags.AllowEmptyHost*/;
                }
                if ((options & 4/*GenericUriParserOptions.NoUserInfo*/) !== 0)
                {
                    flags &= ~4/*UriSyntaxFlags.MayHaveUserInfo*/;
                }
                if ((options & 8/*GenericUriParserOptions.NoPort*/) !== 0)
                {
                    flags &= ~8/*UriSyntaxFlags.MayHavePort*/;
                }
                if ((options & 16/*GenericUriParserOptions.NoQuery*/) !== 0)
                {
                    flags &= ~32/*UriSyntaxFlags.MayHaveQuery*/;
                }
                if ((options & 32/*GenericUriParserOptions.NoFragment*/) !== 0)
                {
                    flags &= ~64/*UriSyntaxFlags.MayHaveFragment*/;
                }
                if ((options & 64/*GenericUriParserOptions.DontConvertPathBackslashes*/) !== 0)
                {
                    flags &= ~4194304/*UriSyntaxFlags.ConvertPathSlashes*/;
                }
                if ((options & 128/*GenericUriParserOptions.DontCompressPath*/) !== 0)
                {
                    flags &= ~(8388608/*UriSyntaxFlags.CompressPath*/ | 16777216/*UriSyntaxFlags.CanonicalizeAsFilePath*/);
                }
                if ((options & 256/*GenericUriParserOptions.DontUnescapePathDotsAndSlashes*/) !== 0)
                {
                    flags &= ~33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/;
                }
                if ((options & 512/*GenericUriParserOptions.Idn*/) !== 0)
                {
                    flags |= 67108864/*UriSyntaxFlags.AllowIdn*/;
                }
                if ((options & 1024/*GenericUriParserOptions.IriParsing*/) !== 0)
                {
                    flags |= 268435456/*UriSyntaxFlags.AllowIriParsing*/;
                }
                return flags;
            }
            //--TRIMMABLE-BOUNDARY-END(12885229570)
            
            //--TRIMMABLE-BOUNDARY-START(8590262274)
            /*UriSyntaxFlags*/ static DefaultGenericUriParserFlags = 65015677;
            //--TRIMMABLE-BOUNDARY-END(8590262274)
            
            static $h = 327682;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2621442,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885229570),
    {
      "r": 2818050,
      "p": [
        {
          "n": "options",
          "p": 393218
        }
      ],
      "n": "MapGenericParserOptions",
      "d": 327682,
      "h": 12885229570,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885229570)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590262274),
    {
      "t": 2818050,
      "n": "DefaultGenericUriParserFlags",
      "d": 327682,
      "h": 8590262274,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590262274)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295294978),
    {
      "p": [
        {
          "n": "options",
          "p": 393218
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327682,
      "h": 4295294978,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295294978)
  ],
  "h": 327682
}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.GenericUriParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327682)
        
        
        //--TRIMMABLE-BOUNDARY-START(196610)
        $asm.$cls("$spu.System.FileStyleUriParser", ($self) => class FileStyleUriParser extends $.$spu.System.UriParser
        {
            //--TRIMMABLE-BOUNDARY-START(4295163906)
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.FileUri.Flags);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295163906);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163906)
            
            static $h = 196610;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2621442,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163906),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196610,
      "h": 4295163906,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163906)
  ],
  "h": 196610
}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.FileStyleUriParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196610)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179650)
        $asm.$cls("$spu.System.NewsStyleUriParser", ($self) => class NewsStyleUriParser extends $.$spu.System.UriParser
        {
            //--TRIMMABLE-BOUNDARY-START(4296146946)
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.NewsUri.Flags);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296146946);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296146946)
            
            static $h = 1179650;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2621442,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296146946),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1179650,
      "h": 4296146946,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296146946)
  ],
  "h": 1179650
}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.NewsStyleUriParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179650)
        
        
        //--TRIMMABLE-BOUNDARY-START(458754)
        $asm.$cls("$spu.System.GopherStyleUriParser", ($self) => class GopherStyleUriParser extends $.$spu.System.UriParser
        {
            //--TRIMMABLE-BOUNDARY-START(4295426050)
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.GopherUri.Flags);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426050);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426050)
            
            static $h = 458754;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2621442,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426050),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458754,
      "h": 4295426050,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426050)
  ],
  "h": 458754
}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.GopherStyleUriParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458754)
        
        
        //--TRIMMABLE-BOUNDARY-START(851970)
        $asm.$cls("$spu.System.LdapStyleUriParser", ($self) => class LdapStyleUriParser extends $.$spu.System.UriParser
        {
            //--TRIMMABLE-BOUNDARY-START(4295819266)
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.LdapUri.Flags);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295819266);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295819266)
            
            static $h = 851970;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2621442,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819266),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 851970,
      "h": 4295819266,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819266)
  ],
  "h": 851970
}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.LdapStyleUriParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(851970)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048578)
        $asm.$cls("$spu.System.NetPipeStyleUriParser", ($self) => class NetPipeStyleUriParser extends $.$spu.System.UriParser
        {
            //--TRIMMABLE-BOUNDARY-START(4296015874)
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.NetPipeUri.Flags);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296015874);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296015874)
            
            static $h = 1048578;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2621442,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015874),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1048578,
      "h": 4296015874,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015874)
  ],
  "h": 1048578
}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.NetPipeStyleUriParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048578)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507330)
        $asm.$str("$spu.System.Text.ValueStringBuilder", ($self) => class ValueStringBuilder extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(47246147586)
            /*void */ Append$4(/*Rune*/ rune)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246147586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if (((((pos + 1) | 0)) >>> 0) < (chars.Length >>> 0) && (pos >>> 0) < (chars.Length >>> 0))
                {
                    if (rune.Value <= 65535)
                    {
                        chars.get_Item(pos).$v = $.$cast(rune.Value, $.$$.System.Char);
                        this._pos = ((pos + 1) | 0);
                    }
                    else 
                    {
                        chars.get_Item(pos).$v = $.$cast(((BigInt(rune.Value) + (BigInt(((((55296 - 64) >>> 0)) << 10) >>> 0))) >> 10n), $.$$.System.Char);
                        chars.get_Item(((pos + 1) | 0)).$v = $.$cast(((BigInt(rune.Value) & 1023n) + 56320n), $.$$.System.Char);
                        this._pos = ((pos + 2) | 0);
                    }
                }
                else 
                {
                    this.GrowAndAppend$1(rune);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246147586)
            
            //--TRIMMABLE-BOUNDARY-START(141735428098)
            /*void */ GrowAndAppend$1(/*Rune*/ rune)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735428098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (rune.Value <= 65535)
                {
                    this.Append$1($.$cast(rune.Value, $.$$.System.Char));
                }
                else 
                {
                    this.Grow(2);
                    this.Append$4(rune);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141735428098)
            
            //--TRIMMABLE-BOUNDARY-START(4296474626)
            /*char[]?*/  get _arrayToReturnToPool() { return this.$getField(0, 4); }
            /*char[]?*/  set _arrayToReturnToPool(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4296474626)
            
            //--TRIMMABLE-BOUNDARY-START(8591441922)
            /*Span<char>*/  get _chars() { return this.$getField(4, 6); }
            /*Span<char>*/  set _chars(value) { this.$setField(4, 6, value); }
            //--TRIMMABLE-BOUNDARY-END(8591441922)
            
            //--TRIMMABLE-BOUNDARY-START(12886409218)
            /*int*/  get _pos() { return this.$getField(10, 4); }
            /*int*/  set _pos(value) { this.$setField(10, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12886409218)
            
            //--TRIMMABLE-BOUNDARY-START(25771311106)
            $ctor$4(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771311106);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771311106)
            
            //--TRIMMABLE-BOUNDARY-START(21476343810)
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476343810);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arrayToReturnToPool = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476343810)
            
            //--TRIMMABLE-BOUNDARY-START(154620329986)
            /*int */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670657026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._pos;
            }
            /*int */ set Length(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505231874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(value >= 0, "value >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            //--TRIMMABLE-BOUNDARY-END(154620329986)
            
            //--TRIMMABLE-BOUNDARY-START(77310918658)
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(77310918658)
            
            //--TRIMMABLE-BOUNDARY-START(85900853250)
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900853250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900853250)
            
            //--TRIMMABLE-BOUNDARY-START(124555558914)
            /*ref char */ GetPinnableReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555558914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, this._chars);
            }
            //--TRIMMABLE-BOUNDARY-END(124555558914)
            
            //--TRIMMABLE-BOUNDARY-START(128850526210)
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850526210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, this._chars);
            }
            //--TRIMMABLE-BOUNDARY-END(128850526210)
            
            //--TRIMMABLE-BOUNDARY-START(171800199170)
            /*ref char*/ get_Item$1(/*int*/ index)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            //--TRIMMABLE-BOUNDARY-END(171800199170)
            
            //--TRIMMABLE-BOUNDARY-START(176095166466)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095166466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let s = $.$$.System.Span$$($.$$.System.Char).ToString.call(this._chars.Slice(0, this._pos));
                this.Dispose();
                return s;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spu.System.Text.ValueStringBuilder.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(176095166466)
            
            //--TRIMMABLE-BOUNDARY-START(158915297282)
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            //--TRIMMABLE-BOUNDARY-END(158915297282)
            
            //--TRIMMABLE-BOUNDARY-START(64426016770)
            /*ReadOnlySpan<char> */ AsSpan$1(/*bool*/ terminate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426016770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(0, this._pos));
            }
            //--TRIMMABLE-BOUNDARY-END(64426016770)
            
            //--TRIMMABLE-BOUNDARY-START(60131049474)
            /*ReadOnlySpan<char> */ AsSpan()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131049474);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(0, this._pos));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131049474)
            
            //--TRIMMABLE-BOUNDARY-START(73015951362)
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015951362);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(start, ((this._pos - start) | 0)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015951362)
            
            //--TRIMMABLE-BOUNDARY-START(68720984066)
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start, /*int*/ length)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720984066);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(start, length));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720984066)
            
            //--TRIMMABLE-BOUNDARY-START(180390133762)
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390133762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._chars.Slice(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180390133762)
            
            //--TRIMMABLE-BOUNDARY-START(146030395394)
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030395394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                this._chars.Slice(index, count).Fill(value);
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(146030395394)
            
            //--TRIMMABLE-BOUNDARY-START(150325362690)
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325362690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                $.$$.System.String.CopyTo$1.call(s, this._chars.Slice$1(index));
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(150325362690)
            
            //--TRIMMABLE-BOUNDARY-START(34361245698)
            /*void */ Append$1(/*char*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361245698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars.get_Item(pos).$v = c;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend(c);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361245698)
            
            //--TRIMMABLE-BOUNDARY-START(42951180290)
            /*void */ Append$3(/*string?*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951180290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars.get_Item(pos).$v = $.$$.System.String.get_Chars.call(s, 0);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951180290)
            
            //--TRIMMABLE-BOUNDARY-START(51541114882)
            /*void */ AppendSlow(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541114882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$$.System.String.CopyTo$1.call(s, this._chars.Slice$1(pos));
                this._pos += s.length;
            }
            //--TRIMMABLE-BOUNDARY-END(51541114882)
            
            //--TRIMMABLE-BOUNDARY-START(30066278402)
            /*void */ Append(/*char*/ c, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066278402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst.get_Item(i).$v = c;
                }
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(30066278402)
            
            //--TRIMMABLE-BOUNDARY-START(38656212994)
            /*void */ Append$2(/*scoped ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656212994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice$1(this._pos));
                this._pos += value.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(38656212994)
            
            //--TRIMMABLE-BOUNDARY-START(55836082178)
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836082178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice(origPos, length);
            }
            //--TRIMMABLE-BOUNDARY-END(55836082178)
            
            //--TRIMMABLE-BOUNDARY-START(137440460802)
            /*void */ GrowAndAppend(/*char*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440460802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Grow(1);
                this.Append$1(c);
            }
            //--TRIMMABLE-BOUNDARY-END(137440460802)
            
            //--TRIMMABLE-BOUNDARY-START(133145493506)
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145493506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$$.System.Diagnostics.Debug.Assert$2(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$$.System.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$$.System.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(newCapacity);
                this._chars.Slice(0, this._pos).CopyTo($.$$.System.Span$$($.$$.System.Char).op_Implicit$2(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133145493506)
            
            //--TRIMMABLE-BOUNDARY-START(81605885954)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605885954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$spu.System.Text.ValueStringBuilder().Clone(this);
                if (toReturn !== null)
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605885954)
            
            //--TRIMMABLE-BOUNDARY-START(17181376514)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181376514)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.Clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296474626)
                this._arrayToReturnToPool = null;
                //--TRIMMABLE-BOUNDARY-END(4296474626)
                
                //--TRIMMABLE-BOUNDARY-START(8591441922)
                this._chars = $.$default($.$$.System.Span$$($.$$.System.Char));
                //--TRIMMABLE-BOUNDARY-END(8591441922)
                
                //--TRIMMABLE-BOUNDARY-START(12886409218)
                this._pos = 0;
                //--TRIMMABLE-BOUNDARY-END(12886409218)
                
            }
            static $h = 1507330;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(154620329986),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670657026,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505231874,
        "f": 83886081
      },
      "n": "Length",
      "d": 1507330,
      "h": 154620329986,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154620329986),
//--TRIMMABLE-BOUNDARY-START(77310918658),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490787842,
        "f": 50331649
      },
      "n": "Capacity",
      "d": 1507330,
      "h": 77310918658,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310918658),
//--TRIMMABLE-BOUNDARY-START(171800199170),
    {
      "p": 458753,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080722434,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 1507330,
      "h": 171800199170,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171800199170),
//--TRIMMABLE-BOUNDARY-START(158915297282),
    {
      "p": $.$$.System.Span$$($.$$.System.Char).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260591618,
        "f": 50331649
      },
      "n": "RawChars",
      "d": 1507330,
      "h": 158915297282,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158915297282)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246147586),
    {
      "r": 65537,
      "p": [
        {
          "n": "rune",
          "p": 166854657
        }
      ],
      "n": "Append",
      "o": "@$4",
      "d": 1507330,
      "h": 47246147586,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246147586),
//--TRIMMABLE-BOUNDARY-START(141735428098),
    {
      "r": 65537,
      "p": [
        {
          "n": "rune",
          "p": 166854657
        }
      ],
      "n": "GrowAndAppend",
      "o": "@$1",
      "d": 1507330,
      "h": 141735428098,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141735428098),
//--TRIMMABLE-BOUNDARY-START(85900853250),
    {
      "r": 65537,
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": "EnsureCapacity",
      "d": 1507330,
      "h": 85900853250,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900853250),
//--TRIMMABLE-BOUNDARY-START(124555558914),
    {
      "r": 458753,
      "n": "GetPinnableReference",
      "d": 1507330,
      "h": 124555558914,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124555558914),
//--TRIMMABLE-BOUNDARY-START(128850526210),
    {
      "r": 458753,
      "p": [
        {
          "n": "terminate",
          "p": 262145
        }
      ],
      "n": "GetPinnableReference",
      "o": "@$1",
      "d": 1507330,
      "h": 128850526210,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128850526210),
//--TRIMMABLE-BOUNDARY-START(176095166466),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1507330,
      "h": 176095166466,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176095166466),
//--TRIMMABLE-BOUNDARY-START(64426016770),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "terminate",
          "p": 262145
        }
      ],
      "n": "AsSpan",
      "o": "@$1",
      "d": 1507330,
      "h": 64426016770,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426016770),
//--TRIMMABLE-BOUNDARY-START(60131049474),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "n": "AsSpan",
      "d": 1507330,
      "h": 60131049474,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131049474),
//--TRIMMABLE-BOUNDARY-START(73015951362),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        }
      ],
      "n": "AsSpan",
      "o": "@$3",
      "d": 1507330,
      "h": 73015951362,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015951362),
//--TRIMMABLE-BOUNDARY-START(68720984066),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "AsSpan",
      "o": "@$2",
      "d": 1507330,
      "h": 68720984066,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720984066),
//--TRIMMABLE-BOUNDARY-START(180390133762),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryCopyTo",
      "d": 1507330,
      "h": 180390133762,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180390133762),
//--TRIMMABLE-BOUNDARY-START(146030395394),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 458753
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Insert",
      "d": 1507330,
      "h": 146030395394,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146030395394),
//--TRIMMABLE-BOUNDARY-START(150325362690),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "Insert",
      "o": "@$1",
      "d": 1507330,
      "h": 150325362690,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150325362690),
//--TRIMMABLE-BOUNDARY-START(34361245698),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "Append",
      "o": "@$1",
      "d": 1507330,
      "h": 34361245698,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361245698),
//--TRIMMABLE-BOUNDARY-START(42951180290),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "Append",
      "o": "@$3",
      "d": 1507330,
      "h": 42951180290,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951180290),
//--TRIMMABLE-BOUNDARY-START(51541114882),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "AppendSlow",
      "d": 1507330,
      "h": 51541114882,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51541114882),
//--TRIMMABLE-BOUNDARY-START(30066278402),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Append",
      "d": 1507330,
      "h": 30066278402,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066278402),
//--TRIMMABLE-BOUNDARY-START(38656212994),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": 1507330,
      "h": 38656212994,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656212994),
//--TRIMMABLE-BOUNDARY-START(55836082178),
    {
      "r": $.$$.System.Span$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "AppendSpan",
      "d": 1507330,
      "h": 55836082178,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836082178),
//--TRIMMABLE-BOUNDARY-START(137440460802),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "GrowAndAppend",
      "d": 1507330,
      "h": 137440460802,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137440460802),
//--TRIMMABLE-BOUNDARY-START(133145493506),
    {
      "r": 65537,
      "p": [
        {
          "n": "additionalCapacityBeyondPos",
          "p": 655361
        }
      ],
      "n": "Grow",
      "d": 1507330,
      "h": 133145493506,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133145493506),
//--TRIMMABLE-BOUNDARY-START(81605885954),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1507330,
      "h": 81605885954,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605885954)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296474626),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "_arrayToReturnToPool",
      "d": 1507330,
      "h": 4296474626,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474626),
//--TRIMMABLE-BOUNDARY-START(8591441922),
    {
      "t": $.$$.System.Span$$($.$$.System.Char).$h,
      "n": "_chars",
      "d": 1507330,
      "h": 8591441922,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591441922),
//--TRIMMABLE-BOUNDARY-START(12886409218),
    {
      "t": 655361,
      "n": "_pos",
      "d": 1507330,
      "h": 12886409218,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886409218)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771311106),
    {
      "p": [
        {
          "n": "initialBuffer",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1507330,
      "h": 25771311106,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771311106),
//--TRIMMABLE-BOUNDARY-START(21476343810),
    {
      "p": [
        {
          "n": "initialCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1507330,
      "h": 21476343810,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476343810),
//--TRIMMABLE-BOUNDARY-START(17181376514),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1507330,
      "h": 17181376514,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181376514)
  ],
  "h": 1507330
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Text.ValueStringBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507330)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114114)
        $asm.$cls("$spu.System.NetTcpStyleUriParser", ($self) => class NetTcpStyleUriParser extends $.$spu.System.UriParser
        {
            //--TRIMMABLE-BOUNDARY-START(4296081410)
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.NetTcpUri.Flags);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296081410);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296081410)
            
            static $h = 1114114;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2621442,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081410),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1114114,
      "h": 4296081410,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296081410)
  ],
  "h": 1114114
}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.NetTcpStyleUriParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114114)
        
        
        //--TRIMMABLE-BOUNDARY-START(65538)
        $asm.$str("$spu.System.Collections.Generic.ValueListBuilder<>", (T) => $asm.$gt("$spu.System.Collections.Generic.ValueListBuilder<>", [T], ($self) => class ValueListBuilder$$ extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12884967426)
            /*Span<T>*/  get _span() { return this.$getField(0, 8); }
            /*Span<T>*/  set _span(value) { this.$setField(0, 8, value); }
            //--TRIMMABLE-BOUNDARY-END(12884967426)
            
            //--TRIMMABLE-BOUNDARY-START(4295032834)
            /*T[]?*/  get _arrayFromPool() { return this.$getField(8, 4); }
            /*T[]?*/  set _arrayFromPool(value) { this.$setField(8, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4295032834)
            
            //--TRIMMABLE-BOUNDARY-START(8590000130)
            /*int*/  get _pos() { return this.$getField(12, 4); }
            /*int*/  set _pos(value) { this.$setField(12, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8590000130)
            
            //--TRIMMABLE-BOUNDARY-START(25769869314)
            $ctor$4(/*Span<T?>*/ scratchBuffer)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769869314);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._span = scratchBuffer;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25769869314)
            
            //--TRIMMABLE-BOUNDARY-START(21474902018)
            $ctor$3(/*int*/ capacity)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21474902018);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Grow(capacity);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902018)
            
            //--TRIMMABLE-BOUNDARY-START(90194378754)
            /*int */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309476866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._pos;
            }
            /*int */ set Length(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784313346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(value >= 0, "value >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(value <= this._span.Length, "value <= _span.Length");
                this._pos = value;
            }
            //--TRIMMABLE-BOUNDARY-END(90194378754)
            
            //--TRIMMABLE-BOUNDARY-START(103079280642)
            /*ref T*/ get_Item$1(/*int*/ index)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(index < this._pos, "index < _pos");
                return this._span.get_Item(index);
            }
            //--TRIMMABLE-BOUNDARY-END(103079280642)
            
            //--TRIMMABLE-BOUNDARY-START(38654771202)
            /*void */ Append$1(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                /*Span<T>*/ let span = this._span;
                if ((pos >>> 0) < (span.Length >>> 0))
                {
                    span.get_Item(pos).$v = item;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AddWithResize(item);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654771202)
            
            //--TRIMMABLE-BOUNDARY-START(34359803906)
            /*void */ Append(/*scoped ReadOnlySpan<T>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                /*Span<T>*/ let span = this._span;
                if (source.Length === 1 && (pos >>> 0) < (span.Length >>> 0))
                {
                    span.get_Item(pos).$v = source.get_Item(0).$v;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendMultiChar(source);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359803906)
            
            //--TRIMMABLE-BOUNDARY-START(42949738498)
            /*void */ AppendMultiChar(/*scoped ReadOnlySpan<T>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949738498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((((this._pos + source.Length) | 0)) >>> 0) > (this._span.Length >>> 0))
                {
                    this.Grow(((((this._span.Length - this._pos) | 0) + source.Length) | 0));
                }
                source.CopyTo(this._span.Slice$1(this._pos));
                this._pos += source.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(42949738498)
            
            //--TRIMMABLE-BOUNDARY-START(85899411458)
            /*void */ Insert(/*int*/ index, /*scoped ReadOnlySpan<T>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899411458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(index === 0, "Implementation currently only supports index == 0");
                if (((((this._pos + source.Length) | 0)) >>> 0) > (this._span.Length >>> 0))
                {
                    this.Grow(source.Length);
                }
                this._span.Slice(0, this._pos).CopyTo(this._span.Slice$1(source.Length));
                source.CopyTo(this._span);
                this._pos += source.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(85899411458)
            
            //--TRIMMABLE-BOUNDARY-START(47244705794)
            /*Span<T> */ AppendSpan(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(length >= 0, "length >= 0");
                /*int*/ let pos = this._pos;
                /*Span<T>*/ let span = this._span;
                if ($.$cast((pos >>> 0), $.$$.System.UInt64) + $.$cast((length >>> 0), $.$$.System.UInt64) <= $.$cast((span.Length >>> 0), $.$$.System.UInt64))
                {
                    this._pos = ((pos + length) | 0);
                    return span.Slice(pos, length);
                }
                else 
                {
                    return this.AppendSpanWithGrow(length);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244705794)
            
            //--TRIMMABLE-BOUNDARY-START(51539673090)
            /*Span<T> */ AppendSpanWithGrow(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                this.Grow(((((this._span.Length - pos) | 0) + length) | 0));
                this._pos += length;
                return this._span.Slice(pos, length);
            }
            //--TRIMMABLE-BOUNDARY-END(51539673090)
            
            //--TRIMMABLE-BOUNDARY-START(30064836610)
            /*void */ AddWithResize(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._pos === this._span.Length, "_pos == _span.Length");
                /*int*/ let pos = this._pos;
                this.Grow(1);
                this._span.get_Item(pos).$v = item;
                this._pos = ((pos + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(30064836610)
            
            //--TRIMMABLE-BOUNDARY-START(55834640386)
            /*ReadOnlySpan<T> */ AsSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834640386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Span$$(T).op_Implicit(this._span.Slice(0, this._pos));
            }
            //--TRIMMABLE-BOUNDARY-END(55834640386)
            
            //--TRIMMABLE-BOUNDARY-START(107374247938)
            /*bool */ TryCopyTo(/*Span<T>*/ destination, /*out int*/ itemsWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374247938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._span.Slice(0, this._pos).TryCopyTo(destination))
                {
                    itemsWritten.$v = this._pos;
                    return true;
                }
                itemsWritten.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(107374247938)
            
            //--TRIMMABLE-BOUNDARY-START(60129607682)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129607682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*T[]?*/ let toReturn = this._arrayFromPool;
                if (toReturn !== null)
                {
                    this._arrayFromPool = null;
                    if (!T.$type.IsPrimitive)
                    {
                        $.$$.System.Array.Clear(toReturn, 0, this._pos);
                    }
                    $.$$.System.Buffers.ArrayPool$$(T).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129607682)
            
            //--TRIMMABLE-BOUNDARY-START(81604444162)
            /*void */ Grow(/*int*/ additionalCapacityRequired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604444162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let ArrayMaxLength = 2147483591;
                /*int*/ let nextCapacity = $.$$.System.Math.Max$4(this._span.Length !== 0 ? ((this._span.Length * 2) | 0) : 4, ((this._span.Length + additionalCapacityRequired) | 0));
                if ((nextCapacity >>> 0) > ArrayMaxLength)
                {
                    nextCapacity = $.$$.System.Math.Max$4($.$$.System.Math.Max$4(((this._span.Length + 1) | 0), ArrayMaxLength), this._span.Length);
                }
                /*T[]*/ let array = $.$$.System.Buffers.ArrayPool$$(T).Shared.Rent(nextCapacity);
                this._span.CopyTo($.$$.System.Span$$(T).op_Implicit$2(array));
                /*T[]?*/ let toReturn = this._arrayFromPool;
                this._span = $.$$.System.Span$$(T).op_Implicit$2(this._arrayFromPool = array);
                if (toReturn !== null)
                {
                    if (!T.$type.IsPrimitive)
                    {
                        $.$$.System.Array.Clear(toReturn, 0, this._pos);
                    }
                    $.$$.System.Buffers.ArrayPool$$(T).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604444162)
            
            //--TRIMMABLE-BOUNDARY-START(17179934722)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17179934722)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._span = this._span.Clone();
                copy._arrayFromPool = this._arrayFromPool;
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12884967426)
                this._span = $.$default($.$$.System.Span$$(T));
                //--TRIMMABLE-BOUNDARY-END(12884967426)
                
                //--TRIMMABLE-BOUNDARY-START(4295032834)
                this._arrayFromPool = null;
                //--TRIMMABLE-BOUNDARY-END(4295032834)
                
                //--TRIMMABLE-BOUNDARY-START(8590000130)
                this._pos = 0;
                //--TRIMMABLE-BOUNDARY-END(8590000130)
                
            }
            static $h = 65538;
            static $g = 1;
            static $z = 16;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(90194378754),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 83886081
      },
      "n": "Length",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194378754),
//--TRIMMABLE-BOUNDARY-START(103079280642),
    {
      "p": T?.$h??1507328,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079280642)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38654771202),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "Append",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654771202),
//--TRIMMABLE-BOUNDARY-START(34359803906),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        }
      ],
      "n": "Append",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359803906),
//--TRIMMABLE-BOUNDARY-START(42949738498),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        }
      ],
      "n": "AppendMultiChar",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42949738498),
//--TRIMMABLE-BOUNDARY-START(85899411458),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        }
      ],
      "n": "Insert",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899411458),
//--TRIMMABLE-BOUNDARY-START(47244705794),
    {
      "r": $.$$.System.Span$$(T).$h,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "AppendSpan",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244705794),
//--TRIMMABLE-BOUNDARY-START(51539673090),
    {
      "r": $.$$.System.Span$$(T).$h,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "AppendSpanWithGrow",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51539673090),
//--TRIMMABLE-BOUNDARY-START(30064836610),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1507328
        }
      ],
      "n": "AddWithResize",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30064836610),
//--TRIMMABLE-BOUNDARY-START(55834640386),
    {
      "r": $.$$.System.ReadOnlySpan$$(T).$h,
      "n": "AsSpan",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834640386),
//--TRIMMABLE-BOUNDARY-START(107374247938),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$(T).$h
        },
        {
          "n": "itemsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryCopyTo",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374247938),
//--TRIMMABLE-BOUNDARY-START(60129607682),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129607682),
//--TRIMMABLE-BOUNDARY-START(81604444162),
    {
      "r": 65537,
      "p": [
        {
          "n": "additionalCapacityRequired",
          "p": 655361,
          "f": 65,
          "v": 1
        }
      ],
      "n": "Grow",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81604444162)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12884967426),
    {
      "t": $.$$.System.Span$$(T).$h,
      "n": "_span",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12884967426),
//--TRIMMABLE-BOUNDARY-START(4295032834),
    {
      "t": $.$typeArray(T).$h,
      "n": "_arrayFromPool",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032834),
//--TRIMMABLE-BOUNDARY-START(8590000130),
    {
      "t": 655361,
      "n": "_pos",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590000130)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25769869314),
    {
      "p": [
        {
          "n": "scratchBuffer",
          "p": $.$$.System.Span$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769869314),
//--TRIMMABLE-BOUNDARY-START(21474902018),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474902018),
//--TRIMMABLE-BOUNDARY-START(17179934722),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179934722)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Collections.Generic.ValueListBuilder<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(65538)
        
        
        //--TRIMMABLE-BOUNDARY-START(2752514)
        $asm.$str("$spu.System.UriPartial", ($self) => class UriPartial extends $.$$.System.Enum
        {
            static Scheme = 0;
            static Authority = 1;
            static Path = 2;
            static Query = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2752514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Scheme": 0n,
                    "Authority": 1n,
                    "Path": 2n,
                    "Query": 3n
                };
            }
            static $h = 2752514;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21477588994),
    {
      "t": 2752514,
      "n": "Scheme",
      "d": 2752514,
      "h": 21477588994,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477588994),
//--TRIMMABLE-BOUNDARY-START(8592687106),
    {
      "t": 2752514,
      "n": "Authority",
      "d": 2752514,
      "h": 8592687106,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592687106),
//--TRIMMABLE-BOUNDARY-START(12887654402),
    {
      "t": 2752514,
      "n": "Path",
      "d": 2752514,
      "h": 12887654402,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887654402),
//--TRIMMABLE-BOUNDARY-START(17182621698),
    {
      "t": 2752514,
      "n": "Query",
      "d": 2752514,
      "h": 17182621698,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182621698)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297719810),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2752514,
      "h": 4297719810,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297719810)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 2752514
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.UriPartial`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752514)
        
        
        //--TRIMMABLE-BOUNDARY-START(393218)
        $asm.$str("$spu.System.GenericUriParserOptions", ($self) => class GenericUriParserOptions extends $.$$.System.Enum
        {
            static Default = 0;
            static GenericAuthority = 1;
            static AllowEmptyAuthority = 2;
            static NoUserInfo = 4;
            static NoPort = 8;
            static NoQuery = 16;
            static NoFragment = 32;
            static DontConvertPathBackslashes = 64;
            static DontCompressPath = 128;
            static DontUnescapePathDotsAndSlashes = 256;
            static Idn = 512;
            static IriParsing = 1024;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(393218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Default": 0n,
                    "GenericAuthority": 1n,
                    "AllowEmptyAuthority": 2n,
                    "NoUserInfo": 4n,
                    "NoPort": 8n,
                    "NoQuery": 16n,
                    "NoFragment": 32n,
                    "DontConvertPathBackslashes": 64n,
                    "DontCompressPath": 128n,
                    "DontUnescapePathDotsAndSlashes": 256n,
                    "Idn": 512n,
                    "IriParsing": 1024n
                };
            }
            static $h = 393218;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885295106),
    {
      "t": 393218,
      "n": "Default",
      "d": 393218,
      "h": 12885295106,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885295106),
//--TRIMMABLE-BOUNDARY-START(30065164290),
    {
      "t": 393218,
      "n": "GenericAuthority",
      "d": 393218,
      "h": 30065164290,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065164290),
//--TRIMMABLE-BOUNDARY-START(8590327810),
    {
      "t": 393218,
      "n": "AllowEmptyAuthority",
      "d": 393218,
      "h": 8590327810,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590327810),
//--TRIMMABLE-BOUNDARY-START(55834968066),
    {
      "t": 393218,
      "n": "NoUserInfo",
      "d": 393218,
      "h": 55834968066,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834968066),
//--TRIMMABLE-BOUNDARY-START(47245033474),
    {
      "t": 393218,
      "n": "NoPort",
      "d": 393218,
      "h": 47245033474,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245033474),
//--TRIMMABLE-BOUNDARY-START(51540000770),
    {
      "t": 393218,
      "n": "NoQuery",
      "d": 393218,
      "h": 51540000770,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540000770),
//--TRIMMABLE-BOUNDARY-START(42950066178),
    {
      "t": 393218,
      "n": "NoFragment",
      "d": 393218,
      "h": 42950066178,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950066178),
//--TRIMMABLE-BOUNDARY-START(21475229698),
    {
      "t": 393218,
      "n": "DontConvertPathBackslashes",
      "d": 393218,
      "h": 21475229698,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475229698),
//--TRIMMABLE-BOUNDARY-START(17180262402),
    {
      "t": 393218,
      "n": "DontCompressPath",
      "d": 393218,
      "h": 17180262402,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180262402),
//--TRIMMABLE-BOUNDARY-START(25770196994),
    {
      "t": 393218,
      "n": "DontUnescapePathDotsAndSlashes",
      "d": 393218,
      "h": 25770196994,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770196994),
//--TRIMMABLE-BOUNDARY-START(34360131586),
    {
      "t": 393218,
      "n": "Idn",
      "d": 393218,
      "h": 34360131586,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360131586),
//--TRIMMABLE-BOUNDARY-START(38655098882),
    {
      "t": 393218,
      "n": "IriParsing",
      "d": 393218,
      "h": 38655098882,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655098882)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360514),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393218,
      "h": 4295360514,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360514)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 393218,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.GenericUriParserOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393218)
        
        
        //--TRIMMABLE-BOUNDARY-START(2490370)
        $asm.$str("$spu.System.UriHostNameType", ($self) => class UriHostNameType extends $.$$.System.Enum
        {
            static Unknown = 0;
            static Basic = 1;
            static Dns = 2;
            static IPv4 = 3;
            static IPv6 = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2490370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Basic": 1n,
                    "Dns": 2n,
                    "IPv4": 3n,
                    "IPv6": 4n
                };
            }
            static $h = 2490370;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25772294146),
    {
      "t": 2490370,
      "n": "Unknown",
      "d": 2490370,
      "h": 25772294146,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772294146),
//--TRIMMABLE-BOUNDARY-START(8592424962),
    {
      "t": 2490370,
      "n": "Basic",
      "d": 2490370,
      "h": 8592424962,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592424962),
//--TRIMMABLE-BOUNDARY-START(12887392258),
    {
      "t": 2490370,
      "n": "Dns",
      "d": 2490370,
      "h": 12887392258,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887392258),
//--TRIMMABLE-BOUNDARY-START(17182359554),
    {
      "t": 2490370,
      "n": "IPv4",
      "d": 2490370,
      "h": 17182359554,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182359554),
//--TRIMMABLE-BOUNDARY-START(21477326850),
    {
      "t": 2490370,
      "n": "IPv6",
      "d": 2490370,
      "h": 21477326850,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477326850)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297457666),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2490370,
      "h": 4297457666,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297457666)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 2490370
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.UriHostNameType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490370)
        
        
        //--TRIMMABLE-BOUNDARY-START(2555906)
        $asm.$str("$spu.System.UriKind", ($self) => class UriKind extends $.$$.System.Enum
        {
            static RelativeOrAbsolute = 0;
            static Absolute = 1;
            static Relative = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2555906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "RelativeOrAbsolute": 0n,
                    "Absolute": 1n,
                    "Relative": 2n
                };
            }
            static $h = 2555906;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182425090),
    {
      "t": 2555906,
      "n": "RelativeOrAbsolute",
      "d": 2555906,
      "h": 17182425090,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182425090),
//--TRIMMABLE-BOUNDARY-START(8592490498),
    {
      "t": 2555906,
      "n": "Absolute",
      "d": 2555906,
      "h": 8592490498,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592490498),
//--TRIMMABLE-BOUNDARY-START(12887457794),
    {
      "t": 2555906,
      "n": "Relative",
      "d": 2555906,
      "h": 12887457794,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887457794)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297523202),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2555906,
      "h": 4297523202,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297523202)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 2555906
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.UriKind`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2555906)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162690)
        $asm.$str("$spu.System.UriComponents", ($self) => class UriComponents extends $.$$.System.Enum
        {
            static Scheme = 1;
            static UserInfo = 2;
            static Host = 4;
            static Port = 8;
            static Path = 16;
            static Query = 32;
            static Fragment = 64;
            static StrongPort = 128;
            static NormalizedHost = 256;
            static KeepDelimiter = 1073741824;
            static SerializationInfoString = -2147483648;
            static AbsoluteUri = 127;
            static HostAndPort = 132;
            static StrongAuthority = 134;
            static SchemeAndServer = 13;
            static HttpRequestUrl = 61;
            static PathAndQuery = 48;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2162690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Scheme": 1n,
                    "UserInfo": 2n,
                    "Host": 4n,
                    "Port": 8n,
                    "Path": 16n,
                    "Query": 32n,
                    "Fragment": 64n,
                    "StrongPort": 128n,
                    "NormalizedHost": 256n,
                    "KeepDelimiter": 1073741824n,
                    "SerializationInfoString": -2147483648n,
                    "AbsoluteUri": 127n,
                    "HostAndPort": 132n,
                    "StrongAuthority": 134n,
                    "SchemeAndServer": 13n,
                    "HttpRequestUrl": 61n,
                    "PathAndQuery": 48n
                };
            }
            static $h = 2162690;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(55836737538),
    {
      "t": 2162690,
      "n": "Scheme",
      "d": 2162690,
      "h": 55836737538,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836737538),
//--TRIMMABLE-BOUNDARY-START(77311574018),
    {
      "t": 2162690,
      "n": "UserInfo",
      "d": 2162690,
      "h": 77311574018,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77311574018),
//--TRIMMABLE-BOUNDARY-START(17182031874),
    {
      "t": 2162690,
      "n": "Host",
      "d": 2162690,
      "h": 17182031874,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182031874),
//--TRIMMABLE-BOUNDARY-START(47246802946),
    {
      "t": 2162690,
      "n": "Port",
      "d": 2162690,
      "h": 47246802946,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246802946),
//--TRIMMABLE-BOUNDARY-START(38656868354),
    {
      "t": 2162690,
      "n": "Path",
      "d": 2162690,
      "h": 38656868354,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656868354),
//--TRIMMABLE-BOUNDARY-START(51541770242),
    {
      "t": 2162690,
      "n": "Query",
      "d": 2162690,
      "h": 51541770242,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541770242),
//--TRIMMABLE-BOUNDARY-START(12887064578),
    {
      "t": 2162690,
      "n": "Fragment",
      "d": 2162690,
      "h": 12887064578,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887064578),
//--TRIMMABLE-BOUNDARY-START(73016606722),
    {
      "t": 2162690,
      "n": "StrongPort",
      "d": 2162690,
      "h": 73016606722,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73016606722),
//--TRIMMABLE-BOUNDARY-START(34361901058),
    {
      "t": 2162690,
      "n": "NormalizedHost",
      "d": 2162690,
      "h": 34361901058,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361901058),
//--TRIMMABLE-BOUNDARY-START(30066933762),
    {
      "t": 2162690,
      "n": "KeepDelimiter",
      "d": 2162690,
      "h": 30066933762,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066933762),
//--TRIMMABLE-BOUNDARY-START(64426672130),
    {
      "t": 2162690,
      "n": "SerializationInfoString",
      "d": 2162690,
      "h": 64426672130,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64426672130),
//--TRIMMABLE-BOUNDARY-START(8592097282),
    {
      "t": 2162690,
      "n": "AbsoluteUri",
      "d": 2162690,
      "h": 8592097282,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592097282),
//--TRIMMABLE-BOUNDARY-START(21476999170),
    {
      "t": 2162690,
      "n": "HostAndPort",
      "d": 2162690,
      "h": 21476999170,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476999170),
//--TRIMMABLE-BOUNDARY-START(68721639426),
    {
      "t": 2162690,
      "n": "StrongAuthority",
      "d": 2162690,
      "h": 68721639426,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68721639426),
//--TRIMMABLE-BOUNDARY-START(60131704834),
    {
      "t": 2162690,
      "n": "SchemeAndServer",
      "d": 2162690,
      "h": 60131704834,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60131704834),
//--TRIMMABLE-BOUNDARY-START(25771966466),
    {
      "t": 2162690,
      "n": "HttpRequestUrl",
      "d": 2162690,
      "h": 25771966466,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771966466),
//--TRIMMABLE-BOUNDARY-START(42951835650),
    {
      "t": 2162690,
      "n": "PathAndQuery",
      "d": 2162690,
      "h": 42951835650,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951835650)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297129986),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2162690,
      "h": 4297129986,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297129986)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 2162690,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.UriComponents`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162690)
        
        
        //--TRIMMABLE-BOUNDARY-START(2293762)
        $asm.$str("$spu.System.UriFormat", ($self) => class UriFormat extends $.$$.System.Enum
        {
            static UriEscaped = 1;
            static Unescaped = 2;
            static SafeUnescaped = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2293762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "UriEscaped": 1n,
                    "Unescaped": 2n,
                    "SafeUnescaped": 3n
                };
            }
            static $h = 2293762;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182162946),
    {
      "t": 2293762,
      "n": "UriEscaped",
      "d": 2293762,
      "h": 17182162946,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182162946),
//--TRIMMABLE-BOUNDARY-START(12887195650),
    {
      "t": 2293762,
      "n": "Unescaped",
      "d": 2293762,
      "h": 12887195650,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887195650),
//--TRIMMABLE-BOUNDARY-START(8592228354),
    {
      "t": 2293762,
      "n": "SafeUnescaped",
      "d": 2293762,
      "h": 8592228354,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592228354)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297261058),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2293762,
      "h": 4297261058,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297261058)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 2293762
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.UriFormat`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293762)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310722)
        $asm.$str("$spu.System.ParsingError", ($self) => class ParsingError extends $.$$.System.Enum
        {
            static None = 0;
            static BadFormat = 1;
            static BadScheme = 2;
            static BadAuthority = 3;
            static EmptyUriString = 4;
            static LastErrorOkayForRelativeUris = 5;
            static SchemeLimit = 6;
            static MustRootedPath = 7;
            static BadHostName = 8;
            static NonEmptyHost = 9;
            static BadPort = 10;
            static BadAuthorityTerminator = 11;
            static CannotCreateRelative = 12;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1310722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "BadFormat": 1n,
                    "BadScheme": 2n,
                    "BadAuthority": 3n,
                    "EmptyUriString": 4n,
                    "LastErrorOkayForRelativeUris": 5n,
                    "SchemeLimit": 6n,
                    "MustRootedPath": 7n,
                    "BadHostName": 8n,
                    "NonEmptyHost": 9n,
                    "BadPort": 10n,
                    "BadAuthorityTerminator": 11n,
                    "CannotCreateRelative": 12n
                };
            }
            static $h = 1310722;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540918274),
    {
      "t": 1310722,
      "n": "None",
      "d": 1310722,
      "h": 51540918274,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540918274),
//--TRIMMABLE-BOUNDARY-START(17181179906),
    {
      "t": 1310722,
      "n": "BadFormat",
      "d": 1310722,
      "h": 17181179906,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181179906),
//--TRIMMABLE-BOUNDARY-START(30066081794),
    {
      "t": 1310722,
      "n": "BadScheme",
      "d": 1310722,
      "h": 30066081794,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066081794),
//--TRIMMABLE-BOUNDARY-START(8591245314),
    {
      "t": 1310722,
      "n": "BadAuthority",
      "d": 1310722,
      "h": 8591245314,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591245314),
//--TRIMMABLE-BOUNDARY-START(38656016386),
    {
      "t": 1310722,
      "n": "EmptyUriString",
      "d": 1310722,
      "h": 38656016386,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656016386),
//--TRIMMABLE-BOUNDARY-START(42950983682),
    {
      "t": 1310722,
      "n": "LastErrorOkayForRelativeUris",
      "d": 1310722,
      "h": 42950983682,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950983682),
//--TRIMMABLE-BOUNDARY-START(60130852866),
    {
      "t": 1310722,
      "n": "SchemeLimit",
      "d": 1310722,
      "h": 60130852866,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130852866),
//--TRIMMABLE-BOUNDARY-START(47245950978),
    {
      "t": 1310722,
      "n": "MustRootedPath",
      "d": 1310722,
      "h": 47245950978,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245950978),
//--TRIMMABLE-BOUNDARY-START(21476147202),
    {
      "t": 1310722,
      "n": "BadHostName",
      "d": 1310722,
      "h": 21476147202,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476147202),
//--TRIMMABLE-BOUNDARY-START(55835885570),
    {
      "t": 1310722,
      "n": "NonEmptyHost",
      "d": 1310722,
      "h": 55835885570,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835885570),
//--TRIMMABLE-BOUNDARY-START(25771114498),
    {
      "t": 1310722,
      "n": "BadPort",
      "d": 1310722,
      "h": 25771114498,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771114498),
//--TRIMMABLE-BOUNDARY-START(12886212610),
    {
      "t": 1310722,
      "n": "BadAuthorityTerminator",
      "d": 1310722,
      "h": 12886212610,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886212610),
//--TRIMMABLE-BOUNDARY-START(34361049090),
    {
      "t": 1310722,
      "n": "CannotCreateRelative",
      "d": 1310722,
      "h": 34361049090,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361049090)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278018),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1310722,
      "h": 4296278018,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278018)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1310722
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ParsingError`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310722)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638402)
        $asm.$str("$spu.System.UnescapeMode", ($self) => class UnescapeMode extends $.$$.System.Enum
        {
            static CopyOnly = 0;
            static Escape = 1;
            static Unescape = 2;
            static EscapeUnescape = 3;
            static V1ToStringFlag = 4;
            static UnescapeAll = 8;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1638402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "CopyOnly": 0n,
                    "Escape": 1n,
                    "Unescape": 2n,
                    "EscapeUnescape": 3n,
                    "V1ToStringFlag": 4n,
                    "UnescapeAll": 8n
                };
            }
            static $h = 1638402;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591572994),
    {
      "t": 1638402,
      "n": "CopyOnly",
      "d": 1638402,
      "h": 8591572994,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591572994),
//--TRIMMABLE-BOUNDARY-START(12886540290),
    {
      "t": 1638402,
      "n": "Escape",
      "d": 1638402,
      "h": 12886540290,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886540290),
//--TRIMMABLE-BOUNDARY-START(21476474882),
    {
      "t": 1638402,
      "n": "Unescape",
      "d": 1638402,
      "h": 21476474882,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476474882),
//--TRIMMABLE-BOUNDARY-START(17181507586),
    {
      "t": 1638402,
      "n": "EscapeUnescape",
      "d": 1638402,
      "h": 17181507586,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181507586),
//--TRIMMABLE-BOUNDARY-START(30066409474),
    {
      "t": 1638402,
      "n": "V1ToStringFlag",
      "d": 1638402,
      "h": 30066409474,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066409474),
//--TRIMMABLE-BOUNDARY-START(25771442178),
    {
      "t": 1638402,
      "n": "UnescapeAll",
      "d": 1638402,
      "h": 25771442178,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771442178)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605698),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638402,
      "h": 4296605698,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605698)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1638402,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.UnescapeMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638402)
        
        
        //--TRIMMABLE-BOUNDARY-START(2818050)
        $asm.$str("$spu.System.UriSyntaxFlags", ($self) => class UriSyntaxFlags extends $.$$.System.Enum
        {
            static None = 0;
            static MustHaveAuthority = 1;
            static OptionalAuthority = 2;
            static MayHaveUserInfo = 4;
            static MayHavePort = 8;
            static MayHavePath = 16;
            static MayHaveQuery = 32;
            static MayHaveFragment = 64;
            static AllowEmptyHost = 128;
            static AllowUncHost = 256;
            static AllowDnsHost = 512;
            static AllowIPv4Host = 1024;
            static AllowIPv6Host = 2048;
            static AllowAnInternetHost = 3584;
            static AllowAnyOtherHost = 4096;
            static FileLikeUri = 8192;
            static MailToLikeUri = 16384;
            static V1_UnknownUri = 65536;
            static SimpleUserSyntax = 131072;
            static AllowDOSPath = 1048576;
            static PathIsRooted = 2097152;
            static ConvertPathSlashes = 4194304;
            static CompressPath = 8388608;
            static CanonicalizeAsFilePath = 16777216;
            static UnEscapeDotsAndSlashes = 33554432;
            static AllowIdn = 67108864;
            static AllowIriParsing = 268435456;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2818050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "MustHaveAuthority": 1n,
                    "OptionalAuthority": 2n,
                    "MayHaveUserInfo": 4n,
                    "MayHavePort": 8n,
                    "MayHavePath": 16n,
                    "MayHaveQuery": 32n,
                    "MayHaveFragment": 64n,
                    "AllowEmptyHost": 128n,
                    "AllowUncHost": 256n,
                    "AllowDnsHost": 512n,
                    "AllowIPv4Host": 1024n,
                    "AllowIPv6Host": 2048n,
                    "AllowAnInternetHost": 3584n,
                    "AllowAnyOtherHost": 4096n,
                    "FileLikeUri": 8192n,
                    "MailToLikeUri": 16384n,
                    "V1_UnknownUri": 65536n,
                    "SimpleUserSyntax": 131072n,
                    "AllowDOSPath": 1048576n,
                    "PathIsRooted": 2097152n,
                    "ConvertPathSlashes": 4194304n,
                    "CompressPath": 8388608n,
                    "CanonicalizeAsFilePath": 16777216n,
                    "UnEscapeDotsAndSlashes": 33554432n,
                    "AllowIdn": 67108864n,
                    "AllowIriParsing": 268435456n
                };
            }
            static $h = 2818050;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(98787065858),
    {
      "t": 2818050,
      "n": "None",
      "d": 2818050,
      "h": 98787065858,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98787065858),
//--TRIMMABLE-BOUNDARY-START(94492098562),
    {
      "t": 2818050,
      "n": "MustHaveAuthority",
      "d": 2818050,
      "h": 94492098562,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94492098562),
//--TRIMMABLE-BOUNDARY-START(103082033154),
    {
      "t": 2818050,
      "n": "OptionalAuthority",
      "d": 2818050,
      "h": 103082033154,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103082033154),
//--TRIMMABLE-BOUNDARY-START(90197131266),
    {
      "t": 2818050,
      "n": "MayHaveUserInfo",
      "d": 2818050,
      "h": 90197131266,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90197131266),
//--TRIMMABLE-BOUNDARY-START(81607196674),
    {
      "t": 2818050,
      "n": "MayHavePort",
      "d": 2818050,
      "h": 81607196674,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81607196674),
//--TRIMMABLE-BOUNDARY-START(77312229378),
    {
      "t": 2818050,
      "n": "MayHavePath",
      "d": 2818050,
      "h": 77312229378,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77312229378),
//--TRIMMABLE-BOUNDARY-START(85902163970),
    {
      "t": 2818050,
      "n": "MayHaveQuery",
      "d": 2818050,
      "h": 85902163970,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85902163970),
//--TRIMMABLE-BOUNDARY-START(73017262082),
    {
      "t": 2818050,
      "n": "MayHaveFragment",
      "d": 2818050,
      "h": 73017262082,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73017262082),
//--TRIMMABLE-BOUNDARY-START(25772621826),
    {
      "t": 2818050,
      "n": "AllowEmptyHost",
      "d": 2818050,
      "h": 25772621826,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772621826),
//--TRIMMABLE-BOUNDARY-START(47247458306),
    {
      "t": 2818050,
      "n": "AllowUncHost",
      "d": 2818050,
      "h": 47247458306,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47247458306),
//--TRIMMABLE-BOUNDARY-START(17182687234),
    {
      "t": 2818050,
      "n": "AllowDnsHost",
      "d": 2818050,
      "h": 17182687234,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182687234),
//--TRIMMABLE-BOUNDARY-START(34362556418),
    {
      "t": 2818050,
      "n": "AllowIPv4Host",
      "d": 2818050,
      "h": 34362556418,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34362556418),
//--TRIMMABLE-BOUNDARY-START(38657523714),
    {
      "t": 2818050,
      "n": "AllowIPv6Host",
      "d": 2818050,
      "h": 38657523714,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38657523714),
//--TRIMMABLE-BOUNDARY-START(8592752642),
    {
      "t": 2818050,
      "n": "AllowAnInternetHost",
      "d": 2818050,
      "h": 8592752642,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592752642),
//--TRIMMABLE-BOUNDARY-START(12887719938),
    {
      "t": 2818050,
      "n": "AllowAnyOtherHost",
      "d": 2818050,
      "h": 12887719938,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887719938),
//--TRIMMABLE-BOUNDARY-START(64427327490),
    {
      "t": 2818050,
      "n": "FileLikeUri",
      "d": 2818050,
      "h": 64427327490,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64427327490),
//--TRIMMABLE-BOUNDARY-START(68722294786),
    {
      "t": 2818050,
      "n": "MailToLikeUri",
      "d": 2818050,
      "h": 68722294786,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68722294786),
//--TRIMMABLE-BOUNDARY-START(120261902338),
    {
      "t": 2818050,
      "n": "V1_UnknownUri",
      "d": 2818050,
      "h": 120261902338,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120261902338),
//--TRIMMABLE-BOUNDARY-START(111671967746),
    {
      "t": 2818050,
      "n": "SimpleUserSyntax",
      "d": 2818050,
      "h": 111671967746,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111671967746),
//--TRIMMABLE-BOUNDARY-START(21477654530),
    {
      "t": 2818050,
      "n": "AllowDOSPath",
      "d": 2818050,
      "h": 21477654530,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477654530),
//--TRIMMABLE-BOUNDARY-START(107377000450),
    {
      "t": 2818050,
      "n": "PathIsRooted",
      "d": 2818050,
      "h": 107377000450,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107377000450),
//--TRIMMABLE-BOUNDARY-START(60132360194),
    {
      "t": 2818050,
      "n": "ConvertPathSlashes",
      "d": 2818050,
      "h": 60132360194,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60132360194),
//--TRIMMABLE-BOUNDARY-START(55837392898),
    {
      "t": 2818050,
      "n": "CompressPath",
      "d": 2818050,
      "h": 55837392898,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55837392898),
//--TRIMMABLE-BOUNDARY-START(51542425602),
    {
      "t": 2818050,
      "n": "CanonicalizeAsFilePath",
      "d": 2818050,
      "h": 51542425602,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51542425602),
//--TRIMMABLE-BOUNDARY-START(115966935042),
    {
      "t": 2818050,
      "n": "UnEscapeDotsAndSlashes",
      "d": 2818050,
      "h": 115966935042,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115966935042),
//--TRIMMABLE-BOUNDARY-START(30067589122),
    {
      "t": 2818050,
      "n": "AllowIdn",
      "d": 2818050,
      "h": 30067589122,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067589122),
//--TRIMMABLE-BOUNDARY-START(42952491010),
    {
      "t": 2818050,
      "n": "AllowIriParsing",
      "d": 2818050,
      "h": 42952491010,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42952491010)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297785346),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2818050,
      "h": 4297785346,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297785346)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 2818050,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.UriSyntaxFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2818050)
        
        
        //--TRIMMABLE-BOUNDARY-START(2359298)
        $asm.$cls("$spu.System.UriFormatException", ($self) => class UriFormatException extends $.$$.System.FormatException
        {
            //--TRIMMABLE-BOUNDARY-START(4297326594)
            $ctor$13()
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297326594);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297326594)
            
            //--TRIMMABLE-BOUNDARY-START(17182228482)
            $ctor$16(/*string?*/ textString)
            {
                super.$ctor$12(textString);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182228482);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182228482)
            
            //--TRIMMABLE-BOUNDARY-START(12887261186)
            $ctor$15(/*string?*/ textString, /*Exception?*/ e)
            {
                super.$ctor$11(textString, e);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887261186);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887261186)
            
            //--TRIMMABLE-BOUNDARY-START(8592293890)
            $ctor$14(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.$ctor$10(serializationInfo, streamingContext);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592293890);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592293890)
            
            //--TRIMMABLE-BOUNDARY-START(21477195778)
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477195778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.GetObjectData(serializationInfo, streamingContext);
            }
            //--TRIMMABLE-BOUNDARY-END(21477195778)
            
            static $h = 2359298;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 80543745,
  "h": 2359298
}; }
            static get $b() { return $.$$.System.FormatException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.UriFormatException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359298)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))
//--TRIMMABLE-BOUNDARY-END(2)
