
(function ($global, $, $spc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Private.Uri", 
    {"h":39060,"f":"System.Private.Uri","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Private.Uri","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Private.Uri","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$spu.System.UriParser", ($self) => class UriParser extends $.$spc.System.Object
        {
            /*string */ get SchemeName()
            {
                return this._scheme;
            }
            /*int */ get DefaultPort()
            {
                return this._port;
            }
            /*UriSyntaxFlags*/ static SchemeOnlyFlags = 16;
            $ctor$1()
            {
                this.$ctor$2(16/*SchemeOnlyFlags*/);
                {
                }
                return this;
            }
            /*UriParser */ OnNewUri()
            {
                return this;
            }
            /*void */ OnRegister(/*string*/ schemeName, /*int*/ defaultPort)
            {
            }
            /*void */ InitializeAndValidate(/*Uri*/ uri, /*out UriFormatException?*/ parsingError)
            {
                if (uri._syntax === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (!$.$spc.System.Object.ReferenceEquals(uri._syntax, this))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.Format($.$spu.System.SR.net_uri_UserDrivenParsing, $.$spc.System.Object.GetType.call(uri._syntax)));
                }
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spu.System.Uri.Flags.$z === $.$spc.System.UInt64.$z, "sizeof(Uri.Flags) == sizeof(ulong)");
                /*ulong*/ let previous = $.$spc.System.Threading.Interlocked.Or$3($.$spc.System.Runtime.CompilerServices.Unsafe.As($.$spu.System.Uri.Flags, $.$spc.System.UInt64, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => uri._flags, ($v) => uri._flags = $v, null)), 72057594037927936n);
                if (($.$cast(previous, $.$spu.System.Uri.Flags) & 72057594037927936n) !== 0n)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_InitializeCalledAlreadyOrTooLate);
                }
                parsingError.$v = uri.ParseMinimal();
            }
            /*string? */ Resolve(/*Uri*/ baseUri, /*Uri?*/ relativeUri, /*out UriFormatException?*/ parsingError)
            {
                if (baseUri.UserDrivenParsing)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.Format($.$spu.System.SR.net_uri_UserDrivenParsing, $.$spc.System.Object.GetType.call(this)));
                }
                if (!baseUri.IsAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*string?*/ let newUriString = null;
                /*bool*/ let userEscaped = false;
                parsingError.$v = null;
                /*Uri?*/ let result = $.$spu.System.Uri.ResolveHelper(baseUri, relativeUri, $.$ref(() => newUriString, ($v) => newUriString = $v, $.$spc.System.String), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => userEscaped, ($v) => userEscaped = $v, null));
                if ($.$spu.System.Uri.op_Inequality(result, null))
                {
                    return result.OriginalString;
                }
                return newUriString;
            }
            /*bool */ IsBaseOf(/*Uri*/ baseUri, /*Uri*/ relativeUri)
            {
                return baseUri.IsBaseOfHelper(relativeUri);
            }
            /*string */ GetComponents(/*Uri*/ uri, /*UriComponents*/ components, /*UriFormat*/ format)
            {
                if (((components & -2147483648/*UriComponents.SerializationInfoString*/) !== 0) && components !== -2147483648/*UriComponents.SerializationInfoString*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("components", $.$box(components, $.$spu.System.UriComponents), $.$spu.System.SR.net_uri_NotJustSerialization);
                }
                if ((format & ~3/*UriFormat.SafeUnescaped*/) !== 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("format");
                }
                if (uri.UserDrivenParsing)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.Format($.$spu.System.SR.net_uri_UserDrivenParsing, $.$spc.System.Object.GetType.call(this)));
                }
                if (!uri.IsAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (uri.DisablePathAndQueryCanonicalization && (components & (16/*UriComponents.Path*/ | 32/*UriComponents.Query*/)) !== 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_GetComponentsCalledWhenCanonicalizationDisabled);
                }
                return uri.GetComponentsHelper(components, format);
            }
            /*bool */ IsWellFormedOriginalString(/*Uri*/ uri)
            {
                return uri.InternalIsWellFormedOriginalString();
            }
            static /*void */ Register(/*UriParser*/ uriParser, /*string*/ schemeName, /*int*/ defaultPort)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(uriParser, "uriParser");
                $.$spc.System.ArgumentNullException.ThrowIfNull(schemeName, "schemeName");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfEqual($.$spc.System.Int32, schemeName.length, 1, "schemeName.Length");
                if (!$.$spu.System.Uri.CheckSchemeName(schemeName))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("schemeName");
                }
                if ((defaultPort >>> 0) > 65535 && defaultPort !== -1)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("defaultPort");
                }
                schemeName = $.$spc.System.String.ToLowerInvariant.call(schemeName);
                $.$spu.System.UriParser.FetchSyntax(uriParser, schemeName, defaultPort);
            }
            static /*bool */ IsKnownScheme(/*string*/ schemeName)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(schemeName, "schemeName");
                if (!$.$spu.System.Uri.CheckSchemeName(schemeName))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("schemeName");
                }
                /*UriParser?*/ let syntax = $.$spu.System.UriParser.GetSyntax($.$spc.System.String.ToLowerInvariant.call(schemeName));
                return syntax !== null && syntax.NotAny(65536/*UriSyntaxFlags.V1_UnknownUri*/);
            }
            /*UriParser*/ static HttpUri = null;
            /*UriParser*/ static HttpsUri = null;
            /*UriParser*/ static WsUri = null;
            /*UriParser*/ static WssUri = null;
            /*UriParser*/ static FtpUri = null;
            /*UriParser*/ static FileUri = null;
            /*UriParser*/ static UnixFileUri = null;
            /*UriParser*/ static GopherUri = null;
            /*UriParser*/ static NntpUri = null;
            /*UriParser*/ static NewsUri = null;
            /*UriParser*/ static MailToUri = null;
            /*UriParser*/ static UuidUri = null;
            /*UriParser*/ static TelnetUri = null;
            /*UriParser*/ static LdapUri = null;
            /*UriParser*/ static NetTcpUri = null;
            /*UriParser*/ static NetPipeUri = null;
            /*UriParser*/ static VsMacrosUri = null;
            /*Hashtable*/ static s_table = null;
            /*Hashtable*/ static s_tempTable = null;
            /*UriSyntaxFlags*/ _flags = 0;
            /*int*/ _port = 0;
            /*string*/ _scheme = null;
            /*int*/ static NoDefaultPort = -1;
            /*int*/ static c_InitialTableSize = 25;
            static $_BuiltInUriParser;
            static get BuiltInUriParser()
            {
                let $cls = $.$spu.System.UriParser;
                return $cls.$_BuiltInUriParser ??= $asm.$ncls("$spu.System.UriParser.BuiltInUriParser", ($self) => class BuiltInUriParser extends $.$spu.System.UriParser
                {
                    $ctor$3(/*string*/ lwrCaseScheme, /*int*/ defaultPort, /*UriSyntaxFlags*/ syntaxFlags)
                    {
                        super.$ctor$2(syntaxFlags | 131072/*UriSyntaxFlags.SimpleUserSyntax*/);
                        {
                            this._scheme = lwrCaseScheme;
                            this._port = defaultPort;
                        }
                        return this;
                    }
                    static $h = 2726036;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2660500,"c":[{"p":[{"n":"lwrCaseScheme","p":1310721},{"n":"defaultPort","p":655361},{"n":"syntaxFlags","p":2857108}],"n":".ctor","o":"$ctor$3","d":2726036,"h":4297693332,"f":8}],"d":2660500,"h":2726036}; }
                    static get $b() { return $.$spu.System.UriParser; }
                    static get $fullName() { return `System.UriParser.BuiltInUriParser`; }
                }, $cls, ($v) => $cls.$_BuiltInUriParser = $v);
            }
            /*UriSyntaxFlags */ get Flags()
            {
                return this._flags;
            }
            /*bool */ NotAny(/*UriSyntaxFlags*/ flags)
            {
                return this.IsFullMatch(flags, 0/*UriSyntaxFlags.None*/);
            }
            /*bool */ InFact(/*UriSyntaxFlags*/ flags)
            {
                return !this.IsFullMatch(flags, 0/*UriSyntaxFlags.None*/);
            }
            /*bool */ IsAllSet(/*UriSyntaxFlags*/ flags)
            {
                return this.IsFullMatch(flags, flags);
            }
            /*bool */ IsFullMatch(/*UriSyntaxFlags*/ flags, /*UriSyntaxFlags*/ expected)
            {
                return (this._flags & flags) === expected;
            }
            $ctor$2(/*UriSyntaxFlags*/ flags)
            {
                super.$ctor();
                {
                    this._flags = flags;
                    this._scheme = $.$spc.System.String.Empty;
                }
                return this;
            }
            static /*void */ FetchSyntax(/*UriParser*/ syntax, /*string*/ lwrCaseSchemeName, /*int*/ defaultPort)
            {
                if (syntax.SchemeName.length !== 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.Format($.$spu.System.SR.net_uri_NeedFreshParser, syntax.SchemeName));
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$spu.System.UriParser.s_table)
                    {
                        syntax._flags &= ~65536/*UriSyntaxFlags.V1_UnknownUri*/;
                        /*UriParser?*/ let oldSyntax = $.$cast($.$spu.System.UriParser.s_table.get_Item(lwrCaseSchemeName), $.$spu.System.UriParser);
                        if (oldSyntax !== null)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.Format($.$spu.System.SR.net_uri_AlreadyRegistered, oldSyntax.SchemeName));
                        }
                        oldSyntax = $.$cast($.$spu.System.UriParser.s_tempTable.get_Item(syntax.SchemeName), $.$spu.System.UriParser);
                        if (oldSyntax !== null)
                        {
                            lwrCaseSchemeName = oldSyntax._scheme;
                            $.$spu.System.UriParser.s_tempTable.Remove(lwrCaseSchemeName);
                        }
                        syntax.OnRegister(lwrCaseSchemeName, defaultPort);
                        syntax._scheme = lwrCaseSchemeName;
                        syntax.CheckSetIsSimpleFlag();
                        syntax._port = defaultPort;
                        $.$spu.System.UriParser.s_table.set_Item(syntax.SchemeName, syntax);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$spu.System.UriParser.s_table)
                }
            }
            /*int*/ static c_MaxCapacity = 512;
            static /*UriParser */ FindOrFetchAsUnknownV1Syntax(/*string*/ lwrCaseScheme)
            {
                /*UriParser?*/ let syntax = $.$cast($.$spu.System.UriParser.s_table.get_Item(lwrCaseScheme), $.$spu.System.UriParser);
                if (syntax !== null)
                {
                    return syntax;
                }
                syntax = $.$cast($.$spu.System.UriParser.s_tempTable.get_Item(lwrCaseScheme), $.$spu.System.UriParser);
                if (syntax !== null)
                {
                    return syntax;
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$spu.System.UriParser.s_table)
                    {
                        if ($.$spu.System.UriParser.s_tempTable.Count >= 512/*c_MaxCapacity*/)
                        {
                            $.$spu.System.UriParser.s_tempTable = new $.$spc.System.Collections.Hashtable().$ctor$3(25/*c_InitialTableSize*/);
                        }
                        syntax = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3(lwrCaseScheme, -1/*NoDefaultPort*/, 351342590/*UnknownV1SyntaxFlags*/);
                        $.$spu.System.UriParser.s_tempTable.set_Item(lwrCaseScheme, syntax);
                        return syntax;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$spu.System.UriParser.s_table)
                }
            }
            static /*UriParser? */ GetSyntax(/*string*/ lwrCaseScheme)
            {
                return $.$cast(($.$spu.System.UriParser.s_table.get_Item(lwrCaseScheme) ?? $.$spu.System.UriParser.s_tempTable.get_Item(lwrCaseScheme)), $.$spu.System.UriParser);
            }
            /*bool */ get IsSimple()
            {
                return this.InFact(131072/*UriSyntaxFlags.SimpleUserSyntax*/);
            }
            /*void */ CheckSetIsSimpleFlag()
            {
                /*Type*/ let type = $.$spc.System.Object.GetType.call(this);
                if ($.$spc.System.Type.op_Equality$1(type, $.$spu.System.GenericUriParser.$type) || $.$spc.System.Type.op_Equality$1(type, $.$spu.System.HttpStyleUriParser.$type) || $.$spc.System.Type.op_Equality$1(type, $.$spu.System.FtpStyleUriParser.$type) || $.$spc.System.Type.op_Equality$1(type, $.$spu.System.FileStyleUriParser.$type) || $.$spc.System.Type.op_Equality$1(type, $.$spu.System.NewsStyleUriParser.$type) || $.$spc.System.Type.op_Equality$1(type, $.$spu.System.GopherStyleUriParser.$type) || $.$spc.System.Type.op_Equality$1(type, $.$spu.System.NetPipeStyleUriParser.$type) || $.$spc.System.Type.op_Equality$1(type, $.$spu.System.NetTcpStyleUriParser.$type) || $.$spc.System.Type.op_Equality$1(type, $.$spu.System.LdapStyleUriParser.$type))
                {
                    this._flags |= 131072/*UriSyntaxFlags.SimpleUserSyntax*/;
                }
            }
            /*UriParser */ InternalOnNewUri()
            {
                /*UriParser*/ let effectiveParser = this.OnNewUri();
                if (this !== effectiveParser)
                {
                    effectiveParser._scheme = this._scheme;
                    effectiveParser._port = this._port;
                    effectiveParser._flags = this._flags;
                }
                return effectiveParser;
            }
            /*void */ InternalValidate(/*Uri*/ thisUri, /*out UriFormatException?*/ parsingError)
            {
                thisUri.DebugAssertInCtor();
                this.InitializeAndValidate(thisUri, parsingError);
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spu.System.Uri.Flags.$z === $.$spc.System.UInt64.$z, "sizeof(Uri.Flags) == sizeof(ulong)");
                $.$spc.System.Threading.Interlocked.Or$3($.$spc.System.Runtime.CompilerServices.Unsafe.As($.$spu.System.Uri.Flags, $.$spc.System.UInt64, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => thisUri._flags, ($v) => thisUri._flags = $v, null)), 72057594037927936n);
            }
            /*string? */ InternalResolve(/*Uri*/ thisBaseUri, /*Uri*/ uriLink, /*out UriFormatException?*/ parsingError)
            {
                return this.Resolve(thisBaseUri, uriLink, parsingError);
            }
            /*bool */ InternalIsBaseOf(/*Uri*/ thisBaseUri, /*Uri*/ uriLink)
            {
                return this.IsBaseOf(thisBaseUri, uriLink);
            }
            /*string */ InternalGetComponents(/*Uri*/ thisUri, /*UriComponents*/ uriComponents, /*UriFormat*/ uriFormat)
            {
                return this.GetComponents(thisUri, uriComponents, uriFormat);
            }
            /*bool */ InternalIsWellFormedOriginalString(/*Uri*/ thisUri)
            {
                return this.IsWellFormedOriginalString(thisUri);
            }
            /*UriSyntaxFlags*/ static UnknownV1SyntaxFlags = 351342590;
            /*UriSyntaxFlags*/ static HttpSyntaxFlags = 367005565;
            /*UriSyntaxFlags*/ static FtpSyntaxFlags = 367005533;
            /*UriSyntaxFlags*/ static FileSyntaxFlags = 401616881;
            /*UriSyntaxFlags*/ static UnixFileSyntaxFlags = 397422577;
            /*UriSyntaxFlags*/ static VsmacrosSyntaxFlags = 399519697;
            /*UriSyntaxFlags*/ static GopherSyntaxFlags = 337645405;
            /*UriSyntaxFlags*/ static NewsSyntaxFlags = 268435536;
            /*UriSyntaxFlags*/ static NntpSyntaxFlags = 337645405;
            /*UriSyntaxFlags*/ static TelnetSyntaxFlags = 337645405;
            /*UriSyntaxFlags*/ static LdapSyntaxFlags = 337645565;
            /*UriSyntaxFlags*/ static MailtoSyntaxFlags = 335564796;
            /*UriSyntaxFlags*/ static NetPipeSyntaxFlags = 400559729;
            /*UriSyntaxFlags*/ static NetTcpSyntaxFlags = 400559737;
            //Static Initializer
            static $sinit()
            {
                {
                    this.HttpUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("http", 80, 367005565/*HttpSyntaxFlags*/);
                }
                {
                    this.HttpsUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("https", 443, $.$spu.System.UriParser.HttpUri._flags);
                }
                {
                    this.WsUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("ws", 80, 367005565/*HttpSyntaxFlags*/);
                }
                {
                    this.WssUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("wss", 443, 367005565/*HttpSyntaxFlags*/);
                }
                {
                    this.FtpUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("ftp", 21, 367005533/*FtpSyntaxFlags*/);
                }
                {
                    this.FileUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("file", -1/*NoDefaultPort*/, 401616881/*FileSyntaxFlags*/);
                }
                {
                    this.UnixFileUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("file", -1/*NoDefaultPort*/, 397422577/*UnixFileSyntaxFlags*/);
                }
                {
                    this.GopherUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("gopher", 70, 337645405/*GopherSyntaxFlags*/);
                }
                {
                    this.NntpUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("nntp", 119, 337645405/*NntpSyntaxFlags*/);
                }
                {
                    this.NewsUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("news", -1/*NoDefaultPort*/, 268435536/*NewsSyntaxFlags*/);
                }
                {
                    this.MailToUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("mailto", 25, 335564796/*MailtoSyntaxFlags*/);
                }
                {
                    this.UuidUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("uuid", -1/*NoDefaultPort*/, $.$spu.System.UriParser.NewsUri._flags);
                }
                {
                    this.TelnetUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("telnet", 23, 337645405/*TelnetSyntaxFlags*/);
                }
                {
                    this.LdapUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("ldap", 389, 337645565/*LdapSyntaxFlags*/);
                }
                {
                    this.NetTcpUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("net.tcp", 808, 400559737/*NetTcpSyntaxFlags*/);
                }
                {
                    this.NetPipeUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("net.pipe", -1/*NoDefaultPort*/, 400559729/*NetPipeSyntaxFlags*/);
                }
                {
                    this.VsMacrosUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("vsmacros", -1/*NoDefaultPort*/, 399519697/*VsmacrosSyntaxFlags*/);
                }
                {
                    this.s_table = (() =>
                    {
                        //new $.$spc.System.Collections.Hashtable()
                        const $t1 = $.$spc.System.Collections.Hashtable;
                        const $i1 = new $t1();
                        $i1.$ctor$3(16);
                        $i1.Add($.$spu.System.UriParser.HttpUri.SchemeName, $.$spu.System.UriParser.HttpUri);
                        $i1.Add($.$spu.System.UriParser.HttpsUri.SchemeName, $.$spu.System.UriParser.HttpsUri);
                        $i1.Add($.$spu.System.UriParser.WsUri.SchemeName, $.$spu.System.UriParser.WsUri);
                        $i1.Add($.$spu.System.UriParser.WssUri.SchemeName, $.$spu.System.UriParser.WssUri);
                        $i1.Add($.$spu.System.UriParser.FtpUri.SchemeName, $.$spu.System.UriParser.FtpUri);
                        $i1.Add($.$spu.System.UriParser.FileUri.SchemeName, $.$spu.System.UriParser.FileUri);
                        $i1.Add($.$spu.System.UriParser.GopherUri.SchemeName, $.$spu.System.UriParser.GopherUri);
                        $i1.Add($.$spu.System.UriParser.NntpUri.SchemeName, $.$spu.System.UriParser.NntpUri);
                        $i1.Add($.$spu.System.UriParser.NewsUri.SchemeName, $.$spu.System.UriParser.NewsUri);
                        $i1.Add($.$spu.System.UriParser.MailToUri.SchemeName, $.$spu.System.UriParser.MailToUri);
                        $i1.Add($.$spu.System.UriParser.UuidUri.SchemeName, $.$spu.System.UriParser.UuidUri);
                        $i1.Add($.$spu.System.UriParser.TelnetUri.SchemeName, $.$spu.System.UriParser.TelnetUri);
                        $i1.Add($.$spu.System.UriParser.LdapUri.SchemeName, $.$spu.System.UriParser.LdapUri);
                        $i1.Add($.$spu.System.UriParser.NetTcpUri.SchemeName, $.$spu.System.UriParser.NetTcpUri);
                        $i1.Add($.$spu.System.UriParser.NetPipeUri.SchemeName, $.$spu.System.UriParser.NetPipeUri);
                        $i1.Add($.$spu.System.UriParser.VsMacrosUri.SchemeName, $.$spu.System.UriParser.VsMacrosUri);
                        return $i1;
                    })();
                }
                {
                    this.s_tempTable = new $.$spc.System.Collections.Hashtable().$ctor$3(25/*c_InitialTableSize*/);
                }
            }
            static $h = 2660500;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8592595092,"f":8},"n":"SchemeName","d":2660500,"h":4297627796,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":17182529684,"f":8},"n":"DefaultPort","d":2660500,"h":12887562388,"f":8},{"p":2857108,"g":{"r":0,"d":0,"h":180391286932,"f":8},"n":"Flags","d":2660500,"h":176096319636,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":227635927188,"f":8},"n":"IsSimple","d":2660500,"h":223340959892,"f":8}],"m":[{"r":2660500,"n":"OnNewUri","d":2660500,"h":30067431572,"f":132},{"r":65537,"p":[{"n":"schemeName","p":1310721},{"n":"defaultPort","p":655361}],"n":"OnRegister","d":2660500,"h":34362398868,"f":132},{"r":65537,"p":[{"n":"uri","p":1742996},{"n":"parsingError","p":2398356,"f":2}],"n":"InitializeAndValidate","d":2660500,"h":38657366164,"f":132},{"r":1310721,"p":[{"n":"baseUri","p":1742996},{"n":"relativeUri","p":1742996},{"n":"parsingError","p":2398356,"f":2}],"n":"Resolve","d":2660500,"h":42952333460,"f":132},{"r":262145,"p":[{"n":"baseUri","p":1742996},{"n":"relativeUri","p":1742996}],"n":"IsBaseOf","d":2660500,"h":47247300756,"f":132},{"r":1310721,"p":[{"n":"uri","p":1742996},{"n":"components","p":2201748},{"n":"format","p":2332820}],"n":"GetComponents","d":2660500,"h":51542268052,"f":132},{"r":262145,"p":[{"n":"uri","p":1742996}],"n":"IsWellFormedOriginalString","d":2660500,"h":55837235348,"f":132},{"r":65537,"p":[{"n":"uriParser","p":2660500},{"n":"schemeName","p":1310721},{"n":"defaultPort","p":655361}],"n":"Register","d":2660500,"h":60132202644,"f":33},{"r":262145,"p":[{"n":"schemeName","p":1310721}],"n":"IsKnownScheme","d":2660500,"h":64427169940,"f":33},{"r":262145,"p":[{"n":"flags","p":2857108}],"n":"NotAny","d":2660500,"h":184686254228,"f":8},{"r":262145,"p":[{"n":"flags","p":2857108}],"n":"InFact","d":2660500,"h":188981221524,"f":8},{"r":262145,"p":[{"n":"flags","p":2857108}],"n":"IsAllSet","d":2660500,"h":193276188820,"f":8},{"r":262145,"p":[{"n":"flags","p":2857108},{"n":"expected","p":2857108}],"n":"IsFullMatch","d":2660500,"h":197571156116,"f":2},{"r":65537,"p":[{"n":"syntax","p":2660500},{"n":"lwrCaseSchemeName","p":1310721},{"n":"defaultPort","p":655361}],"n":"FetchSyntax","d":2660500,"h":206161090708,"f":34},{"r":2660500,"p":[{"n":"lwrCaseScheme","p":1310721}],"n":"FindOrFetchAsUnknownV1Syntax","d":2660500,"h":214751025300,"f":40},{"r":2660500,"p":[{"n":"lwrCaseScheme","p":1310721}],"n":"GetSyntax","d":2660500,"h":219045992596,"f":40},{"r":65537,"n":"CheckSetIsSimpleFlag","d":2660500,"h":231930894484,"f":8},{"r":2660500,"n":"InternalOnNewUri","d":2660500,"h":236225861780,"f":8},{"r":65537,"p":[{"n":"thisUri","p":1742996},{"n":"parsingError","p":2398356,"f":2}],"n":"InternalValidate","d":2660500,"h":240520829076,"f":8},{"r":1310721,"p":[{"n":"thisBaseUri","p":1742996},{"n":"uriLink","p":1742996},{"n":"parsingError","p":2398356,"f":2}],"n":"InternalResolve","d":2660500,"h":244815796372,"f":8},{"r":262145,"p":[{"n":"thisBaseUri","p":1742996},{"n":"uriLink","p":1742996}],"n":"InternalIsBaseOf","d":2660500,"h":249110763668,"f":8},{"r":1310721,"p":[{"n":"thisUri","p":1742996},{"n":"uriComponents","p":2201748},{"n":"uriFormat","p":2332820}],"n":"InternalGetComponents","d":2660500,"h":253405730964,"f":8},{"r":262145,"p":[{"n":"thisUri","p":1742996}],"n":"InternalIsWellFormedOriginalString","d":2660500,"h":257700698260,"f":8}],"l":[{"t":2857108,"n":"SchemeOnlyFlags","d":2660500,"h":21477496980,"f":34},{"t":2660500,"n":"HttpUri","d":2660500,"h":68722137236,"f":40},{"t":2660500,"n":"HttpsUri","d":2660500,"h":73017104532,"f":40},{"t":2660500,"n":"WsUri","d":2660500,"h":77312071828,"f":40},{"t":2660500,"n":"WssUri","d":2660500,"h":81607039124,"f":40},{"t":2660500,"n":"FtpUri","d":2660500,"h":85902006420,"f":40},{"t":2660500,"n":"FileUri","d":2660500,"h":90196973716,"f":40},{"t":2660500,"n":"UnixFileUri","d":2660500,"h":94491941012,"f":40},{"t":2660500,"n":"GopherUri","d":2660500,"h":98786908308,"f":40},{"t":2660500,"n":"NntpUri","d":2660500,"h":103081875604,"f":40},{"t":2660500,"n":"NewsUri","d":2660500,"h":107376842900,"f":40},{"t":2660500,"n":"MailToUri","d":2660500,"h":111671810196,"f":40},{"t":2660500,"n":"UuidUri","d":2660500,"h":115966777492,"f":40},{"t":2660500,"n":"TelnetUri","d":2660500,"h":120261744788,"f":40},{"t":2660500,"n":"LdapUri","d":2660500,"h":124556712084,"f":40},{"t":2660500,"n":"NetTcpUri","d":2660500,"h":128851679380,"f":40},{"t":2660500,"n":"NetPipeUri","d":2660500,"h":133146646676,"f":40},{"t":2660500,"n":"VsMacrosUri","d":2660500,"h":137441613972,"f":40},{"t":30998529,"n":"s_table","d":2660500,"h":141736581268,"f":34},{"t":30998529,"n":"s_tempTable","d":2660500,"h":146031548564,"f":34},{"t":2857108,"n":"_flags","d":2660500,"h":150326515860,"f":2},{"t":655361,"n":"_port","d":2660500,"h":154621483156,"f":2},{"t":1310721,"n":"_scheme","d":2660500,"h":158916450452,"f":2},{"t":655361,"n":"NoDefaultPort","d":2660500,"h":163211417748,"f":40},{"t":655361,"n":"c_InitialTableSize","d":2660500,"h":167506385044,"f":34},{"t":655361,"n":"c_MaxCapacity","d":2660500,"h":210456058004,"f":34},{"t":2857108,"n":"UnknownV1SyntaxFlags","d":2660500,"h":261995665556,"f":34},{"t":2857108,"n":"HttpSyntaxFlags","d":2660500,"h":266290632852,"f":34},{"t":2857108,"n":"FtpSyntaxFlags","d":2660500,"h":270585600148,"f":34},{"t":2857108,"n":"FileSyntaxFlags","d":2660500,"h":274880567444,"f":34},{"t":2857108,"n":"UnixFileSyntaxFlags","d":2660500,"h":279175534740,"f":34},{"t":2857108,"n":"VsmacrosSyntaxFlags","d":2660500,"h":283470502036,"f":34},{"t":2857108,"n":"GopherSyntaxFlags","d":2660500,"h":287765469332,"f":34},{"t":2857108,"n":"NewsSyntaxFlags","d":2660500,"h":292060436628,"f":34},{"t":2857108,"n":"NntpSyntaxFlags","d":2660500,"h":296355403924,"f":34},{"t":2857108,"n":"TelnetSyntaxFlags","d":2660500,"h":300650371220,"f":34},{"t":2857108,"n":"LdapSyntaxFlags","d":2660500,"h":304945338516,"f":34},{"t":2857108,"n":"MailtoSyntaxFlags","d":2660500,"h":309240305812,"f":34},{"t":2857108,"n":"NetPipeSyntaxFlags","d":2660500,"h":313535273108,"f":34},{"t":2857108,"n":"NetTcpSyntaxFlags","d":2660500,"h":317830240404,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":2660500,"h":25772464276,"f":4},{"p":[{"n":"flags","p":2857108}],"n":".ctor","o":"$ctor$2","d":2660500,"h":201866123412,"f":8}],"j":[2726036],"h":2660500}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.UriParser`; }
        });
        
        $asm.$cls("$spu.System.UriBuilder", ($self) => class UriBuilder extends $.$spc.System.Object
        {
            /*string*/ _scheme = null;
            /*string*/ _username = null;
            /*string*/ _password = null;
            /*string*/ _host = null;
            /*int*/ _port = -1;
            /*string*/ _path = null;
            /*string*/ _query = null;
            /*string*/ _fragment = null;
            /*bool*/ _changed = true;
            /*Uri?*/ _uri = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*string*/ uri)
            {
                super.$ctor();
                {
                    this._uri = new $.$spu.System.Uri().$ctor$5(uri, 0/*UriKind.RelativeOrAbsolute*/);
                    if (!this._uri.IsAbsoluteUri)
                    {
                        this._uri = new $.$spu.System.Uri().$ctor$2($.$spu.System.Uri.UriSchemeHttp + $.$spu.System.Uri.SchemeDelimiter + uri);
                    }
                    this.SetFieldsFromUri();
                }
                return this;
            }
            $ctor$3(/*Uri*/ uri)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(uri, "uri");
                    this._uri = uri;
                    this.SetFieldsFromUri();
                }
                return this;
            }
            $ctor$4(/*string?*/ schemeName, /*string?*/ hostName)
            {
                super.$ctor();
                {
                    this.Scheme = schemeName;
                    this.Host = hostName;
                }
                return this;
            }
            $ctor$5(/*string?*/ scheme, /*string?*/ host, /*int*/ portNumber)
            {
                this.$ctor$4(scheme, host);
                {
                    this.Port = portNumber;
                }
                return this;
            }
            $ctor$6(/*string?*/ scheme, /*string?*/ host, /*int*/ port, /*string?*/ pathValue)
            {
                this.$ctor$5(scheme, host, port);
                {
                    this.Path = pathValue;
                }
                return this;
            }
            $ctor$7(/*string?*/ scheme, /*string?*/ host, /*int*/ port, /*string?*/ path, /*string?*/ extraValue)
            {
                this.$ctor$6(scheme, host, port, path);
                {
                    if (!$.$spc.System.String.IsNullOrEmpty(extraValue))
                    {
                        if ($.$spc.System.String.get_Chars.call(extraValue, 0) === /*#*/ 35)
                        {
                            this._fragment = extraValue;
                        }
                        else if ($.$spc.System.String.get_Chars.call(extraValue, 0) === /*?*/ 63)
                        {
                            /*int*/ let fragmentIndex = $.$spc.System.String.IndexOf.call(extraValue, /*#*/ 35);
                            if (fragmentIndex === -1)
                            {
                                this._query = extraValue;
                            }
                            else 
                            {
                                this._query = $.$spc.System.String.Substring$1.call(extraValue, 0, fragmentIndex);
                                this._fragment = $.$spc.System.String.Substring.call(extraValue, fragmentIndex);
                            }
                        }
                        else 
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$spu.System.SR.Argument_ExtraNotValid, "extraValue");
                        }
                        if (this._query.length === 1)
                        {
                            this._query = $.$spc.System.String.Empty;
                        }
                        if (this._fragment.length === 1)
                        {
                            this._fragment = $.$spc.System.String.Empty;
                        }
                    }
                }
                return this;
            }
            /*string */ get Scheme()
            {
                return this._scheme;
            }
            /*string */ set Scheme(value)
            {
                value ??= $.$spc.System.String.Empty;
                if (value.length !== 0)
                {
                    if (!$.$spu.System.Uri.CheckSchemeName(value))
                    {
                        /*int*/ let index = $.$spc.System.String.IndexOf.call(value, /*:*/ 58);
                        if (index !== -1)
                        {
                            value = $.$spc.System.String.Substring$1.call(value, 0, index);
                        }
                        if (!$.$spu.System.Uri.CheckSchemeName(value))
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$spu.System.SR.net_uri_BadScheme, "value");
                        }
                    }
                    value = $.$spc.System.String.ToLowerInvariant.call(value);
                }
                this._scheme = value;
                this._changed = true;
            }
            /*string */ get UserName()
            {
                return this._username;
            }
            /*string */ set UserName(value)
            {
                this._username = value ?? $.$spc.System.String.Empty;
                this._changed = true;
            }
            /*string */ get Password()
            {
                return this._password;
            }
            /*string */ set Password(value)
            {
                this._password = value ?? $.$spc.System.String.Empty;
                this._changed = true;
            }
            /*string */ get Host()
            {
                return this._host;
            }
            /*string */ set Host(value)
            {
                if (!$.$spc.System.String.IsNullOrEmpty(value) && $.$spc.System.String.Contains$2.call(value, /*:*/ 58) && $.$spc.System.String.get_Chars.call(value, 0) !== /*[*/ 91)
                {
                    value = "[" + value + "]";
                }
                this._host = value ?? $.$spc.System.String.Empty;
                this._changed = true;
            }
            /*int */ get Port()
            {
                return this._port;
            }
            /*int */ set Port(value)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, value, -1, "value");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, value, 65535, "value");
                this._port = value;
                this._changed = true;
            }
            /*string */ get Path()
            {
                return this._path;
            }
            /*string */ set Path(value)
            {
                this._path = $.$spc.System.String.IsNullOrEmpty(value) ? "/" : $.$spu.System.Uri.InternalEscapeString($.$spc.System.String.Replace$2.call(value, /*\\*/ 92, /*/*/ 47));
                this._changed = true;
            }
            /*string */ get Query()
            {
                return this._query;
            }
            /*string */ set Query(value)
            {
                if (!$.$spc.System.String.IsNullOrEmpty(value) && $.$spc.System.String.get_Chars.call(value, 0) !== /*?*/ 63)
                {
                    value = /*?*/ 63 + value;
                }
                this._query = value ?? $.$spc.System.String.Empty;
                this._changed = true;
            }
            /*string */ get Fragment()
            {
                return this._fragment;
            }
            /*string */ set Fragment(value)
            {
                if (!$.$spc.System.String.IsNullOrEmpty(value) && $.$spc.System.String.get_Chars.call(value, 0) !== /*#*/ 35)
                {
                    value = /*#*/ 35 + value;
                }
                this._fragment = value ?? $.$spc.System.String.Empty;
                this._changed = true;
            }
            /*Uri */ get Uri()
            {
                if (this._changed)
                {
                    this._uri = new $.$spu.System.Uri().$ctor$2($.$spu.System.UriBuilder.ToString.call(this));
                    this.SetFieldsFromUri();
                    this._changed = false;
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(this._uri === null), "_uri is not null");
                }
                return this._uri;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ rparam)
            {
                return !(rparam === null) && $.$spu.System.Uri.Equals.call(this.Uri, $.$spc.System.Object.ToString.call(rparam));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$spu.System.UriBuilder.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spu.System.Uri.GetHashCode.call(this.Uri);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$spu.System.UriBuilder.GetHashCode.apply(this, arguments); }
            /*SearchValues<char>*/ static s_userInfoReservedChars = null;
            static /*string */ EncodeUserInfo(/*string*/ input)
            {
                if (!$.$spc.System.MemoryExtensions.ContainsAny$11($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(input), $.$spu.System.UriBuilder.s_userInfoReservedChars))
                {
                    return input;
                }
                return $.$spc.System.String.Replace$1.call($.$spc.System.String.Replace$1.call($.$spc.System.String.Replace$1.call($.$spc.System.String.Replace$1.call($.$spc.System.String.Replace$1.call(input, "/", "%2F", 4/*StringComparison.Ordinal*/), "\\", "%5C", 4/*StringComparison.Ordinal*/), "?", "%3F", 4/*StringComparison.Ordinal*/), "#", "%23", 4/*StringComparison.Ordinal*/), "@", "%40", 4/*StringComparison.Ordinal*/);
            }
            /*void */ SetFieldsFromUri()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._uri === null), "_uri is not null");
                this._scheme = this._uri.Scheme;
                this._host = this._uri.Host;
                this._port = this._uri.Port;
                this._path = this._uri.AbsolutePath;
                this._query = this._uri.Query;
                this._fragment = this._uri.Fragment;
                /*string*/ let userInfo = this._uri.UserInfo;
                if (userInfo.length > 0)
                {
                    /*int*/ let index = $.$spc.System.String.IndexOf.call(userInfo, /*:*/ 58);
                    if (index !== -1)
                    {
                        this._password = $.$spc.System.String.Substring.call(userInfo, ((index + 1) | 0));
                        this._username = $.$spc.System.String.Substring$1.call(userInfo, 0, index);
                    }
                    else 
                    {
                        this._username = userInfo;
                    }
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                if (this.UserName.length === 0 && this.Password.length !== 0)
                {
                    throw new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_BadUserPassword);
                }
                /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*Uri.StackallocThreshold*/, null));
                /*string*/ let scheme = this.Scheme;
                /*string*/ let host = this.Host;
                if (scheme.length !== 0)
                {
                    /*UriParser?*/ let syntax = $.$spu.System.UriParser.GetSyntax(scheme);
                    /*string*/ let schemeDelimiter;
                    if (syntax === null)
                    {
                        schemeDelimiter = host.length === 0 ? ":" : $.$spu.System.Uri.SchemeDelimiter;
                    }
                    else 
                    {
                        schemeDelimiter = syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/) || (host.length !== 0 && syntax.NotAny(16384/*UriSyntaxFlags.MailToLikeUri*/) && syntax.InFact(2/*UriSyntaxFlags.OptionalAuthority*/)) ? $.$spu.System.Uri.SchemeDelimiter : ":";
                    }
                    vsb.Append$2(scheme);
                    vsb.Append$2(schemeDelimiter);
                }
                /*string*/ let username = $.$spu.System.UriBuilder.EncodeUserInfo(this.UserName);
                if (username.length !== 0)
                {
                    vsb.Append$2(username);
                    /*string*/ let password = $.$spu.System.UriBuilder.EncodeUserInfo(this.Password);
                    if (password.length !== 0)
                    {
                        vsb.Append$1(/*:*/ 58);
                        vsb.Append$2(password);
                    }
                    vsb.Append$1(/*@*/ 64);
                }
                if (host.length !== 0)
                {
                    vsb.Append$2(host);
                    if (this._port !== -1)
                    {
                        vsb.Append$1(/*:*/ 58);
                        /*int*/ let MaxUshortLength = 5;
                        /*int*/ let charsWritten;
                        /*bool*/ let success = $.$spc.System.Int32.TryFormat.call(this._port, vsb.AppendSpan(MaxUshortLength), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))(), null);
                        $.$spc.System.Diagnostics.Debug.Assert$1(success, "success");
                        vsb.Length -= ((MaxUshortLength - charsWritten) | 0);
                    }
                }
                /*var*/ let path = this.Path;
                if (path.length !== 0)
                {
                    if (!$.$spc.System.String.StartsWith$3.call(path, /*/*/ 47) && host.length !== 0)
                    {
                        vsb.Append$1(/*/*/ 47);
                    }
                    vsb.Append$2(path);
                }
                vsb.Append$2(this.Query);
                vsb.Append$2(this.Fragment);
                return $.$spu.System.Text.ValueStringBuilder.ToString.call(vsb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spu.System.UriBuilder.ToString.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this._scheme = "http";
                this._username = $.$spc.System.String.Empty;
                this._password = $.$spc.System.String.Empty;
                this._host = "localhost";
                this._path = "/";
                this._query = $.$spc.System.String.Empty;
                this._fragment = $.$spc.System.String.Empty;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_userInfoReservedChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("/\\?#@"));
                }
            }
            static $h = 2136212;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":81606514836,"f":1},"s":{"r":0,"d":0,"h":85901482132,"f":1},"n":"Scheme","d":2136212,"h":77311547540,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":94491416724,"f":1},"s":{"r":0,"d":0,"h":98786384020,"f":1},"n":"UserName","d":2136212,"h":90196449428,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":107376318612,"f":1},"s":{"r":0,"d":0,"h":111671285908,"f":1},"n":"Password","d":2136212,"h":103081351316,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":120261220500,"f":1},"s":{"r":0,"d":0,"h":124556187796,"f":1},"n":"Host","d":2136212,"h":115966253204,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":133146122388,"f":1},"s":{"r":0,"d":0,"h":137441089684,"f":1},"n":"Port","d":2136212,"h":128851155092,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":146031024276,"f":1},"s":{"r":0,"d":0,"h":150325991572,"f":1},"n":"Path","d":2136212,"h":141736056980,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":158915926164,"f":1},"s":{"r":0,"d":0,"h":163210893460,"f":1},"n":"Query","d":2136212,"h":154620958868,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":171800828052,"f":1},"s":{"r":0,"d":0,"h":176095795348,"f":1},"n":"Fragment","d":2136212,"h":167505860756,"f":1},{"p":1742996,"g":{"r":0,"d":0,"h":184685729940,"f":1},"n":"Uri","d":2136212,"h":180390762644,"f":1}],"m":[{"r":262145,"p":[{"n":"rparam","p":131073}],"n":"Equals","d":2136212,"h":188980697236,"f":32769},{"r":655361,"n":"GetHashCode","d":2136212,"h":193275664532,"f":32769},{"r":1310721,"p":[{"n":"input","p":1310721}],"n":"EncodeUserInfo","d":2136212,"h":201865599124,"f":34},{"r":65537,"n":"SetFieldsFromUri","d":2136212,"h":206160566420,"f":2},{"r":1310721,"n":"ToString","d":2136212,"h":210455533716,"f":32769}],"l":[{"t":1310721,"n":"_scheme","d":2136212,"h":4297103508,"f":2},{"t":1310721,"n":"_username","d":2136212,"h":8592070804,"f":2},{"t":1310721,"n":"_password","d":2136212,"h":12887038100,"f":2},{"t":1310721,"n":"_host","d":2136212,"h":17182005396,"f":2},{"t":655361,"n":"_port","d":2136212,"h":21476972692,"f":2},{"t":1310721,"n":"_path","d":2136212,"h":25771939988,"f":2},{"t":1310721,"n":"_query","d":2136212,"h":30066907284,"f":2},{"t":1310721,"n":"_fragment","d":2136212,"h":34361874580,"f":2},{"t":262145,"n":"_changed","d":2136212,"h":38656841876,"f":2},{"t":1742996,"n":"_uri","d":2136212,"h":42951809172,"f":2},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"s_userInfoReservedChars","d":2136212,"h":197570631828,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":2136212,"h":47246776468,"f":1},{"p":[{"n":"uri","p":1310721}],"n":".ctor","o":"$ctor$2","d":2136212,"h":51541743764,"f":1},{"p":[{"n":"uri","p":1742996}],"n":".ctor","o":"$ctor$3","d":2136212,"h":55836711060,"f":1},{"p":[{"n":"schemeName","p":1310721},{"n":"hostName","p":1310721}],"n":".ctor","o":"$ctor$4","d":2136212,"h":60131678356,"f":1},{"p":[{"n":"scheme","p":1310721},{"n":"host","p":1310721},{"n":"portNumber","p":655361}],"n":".ctor","o":"$ctor$5","d":2136212,"h":64426645652,"f":1},{"p":[{"n":"scheme","p":1310721},{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"pathValue","p":1310721}],"n":".ctor","o":"$ctor$6","d":2136212,"h":68721612948,"f":1},{"p":[{"n":"scheme","p":1310721},{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"path","p":1310721},{"n":"extraValue","p":1310721}],"n":".ctor","o":"$ctor$7","d":2136212,"h":73016580244,"f":1}],"h":2136212}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.UriBuilder`; }
        });
        
        $asm.$cls("$spu.System.Net.IPv4AddressHelper", ($self) => class IPv4AddressHelper
        {
            static /*string */ ParseCanonicalName(/*string*/ str, /*int*/ start, /*int*/ end, /*ref bool*/ isLoopback)
            {
                /*int*/ let changedEnd = end;
                /*long*/ let result;
                {
                    /*fixed*/ 
                    {
                        /*char**/ let ipString = $.$spc.System.String.GetPinnableReference.call(str);
                        result = $.$spu.System.Net.IPv4AddressHelper.ParseNonCanonical($.$spc.System.Char, ipString, start, $.$ref(() => changedEnd, ($v) => changedEnd = $v, $.$spc.System.Int32), true);
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$2(result !== -1n, `Failed to parse after already validated: ${str}`);
                /*Span<byte>*/ let numbers = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), [$.$cast((result >> 24n), $.$spc.System.Byte), $.$cast((result >> 16n), $.$spc.System.Byte), $.$cast((result >> 8n), $.$spc.System.Byte), $.$cast((result), $.$spc.System.Byte)], null, null));
                isLoopback.$v = numbers.get_Item(0).$v === 127;
                /*Span<char>*/ let stackSpace = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, ((((4/*NumberOfLabels*/ * 3) | 0) + 3) | 0), null);
                /*int*/ let totalChars = 0, charsWritten;
                for(/*int*/ let i = 0; i < ((4/*NumberOfLabels*/ - 1) | 0); i++)
                {
                    $.$spc.System.Byte.TryFormat.call(numbers.get_Item(i).$v, stackSpace.Slice(totalChars), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))(), null);
                    /*int*/ let periodPos = ((totalChars + charsWritten) | 0);
                    stackSpace.get_Item(periodPos).$v = /*.*/ 46;
                    totalChars = ((periodPos + 1) | 0);
                }
                $.$spc.System.Byte.TryFormat.call(numbers.get_Item(3).$v, stackSpace.Slice(totalChars), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))(), null);
                return $.$spc.System.String.Create($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(stackSpace.Slice$1(0, ((totalChars + charsWritten) | 0))));
            }
            /*long*/ static Invalid = -1n;
            /*long*/ static MaxIPv4Value = 4294967295n;
            /*int*/ static Octal = 8;
            /*int*/ static Decimal = 10;
            /*int*/ static Hex = 16;
            /*int*/ static NumberOfLabels = 4;
            static /*ushort */ ToUShort(TChar, /*TChar*/ value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                return $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) ? $.$cast($.$box(value, TChar), $.$spc.System.Char) : $.$cast($.$box(value, TChar), $.$spc.System.Byte);
            }
            static /*int */ ParseHostNumber(TChar, /*ReadOnlySpan<TChar>*/ str, /*int*/ start, /*int*/ end)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*Span<byte>*/ let numbers = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 4/*NumberOfLabels*/, null);
                for(/*int*/ let i = 0; i < numbers.Length; ++i)
                {
                    /*int*/ let b = 0;
                    /*int*/ let ch;
                    for(; (start < end) && (ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, str.get_Item(start).$v)) !== /*.*/ 46 && ch !== /*:*/ 58; ++start)
                    {
                        b = (((((((b * 10) | 0)) + ch) | 0) - /*0*/ 48) | 0);
                    }
                    numbers.get_Item(i).$v = $.$cast(b, $.$spc.System.Byte);
                    ++start;
                }
                return $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadInt32BigEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(numbers));
            }
            static /*bool */ IsValid(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ allowIPv6, /*bool*/ notImplicitFile, /*bool*/ unknownScheme)
            {
                if (allowIPv6 || unknownScheme)
                {
                    return $.$spu.System.Net.IPv4AddressHelper.IsValidCanonical(TChar, name, start, end, allowIPv6, notImplicitFile);
                }
                else 
                {
                    return $.$spu.System.Net.IPv4AddressHelper.ParseNonCanonical(TChar, name, start, end, notImplicitFile) !== -1n;
                }
            }
            static /*bool */ IsValidCanonical(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ allowIPv6, /*bool*/ notImplicitFile)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let dots = 0;
                /*long*/ let number = 0n;
                /*bool*/ let haveNumber = false;
                /*bool*/ let firstCharIsZero = false;
                while(start < end.$v)
                {
                    /*int*/ let ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(start));
                    if (allowIPv6)
                    {
                        if (ch === /*]*/ 93 || ch === /*/*/ 47 || ch === /*%*/ 37)
                        {
                            break;
                        }
                    }
                    else if (ch === /*/*/ 47 || ch === /*\\*/ 92 || (notImplicitFile && (ch === /*:*/ 58 || ch === /*?*/ 63 || ch === /*#*/ 35)))
                    {
                        break;
                    }
                    /*uint*/ let parsedCharacter = ((((ch - /*0*/ 48) | 0)) >>> 0);
                    if (parsedCharacter < 10/*IPv4AddressHelper.Decimal*/)
                    {
                        if (!haveNumber && parsedCharacter === 0)
                        {
                            if ((((start + 1) | 0) < end.$v) && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((start + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*0*/ 48)))
                            {
                                return false;
                            }
                            firstCharIsZero = true;
                        }
                        haveNumber = true;
                        number = number * BigInt(10/*IPv4AddressHelper.Decimal*/) + BigInt(parsedCharacter);
                        if (number > BigInt(255/*byte.MaxValue*/))
                        {
                            return false;
                        }
                    }
                    else if (ch === /*.*/ 46)
                    {
                        if (!haveNumber || (number > 0n && firstCharIsZero))
                        {
                            return false;
                        }
                        ++dots;
                        haveNumber = false;
                        number = 0n;
                        firstCharIsZero = false;
                    }
                    else 
                    {
                        return false;
                    }
                    ++start;
                }
                /*bool*/ let res = (dots === 3) && haveNumber;
                if (res)
                {
                    end.$v = start;
                }
                return res;
            }
            static /*long */ ParseNonCanonical(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ notImplicitFile)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let numberBase = 10/*IPv4AddressHelper.Decimal*/;
                /*int*/ let ch = 0;
                /*Span<long>*/ let parts = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Int64, 3, null);
                /*long*/ let currentValue = 0n;
                /*bool*/ let atLeastOneChar = false;
                /*int*/ let dotCount = 0;
                /*int*/ let current = start;
                for(; current < end.$v; current++)
                {
                    ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                    currentValue = 0n;
                    numberBase = 10/*IPv4AddressHelper.Decimal*/;
                    if (ch === /*0*/ 48)
                    {
                        current++;
                        atLeastOneChar = true;
                        if (current < end.$v)
                        {
                            ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                            if (ch === /*x*/ 120 || ch === /*X*/ 88)
                            {
                                numberBase = 16/*IPv4AddressHelper.Hex*/;
                                current++;
                                atLeastOneChar = false;
                            }
                            else 
                            {
                                numberBase = 8/*IPv4AddressHelper.Octal*/;
                            }
                        }
                    }
                    for(; current < end.$v; current++)
                    {
                        ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                        /*int*/ let digitValue = $.$spu.System.HexConverter.FromChar(ch);
                        if (digitValue >= numberBase)
                        {
                            break;
                        }
                        currentValue = (currentValue * BigInt(numberBase)) + BigInt(digitValue);
                        if (currentValue > 4294967295n)
                        {
                            return -1n;
                        }
                        atLeastOneChar = true;
                    }
                    if (current < end.$v && ch === /*.*/ 46)
                    {
                        if (dotCount >= 3 || !atLeastOneChar || currentValue > 255n)
                        {
                            return -1n;
                        }
                        parts.get_Item(dotCount).$v = currentValue;
                        dotCount++;
                        atLeastOneChar = false;
                        continue;
                    }
                    break;
                }
                if (!atLeastOneChar)
                {
                    return -1n;
                }
                else if (current >= end.$v)
                {
                }
                else if (ch === /*/*/ 47 || ch === /*\\*/ 92 || (notImplicitFile && (ch === /*:*/ 58 || ch === /*?*/ 63 || ch === /*#*/ 35)))
                {
                    end.$v = current;
                }
                else 
                {
                    return -1n;
                }
                switch(dotCount)
                {
                    case 0:
                    return currentValue;
                    case 1:
                    $.$spc.System.Diagnostics.Debug.Assert$1(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    if (currentValue > 16777215n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | currentValue;
                    case 2:
                    $.$spc.System.Diagnostics.Debug.Assert$1(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    $.$spc.System.Diagnostics.Debug.Assert$1(parts.get_Item(1).$v <= 255n, "parts[1] <= 0xFF");
                    if (currentValue > 65535n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | (BigInt.asIntN(64, parts.get_Item(1).$v << 16n)) | currentValue;
                    case 3:
                    $.$spc.System.Diagnostics.Debug.Assert$1(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    $.$spc.System.Diagnostics.Debug.Assert$1(parts.get_Item(1).$v <= 255n, "parts[1] <= 0xFF");
                    $.$spc.System.Diagnostics.Debug.Assert$1(parts.get_Item(2).$v <= 255n, "parts[2] <= 0xFF");
                    if (currentValue > 255n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | (BigInt.asIntN(64, parts.get_Item(1).$v << 16n)) | (BigInt.asIntN(64, parts.get_Item(2).$v << 8n)) | currentValue;
                    default:
                    return -1n;
                }
            }
            static $h = 956564;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"str","p":1310721},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"isLoopback","p":262145,"f":4}],"n":"ParseCanonicalName","d":956564,"h":4295923860,"f":40},{"r":589825,"p":[{"n":"value","p":(TChar) => TChar.$h}],"g":["TChar"],"n":"ToUShort","d":956564,"h":34360694932,"f":131112},{"r":655361,"p":[{"n":"str","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"start","p":655361},{"n":"end","p":655361}],"g":["TChar"],"n":"ParseHostNumber","d":956564,"h":38655662228,"f":131112},{"r":262145,"p":[{"n":"name","p":0},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"allowIPv6","p":262145},{"n":"notImplicitFile","p":262145},{"n":"unknownScheme","p":262145}],"g":["TChar"],"n":"IsValid","d":956564,"h":42950629524,"f":131112},{"r":262145,"p":[{"n":"name","p":0},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"allowIPv6","p":262145},{"n":"notImplicitFile","p":262145}],"g":["TChar"],"n":"IsValidCanonical","d":956564,"h":47245596820,"f":131112},{"r":917505,"p":[{"n":"name","p":0},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"notImplicitFile","p":262145}],"g":["TChar"],"n":"ParseNonCanonical","d":956564,"h":51540564116,"f":131112}],"l":[{"t":917505,"n":"Invalid","d":956564,"h":8590891156,"f":40},{"t":917505,"n":"MaxIPv4Value","d":956564,"h":12885858452,"f":34},{"t":655361,"n":"Octal","d":956564,"h":17180825748,"f":34},{"t":655361,"n":"Decimal","d":956564,"h":21475793044,"f":34},{"t":655361,"n":"Hex","d":956564,"h":25770760340,"f":34},{"t":655361,"n":"NumberOfLabels","d":956564,"h":30065727636,"f":34}],"h":956564}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.IPv4AddressHelper`; }
        });
        
        $asm.$cls("$spu.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$spu.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Private.Uri", $.$spu.System.SR.$type.Assembly);
                    $.$spu.System.SR.s_resourceManager = temp;
                }
                return $.$spu.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$spu.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$spu.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_AddingDuplicate()
            {
                return "An item with the same key has already been added. Key: {0}";
            }
            static /*string */ FormatArgument_AddingDuplicate(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("An item with the same key has already been added. Key: {0}", arg1);
            }
            static /*string */ get net_uri_BadAuthority()
            {
                return "Invalid URI: The Authority/Host could not be parsed.";
            }
            static /*string */ get net_uri_BadAuthorityTerminator()
            {
                return "Invalid URI: The Authority/Host cannot end with a backslash character ('\\\\').";
            }
            static /*string */ get net_uri_BadFormat()
            {
                return "Invalid URI: The format of the URI could not be determined.";
            }
            static /*string */ get net_uri_NeedFreshParser()
            {
                return "The URI parser instance passed into 'uriParser' parameter is already registered with the scheme name '{0}'.";
            }
            static /*string */ Formatnet_uri_NeedFreshParser(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The URI parser instance passed into 'uriParser' parameter is already registered with the scheme name '{0}'.", arg1);
            }
            static /*string */ get net_uri_AlreadyRegistered()
            {
                return "A URI scheme name '{0}' already has a registered custom parser.";
            }
            static /*string */ Formatnet_uri_AlreadyRegistered(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("A URI scheme name '{0}' already has a registered custom parser.", arg1);
            }
            static /*string */ get net_uri_BadHostName()
            {
                return "Invalid URI: The hostname could not be parsed.";
            }
            static /*string */ get net_uri_BadPort()
            {
                return "Invalid URI: Invalid port specified.";
            }
            static /*string */ get net_uri_BadScheme()
            {
                return "Invalid URI: The URI scheme is not valid.";
            }
            static /*string */ get net_uri_BadUserPassword()
            {
                return "Invalid URI: The username:password construct is badly formed.";
            }
            static /*string */ get net_uri_CannotCreateRelative()
            {
                return "A relative URI cannot be created because the 'uriString' parameter represents an absolute URI.";
            }
            static /*string */ get net_uri_SchemeLimit()
            {
                return "Invalid URI: The Uri scheme is too long.";
            }
            static /*string */ get net_uri_EmptyUri()
            {
                return "Invalid URI: The URI is empty.";
            }
            static /*string */ get net_uri_InvalidUriKind()
            {
                return "The value '{0}' passed for the UriKind parameter is invalid.";
            }
            static /*string */ Formatnet_uri_InvalidUriKind(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The value '{0}' passed for the UriKind parameter is invalid.", arg1);
            }
            static /*string */ get net_uri_MustRootedPath()
            {
                return "Invalid URI: A Dos path must be rooted, for example, 'c:\\\\'.";
            }
            static /*string */ get net_uri_NotAbsolute()
            {
                return "This operation is not supported for a relative URI.";
            }
            static /*string */ get net_uri_PortOutOfRange()
            {
                return "A derived type '{0}' has reported an invalid value for the Uri port '{1}'.";
            }
            static /*string */ Formatnet_uri_PortOutOfRange(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("A derived type '{0}' has reported an invalid value for the Uri port '{1}'.", arg1, arg2);
            }
            static /*string */ get net_uri_UserDrivenParsing()
            {
                return "A derived type '{0}' is responsible for parsing this Uri instance. The base implementation must not be used.";
            }
            static /*string */ Formatnet_uri_UserDrivenParsing(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("A derived type '{0}' is responsible for parsing this Uri instance. The base implementation must not be used.", arg1);
            }
            static /*string */ get net_uri_NotJustSerialization()
            {
                return "UriComponents.SerializationInfoString must not be combined with other UriComponents.";
            }
            static /*string */ get net_uri_BadUnicodeHostForIdn()
            {
                return "An invalid Unicode character by IDN standards was specified in the host.";
            }
            static /*string */ get Argument_ExtraNotValid()
            {
                return "Extra portion of URI not valid.";
            }
            static /*string */ get Argument_InvalidUriSubcomponent()
            {
                return "The subcomponent, {0}, of this uri is not valid.";
            }
            static /*string */ FormatArgument_InvalidUriSubcomponent(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The subcomponent, {0}, of this uri is not valid.", arg1);
            }
            static /*string */ get Arg_KeyNotFoundWithKey()
            {
                return "The given key '{0}' was not present in the dictionary.";
            }
            static /*string */ FormatArg_KeyNotFoundWithKey(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The given key '{0}' was not present in the dictionary.", arg1);
            }
            static /*string */ get InvalidNullArgument()
            {
                return "Null is not a valid value for {0}.";
            }
            static /*string */ FormatInvalidNullArgument(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Null is not a valid value for {0}.", arg1);
            }
            static /*string */ get net_uri_InitializeCalledAlreadyOrTooLate()
            {
                return "UriParser's base InitializeAndValidate may only be called once on a single Uri instance and only from an override of InitializeAndValidate.";
            }
            static /*string */ get net_uri_GetComponentsCalledWhenCanonicalizationDisabled()
            {
                return "GetComponents() may not be used for Path/Query on a Uri instance created with UriCreationOptions.DangerousDisablePathAndQueryCanonicalization.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$spu.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$spu.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$spu.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$spu.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$spu.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$spu.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1480852;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1480852}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$spu.System.UncNameHelper", ($self) => class UncNameHelper
        {
            /*int*/ static MaximumInternetNameLength = 256;
            static /*string */ ParseCanonicalName(/*string*/ str, /*int*/ start, /*int*/ end, /*ref bool*/ loopback)
            {
                return $.$spu.System.DomainNameHelper.ParseCanonicalName(str, start, end, loopback);
            }
            static /*bool */ IsValid(/*char**/ name, /*int*/ start, /*ref int*/ returnedEnd, /*bool*/ notImplicitFile)
            {
                /*int*/ let end = returnedEnd.$v;
                if (start === end)
                {
                    return false;
                }
                /*bool*/ let validShortName = false;
                /*int*/ let i = start;
                for(; i < end; ++i)
                {
                    if (name.GetAt(i) === /*/*/ 47 || name.GetAt(i) === /*\\*/ 92 || (notImplicitFile && (name.GetAt(i) === /*:*/ 58 || name.GetAt(i) === /*?*/ 63 || name.GetAt(i) === /*#*/ 35)))
                    {
                        end = i;
                        break;
                    }
                    else if (name.GetAt(i) === /*.*/ 46)
                    {
                        ++i;
                        break;
                    }
                    if ($.$spc.System.Char.IsLetter(name.GetAt(i)) || name.GetAt(i) === /*-*/ 45 || name.GetAt(i) === /*_*/ 95)
                    {
                        validShortName = true;
                    }
                    else if (!$.$spc.System.Char.IsAsciiDigit(name.GetAt(i)))
                    {
                        return false;
                    }
                }
                if (!validShortName)
                {
                    return false;
                }
                for(; i < end; ++i)
                {
                    if (name.GetAt(i) === /*/*/ 47 || name.GetAt(i) === /*\\*/ 92 || (notImplicitFile && (name.GetAt(i) === /*:*/ 58 || name.GetAt(i) === /*?*/ 63 || name.GetAt(i) === /*#*/ 35)))
                    {
                        end = i;
                        break;
                    }
                    else if (name.GetAt(i) === /*.*/ 46)
                    {
                        if (!validShortName || ((((i - 1) | 0)) >= start && name.GetAt(((i - 1) | 0)) === /*.*/ 46))
                        {
                            return false;
                        }
                        validShortName = false;
                    }
                    else if (name.GetAt(i) === /*-*/ 45 || name.GetAt(i) === /*_*/ 95)
                    {
                        if (!validShortName)
                        {
                            return false;
                        }
                    }
                    else if ($.$spc.System.Char.IsLetter(name.GetAt(i)) || $.$spc.System.Char.IsAsciiDigit(name.GetAt(i)))
                    {
                        if (!validShortName)
                        {
                            validShortName = true;
                        }
                    }
                    else 
                    {
                        return false;
                    }
                }
                if ((((i - 1) | 0)) >= start && name.GetAt(((i - 1) | 0)) === /*.*/ 46)
                {
                    validShortName = true;
                }
                if (!validShortName)
                {
                    return false;
                }
                returnedEnd.$v = end;
                return true;
            }
            static $h = 1611924;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"str","p":1310721},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"loopback","p":262145,"f":4}],"n":"ParseCanonicalName","d":1611924,"h":8591546516,"f":33},{"r":262145,"p":[{"n":"name","p":0},{"n":"start","p":655361},{"n":"returnedEnd","p":655361,"f":4},{"n":"notImplicitFile","p":262145}],"n":"IsValid","d":1611924,"h":12886513812,"f":33}],"l":[{"t":655361,"n":"MaximumInternetNameLength","d":1611924,"h":4296579220,"f":33}],"h":1611924}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.UncNameHelper`; }
        });
        
        $asm.$cls("$spu.System.PercentEncodingHelper", ($self) => class PercentEncodingHelper
        {
            static /*int */ UnescapePercentEncodedUTF8Sequence(/*char**/ input, /*int*/ length, /*ref ValueStringBuilder*/ dest, /*bool*/ isQuery, /*bool*/ iriParsing)
            {
                /*uint*/ let fourByteBuffer;
                /*int*/ let bytesLeftInBuffer;
                /*int*/ let totalCharsConsumed;
                /*int*/ let charsToCopy;
                /*int*/ let bytesConsumed;
                /*uint*/ let value;
                /*uint*/ let second;
                /*uint*/ let temp;
                /*int*/ let i;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(length >= 3, "length >= 3");
                            $.$spc.System.Diagnostics.Debug.Assert$1(input.GetAt(0) === /*%*/ 37, "input[0] == '%'");
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spu.System.UriHelper.DecodeHexChars(input.GetAt(1), input.GetAt(2)) !== /*\uFFFF*/ 65535, "UriHelper.DecodeHexChars(input[1], input[2]) != Uri.c_DummyChar");
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spu.System.UriHelper.DecodeHexChars(input.GetAt(1), input.GetAt(2)) >= 128, "UriHelper.DecodeHexChars(input[1], input[2]) >= 128");
                            fourByteBuffer = 0;
                            bytesLeftInBuffer = 0;
                            totalCharsConsumed = 0;
                            charsToCopy = 0;
                            bytesConsumed = 0;
                        }
                        case 1: /*RefillBuffer*/
                        i = ((totalCharsConsumed + (((bytesLeftInBuffer * 3) | 0))) | 0);
                        case 2: /*ReadByteFromInput*/
                        if (((((length - i) | 0)) >>> 0) <= 2 || input.GetAt(i) !== /*%*/ 37)
                        {
                            $gotoJumpState1 = 5; /*goto NoMoreOrInvalidInput*/
                            continue $gotoJumpStart1;
                        }
                        value = input.GetAt(((i + 1) | 0));
                        if ($.$cast(((BigInt(value - /*A*/ 65)) & BigInt(~32)), $.$spc.System.UInt32) <= (/*F*/ 70 - /*A*/ 65))
                        {
                            value = (((((value | 32) - /*a*/ 97) >>> 0) + 10) >>> 0);
                        }
                        else if ((((value - /*8*/ 56) >>> 0)) <= (/*9*/ 57 - /*8*/ 56))
                        {
                            value -= /*0*/ 48;
                        }
                        else 
                        {
                            $gotoJumpState1 = 5; /*goto NoMoreOrInvalidInput*/
                            continue $gotoJumpStart1;
                        }
                        second = ((input.GetAt(((i + 2) | 0)) - /*0*/ 48) >>> 0);
                        if (second <= 9)
                        {
                        }
                        else if ($.$cast(((BigInt(second - (/*A*/ 65 - /*0*/ 48))) & BigInt(~32)), $.$spc.System.UInt32) <= (/*F*/ 70 - /*A*/ 65))
                        {
                            second = ((((((((second + /*0*/ 48) >>> 0)) | 32) - /*a*/ 97) >>> 0) + 10) >>> 0);
                        }
                        else 
                        {
                            $gotoJumpState1 = 5; /*goto NoMoreOrInvalidInput*/
                            continue $gotoJumpStart1;
                        }
                        value = ((value << 4) >>> 0) | second;
                        $.$spc.System.Diagnostics.Debug.Assert$1(value >= 128, "value >= 128");
                        if ($.$spc.System.BitConverter.IsLittleEndian)
                        {
                            fourByteBuffer = (fourByteBuffer >>> 8) | ((value << 24) >>> 0);
                        }
                        else 
                        {
                            fourByteBuffer = ((fourByteBuffer << 8) >>> 0) | value;
                        }
                        if (++bytesLeftInBuffer !== 4)
                        {
                            i += 3;
                            $gotoJumpState1 = 2; /*goto ReadByteFromInput*/
                            continue $gotoJumpStart1;
                        }
                        case 3: /*DecodeRune*/
                        $.$spc.System.Diagnostics.Debug.Assert$1(totalCharsConsumed % 3 === 0, "totalCharsConsumed % 3 == 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(bytesLeftInBuffer === 2 || bytesLeftInBuffer === 3 || bytesLeftInBuffer === 4, "bytesLeftInBuffer == 2 || bytesLeftInBuffer == 3 || bytesLeftInBuffer == 4");
                        $.$spc.System.Diagnostics.Debug.Assert$1((fourByteBuffer & ($.$spc.System.BitConverter.IsLittleEndian ? 128 : 2147483648)) !== 0, "(fourByteBuffer & (BitConverter.IsLittleEndian ? 0x00000080 : 0x80000000)) != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1((BigInt(fourByteBuffer) & (BigInt($.$spc.System.BitConverter.IsLittleEndian ? 32768 : 8388608))) !== 0n, "(fourByteBuffer & (BitConverter.IsLittleEndian ? 0x00008000 : 0x00800000)) != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(bytesLeftInBuffer < 3 || (BigInt(fourByteBuffer) & (BigInt($.$spc.System.BitConverter.IsLittleEndian ? 8388608 : 32768))) !== 0n, "bytesLeftInBuffer < 3 || (fourByteBuffer & (BitConverter.IsLittleEndian ? 0x00800000 : 0x00008000)) != 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(bytesLeftInBuffer < 4 || (fourByteBuffer & ($.$spc.System.BitConverter.IsLittleEndian ? 2147483648 : 128)) !== 0, "bytesLeftInBuffer < 4 || (fourByteBuffer & (BitConverter.IsLittleEndian ? 0x80000000 : 0x00000080)) != 0");
                        temp = fourByteBuffer;
                        /*Rune*/ let rune;
                        if ($.$spc.System.Text.Rune.DecodeFromUtf8(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$4($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.UInt32, () => temp, ($v) => temp = $v, null), bytesLeftInBuffer), $.$ref(() => rune, ($v) => rune = $v, $.$spc.System.Text.Rune), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$spc.System.Int32)) === 0/*OperationStatus.Done*/)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$2(bytesConsumed >= 2, `Rune.DecodeFromUtf8 consumed ${bytesConsumed} bytes, likely indicating input was modified concurrently during UnescapePercentEncodedUTF8Sequence's execution`);
                            if (!iriParsing || $.$spu.System.IriHelper.CheckIriUnicodeRange$2((rune.Value >>> 0), isQuery))
                            {
                                if (charsToCopy !== 0)
                                {
                                    dest.$v.Append$4(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(input.Add(totalCharsConsumed).Add(-charsToCopy), charsToCopy));
                                    charsToCopy = 0;
                                }
                                dest.$v.Append(rune);
                                $gotoJumpState1 = 4; /*goto AfterDecodeRune*/
                                continue $gotoJumpStart1;
                            }
                        }
                        else 
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$2(bytesConsumed > 0, `Rune.DecodeFromUtf8 consumed ${bytesConsumed} bytes when decoding ${bytesLeftInBuffer} bytes`);
                        }
                        charsToCopy += ((bytesConsumed * 3) | 0);
                        case 4: /*AfterDecodeRune*/
                        bytesLeftInBuffer -= bytesConsumed;
                        totalCharsConsumed += ((bytesConsumed * 3) | 0);
                        $gotoJumpState1 = 1; /*goto RefillBuffer*/
                        continue $gotoJumpStart1;
                        case 5: /*NoMoreOrInvalidInput*/
                        $.$spc.System.Diagnostics.Debug.Assert$1(bytesLeftInBuffer < 4, "bytesLeftInBuffer < 4");
                        if (bytesLeftInBuffer > 1)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(bytesLeftInBuffer === 2 || bytesLeftInBuffer === 3, "bytesLeftInBuffer == 2 || bytesLeftInBuffer == 3");
                            if (bytesConsumed === 1)
                            {
                                if ($.$spc.System.BitConverter.IsLittleEndian)
                                {
                                    fourByteBuffer >>= 8;
                                }
                                else 
                                {
                                    fourByteBuffer <<= 8;
                                }
                            }
                            else 
                            {
                                if ($.$spc.System.BitConverter.IsLittleEndian)
                                {
                                    fourByteBuffer >>= (((32 - (bytesLeftInBuffer << 3)) | 0));
                                }
                                else 
                                {
                                    fourByteBuffer <<= (((32 - (bytesLeftInBuffer << 3)) | 0));
                                }
                            }
                            $gotoJumpState1 = 3; /*goto DecodeRune*/
                            continue $gotoJumpStart1;
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(bytesLeftInBuffer === 0 || bytesLeftInBuffer === 1, "bytesLeftInBuffer == 0 || bytesLeftInBuffer == 1");
                        if ((bytesLeftInBuffer | charsToCopy) === 0)
                        {
                            return totalCharsConsumed;
                        }
                        bytesLeftInBuffer *= 3;
                        dest.$v.Append$4(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(input.Add(totalCharsConsumed).Add(-charsToCopy), ((charsToCopy + bytesLeftInBuffer) | 0)));
                        return ((totalCharsConsumed + bytesLeftInBuffer) | 0);
                    }
                    break;
                }
            }
            static $h = 1415316;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"input","p":0},{"n":"length","p":655361},{"n":"dest","p":1546388,"f":4},{"n":"isQuery","p":262145},{"n":"iriParsing","p":262145}],"n":"UnescapePercentEncodedUTF8Sequence","d":1415316,"h":4296382612,"f":33}],"h":1415316}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.PercentEncodingHelper`; }
        });
        
        $asm.$cls("$spu.System.Net.IPv6AddressHelper", ($self) => class IPv6AddressHelper
        {
            /*int*/ static Hex = 16;
            /*int*/ static NumberOfLabels = 8;
            static /*(int longestSequenceStart, int longestSequenceLength) */ FindCompressionRange(/*ReadOnlySpan<ushort>*/ numbers)
            {
                /*int*/ let longestSequenceLength = 0, longestSequenceStart = -1, currentSequenceLength = 0;
                for(/*int*/ let i = 0; i < numbers.Length; i++)
                {
                    if (numbers.get_Item(i).$v === 0)
                    {
                        currentSequenceLength++;
                        if (currentSequenceLength > longestSequenceLength)
                        {
                            longestSequenceLength = currentSequenceLength;
                            longestSequenceStart = ((((i - currentSequenceLength) | 0) + 1) | 0);
                        }
                    }
                    else 
                    {
                        currentSequenceLength = 0;
                    }
                }
                return longestSequenceLength > 1 ? new ($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32))().$ctor$2(longestSequenceStart, ((longestSequenceStart + longestSequenceLength) | 0)) : new ($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32))().$ctor$2(-1, 0);
            }
            static /*bool */ ShouldHaveIpv4Embedded(/*ReadOnlySpan<ushort>*/ numbers)
            {
                if (numbers.get_Item(0).$v === 0 && numbers.get_Item(1).$v === 0 && numbers.get_Item(2).$v === 0 && numbers.get_Item(3).$v === 0 && numbers.get_Item(6).$v !== 0)
                {
                    if (numbers.get_Item(4).$v === 0 && (numbers.get_Item(5).$v === 0 || numbers.get_Item(5).$v === 65535))
                    {
                        return true;
                    }
                    else if (numbers.get_Item(4).$v === 65535 && numbers.get_Item(5).$v === 0)
                    {
                        return true;
                    }
                }
                return numbers.get_Item(4).$v === 0 && numbers.get_Item(5).$v === 24318;
            }
            static /*bool */ IsValidStrict(TChar, /*TChar**/ name, /*int*/ start, /*int*/ end)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let sequenceCount = 0;
                /*int*/ let sequenceLength = 0;
                /*bool*/ let haveCompressor = false;
                /*bool*/ let haveIPv4Address = false;
                /*bool*/ let expectingNumber = true;
                /*int*/ let lastSequence = 1;
                /*bool*/ let needsClosingBracket = false;
                if (start < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(start), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*[*/ 91)))
                {
                    start++;
                    needsClosingBracket = true;
                    $.$spc.System.Diagnostics.Debug.Assert$1(start < end, "start < end");
                }
                if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(start), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58)) && (((start + 1) | 0) >= end || TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(name.GetAt(((start + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58))))
                {
                    return false;
                }
                /*int*/ let i;
                for(i = start; i < end; ++i)
                {
                    /*int*/ let currentCh = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i));
                    if ($.$spu.System.HexConverter.IsHexChar(currentCh))
                    {
                        ++sequenceLength;
                        expectingNumber = false;
                    }
                    else 
                    {
                        if (sequenceLength > 4)
                        {
                            return false;
                        }
                        if (sequenceLength !== 0)
                        {
                            ++sequenceCount;
                            lastSequence = ((i - sequenceLength) | 0);
                            sequenceLength = 0;
                        }
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? currentCh)
                            {
                                case /*%*/ 37:
                                while(((i + 1) | 0) < end)
                                {
                                    i++;
                                    if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(i), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*]*/ 93)))
                                    {
                                        $switchJumpState1 = /*]*/ 93; /*goto case ']'*/
                                        continue $switchJumpStart1;
                                    }
                                    else if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(i), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*/*/ 47)))
                                    {
                                        $switchJumpState1 = /*/*/ 47; /*goto case '/'*/
                                        continue $switchJumpStart1;
                                    }
                                }
                                break;
                                case /*]*/ 93:
                                if (!needsClosingBracket)
                                {
                                    return false;
                                }
                                needsClosingBracket = false;
                                if (((i + 1) | 0) < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(name.GetAt(((i + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58)))
                                {
                                    return false;
                                }
                                if (((i + 3) | 0) < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i + 2) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*0*/ 48)) && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i + 3) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*x*/ 120)))
                                {
                                    i += 4;
                                    for(; i < end; i++)
                                    {
                                        /*int*/ let ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i));
                                        if (!$.$spu.System.HexConverter.IsHexChar(ch))
                                        {
                                            return false;
                                        }
                                    }
                                }
                                else 
                                {
                                    i += 2;
                                    for(; i < end; i++)
                                    {
                                        if (!$.$spc.System.Char.IsAsciiDigit($.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i))))
                                        {
                                            return false;
                                        }
                                    }
                                }
                                continue;
                                case /*:*/ 58:
                                if ((i > 0) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i - 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58))))
                                {
                                    if (haveCompressor)
                                    {
                                        return false;
                                    }
                                    haveCompressor = true;
                                    expectingNumber = false;
                                }
                                else 
                                {
                                    expectingNumber = true;
                                }
                                break;
                                case /*/*/ 47:
                                return false;
                                case /*.*/ 46:
                                if (haveIPv4Address)
                                {
                                    return false;
                                }
                                i = end;
                                if (!$.$spu.System.Net.IPv4AddressHelper.IsValid(TChar, name, lastSequence, $.$ref(() => i, ($v) => i = $v, $.$spc.System.Int32), true, false, false))
                                {
                                    return false;
                                }
                                ++sequenceCount;
                                lastSequence = ((i - sequenceLength) | 0);
                                sequenceLength = 0;
                                haveIPv4Address = true;
                                --i;
                                break;
                                default:
                                return false;
                            }
                            break;
                        }
                        sequenceLength = 0;
                    }
                }
                if (sequenceLength !== 0)
                {
                    if (sequenceLength > 4)
                    {
                        return false;
                    }
                    ++sequenceCount;
                }
                /*int*/ let ExpectedSequenceCount = 8;
                return !expectingNumber && (haveCompressor ? (sequenceCount < ExpectedSequenceCount) : (sequenceCount === ExpectedSequenceCount)) && !needsClosingBracket;
            }
            static /*void */ Parse(TChar, /*ReadOnlySpan<TChar>*/ address, /*scoped Span<ushort>*/ numbers, /*out ReadOnlySpan<TChar>*/ scopeId)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let number = 0;
                /*int*/ let currentCh;
                /*int*/ let index = 0;
                /*int*/ let compressorIndex = -1;
                /*bool*/ let numberIsValid = true;
                scopeId.$v = $.$spc.System.ReadOnlySpan$$(TChar).Empty;
                for(/*int*/ let i = (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(0).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*[*/ 91)) ? 1 : 0); i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*]*/ 93)); )
                {
                    currentCh = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, address.get_Item(i).$v);
                    switch(currentCh)
                    {
                        case /*%*/ 37:
                        if (numberIsValid)
                        {
                            numbers.get_Item(index++).$v = $.$cast(number, $.$spc.System.UInt16);
                            numberIsValid = false;
                        }
                        /*int*/ let scopeStart = i;
                        for(++i; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*]*/ 93)) && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*/*/ 47)); ++i)
                        {
                        }
                        scopeId.$v = address.Slice$1(scopeStart, ((i - scopeStart) | 0));
                        for(; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*]*/ 93)); ++i)
                        {
                        }
                        break;
                        case /*:*/ 58:
                        numbers.get_Item(index++).$v = $.$cast(number, $.$spc.System.UInt16);
                        number = 0;
                        ++i;
                        if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58)))
                        {
                            compressorIndex = index;
                            ++i;
                        }
                        else if ((compressorIndex < 0) && (index < 6))
                        {
                            break;
                        }
                        for(/*int*/ let j = i; j < address.Length && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*]*/ 93))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*%*/ 37))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*/*/ 47))) && (j < ((i + 4) | 0)); ++j)
                        {
                            if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*.*/ 46)))
                            {
                                while(j < address.Length && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*]*/ 93))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*/*/ 47))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*%*/ 37))))
                                {
                                    ++j;
                                }
                                /*int*/ let ipv4Address = $.$spu.System.Net.IPv4AddressHelper.ParseHostNumber(TChar, address, i, j);
                                numbers.get_Item(index++).$v = $.$cast((ipv4Address >> 16), $.$spc.System.UInt16);
                                numbers.get_Item(index++).$v = $.$cast((ipv4Address & 65535), $.$spc.System.UInt16);
                                i = j;
                                number = 0;
                                numberIsValid = false;
                                break;
                            }
                        }
                        break;
                        case /*/*/ 47:
                        if (numberIsValid)
                        {
                            numbers.get_Item(index++).$v = $.$cast(number, $.$spc.System.UInt16);
                            numberIsValid = false;
                        }
                        for(++i; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*]*/ 93)); i++)
                        {
                        }
                        break;
                        default:
                        /*int*/ let characterValue = $.$spu.System.HexConverter.FromChar(currentCh);
                        number = ((((number * 16/*IPv6AddressHelper.Hex*/) | 0) + characterValue) | 0);
                        i++;
                        break;
                    }
                }
                if (numberIsValid)
                {
                    numbers.get_Item(index++).$v = $.$cast(number, $.$spc.System.UInt16);
                }
                if (compressorIndex > 0)
                {
                    /*int*/ let toIndex = ((8/*NumberOfLabels*/ - 1) | 0);
                    /*int*/ let fromIndex = ((index - 1) | 0);
                    if (fromIndex !== toIndex)
                    {
                        for(/*int*/ let i = ((index - compressorIndex) | 0); i > 0; --i)
                        {
                            numbers.get_Item(toIndex--).$v = numbers.get_Item(fromIndex).$v;
                            numbers.get_Item(fromIndex--).$v = 0;
                        }
                    }
                }
            }
            static /*string */ ParseCanonicalName(/*ReadOnlySpan<char>*/ str, /*ref bool*/ isLoopback, /*out ReadOnlySpan<char>*/ scopeId)
            {
                /*Span<ushort>*/ let numbers = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt16, 8/*NumberOfLabels*/, null);
                numbers.Clear();
                $.$spu.System.Net.IPv6AddressHelper.Parse($.$spc.System.Char, str, numbers, scopeId);
                isLoopback.$v = $.$spu.System.Net.IPv6AddressHelper.IsLoopback($.$spc.System.Span$$($.$spc.System.UInt16).op_Implicit$2(numbers));
                const { Item1: rangeStart, Item2: rangeEnd } = $.$spu.System.Net.IPv6AddressHelper.FindCompressionRange($.$spc.System.Span$$($.$spc.System.UInt16).op_Implicit$2(numbers));
                /*bool*/ let ipv4Embedded = $.$spu.System.Net.IPv6AddressHelper.ShouldHaveIpv4Embedded($.$spc.System.Span$$($.$spc.System.UInt16).op_Implicit$2(numbers));
                /*Span<char>*/ let stackSpace = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 48, null);
                stackSpace.get_Item(0).$v = /*[*/ 91;
                /*int*/ let pos = 1;
                /*int*/ let charsWritten;
                /*bool*/ let success;
                for(/*int*/ let i = 0; i < 8/*NumberOfLabels*/; i++)
                {
                    if (ipv4Embedded && i === (((8/*NumberOfLabels*/ - 2) | 0)))
                    {
                        stackSpace.get_Item(pos++).$v = /*:*/ 58;
                        success = $.$spc.System.Int32.TryFormat.call((numbers.get_Item(i).$v >>> 8), stackSpace.Slice(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))(), null);
                        $.$spc.System.Diagnostics.Debug.Assert$1(success, "success");
                        pos += charsWritten;
                        stackSpace.get_Item(pos++).$v = /*.*/ 46;
                        success = $.$spc.System.Int32.TryFormat.call((numbers.get_Item(i).$v & 255), stackSpace.Slice(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))(), null);
                        $.$spc.System.Diagnostics.Debug.Assert$1(success, "success");
                        pos += charsWritten;
                        stackSpace.get_Item(pos++).$v = /*.*/ 46;
                        success = $.$spc.System.Int32.TryFormat.call((numbers.get_Item(((i + 1) | 0)).$v >>> 8), stackSpace.Slice(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))(), null);
                        $.$spc.System.Diagnostics.Debug.Assert$1(success, "success");
                        pos += charsWritten;
                        stackSpace.get_Item(pos++).$v = /*.*/ 46;
                        success = $.$spc.System.Int32.TryFormat.call((numbers.get_Item(((i + 1) | 0)).$v & 255), stackSpace.Slice(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))(), null);
                        $.$spc.System.Diagnostics.Debug.Assert$1(success, "success");
                        pos += charsWritten;
                        break;
                    }
                    if (rangeStart === i)
                    {
                        stackSpace.get_Item(pos++).$v = /*:*/ 58;
                    }
                    if (rangeStart <= i && rangeEnd === 8/*NumberOfLabels*/)
                    {
                        stackSpace.get_Item(pos++).$v = /*:*/ 58;
                        break;
                    }
                    if (rangeStart <= i && i < rangeEnd)
                    {
                        continue;
                    }
                    if (i !== 0)
                    {
                        stackSpace.get_Item(pos++).$v = /*:*/ 58;
                    }
                    success = $.$spc.System.UInt16.TryFormat.call(numbers.get_Item(i).$v, stackSpace.Slice(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), $.$spc.System.String.op_Implicit("x"), null);
                    $.$spc.System.Diagnostics.Debug.Assert$1(success, "success");
                    pos += charsWritten;
                }
                stackSpace.get_Item(pos++).$v = /*]*/ 93;
                return $.$spc.System.String.Create($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(stackSpace.Slice$1(0, pos)));
            }
            static /*bool */ IsLoopback(/*ReadOnlySpan<ushort>*/ numbers)
            {
                return ((numbers.get_Item(0).$v === 0) && (numbers.get_Item(1).$v === 0) && (numbers.get_Item(2).$v === 0) && (numbers.get_Item(3).$v === 0) && (numbers.get_Item(4).$v === 0)) && (((numbers.get_Item(5).$v === 0) && (numbers.get_Item(6).$v === 0) && (numbers.get_Item(7).$v === 1)) || (((numbers.get_Item(6).$v === 32512) && (numbers.get_Item(7).$v === 1)) && ((numbers.get_Item(5).$v === 0) || (numbers.get_Item(5).$v === 65535))));
            }
            static /*bool */ InternalIsValid(/*char**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ validateStrictAddress)
            {
                /*int*/ let sequenceCount = 0;
                /*int*/ let sequenceLength = 0;
                /*bool*/ let haveCompressor = false;
                /*bool*/ let haveIPv4Address = false;
                /*bool*/ let havePrefix = false;
                /*bool*/ let expectingNumber = true;
                /*int*/ let lastSequence = 1;
                if (name.GetAt(start) === /*:*/ 58 && (((start + 1) | 0) >= end.$v || name.GetAt(((start + 1) | 0)) !== /*:*/ 58))
                {
                    return false;
                }
                /*int*/ let i;
                for(i = start; i < end.$v; ++i)
                {
                    if (havePrefix ? $.$spc.System.Char.IsAsciiDigit(name.GetAt(i)) : $.$spc.System.Char.IsAsciiHexDigit(name.GetAt(i)))
                    {
                        ++sequenceLength;
                        expectingNumber = false;
                    }
                    else 
                    {
                        if (sequenceLength > 4)
                        {
                            return false;
                        }
                        if (sequenceLength !== 0)
                        {
                            ++sequenceCount;
                            lastSequence = ((i - sequenceLength) | 0);
                        }
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            let $switch1 = $switchJumpState1 ?? (name.get_Item(i).$v);
                            switch($switch1)
                            {
                                case /*%*/ 37:
                                while(true)
                                {
                                    if (++i === end.$v)
                                    {
                                        return false;
                                    }
                                    if (name.GetAt(i) === /*]*/ 93)
                                    {
                                        $switchJumpState1 = /*]*/ 93; /*goto case ']'*/
                                        continue $switchJumpStart1;
                                    }
                                    else if (name.GetAt(i) === /*/*/ 47)
                                    {
                                        $switchJumpState1 = /*/*/ 47; /*goto case '/'*/
                                        continue $switchJumpStart1;
                                    }
                                }
                                case /*]*/ 93:
                                start = i;
                                i = end.$v;
                                continue;
                                case /*:*/ 58:
                                if ((i > 0) && (name.GetAt(((i - 1) | 0)) === /*:*/ 58))
                                {
                                    if (haveCompressor)
                                    {
                                        return false;
                                    }
                                    haveCompressor = true;
                                    expectingNumber = false;
                                }
                                else 
                                {
                                    expectingNumber = true;
                                }
                                break;
                                case /*/*/ 47:
                                if (validateStrictAddress)
                                {
                                    return false;
                                }
                                if ((sequenceCount === 0) || havePrefix)
                                {
                                    return false;
                                }
                                havePrefix = true;
                                expectingNumber = true;
                                break;
                                case /*.*/ 46:
                                if (haveIPv4Address)
                                {
                                    return false;
                                }
                                i = end.$v;
                                if (!$.$spu.System.Net.IPv4AddressHelper.IsValid($.$spc.System.Char, name, lastSequence, $.$ref(() => i, ($v) => i = $v, $.$spc.System.Int32), true, false, false))
                                {
                                    return false;
                                }
                                ++sequenceCount;
                                haveIPv4Address = true;
                                --i;
                                break;
                                default:
                                return false;
                            }
                            break;
                        }
                        sequenceLength = 0;
                    }
                }
                if (havePrefix && ((sequenceLength < 1) || (sequenceLength > 2)))
                {
                    return false;
                }
                /*int*/ let expectedSequenceCount = ((8 + (havePrefix ? 1 : 0)) | 0);
                if (!expectingNumber && (sequenceLength <= 4) && (haveCompressor ? (sequenceCount < expectedSequenceCount) : (sequenceCount === expectedSequenceCount)))
                {
                    if (i === ((end.$v + 1) | 0))
                    {
                        end.$v = ((start + 1) | 0);
                        return true;
                    }
                    return false;
                }
                return false;
            }
            static /*bool */ IsValid(/*char**/ name, /*int*/ start, /*ref int*/ end)
            {
                return $.$spu.System.Net.IPv6AddressHelper.InternalIsValid(name, start, end, false);
            }
            static $h = 1022100;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32).$h,"p":[{"n":"numbers","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt16).$h}],"n":"FindCompressionRange","d":1022100,"h":12885923988,"f":40},{"r":262145,"p":[{"n":"numbers","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt16).$h}],"n":"ShouldHaveIpv4Embedded","d":1022100,"h":17180891284,"f":40},{"r":262145,"p":[{"n":"name","p":0},{"n":"start","p":655361},{"n":"end","p":655361}],"g":["TChar"],"n":"IsValidStrict","d":1022100,"h":21475858580,"f":131112},{"r":65537,"p":[{"n":"address","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"numbers","p":$.$spc.System.Span$$($.$spc.System.UInt16).$h},{"n":"scopeId","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h,"f":2}],"g":["TChar"],"n":"Parse","d":1022100,"h":25770825876,"f":131112},{"r":1310721,"p":[{"n":"str","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"isLoopback","p":262145,"f":4},{"n":"scopeId","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"f":2}],"n":"ParseCanonicalName","d":1022100,"h":30065793172,"f":40},{"r":262145,"p":[{"n":"numbers","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt16).$h}],"n":"IsLoopback","d":1022100,"h":34360760468,"f":34},{"r":262145,"p":[{"n":"name","p":0},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"validateStrictAddress","p":262145}],"n":"InternalIsValid","d":1022100,"h":38655727764,"f":34},{"r":262145,"p":[{"n":"name","p":0},{"n":"start","p":655361},{"n":"end","p":655361,"f":4}],"n":"IsValid","d":1022100,"h":42950695060,"f":40}],"l":[{"t":655361,"n":"Hex","d":1022100,"h":4295989396,"f":34},{"t":655361,"n":"NumberOfLabels","d":1022100,"h":8590956692,"f":34}],"h":1022100}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.IPv6AddressHelper`; }
        });
        
        $asm.$cls("$spu.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 1284244;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":1284244,"h":4296251540,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":1284244,"h":8591218836,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":1284244,"h":12886186132,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":1284244,"h":17181153428,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":1284244,"h":21476120724,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":1284244,"h":25771088020,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":1284244,"h":30066055316,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":1284244,"h":34361022612,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":1284244,"h":38655989908,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":1284244,"h":42950957204,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":1284244,"h":47245924500,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":1284244,"h":51540891796,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":1284244,"h":55835859092,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":1284244,"h":60130826388,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":1284244,"h":64425793684,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":1284244,"h":68720760980,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":1284244,"h":73015728276,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":1284244,"h":77310695572,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":1284244,"h":81605662868,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":1284244,"h":85900630164,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":1284244,"h":90195597460,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":1284244,"h":94490564756,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":1284244,"h":98785532052,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":1284244,"h":103080499348,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":1284244,"h":107375466644,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":1284244,"h":111670433940,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":1284244,"h":115965401236,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":1284244,"h":120260368532,"f":40},{"t":1310721,"n":"WebRequestMessage","d":1284244,"h":124555335828,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":1284244,"h":128850303124,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":1284244,"h":133145270420,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":1284244,"h":137440237716,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":1284244,"h":141735205012,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":1284244,"h":146030172308,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":1284244,"h":150325139604,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":1284244,"h":154620106900,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":1284244,"h":158915074196,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":1284244,"h":163210041492,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":1284244,"h":167505008788,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":1284244,"h":171799976084,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":1284244,"h":176094943380,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":1284244,"h":180389910676,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":1284244,"h":184684877972,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":1284244,"h":188979845268,"f":40},{"t":1310721,"n":"RijndaelMessage","d":1284244,"h":193274812564,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":1284244,"h":197569779860,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":1284244,"h":201864747156,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":1284244,"h":206159714452,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":1284244,"h":210454681748,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":1284244,"h":214749649044,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":1284244,"h":219044616340,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":1284244,"h":223339583636,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":1284244,"h":227634550932,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":1284244,"h":231929518228,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":1284244,"h":236224485524,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":1284244,"h":240519452820,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":1284244,"h":244814420116,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":1284244,"h":249109387412,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":1284244,"h":253404354708,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":1284244,"h":257699322004,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":1284244,"h":261994289300,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":1284244,"h":266289256596,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":1284244,"h":270584223892,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":1284244,"h":274879191188,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":1284244,"h":279174158484,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":1284244,"h":283469125780,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":1284244,"h":287764093076,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":1284244,"h":292059060372,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":1284244,"h":296354027668,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":1284244,"h":300648994964,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":1284244,"h":304943962260,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":1284244,"h":309238929556,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":1284244,"h":313533896852,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":1284244,"h":317828864148,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":1284244,"h":322123831444,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":1284244,"h":326418798740,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":1284244,"h":330713766036,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":1284244,"h":335008733332,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":1284244,"h":339303700628,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":1284244,"h":343598667924,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":1284244,"h":347893635220,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":1284244,"h":352188602516,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":1284244,"h":356483569812,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":1284244,"h":360778537108,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":1284244,"h":365073504404,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":1284244,"h":369368471700,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":1284244,"h":373663438996,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":1284244,"h":377958406292,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":1284244,"h":382253373588,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":1284244,"h":386548340884,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":1284244,"h":390843308180,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":1284244,"h":395138275476,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":1284244,"h":399433242772,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":1284244,"h":403728210068,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":1284244,"h":408023177364,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":1284244,"h":412318144660,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":1284244,"h":416613111956,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":1284244,"h":420908079252,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":1284244,"h":425203046548,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":1284244,"h":429498013844,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":1284244,"h":433792981140,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":1284244,"h":438087948436,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":1284244,"h":442382915732,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":1284244,"h":446677883028,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":1284244,"h":450972850324,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":1284244,"h":455267817620,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":1284244,"h":459562784916,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":1284244,"h":463857752212,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":1284244,"h":468152719508,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":1284244,"h":472447686804,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":1284244,"h":476742654100,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":1284244,"h":481037621396,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":1284244,"h":485332588692,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":1284244,"h":489627555988,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":1284244,"h":493922523284,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":1284244,"h":498217490580,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":1284244,"h":502512457876,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":1284244,"h":506807425172,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":1284244,"h":511102392468,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":1284244,"h":515397359764,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":1284244,"h":519692327060,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":1284244,"h":523987294356,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":1284244,"h":528282261652,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":1284244,"h":532577228948,"f":40}],"h":1284244}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$spu.System.DomainNameHelper", ($self) => class DomainNameHelper
        {
            /*string*/ static IriDotCharacters = null;
            /*SearchValues<char>*/ static s_unsafeForNormalizedHostChars = null;
            /*SearchValues<char>*/ static s_validChars = null;
            /*SearchValues<char>*/ static s_iriInvalidChars = null;
            /*SearchValues<char>*/ static s_asciiLetterUpperOrColonChars = null;
            /*IdnMapping*/ static s_idnMapping = null;
            /*string*/ static Localhost = null;
            /*string*/ static Loopback = null;
            static /*string */ ParseCanonicalName(/*string*/ str, /*int*/ start, /*int*/ end, /*ref bool*/ loopback)
            {
                /*int*/ let index = $.$spc.System.MemoryExtensions.LastIndexOfAny$10($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$7(str, start, ((end - start) | 0)), $.$spu.System.DomainNameHelper.s_asciiLetterUpperOrColonChars);
                if (index >= 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!$.$spc.System.MemoryExtensions.Contains$1($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$7(str, start, index), /*:*/ 58), "A colon should appear at most once, and must never be followed by letters.");
                    if ($.$spc.System.String.get_Chars.call(str, ((start + index) | 0)) === /*:*/ 58)
                    {
                        end = ((start + index) | 0);
                        index = $.$spc.System.MemoryExtensions.IndexOfAnyInRange$1($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$7(str, start, index), /*A*/ 65, /*Z*/ 90);
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(index === -1 || $.$spc.System.Char.IsAsciiLetterUpper($.$spc.System.String.get_Chars.call(str, ((start + index) | 0))), "index == -1 || char.IsAsciiLetterUpper(str[start + index])");
                /*ReadOnlySpan<char>*/ let span = $.$spc.System.MemoryExtensions.AsSpan$7(str, start, ((end - start) | 0));
                if (index >= 0)
                {
                    if ($.$spc.System.MemoryExtensions.Equals$2(span, $.$spc.System.String.op_Implicit("localhost"/*Localhost*/), 5/*StringComparison.OrdinalIgnoreCase*/) || $.$spc.System.MemoryExtensions.Equals$2(span, $.$spc.System.String.op_Implicit("loopback"/*Loopback*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        loopback.$v = true;
                        return "localhost"/*Localhost*/;
                    }
                    return $.$spu.System.UriHelper.SpanToLowerInvariantString(span);
                }
                if ((span === "localhost"/*Localhost*/) || (span === "loopback"/*Loopback*/))
                {
                    loopback.$v = true;
                    return "localhost"/*Localhost*/;
                }
                return $.$spc.System.String.Substring$1.call(str, start, ((end - start) | 0));
            }
            static /*bool */ IsValid(/*ReadOnlySpan<char>*/ hostname, /*bool*/ iri, /*bool*/ notImplicitFile, /*out int*/ length)
            {
                /*int*/ let invalidCharOrDelimiterIndex = iri ? $.$spc.System.MemoryExtensions.IndexOfAny$11($.$spc.System.Char, hostname, $.$spu.System.DomainNameHelper.s_iriInvalidChars) : $.$spc.System.MemoryExtensions.IndexOfAnyExcept$14($.$spc.System.Char, hostname, $.$spu.System.DomainNameHelper.s_validChars);
                if (invalidCharOrDelimiterIndex >= 0)
                {
                    /*char*/ let c = hostname.get_Item(invalidCharOrDelimiterIndex).$v;
                    if ((c === /*/*/ 47) || (c === /*\\*/ 92) || (notImplicitFile && (((c === /*:*/ 58) || (c === /*?*/ 63)) || (c === /*#*/ 35))))
                    {
                        hostname = hostname.Slice$1(0, invalidCharOrDelimiterIndex);
                    }
                    else 
                    {
                        length.$v = 0;
                        return false;
                    }
                }
                length.$v = hostname.Length;
                if (length.$v === 0)
                {
                    return false;
                }
                while(true)
                {
                    /*char*/ let firstChar = hostname.get_Item(0).$v;
                    if ((!iri || firstChar < 160) && !$.$spc.System.Char.IsAsciiLetterOrDigit(firstChar))
                    {
                        return false;
                    }
                    /*int*/ let dotIndex = iri ? $.$spc.System.MemoryExtensions.IndexOfAny$9($.$spc.System.Char, hostname, $.$spc.System.String.op_Implicit(".\u3002\uFF0E\uFF61"/*IriDotCharacters*/)) : $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, hostname, /*.*/ 46);
                    /*int*/ let labelLength = dotIndex < 0 ? hostname.Length : dotIndex;
                    if (iri)
                    {
                        /*ReadOnlySpan<char>*/ let label = hostname.Slice$1(0, labelLength);
                        if (!$.$spc.System.Text.Ascii.IsValid$1(label))
                        {
                            labelLength += 4;
                            var $en5 = label.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var c = $en5.Current.$v;
                                {
                                    if (c > 255)
                                    {
                                        labelLength++;
                                    }
                                }
                            }
                        }
                    }
                    if (!$.$spu.System.IriHelper.IsInInclusiveRange((labelLength >>> 0), 1, 63))
                    {
                        return false;
                    }
                    if (dotIndex < 0)
                    {
                        return true;
                    }
                    hostname = hostname.Slice(((dotIndex + 1) | 0));
                    if (hostname.IsEmpty)
                    {
                        return true;
                    }
                }
            }
            static /*string */ IdnEquivalent(/*string*/ hostname)
            {
                if ($.$spc.System.Text.Ascii.IsValid$1($.$spc.System.String.op_Implicit(hostname)))
                {
                    return $.$spc.System.String.ToLowerInvariant.call(hostname);
                }
                /*string*/ let bidiStrippedHost = $.$spu.System.UriHelper.StripBidiControlCharacters($.$spc.System.String.op_Implicit(hostname), hostname);
                try
                {
                    /*string*/ let asciiForm = $.$spu.System.DomainNameHelper.s_idnMapping.GetAscii(bidiStrippedHost);
                    if ($.$spc.System.MemoryExtensions.ContainsAny$11($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(asciiForm), $.$spu.System.DomainNameHelper.s_unsafeForNormalizedHostChars))
                    {
                        throw new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_BadUnicodeHostForIdn);
                    }
                    return asciiForm;
                }
                catch($e)
                {
                    throw new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_BadUnicodeHostForIdn);
                }
            }
            static /*bool */ TryGetUnicodeEquivalent(/*string*/ hostname, /*ref ValueStringBuilder*/ dest)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Object.ReferenceEquals(hostname, $.$spu.System.UriHelper.StripBidiControlCharacters($.$spc.System.String.op_Implicit(hostname), hostname)), "ReferenceEquals(hostname, UriHelper.StripBidiControlCharacters(hostname, hostname))");
                for(/*int*/ let i = 0; i < hostname.length; i++)
                {
                    if (i !== 0)
                    {
                        dest.$v.Append$1(/*.*/ 46);
                    }
                    /*ReadOnlySpan<char>*/ let label = $.$spc.System.MemoryExtensions.AsSpan$4(hostname, i);
                    /*int*/ let dotIndex = $.$spc.System.MemoryExtensions.IndexOfAny$9($.$spc.System.Char, label, $.$spc.System.String.op_Implicit(".\u3002\uFF0E\uFF61"/*IriDotCharacters*/));
                    if (dotIndex >= 0)
                    {
                        label = label.Slice$1(0, dotIndex);
                    }
                    if (!$.$spc.System.Text.Ascii.IsValid$1(label))
                    {
                        try
                        {
                            /*string*/ let asciiForm = $.$spu.System.DomainNameHelper.s_idnMapping.GetAscii$2(hostname, i, label.Length);
                            dest.$v.Append$2($.$spu.System.DomainNameHelper.s_idnMapping.GetUnicode(asciiForm));
                        }
                        catch($e)
                        {
                            return false;
                        }
                    }
                    else 
                    {
                        /*bool*/ let aceValid = false;
                        if ($.$spc.System.MemoryExtensions.StartsWith$5(label, $.$spc.System.String.op_Implicit("xn--"), 4/*StringComparison.Ordinal*/))
                        {
                            try
                            {
                                dest.$v.Append$2($.$spu.System.DomainNameHelper.s_idnMapping.GetUnicode$2(hostname, i, label.Length));
                                aceValid = true;
                            }
                            catch($e)
                            {
                            }
                        }
                        if (!aceValid)
                        {
                            /*int*/ let charsWritten = $.$spc.System.MemoryExtensions.ToLowerInvariant(label, dest.$v.AppendSpan(label.Length));
                            $.$spc.System.Diagnostics.Debug.Assert$1(charsWritten === label.Length, "charsWritten == label.Length");
                        }
                    }
                    i += label.Length;
                }
                return true;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.IriDotCharacters = ".\u3002\uFF0E\uFF61";
                }
                {
                    this.s_unsafeForNormalizedHostChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("\\/?@#:[]"));
                }
                {
                    this.s_validChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz."));
                }
                {
                    this.s_iriInvalidChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\u0008\t\n\u000B\u000C\r\u000E\u000F" + "\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001A\u001B\u001C\u001D\u001E\u001F" + " !\"#$%&'()*+,/:;<=>?@[\\]^`{|}~\u007F" + "\u0080\u0081\u0082\u0083\u0084\u0085\u0086\u0087\u0088\u0089\u008A\u008B\u008C\u008D\u008E\u008F" + "\u0090\u0091\u0092\u0093\u0094\u0095\u0096\u0097\u0098\u0099\u009A\u009B\u009C\u009D\u009E\u009F"));
                }
                {
                    this.s_asciiLetterUpperOrColonChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("ABCDEFGHIJKLMNOPQRSTUVWXYZ:"));
                }
                {
                    this.s_idnMapping = new $.$spc.System.Globalization.IdnMapping().$ctor$1();
                }
                {
                    this.Localhost = "localhost";
                }
                {
                    this.Loopback = "loopback";
                }
            }
            static $h = 170132;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"str","p":1310721},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"loopback","p":262145,"f":4}],"n":"ParseCanonicalName","d":170132,"h":38654875796,"f":40},{"r":262145,"p":[{"n":"hostname","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"iri","p":262145},{"n":"notImplicitFile","p":262145},{"n":"length","p":655361,"f":2}],"n":"IsValid","d":170132,"h":42949843092,"f":33},{"r":1310721,"p":[{"n":"hostname","p":1310721}],"n":"IdnEquivalent","d":170132,"h":47244810388,"f":33},{"r":262145,"p":[{"n":"hostname","p":1310721},{"n":"dest","p":1546388,"f":4}],"n":"TryGetUnicodeEquivalent","d":170132,"h":51539777684,"f":33}],"l":[{"t":1310721,"n":"IriDotCharacters","d":170132,"h":4295137428,"f":34},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"s_unsafeForNormalizedHostChars","d":170132,"h":8590104724,"f":34},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"s_validChars","d":170132,"h":12885072020,"f":34},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"s_iriInvalidChars","d":170132,"h":17180039316,"f":34},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"s_asciiLetterUpperOrColonChars","d":170132,"h":21475006612,"f":34},{"t":53346305,"n":"s_idnMapping","d":170132,"h":25769973908,"f":34},{"t":1310721,"n":"Localhost","d":170132,"h":30064941204,"f":34},{"t":1310721,"n":"Loopback","d":170132,"h":34359908500,"f":34}],"h":170132}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.DomainNameHelper`; }
        });
        
        $asm.$cls("$spu.System.IriHelper", ($self) => class IriHelper
        {
            static /*bool */ CheckIriUnicodeRange(/*char*/ unicode, /*bool*/ isQuery)
            {
                return $.$spu.System.IriHelper.IsInInclusiveRange(unicode, /*\u00A0*/ 160, /*\uD7FF*/ 55295) || $.$spu.System.IriHelper.IsInInclusiveRange(unicode, /*\uF900*/ 63744, /*\uFDCF*/ 64975) || $.$spu.System.IriHelper.IsInInclusiveRange(unicode, /*\uFDF0*/ 65008, /*\uFFEF*/ 65519) || (isQuery && $.$spu.System.IriHelper.IsInInclusiveRange(unicode, /*\uE000*/ 57344, /*\uF8FF*/ 63743));
            }
            static /*bool */ CheckIriUnicodeRange$1(/*char*/ highSurr, /*char*/ lowSurr, /*out bool*/ isSurrogatePair, /*bool*/ isQuery)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Char.IsHighSurrogate(highSurr), "char.IsHighSurrogate(highSurr)");
                /*Rune*/ let rune;
                if ($.$spc.System.Text.Rune.TryCreate$1(highSurr, lowSurr, $.$ref(() => rune, ($v) => rune = $v, $.$spc.System.Text.Rune)))
                {
                    isSurrogatePair.$v = true;
                    return ((rune.Value & 65535) < 65534) && (((((rune.Value - 917504) | 0)) >>> 0) >= (((921600 - 917504) | 0))) && (isQuery || rune.Value < 983040);
                }
                isSurrogatePair.$v = false;
                return false;
            }
            static /*bool */ CheckIriUnicodeRange$2(/*uint*/ value, /*bool*/ isQuery)
            {
                if (value <= 65535)
                {
                    return $.$spu.System.IriHelper.IsInInclusiveRange(value, /*\u00A0*/ 160, /*\uD7FF*/ 55295) || $.$spu.System.IriHelper.IsInInclusiveRange(value, /*\uF900*/ 63744, /*\uFDCF*/ 64975) || $.$spu.System.IriHelper.IsInInclusiveRange(value, /*\uFDF0*/ 65008, /*\uFFEF*/ 65519) || (isQuery && $.$spu.System.IriHelper.IsInInclusiveRange(value, /*\uE000*/ 57344, /*\uF8FF*/ 63743));
                }
                else 
                {
                    return ((value & 65535) < 65534) && !$.$spu.System.IriHelper.IsInInclusiveRange(value, 917504, 921599) && (isQuery || value < 983040);
                }
            }
            static /*bool */ IsInInclusiveRange(/*uint*/ value, /*uint*/ min, /*uint*/ max)
            {
                return ((((value - min) >>> 0)) >>> 0) <= ((((max - min) >>> 0)) >>> 0);
            }
            static /*bool */ CheckIsReserved(/*char*/ ch, /*UriComponents*/ component)
            {
                if ((127/*UriComponents.AbsoluteUri*/ & component) === 0)
                {
                    return component === 0 && $.$spu.System.UriHelper.IsGenDelim(ch);
                }
                return $.$spc.System.String.Contains$2.call(";/?:@&=+$,#[]!'()*"/*UriHelper.RFC3986ReservedMarks*/, ch);
            }
            static /*string */ EscapeUnescapeIri(/*char**/ pInput, /*int*/ start, /*int*/ end, /*UriComponents*/ component)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(end >= 0 && start >= 0 && start <= end, "end >= 0 && start >= 0 && start <= end");
                /*int*/ let size = ((end - start) | 0);
                /*var*/ let dest = size <= 512/*Uri.StackallocThreshold*/ ? new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*Uri.StackallocThreshold*/, null)) : new $.$spu.System.Text.ValueStringBuilder().$ctor$3(size);
                /*Span<byte>*/ let maxUtf8EncodedSpan = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 4, null);
                for(/*int*/ let i = start; i < end; ++i)
                {
                    /*char*/ let ch = pInput.GetAt(i);
                    if (ch === /*%*/ 37)
                    {
                        if (((end - i) | 0) > 2)
                        {
                            ch = $.$spu.System.UriHelper.DecodeHexChars(pInput.GetAt(((i + 1) | 0)), pInput.GetAt(((i + 2) | 0)));
                            if (ch === /*\uFFFF*/ 65535 || ch === /*%*/ 37 || $.$spu.System.IriHelper.CheckIsReserved(ch, component) || $.$spu.System.UriHelper.IsNotSafeForUnescape(ch))
                            {
                                dest.Append$1(pInput.GetAt(i++));
                                dest.Append$1(pInput.GetAt(i++));
                                dest.Append$1(pInput.GetAt(i));
                                continue;
                            }
                            else if (ch <= /*\u007F*/ 127)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(ch < 255, "Expecting ASCII character.");
                                dest.Append$1(ch);
                                i += 2;
                                continue;
                            }
                            else 
                            {
                                /*int*/ let charactersRead = $.$spu.System.PercentEncodingHelper.UnescapePercentEncodedUTF8Sequence(pInput.Add(i), ((end - i) | 0), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null), component === 32/*UriComponents.Query*/, true);
                                $.$spc.System.Diagnostics.Debug.Assert$1(charactersRead > 0, "charactersRead > 0");
                                i += ((charactersRead - 1) | 0);
                            }
                        }
                        else 
                        {
                            dest.Append$1(pInput.GetAt(i));
                        }
                    }
                    else if (ch > /*\u007F*/ 127)
                    {
                        /*bool*/ let isInIriUnicodeRange;
                        /*bool*/ let surrogatePair = false;
                        /*char*/ let ch2 = /*\u0000*/ 0;
                        if (($.$spc.System.Char.IsHighSurrogate(ch)) && (((i + 1) | 0) < end))
                        {
                            ch2 = pInput.GetAt(((i + 1) | 0));
                            isInIriUnicodeRange = $.$spu.System.IriHelper.CheckIriUnicodeRange$1(ch, ch2, $.$ref(() => surrogatePair, ($v) => surrogatePair = $v, $.$spc.System.Boolean), component === 32/*UriComponents.Query*/);
                        }
                        else 
                        {
                            isInIriUnicodeRange = $.$spu.System.IriHelper.CheckIriUnicodeRange(ch, component === 32/*UriComponents.Query*/);
                        }
                        if (isInIriUnicodeRange)
                        {
                            dest.Append$1(ch);
                            if (surrogatePair)
                            {
                                dest.Append$1(ch2);
                            }
                        }
                        else 
                        {
                            /*Rune*/ let rune;
                            if (surrogatePair)
                            {
                                rune = new $.$spc.System.Text.Rune().$ctor$3(ch, ch2);
                            }
                            else if (!$.$spc.System.Text.Rune.TryCreate(ch, $.$ref(() => rune, ($v) => rune = $v, $.$spc.System.Text.Rune)))
                            {
                                rune = $.$spc.System.Text.Rune.ReplacementChar;
                            }
                            /*int*/ let bytesWritten = rune.EncodeToUtf8(maxUtf8EncodedSpan);
                            /*ReadOnlySpan<byte>*/ let encodedBytes = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(maxUtf8EncodedSpan.Slice$1(0, bytesWritten));
                            var $en5 = encodedBytes.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var b = $en5.Current.$v;
                                {
                                    $.$spu.System.UriHelper.PercentEncodeByte(b, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null));
                                }
                            }
                        }
                        if (surrogatePair)
                        {
                            i++;
                        }
                    }
                    else 
                    {
                        dest.Append$1(pInput.GetAt(i));
                    }
                }
                return $.$spu.System.Text.ValueStringBuilder.ToString.call(dest);
            }
            static $h = 825492;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"unicode","p":458753},{"n":"isQuery","p":262145}],"n":"CheckIriUnicodeRange","d":825492,"h":4295792788,"f":40},{"r":262145,"p":[{"n":"highSurr","p":458753},{"n":"lowSurr","p":458753},{"n":"isSurrogatePair","p":262145,"f":2},{"n":"isQuery","p":262145}],"n":"CheckIriUnicodeRange","o":"@$1","d":825492,"h":8590760084,"f":40},{"r":262145,"p":[{"n":"value","p":720897},{"n":"isQuery","p":262145}],"n":"CheckIriUnicodeRange","o":"@$2","d":825492,"h":12885727380,"f":40},{"r":262145,"p":[{"n":"value","p":720897},{"n":"min","p":720897},{"n":"max","p":720897}],"n":"IsInInclusiveRange","d":825492,"h":17180694676,"f":33},{"r":262145,"p":[{"n":"ch","p":458753},{"n":"component","p":2201748}],"n":"CheckIsReserved","d":825492,"h":21475661972,"f":40},{"r":1310721,"p":[{"n":"pInput","p":0},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"component","p":2201748}],"n":"EscapeUnescapeIri","d":825492,"h":25770629268,"f":40}],"h":825492}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IriHelper`; }
        });
        
        $asm.$cls("$spu.System.HexConverter", ($self) => class HexConverter
        {
            static $_Casing;
            static get Casing()
            {
                let $cls = $.$spu.System.HexConverter;
                return $cls.$_Casing ??= $asm.$nstr("$spu.System.HexConverter.Casing", ($self) => class Casing extends $.$spc.System.Enum
                {
                    static Upper = 0;
                    static Lower = 8224;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Upper": 0n,
                            "Lower": 8224n
                        };
                    }
                    static $h = 628884;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.UInt32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":720897,"l":[{"t":628884,"n":"Upper","d":628884,"h":4295596180,"f":33},{"t":628884,"n":"Lower","d":628884,"h":8590563476,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":628884,"h":12885530772,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":563348,"h":628884}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.HexConverter.Casing`; }
                }, $cls, ($v) => $cls.$_Casing = $v);
            }
            static /*void */ ToBytesBuffer(/*byte*/ value, /*Span<byte>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast(packedResult, $.$spc.System.Byte);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$spc.System.Byte);
            }
            static /*void */ ToCharsBuffer(/*byte*/ value, /*Span<char>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast((packedResult & 255), $.$spc.System.Char);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$spc.System.Char);
            }
            static /*void */ EncodeToUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ utf8Destination, /*Casing*/ casing)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(utf8Destination.Length >= (((source.Length * 2) | 0)), "utf8Destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$spu.System.HexConverter.ToBytesBuffer(source.get_Item(pos).$v, utf8Destination, ((pos * 2) | 0), casing);
                }
            }
            static /*void */ EncodeToUtf16(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Casing*/ casing)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(destination.Length >= (((source.Length * 2) | 0)), "destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$spu.System.HexConverter.ToCharsBuffer(source.get_Item(pos).$v, destination, ((pos * 2) | 0), casing);
                }
            }
            static /*string */ ToString$1(/*ReadOnlySpan<byte>*/ bytes, /*Casing*/ casing)
            {
                /*SpanCasingPair*/ let args = (() =>
                {
                    //new $.$spu.System.HexConverter.SpanCasingPair()
                    const $t1 = $.$spu.System.HexConverter.SpanCasingPair;
                    const $i1 = new $t1();
                    $i1.Bytes = bytes;
                    $i1.Casing = casing;
                    return $i1;
                })();
                return $.$spc.System.String.Create$8($.$spu.System.HexConverter.SpanCasingPair, ((bytes.Length * 2) | 0), args.Clone(), new ($.$spc.System.Buffers.SpanAction$$$($.$spc.System.Char, $.$spu.System.HexConverter.SpanCasingPair))().$ctor($.$spu.System.HexConverter, /*static*/ (/*chars*/ chars, /*args*/ args) =>
                {
                    return $.$spu.System.HexConverter.EncodeToUtf16(args.Bytes, chars, args.Casing);
                }, {"r":65537,"p":[{"n":"chars","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"args","p":694420}],"n":"","d":563348,"h":0,"f":1048610}));
            }
            static $_SpanCasingPair;
            static get SpanCasingPair()
            {
                let $cls = $.$spu.System.HexConverter;
                return $cls.$_SpanCasingPair ??= $asm.$nstr("$spu.System.HexConverter.SpanCasingPair", ($self) => class SpanCasingPair extends $.$spc.System.ValueType
                {
                    /*ReadOnlySpan<byte>*/ Bytes;
                    /*Casing*/ Casing = 0;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Bytes = this.Bytes.Clone();
                        copy.Casing = this.Casing;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Bytes = $.$default($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte));
                        this.Casing = 0;
                    }
                    static $h = 694420;
                    static $z = 9;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":12885596308,"f":1},"s":{"r":0,"d":0,"h":17180563604,"f":1},"n":"Bytes","d":694420,"h":8590629012,"f":1},{"p":628884,"g":{"r":0,"d":0,"h":30065465492,"f":1},"s":{"r":0,"d":0,"h":34360432788,"f":1},"n":"Casing","d":694420,"h":25770498196,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":694420,"h":38655400084,"f":1}],"d":563348,"h":694420}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.HexConverter.SpanCasingPair`; }
                }, $cls, ($v) => $cls.$_SpanCasingPair = $v);
            }
            static /*char */ ToCharUpper(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*A*/ 65 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$spc.System.Char);
            }
            static /*char */ ToCharLower(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*a*/ 97 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$spc.System.Char);
            }
            static /*bool */ TryDecodeFromUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                return $.$spu.System.HexConverter.TryDecodeFromUtf8_Scalar(utf8Source, destination, bytesProcessed);
            }
            static /*bool */ TryDecodeFromUtf16(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                return $.$spu.System.HexConverter.TryDecodeFromUtf16_Scalar(source, destination, charsProcessed);
            }
            static /*bool */ TryDecodeFromUtf8_Scalar(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((utf8Source.Length % 2) === 0, "Un-even number of characters provided");
                $.$spc.System.Diagnostics.Debug.Assert$1(($.trunc(utf8Source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$spu.System.HexConverter.FromChar(utf8Source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$spu.System.HexConverter.FromChar(utf8Source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$spc.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                bytesProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*bool */ TryDecodeFromUtf16_Scalar(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((source.Length % 2) === 0, "Un-even number of characters provided");
                $.$spc.System.Diagnostics.Debug.Assert$1(($.trunc(source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$spu.System.HexConverter.FromChar(source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$spu.System.HexConverter.FromChar(source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$spc.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                charsProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*int */ FromChar(/*int*/ c)
            {
                return (c >= $.$spu.System.HexConverter.CharToHexLookup.Length) ? 255 : $.$spu.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromUpperChar(/*int*/ c)
            {
                return (c > 71) ? 255 : $.$spu.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromLowerChar(/*int*/ c)
            {
                if (((((c - /*0*/ 48) | 0)) >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                {
                    return ((c - /*0*/ 48) | 0);
                }
                if (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97))
                {
                    return ((((c - /*a*/ 97) | 0) + 10) | 0);
                }
                return 255;
            }
            static /*bool */ IsHexChar(/*int*/ c)
            {
                //if (IntPtr.Size == 8) { ... }
                return $.$spu.System.HexConverter.FromChar(c) !== 255;
            }
            static /*bool */ IsHexUpperChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*A*/ 65) | 0)) >>> 0) <= (/*F*/ 70 - /*A*/ 65));
            }
            static /*bool */ IsHexLowerChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97));
            }
            static /*ReadOnlySpan<byte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255 ]);
            }
            static $h = 563348;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":90194876564,"f":33},"n":"CharToHexLookup","d":563348,"h":85899909268,"f":33}],"m":[{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":628884,"f":65,"v":0}],"n":"ToBytesBuffer","d":563348,"h":8590497940,"f":33},{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":628884,"f":65,"v":0}],"n":"ToCharsBuffer","d":563348,"h":12885465236,"f":33},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"utf8Destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"casing","p":628884,"f":65,"v":0}],"n":"EncodeToUtf8","d":563348,"h":17180432532,"f":33},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"casing","p":628884,"f":65,"v":0}],"n":"EncodeToUtf16","d":563348,"h":21475399828,"f":33},{"r":1310721,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"casing","p":628884,"f":65,"v":0}],"n":"ToString","o":"@$1","d":563348,"h":25770367124,"f":33},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharUpper","d":563348,"h":34360301716,"f":33},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharLower","d":563348,"h":38655269012,"f":33},{"r":262145,"p":[{"n":"utf8Source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8","d":563348,"h":42950236308,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16","d":563348,"h":47245203604,"f":33},{"r":262145,"p":[{"n":"utf8Source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8_Scalar","d":563348,"h":51540170900,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16_Scalar","d":563348,"h":55835138196,"f":34},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromChar","d":563348,"h":60130105492,"f":33},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromUpperChar","d":563348,"h":64425072788,"f":33},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromLowerChar","d":563348,"h":68720040084,"f":33},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexChar","d":563348,"h":73015007380,"f":33},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexUpperChar","d":563348,"h":77309974676,"f":33},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexLowerChar","d":563348,"h":81604941972,"f":33}],"j":[628884,694420],"h":563348}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.HexConverter`; }
        });
        
        $asm.$cls("$spu.System.UriHelper", ($self) => class UriHelper
        {
            static /*string */ SpanToLowerInvariantString(/*ReadOnlySpan<char>*/ span)
            {
                return $.$spc.System.String.Create$8($.$spc.System.ReadOnlySpan$$($.$spc.System.Char), span.Length, span, new ($.$spc.System.Buffers.SpanAction$$$($.$spc.System.Char, $.$spc.System.ReadOnlySpan$$($.$spc.System.Char)))().$ctor($.$spu.System.UriHelper, /*static*/ (/*buffer*/ buffer, /*span*/ span) =>
                {
                    /*int*/ let charsWritten = $.$spc.System.MemoryExtensions.ToLowerInvariant(span, buffer);
                    $.$spc.System.Diagnostics.Debug.Assert$1(charsWritten === buffer.Length, "charsWritten == buffer.Length");
                }, {"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"span","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"","d":2463892,"h":0,"f":1048610}));
            }
            static /*string */ NormalizeAndConcat(/*string?*/ start, /*ReadOnlySpan<char>*/ toNormalize)
            {
                /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*Uri.StackallocThreshold*/, null));
                /*int*/ let charsWritten;
                while(!$.$spc.System.StringNormalizationExtensions.TryNormalize(toNormalize, vsb.RawChars, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), 1/*NormalizationForm.FormC*/))
                {
                    vsb.EnsureCapacity(((vsb.Capacity + 1) | 0));
                }
                /*string*/ let result = $.$spc.System.String.Concat$10($.$spc.System.String.op_Implicit(start), $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(vsb.RawChars.Slice$1(0, charsWritten)));
                vsb.Dispose();
                return result;
            }
            static /*bool */ TestForSubPath(/*char**/ selfPtr, /*int*/ selfLength, /*char**/ otherPtr, /*int*/ otherLength, /*bool*/ ignoreCase)
            {
                /*int*/ let i = 0;
                /*char*/ let chSelf;
                /*char*/ let chOther;
                /*bool*/ let AllSameBeforeSlash = true;
                for(; i < selfLength && i < otherLength; ++i)
                {
                    chSelf = (selfPtr.Add(i)).$v;
                    chOther = (otherPtr.Add(i)).$v;
                    if (chSelf === /*?*/ 63 || chSelf === /*#*/ 35)
                    {
                        return true;
                    }
                    if (chSelf === /*/*/ 47)
                    {
                        if (chOther !== /*/*/ 47)
                        {
                            return false;
                        }
                        if (!AllSameBeforeSlash)
                        {
                            return false;
                        }
                        AllSameBeforeSlash = true;
                        continue;
                    }
                    if (chOther === /*?*/ 63 || chOther === /*#*/ 35)
                    {
                        break;
                    }
                    if (!ignoreCase)
                    {
                        if (chSelf !== chOther)
                        {
                            AllSameBeforeSlash = false;
                        }
                    }
                    else 
                    {
                        if ($.$spc.System.Char.ToLowerInvariant(chSelf) !== $.$spc.System.Char.ToLowerInvariant(chOther))
                        {
                            AllSameBeforeSlash = false;
                        }
                    }
                }
                for(; i < selfLength; ++i)
                {
                    if ((chSelf = (selfPtr.Add(i)).$v) === /*?*/ 63 || chSelf === /*#*/ 35)
                    {
                        return true;
                    }
                    if (chSelf === /*/*/ 47)
                    {
                        return false;
                    }
                }
                return true;
            }
            static /*bool */ TryEscapeDataString(/*ReadOnlySpan<char>*/ charsToEscape, /*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                if (destination.Length < charsToEscape.Length)
                {
                    charsWritten.$v = 0;
                    return false;
                }
                /*int*/ let indexOfFirstToEscape = $.$spc.System.MemoryExtensions.IndexOfAnyExcept$14($.$spc.System.Char, charsToEscape, $.$spu.System.UriHelper.Unreserved);
                if (indexOfFirstToEscape < 0)
                {
                    charsToEscape.CopyTo(destination);
                    charsWritten.$v = charsToEscape.Length;
                    return true;
                }
                /*scoped ValueStringBuilder*/ let vsb;
                /*bool*/ let overlapped = $.$spc.System.MemoryExtensions.Overlaps$2($.$spc.System.Char, charsToEscape, $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(destination));
                if (overlapped)
                {
                    vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*Uri.StackallocThreshold*/, null));
                    vsb.EnsureCapacity(charsToEscape.Length);
                }
                else 
                {
                    vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$2(destination.Slice(indexOfFirstToEscape));
                }
                $.$spu.System.UriHelper.EscapeStringToBuilder(charsToEscape.Slice(indexOfFirstToEscape), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), $.$spu.System.UriHelper.Unreserved, false);
                /*int*/ let newLength = $.$checked(indexOfFirstToEscape + vsb.Length, 1);
                $.$spc.System.Diagnostics.Debug.Assert$1(newLength > charsToEscape.Length, "newLength > charsToEscape.Length");
                if (destination.Length >= newLength)
                {
                    charsToEscape.Slice$1(0, indexOfFirstToEscape).CopyTo(destination);
                    if (overlapped)
                    {
                        vsb.AsSpan$1().CopyTo(destination.Slice(indexOfFirstToEscape));
                        vsb.Dispose();
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.MemoryExtensions.Overlaps$2($.$spc.System.Char, $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(vsb.RawChars), $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(destination)), "vsb.RawChars.Overlaps(destination)");
                    }
                    charsWritten.$v = newLength;
                    return true;
                }
                vsb.Dispose();
                charsWritten.$v = 0;
                return false;
            }
            static /*string */ EscapeString(/*string*/ stringToEscape, /*bool*/ checkExistingEscaped, /*SearchValues<char>*/ noEscape)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(stringToEscape, "stringToEscape");
                return $.$spu.System.UriHelper.EscapeString$1($.$spc.System.String.op_Implicit(stringToEscape), checkExistingEscaped, noEscape, stringToEscape);
            }
            static /*string */ EscapeString$1(/*ReadOnlySpan<char>*/ charsToEscape, /*bool*/ checkExistingEscaped, /*SearchValues<char>*/ noEscape, /*string?*/ backingString)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!noEscape.Contains(/*%*/ 37), "Need to treat % specially; it should be part of any escaped set");
                $.$spc.System.Diagnostics.Debug.Assert$1(backingString === null || backingString.length === charsToEscape.Length, "backingString is null || backingString.Length == charsToEscape.Length");
                /*int*/ let indexOfFirstToEscape = $.$spc.System.MemoryExtensions.IndexOfAnyExcept$14($.$spc.System.Char, charsToEscape, noEscape);
                if (indexOfFirstToEscape < 0)
                {
                    return backingString ?? $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(charsToEscape);
                }
                /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*Uri.StackallocThreshold*/, null));
                vsb.EnsureCapacity(charsToEscape.Length);
                $.$spu.System.UriHelper.EscapeStringToBuilder(charsToEscape.Slice(indexOfFirstToEscape), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), noEscape, checkExistingEscaped);
                /*string*/ let result = $.$spc.System.String.Concat$10(charsToEscape.Slice$1(0, indexOfFirstToEscape), vsb.AsSpan$1());
                vsb.Dispose();
                return result;
            }
            static /*void */ EscapeString$2(/*scoped ReadOnlySpan<char>*/ stringToEscape, /*ref ValueStringBuilder*/ dest, /*bool*/ checkExistingEscaped, /*SearchValues<char>*/ noEscape)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!noEscape.Contains(/*%*/ 37), "Need to treat % specially; it should be part of any escaped set");
                /*int*/ let indexOfFirstToEscape = $.$spc.System.MemoryExtensions.IndexOfAnyExcept$14($.$spc.System.Char, stringToEscape, noEscape);
                if (indexOfFirstToEscape < 0)
                {
                    dest.$v.Append$4(stringToEscape);
                }
                else 
                {
                    dest.$v.Append$4(stringToEscape.Slice$1(0, indexOfFirstToEscape));
                    $.$spu.System.UriHelper.EscapeStringToBuilder(stringToEscape.Slice(indexOfFirstToEscape), dest, noEscape, checkExistingEscaped);
                }
            }
            static /*void */ EscapeStringToBuilder(/*scoped ReadOnlySpan<char>*/ stringToEscape, /*ref ValueStringBuilder*/ vsb, /*SearchValues<char>*/ noEscape, /*bool*/ checkExistingEscaped)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!stringToEscape.IsEmpty && !noEscape.Contains(stringToEscape.get_Item(0).$v), "!stringToEscape.IsEmpty && !noEscape.Contains(stringToEscape[0])");
                /*Span<byte>*/ let utf8Bytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 4, null);
                while(!stringToEscape.IsEmpty)
                {
                    /*char*/ let c = stringToEscape.get_Item(0).$v;
                    if (!$.$spc.System.Char.IsAscii(c))
                    {
                        /*Rune*/ let r;
                        /*int*/ let charsConsumed;
                        if ($.$spc.System.Text.Rune.DecodeFromUtf16(stringToEscape, $.$ref(() => r, ($v) => r = $v, $.$spc.System.Text.Rune), $.$ref(() => charsConsumed, ($v) => charsConsumed = $v, $.$spc.System.Int32)) !== 0/*OperationStatus.Done*/)
                        {
                            r = $.$spc.System.Text.Rune.ReplacementChar;
                        }
                        let e;
                        $.$spc.System.Diagnostics.Debug.Assert$1((e = $.$spc.System.MemoryExtensions.EnumerateRunes(stringToEscape), e != null && true) && e.MoveNext() && $.$spc.System.Text.Rune.op_Equality(e.Current, r), "stringToEscape.EnumerateRunes() is { } e && e.MoveNext() && e.Current == r");
                        $.$spc.System.Diagnostics.Debug.Assert$1((charsConsumed === 1) || (charsConsumed === 2), "charsConsumed is 1 or 2");
                        stringToEscape = stringToEscape.Slice(charsConsumed);
                        /*int*/ let bytesWritten;
                        r.TryEncodeToUtf8(utf8Bytes, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32));
                        var $en4 = utf8Bytes.Slice$1(0, bytesWritten).GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var b = $en4.Current.$v;
                            {
                                $.$spu.System.UriHelper.PercentEncodeByte(b, vsb);
                            }
                        }
                        continue;
                    }
                    if (!noEscape.Contains(c))
                    {
                        if (c === /*%*/ 37 && checkExistingEscaped)
                        {
                            if (stringToEscape.Length > 2 && $.$spc.System.Char.IsAsciiHexDigit(stringToEscape.get_Item(1).$v) && $.$spc.System.Char.IsAsciiHexDigit(stringToEscape.get_Item(2).$v))
                            {
                                vsb.$v.Append$1(/*%*/ 37);
                                vsb.$v.Append$1(stringToEscape.get_Item(1).$v);
                                vsb.$v.Append$1(stringToEscape.get_Item(2).$v);
                                stringToEscape = stringToEscape.Slice(3);
                                continue;
                            }
                        }
                        $.$spu.System.UriHelper.PercentEncodeByte($.$cast(c, $.$spc.System.Byte), vsb);
                        stringToEscape = stringToEscape.Slice(1);
                        continue;
                    }
                    /*int*/ let charsToCopy = $.$spc.System.MemoryExtensions.IndexOfAnyExcept$14($.$spc.System.Char, stringToEscape, noEscape);
                    if (charsToCopy < 0)
                    {
                        charsToCopy = stringToEscape.Length;
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(charsToCopy > 0, "charsToCopy > 0");
                    vsb.$v.Append$4(stringToEscape.Slice$1(0, charsToCopy));
                    stringToEscape = stringToEscape.Slice(charsToCopy);
                }
            }
            static /*char[] */ UnescapeString(/*string*/ input, /*int*/ start, /*int*/ end, /*char[]*/ dest, /*ref int*/ destPosition, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                /*fixed*/ 
                {
                    /*char**/ let pStr = $.$spc.System.String.GetPinnableReference.call(input);
                    return $.$spu.System.UriHelper.UnescapeString$1(pStr, start, end, dest, destPosition, rsvd1, rsvd2, rsvd3, unescapeMode, syntax, isQuery);
                }
            }
            static /*char[] */ UnescapeString$1(/*char**/ pStr, /*int*/ start, /*int*/ end, /*char[]*/ dest, /*ref int*/ destPosition, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                /*ValueStringBuilder*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$3(dest.length);
                vsb.Append$4($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Char, dest, 0, destPosition.$v)));
                $.$spu.System.UriHelper.UnescapeString$4(pStr, start, end, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), rsvd1, rsvd2, rsvd3, unescapeMode, syntax, isQuery);
                if (vsb.Length > dest.length)
                {
                    dest = vsb.AsSpan$1().ToArray();
                }
                else 
                {
                    vsb.AsSpan$2(destPosition.$v).TryCopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Char, dest, destPosition.$v));
                }
                destPosition.$v = vsb.Length;
                vsb.Dispose();
                return dest;
            }
            static /*void */ UnescapeString$2(/*string*/ input, /*int*/ start, /*int*/ end, /*ref ValueStringBuilder*/ dest, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                /*fixed*/ 
                {
                    /*char**/ let pStr = $.$spc.System.String.GetPinnableReference.call(input);
                    $.$spu.System.UriHelper.UnescapeString$4(pStr, start, end, dest, rsvd1, rsvd2, rsvd3, unescapeMode, syntax, isQuery);
                }
            }
            static /*void */ UnescapeString$3(/*scoped ReadOnlySpan<char>*/ input, /*scoped ref ValueStringBuilder*/ dest, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                /*fixed*/ 
                {
                    /*char**/ let pStr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Char, input);
                    $.$spu.System.UriHelper.UnescapeString$4(pStr, 0, input.Length, dest, rsvd1, rsvd2, rsvd3, unescapeMode, syntax, isQuery);
                }
            }
            static /*void */ UnescapeString$4(/*char**/ pStr, /*int*/ start, /*int*/ end, /*ref ValueStringBuilder*/ dest, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                if ((unescapeMode & 3/*UnescapeMode.EscapeUnescape*/) === 0/*UnescapeMode.CopyOnly*/)
                {
                    dest.$v.Append$4(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(pStr.Add(start), ((end - start) | 0)));
                    return;
                }
                /*bool*/ let escapeReserved = false;
                /*bool*/ let iriParsing = $.$spu.System.Uri.IriParsingStatic(syntax) && ((unescapeMode & 3/*UnescapeMode.EscapeUnescape*/) === 3/*UnescapeMode.EscapeUnescape*/);
                for(/*int*/ let next = start; next < end; )
                {
                    /*char*/ let ch = 0;
                    for(; next < end; ++next)
                    {
                        if ((ch = pStr.GetAt(next)) === /*%*/ 37)
                        {
                            if ((unescapeMode & 2/*UnescapeMode.Unescape*/) === 0)
                            {
                                escapeReserved = true;
                            }
                            else if (((next + 2) | 0) < end)
                            {
                                ch = $.$spu.System.UriHelper.DecodeHexChars(pStr.GetAt(((next + 1) | 0)), pStr.GetAt(((next + 2) | 0)));
                                if (unescapeMode >= 8/*UnescapeMode.UnescapeAll*/)
                                {
                                    if (ch === /*\uFFFF*/ 65535)
                                    {
                                        continue;
                                    }
                                }
                                else if (ch === /*\uFFFF*/ 65535)
                                {
                                    if ((unescapeMode & 1/*UnescapeMode.Escape*/) !== 0)
                                    {
                                        escapeReserved = true;
                                    }
                                    else 
                                    {
                                        continue;
                                    }
                                }
                                else if (ch === /*%*/ 37)
                                {
                                    next += 2;
                                    continue;
                                }
                                else if (ch === rsvd1 || ch === rsvd2 || ch === rsvd3)
                                {
                                    next += 2;
                                    continue;
                                }
                                else if ((unescapeMode & 4/*UnescapeMode.V1ToStringFlag*/) === 0 && $.$spu.System.UriHelper.IsNotSafeForUnescape(ch))
                                {
                                    next += 2;
                                    continue;
                                }
                                else if (iriParsing && ((ch <= /*\u009F*/ 159 && $.$spu.System.UriHelper.IsNotSafeForUnescape(ch)) || (ch > /*\u009F*/ 159 && !$.$spu.System.IriHelper.CheckIriUnicodeRange(ch, isQuery))))
                                {
                                    next += 2;
                                    continue;
                                }
                                break;
                            }
                            else if (unescapeMode >= 8/*UnescapeMode.UnescapeAll*/)
                            {
                                continue;
                            }
                            else 
                            {
                                escapeReserved = true;
                            }
                            break;
                        }
                        else if ((unescapeMode & (2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/)) === (2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/))
                        {
                            continue;
                        }
                        else if ((unescapeMode & 1/*UnescapeMode.Escape*/) !== 0)
                        {
                            if (ch === rsvd1 || ch === rsvd2 || ch === rsvd3)
                            {
                                escapeReserved = true;
                                break;
                            }
                            else if ((unescapeMode & 4/*UnescapeMode.V1ToStringFlag*/) === 0 && (ch <= /*\u001F*/ 31 || (ch >= /*\u007F*/ 127 && ch <= /*\u009F*/ 159)))
                            {
                                escapeReserved = true;
                                break;
                            }
                        }
                    }
                    while(start < next)
                    {
                        dest.$v.Append$1(pStr.GetAt(start++));
                    }
                    if (next !== end)
                    {
                        if (escapeReserved)
                        {
                            $.$spu.System.UriHelper.PercentEncodeByte($.$cast(pStr.GetAt(next), $.$spc.System.Byte), dest);
                            escapeReserved = false;
                            next++;
                        }
                        else if (ch <= 127)
                        {
                            dest.$v.Append$1(ch);
                            next += 3;
                        }
                        else 
                        {
                            /*int*/ let charactersRead = $.$spu.System.PercentEncodingHelper.UnescapePercentEncodedUTF8Sequence(pStr.Add(next), ((end - next) | 0), dest, isQuery, iriParsing);
                            $.$spc.System.Diagnostics.Debug.Assert$1(charactersRead > 0, "charactersRead > 0");
                            next += charactersRead;
                        }
                        start = next;
                    }
                }
            }
            static /*void */ PercentEncodeByte(/*byte*/ b, /*ref ValueStringBuilder*/ to)
            {
                to.$v.Append$1(/*%*/ 37);
                $.$spu.System.HexConverter.ToCharsBuffer(b, to.$v.AppendSpan(2), 0, 0/*HexConverter.Casing.Upper*/);
            }
            static /*char */ DecodeHexChars(/*int*/ first, /*int*/ second)
            {
                /*int*/ let a = $.$spu.System.HexConverter.FromChar(first);
                /*int*/ let b = $.$spu.System.HexConverter.FromChar(second);
                if ((a | b) === 255)
                {
                    return /*\uFFFF*/ 65535;
                }
                return $.$cast(((a << 4) | b), $.$spc.System.Char);
            }
            /*string*/ static RFC3986ReservedMarks = null;
            /*string*/ static AdditionalUnsafeToUnescape = null;
            static /*bool */ IsNotSafeForUnescape(/*char*/ ch)
            {
                if (ch <= /*\u001F*/ 31 || (ch >= /*\u007F*/ 127 && ch <= /*\u009F*/ 159))
                {
                    return true;
                }
                /*string*/ let NotSafeForUnescape = ";/?:@&=+$,#[]!'()*"/*RFC3986ReservedMarks*/ + "%\\#"/*AdditionalUnsafeToUnescape*/;
                return $.$spc.System.String.Contains$2.call(NotSafeForUnescape, ch);
            }
            /*SearchValues<char>*/ static Unreserved = null;
            /*SearchValues<char>*/ static UnreservedReserved = null;
            /*SearchValues<char>*/ static UnreservedReservedExceptHash = null;
            /*SearchValues<char>*/ static UnreservedReservedExceptQuestionMarkHash = null;
            static /*bool */ IsGenDelim(/*char*/ ch)
            {
                return (ch === /*:*/ 58 || ch === /*/*/ 47 || ch === /*?*/ 63 || ch === /*#*/ 35 || ch === /*[*/ 91 || ch === /*]*/ 93 || ch === /*@*/ 64);
            }
            /*char[]*/ static s_WSchars = null;
            static /*bool */ IsLWS(/*char*/ ch)
            {
                return (ch <= /* */ 32) && (ch === /* */ 32 || ch === /*\n*/ 10 || ch === /*\r*/ 13 || ch === /*\t*/ 9);
            }
            static /*bool */ IsBidiControlCharacter(/*char*/ ch)
            {
                return $.$spc.System.Char.IsBetween(ch, /*\u200E*/ 8206, /*\u202E*/ 8238) && !$.$spc.System.Char.IsBetween(ch, /*\u2010*/ 8208, /*\u2029*/ 8233);
            }
            static /*string */ StripBidiControlCharacters(/*ReadOnlySpan<char>*/ strToClean, /*string?*/ backingString)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(backingString === null || strToClean.Length === backingString.length, "backingString is null || strToClean.Length == backingString.Length");
                /*string?*/ let stripped;
                if ($.$spu.System.UriHelper.StripBidiControlCharacters$1(strToClean, $.$ref(() => stripped, ($v) => stripped = $v, $.$spc.System.String)))
                {
                    return stripped;
                }
                return backingString ?? $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(strToClean);
            }
            static /*bool */ StripBidiControlCharacters$1(/*ReadOnlySpan<char>*/ strToClean, /*out string?*/ stripped)
            {
                /*int*/ let charsToRemove = 0;
                /*int*/ let indexOfPossibleCharToRemove = $.$spc.System.MemoryExtensions.IndexOfAnyInRange$1($.$spc.System.Char, strToClean, /*\u200E*/ 8206, /*\u202E*/ 8238);
                if (indexOfPossibleCharToRemove >= 0)
                {
                    var $en3 = strToClean.Slice(indexOfPossibleCharToRemove).GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var c = $en3.Current.$v;
                        {
                            if ($.$spu.System.UriHelper.IsBidiControlCharacter(c))
                            {
                                charsToRemove++;
                            }
                        }
                    }
                }
                if (charsToRemove === 0)
                {
                    stripped.$v = null;
                    return false;
                }
                stripped.$v = $.$spc.System.String.Create$8($.$spc.System.ReadOnlySpan$$($.$spc.System.Char), ((strToClean.Length - charsToRemove) | 0), strToClean, new ($.$spc.System.Buffers.SpanAction$$$($.$spc.System.Char, $.$spc.System.ReadOnlySpan$$($.$spc.System.Char)))().$ctor($.$spu.System.UriHelper, /*static*/ (/*buffer*/ buffer, /*strToClean*/ strToClean) =>
                {
                    /*int*/ let destIndex = 0;
                    var $en3 = strToClean.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var c = $en3.Current.$v;
                        {
                            if (!$.$spu.System.UriHelper.IsBidiControlCharacter(c))
                            {
                                buffer.get_Item(destIndex++).$v = c;
                            }
                        }
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(buffer.Length === destIndex, "buffer.Length == destIndex");
                }, {"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"strToClean","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"","d":2463892,"h":0,"f":1048610}));
                return true;
            }
            static /*int */ Compress(/*Span<char>*/ span, /*bool*/ convertPathSlashes, /*bool*/ canonicalizeAsFilePath)
            {
                if (span.IsEmpty)
                {
                    return 0;
                }
                if (convertPathSlashes)
                {
                    $.$spc.System.MemoryExtensions.Replace($.$spc.System.Char, span, /*\\*/ 92, /*/*/ 47);
                }
                /*ValueListBuilder<(int Start, int Length)>*/ let removedSegments = new ($.$spu.System.Collections.Generic.ValueListBuilder$$($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32)))();
                /*int*/ let slashCount = 0;
                /*int*/ let lastSlash = 0;
                /*int*/ let dotCount = 0;
                /*int*/ let removeSegments = 0;
                for(/*int*/ let i = ((span.Length - 1) | 0); i >= 0; i--)
                {
                    /*char*/ let ch = span.get_Item(i).$v;
                    if (ch === /*/*/ 47)
                    {
                        ++slashCount;
                    }
                    else 
                    {
                        if (slashCount > 1)
                        {
                            lastSlash = ((i + 1) | 0);
                        }
                        slashCount = 0;
                    }
                    if (ch === /*.*/ 46)
                    {
                        ++dotCount;
                        continue;
                    }
                    else if (dotCount !== 0)
                    {
                        /*bool*/ let skipSegment = canonicalizeAsFilePath && (dotCount > 2 || ch !== /*/*/ 47);
                        if (!skipSegment && ch === /*/*/ 47)
                        {
                            if ((lastSlash === ((((i + dotCount) | 0) + 1) | 0) || (lastSlash === 0 && ((((i + dotCount) | 0) + 1) | 0) === span.Length)) && (dotCount <= 2))
                            {
                                removedSegments.Append(new ($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32))().$ctor$2(((i + 1) | 0), ((dotCount + (lastSlash === 0 ? 0 : 1)) | 0)));
                                lastSlash = i;
                                if (dotCount === 2)
                                {
                                    ++removeSegments;
                                }
                                dotCount = 0;
                                continue;
                            }
                        }
                        dotCount = 0;
                    }
                    if (ch === /*/*/ 47)
                    {
                        if (removeSegments !== 0)
                        {
                            removeSegments--;
                            removedSegments.Append(new ($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32))().$ctor$2(((i + 1) | 0), ((lastSlash - i) | 0)));
                        }
                        lastSlash = i;
                    }
                }
                if (canonicalizeAsFilePath)
                {
                    if (slashCount <= 1)
                    {
                        if (removeSegments !== 0 && span.get_Item(0).$v !== /*/*/ 47)
                        {
                            removedSegments.Append(new ($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32))().$ctor$2(0, ((lastSlash + 1) | 0)));
                        }
                        else if (dotCount !== 0)
                        {
                            if (lastSlash === dotCount || (lastSlash === 0 && dotCount === span.Length))
                            {
                                removedSegments.Append(new ($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32))().$ctor$2(0, ((dotCount + (lastSlash === 0 ? 0 : 1)) | 0)));
                            }
                        }
                    }
                }
                if (removedSegments.Length === 0)
                {
                    return span.Length;
                }
                /*int*/ let writeOffset = removedSegments.get_Item(removedSegments.Length - 1).$v.Item1;
                /*int*/ let readOffset = writeOffset;
                for(/*int*/ let i = ((removedSegments.Length - 1) | 0); i >= 0; i--)
                {
                    const { Item1: start, Item2: length } = removedSegments.get_Item(i).$v;
                    $.$spc.System.Diagnostics.Debug.Assert$1(start >= readOffset && length > 0 && ((start + length) | 0) <= span.Length, "start >= readOffset && length > 0 && start + length <= span.Length");
                    if (readOffset !== start)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(readOffset > writeOffset, "readOffset > writeOffset");
                        /*int*/ let segmentLength = ((start - readOffset) | 0);
                        span.Slice$1(readOffset, segmentLength).CopyTo(span.Slice(writeOffset));
                        writeOffset += segmentLength;
                    }
                    readOffset = ((start + length) | 0);
                }
                if (readOffset !== span.Length)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(readOffset > writeOffset, "readOffset > writeOffset");
                    span.Slice(readOffset).CopyTo(span.Slice(writeOffset));
                    writeOffset += ((span.Length - readOffset) | 0);
                }
                removedSegments.Dispose();
                return writeOffset;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.RFC3986ReservedMarks = ";/?:@&=+$,#[]!'()*";
                }
                {
                    this.AdditionalUnsafeToUnescape = "%\\#";
                }
                {
                    this.Unreserved = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz~"));
                }
                {
                    this.UnreservedReserved = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("!#$&'()*+,-./0123456789:;=?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]_abcdefghijklmnopqrstuvwxyz~"));
                }
                {
                    this.UnreservedReservedExceptHash = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("!$&'()*+,-./0123456789:;=?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]_abcdefghijklmnopqrstuvwxyz~"));
                }
                {
                    this.UnreservedReservedExceptQuestionMarkHash = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("!$&'()*+,-./0123456789:;=@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]_abcdefghijklmnopqrstuvwxyz~"));
                }
                {
                    this.s_WSchars = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), [/* */ 32, /*\n*/ 10, /*\r*/ 13, /*\t*/ 9], [-1], null);
                }
            }
            static $h = 2463892;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"span","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"SpanToLowerInvariantString","d":2463892,"h":4297431188,"f":33},{"r":1310721,"p":[{"n":"start","p":1310721},{"n":"toNormalize","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"NormalizeAndConcat","d":2463892,"h":8592398484,"f":33},{"r":262145,"p":[{"n":"selfPtr","p":0},{"n":"selfLength","p":655361},{"n":"otherPtr","p":0},{"n":"otherLength","p":655361},{"n":"ignoreCase","p":262145}],"n":"TestForSubPath","d":2463892,"h":12887365780,"f":40},{"r":262145,"p":[{"n":"charsToEscape","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryEscapeDataString","d":2463892,"h":17182333076,"f":33},{"r":1310721,"p":[{"n":"stringToEscape","p":1310721},{"n":"checkExistingEscaped","p":262145},{"n":"noEscape","p":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h}],"n":"EscapeString","d":2463892,"h":21477300372,"f":33},{"r":1310721,"p":[{"n":"charsToEscape","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"checkExistingEscaped","p":262145},{"n":"noEscape","p":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h},{"n":"backingString","p":1310721}],"n":"EscapeString","o":"@$1","d":2463892,"h":25772267668,"f":33},{"r":65537,"p":[{"n":"stringToEscape","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"dest","p":1546388,"f":4},{"n":"checkExistingEscaped","p":262145},{"n":"noEscape","p":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h}],"n":"EscapeString","o":"@$2","d":2463892,"h":30067234964,"f":40},{"r":65537,"p":[{"n":"stringToEscape","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"vsb","p":1546388,"f":4},{"n":"noEscape","p":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h},{"n":"checkExistingEscaped","p":262145}],"n":"EscapeStringToBuilder","d":2463892,"h":34362202260,"f":34},{"r":0,"p":[{"n":"input","p":1310721},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"dest","p":0},{"n":"destPosition","p":655361,"f":4},{"n":"rsvd1","p":458753},{"n":"rsvd2","p":458753},{"n":"rsvd3","p":458753},{"n":"unescapeMode","p":1677460},{"n":"syntax","p":2660500},{"n":"isQuery","p":262145}],"n":"UnescapeString","d":2463892,"h":38657169556,"f":40},{"r":0,"p":[{"n":"pStr","p":0},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"dest","p":0},{"n":"destPosition","p":655361,"f":4},{"n":"rsvd1","p":458753},{"n":"rsvd2","p":458753},{"n":"rsvd3","p":458753},{"n":"unescapeMode","p":1677460},{"n":"syntax","p":2660500},{"n":"isQuery","p":262145}],"n":"UnescapeString","o":"@$1","d":2463892,"h":42952136852,"f":40},{"r":65537,"p":[{"n":"input","p":1310721},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"dest","p":1546388,"f":4},{"n":"rsvd1","p":458753},{"n":"rsvd2","p":458753},{"n":"rsvd3","p":458753},{"n":"unescapeMode","p":1677460},{"n":"syntax","p":2660500},{"n":"isQuery","p":262145}],"n":"UnescapeString","o":"@$2","d":2463892,"h":47247104148,"f":40},{"r":65537,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"dest","p":1546388,"f":4},{"n":"rsvd1","p":458753},{"n":"rsvd2","p":458753},{"n":"rsvd3","p":458753},{"n":"unescapeMode","p":1677460},{"n":"syntax","p":2660500},{"n":"isQuery","p":262145}],"n":"UnescapeString","o":"@$3","d":2463892,"h":51542071444,"f":40},{"r":65537,"p":[{"n":"pStr","p":0},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"dest","p":1546388,"f":4},{"n":"rsvd1","p":458753},{"n":"rsvd2","p":458753},{"n":"rsvd3","p":458753},{"n":"unescapeMode","p":1677460},{"n":"syntax","p":2660500},{"n":"isQuery","p":262145}],"n":"UnescapeString","o":"@$4","d":2463892,"h":55837038740,"f":40},{"r":65537,"p":[{"n":"b","p":393217},{"n":"to","p":1546388,"f":4}],"n":"PercentEncodeByte","d":2463892,"h":60132006036,"f":40},{"r":458753,"p":[{"n":"first","p":655361},{"n":"second","p":655361}],"n":"DecodeHexChars","d":2463892,"h":64426973332,"f":40},{"r":262145,"p":[{"n":"ch","p":458753}],"n":"IsNotSafeForUnescape","d":2463892,"h":77311875220,"f":40},{"r":262145,"p":[{"n":"ch","p":458753}],"n":"IsGenDelim","d":2463892,"h":98786711700,"f":40},{"r":262145,"p":[{"n":"ch","p":458753}],"n":"IsLWS","d":2463892,"h":107376646292,"f":40},{"r":262145,"p":[{"n":"ch","p":458753}],"n":"IsBidiControlCharacter","d":2463892,"h":111671613588,"f":40},{"r":1310721,"p":[{"n":"strToClean","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"backingString","p":1310721,"f":65}],"n":"StripBidiControlCharacters","d":2463892,"h":115966580884,"f":33},{"r":262145,"p":[{"n":"strToClean","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"stripped","p":1310721,"f":2}],"n":"StripBidiControlCharacters","o":"@$1","d":2463892,"h":120261548180,"f":33},{"r":655361,"p":[{"n":"span","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"convertPathSlashes","p":262145},{"n":"canonicalizeAsFilePath","p":262145}],"n":"Compress","d":2463892,"h":124556515476,"f":33}],"l":[{"t":1310721,"n":"RFC3986ReservedMarks","d":2463892,"h":68721940628,"f":40},{"t":1310721,"n":"AdditionalUnsafeToUnescape","d":2463892,"h":73016907924,"f":34},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"Unreserved","d":2463892,"h":81606842516,"f":33},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"UnreservedReserved","d":2463892,"h":85901809812,"f":33},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"UnreservedReservedExceptHash","d":2463892,"h":90196777108,"f":33},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"UnreservedReservedExceptQuestionMarkHash","d":2463892,"h":94491744404,"f":33},{"t":0,"n":"s_WSchars","d":2463892,"h":103081678996,"f":40}],"h":2463892}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.UriHelper`; }
        });
        
        $asm.$cls("$spu.System.Uri", ($self) => class Uri extends $.$spc.System.Object
        {
            /*void */ CreateThis(/*string?*/ uri, /*bool*/ dontEscape, /*UriKind*/ uriKind, /*in UriCreationOptions*/ creationOptions)
            {
                this.DebugAssertInCtor();
                if (uriKind < 0/*UriKind.RelativeOrAbsolute*/ || uriKind > 2/*UriKind.Relative*/)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spu.System.SR.Format($.$spu.System.SR.net_uri_InvalidUriKind, $.$box(uriKind, $.$spu.System.UriKind)));
                }
                this._string = uri ?? $.$spc.System.String.Empty;
                $.$spc.System.Diagnostics.Debug.Assert$1(this._originalUnicodeString === null && this._info === null && this._syntax === null && this._flags === 0n, "_originalUnicodeString is null && _info is null && _syntax is null && _flags == Flags.Zero");
                if (dontEscape)
                {
                    this._flags |= 34359738368n;
                }
                if (creationOptions.$v.DangerousDisablePathAndQueryCanonicalization)
                {
                    this._flags |= 36028797018963968n;
                }
                /*ParsingError*/ let err = $.$spu.System.Uri.ParseScheme(this._string, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => this._flags, ($v) => this._flags = $v, null), $.$ref(() => this._syntax, ($v) => this._syntax = $v, $.$spu.System.UriParser));
                /*UriFormatException?*/ let e;
                this.InitializeUri(err, uriKind, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException));
                if (e !== null)
                {
                    throw e;
                }
            }
            /*void */ InitializeUri(/*ParsingError*/ err, /*UriKind*/ uriKind, /*out UriFormatException?*/ e)
            {
                this.DebugAssertInCtor();
                if (err === 0/*ParsingError.None*/)
                {
                    if (this.IsImplicitFile)
                    {
                        if (this.NotAny(8796093022208n) && uriKind !== 1/*UriKind.Absolute*/ && ((uriKind === 2/*UriKind.Relative*/ || (this._string.length >= 2 && ($.$spc.System.String.get_Chars.call(this._string, 0) !== /*\\*/ 92 || $.$spc.System.String.get_Chars.call(this._string, 1) !== /*\\*/ 92))) || (!$.$spc.System.OperatingSystem.IsWindows() && this.InFact(18014398509481984n))))
                        {
                            this._syntax = null;
                            this._flags &= 34359738368n;
                            e.$v = null;
                            return;
                        }
                        else if (uriKind === 2/*UriKind.Relative*/ && this.InFact(8796093022208n))
                        {
                            this._syntax = null;
                            this._flags &= 34359738368n;
                            e.$v = null;
                            return;
                        }
                    }
                }
                else if (err > 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                {
                    this._string = null;
                    e.$v = $.$spu.System.Uri.GetException(err);
                    return;
                }
                /*bool*/ let hasUnicode = false;
                if (this.IriParsing && $.$spu.System.Uri.CheckForUnicodeOrEscapedUnreserved(this._string))
                {
                    this._flags |= 562949953421312n;
                    hasUnicode = true;
                    this._originalUnicodeString = this._string;
                }
                if (this._syntax !== null)
                {
                    if (this._syntax.IsSimple)
                    {
                        if ((err = this.PrivateParseMinimal()) !== 0/*ParsingError.None*/)
                        {
                            if (uriKind !== 1/*UriKind.Absolute*/ && err <= 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                            {
                                this._syntax = null;
                                e.$v = null;
                                this._flags &= 34359738368n;
                                return;
                            }
                            else 
                            {
                                e.$v = $.$spu.System.Uri.GetException(err);
                            }
                        }
                        else if (uriKind === 2/*UriKind.Relative*/)
                        {
                            e.$v = $.$spu.System.Uri.GetException(12/*ParsingError.CannotCreateRelative*/);
                        }
                        else 
                        {
                            e.$v = null;
                        }
                        if (hasUnicode)
                        {
                            try
                            {
                                this.EnsureParseRemaining();
                            }
                            catch(ex)
                            {
                                e.$v = ex;
                                return;
                            }
                        }
                    }
                    else 
                    {
                        this._syntax = this._syntax.InternalOnNewUri();
                        this._flags |= 1099511627776n;
                        this._syntax.InternalValidate(this, e);
                        if (e.$v !== null)
                        {
                            if (uriKind !== 1/*UriKind.Absolute*/ && err !== 0/*ParsingError.None*/ && err <= 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                            {
                                this._syntax = null;
                                e.$v = null;
                                this._flags &= 34359738368n;
                            }
                        }
                        else 
                        {
                            if (err !== 0/*ParsingError.None*/ || this.InFact(4398046511104n))
                            {
                                this._flags = 1099511627776n | (this._flags & 34359738368n);
                            }
                            else if (uriKind === 2/*UriKind.Relative*/)
                            {
                                e.$v = $.$spu.System.Uri.GetException(12/*ParsingError.CannotCreateRelative*/);
                            }
                            if (hasUnicode)
                            {
                                try
                                {
                                    this.EnsureParseRemaining();
                                }
                                catch(ex)
                                {
                                    e.$v = ex;
                                    return;
                                }
                            }
                        }
                    }
                }
                else if (err !== 0/*ParsingError.None*/ && uriKind !== 1/*UriKind.Absolute*/ && err <= 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                {
                    e.$v = null;
                    this._flags &= (34359738368n | 562949953421312n);
                    if (hasUnicode)
                    {
                        this._string = this.EscapeUnescapeIri(this._originalUnicodeString, 0, this._originalUnicodeString.length, $.$cast(0, $.$spu.System.UriComponents));
                    }
                }
                else 
                {
                    this._string = null;
                    e.$v = $.$spu.System.Uri.GetException(err);
                }
            }
            /*SearchValues<char>*/ static s_asciiOtherThanPercent = null;
            static /*bool */ CheckForUnicodeOrEscapedUnreserved(/*string*/ data)
            {
                /*int*/ let i = $.$spc.System.MemoryExtensions.IndexOfAnyExcept$14($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(data), $.$spu.System.Uri.s_asciiOtherThanPercent);
                if (i >= 0)
                {
                    for(; i < data.length; i++)
                    {
                        /*char*/ let c = $.$spc.System.String.get_Chars.call(data, i);
                        if (c === /*%*/ 37)
                        {
                            if (((((i + 2) | 0)) >>> 0) < (data.length >>> 0))
                            {
                                /*char*/ let value = $.$spu.System.UriHelper.DecodeHexChars($.$spc.System.String.get_Chars.call(data, ((i + 1) | 0)), $.$spc.System.String.get_Chars.call(data, ((i + 2) | 0)));
                                if (!$.$spc.System.Char.IsAscii(value) || $.$spu.System.UriHelper.Unreserved.Contains(value))
                                {
                                    return true;
                                }
                                i += 2;
                            }
                        }
                        else if (c > 127)
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            static /*bool */ TryCreate(/*string?*/ uriString, /*UriKind*/ uriKind, /*out Uri?*/ result)
            {
                if (uriString === null)
                {
                    result.$v = null;
                    return false;
                }
                /*UriFormatException?*/ let e = null;
                let $v2 = new $.$spu.System.UriCreationOptions();
                result.$v = $.$spu.System.Uri.CreateHelper(uriString, false, uriKind, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException), $.$ref(() => $v2, ($v) => $v2 = $v));
                result.$v?.DebugSetLeftCtor();
                return e === null && $.$spu.System.Uri.op_Inequality(result.$v, null);
            }
            static /*bool */ TryCreate$1(/*string?*/ uriString, /*in UriCreationOptions*/ creationOptions, /*out Uri?*/ result)
            {
                if (uriString === null)
                {
                    result.$v = null;
                    return false;
                }
                /*UriFormatException?*/ let e = null;
                result.$v = $.$spu.System.Uri.CreateHelper(uriString, false, 1/*UriKind.Absolute*/, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException), creationOptions);
                result.$v?.DebugSetLeftCtor();
                return e === null && $.$spu.System.Uri.op_Inequality(result.$v, null);
            }
            static /*bool */ TryCreate$2(/*Uri?*/ baseUri, /*string?*/ relativeUri, /*out Uri?*/ result)
            {
                /*Uri?*/ let relativeLink;
                if ($.$spu.System.Uri.TryCreate(relativeUri, 0/*UriKind.RelativeOrAbsolute*/, $.$ref(() => relativeLink, ($v) => relativeLink = $v, $.$spu.System.Uri)))
                {
                    if (!relativeLink.IsAbsoluteUri)
                    {
                        return $.$spu.System.Uri.TryCreate$3(baseUri, relativeLink, result);
                    }
                    result.$v = relativeLink;
                    return true;
                }
                result.$v = null;
                return false;
            }
            static /*bool */ TryCreate$3(/*Uri?*/ baseUri, /*Uri?*/ relativeUri, /*out Uri?*/ result)
            {
                result.$v = null;
                if (baseUri === null || relativeUri === null)
                {
                    return false;
                }
                if (baseUri.IsNotAbsoluteUri)
                {
                    return false;
                }
                /*UriFormatException?*/ let e = null;
                /*string?*/ let newUriString = null;
                /*bool*/ let dontEscape;
                if (baseUri.Syntax.IsSimple)
                {
                    dontEscape = relativeUri.UserEscaped;
                    result.$v = $.$spu.System.Uri.ResolveHelper(baseUri, relativeUri, $.$ref(() => newUriString, ($v) => newUriString = $v, $.$spc.System.String), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => dontEscape, ($v) => dontEscape = $v, null));
                }
                else 
                {
                    dontEscape = false;
                    newUriString = baseUri.Syntax.InternalResolve(baseUri, relativeUri, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException));
                    if (e !== null)
                    {
                        return false;
                    }
                }
                let $v2 = new $.$spu.System.UriCreationOptions();
                result.$v ??= $.$spu.System.Uri.CreateHelper(newUriString, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException), $.$ref(() => $v2, ($v) => $v2 = $v));
                result.$v?.DebugSetLeftCtor();
                return e === null && $.$spu.System.Uri.op_Inequality(result.$v, null) && result.$v.IsAbsoluteUri;
            }
            /*string */ GetComponents(/*UriComponents*/ components, /*UriFormat*/ format)
            {
                if (this.DisablePathAndQueryCanonicalization && (components & (16/*UriComponents.Path*/ | 32/*UriComponents.Query*/)) !== 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_GetComponentsCalledWhenCanonicalizationDisabled);
                }
                return this.InternalGetComponents(components, format);
            }
            /*string */ InternalGetComponents(/*UriComponents*/ components, /*UriFormat*/ format)
            {
                if (((components & -2147483648/*UriComponents.SerializationInfoString*/) !== 0) && components !== -2147483648/*UriComponents.SerializationInfoString*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("components", $.$box(components, $.$spu.System.UriComponents), $.$spu.System.SR.net_uri_NotJustSerialization);
                }
                if ((format & ~3/*UriFormat.SafeUnescaped*/) !== 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("format");
                }
                if (this.IsNotAbsoluteUri)
                {
                    if (components === -2147483648/*UriComponents.SerializationInfoString*/)
                    {
                        return this.GetRelativeSerializationString(format);
                    }
                    else 
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                    }
                }
                if (this.Syntax.IsSimple)
                {
                    return this.GetComponentsHelper(components, format);
                }
                return this.Syntax.InternalGetComponents(this, components, format);
            }
            static /*int */ Compare(/*Uri?*/ uri1, /*Uri?*/ uri2, /*UriComponents*/ partsToCompare, /*UriFormat*/ compareFormat, /*StringComparison*/ comparisonType)
            {
                if (uri1 === null)
                {
                    if (uri2 === null)
                    {
                        return 0;
                    }
                    return -1;
                }
                if (uri2 === null)
                {
                    return 1;
                }
                if (!uri1.IsAbsoluteUri || !uri2.IsAbsoluteUri)
                {
                    return uri1.IsAbsoluteUri ? 1 : uri2.IsAbsoluteUri ? -1 : $.$spc.System.String.Compare$2(uri1.OriginalString, uri2.OriginalString, comparisonType);
                }
                return $.$spc.System.String.Compare$2(uri1.GetParts(partsToCompare, compareFormat), uri2.GetParts(partsToCompare, compareFormat), comparisonType);
            }
            /*bool */ IsWellFormedOriginalString()
            {
                if (this.IsNotAbsoluteUri || this.Syntax.IsSimple)
                {
                    return this.InternalIsWellFormedOriginalString();
                }
                return this.Syntax.InternalIsWellFormedOriginalString(this);
            }
            static /*bool */ IsWellFormedUriString(/*string?*/ uriString, /*UriKind*/ uriKind)
            {
                /*Uri?*/ let result;
                if (!$.$spu.System.Uri.TryCreate(uriString, uriKind, $.$ref(() => result, ($v) => result = $v, $.$spu.System.Uri)))
                {
                    return false;
                }
                return result.IsWellFormedOriginalString();
            }
            /*bool */ InternalIsWellFormedOriginalString()
            {
                if (this.UserDrivenParsing)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.Format($.$spu.System.SR.net_uri_UserDrivenParsing, $.$spc.System.Object.GetType.call(this)));
                }
                /*fixed*/ 
                {
                    /*char**/ let str = $.$spc.System.String.GetPinnableReference.call(this._string);
                    /*int*/ let idx = 0;
                    if (!this.IsAbsoluteUri)
                    {
                        if ($.$spu.System.Uri.CheckForColonInFirstPathSegment(this._string))
                        {
                            return false;
                        }
                        return (this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$spc.System.Int32), this._string.length, /*\uFFFE*/ 65534) & (16/*Check.BackslashInPath*/ | 1/*Check.EscapedCanonical*/)) === 1/*Check.EscapedCanonical*/;
                    }
                    if (this.IsImplicitFile)
                    {
                        return false;
                    }
                    this.EnsureParseRemaining();
                    /*Flags*/ let nonCanonical = (this._flags & (8064n | 16888498602639360n));
                    if ((nonCanonical & (1125899906842624n | 2251799813685248n | 4503599627370496n | 9007199254740992n)) !== 0n)
                    {
                        if ((nonCanonical & (128n | 1125899906842624n)) === (128n | 1125899906842624n))
                        {
                            nonCanonical &= ~(128n | 1125899906842624n);
                        }
                        if ((nonCanonical & (1024n | 2251799813685248n)) === (1024n | 2251799813685248n))
                        {
                            nonCanonical &= ~(1024n | 2251799813685248n);
                        }
                        if ((nonCanonical & (2048n | 4503599627370496n)) === (2048n | 4503599627370496n))
                        {
                            nonCanonical &= ~(2048n | 4503599627370496n);
                        }
                        if ((nonCanonical & (4096n | 9007199254740992n)) === (4096n | 9007199254740992n))
                        {
                            nonCanonical &= ~(4096n | 9007199254740992n);
                        }
                    }
                    if ((nonCanonical & 8064n & (128n | 1024n | 2048n | 4096n)) !== 0n)
                    {
                        return false;
                    }
                    if (this.InFact(68719476736n))
                    {
                        idx = ((((this._info.Offset.Scheme + this._syntax.SchemeName.length) | 0) + 2) | 0);
                        if (idx >= this._info.Offset.User || $.$spc.System.String.get_Chars.call(this._string, ((idx - 1) | 0)) === /*\\*/ 92 || $.$spc.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92)
                        {
                            return false;
                        }
                        if (this.InFact(17592186044416n | 8796093022208n))
                        {
                            while(++idx < this._info.Offset.User && ($.$spc.System.String.get_Chars.call(this._string, idx) === /*/*/ 47 || $.$spc.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92))
                            {
                                return false;
                            }
                        }
                    }
                    if (this.InFact(16384n) && this._info.Offset.Query > this._info.Offset.Path)
                    {
                        return false;
                    }
                    if (this.InFact(32768n))
                    {
                        return false;
                    }
                    if (this.IsDosPath && $.$spc.System.String.get_Chars.call(this._string, ((((this._info.Offset.Path + this.SecuredPathIndex) | 0) - 1) | 0)) === /*|*/ 124)
                    {
                        return false;
                    }
                    if ((this._flags & 2199023255552n) === 0n && this.HostType !== 4294967296n)
                    {
                        idx = this._info.Offset.User;
                        /*Check*/ let result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$spc.System.Int32), this._info.Offset.Path, /*/*/ 47);
                        if (((result & (32/*Check.ReservedFound*/ | 16/*Check.BackslashInPath*/ | 1/*Check.EscapedCanonical*/)) !== 1/*Check.EscapedCanonical*/) && (!this.IriParsing || (result & (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) !== (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                        {
                            return false;
                        }
                    }
                    if ((this._flags & (1n | 68719476736n)) === (1n | 68719476736n))
                    {
                        idx = this._syntax.SchemeName.length;
                        while(str.GetAt(idx++) !== /*:*/ 58)
                        {
                        }
                        if (((idx + 1) | 0) >= this._string.length || str.GetAt(idx) !== /*/*/ 47 || str.GetAt(((idx + 1) | 0)) !== /*/*/ 47)
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            static /*string */ UnescapeDataString(/*string*/ stringToUnescape)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(stringToUnescape, "stringToUnescape");
                return $.$spu.System.Uri.UnescapeDataString$2($.$spc.System.String.op_Implicit(stringToUnescape), stringToUnescape);
            }
            static /*string */ UnescapeDataString$1(/*ReadOnlySpan<char>*/ charsToUnescape)
            {
                return $.$spu.System.Uri.UnescapeDataString$2(charsToUnescape, null);
            }
            static /*string */ UnescapeDataString$2(/*ReadOnlySpan<char>*/ charsToUnescape, /*string?*/ backingString)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(backingString === null || backingString.length === charsToUnescape.Length, "backingString is null || backingString.Length == charsToUnescape.Length");
                /*int*/ let indexOfFirstToUnescape = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, charsToUnescape, /*%*/ 37);
                if (indexOfFirstToUnescape < 0)
                {
                    return backingString ?? $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(charsToUnescape);
                }
                /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*StackallocThreshold*/, null));
                vsb.EnsureCapacity(((charsToUnescape.Length - indexOfFirstToUnescape) | 0));
                $.$spu.System.UriHelper.UnescapeString$3(charsToUnescape.Slice(indexOfFirstToUnescape), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, null, false);
                /*string*/ let result = $.$spc.System.String.Concat$10(charsToUnescape.Slice$1(0, indexOfFirstToUnescape), vsb.AsSpan$1());
                vsb.Dispose();
                return result;
            }
            static /*bool */ TryUnescapeDataString(/*ReadOnlySpan<char>*/ charsToUnescape, /*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                /*int*/ let indexOfFirstToUnescape = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, charsToUnescape, /*%*/ 37);
                if (indexOfFirstToUnescape < 0)
                {
                    if (charsToUnescape.TryCopyTo(destination))
                    {
                        charsWritten.$v = charsToUnescape.Length;
                        return true;
                    }
                    charsWritten.$v = 0;
                    return false;
                }
                /*scoped ValueStringBuilder*/ let vsb;
                /*bool*/ let overlapped = $.$spc.System.MemoryExtensions.Overlaps$2($.$spc.System.Char, charsToUnescape, $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(destination)) && !$.$spc.System.Runtime.CompilerServices.Unsafe.AreSame($.$spc.System.Char, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Char, charsToUnescape), $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, destination));
                if (overlapped)
                {
                    vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*StackallocThreshold*/, null));
                    vsb.EnsureCapacity(((charsToUnescape.Length - indexOfFirstToUnescape) | 0));
                }
                else 
                {
                    vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$2(destination.Slice(indexOfFirstToUnescape));
                }
                $.$spu.System.UriHelper.UnescapeString$3(charsToUnescape.Slice(indexOfFirstToUnescape), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, null, false);
                /*int*/ let newLength = ((indexOfFirstToUnescape + vsb.Length) | 0);
                $.$spc.System.Diagnostics.Debug.Assert$1(newLength <= charsToUnescape.Length, "newLength <= charsToUnescape.Length");
                if (destination.Length >= newLength)
                {
                    charsToUnescape.Slice$1(0, indexOfFirstToUnescape).CopyTo(destination);
                    if (overlapped)
                    {
                        vsb.AsSpan$1().CopyTo(destination.Slice(indexOfFirstToUnescape));
                        vsb.Dispose();
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.MemoryExtensions.Overlaps$2($.$spc.System.Char, $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(vsb.RawChars), $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(destination)), "vsb.RawChars.Overlaps(destination)");
                    }
                    charsWritten.$v = newLength;
                    return true;
                }
                vsb.Dispose();
                charsWritten.$v = 0;
                return false;
            }
            static /*string */ EscapeUriString(/*string*/ stringToEscape)
            {
                return $.$spu.System.UriHelper.EscapeString(stringToEscape, false, $.$spu.System.UriHelper.UnreservedReserved);
            }
            static /*string */ EscapeDataString(/*string*/ stringToEscape)
            {
                return $.$spu.System.UriHelper.EscapeString(stringToEscape, false, $.$spu.System.UriHelper.Unreserved);
            }
            static /*string */ EscapeDataString$1(/*ReadOnlySpan<char>*/ charsToEscape)
            {
                return $.$spu.System.UriHelper.EscapeString$1(charsToEscape, false, $.$spu.System.UriHelper.Unreserved, null);
            }
            static /*bool */ TryEscapeDataString(/*ReadOnlySpan<char>*/ charsToEscape, /*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                return $.$spu.System.UriHelper.TryEscapeDataString(charsToEscape, destination, charsWritten);
            }
            /*string */ EscapeUnescapeIri(/*string*/ input, /*int*/ start, /*int*/ end, /*UriComponents*/ component)
            {
                /*fixed*/ 
                {
                    /*char**/ let pInput = $.$spc.System.String.GetPinnableReference.call(input);
                    return $.$spu.System.IriHelper.EscapeUnescapeIri(pInput, start, end, component);
                }
            }
            $ctor$1(/*Flags*/ flags, /*UriParser?*/ uriParser, /*string*/ uri)
            {
                super.$ctor();
                {
                    this._flags = flags;
                    this._syntax = uriParser;
                    this._string = uri;
                    if (uriParser === null)
                    {
                        this.DebugSetLeftCtor();
                    }
                }
                return this;
            }
            static /*Uri? */ CreateHelper(/*string*/ uriString, /*bool*/ dontEscape, /*UriKind*/ uriKind, /*ref UriFormatException?*/ e, /*in UriCreationOptions*/ creationOptions)
            {
                if (uriKind < 0/*UriKind.RelativeOrAbsolute*/ || uriKind > 2/*UriKind.Relative*/)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spu.System.SR.Format($.$spu.System.SR.net_uri_InvalidUriKind, $.$box(uriKind, $.$spu.System.UriKind)));
                }
                /*UriParser?*/ let syntax = null;
                /*Flags*/ let flags = 0n;
                /*ParsingError*/ let err = $.$spu.System.Uri.ParseScheme(uriString, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => flags, ($v) => flags = $v, null), $.$ref(() => syntax, ($v) => syntax = $v, $.$spu.System.UriParser));
                if (dontEscape)
                {
                    flags |= 34359738368n;
                }
                if (creationOptions.$v.DangerousDisablePathAndQueryCanonicalization)
                {
                    flags |= 36028797018963968n;
                }
                if (err !== 0/*ParsingError.None*/)
                {
                    if (uriKind !== 1/*UriKind.Absolute*/ && err <= 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                    {
                        return new $.$spu.System.Uri().$ctor$1((flags & 34359738368n), null, uriString);
                    }
                    return null;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(syntax !== null, "syntax != null");
                /*Uri*/ let result = new $.$spu.System.Uri().$ctor$1(flags, syntax, uriString);
                try
                {
                    result.InitializeUri(err, uriKind, e);
                    if (e.$v === null)
                    {
                        result.DebugSetLeftCtor();
                        return result;
                    }
                    return null;
                }
                catch(ee)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!syntax.IsSimple, "A UriPraser threw on InitializeAndValidate.");
                    e.$v = ee;
                    return null;
                }
            }
            static /*Uri? */ ResolveHelper(/*Uri*/ baseUri, /*Uri?*/ relativeUri, /*ref string?*/ newUriString, /*ref bool*/ userEscaped)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!baseUri.IsNotAbsoluteUri && !baseUri.UserDrivenParsing, "Uri::ResolveHelper()|baseUri is not Absolute or is controlled by User Parser.");
                /*string*/ let relativeStr;
                if (!(relativeUri === null))
                {
                    if (relativeUri.IsAbsoluteUri)
                    {
                        return relativeUri;
                    }
                    relativeStr = relativeUri.OriginalString;
                    userEscaped.$v = relativeUri.UserEscaped;
                }
                else 
                {
                    relativeStr = $.$spc.System.String.Empty;
                }
                if (relativeStr.length > 0 && ($.$spu.System.UriHelper.IsLWS($.$spc.System.String.get_Chars.call(relativeStr, 0)) || $.$spu.System.UriHelper.IsLWS($.$spc.System.String.get_Chars.call(relativeStr, ((relativeStr.length - 1) | 0)))))
                {
                    relativeStr = $.$spc.System.String.Trim$2.call(relativeStr, $.$spu.System.UriHelper.s_WSchars);
                }
                if (relativeStr.length === 0)
                {
                    newUriString.$v = baseUri.GetParts(127/*UriComponents.AbsoluteUri*/, baseUri.UserEscaped ? 1/*UriFormat.UriEscaped*/ : 3/*UriFormat.SafeUnescaped*/);
                    return null;
                }
                if ($.$spc.System.String.get_Chars.call(relativeStr, 0) === /*#*/ 35 && !baseUri.IsImplicitFile && baseUri.Syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/))
                {
                    newUriString.$v = baseUri.GetParts(127/*UriComponents.AbsoluteUri*/ & ~64/*UriComponents.Fragment*/, 1/*UriFormat.UriEscaped*/) + relativeStr;
                    return null;
                }
                if ($.$spc.System.String.get_Chars.call(relativeStr, 0) === /*?*/ 63 && !baseUri.IsImplicitFile && baseUri.Syntax.InFact(32/*UriSyntaxFlags.MayHaveQuery*/))
                {
                    newUriString.$v = baseUri.GetParts(127/*UriComponents.AbsoluteUri*/ & ~32/*UriComponents.Query*/ & ~64/*UriComponents.Fragment*/, 1/*UriFormat.UriEscaped*/) + relativeStr;
                    return null;
                }
                if (relativeStr.length >= 3 && ($.$spc.System.String.get_Chars.call(relativeStr, 1) === /*:*/ 58 || $.$spc.System.String.get_Chars.call(relativeStr, 1) === /*|*/ 124) && $.$spc.System.Char.IsAsciiLetter($.$spc.System.String.get_Chars.call(relativeStr, 0)) && ($.$spc.System.String.get_Chars.call(relativeStr, 2) === /*\\*/ 92 || $.$spc.System.String.get_Chars.call(relativeStr, 2) === /*/*/ 47))
                {
                    if (baseUri.IsImplicitFile)
                    {
                        newUriString.$v = relativeStr;
                        return null;
                    }
                    else if (baseUri.Syntax.InFact(1048576/*UriSyntaxFlags.AllowDOSPath*/))
                    {
                        /*string*/ let prefix;
                        if (baseUri.InFact(68719476736n))
                        {
                            prefix = baseUri.Syntax.InFact(2097152/*UriSyntaxFlags.PathIsRooted*/) ? ":///" : "://";
                        }
                        else 
                        {
                            prefix = baseUri.Syntax.InFact(2097152/*UriSyntaxFlags.PathIsRooted*/) ? ":/" : ":";
                        }
                        newUriString.$v = baseUri.Scheme + prefix + relativeStr;
                        return null;
                    }
                }
                $.$spu.System.Uri.GetCombinedString(baseUri, relativeStr, userEscaped.$v, newUriString);
                if ($.$spc.System.Object.ReferenceEquals(newUriString.$v, baseUri._string))
                {
                    return baseUri;
                }
                return null;
            }
            /*string */ GetRelativeSerializationString(/*UriFormat*/ format)
            {
                if (format === 1/*UriFormat.UriEscaped*/)
                {
                    return $.$spu.System.UriHelper.EscapeString(this._string, true, $.$spu.System.UriHelper.UnreservedReserved);
                }
                else if (format === 2/*UriFormat.Unescaped*/)
                {
                    return $.$spu.System.Uri.UnescapeDataString(this._string);
                }
                else if (format === 3/*UriFormat.SafeUnescaped*/)
                {
                    if (this._string.length === 0)
                    {
                        return $.$spc.System.String.Empty;
                    }
                    /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*StackallocThreshold*/, null));
                    $.$spu.System.UriHelper.UnescapeString$3($.$spc.System.String.op_Implicit(this._string), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 3/*UnescapeMode.EscapeUnescape*/, null, false);
                    return $.$spu.System.Text.ValueStringBuilder.ToString.call(vsb);
                }
                else 
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("format");
                }
            }
            /*string */ GetComponentsHelper(/*UriComponents*/ uriComponents, /*UriFormat*/ uriFormat)
            {
                if (uriComponents === 1/*UriComponents.Scheme*/)
                {
                    return this._syntax.SchemeName;
                }
                if ((uriComponents & -2147483648/*UriComponents.SerializationInfoString*/) !== 0)
                {
                    uriComponents |= 127/*UriComponents.AbsoluteUri*/;
                }
                this.EnsureParseRemaining();
                if ((uriComponents & 256/*UriComponents.NormalizedHost*/) !== 0)
                {
                    uriComponents |= 4/*UriComponents.Host*/;
                }
                if ((uriComponents & 4/*UriComponents.Host*/) !== 0)
                {
                    this.EnsureHostString(true);
                }
                if (uriComponents === 8/*UriComponents.Port*/ || uriComponents === 128/*UriComponents.StrongPort*/)
                {
                    if (((this._flags & 549755813888n) !== 0n) || (uriComponents === 128/*UriComponents.StrongPort*/ && this._syntax.DefaultPort !== -1/*UriParser.NoDefaultPort*/))
                    {
                        return $.$spc.System.UInt16.ToString$1.call(this._info.Offset.PortValue, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
                    }
                    return $.$spc.System.String.Empty;
                }
                if ((uriComponents & 128/*UriComponents.StrongPort*/) !== 0)
                {
                    uriComponents |= 8/*UriComponents.Port*/;
                }
                if (uriComponents === 4/*UriComponents.Host*/ && (uriFormat === 1/*UriFormat.UriEscaped*/ || ((this._flags & (4n | 256n)) === 0n)))
                {
                    this.EnsureHostString(false);
                    return this._info.Host;
                }
                switch(uriFormat)
                {
                    case 1/*UriFormat.UriEscaped*/:
                    return this.GetEscapedParts(uriComponents);
                    case 32767/*V1ToStringUnescape*/:
                    case 3/*UriFormat.SafeUnescaped*/:
                    case 2/*UriFormat.Unescaped*/:
                    return this.GetUnescapedParts(uriComponents, uriFormat);
                    default:
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("uriFormat");
                }
            }
            /*bool */ IsBaseOf(/*Uri*/ uri)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(uri, "uri");
                if (!this.IsAbsoluteUri)
                {
                    return false;
                }
                if (this.Syntax.IsSimple)
                {
                    return this.IsBaseOfHelper(uri);
                }
                return this.Syntax.InternalIsBaseOf(this, uri);
            }
            /*bool */ IsBaseOfHelper(/*Uri*/ uriLink)
            {
                /*UriComponents*/ let ComponentsToCompare = 127/*UriComponents.AbsoluteUri*/ & ~64/*UriComponents.Fragment*/ & ~2/*UriComponents.UserInfo*/;
                if (!this.IsAbsoluteUri || this.UserDrivenParsing)
                {
                    return false;
                }
                if (!uriLink.IsAbsoluteUri)
                {
                    /*string?*/ let newUriString = null;
                    /*bool*/ let dontEscape = false;
                    uriLink = $.$spu.System.Uri.ResolveHelper(this, uriLink, $.$ref(() => newUriString, ($v) => newUriString = $v, $.$spc.System.String), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => dontEscape, ($v) => dontEscape = $v, null));
                    if (uriLink === null)
                    {
                        /*UriFormatException?*/ let e = null;
                        let $v4 = new $.$spu.System.UriCreationOptions();
                        uriLink = $.$spu.System.Uri.CreateHelper(newUriString, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException), $.$ref(() => $v4, ($v) => $v4 = $v));
                        if (e !== null)
                        {
                            return false;
                        }
                    }
                }
                if ($.$spc.System.String.op_Inequality(this.Syntax.SchemeName, uriLink.Syntax.SchemeName))
                {
                    return false;
                }
                /*string*/ let self = this.GetParts(ComponentsToCompare, 3/*UriFormat.SafeUnescaped*/);
                /*string*/ let other = uriLink.GetParts(ComponentsToCompare, 3/*UriFormat.SafeUnescaped*/);
                {
                    /*fixed*/ 
                    {
                        /*char**/ let selfPtr = $.$spc.System.String.GetPinnableReference.call(self);
                        /*fixed*/ 
                        {
                            /*char**/ let otherPtr = $.$spc.System.String.GetPinnableReference.call(other);
                            return $.$spu.System.UriHelper.TestForSubPath(selfPtr, self.length, otherPtr, other.length, this.IsUncOrDosPath || uriLink.IsUncOrDosPath);
                        }
                    }
                }
            }
            /*void */ CreateThisFromUri(/*Uri*/ otherUri)
            {
                this.DebugAssertInCtor();
                this._flags = otherUri._flags;
                if (this.InFact(140737488355328n))
                {
                    this._info = otherUri._info;
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!this.InFact(562949953421312n) || otherUri.IsNotAbsoluteUri, "!InFact(Flags.HasUnicode) || otherUri.IsNotAbsoluteUri");
                    this._info = null;
                    if (this.InFact(70368744177664n))
                    {
                        this._flags &= ~(70368744177664n | 140737488355328n | 4294967295n);
                        /*int*/ let portIndex = otherUri._info.Offset.Path;
                        if (this.InFact(549755813888n))
                        {
                            while($.$spc.System.String.get_Chars.call(otherUri._string, portIndex) !== /*:*/ 58 && portIndex > otherUri._info.Offset.Host)
                            {
                                portIndex--;
                            }
                            if ($.$spc.System.String.get_Chars.call(otherUri._string, portIndex) !== /*:*/ 58)
                            {
                                $.$spc.System.Diagnostics.Debug.Fail("Uri failed to locate custom port at index: " + portIndex);
                                portIndex = otherUri._info.Offset.Path;
                            }
                        }
                        this._flags |= $.$cast(portIndex, $.$spu.System.Uri.Flags);
                    }
                }
                this._syntax = otherUri._syntax;
                this._string = otherUri._string;
                this._originalUnicodeString = otherUri._originalUnicodeString;
            }
            /*string*/ static UriSchemeFile = null;
            /*string*/ static UriSchemeFtp = null;
            /*string*/ static UriSchemeSftp = null;
            /*string*/ static UriSchemeFtps = null;
            /*string*/ static UriSchemeGopher = null;
            /*string*/ static UriSchemeHttp = null;
            /*string*/ static UriSchemeHttps = null;
            /*string*/ static UriSchemeWs = null;
            /*string*/ static UriSchemeWss = null;
            /*string*/ static UriSchemeMailto = null;
            /*string*/ static UriSchemeNews = null;
            /*string*/ static UriSchemeNntp = null;
            /*string*/ static UriSchemeSsh = null;
            /*string*/ static UriSchemeTelnet = null;
            /*string*/ static UriSchemeNetTcp = null;
            /*string*/ static UriSchemeNetPipe = null;
            /*string*/ static SchemeDelimiter = null;
            /*int*/ static SchemeLengthLimit = 1024;
            /*int*/ static StackallocThreshold = 512;
            /*string*/ _string = null;
            /*string*/ _originalUnicodeString = null;
            /*UriParser*/ _syntax = null;
            /*Flags*/ _flags = 0n;
            /*UriInfo*/ _info = null;
            static $_Flags;
            static get Flags()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_Flags ??= $asm.$nstr("$spu.System.Uri.Flags", ($self) => class Flags extends $.$spc.System.Enum
                {
                    static Zero = 0n;
                    static SchemeNotCanonical = 1n;
                    static UserNotCanonical = 2n;
                    static HostNotCanonical = 4n;
                    static PortNotCanonical = 8n;
                    static PathNotCanonical = 16n;
                    static QueryNotCanonical = 32n;
                    static FragmentNotCanonical = 64n;
                    static CannotDisplayCanonical = 127n;
                    static E_UserNotCanonical = 128n;
                    static E_HostNotCanonical = 256n;
                    static E_PortNotCanonical = 512n;
                    static E_PathNotCanonical = 1024n;
                    static E_QueryNotCanonical = 2048n;
                    static E_FragmentNotCanonical = 4096n;
                    static E_CannotDisplayCanonical = 8064n;
                    static ShouldBeCompressed = 8192n;
                    static FirstSlashAbsent = 16384n;
                    static BackslashInPath = 32768n;
                    static IndexMask = 4294967295n;
                    static HostTypeMask = 30064771072n;
                    static HostNotParsed = 0n;
                    static IPv6HostType = 4294967296n;
                    static IPv4HostType = 8589934592n;
                    static DnsHostType = 12884901888n;
                    static UncHostType = 17179869184n;
                    static BasicHostType = 21474836480n;
                    static UnusedHostType = 25769803776n;
                    static UnknownHostType = 30064771072n;
                    static UserEscaped = 34359738368n;
                    static AuthorityFound = 68719476736n;
                    static HasUserInfo = 137438953472n;
                    static LoopbackHost = 274877906944n;
                    static NotDefaultPort = 549755813888n;
                    static UserDrivenParsing = 1099511627776n;
                    static CanonicalDnsHost = 2199023255552n;
                    static ErrorOrParsingRecursion = 4398046511104n;
                    static DosPath = 8796093022208n;
                    static UncPath = 17592186044416n;
                    static ImplicitFile = 35184372088832n;
                    static MinimalUriInfoSet = 70368744177664n;
                    static AllUriInfoSet = 140737488355328n;
                    static IdnHost = 281474976710656n;
                    static HasUnicode = 562949953421312n;
                    static UserIriCanonical = 1125899906842624n;
                    static PathIriCanonical = 2251799813685248n;
                    static QueryIriCanonical = 4503599627370496n;
                    static FragmentIriCanonical = 9007199254740992n;
                    static IriCanonical = 16888498602639360n;
                    static UnixPath = 18014398509481984n;
                    static DisablePathAndQueryCanonicalization = 36028797018963968n;
                    static CustomParser_ParseMinimalAlreadyCalled = 72057594037927936n;
                    static Debug_LeftConstructor = 144115188075855872n;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Zero": 0n,
                            "SchemeNotCanonical": 1n,
                            "UserNotCanonical": 2n,
                            "HostNotCanonical": 4n,
                            "PortNotCanonical": 8n,
                            "PathNotCanonical": 16n,
                            "QueryNotCanonical": 32n,
                            "FragmentNotCanonical": 64n,
                            "CannotDisplayCanonical": 127n,
                            "E_UserNotCanonical": 128n,
                            "E_HostNotCanonical": 256n,
                            "E_PortNotCanonical": 512n,
                            "E_PathNotCanonical": 1024n,
                            "E_QueryNotCanonical": 2048n,
                            "E_FragmentNotCanonical": 4096n,
                            "E_CannotDisplayCanonical": 8064n,
                            "ShouldBeCompressed": 8192n,
                            "FirstSlashAbsent": 16384n,
                            "BackslashInPath": 32768n,
                            "IndexMask": 4294967295n,
                            "HostTypeMask": 30064771072n,
                            "HostNotParsed": 0n,
                            "IPv6HostType": 4294967296n,
                            "IPv4HostType": 8589934592n,
                            "DnsHostType": 12884901888n,
                            "UncHostType": 17179869184n,
                            "BasicHostType": 21474836480n,
                            "UnusedHostType": 25769803776n,
                            "UnknownHostType": 30064771072n,
                            "UserEscaped": 34359738368n,
                            "AuthorityFound": 68719476736n,
                            "HasUserInfo": 137438953472n,
                            "LoopbackHost": 274877906944n,
                            "NotDefaultPort": 549755813888n,
                            "UserDrivenParsing": 1099511627776n,
                            "CanonicalDnsHost": 2199023255552n,
                            "ErrorOrParsingRecursion": 4398046511104n,
                            "DosPath": 8796093022208n,
                            "UncPath": 17592186044416n,
                            "ImplicitFile": 35184372088832n,
                            "MinimalUriInfoSet": 70368744177664n,
                            "AllUriInfoSet": 140737488355328n,
                            "IdnHost": 281474976710656n,
                            "HasUnicode": 562949953421312n,
                            "UserIriCanonical": 1125899906842624n,
                            "PathIriCanonical": 2251799813685248n,
                            "QueryIriCanonical": 4503599627370496n,
                            "FragmentIriCanonical": 9007199254740992n,
                            "IriCanonical": 16888498602639360n,
                            "UnixPath": 18014398509481984n,
                            "DisablePathAndQueryCanonicalization": 36028797018963968n,
                            "CustomParser_ParseMinimalAlreadyCalled": 72057594037927936n,
                            "Debug_LeftConstructor": 144115188075855872n
                        };
                    }
                    static $h = 1874068;
                    static $z = 8;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.UInt64; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":983041,"l":[{"t":1874068,"n":"Zero","d":1874068,"h":4296841364,"f":33},{"t":1874068,"n":"SchemeNotCanonical","d":1874068,"h":8591808660,"f":33},{"t":1874068,"n":"UserNotCanonical","d":1874068,"h":12886775956,"f":33},{"t":1874068,"n":"HostNotCanonical","d":1874068,"h":17181743252,"f":33},{"t":1874068,"n":"PortNotCanonical","d":1874068,"h":21476710548,"f":33},{"t":1874068,"n":"PathNotCanonical","d":1874068,"h":25771677844,"f":33},{"t":1874068,"n":"QueryNotCanonical","d":1874068,"h":30066645140,"f":33},{"t":1874068,"n":"FragmentNotCanonical","d":1874068,"h":34361612436,"f":33},{"t":1874068,"n":"CannotDisplayCanonical","d":1874068,"h":38656579732,"f":33},{"t":1874068,"n":"E_UserNotCanonical","d":1874068,"h":42951547028,"f":33},{"t":1874068,"n":"E_HostNotCanonical","d":1874068,"h":47246514324,"f":33},{"t":1874068,"n":"E_PortNotCanonical","d":1874068,"h":51541481620,"f":33},{"t":1874068,"n":"E_PathNotCanonical","d":1874068,"h":55836448916,"f":33},{"t":1874068,"n":"E_QueryNotCanonical","d":1874068,"h":60131416212,"f":33},{"t":1874068,"n":"E_FragmentNotCanonical","d":1874068,"h":64426383508,"f":33},{"t":1874068,"n":"E_CannotDisplayCanonical","d":1874068,"h":68721350804,"f":33},{"t":1874068,"n":"ShouldBeCompressed","d":1874068,"h":73016318100,"f":33},{"t":1874068,"n":"FirstSlashAbsent","d":1874068,"h":77311285396,"f":33},{"t":1874068,"n":"BackslashInPath","d":1874068,"h":81606252692,"f":33},{"t":1874068,"n":"IndexMask","d":1874068,"h":85901219988,"f":33},{"t":1874068,"n":"HostTypeMask","d":1874068,"h":90196187284,"f":33},{"t":1874068,"n":"HostNotParsed","d":1874068,"h":94491154580,"f":33},{"t":1874068,"n":"IPv6HostType","d":1874068,"h":98786121876,"f":33},{"t":1874068,"n":"IPv4HostType","d":1874068,"h":103081089172,"f":33},{"t":1874068,"n":"DnsHostType","d":1874068,"h":107376056468,"f":33},{"t":1874068,"n":"UncHostType","d":1874068,"h":111671023764,"f":33},{"t":1874068,"n":"BasicHostType","d":1874068,"h":115965991060,"f":33},{"t":1874068,"n":"UnusedHostType","d":1874068,"h":120260958356,"f":33},{"t":1874068,"n":"UnknownHostType","d":1874068,"h":124555925652,"f":33},{"t":1874068,"n":"UserEscaped","d":1874068,"h":128850892948,"f":33},{"t":1874068,"n":"AuthorityFound","d":1874068,"h":133145860244,"f":33},{"t":1874068,"n":"HasUserInfo","d":1874068,"h":137440827540,"f":33},{"t":1874068,"n":"LoopbackHost","d":1874068,"h":141735794836,"f":33},{"t":1874068,"n":"NotDefaultPort","d":1874068,"h":146030762132,"f":33},{"t":1874068,"n":"UserDrivenParsing","d":1874068,"h":150325729428,"f":33},{"t":1874068,"n":"CanonicalDnsHost","d":1874068,"h":154620696724,"f":33},{"t":1874068,"n":"ErrorOrParsingRecursion","d":1874068,"h":158915664020,"f":33},{"t":1874068,"n":"DosPath","d":1874068,"h":163210631316,"f":33},{"t":1874068,"n":"UncPath","d":1874068,"h":167505598612,"f":33},{"t":1874068,"n":"ImplicitFile","d":1874068,"h":171800565908,"f":33},{"t":1874068,"n":"MinimalUriInfoSet","d":1874068,"h":176095533204,"f":33},{"t":1874068,"n":"AllUriInfoSet","d":1874068,"h":180390500500,"f":33},{"t":1874068,"n":"IdnHost","d":1874068,"h":184685467796,"f":33},{"t":1874068,"n":"HasUnicode","d":1874068,"h":188980435092,"f":33},{"t":1874068,"n":"UserIriCanonical","d":1874068,"h":193275402388,"f":33},{"t":1874068,"n":"PathIriCanonical","d":1874068,"h":197570369684,"f":33},{"t":1874068,"n":"QueryIriCanonical","d":1874068,"h":201865336980,"f":33},{"t":1874068,"n":"FragmentIriCanonical","d":1874068,"h":206160304276,"f":33},{"t":1874068,"n":"IriCanonical","d":1874068,"h":210455271572,"f":33},{"t":1874068,"n":"UnixPath","d":1874068,"h":214750238868,"f":33},{"t":1874068,"n":"DisablePathAndQueryCanonicalization","d":1874068,"h":219045206164,"f":33},{"t":1874068,"n":"CustomParser_ParseMinimalAlreadyCalled","d":1874068,"h":223340173460,"f":33},{"t":1874068,"n":"Debug_LeftConstructor","d":1874068,"h":227635140756,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1874068,"h":231930108052,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":1742996,"h":1874068,"a":[{"t":47710209,"c":4342677505}]}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Uri.Flags`; }
                }, $cls, ($v) => $cls.$_Flags = $v);
            }
            /*void */ DebugSetLeftCtor()
            {
                this._flags |= 144115188075855872n;
                this.AssertInvariants();
            }
            /*void */ AssertInvariants()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.InFact(70368744177664n) === (!(this._info === null)), "InFact(Flags.MinimalUriInfoSet) == (_info is not null)");
                let info;
                if ($.$is(this._info, $.$spu.System.Uri.UriInfo, { set $v(v){ info = v; } }))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this.IsAbsoluteUri, "IsAbsoluteUri");
                    /*Offset*/ let offset = info.Offset;
                    $.$spc.System.Diagnostics.Debug.Assert$1(offset.Scheme >= 0, "offset.Scheme >= 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(offset.User >= 0 && offset.User >= offset.Scheme, "offset.User >= 0 && offset.User >= offset.Scheme");
                    $.$spc.System.Diagnostics.Debug.Assert$1(offset.Host >= 0 && offset.Host >= offset.User, "offset.Host >= 0 && offset.Host >= offset.User");
                    $.$spc.System.Diagnostics.Debug.Assert$1(offset.Path >= 0, "offset.Path >= 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(offset.End >= 0 && offset.End >= offset.Path, "offset.End >= 0 && offset.End >= offset.Path");
                    if (this.InFact(140737488355328n))
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(offset.Path >= offset.Host, "offset.Path >= offset.Host");
                        $.$spc.System.Diagnostics.Debug.Assert$1(offset.Query >= 0 && offset.Query >= offset.Path, "offset.Query >= 0 && offset.Query >= offset.Path");
                        $.$spc.System.Diagnostics.Debug.Assert$1(offset.Fragment >= 0 && offset.Fragment >= offset.Query, "offset.Fragment >= 0 && offset.Fragment >= offset.Query");
                        $.$spc.System.Diagnostics.Debug.Assert$1(offset.End >= offset.Fragment && offset.End <= this._string.length, "offset.End >= offset.Fragment && offset.End <= _string.Length");
                    }
                    else 
                    {
                        if (!this.InFact(562949953421312n))
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(offset.Path >= offset.Host, "offset.Path >= offset.Host");
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(offset.Query === 0, "offset.Query == 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(offset.Fragment === 0, "offset.Fragment == 0");
                    }
                }
                else 
                {
                    if (this.IsAbsoluteUri && this.IriParsing)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Text.Ascii.IsValid$1($.$spc.System.String.op_Implicit(this._string)), "Ascii.IsValid(_string)");
                    }
                }
            }
            /*void */ DebugAssertInCtor()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((this._flags & 144115188075855872n) === 0n, "(_flags & Flags.Debug_LeftConstructor) == 0");
            }
            static $_UriInfo;
            static get UriInfo()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_UriInfo ??= $asm.$ncls("$spu.System.Uri.UriInfo", ($self) => class UriInfo extends $.$spc.System.Object
                {
                    /*Offset*/ Offset;
                    /*string?*/ String = null;
                    /*string?*/ Host = null;
                    /*string?*/ IdnHost = null;
                    /*string?*/ PathAndQuery = null;
                    /*MoreInfo?*/ _moreInfo = null;
                    /*MoreInfo */ get MoreInfo()
                    {
                        if (this._moreInfo === null)
                        {
                            $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spu.System.Uri.MoreInfo, $.$ref(() => this._moreInfo, ($v) => this._moreInfo = $v, $.$spu.System.Uri.MoreInfo), new $.$spu.System.Uri.MoreInfo().$ctor$1(), null);
                        }
                        return this._moreInfo;
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Offset = $.$default($.$spu.System.Uri.Offset);
                    }
                    static $h = 2070676;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1939604,"g":{"r":0,"d":0,"h":34361809044,"f":1},"n":"MoreInfo","d":2070676,"h":30066841748,"f":1}],"l":[{"t":2005140,"n":"Offset","d":2070676,"h":4297037972,"f":1},{"t":1310721,"n":"String","d":2070676,"h":8592005268,"f":1},{"t":1310721,"n":"Host","d":2070676,"h":12886972564,"f":1},{"t":1310721,"n":"IdnHost","d":2070676,"h":17181939860,"f":1},{"t":1310721,"n":"PathAndQuery","d":2070676,"h":21476907156,"f":1},{"t":1939604,"n":"_moreInfo","d":2070676,"h":25771874452,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":2070676,"h":38656776340,"f":1}],"d":1742996,"h":2070676}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Uri.UriInfo`; }
                }, $cls, ($v) => $cls.$_UriInfo = $v);
            }
            static $_Offset;
            static get Offset()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_Offset ??= $asm.$nstr("$spu.System.Uri.Offset", ($self) => class Offset extends $.$spc.System.ValueType
                {
                    /*int*/  get Scheme() { return this.$getField(0, $.$spc.System.Int32); }
                    /*int*/  set Scheme(value) { this.$setField(0, $.$spc.System.Int32, value); }
                    /*int*/  get User() { return this.$getField(4, $.$spc.System.Int32); }
                    /*int*/  set User(value) { this.$setField(4, $.$spc.System.Int32, value); }
                    /*int*/  get Host() { return this.$getField(8, $.$spc.System.Int32); }
                    /*int*/  set Host(value) { this.$setField(8, $.$spc.System.Int32, value); }
                    /*ushort*/  get PortValue() { return this.$getField(12, $.$spc.System.UInt16); }
                    /*ushort*/  set PortValue(value) { this.$setField(12, $.$spc.System.UInt16, value); }
                    /*int*/  get Path() { return this.$getField(14, $.$spc.System.Int32); }
                    /*int*/  set Path(value) { this.$setField(14, $.$spc.System.Int32, value); }
                    /*int*/  get Query() { return this.$getField(18, $.$spc.System.Int32); }
                    /*int*/  set Query(value) { this.$setField(18, $.$spc.System.Int32, value); }
                    /*int*/  get Fragment() { return this.$getField(22, $.$spc.System.Int32); }
                    /*int*/  set Fragment(value) { this.$setField(22, $.$spc.System.Int32, value); }
                    /*int*/  get End() { return this.$getField(26, $.$spc.System.Int32); }
                    /*int*/  set End(value) { this.$setField(26, $.$spc.System.Int32, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Scheme = this.Scheme;
                        copy.User = this.User;
                        copy.Host = this.Host;
                        copy.PortValue = this.PortValue;
                        copy.Path = this.Path;
                        copy.Query = this.Query;
                        copy.Fragment = this.Fragment;
                        copy.End = this.End;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Scheme = 0;
                        this.User = 0;
                        this.Host = 0;
                        this.PortValue = 0;
                        this.Path = 0;
                        this.Query = 0;
                        this.Fragment = 0;
                        this.End = 0;
                    }
                    static $h = 2005140;
                    static $z = 30;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"Scheme","d":2005140,"h":4296972436,"f":1},{"t":655361,"n":"User","d":2005140,"h":8591939732,"f":1},{"t":655361,"n":"Host","d":2005140,"h":12886907028,"f":1},{"t":589825,"n":"PortValue","d":2005140,"h":17181874324,"f":1},{"t":655361,"n":"Path","d":2005140,"h":21476841620,"f":1},{"t":655361,"n":"Query","d":2005140,"h":25771808916,"f":1},{"t":655361,"n":"Fragment","d":2005140,"h":30066776212,"f":1},{"t":655361,"n":"End","d":2005140,"h":34361743508,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":2005140,"h":38656710804,"f":1}],"d":1742996,"h":2005140}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Uri.Offset`; }
                }, $cls, ($v) => $cls.$_Offset = $v);
            }
            static $_MoreInfo;
            static get MoreInfo()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_MoreInfo ??= $asm.$ncls("$spu.System.Uri.MoreInfo", ($self) => class MoreInfo extends $.$spc.System.Object
                {
                    /*string?*/ Path = null;
                    /*string?*/ Query = null;
                    /*string?*/ Fragment = null;
                    /*string?*/ AbsoluteUri = null;
                    /*string?*/ RemoteUrl = null;
                    /*string?*/ ScopeId = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 1939604;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"Path","d":1939604,"h":4296906900,"f":1},{"t":1310721,"n":"Query","d":1939604,"h":8591874196,"f":1},{"t":1310721,"n":"Fragment","d":1939604,"h":12886841492,"f":1},{"t":1310721,"n":"AbsoluteUri","d":1939604,"h":17181808788,"f":1},{"t":1310721,"n":"RemoteUrl","d":1939604,"h":21476776084,"f":1},{"t":1310721,"n":"ScopeId","d":1939604,"h":25771743380,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1939604,"h":30066710676,"f":1}],"d":1742996,"h":1939604}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Uri.MoreInfo`; }
                }, $cls, ($v) => $cls.$_MoreInfo = $v);
            }
            /*void */ InterlockedSetFlags(/*Flags*/ flags)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._syntax !== null, "_syntax != null");
                if (this._syntax.IsSimple)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spu.System.Uri.Flags.$z === $.$spc.System.UInt64.$z, "sizeof(Flags) == sizeof(ulong)");
                    $.$spc.System.Threading.Interlocked.Or$3($.$spc.System.Runtime.CompilerServices.Unsafe.As($.$spu.System.Uri.Flags, $.$spc.System.UInt64, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => this._flags, ($v) => this._flags = $v, null)), flags);
                }
                else 
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._info)
                        {
                            this._flags |= flags;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._info)
                    }
                }
            }
            /*bool */ get IsImplicitFile()
            {
                return (this._flags & 35184372088832n) !== 0n;
            }
            /*bool */ get IsUncOrDosPath()
            {
                return (this._flags & (17592186044416n | 8796093022208n)) !== 0n;
            }
            /*bool */ get IsDosPath()
            {
                return (this._flags & 8796093022208n) !== 0n;
            }
            /*bool */ get IsUncPath()
            {
                return (this._flags & 17592186044416n) !== 0n;
            }
            /*bool */ get IsUnixPath()
            {
                return (this._flags & 18014398509481984n) !== 0n;
            }
            /*Flags */ get HostType()
            {
                return this._flags & 30064771072n;
            }
            /*UriParser */ get Syntax()
            {
                return this._syntax;
            }
            /*bool */ get IsNotAbsoluteUri()
            {
                return this._syntax === null;
            }
            /*bool */ get IriParsing()
            {
                return $.$spu.System.Uri.IriParsingStatic(this._syntax);
            }
            static /*bool */ IriParsingStatic(/*UriParser?*/ syntax)
            {
                return syntax === null || syntax.InFact(268435456/*UriSyntaxFlags.AllowIriParsing*/);
            }
            /*bool */ get DisablePathAndQueryCanonicalization()
            {
                return (this._flags & 36028797018963968n) !== 0n;
            }
            /*bool */ get UserDrivenParsing()
            {
                return (this._flags & 1099511627776n) !== 0n;
            }
            /*int */ get SecuredPathIndex()
            {
                if (this.IsDosPath)
                {
                    /*char*/ let ch = $.$spc.System.String.get_Chars.call(this._string, this._info.Offset.Path);
                    return (ch === /*/*/ 47 || ch === /*\\*/ 92) ? 3 : 2;
                }
                return 0;
            }
            /*bool */ NotAny(/*Flags*/ flags)
            {
                return (this._flags & flags) === 0n;
            }
            /*bool */ InFact(/*Flags*/ flags)
            {
                return (this._flags & flags) !== 0n;
            }
            static /*bool */ StaticNotAny(/*Flags*/ allFlags, /*Flags*/ checkFlags)
            {
                return (allFlags & checkFlags) === 0n;
            }
            static /*bool */ StaticInFact(/*Flags*/ allFlags, /*Flags*/ checkFlags)
            {
                return (allFlags & checkFlags) !== 0n;
            }
            /*UriInfo */ EnsureUriInfo()
            {
                /*Flags*/ let cF = this._flags;
                if ((cF & 70368744177664n) === 0n)
                {
                    this.CreateUriInfo(cF);
                    this.AssertInvariants();
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._info !== null && (this._flags & 70368744177664n) !== 0n, "_info != null && (_flags & Flags.MinimalUriInfoSet) != 0");
                return this._info;
            }
            /*void */ EnsureParseRemaining()
            {
                if ((this._flags & 140737488355328n) === 0n)
                {
                    this.ParseRemaining();
                    this.AssertInvariants();
                }
            }
            /*void */ EnsureHostString(/*bool*/ allowDnsOptimization)
            {
                /*UriInfo*/ let info = this.EnsureUriInfo();
                if (info.Host === null)
                {
                    if (allowDnsOptimization && this.InFact(2199023255552n))
                    {
                        return;
                    }
                    this.CreateHostString();
                }
            }
            $ctor$2(/*string*/ uriString)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(uriString, "uriString");
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(uriString, false, 1/*UriKind.Absolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            $ctor$3(/*string*/ uriString, /*bool*/ dontEscape)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(uriString, "uriString");
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(uriString, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            $ctor$4(/*Uri*/ baseUri, /*string?*/ relativeUri, /*bool*/ dontEscape)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(baseUri, "baseUri");
                    if (!baseUri.IsAbsoluteUri)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("baseUri");
                    }
                    this.CreateUri(baseUri, relativeUri, dontEscape);
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            $ctor$5(/*string*/ uriString, /*UriKind*/ uriKind)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(uriString, "uriString");
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(uriString, false, uriKind, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            $ctor$6(/*string*/ uriString, /*in UriCreationOptions*/ creationOptions)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(uriString, "uriString");
                    this.CreateThis(uriString, false, 1/*UriKind.Absolute*/, creationOptions);
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            $ctor$7(/*Uri*/ baseUri, /*string?*/ relativeUri)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(baseUri, "baseUri");
                    if (!baseUri.IsAbsoluteUri)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("baseUri");
                    }
                    this.CreateUri(baseUri, relativeUri, false);
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            $ctor$8(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.$ctor();
                {
                    /*string?*/ let uriString = serializationInfo.GetString("AbsoluteUri");
                    if (uriString.length !== 0)
                    {
                        let $v1 = new $.$spu.System.UriCreationOptions();
                        this.CreateThis(uriString, false, 1/*UriKind.Absolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                        this.DebugSetLeftCtor();
                        return this;
                    }
                    uriString = serializationInfo.GetString("RelativeUri");
                    if (uriString === null)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$spu.System.SR.Format($.$spu.System.SR.InvalidNullArgument, "RelativeUri"), "serializationInfo");
                    }
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(uriString, false, 2/*UriKind.Relative*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                this.GetObjectData(serializationInfo, streamingContext);
            }
            /*void */ GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                if (this.IsAbsoluteUri)
                {
                    serializationInfo.AddValue$1("AbsoluteUri", this.GetParts(-2147483648/*UriComponents.SerializationInfoString*/, 1/*UriFormat.UriEscaped*/));
                }
                else 
                {
                    serializationInfo.AddValue$1("AbsoluteUri", $.$spc.System.String.Empty);
                    serializationInfo.AddValue$1("RelativeUri", this.GetParts(-2147483648/*UriComponents.SerializationInfoString*/, 1/*UriFormat.UriEscaped*/));
                }
            }
            /*void */ CreateUri(/*Uri*/ baseUri, /*string?*/ relativeUri, /*bool*/ dontEscape)
            {
                this.DebugAssertInCtor();
                let $v1 = new $.$spu.System.UriCreationOptions();
                this.CreateThis(relativeUri, dontEscape, 0/*UriKind.RelativeOrAbsolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                if (baseUri.Syntax.IsSimple)
                {
                    /*Uri?*/ let uriResult = $.$spu.System.Uri.ResolveHelper(baseUri, this, $.$ref(() => relativeUri, ($v) => relativeUri = $v, $.$spc.System.String), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => dontEscape, ($v) => dontEscape = $v, null));
                    if ($.$spu.System.Uri.op_Inequality(uriResult, null))
                    {
                        if (!$.$spc.System.Object.ReferenceEquals(this, uriResult))
                        {
                            this.CreateThisFromUri(uriResult);
                        }
                        return;
                    }
                }
                else 
                {
                    dontEscape = false;
                    /*UriFormatException?*/ let e;
                    relativeUri = baseUri.Syntax.InternalResolve(baseUri, this, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException));
                    if (e !== null)
                    {
                        throw e;
                    }
                }
                this._flags = 0n;
                this._info = null;
                this._syntax = null;
                this._originalUnicodeString = null;
                let $v2 = new $.$spu.System.UriCreationOptions();
                this.CreateThis(relativeUri, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => $v2, ($v) => $v2 = $v));
            }
            $ctor$9(/*Uri*/ baseUri, /*Uri*/ relativeUri)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(baseUri, "baseUri");
                    if (!baseUri.IsAbsoluteUri)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("baseUri");
                    }
                    this.CreateThisFromUri(relativeUri);
                    /*string?*/ let newUriString = null;
                    /*bool*/ let dontEscape;
                    if (baseUri.Syntax.IsSimple)
                    {
                        dontEscape = this.InFact(34359738368n);
                        /*Uri?*/ let resolvedRelativeUri = $.$spu.System.Uri.ResolveHelper(baseUri, this, $.$ref(() => newUriString, ($v) => newUriString = $v, $.$spc.System.String), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => dontEscape, ($v) => dontEscape = $v, null));
                        if ($.$spu.System.Uri.op_Inequality(resolvedRelativeUri, null))
                        {
                            if (!$.$spc.System.Object.ReferenceEquals(this, resolvedRelativeUri))
                            {
                                this.CreateThisFromUri(resolvedRelativeUri);
                            }
                            this.DebugSetLeftCtor();
                            return this;
                        }
                    }
                    else 
                    {
                        dontEscape = false;
                        /*UriFormatException?*/ let e;
                        newUriString = baseUri.Syntax.InternalResolve(baseUri, this, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException));
                        if (e !== null)
                        {
                            throw e;
                        }
                    }
                    this._flags = 0n;
                    this._info = null;
                    this._syntax = null;
                    this._originalUnicodeString = null;
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(newUriString, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            static /*void */ GetCombinedString(/*Uri*/ baseUri, /*string*/ relativeStr, /*bool*/ dontEscape, /*ref string?*/ result)
            {
                for(/*int*/ let i = 0; i < relativeStr.length; ++i)
                {
                    if ($.$spc.System.String.get_Chars.call(relativeStr, i) === /*/*/ 47 || $.$spc.System.String.get_Chars.call(relativeStr, i) === /*\\*/ 92 || $.$spc.System.String.get_Chars.call(relativeStr, i) === /*?*/ 63 || $.$spc.System.String.get_Chars.call(relativeStr, i) === /*#*/ 35)
                    {
                        break;
                    }
                    else if ($.$spc.System.String.get_Chars.call(relativeStr, i) === /*:*/ 58)
                    {
                        if (i < 2)
                        {
                            break;
                        }
                        /*ParsingError*/ let error = 0/*ParsingError.None*/;
                        /*UriParser?*/ let syntax = $.$spu.System.Uri.CheckSchemeSyntax($.$spc.System.MemoryExtensions.AsSpan$7(relativeStr, 0, i), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.ParsingError, () => error, ($v) => error = $v, null));
                        if (error === 0/*ParsingError.None*/)
                        {
                            if (baseUri.Syntax === syntax)
                            {
                                if (((i + 1) | 0) < relativeStr.length)
                                {
                                    relativeStr = $.$spc.System.String.Substring.call(relativeStr, ((i + 1) | 0));
                                }
                                else 
                                {
                                    relativeStr = $.$spc.System.String.Empty;
                                }
                            }
                            else 
                            {
                                result.$v = relativeStr;
                                return;
                            }
                        }
                        break;
                    }
                }
                if (relativeStr.length === 0)
                {
                    result.$v = baseUri.OriginalString;
                }
                else 
                {
                    result.$v = $.$spu.System.Uri.CombineUri(baseUri, relativeStr, dontEscape ? 1/*UriFormat.UriEscaped*/ : 3/*UriFormat.SafeUnescaped*/);
                }
            }
            static /*UriFormatException? */ GetException(/*ParsingError*/ err)
            {
                switch(err)
                {
                    case 0/*ParsingError.None*/:
                    return null;
                    case 1/*ParsingError.BadFormat*/:
                    return new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_BadFormat);
                    case 2/*ParsingError.BadScheme*/:
                    return new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_BadScheme);
                    case 3/*ParsingError.BadAuthority*/:
                    return new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_BadAuthority);
                    case 4/*ParsingError.EmptyUriString*/:
                    return new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_EmptyUri);
                    case 6/*ParsingError.SchemeLimit*/:
                    return new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_SchemeLimit);
                    case 7/*ParsingError.MustRootedPath*/:
                    return new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_MustRootedPath);
                    case 8/*ParsingError.BadHostName*/:
                    return new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_BadHostName);
                    case 9/*ParsingError.NonEmptyHost*/:
                    return new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_BadFormat);
                    case 10/*ParsingError.BadPort*/:
                    return new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_BadPort);
                    case 11/*ParsingError.BadAuthorityTerminator*/:
                    return new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_BadAuthorityTerminator);
                    case 12/*ParsingError.CannotCreateRelative*/:
                    return new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_CannotCreateRelative);
                    default:
                    break;
                }
                return new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.net_uri_BadFormat);
            }
            /*string */ get AbsolutePath()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*string*/ let path = this.PrivateAbsolutePath;
                if (this.IsDosPath && $.$spc.System.String.get_Chars.call(path, 0) === /*/*/ 47)
                {
                    path = $.$spc.System.String.Substring.call(path, 1);
                }
                return path;
            }
            /*string */ get PrivateAbsolutePath()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsAbsoluteUri, "IsAbsoluteUri");
                /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                return info.Path ??= this.GetParts(16/*UriComponents.Path*/ | 1073741824/*UriComponents.KeepDelimiter*/, 1/*UriFormat.UriEscaped*/);
            }
            /*string */ get AbsoluteUri()
            {
                if (this._syntax === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                return info.AbsoluteUri ??= this.GetParts(127/*UriComponents.AbsoluteUri*/, 1/*UriFormat.UriEscaped*/);
            }
            /*string */ get LocalPath()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.GetLocalPath();
            }
            /*string */ get Authority()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.GetParts(4/*UriComponents.Host*/ | 8/*UriComponents.Port*/, 1/*UriFormat.UriEscaped*/);
            }
            /*UriHostNameType */ get HostNameType()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (this._syntax.IsSimple)
                {
                    this.EnsureUriInfo();
                }
                else 
                {
                    this.EnsureHostString(false);
                }
                switch(this.HostType)
                {
                    case 12884901888n:
                    return 2/*UriHostNameType.Dns*/;
                    case 8589934592n:
                    return 3/*UriHostNameType.IPv4*/;
                    case 4294967296n:
                    return 4/*UriHostNameType.IPv6*/;
                    case 21474836480n:
                    return 1/*UriHostNameType.Basic*/;
                    case 17179869184n:
                    return 1/*UriHostNameType.Basic*/;
                    case 30064771072n:
                    return 0/*UriHostNameType.Unknown*/;
                    default:
                    break;
                }
                return 0/*UriHostNameType.Unknown*/;
            }
            /*bool */ get IsDefaultPort()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (this._syntax.IsSimple)
                {
                    this.EnsureUriInfo();
                }
                else 
                {
                    this.EnsureHostString(false);
                }
                return this.NotAny(549755813888n);
            }
            /*bool */ get IsFile()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this._syntax.SchemeName === $.$spu.System.Uri.UriSchemeFile;
            }
            /*bool */ get IsLoopback()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                this.EnsureHostString(false);
                return this.InFact(274877906944n);
            }
            /*string */ get PathAndQuery()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*UriInfo*/ let info = this.EnsureUriInfo();
                if (info.PathAndQuery === null)
                {
                    /*string*/ let result = this.GetParts(48/*UriComponents.PathAndQuery*/, 1/*UriFormat.UriEscaped*/);
                    if (this.IsDosPath && $.$spc.System.String.get_Chars.call(result, 0) === /*/*/ 47)
                    {
                        result = $.$spc.System.String.Substring.call(result, 1);
                    }
                    info.PathAndQuery = result;
                }
                return info.PathAndQuery;
            }
            /*string[] */ get Segments()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*string[]*/ let segments;
                /*string*/ let path = this.PrivateAbsolutePath;
                if (path.length === 0)
                {
                    segments = $.$spc.System.Array.Empty($.$spc.System.String);
                }
                else 
                {
                    /*var*/ let pathSegments = new ($.$spu.System.Collections.Generic.ValueListBuilder$$($.$spc.System.String))().$ctor$3(4);
                    /*int*/ let current = 0;
                    while(current < path.length)
                    {
                        /*int*/ let next = $.$spc.System.String.IndexOf$1.call(path, /*/*/ 47, current);
                        if (next === -1)
                        {
                            next = ((path.length - 1) | 0);
                        }
                        pathSegments.Append($.$spc.System.String.Substring$1.call(path, current, (((((next - current) | 0)) + 1) | 0)));
                        current = ((next + 1) | 0);
                    }
                    segments = pathSegments.AsSpan().ToArray();
                    pathSegments.Dispose();
                }
                return segments;
            }
            /*bool */ get IsUnc()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.IsUncPath;
            }
            /*string */ get Host()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.GetParts(4/*UriComponents.Host*/, 1/*UriFormat.UriEscaped*/);
            }
            static /*bool */ StaticIsFile(/*UriParser*/ syntax)
            {
                return syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/);
            }
            /*string */ GetLocalPath()
            {
                this.EnsureParseRemaining();
                if (this.IsUncOrDosPath)
                {
                    this.EnsureHostString(false);
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._info !== null, "_info != null");
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(this._info.Host, null), "_info.Host != null");
                    /*int*/ let start;
                    if (this.NotAny(4n | 16n | 8192n))
                    {
                        start = this.IsUncPath ? ((this._info.Offset.Host - 2) | 0) : this._info.Offset.Path;
                        /*string*/ let str = (this.IsImplicitFile && this._info.Offset.Host === (this.IsDosPath ? 0 : 2) && this._info.Offset.Query === this._info.Offset.End) ? this._string : (this.IsDosPath && ($.$spc.System.String.get_Chars.call(this._string, start) === /*/*/ 47 || $.$spc.System.String.get_Chars.call(this._string, start) === /*\\*/ 92)) ? $.$spc.System.String.Substring$1.call(this._string, ((start + 1) | 0), ((((this._info.Offset.Query - start) | 0) - 1) | 0)) : $.$spc.System.String.Substring$1.call(this._string, start, ((this._info.Offset.Query - start) | 0));
                        if (this.IsDosPath && $.$spc.System.String.get_Chars.call(str, 1) === /*|*/ 124)
                        {
                            str = $.$spc.System.String.Remove.call(str, 1, 1);
                            str = $.$spc.System.String.Insert.call(str, 1, ":");
                        }
                        str = $.$spc.System.String.Replace$2.call(str, /*/*/ 47, /*\\*/ 92);
                        return str;
                    }
                    /*char[]*/ let result;
                    /*int*/ let count = 0;
                    start = this._info.Offset.Path;
                    /*string*/ let host = this._info.Host;
                    result = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), null, [((((((host.length + 3) | 0) + this._info.Offset.Fragment) | 0) - this._info.Offset.Path) | 0)], null);
                    if (this.IsUncPath)
                    {
                        $.$spc.System.Array.$WriteT1.call(result, /*\\*/ 92, 0);
                        $.$spc.System.Array.$WriteT1.call(result, /*\\*/ 92, 1);
                        count = 2;
                        $.$spu.System.UriHelper.UnescapeString(host, 0, host.length, result, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 0/*UnescapeMode.CopyOnly*/, this._syntax, false);
                    }
                    else 
                    {
                        if ($.$spc.System.String.get_Chars.call(this._string, start) === /*/*/ 47 || $.$spc.System.String.get_Chars.call(this._string, start) === /*\\*/ 92)
                        {
                            ++start;
                        }
                    }
                    /*int*/ let pathStart = count;
                    /*UnescapeMode*/ let mode = (this.InFact(16n) && !this.IsImplicitFile) ? (2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/) : 0/*UnescapeMode.CopyOnly*/;
                    $.$spu.System.UriHelper.UnescapeString(this._string, start, this._info.Offset.Query, result, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, mode, this._syntax, true);
                    if ($.$spc.System.Array.$ReadT1.call(result, 1) === /*|*/ 124)
                    {
                        $.$spc.System.Array.$WriteT1.call(result, /*:*/ 58, 1);
                    }
                    if (this.InFact(8192n))
                    {
                        $.$spu.System.Uri.Compress(result, this.IsDosPath ? ((pathStart + 2) | 0) : pathStart, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32), this._syntax);
                    }
                    /*Span<char>*/ let slashSpan = $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Char, result, 0, count);
                    $.$spc.System.MemoryExtensions.Replace($.$spc.System.Char, slashSpan, /*/*/ 47, /*\\*/ 92);
                    return $.$spc.System.String.Create$1(result, 0, count);
                }
                else 
                {
                    return this.GetUnescapedParts(16/*UriComponents.Path*/ | 1073741824/*UriComponents.KeepDelimiter*/, 2/*UriFormat.Unescaped*/);
                }
            }
            /*int */ get Port()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (this._syntax.IsSimple)
                {
                    this.EnsureUriInfo();
                }
                else 
                {
                    this.EnsureHostString(false);
                }
                if (this.InFact(549755813888n))
                {
                    return $.$cast(this._info.Offset.PortValue, $.$spc.System.Int32);
                }
                return this._syntax.DefaultPort;
            }
            /*string */ get Query()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                return info.Query ??= this.GetParts(32/*UriComponents.Query*/ | 1073741824/*UriComponents.KeepDelimiter*/, 1/*UriFormat.UriEscaped*/);
            }
            /*string */ get Fragment()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                return info.Fragment ??= this.GetParts(64/*UriComponents.Fragment*/ | 1073741824/*UriComponents.KeepDelimiter*/, 1/*UriFormat.UriEscaped*/);
            }
            /*string */ get Scheme()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this._syntax.SchemeName;
            }
            /*string */ get OriginalString()
            {
                return this._originalUnicodeString ?? this._string;
            }
            /*string */ get DnsSafeHost()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                this.EnsureHostString(false);
                /*Flags*/ let hostType = this.HostType;
                if (hostType === 4294967296n || (hostType === 21474836480n && this.InFact(4n | 256n)))
                {
                    return this.IdnHost;
                }
                else 
                {
                    return this._info.Host;
                }
            }
            /*string */ get IdnHost()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if ((this._info?.IdnHost ?? null) === null)
                {
                    this.EnsureHostString(false);
                    /*string*/ let host = this._info.Host;
                    /*Flags*/ let hostType = this.HostType;
                    if (hostType === 12884901888n)
                    {
                        host = $.$spu.System.DomainNameHelper.IdnEquivalent(host);
                    }
                    else if (hostType === 4294967296n)
                    {
                        let scopeId;
                        host = $.$is((this._info._moreInfo?.ScopeId ?? null), $.$spc.System.String, { set $v(v){ scopeId = v; } }) ? $.$spc.System.String.Concat$10($.$spc.System.MemoryExtensions.AsSpan$7(host, 1, ((host.length - 2) | 0)), $.$spc.System.String.op_Implicit(scopeId)) : $.$spc.System.String.Substring$1.call(host, 1, ((host.length - 2) | 0));
                    }
                    else if (hostType === 21474836480n && this.InFact(4n | 256n))
                    {
                        /*var*/ let dest = new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*StackallocThreshold*/, null));
                        $.$spu.System.UriHelper.UnescapeString$2(host, 0, host.length, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, this._syntax, false);
                        host = $.$spu.System.Text.ValueStringBuilder.ToString.call(dest);
                    }
                    this._info.IdnHost = host;
                }
                return this._info.IdnHost;
            }
            /*bool */ get IsAbsoluteUri()
            {
                return this._syntax !== null;
            }
            /*bool */ get UserEscaped()
            {
                return this.InFact(34359738368n);
            }
            /*string */ get UserInfo()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.GetParts(2/*UriComponents.UserInfo*/, 1/*UriFormat.UriEscaped*/);
            }
            static /*UriHostNameType */ CheckHostName(/*string?*/ name)
            {
                if ($.$spc.System.String.IsNullOrEmpty(name))
                {
                    return 0/*UriHostNameType.Unknown*/;
                }
                /*int*/ let end = name.length;
                {
                    /*fixed*/ 
                    {
                        /*char**/ let fixedName = $.$spc.System.String.GetPinnableReference.call(name);
                        if ($.$spc.System.String.StartsWith$3.call(name, /*[*/ 91) && $.$spc.System.String.EndsWith$3.call(name, /*]*/ 93))
                        {
                            if ($.$spu.System.Net.IPv6AddressHelper.IsValid(fixedName, 1, $.$ref(() => end, ($v) => end = $v, $.$spc.System.Int32)) && end === name.length)
                            {
                                return 4/*UriHostNameType.IPv6*/;
                            }
                        }
                        end = name.length;
                        if ($.$spu.System.Net.IPv4AddressHelper.IsValid($.$spc.System.Char, fixedName, 0, $.$ref(() => end, ($v) => end = $v, $.$spc.System.Int32), false, false, false) && end === name.length)
                        {
                            return 3/*UriHostNameType.IPv4*/;
                        }
                    }
                    /*int*/ let length;
                    if ($.$spu.System.DomainNameHelper.IsValid($.$spc.System.String.op_Implicit(name), false, false, $.$ref(() => length, ($v) => length = $v, $.$spc.System.Int32)) && length === name.length)
                    {
                        return 2/*UriHostNameType.Dns*/;
                    }
                    if ($.$spu.System.DomainNameHelper.IsValid($.$spc.System.String.op_Implicit(name), true, false, $.$ref(() => length, ($v) => length = $v, $.$spc.System.Int32)) && length === name.length)
                    {
                        return 2/*UriHostNameType.Dns*/;
                    }
                    end = ((name.length + 2) | 0);
                    name = "[" + name + "]";
                    /*fixed*/ 
                    {
                        /*char**/ let newFixedName = $.$spc.System.String.GetPinnableReference.call(name);
                        if ($.$spu.System.Net.IPv6AddressHelper.IsValid(newFixedName, 1, $.$ref(() => end, ($v) => end = $v, $.$spc.System.Int32)) && end === name.length)
                        {
                            return 4/*UriHostNameType.IPv6*/;
                        }
                    }
                }
                return 0/*UriHostNameType.Unknown*/;
            }
            /*string */ GetLeftPart(/*UriPartial*/ part)
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                this.EnsureUriInfo();
                /*UriComponents*/ let NonPathPart = (1/*UriComponents.Scheme*/ | 2/*UriComponents.UserInfo*/ | 4/*UriComponents.Host*/ | 8/*UriComponents.Port*/);
                switch(part)
                {
                    case 0/*UriPartial.Scheme*/:
                    return this.GetParts(1/*UriComponents.Scheme*/ | 1073741824/*UriComponents.KeepDelimiter*/, 1/*UriFormat.UriEscaped*/);
                    case 1/*UriPartial.Authority*/:
                    if (this.NotAny(68719476736n) || this.IsDosPath)
                    {
                        return $.$spc.System.String.Empty;
                    }
                    return this.GetParts(NonPathPart, 1/*UriFormat.UriEscaped*/);
                    case 2/*UriPartial.Path*/:
                    return this.GetParts(NonPathPart | 16/*UriComponents.Path*/, 1/*UriFormat.UriEscaped*/);
                    case 3/*UriPartial.Query*/:
                    return this.GetParts(NonPathPart | 16/*UriComponents.Path*/ | 32/*UriComponents.Query*/, 1/*UriFormat.UriEscaped*/);
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$spu.System.SR.Format($.$spu.System.SR.Argument_InvalidUriSubcomponent, $.$box(part, $.$spu.System.UriPartial)), "part");
            }
            static /*string */ HexEscape(/*char*/ character)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Char, character, /*\u00FF*/ 255, "character");
                return $.$spc.System.String.Create$8($.$spc.System.Byte, 3, $.$cast(character, $.$spc.System.Byte), new ($.$spc.System.Buffers.SpanAction$$$($.$spc.System.Char, $.$spc.System.Byte))().$ctor(this,  (/*Span<char>*/ chars, /*byte*/ b) =>
                {
                    chars.get_Item(0).$v = /*%*/ 37;
                    $.$spu.System.HexConverter.ToCharsBuffer(b, chars, 1, 0/*HexConverter.Casing.Upper*/);
                }, {"r":65537,"p":[{"n":"chars","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"b","p":393217}],"n":"","d":1742996,"h":0,"f":1048578}));
            }
            static /*char */ HexUnescape(/*string*/ pattern, /*ref int*/ index)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index.$v, "index");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual($.$spc.System.Int32, index.$v, pattern.length, "index");
                if (($.$spc.System.String.get_Chars.call(pattern, index.$v) === /*%*/ 37) && (((pattern.length - index.$v) | 0) >= 3))
                {
                    /*char*/ let ret = $.$spu.System.UriHelper.DecodeHexChars($.$spc.System.String.get_Chars.call(pattern, ((index.$v + 1) | 0)), $.$spc.System.String.get_Chars.call(pattern, ((index.$v + 2) | 0)));
                    if (ret !== /*\uFFFF*/ 65535)
                    {
                        index.$v += 3;
                        return ret;
                    }
                }
                return $.$spc.System.String.get_Chars.call(pattern, index.$v++);
            }
            static /*bool */ IsHexEncoding(/*string*/ pattern, /*int*/ index)
            {
                return (((pattern.length - index) | 0)) >= 3 && $.$spc.System.String.get_Chars.call(pattern, index) === /*%*/ 37 && $.$spc.System.Char.IsAsciiHexDigit($.$spc.System.String.get_Chars.call(pattern, ((index + 1) | 0))) && $.$spc.System.Char.IsAsciiHexDigit($.$spc.System.String.get_Chars.call(pattern, ((index + 2) | 0)));
            }
            /*SearchValues<char>*/ static s_schemeChars = null;
            static /*bool */ CheckSchemeName(/*string?*/ schemeName)
            {
                return !$.$spc.System.String.IsNullOrEmpty(schemeName) && $.$spc.System.Char.IsAsciiLetter($.$spc.System.String.get_Chars.call(schemeName, 0)) && !$.$spc.System.MemoryExtensions.ContainsAnyExcept$13($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(schemeName), $.$spu.System.Uri.s_schemeChars);
            }
            static /*bool */ IsHexDigit(/*char*/ character)
            {
                return $.$spc.System.Char.IsAsciiHexDigit(character);
            }
            static /*int */ FromHex(/*char*/ digit)
            {
                /*int*/ let result = $.$spu.System.HexConverter.FromChar(digit);
                if (result === 255)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13(null, "digit");
                }
                return result;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                if (this.IsNotAbsoluteUri)
                {
                    return $.$spc.System.String.GetHashCode.call(this.OriginalString);
                }
                else 
                {
                    /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                    /*UriComponents*/ let components = 61/*UriComponents.HttpRequestUrl*/;
                    if (this._syntax.InFact(16384/*UriSyntaxFlags.MailToLikeUri*/))
                    {
                        components |= 2/*UriComponents.UserInfo*/;
                    }
                    /*string*/ let remoteUrl = info.RemoteUrl ??= this.GetParts(components, 3/*UriFormat.SafeUnescaped*/);
                    if (this.IsUncOrDosPath)
                    {
                        return $.$spc.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(remoteUrl);
                    }
                    else 
                    {
                        return $.$spc.System.String.GetHashCode.call(remoteUrl);
                    }
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$spu.System.Uri.GetHashCode.apply(this, arguments); }
            /*UriFormat*/ static V1ToStringUnescape = 32767;
            static/*conventional*/ /*string */ ToString()
            {
                if (this._syntax === null)
                {
                    return this._string;
                }
                this.EnsureUriInfo();
                return this._info.String ??= this._syntax.IsSimple ? this.GetComponentsHelper(127/*UriComponents.AbsoluteUri*/, 32767/*V1ToStringUnescape*/) : this.GetParts(127/*UriComponents.AbsoluteUri*/, 3/*UriFormat.SafeUnescaped*/);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spu.System.Uri.ToString.apply(this, arguments); }
            /*bool */ TryFormat(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                /*ReadOnlySpan<char>*/ let result;
                if (this._syntax === null)
                {
                    result = $.$spc.System.String.op_Implicit(this._string);
                }
                else 
                {
                    this.EnsureUriInfo();
                    if (!(this._info.String === null))
                    {
                        result = $.$spc.System.String.op_Implicit(this._info.String);
                    }
                    else 
                    {
                        /*UriFormat*/ let uriFormat = 32767/*V1ToStringUnescape*/;
                        if (!this._syntax.IsSimple)
                        {
                            if (this.IsNotAbsoluteUri)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                            }
                            if (this.UserDrivenParsing)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.Format($.$spu.System.SR.net_uri_UserDrivenParsing, $.$spc.System.Object.GetType.call(this)));
                            }
                            if (this.DisablePathAndQueryCanonicalization)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_GetComponentsCalledWhenCanonicalizationDisabled);
                            }
                            uriFormat = 3/*UriFormat.SafeUnescaped*/;
                        }
                        this.EnsureParseRemaining();
                        this.EnsureHostString(true);
                        /*ushort*/ let nonCanonical = $.$cast(($.$cast(this._flags, $.$spc.System.UInt16) & $.$cast(127n, $.$spc.System.UInt16)), $.$spc.System.UInt16);
                        if (((this._flags & (8192n | 16384n | 32768n)) !== 0n) || (this.IsDosPath && $.$spc.System.String.get_Chars.call(this._string, ((((this._info.Offset.Path + this.SecuredPathIndex) | 0) - 1) | 0)) === /*|*/ 124))
                        {
                            nonCanonical |= $.$cast(16n, $.$spc.System.UInt16);
                        }
                        if (($.$cast(127/*UriComponents.AbsoluteUri*/, $.$spc.System.UInt16) & nonCanonical) !== 0)
                        {
                            return this.TryRecreateParts(destination, charsWritten, 127/*UriComponents.AbsoluteUri*/, nonCanonical, uriFormat);
                        }
                        result = $.$spc.System.MemoryExtensions.AsSpan$7(this._string, this._info.Offset.Scheme, ((this._info.Offset.End - this._info.Offset.Scheme) | 0));
                    }
                }
                if (result.TryCopyTo(destination))
                {
                    charsWritten.$v = result.Length;
                    return true;
                }
                charsWritten.$v = 0;
                return false;
            }
            /*bool */ System$ISpanFormattable$TryFormat(/*Span<char>*/ destination, /*out int*/ charsWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                return this.TryFormat(destination, charsWritten);
            }
            /*string */ System$IFormattable$ToString(/*string?*/ format, /*IFormatProvider?*/ formatProvider)
            {
                return $.$spu.System.Uri.ToString.call(this);
            }
            static /*bool */ op_Equality(/*Uri?*/ uri1, /*Uri?*/ uri2)
            {
                if ($.$spc.System.Object.ReferenceEquals(uri1, uri2))
                {
                    return true;
                }
                if (uri1 === null || uri2 === null)
                {
                    return false;
                }
                return uri1.Equals$2(uri2);
            }
            static /*bool */ op_Inequality(/*Uri?*/ uri1, /*Uri?*/ uri2)
            {
                if ($.$spc.System.Object.ReferenceEquals(uri1, uri2))
                {
                    return false;
                }
                if (uri1 === null || uri2 === null)
                {
                    return true;
                }
                return !uri1.Equals$2(uri2);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                if (comparand === null)
                {
                    return false;
                }
                if ($.$spc.System.Object.ReferenceEquals(this, comparand))
                {
                    return true;
                }
                /*Uri?*/ let other = $.$as(comparand, $.$spu.System.Uri);
                if (other === null)
                {
                    if (this.DisablePathAndQueryCanonicalization)
                    {
                        return false;
                    }
                    let s;
                    if (!($.$is(comparand, $.$spc.System.String, { set $v(v){ s = v; } })))
                    {
                        return false;
                    }
                    if ($.$spc.System.Object.ReferenceEquals(s, this.OriginalString))
                    {
                        return true;
                    }
                    if (!$.$spu.System.Uri.TryCreate(s, 0/*UriKind.RelativeOrAbsolute*/, $.$ref(() => other, ($v) => other = $v, $.$spu.System.Uri)))
                    {
                        return false;
                    }
                }
                return this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$spu.System.Uri.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Uri?*/ other)
            {
                if (other === null)
                {
                    return false;
                }
                if ($.$spc.System.Object.ReferenceEquals(this, other))
                {
                    return true;
                }
                if (this.DisablePathAndQueryCanonicalization !== other.DisablePathAndQueryCanonicalization)
                {
                    return false;
                }
                if ($.$spc.System.Object.ReferenceEquals(this.OriginalString, other.OriginalString))
                {
                    return true;
                }
                if (this.IsAbsoluteUri !== other.IsAbsoluteUri)
                {
                    return false;
                }
                if (this.IsNotAbsoluteUri)
                {
                    return $.$spc.System.String.Equals$2.call(this.OriginalString, other.OriginalString);
                }
                if (this.NotAny(140737488355328n) || other.NotAny(140737488355328n))
                {
                    if ($.$spc.System.String.Equals$5(this._string, other._string, this.IsUncOrDosPath ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                    {
                        return true;
                    }
                }
                this.EnsureUriInfo();
                other.EnsureUriInfo();
                if (!this.UserDrivenParsing && !other.UserDrivenParsing && this.Syntax.IsSimple && other.Syntax.IsSimple)
                {
                    if (this.InFact(2199023255552n) && other.InFact(2199023255552n))
                    {
                        /*int*/ let i1 = this._info.Offset.Host;
                        /*int*/ let end1 = this._info.Offset.Path;
                        /*int*/ let i2 = other._info.Offset.Host;
                        /*int*/ let end2 = other._info.Offset.Path;
                        /*string*/ let str = other._string;
                        if (((end1 - i1) | 0) > ((end2 - i2) | 0))
                        {
                            end1 = ((((i1 + end2) | 0) - i2) | 0);
                        }
                        while(i1 < end1)
                        {
                            if ($.$spc.System.String.get_Chars.call(this._string, i1) !== $.$spc.System.String.get_Chars.call(str, i2))
                            {
                                return false;
                            }
                            if ($.$spc.System.String.get_Chars.call(str, i2) === /*:*/ 58)
                            {
                                break;
                            }
                            ++i1;
                            ++i2;
                        }
                        if (i1 < this._info.Offset.Path && $.$spc.System.String.get_Chars.call(this._string, i1) !== /*:*/ 58)
                        {
                            return false;
                        }
                        if (i2 < end2 && $.$spc.System.String.get_Chars.call(str, i2) !== /*:*/ 58)
                        {
                            return false;
                        }
                    }
                    else 
                    {
                        this.EnsureHostString(false);
                        other.EnsureHostString(false);
                        if (!$.$spc.System.String.Equals$2.call(this._info.Host, other._info.Host))
                        {
                            return false;
                        }
                    }
                    if (this.Port !== other.Port)
                    {
                        return false;
                    }
                }
                /*MoreInfo*/ let selfInfo = this._info.MoreInfo;
                /*MoreInfo*/ let otherInfo = other._info.MoreInfo;
                /*UriComponents*/ let components = 61/*UriComponents.HttpRequestUrl*/;
                if (this._syntax.InFact(16384/*UriSyntaxFlags.MailToLikeUri*/))
                {
                    if (!other._syntax.InFact(16384/*UriSyntaxFlags.MailToLikeUri*/))
                    {
                        return false;
                    }
                    components |= 2/*UriComponents.UserInfo*/;
                }
                /*string*/ let selfUrl = selfInfo.RemoteUrl ??= this.GetParts(components, 3/*UriFormat.SafeUnescaped*/);
                /*string*/ let otherUrl = otherInfo.RemoteUrl ??= other.GetParts(components, 3/*UriFormat.SafeUnescaped*/);
                return $.$spc.System.String.Equals$5(selfUrl, otherUrl, this.IsUncOrDosPath ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/);
            }
            /*Uri */ MakeRelativeUri(/*Uri*/ uri)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(uri, "uri");
                if (this.IsNotAbsoluteUri || uri.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (($.$spc.System.String.op_Equality(this.Scheme, uri.Scheme)) && ($.$spc.System.String.op_Equality(this.Host, uri.Host)) && (this.Port === uri.Port))
                {
                    /*string*/ let otherPath = uri.AbsolutePath;
                    /*string*/ let relativeUriString = $.$spu.System.Uri.PathDifference(this.AbsolutePath, otherPath, !this.IsUncOrDosPath);
                    if ($.$spu.System.Uri.CheckForColonInFirstPathSegment(relativeUriString) && !(uri.IsDosPath && $.$spc.System.String.Equals$3.call(otherPath, relativeUriString, 4/*StringComparison.Ordinal*/)))
                    {
                        relativeUriString = "./" + relativeUriString;
                    }
                    relativeUriString += uri.GetParts(32/*UriComponents.Query*/ | 64/*UriComponents.Fragment*/, 1/*UriFormat.UriEscaped*/);
                    return new $.$spu.System.Uri().$ctor$5(relativeUriString, 2/*UriKind.Relative*/);
                }
                return uri;
            }
            /*SearchValues<char>*/ static s_segmentSeparatorChars = null;
            static /*bool */ CheckForColonInFirstPathSegment(/*string*/ uriString)
            {
                /*int*/ let index = $.$spc.System.MemoryExtensions.IndexOfAny$11($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(uriString), $.$spu.System.Uri.s_segmentSeparatorChars);
                return (index >>> 0) < (uriString.length >>> 0) && $.$spc.System.String.get_Chars.call(uriString, index) === /*:*/ 58;
            }
            static /*string */ InternalEscapeString(/*string*/ rawString)
            {
                return rawString === null ? $.$spc.System.String.Empty : $.$spu.System.UriHelper.EscapeString(rawString, true, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
            }
            static /*ParsingError */ ParseScheme(/*string*/ uriString, /*ref Flags*/ flags, /*ref UriParser?*/ syntax)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((flags.$v & 144115188075855872n) === 0n, "(flags & Flags.Debug_LeftConstructor) == 0");
                /*int*/ let length = uriString.length;
                if (length === 0)
                {
                    return 4/*ParsingError.EmptyUriString*/;
                }
                if ($.$spc.System.String.StartsWith$1.call(uriString, "https:", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    syntax.$v = $.$spu.System.UriParser.HttpsUri;
                    flags.$v |= $.$cast(6n, $.$spu.System.Uri.Flags);
                }
                else if ($.$spc.System.String.StartsWith$1.call(uriString, "http:", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    syntax.$v = $.$spu.System.UriParser.HttpUri;
                    flags.$v |= $.$cast(5n, $.$spu.System.Uri.Flags);
                }
                else 
                {
                    /*ParsingError*/ let err = 0/*ParsingError.None*/;
                    /*int*/ let idx = $.$spu.System.Uri.ParseSchemeCheckImplicitFile(uriString, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.ParsingError, () => err, ($v) => err = $v, null), flags, syntax);
                    $.$spc.System.Diagnostics.Debug.Assert$1((err === 0) === (!(syntax.$v === null)), "(err is ParsingError.None) == (syntax is not null)");
                    if (err !== 0/*ParsingError.None*/)
                    {
                        return err;
                    }
                    flags.$v |= $.$cast(idx, $.$spu.System.Uri.Flags);
                }
                return 0/*ParsingError.None*/;
            }
            /*UriFormatException? */ ParseMinimal()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._syntax !== null && !this._syntax.IsSimple, "_syntax != null && !_syntax.IsSimple");
                $.$spc.System.Diagnostics.Debug.Assert$1((this._flags & 72057594037927936n) !== 0n, "(_flags & Flags.CustomParser_ParseMinimalAlreadyCalled) != 0");
                this.DebugAssertInCtor();
                /*ParsingError*/ let result = this.PrivateParseMinimal();
                if (result === 0/*ParsingError.None*/)
                {
                    return null;
                }
                this._flags |= 4398046511104n;
                return $.$spu.System.Uri.GetException(result);
            }
            /*ParsingError */ PrivateParseMinimal()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._syntax !== null, "_syntax != null");
                this.DebugAssertInCtor();
                /*int*/ let idx = $.$cast((this._flags & 4294967295n), $.$spc.System.Int32);
                /*int*/ let length = this._string.length;
                this._flags &= ~(4294967295n | 1099511627776n);
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Object.ReferenceEquals(this._string, this.OriginalString), "ReferenceEquals(_string, OriginalString)");
                /*fixed*/ 
                {
                    /*char**/ let pUriString = $.$spc.System.String.GetPinnableReference.call(this._string);
                    if (length > idx && $.$spu.System.UriHelper.IsLWS(pUriString.GetAt(((length - 1) | 0))))
                    {
                        --length;
                        while(length !== idx && $.$spu.System.UriHelper.IsLWS(pUriString.GetAt(--length)))
                        {
                        }
                        ++length;
                    }
                    if (!$.$spc.System.OperatingSystem.IsWindows() && this.InFact(18014398509481984n))
                    {
                        this._flags |= 21474836480n;
                        this._flags |= $.$cast(idx, $.$spu.System.Uri.Flags);
                        return 0/*ParsingError.None*/;
                    }
                    if (this._syntax.IsAllSet(128/*UriSyntaxFlags.AllowEmptyHost*/ | 1048576/*UriSyntaxFlags.AllowDOSPath*/) && this.NotAny(35184372088832n) && (((idx + 1) | 0) < length))
                    {
                        /*char*/ let c;
                        /*int*/ let i = idx;
                        for(; i < length; ++i)
                        {
                            if (!((c = pUriString.GetAt(i)) === /*\\*/ 92 || c === /*/*/ 47))
                            {
                                break;
                            }
                        }
                        if (this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/) || ((i - idx) | 0) <= 3)
                        {
                            if (((i - idx) | 0) >= 2)
                            {
                                this._flags |= 68719476736n;
                            }
                            if (((i + 1) | 0) < length && ((c = pUriString.GetAt(((i + 1) | 0))) === /*:*/ 58 || c === /*|*/ 124) && $.$spc.System.Char.IsAsciiLetter(pUriString.GetAt(i)))
                            {
                                if (((i + 2) | 0) >= length || ((c = pUriString.GetAt(((i + 2) | 0))) !== /*\\*/ 92 && c !== /*/*/ 47))
                                {
                                    if (this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/))
                                    {
                                        return 7/*ParsingError.MustRootedPath*/;
                                    }
                                }
                                else 
                                {
                                    this._flags |= 8796093022208n;
                                    if (this._syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/))
                                    {
                                        this._flags |= 68719476736n;
                                    }
                                    if (i !== idx && ((i - idx) | 0) !== 2)
                                    {
                                        idx = ((i - 1) | 0);
                                    }
                                    else 
                                    {
                                        idx = i;
                                    }
                                }
                            }
                            else if (this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/) && (((i - idx) | 0) >= 2 && ((i - idx) | 0) !== 3 && i < length && pUriString.GetAt(i) !== /*?*/ 63 && pUriString.GetAt(i) !== /*#*/ 35))
                            {
                                this._flags |= 17592186044416n;
                                idx = i;
                            }
                            else if (!$.$spc.System.OperatingSystem.IsWindows() && this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/) && pUriString.GetAt(((i - 1) | 0)) === /*/*/ 47 && ((i - idx) | 0) === 3)
                            {
                                this._syntax = $.$spu.System.UriParser.UnixFileUri;
                                this._flags |= 18014398509481984n | 68719476736n;
                                idx += 2;
                            }
                        }
                    }
                    if ((this._flags & (17592186044416n | 8796093022208n | 18014398509481984n)) !== 0n)
                    {
                    }
                    else if ((((idx + 2) | 0)) <= length)
                    {
                        /*char*/ let first = pUriString.GetAt(idx);
                        /*char*/ let second = pUriString.GetAt(((idx + 1) | 0));
                        if (this._syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/))
                        {
                            if ((first === /*/*/ 47 || first === /*\\*/ 92) && (second === /*/*/ 47 || second === /*\\*/ 92))
                            {
                                this._flags |= 68719476736n;
                                idx += 2;
                            }
                            else 
                            {
                                return 3/*ParsingError.BadAuthority*/;
                            }
                        }
                        else if (this._syntax.InFact(2/*UriSyntaxFlags.OptionalAuthority*/) && (this.InFact(68719476736n) || (first === /*/*/ 47 && second === /*/*/ 47)))
                        {
                            this._flags |= 68719476736n;
                            idx += 2;
                        }
                        else if (this._syntax.NotAny(16384/*UriSyntaxFlags.MailToLikeUri*/))
                        {
                            if (this.InFact(562949953421312n))
                            {
                                this._string = $.$spc.System.String.Substring$1.call(this._string, 0, idx);
                            }
                            this._flags |= ($.$cast(idx, $.$spu.System.Uri.Flags) | 30064771072n);
                            return 0/*ParsingError.None*/;
                        }
                    }
                    else if (this._syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/))
                    {
                        return 3/*ParsingError.BadAuthority*/;
                    }
                    else if (this._syntax.NotAny(16384/*UriSyntaxFlags.MailToLikeUri*/))
                    {
                        if (this.InFact(562949953421312n))
                        {
                            this._string = $.$spc.System.String.Substring$1.call(this._string, 0, idx);
                        }
                        this._flags |= ($.$cast(idx, $.$spu.System.Uri.Flags) | 30064771072n);
                        return 0/*ParsingError.None*/;
                    }
                    if (this.InFact(8796093022208n))
                    {
                        this._flags |= (((this._flags & 68719476736n) !== 0n) ? 21474836480n : 30064771072n);
                        this._flags |= $.$cast(idx, $.$spu.System.Uri.Flags);
                        return 0/*ParsingError.None*/;
                    }
                    {
                        /*ParsingError*/ let err = 0/*ParsingError.None*/;
                        /*string?*/ let newHost = null;
                        idx = this.CheckAuthorityHelper(pUriString, idx, length, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.ParsingError, () => err, ($v) => err = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => this._flags, ($v) => this._flags = $v, null), this._syntax, $.$ref(() => newHost, ($v) => newHost = $v, $.$spc.System.String));
                        if (err !== 0/*ParsingError.None*/)
                        {
                            return err;
                        }
                        if (idx < length)
                        {
                            /*char*/ let hostTerminator = pUriString.GetAt(idx);
                            if (hostTerminator === /*\\*/ 92 && this.NotAny(35184372088832n) && this._syntax.NotAny(1048576/*UriSyntaxFlags.AllowDOSPath*/))
                            {
                                return 11/*ParsingError.BadAuthorityTerminator*/;
                            }
                            else if (!$.$spc.System.OperatingSystem.IsWindows() && hostTerminator === /*/*/ 47 && this.NotAny(35184372088832n) && this.InFact(17592186044416n) && this._syntax === $.$spu.System.UriParser.FileUri)
                            {
                                this._syntax = $.$spu.System.UriParser.UnixFileUri;
                            }
                        }
                        if (!(newHost === null))
                        {
                            this._string = newHost;
                        }
                    }
                    this._flags |= $.$cast(idx, $.$spu.System.Uri.Flags);
                }
                return 0/*ParsingError.None*/;
            }
            /*void */ CreateUriInfo(/*Flags*/ cF)
            {
                /*UriInfo*/ let info;
                /*int*/ let idx;
                /*bool*/ let notCanonicalScheme;
                /*bool*/ let notEmpty;
                /*Flags*/ let current;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            info = new $.$spu.System.Uri.UriInfo().$ctor$1();
                            info.Offset.End = this._string.length;
                            if (this.UserDrivenParsing)
                            {
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            notCanonicalScheme = false;
                            if ((cF & 35184372088832n) !== 0n)
                            {
                                idx = 0;
                                while($.$spu.System.UriHelper.IsLWS($.$spc.System.String.get_Chars.call(this._string, idx)))
                                {
                                    ++idx;
                                    ++info.Offset.Scheme;
                                }
                                if ($.$spu.System.Uri.StaticInFact(cF, 17592186044416n))
                                {
                                    idx += 2;
                                    /*int*/ let end = $.$cast((cF & 4294967295n), $.$spc.System.Int32);
                                    while(idx < end && ($.$spc.System.String.get_Chars.call(this._string, idx) === /*/*/ 47 || $.$spc.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92))
                                    {
                                        ++idx;
                                    }
                                }
                            }
                            else 
                            {
                                idx = this._syntax.SchemeName.length;
                                while($.$spc.System.String.get_Chars.call(this._string, idx++) !== /*:*/ 58)
                                {
                                    ++info.Offset.Scheme;
                                }
                                if ((cF & 68719476736n) !== 0n)
                                {
                                    if ($.$spc.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92 || $.$spc.System.String.get_Chars.call(this._string, ((idx + 1) | 0)) === /*\\*/ 92)
                                    {
                                        notCanonicalScheme = true;
                                    }
                                    idx += 2;
                                    if ((cF & (17592186044416n | 8796093022208n)) !== 0n)
                                    {
                                        /*int*/ let end = $.$cast((cF & 4294967295n), $.$spc.System.Int32);
                                        while(idx < end && ($.$spc.System.String.get_Chars.call(this._string, idx) === /*/*/ 47 || $.$spc.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92))
                                        {
                                            notCanonicalScheme = true;
                                            ++idx;
                                        }
                                    }
                                }
                            }
                            if (this._syntax.DefaultPort !== -1/*UriParser.NoDefaultPort*/)
                            {
                                info.Offset.PortValue = $.$cast(this._syntax.DefaultPort, $.$spc.System.UInt16);
                            }
                            if ((cF & 30064771072n) === 30064771072n || $.$spu.System.Uri.StaticInFact(cF, 8796093022208n))
                            {
                                info.Offset.User = $.$cast((cF & 4294967295n), $.$spc.System.Int32);
                                info.Offset.Host = info.Offset.User;
                                info.Offset.Path = info.Offset.User;
                                cF &= ~4294967295n;
                                if (notCanonicalScheme)
                                {
                                    cF |= 1n;
                                }
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            info.Offset.User = idx;
                            if (this.HostType === 21474836480n)
                            {
                                info.Offset.Host = idx;
                                info.Offset.Path = $.$cast((cF & 4294967295n), $.$spc.System.Int32);
                                cF &= ~4294967295n;
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            if ((cF & 137438953472n) !== 0n)
                            {
                                while($.$spc.System.String.get_Chars.call(this._string, idx) !== /*@*/ 64)
                                {
                                    ++idx;
                                }
                                ++idx;
                                info.Offset.Host = idx;
                            }
                            else 
                            {
                                info.Offset.Host = idx;
                            }
                            idx = $.$cast((cF & 4294967295n), $.$spc.System.Int32);
                            cF &= ~4294967295n;
                            if (notCanonicalScheme)
                            {
                                cF |= 1n;
                            }
                            info.Offset.Path = idx;
                            notEmpty = false;
                            if ((cF & 562949953421312n) !== 0n)
                            {
                                info.Offset.End = this._originalUnicodeString.length;
                            }
                            if (idx < info.Offset.End)
                            {
                                /*fixed*/ 
                                {
                                    /*char**/ let userString = $.$spc.System.String.GetPinnableReference.call(this.OriginalString);
                                    if (userString.GetAt(idx) === /*:*/ 58)
                                    {
                                        /*int*/ let port = 0;
                                        if (++idx < info.Offset.End)
                                        {
                                            port = userString.GetAt(idx) - /*0*/ 48;
                                            if ((port >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                                            {
                                                notEmpty = true;
                                                if (port === 0)
                                                {
                                                    cF |= (8n | 512n);
                                                }
                                                for(++idx; idx < info.Offset.End; ++idx)
                                                {
                                                    /*int*/ let val = userString.GetAt(idx) - /*0*/ 48;
                                                    if ((val >>> 0) > (/*9*/ 57 - /*0*/ 48))
                                                    {
                                                        break;
                                                    }
                                                    port = (((((port * 10) | 0) + val) | 0));
                                                }
                                            }
                                        }
                                        if (notEmpty && this._syntax.DefaultPort !== port)
                                        {
                                            info.Offset.PortValue = $.$cast(port, $.$spc.System.UInt16);
                                            cF |= 549755813888n;
                                        }
                                        else 
                                        {
                                            cF |= (8n | 512n);
                                        }
                                        info.Offset.Path = idx;
                                    }
                                }
                            }
                        }
                        case 1: /*Done*/
                        cF |= 70368744177664n;
                        $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spu.System.Uri.UriInfo, $.$ref(() => this._info, ($v) => this._info = $v, $.$spu.System.Uri.UriInfo), info, null);
                        current = this._flags;
                        while((current & 70368744177664n) === 0n)
                        {
                            /*Flags*/ let oldValue = $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spu.System.Uri.Flags, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => this._flags, ($v) => this._flags = $v, null), (current & ~4294967295n) | cF, current);
                            if (oldValue === current)
                            {
                                return;
                            }
                            current = oldValue;
                        }
                    }
                    break;
                }
            }
            /*void */ CreateHostString()
            {
                if (!this._syntax.IsSimple)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._info)
                        {
                            if (this.NotAny(4398046511104n))
                            {
                                this._flags |= 4398046511104n;
                                this.GetHostViaCustomSyntax();
                                this._flags &= ~4398046511104n;
                                return;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._info)
                    }
                }
                /*Flags*/ let flags = this._flags;
                /*string*/ let host = $.$spu.System.Uri.CreateHostStringHelper(this._string, this._info.Offset.Host, this._info.Offset.Path, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => flags, ($v) => flags = $v, null), this._info);
                if (host.length !== 0)
                {
                    if (this.HostType === 21474836480n)
                    {
                        /*int*/ let idx = 0;
                        /*Check*/ let result;
                        /*fixed*/ 
                        {
                            /*char**/ let pHost = $.$spc.System.String.GetPinnableReference.call(host);
                            result = this.CheckCanonical(pHost, $.$ref(() => idx, ($v) => idx = $v, $.$spc.System.Int32), host.length, /*\uFFFF*/ 65535);
                        }
                        if ((result & 2/*Check.DisplayCanonical*/) === 0)
                        {
                            if (this.NotAny(35184372088832n) || (result & 32/*Check.ReservedFound*/) !== 0)
                            {
                                flags |= 4n;
                            }
                        }
                        if (this.InFact(35184372088832n) && (result & (32/*Check.ReservedFound*/ | 1/*Check.EscapedCanonical*/)) !== 0)
                        {
                            result &= ~1/*Check.EscapedCanonical*/;
                        }
                        if ((result & (1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/)) !== 1/*Check.EscapedCanonical*/)
                        {
                            flags |= 256n;
                            if (this.NotAny(34359738368n))
                            {
                                host = $.$spu.System.UriHelper.EscapeString(host, !this.IsImplicitFile, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
                            }
                            else 
                            {
                            }
                        }
                    }
                    else if (this.NotAny(2199023255552n))
                    {
                        if (!((this._info._moreInfo?.ScopeId ?? null) === null))
                        {
                            flags |= (4n | 256n);
                        }
                        else 
                        {
                            for(/*int*/ let i = 0; i < host.length; ++i)
                            {
                                if ((((this._info.Offset.Host + i) | 0)) >= this._info.Offset.End || $.$spc.System.String.get_Chars.call(host, i) !== $.$spc.System.String.get_Chars.call(this._string, ((this._info.Offset.Host + i) | 0)))
                                {
                                    flags |= (4n | 256n);
                                    break;
                                }
                            }
                        }
                    }
                }
                this._info.Host = host;
                this.InterlockedSetFlags(flags);
            }
            static /*string */ CreateHostStringHelper(/*string*/ str, /*int*/ idx, /*int*/ end, /*ref Flags*/ flags, /*UriInfo*/ info)
            {
                /*bool*/ let loopback = false;
                /*string*/ let host;
                let $switch1 = flags.$v & 30064771072n;
                switch($switch1)
                {
                    case 12884901888n:
                    host = $.$spu.System.DomainNameHelper.ParseCanonicalName(str, idx, end, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => loopback, ($v) => loopback = $v, null));
                    break;
                    case 4294967296n:
                    /*ReadOnlySpan<char>*/ let scopeIdSpan;
                    host = $.$spu.System.Net.IPv6AddressHelper.ParseCanonicalName($.$spc.System.MemoryExtensions.AsSpan$4(str, idx), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => loopback, ($v) => loopback = $v, null), $.$ref(() => scopeIdSpan, ($v) => scopeIdSpan = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Char)));
                    if (!scopeIdSpan.IsEmpty)
                    {
                        info.MoreInfo.ScopeId = $.$spc.System.String.Create$7(scopeIdSpan);
                    }
                    break;
                    case 8589934592n:
                    host = $.$spu.System.Net.IPv4AddressHelper.ParseCanonicalName(str, idx, end, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => loopback, ($v) => loopback = $v, null));
                    break;
                    case 17179869184n:
                    host = $.$spu.System.UncNameHelper.ParseCanonicalName(str, idx, end, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => loopback, ($v) => loopback = $v, null));
                    break;
                    case 21474836480n:
                    if ($.$spu.System.Uri.StaticInFact(flags.$v, 8796093022208n))
                    {
                        host = $.$spc.System.String.Empty;
                    }
                    else 
                    {
                        host = $.$spc.System.String.Substring$1.call(str, idx, ((end - idx) | 0));
                    }
                    if (host.length === 0)
                    {
                        loopback = true;
                    }
                    break;
                    case 30064771072n:
                    host = $.$spc.System.String.Empty;
                    break;
                    default:
                    throw $.$spu.System.Uri.GetException(8/*ParsingError.BadHostName*/);
                }
                if (loopback)
                {
                    flags.$v |= 274877906944n;
                }
                return host;
            }
            /*void */ GetHostViaCustomSyntax()
            {
                if ($.$spc.System.String.op_Inequality(this._info.Host, null))
                {
                    return;
                }
                /*string*/ let host = this._syntax.InternalGetComponents(this, 4/*UriComponents.Host*/, 1/*UriFormat.UriEscaped*/);
                if (this._info.Host === null)
                {
                    /*ParsingError*/ let err = 0/*ParsingError.None*/;
                    /*Flags*/ let flags = this._flags & ~30064771072n;
                    /*fixed*/ 
                    {
                        /*char**/ let pHost = $.$spc.System.String.GetPinnableReference.call(host);
                        /*string?*/ let newHost = null;
                        if (this.CheckAuthorityHelper(pHost, 0, host.length, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.ParsingError, () => err, ($v) => err = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => flags, ($v) => flags = $v, null), this._syntax, $.$ref(() => newHost, ($v) => newHost = $v, $.$spc.System.String)) !== host.length)
                        {
                            flags &= ~30064771072n;
                            flags |= 30064771072n;
                        }
                    }
                    if (err !== 0/*ParsingError.None*/ || (flags & 30064771072n) === 30064771072n)
                    {
                        this._flags = (this._flags & ~30064771072n) | 21474836480n;
                    }
                    else 
                    {
                        host = $.$spu.System.Uri.CreateHostStringHelper(host, 0, host.length, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => flags, ($v) => flags = $v, null), this._info);
                        for(/*int*/ let i = 0; i < host.length; ++i)
                        {
                            if ((((this._info.Offset.Host + i) | 0)) >= this._info.Offset.End || $.$spc.System.String.get_Chars.call(host, i) !== $.$spc.System.String.get_Chars.call(this._string, ((this._info.Offset.Host + i) | 0)))
                            {
                                this._flags |= (4n | 256n);
                                break;
                            }
                        }
                        this._flags = (this._flags & ~30064771072n) | (flags & 30064771072n);
                    }
                }
                /*string*/ let portStr = this._syntax.InternalGetComponents(this, 128/*UriComponents.StrongPort*/, 1/*UriFormat.UriEscaped*/);
                /*int*/ let port = 0;
                if ($.$spc.System.String.IsNullOrEmpty(portStr))
                {
                    this._flags &= ~549755813888n;
                    this._flags |= (8n | 512n);
                    this._info.Offset.PortValue = 0;
                }
                else 
                {
                    for(/*int*/ let idx = 0; idx < portStr.length; ++idx)
                    {
                        /*int*/ let val = $.$spc.System.String.get_Chars.call(portStr, idx) - /*0*/ 48;
                        if (val < 0 || val > 9 || (port = (((((port * 10) | 0) + val) | 0))) > 65535)
                        {
                            throw new $.$spu.System.UriFormatException().$ctor$14($.$spu.System.SR.Format$1($.$spu.System.SR.net_uri_PortOutOfRange, $.$spc.System.Object.GetType.call(this._syntax), portStr));
                        }
                    }
                    if (port !== this._info.Offset.PortValue)
                    {
                        if (port === this._syntax.DefaultPort)
                        {
                            this._flags &= ~549755813888n;
                        }
                        else 
                        {
                            this._flags |= 549755813888n;
                        }
                        this._flags |= (8n | 512n);
                        this._info.Offset.PortValue = $.$cast(port, $.$spc.System.UInt16);
                    }
                }
                this._info.Host = host;
            }
            /*string */ GetParts(/*UriComponents*/ uriParts, /*UriFormat*/ formatAs)
            {
                return this.InternalGetComponents(uriParts, formatAs);
            }
            /*string */ GetEscapedParts(/*UriComponents*/ uriParts)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._info !== null && (this._flags & 70368744177664n) !== 0n, "_info != null && (_flags & Flags.MinimalUriInfoSet) != 0");
                /*ushort*/ let nonCanonical = $.$cast((($.$cast(this._flags, $.$spc.System.UInt16) & (($.$cast(127n, $.$spc.System.UInt16) << 7) >>> 0)) >> 6), $.$spc.System.UInt16);
                if (this.InFact(1n))
                {
                    nonCanonical |= $.$cast(1n, $.$spc.System.UInt16);
                }
                if ((uriParts & 16/*UriComponents.Path*/) !== 0)
                {
                    if (this.InFact(8192n | 16384n | 32768n))
                    {
                        nonCanonical |= $.$cast(16n, $.$spc.System.UInt16);
                    }
                    else if (this.IsDosPath && $.$spc.System.String.get_Chars.call(this._string, ((((this._info.Offset.Path + this.SecuredPathIndex) | 0) - 1) | 0)) === /*|*/ 124)
                    {
                        nonCanonical |= $.$cast(16n, $.$spc.System.UInt16);
                    }
                }
                if (($.$cast(uriParts, $.$spc.System.UInt16) & nonCanonical) === 0)
                {
                    /*string?*/ let ret = this.GetUriPartsFromUserString(uriParts);
                    if (!(ret === null))
                    {
                        return ret;
                    }
                }
                return this.RecreateParts(uriParts, nonCanonical, 1/*UriFormat.UriEscaped*/);
            }
            /*string */ GetUnescapedParts(/*UriComponents*/ uriParts, /*UriFormat*/ formatAs)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._info !== null && (this._flags & 70368744177664n) !== 0n, "_info != null && (_flags & Flags.MinimalUriInfoSet) != 0");
                /*ushort*/ let nonCanonical = $.$cast(($.$cast(this._flags, $.$spc.System.UInt16) & $.$cast(127n, $.$spc.System.UInt16)), $.$spc.System.UInt16);
                if ((uriParts & 16/*UriComponents.Path*/) !== 0)
                {
                    if ((this._flags & (8192n | 16384n | 32768n)) !== 0n)
                    {
                        nonCanonical |= $.$cast(16n, $.$spc.System.UInt16);
                    }
                    else if (this.IsDosPath && $.$spc.System.String.get_Chars.call(this._string, ((((this._info.Offset.Path + this.SecuredPathIndex) | 0) - 1) | 0)) === /*|*/ 124)
                    {
                        nonCanonical |= $.$cast(16n, $.$spc.System.UInt16);
                    }
                }
                if (($.$cast(uriParts, $.$spc.System.UInt16) & nonCanonical) === 0)
                {
                    /*string?*/ let ret = this.GetUriPartsFromUserString(uriParts);
                    if (!(ret === null))
                    {
                        return ret;
                    }
                }
                return this.RecreateParts(uriParts, nonCanonical, formatAs);
            }
            /*string */ RecreateParts(/*UriComponents*/ parts, /*ushort*/ nonCanonical, /*UriFormat*/ formatAs)
            {
                this.EnsureHostString(false);
                /*string*/ let str = this._string;
                /*var*/ let dest = str.length <= 512/*StackallocThreshold*/ ? new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*StackallocThreshold*/, null)) : new $.$spu.System.Text.ValueStringBuilder().$ctor$3(str.length);
                /*scoped ReadOnlySpan<char>*/ let result = this.RecreateParts$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null), str, parts, nonCanonical, formatAs);
                /*string*/ let s = $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(result);
                dest.Dispose();
                return s;
            }
            /*bool */ TryRecreateParts(/*scoped Span<char>*/ span, /*out int*/ charsWritten, /*UriComponents*/ parts, /*ushort*/ nonCanonical, /*UriFormat*/ formatAs)
            {
                this.EnsureHostString(false);
                /*string*/ let str = this._string;
                /*var*/ let dest = str.length <= 512/*StackallocThreshold*/ ? new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*StackallocThreshold*/, null)) : new $.$spu.System.Text.ValueStringBuilder().$ctor$3(str.length);
                /*scoped ReadOnlySpan<char>*/ let result = this.RecreateParts$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null), str, parts, nonCanonical, formatAs);
                /*bool*/ let copied = result.TryCopyTo(span);
                charsWritten.$v = copied ? result.Length : 0;
                dest.Dispose();
                return copied;
            }
            /*ReadOnlySpan<char> */ RecreateParts$1(/*scoped ref ValueStringBuilder*/ dest, /*string*/ str, /*UriComponents*/ parts, /*ushort*/ nonCanonical, /*UriFormat*/ formatAs)
            {
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this.InFact(140737488355328n), "InFact(Flags.AllUriInfoSet)");
                            if ((parts & 1/*UriComponents.Scheme*/) !== 0)
                            {
                                dest.$v.Append$2(this._syntax.SchemeName);
                                if (parts !== 1/*UriComponents.Scheme*/)
                                {
                                    dest.$v.Append$1(/*:*/ 58);
                                    if (this.InFact(68719476736n))
                                    {
                                        dest.$v.Append$1(/*/*/ 47);
                                        dest.$v.Append$1(/*/*/ 47);
                                    }
                                }
                            }
                            if ((parts & 2/*UriComponents.UserInfo*/) !== 0 && this.InFact(137438953472n))
                            {
                                /*ReadOnlySpan<char>*/ let slice = $.$spc.System.MemoryExtensions.AsSpan$7(str, this._info.Offset.User, ((this._info.Offset.Host - this._info.Offset.User) | 0));
                                if ((nonCanonical & $.$cast(2/*UriComponents.UserInfo*/, $.$spc.System.UInt16)) !== 0)
                                {
                                    switch(formatAs)
                                    {
                                        case 1/*UriFormat.UriEscaped*/:
                                        if (this.NotAny(34359738368n))
                                        {
                                            $.$spu.System.UriHelper.EscapeString$2(slice, dest, true, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
                                        }
                                        else 
                                        {
                                            dest.$v.Append$4(slice);
                                        }
                                        break;
                                        case 3/*UriFormat.SafeUnescaped*/:
                                        let $t3 = slice;
                                        $.$spu.System.UriHelper.UnescapeString$3($t3.Slice$1(0, $t3.Length - 1), dest, /*@*/ 64, /*/*/ 47, /*\\*/ 92, this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/, this._syntax, false);
                                        dest.$v.Append$1(/*@*/ 64);
                                        break;
                                        case 2/*UriFormat.Unescaped*/:
                                        $.$spu.System.UriHelper.UnescapeString$3(slice, dest, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, this._syntax, false);
                                        break;
                                        default:
                                        dest.$v.Append$4(slice);
                                        break;
                                    }
                                }
                                else 
                                {
                                    dest.$v.Append$4(slice);
                                }
                                if (parts === 2/*UriComponents.UserInfo*/)
                                {
                                    dest.$v.Length--;
                                }
                            }
                            if ((parts & 4/*UriComponents.Host*/) !== 0)
                            {
                                /*string*/ let host = this._info.Host;
                                if (host.length !== 0)
                                {
                                    /*UnescapeMode*/ let mode;
                                    if (formatAs !== 1/*UriFormat.UriEscaped*/ && this.HostType === 21474836480n && (nonCanonical & $.$cast(4/*UriComponents.Host*/, $.$spc.System.UInt16)) !== 0)
                                    {
                                        mode = formatAs === 2/*UriFormat.Unescaped*/ ? (2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/) : (this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/);
                                    }
                                    else 
                                    {
                                        mode = 0/*UnescapeMode.CopyOnly*/;
                                    }
                                    /*var*/ let hostBuilder = new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*StackallocThreshold*/, null));
                                    if ((parts & 256/*UriComponents.NormalizedHost*/) !== 0)
                                    {
                                        host = $.$spu.System.UriHelper.StripBidiControlCharacters($.$spc.System.String.op_Implicit(host), host);
                                        if (!$.$spu.System.DomainNameHelper.TryGetUnicodeEquivalent(host, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => hostBuilder, ($v) => hostBuilder = $v, null)))
                                        {
                                            hostBuilder.Length = 0;
                                        }
                                    }
                                    $.$spu.System.UriHelper.UnescapeString$3(hostBuilder.Length === 0 ? $.$spc.System.String.op_Implicit(host) : hostBuilder.AsSpan$1(), dest, /*/*/ 47, /*?*/ 63, /*#*/ 35, mode, this._syntax, false);
                                    hostBuilder.Dispose();
                                    let scopeId;
                                    if ((parts & -2147483648/*UriComponents.SerializationInfoString*/) !== 0 && this.HostType === 4294967296n && $.$is((this._info._moreInfo?.ScopeId ?? null), $.$spc.System.String, { set $v(v){ scopeId = v; } }))
                                    {
                                        dest.$v.Length--;
                                        dest.$v.Append$2(scopeId);
                                        dest.$v.Append$1(/*]*/ 93);
                                    }
                                }
                            }
                            if ((parts & 8/*UriComponents.Port*/) !== 0 && (this.InFact(549755813888n) || ((parts & 128/*UriComponents.StrongPort*/) !== 0 && this._syntax.DefaultPort !== -1/*UriParser.NoDefaultPort*/)))
                            {
                                dest.$v.Append$1(/*:*/ 58);
                                /*int*/ let MaxUshortLength = 5;
                                /*int*/ let charsWritten;
                                /*bool*/ let success = $.$spc.System.UInt16.TryFormat.call(this._info.Offset.PortValue, dest.$v.AppendSpan(MaxUshortLength), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))(), null);
                                $.$spc.System.Diagnostics.Debug.Assert$1(success, "success");
                                dest.$v.Length -= ((MaxUshortLength - charsWritten) | 0);
                            }
                            if ((parts & 16/*UriComponents.Path*/) !== 0)
                            {
                                this.GetCanonicalPath(dest, formatAs);
                                if (parts === 16/*UriComponents.Path*/)
                                {
                                    /*int*/ let offset;
                                    if (this.InFact(68719476736n) && dest.$v.Length !== 0 && dest.$v.get_Item(0).$v === /*/*/ 47)
                                    {
                                        offset = 1;
                                    }
                                    else 
                                    {
                                        offset = 0;
                                    }
                                    return dest.$v.AsSpan$2(offset);
                                }
                            }
                            if ((parts & 32/*UriComponents.Query*/) !== 0 && this._info.Offset.Query < this._info.Offset.Fragment)
                            {
                                /*int*/ let offset = (((this._info.Offset.Query + 1) | 0));
                                if (parts !== 32/*UriComponents.Query*/)
                                {
                                    dest.$v.Append$1(/*?*/ 63);
                                }
                                /*UnescapeMode*/ let mode = 0/*UnescapeMode.CopyOnly*/;
                                if ((nonCanonical & $.$cast(32/*UriComponents.Query*/, $.$spc.System.UInt16)) !== 0)
                                {
                                    if (formatAs === 1/*UriFormat.UriEscaped*/)
                                    {
                                        if (this.NotAny(34359738368n))
                                        {
                                            $.$spu.System.UriHelper.EscapeString$2($.$spc.System.MemoryExtensions.AsSpan$7(str, offset, ((this._info.Offset.Fragment - offset) | 0)), dest, true, $.$spu.System.UriHelper.UnreservedReservedExceptHash);
                                            $gotoJumpState1 = 1; /*goto AfterQuery*/
                                            continue $gotoJumpStart1;
                                        }
                                    }
                                    else 
                                    {
                                        mode = (() =>
                                        {
                                            if (formatAs === 32767/*V1ToStringUnescape*/)
                                            {
                                                return (this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/) | 4/*UnescapeMode.V1ToStringFlag*/;
                                            }
                                            if (formatAs === 2/*UriFormat.Unescaped*/)
                                            {
                                                return 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/;
                                            }
                                            return this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/;
                                        })();
                                    }
                                }
                                $.$spu.System.UriHelper.UnescapeString$2(str, offset, this._info.Offset.Fragment, dest, /*#*/ 35, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, mode, this._syntax, true);
                            }
                        }
                        case 1: /*AfterQuery*/
                        if ((parts & 64/*UriComponents.Fragment*/) !== 0 && this._info.Offset.Fragment < this._info.Offset.End)
                        {
                            /*int*/ let offset = ((this._info.Offset.Fragment + 1) | 0);
                            if (parts !== 64/*UriComponents.Fragment*/)
                            {
                                dest.$v.Append$1(/*#*/ 35);
                            }
                            /*UnescapeMode*/ let mode = 0/*UnescapeMode.CopyOnly*/;
                            if ((nonCanonical & $.$cast(64/*UriComponents.Fragment*/, $.$spc.System.UInt16)) !== 0)
                            {
                                if (formatAs === 1/*UriFormat.UriEscaped*/)
                                {
                                    if (this.NotAny(34359738368n))
                                    {
                                        $.$spu.System.UriHelper.EscapeString$2($.$spc.System.MemoryExtensions.AsSpan$7(str, offset, ((this._info.Offset.End - offset) | 0)), dest, true, $.$spu.System.UriHelper.UnreservedReserved);
                                        $gotoJumpState1 = 2; /*goto AfterFragment*/
                                        continue $gotoJumpStart1;
                                    }
                                }
                                else 
                                {
                                    mode = (() =>
                                    {
                                        if (formatAs === 32767/*V1ToStringUnescape*/)
                                        {
                                            return (this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/) | 4/*UnescapeMode.V1ToStringFlag*/;
                                        }
                                        if (formatAs === 2/*UriFormat.Unescaped*/)
                                        {
                                            return 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/;
                                        }
                                        return this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/;
                                    })();
                                }
                            }
                            $.$spu.System.UriHelper.UnescapeString$2(str, offset, this._info.Offset.End, dest, /*#*/ 35, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, mode, this._syntax, false);
                        }
                        case 2: /*AfterFragment*/
                        return dest.$v.AsSpan$1();
                    }
                    break;
                }
            }
            /*string? */ GetUriPartsFromUserString(/*UriComponents*/ uriParts)
            {
                /*int*/ let delimiterAwareIdx;
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    let $switch1 = $switchJumpState1 ?? (uriParts & ~1073741824/*UriComponents.KeepDelimiter*/);
                    switch($switch1)
                    {
                        case 1/*UriComponents.Scheme*/ | 4/*UriComponents.Host*/ | 8/*UriComponents.Port*/:
                        if (!this.InFact(137438953472n))
                        {
                            return $.$spc.System.String.Substring$1.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.Path - this._info.Offset.Scheme) | 0));
                        }
                        return $.$spc.System.String.Concat$10($.$spc.System.MemoryExtensions.AsSpan$7(this._string, this._info.Offset.Scheme, ((this._info.Offset.User - this._info.Offset.Scheme) | 0)), $.$spc.System.MemoryExtensions.AsSpan$7(this._string, this._info.Offset.Host, ((this._info.Offset.Path - this._info.Offset.Host) | 0)));
                        case 132/*UriComponents.HostAndPort*/:
                        if (!this.InFact(137438953472n))
                        {
                            $switchJumpState1 = 134/*UriComponents.StrongAuthority*/; /*goto case UriComponents.StrongAuthority*/
                            continue $switchJumpStart1;
                        }
                        if (this.InFact(549755813888n) || this._syntax.DefaultPort === -1/*UriParser.NoDefaultPort*/)
                        {
                            return $.$spc.System.String.Substring$1.call(this._string, this._info.Offset.Host, ((this._info.Offset.Path - this._info.Offset.Host) | 0));
                        }
                        return $.$spc.System.String.Concat$11($.$spc.System.MemoryExtensions.AsSpan$7(this._string, this._info.Offset.Host, ((this._info.Offset.Path - this._info.Offset.Host) | 0)), $.$spc.System.String.op_Implicit(":"), $.$spc.System.String.op_Implicit($.$spc.System.UInt16.ToString$1.call(this._info.Offset.PortValue, $.$spc.System.Globalization.CultureInfo.InvariantCulture)));
                        case 127/*UriComponents.AbsoluteUri*/:
                        if (this._info.Offset.Scheme === 0 && this._info.Offset.End === this._string.length)
                        {
                            return this._string;
                        }
                        return $.$spc.System.String.Substring$1.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.End - this._info.Offset.Scheme) | 0));
                        case 61/*UriComponents.HttpRequestUrl*/:
                        if (this.InFact(137438953472n))
                        {
                            return $.$spc.System.String.Concat$10($.$spc.System.MemoryExtensions.AsSpan$7(this._string, this._info.Offset.Scheme, ((this._info.Offset.User - this._info.Offset.Scheme) | 0)), $.$spc.System.MemoryExtensions.AsSpan$7(this._string, this._info.Offset.Host, ((this._info.Offset.Fragment - this._info.Offset.Host) | 0)));
                        }
                        if (this._info.Offset.Scheme === 0 && this._info.Offset.Fragment === this._string.length)
                        {
                            return this._string;
                        }
                        return $.$spc.System.String.Substring$1.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.Fragment - this._info.Offset.Scheme) | 0));
                        case 13/*UriComponents.SchemeAndServer*/ | 2/*UriComponents.UserInfo*/:
                        return $.$spc.System.String.Substring$1.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.Path - this._info.Offset.Scheme) | 0));
                        case (127/*UriComponents.AbsoluteUri*/ & ~64/*UriComponents.Fragment*/):
                        if (this._info.Offset.Scheme === 0 && this._info.Offset.Fragment === this._string.length)
                        {
                            return this._string;
                        }
                        return $.$spc.System.String.Substring$1.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.Fragment - this._info.Offset.Scheme) | 0));
                        case 1/*UriComponents.Scheme*/:
                        if (uriParts !== 1/*UriComponents.Scheme*/)
                        {
                            return $.$spc.System.String.Substring$1.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.User - this._info.Offset.Scheme) | 0));
                        }
                        return this._syntax.SchemeName;
                        case 4/*UriComponents.Host*/:
                        /*int*/ let idx = this._info.Offset.Path;
                        if (this.InFact(549755813888n | 8n))
                        {
                            while($.$spc.System.String.get_Chars.call(this._string, --idx) !== /*:*/ 58)
                            {
                            }
                        }
                        return (((idx - this._info.Offset.Host) | 0) === 0) ? $.$spc.System.String.Empty : $.$spc.System.String.Substring$1.call(this._string, this._info.Offset.Host, ((idx - this._info.Offset.Host) | 0));
                        case 16/*UriComponents.Path*/:
                        if (uriParts === 16/*UriComponents.Path*/ && this.InFact(68719476736n) && this._info.Offset.End > this._info.Offset.Path && $.$spc.System.String.get_Chars.call(this._string, this._info.Offset.Path) === /*/*/ 47)
                        {
                            delimiterAwareIdx = ((this._info.Offset.Path + 1) | 0);
                        }
                        else 
                        {
                            delimiterAwareIdx = this._info.Offset.Path;
                        }
                        if (delimiterAwareIdx >= this._info.Offset.Query)
                        {
                            return $.$spc.System.String.Empty;
                        }
                        return $.$spc.System.String.Substring$1.call(this._string, delimiterAwareIdx, ((this._info.Offset.Query - delimiterAwareIdx) | 0));
                        case 32/*UriComponents.Query*/:
                        if (uriParts === 32/*UriComponents.Query*/)
                        {
                            delimiterAwareIdx = ((this._info.Offset.Query + 1) | 0);
                        }
                        else 
                        {
                            delimiterAwareIdx = this._info.Offset.Query;
                        }
                        if (delimiterAwareIdx >= this._info.Offset.Fragment)
                        {
                            return $.$spc.System.String.Empty;
                        }
                        return $.$spc.System.String.Substring$1.call(this._string, delimiterAwareIdx, ((this._info.Offset.Fragment - delimiterAwareIdx) | 0));
                        case 64/*UriComponents.Fragment*/:
                        if (uriParts === 64/*UriComponents.Fragment*/)
                        {
                            delimiterAwareIdx = ((this._info.Offset.Fragment + 1) | 0);
                        }
                        else 
                        {
                            delimiterAwareIdx = this._info.Offset.Fragment;
                        }
                        if (delimiterAwareIdx >= this._info.Offset.End)
                        {
                            return $.$spc.System.String.Empty;
                        }
                        return $.$spc.System.String.Substring$1.call(this._string, delimiterAwareIdx, ((this._info.Offset.End - delimiterAwareIdx) | 0));
                        case 2/*UriComponents.UserInfo*/ | 4/*UriComponents.Host*/ | 8/*UriComponents.Port*/:
                        return (((this._info.Offset.Path - this._info.Offset.User) | 0) === 0) ? $.$spc.System.String.Empty : $.$spc.System.String.Substring$1.call(this._string, this._info.Offset.User, ((this._info.Offset.Path - this._info.Offset.User) | 0));
                        case 134/*UriComponents.StrongAuthority*/:
                        if (this.InFact(549755813888n) || this._syntax.DefaultPort === -1/*UriParser.NoDefaultPort*/)
                        {
                            $switchJumpState1 = 2/*UriComponents.UserInfo*/ | 4/*UriComponents.Host*/ | 8/*UriComponents.Port*/; /*goto case UriComponents.UserInfo | UriComponents.Host | UriComponents.Port*/
                            continue $switchJumpStart1;
                        }
                        return $.$spc.System.String.Concat$11($.$spc.System.MemoryExtensions.AsSpan$7(this._string, this._info.Offset.User, ((this._info.Offset.Path - this._info.Offset.User) | 0)), $.$spc.System.String.op_Implicit(":"), $.$spc.System.String.op_Implicit($.$spc.System.UInt16.ToString$1.call(this._info.Offset.PortValue, $.$spc.System.Globalization.CultureInfo.InvariantCulture)));
                        case 48/*UriComponents.PathAndQuery*/:
                        return $.$spc.System.String.Substring$1.call(this._string, this._info.Offset.Path, ((this._info.Offset.Fragment - this._info.Offset.Path) | 0));
                        case 61/*UriComponents.HttpRequestUrl*/ | 64/*UriComponents.Fragment*/:
                        if (this.InFact(137438953472n))
                        {
                            return $.$spc.System.String.Concat$10($.$spc.System.MemoryExtensions.AsSpan$7(this._string, this._info.Offset.Scheme, ((this._info.Offset.User - this._info.Offset.Scheme) | 0)), $.$spc.System.MemoryExtensions.AsSpan$7(this._string, this._info.Offset.Host, ((this._info.Offset.End - this._info.Offset.Host) | 0)));
                        }
                        if (this._info.Offset.Scheme === 0 && this._info.Offset.End === this._string.length)
                        {
                            return this._string;
                        }
                        return $.$spc.System.String.Substring$1.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.End - this._info.Offset.Scheme) | 0));
                        case 48/*UriComponents.PathAndQuery*/ | 64/*UriComponents.Fragment*/:
                        return $.$spc.System.String.Substring$1.call(this._string, this._info.Offset.Path, ((this._info.Offset.End - this._info.Offset.Path) | 0));
                        case 2/*UriComponents.UserInfo*/:
                        if (this.NotAny(137438953472n))
                        {
                            return $.$spc.System.String.Empty;
                        }
                        if (uriParts === 2/*UriComponents.UserInfo*/)
                        {
                            delimiterAwareIdx = ((this._info.Offset.Host - 1) | 0);
                        }
                        else 
                        {
                            delimiterAwareIdx = this._info.Offset.Host;
                        }
                        if (this._info.Offset.User >= delimiterAwareIdx)
                        {
                            return $.$spc.System.String.Empty;
                        }
                        return $.$spc.System.String.Substring$1.call(this._string, this._info.Offset.User, ((delimiterAwareIdx - this._info.Offset.User) | 0));
                        default:
                        return null;
                    }
                    break;
                }
            }
            static /*void */ GetLengthWithoutTrailingSpaces(/*string*/ str, /*ref int*/ length, /*int*/ idx)
            {
                /*int*/ let local = length.$v;
                while(local > idx && $.$spu.System.UriHelper.IsLWS($.$spc.System.String.get_Chars.call(str, ((local - 1) | 0))))
                {
                    --local;
                }
                length.$v = local;
            }
            /*void */ ParseRemaining()
            {
                /*Flags*/ let cF;
                /*bool*/ let buildIriStringFromPath;
                /*int*/ let origIdx;
                /*int*/ let idx;
                /*int*/ let length;
                /*Check*/ let result;
                /*UriSyntaxFlags*/ let syntaxFlags;
                /*bool*/ let nonCanonical;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            this.EnsureUriInfo();
                            cF = 0n;
                            if (this.UserDrivenParsing)
                            {
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            buildIriStringFromPath = this.InFact(562949953421312n);
                            idx = this._info.Offset.Scheme;
                            length = this._string.length;
                            result = 0/*Check.None*/;
                            syntaxFlags = this._syntax.Flags;
                            /*fixed*/ 
                            {
                                /*char**/ let str = $.$spc.System.String.GetPinnableReference.call(this._string);
                                $.$spu.System.Uri.GetLengthWithoutTrailingSpaces(this._string, $.$ref(() => length, ($v) => length = $v, $.$spc.System.Int32), idx);
                                if (this.IsImplicitFile)
                                {
                                    cF |= 1n;
                                }
                                else 
                                {
                                    /*int*/ let i;
                                    /*string*/ let schemeName = this._syntax.SchemeName;
                                    for(i = 0; i < schemeName.length; ++i)
                                    {
                                        if ($.$spc.System.String.get_Chars.call(schemeName, i) !== str.GetAt(((idx + i) | 0)))
                                        {
                                            cF |= 1n;
                                        }
                                    }
                                    if (((this._flags & 68719476736n) !== 0n) && (((((idx + i) | 0) + 3) | 0) >= length || str.GetAt(((((idx + i) | 0) + 1) | 0)) !== /*/*/ 47 || str.GetAt(((((idx + i) | 0) + 2) | 0)) !== /*/*/ 47))
                                    {
                                        cF |= 1n;
                                    }
                                }
                                if ((this._flags & 137438953472n) !== 0n)
                                {
                                    idx = this._info.Offset.User;
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$spc.System.Int32), this._info.Offset.Host, /*@*/ 64);
                                    if ((result & 2/*Check.DisplayCanonical*/) === 0)
                                    {
                                        cF |= 2n;
                                    }
                                    if ((result & (1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/)) !== 1/*Check.EscapedCanonical*/)
                                    {
                                        cF |= 128n;
                                    }
                                    if (this.IriParsing && ((result & (2/*Check.DisplayCanonical*/ | 1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) === (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                                    {
                                        cF |= 1125899906842624n;
                                    }
                                }
                            }
                            idx = this._info.Offset.Path;
                            origIdx = this._info.Offset.Path;
                            if (buildIriStringFromPath)
                            {
                                this.DebugAssertInCtor();
                                if (this.IsFile && !this.IsUncPath)
                                {
                                    if (this.IsImplicitFile)
                                    {
                                        this._string = $.$spc.System.String.Empty;
                                    }
                                    else 
                                    {
                                        this._string = this._syntax.SchemeName + $.$spu.System.Uri.SchemeDelimiter;
                                    }
                                    this._info.Offset.Scheme = 0;
                                    this._info.Offset.User = this._string.length;
                                    this._info.Offset.Host = this._string.length;
                                }
                                this._info.Offset.Path = this._string.length;
                                idx = this._info.Offset.Path;
                            }
                            if (this.DisablePathAndQueryCanonicalization)
                            {
                                if (buildIriStringFromPath)
                                {
                                    this.DebugAssertInCtor();
                                    this._string = $.$spc.System.String.Concat$10($.$spc.System.String.op_Implicit(this._string), $.$spc.System.MemoryExtensions.AsSpan$4(this._originalUnicodeString, origIdx));
                                }
                                /*string*/ let str = this._string;
                                if (this.IsImplicitFile || (syntaxFlags & 32/*UriSyntaxFlags.MayHaveQuery*/) === 0)
                                {
                                    idx = str.length;
                                }
                                else 
                                {
                                    idx = $.$spc.System.String.IndexOf.call(str, /*?*/ 63);
                                    if (idx === -1)
                                    {
                                        idx = str.length;
                                    }
                                }
                                this._info.Offset.Query = idx;
                                this._info.Offset.Fragment = str.length;
                                this._info.Offset.End = str.length;
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            if (buildIriStringFromPath)
                            {
                                this.DebugAssertInCtor();
                                /*int*/ let offset = origIdx;
                                if (this.IsImplicitFile || ((syntaxFlags & (32/*UriSyntaxFlags.MayHaveQuery*/ | 64/*UriSyntaxFlags.MayHaveFragment*/)) === 0))
                                {
                                    origIdx = this._originalUnicodeString.length;
                                }
                                else 
                                {
                                    /*ReadOnlySpan<char>*/ let span = $.$spc.System.MemoryExtensions.AsSpan$4(this._originalUnicodeString, origIdx);
                                    /*int*/ let index;
                                    if (this._syntax.InFact(32/*UriSyntaxFlags.MayHaveQuery*/))
                                    {
                                        if (this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/))
                                        {
                                            index = $.$spc.System.MemoryExtensions.IndexOfAny$5($.$spc.System.Char, span, /*?*/ 63, /*#*/ 35);
                                        }
                                        else 
                                        {
                                            index = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, span, /*?*/ 63);
                                        }
                                    }
                                    else 
                                    {
                                        $.$spc.System.Diagnostics.Debug.Assert$1(this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/), "_syntax.InFact(UriSyntaxFlags.MayHaveFragment)");
                                        index = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, span, /*#*/ 35);
                                    }
                                    origIdx = index === -1 ? this._originalUnicodeString.length : (((index + origIdx) | 0));
                                }
                                this._string += this.EscapeUnescapeIri(this._originalUnicodeString, offset, origIdx, 16/*UriComponents.Path*/);
                                length = this._string.length;
                                if ($.$spc.System.String.op_Equality(this._string, this._originalUnicodeString))
                                {
                                    $.$spu.System.Uri.GetLengthWithoutTrailingSpaces(this._string, $.$ref(() => length, ($v) => length = $v, $.$spc.System.Int32), idx);
                                }
                            }
                            /*fixed*/ 
                            {
                                /*char**/ let str = $.$spc.System.String.GetPinnableReference.call(this._string);
                                if (this.IsImplicitFile || ((syntaxFlags & (32/*UriSyntaxFlags.MayHaveQuery*/ | 64/*UriSyntaxFlags.MayHaveFragment*/)) === 0))
                                {
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$spc.System.Int32), length, /*\uFFFF*/ 65535);
                                }
                                else 
                                {
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$spc.System.Int32), length, (((syntaxFlags & 32/*UriSyntaxFlags.MayHaveQuery*/) !== 0) ? /*?*/ 63 : this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/) ? /*#*/ 35 : /*\uFFFE*/ 65534));
                                }
                                if (((this._flags & 68719476736n) !== 0n) && ((syntaxFlags & 2097152/*UriSyntaxFlags.PathIsRooted*/) !== 0) && (this._info.Offset.Path === length || (str.GetAt(this._info.Offset.Path) !== /*/*/ 47 && str.GetAt(this._info.Offset.Path) !== /*\\*/ 92)))
                                {
                                    cF |= 16384n;
                                }
                            }
                            nonCanonical = false;
                            if (this.IsDosPath || (((this._flags & 68719476736n) !== 0n) && (((syntaxFlags & (8388608/*UriSyntaxFlags.CompressPath*/ | 4194304/*UriSyntaxFlags.ConvertPathSlashes*/)) !== 0) || this._syntax.InFact(33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/))))
                            {
                                if (((result & 128/*Check.DotSlashEscaped*/) !== 0) && this._syntax.InFact(33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/))
                                {
                                    cF |= (1024n | 16n);
                                    nonCanonical = true;
                                }
                                if (((syntaxFlags & (4194304/*UriSyntaxFlags.ConvertPathSlashes*/)) !== 0) && (result & 16/*Check.BackslashInPath*/) !== 0)
                                {
                                    cF |= (1024n | 16n);
                                    nonCanonical = true;
                                }
                                if (((syntaxFlags & (8388608/*UriSyntaxFlags.CompressPath*/)) !== 0) && ((cF & 1024n) !== 0n || (result & 4/*Check.DotSlashAttn*/) !== 0))
                                {
                                    cF |= 8192n;
                                }
                                if ((result & 16/*Check.BackslashInPath*/) !== 0)
                                {
                                    cF |= 32768n;
                                }
                            }
                            else if ((result & 16/*Check.BackslashInPath*/) !== 0)
                            {
                                cF |= 1024n;
                                nonCanonical = true;
                            }
                            if ((result & 2/*Check.DisplayCanonical*/) === 0)
                            {
                                if (((this._flags & 35184372088832n) === 0n) || ((this._flags & 34359738368n) !== 0n) || (result & 32/*Check.ReservedFound*/) !== 0)
                                {
                                    cF |= 16n;
                                    nonCanonical = true;
                                }
                            }
                            if (((this._flags & 35184372088832n) !== 0n) && (result & (32/*Check.ReservedFound*/ | 1/*Check.EscapedCanonical*/)) !== 0)
                            {
                                result &= ~1/*Check.EscapedCanonical*/;
                            }
                            if ((result & 1/*Check.EscapedCanonical*/) === 0)
                            {
                                cF |= 1024n;
                            }
                            if (this.IriParsing && !nonCanonical && ((result & (2/*Check.DisplayCanonical*/ | 1/*Check.EscapedCanonical*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) === (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                            {
                                cF |= 2251799813685248n;
                            }
                            if (buildIriStringFromPath)
                            {
                                this.DebugAssertInCtor();
                                /*int*/ let offset = origIdx;
                                if (origIdx < this._originalUnicodeString.length && $.$spc.System.String.get_Chars.call(this._originalUnicodeString, origIdx) === /*?*/ 63)
                                {
                                    if ((syntaxFlags & (64/*UriSyntaxFlags.MayHaveFragment*/)) !== 0)
                                    {
                                        ++origIdx;
                                        /*int*/ let index = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$4(this._originalUnicodeString, origIdx), /*#*/ 35);
                                        origIdx = index === -1 ? this._originalUnicodeString.length : (((index + origIdx) | 0));
                                    }
                                    else 
                                    {
                                        origIdx = this._originalUnicodeString.length;
                                    }
                                    this._string += this.EscapeUnescapeIri(this._originalUnicodeString, offset, origIdx, 32/*UriComponents.Query*/);
                                    length = this._string.length;
                                    if ($.$spc.System.String.op_Equality(this._string, this._originalUnicodeString))
                                    {
                                        $.$spu.System.Uri.GetLengthWithoutTrailingSpaces(this._string, $.$ref(() => length, ($v) => length = $v, $.$spc.System.Int32), idx);
                                    }
                                }
                            }
                            this._info.Offset.Query = idx;
                            /*fixed*/ 
                            {
                                /*char**/ let str = $.$spc.System.String.GetPinnableReference.call(this._string);
                                if (idx < length && str.GetAt(idx) === /*?*/ 63)
                                {
                                    ++idx;
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$spc.System.Int32), length, ((syntaxFlags & (64/*UriSyntaxFlags.MayHaveFragment*/)) !== 0) ? /*#*/ 35 : /*\uFFFE*/ 65534);
                                    if ((result & 2/*Check.DisplayCanonical*/) === 0)
                                    {
                                        cF |= 32n;
                                    }
                                    if ((result & (1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/)) !== 1/*Check.EscapedCanonical*/)
                                    {
                                        cF |= 2048n;
                                    }
                                    if (this.IriParsing && ((result & (2/*Check.DisplayCanonical*/ | 1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) === (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                                    {
                                        cF |= 4503599627370496n;
                                    }
                                }
                            }
                            if (buildIriStringFromPath)
                            {
                                this.DebugAssertInCtor();
                                /*int*/ let offset = origIdx;
                                if (origIdx < this._originalUnicodeString.length && $.$spc.System.String.get_Chars.call(this._originalUnicodeString, origIdx) === /*#*/ 35)
                                {
                                    origIdx = this._originalUnicodeString.length;
                                    this._string += this.EscapeUnescapeIri(this._originalUnicodeString, offset, origIdx, 64/*UriComponents.Fragment*/);
                                    length = this._string.length;
                                    $.$spu.System.Uri.GetLengthWithoutTrailingSpaces(this._string, $.$ref(() => length, ($v) => length = $v, $.$spc.System.Int32), idx);
                                }
                            }
                            this._info.Offset.Fragment = idx;
                            /*fixed*/ 
                            {
                                /*char**/ let str = $.$spc.System.String.GetPinnableReference.call(this._string);
                                if (idx < length && str.GetAt(idx) === /*#*/ 35)
                                {
                                    ++idx;
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$spc.System.Int32), length, /*\uFFFE*/ 65534);
                                    if ((result & 2/*Check.DisplayCanonical*/) === 0)
                                    {
                                        cF |= 64n;
                                    }
                                    if ((result & (1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/)) !== 1/*Check.EscapedCanonical*/)
                                    {
                                        cF |= 4096n;
                                    }
                                    if (this.IriParsing && ((result & (2/*Check.DisplayCanonical*/ | 1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) === (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                                    {
                                        cF |= 9007199254740992n;
                                    }
                                }
                            }
                            this._info.Offset.End = idx;
                        }
                        case 1: /*Done*/
                        cF |= 140737488355328n;
                        this.InterlockedSetFlags(cF);
                    }
                    break;
                }
            }
            static /*int */ ParseSchemeCheckImplicitFile(/*string*/ uriString, /*ref ParsingError*/ err, /*ref Flags*/ flags, /*ref UriParser?*/ syntax)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(err.$v === 0/*ParsingError.None*/, "err == ParsingError.None");
                $.$spc.System.Diagnostics.Debug.Assert$1((flags.$v & 144115188075855872n) === 0n, "(flags & Flags.Debug_LeftConstructor) == 0");
                /*int*/ let i = 0;
                while((i >>> 0) < (uriString.length >>> 0) && $.$spu.System.UriHelper.IsLWS($.$spc.System.String.get_Chars.call(uriString, i)))
                {
                    i++;
                }
                if (!$.$spc.System.OperatingSystem.IsWindows() && (i >>> 0) < (uriString.length >>> 0) && $.$spc.System.String.get_Chars.call(uriString, i) === /*/*/ 47 && (((((i + 1) | 0)) >>> 0) >= (uriString.length >>> 0) || !(($.$spc.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*/*/ 47) || ($.$spc.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*\\*/ 92))))
                {
                    flags.$v |= (18014398509481984n | 35184372088832n | 68719476736n);
                    syntax.$v = $.$spu.System.UriParser.UnixFileUri;
                    return i;
                }
                /*int*/ let colonOffset = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$4(uriString, i), /*:*/ 58);
                if (((((i + 2) | 0)) >>> 0) >= (uriString.length >>> 0) || colonOffset === 0 || (i >>> 0) >= (uriString.length >>> 0) || ((((i + 1) | 0)) >>> 0) >= (uriString.length >>> 0))
                {
                    err.$v = 1/*ParsingError.BadFormat*/;
                    return 0;
                }
                if (($.$spc.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*:*/ 58) || ($.$spc.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*|*/ 124))
                {
                    if ($.$spc.System.Char.IsAsciiLetter($.$spc.System.String.get_Chars.call(uriString, i)))
                    {
                        if (($.$spc.System.String.get_Chars.call(uriString, ((i + 2) | 0)) === /*\\*/ 92) || ($.$spc.System.String.get_Chars.call(uriString, ((i + 2) | 0)) === /*/*/ 47))
                        {
                            flags.$v |= (8796093022208n | 35184372088832n | 68719476736n);
                            syntax.$v = $.$spu.System.UriParser.FileUri;
                            return i;
                        }
                        err.$v = 7/*ParsingError.MustRootedPath*/;
                        return 0;
                    }
                    err.$v = $.$spc.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*:*/ 58 ? 2/*ParsingError.BadScheme*/ : 1/*ParsingError.BadFormat*/;
                    return 0;
                }
                else if (($.$spc.System.String.get_Chars.call(uriString, i) === /*/*/ 47) || ($.$spc.System.String.get_Chars.call(uriString, i) === /*\\*/ 92))
                {
                    if (($.$spc.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*\\*/ 92) || ($.$spc.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*/*/ 47))
                    {
                        flags.$v |= (17592186044416n | 35184372088832n | 68719476736n);
                        syntax.$v = $.$spu.System.UriParser.FileUri;
                        i += 2;
                        while((i >>> 0) < (uriString.length >>> 0) && ($.$spc.System.String.get_Chars.call(uriString, i) === /*/*/ 47) || ($.$spc.System.String.get_Chars.call(uriString, i) === /*\\*/ 92))
                        {
                            i++;
                        }
                        return i;
                    }
                    err.$v = 1/*ParsingError.BadFormat*/;
                    return 0;
                }
                if (colonOffset < 0)
                {
                    err.$v = 1/*ParsingError.BadFormat*/;
                    return 0;
                }
                syntax.$v = $.$spu.System.Uri.CheckSchemeSyntax($.$spc.System.MemoryExtensions.AsSpan$7(uriString, i, colonOffset), err);
                if (syntax.$v === null)
                {
                    return 0;
                }
                return ((((i + colonOffset) | 0) + 1) | 0);
            }
            static /*UriParser? */ CheckSchemeSyntax(/*ReadOnlySpan<char>*/ scheme, /*ref ParsingError*/ error)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(error.$v === 0/*ParsingError.None*/, "error == ParsingError.None");
                let $switch1 = scheme.Length;
                switch($switch1)
                {
                    case 2:
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("ws"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.WsUri;
                    }
                    break;
                    case 3:
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("wss"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.WssUri;
                    }
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("ftp"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.FtpUri;
                    }
                    break;
                    case 4:
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("http"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.HttpUri;
                    }
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("file"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.FileUri;
                    }
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("uuid"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.UuidUri;
                    }
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("nntp"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.NntpUri;
                    }
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("ldap"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.LdapUri;
                    }
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("news"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.NewsUri;
                    }
                    break;
                    case 5:
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("https"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.HttpsUri;
                    }
                    break;
                    case 6:
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("mailto"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.MailToUri;
                    }
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("gopher"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.GopherUri;
                    }
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("telnet"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.TelnetUri;
                    }
                    break;
                    case 7:
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("net.tcp"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.NetTcpUri;
                    }
                    break;
                    case 8:
                    if ($.$spc.System.MemoryExtensions.Equals$2(scheme, $.$spc.System.String.op_Implicit("net.pipe"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.NetPipeUri;
                    }
                    break;
                }
                if (scheme.Length === 0 || !$.$spc.System.Char.IsAsciiLetter(scheme.get_Item(0).$v) || $.$spc.System.MemoryExtensions.ContainsAnyExcept$13($.$spc.System.Char, scheme, $.$spu.System.Uri.s_schemeChars))
                {
                    error.$v = 2/*ParsingError.BadScheme*/;
                    return null;
                }
                if (scheme.Length > 1024/*SchemeLengthLimit*/)
                {
                    error.$v = 6/*ParsingError.SchemeLimit*/;
                    return null;
                }
                return $.$spu.System.UriParser.FindOrFetchAsUnknownV1Syntax($.$spu.System.UriHelper.SpanToLowerInvariantString(scheme));
            }
            /*int */ CheckAuthorityHelper(/*char**/ pString, /*int*/ idx, /*int*/ length, /*ref ParsingError*/ err, /*ref Flags*/ flags, /*UriParser*/ syntax, /*ref string?*/ newHost)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((this._flags & 144115188075855872n) === 0n || (!this._syntax.IsSimple && $.$spc.System.Threading.Monitor.IsEntered(this._info)), "(_flags & Flags.Debug_LeftConstructor) == 0 || (!_syntax.IsSimple && Monitor.IsEntered(_info))");
                /*int*/ let end = length;
                /*char*/ let ch;
                /*int*/ let startInput = idx;
                /*int*/ let start = idx;
                newHost.$v = null;
                /*bool*/ let hasUnicode = ((flags.$v & 562949953421312n) !== 0n);
                /*UriSyntaxFlags*/ let syntaxFlags = syntax.Flags;
                $.$spc.System.Diagnostics.Debug.Assert$1((this._flags & 137438953472n) === 0n && (this._flags & 30064771072n) === 0n, "(_flags & Flags.HasUserInfo) == 0 && (_flags & Flags.HostTypeMask) == 0");
                if (hasUnicode)
                {
                    newHost.$v = $.$spc.System.String.Substring$1.call(this._originalUnicodeString, 0, startInput);
                }
                if (idx === length || ((ch = pString.GetAt(idx)) === /*/*/ 47 || (ch === /*\\*/ 92 && $.$spu.System.Uri.StaticIsFile(syntax)) || ch === /*#*/ 35 || ch === /*?*/ 63))
                {
                    if (syntax.InFact(128/*UriSyntaxFlags.AllowEmptyHost*/))
                    {
                        flags.$v &= ~17592186044416n;
                        if ($.$spu.System.Uri.StaticInFact(flags.$v, 35184372088832n))
                        {
                            err.$v = 8/*ParsingError.BadHostName*/;
                        }
                        else 
                        {
                            flags.$v |= 21474836480n;
                        }
                    }
                    else 
                    {
                        err.$v = 8/*ParsingError.BadHostName*/;
                    }
                    return idx;
                }
                if ((syntaxFlags & 4/*UriSyntaxFlags.MayHaveUserInfo*/) !== 0)
                {
                    for(; start < end; ++start)
                    {
                        if (start === ((end - 1) | 0) || pString.GetAt(start) === /*?*/ 63 || pString.GetAt(start) === /*#*/ 35 || pString.GetAt(start) === /*\\*/ 92 || pString.GetAt(start) === /*/*/ 47)
                        {
                            start = idx;
                            break;
                        }
                        else if (pString.GetAt(start) === /*@*/ 64)
                        {
                            flags.$v |= 137438953472n;
                            if (hasUnicode)
                            {
                                newHost.$v += $.$spu.System.IriHelper.EscapeUnescapeIri(pString, startInput, ((start + 1) | 0), 2/*UriComponents.UserInfo*/);
                            }
                            ++start;
                            ch = pString.GetAt(start);
                            break;
                        }
                    }
                }
                /*int*/ let domainNameLength;
                if (ch === /*[*/ 91 && syntax.InFact(2048/*UriSyntaxFlags.AllowIPv6Host*/) && $.$spu.System.Net.IPv6AddressHelper.IsValid(pString, ((start + 1) | 0), $.$ref(() => end, ($v) => end = $v, $.$spc.System.Int32)))
                {
                    flags.$v |= 4294967296n;
                    if (hasUnicode)
                    {
                        newHost.$v = $.$spc.System.String.Concat$10($.$spc.System.String.op_Implicit(newHost.$v), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(pString.Add(start), ((end - start) | 0)));
                    }
                }
                else if ($.$spc.System.Char.IsAsciiDigit(ch) && syntax.InFact(1024/*UriSyntaxFlags.AllowIPv4Host*/) && $.$spu.System.Net.IPv4AddressHelper.IsValid($.$spc.System.Char, pString, start, $.$ref(() => end, ($v) => end = $v, $.$spc.System.Int32), false, $.$spu.System.Uri.StaticNotAny(flags.$v, 35184372088832n), syntax.InFact(65536/*UriSyntaxFlags.V1_UnknownUri*/)))
                {
                    flags.$v |= 8589934592n;
                    if (hasUnicode)
                    {
                        newHost.$v = $.$spc.System.String.Concat$10($.$spc.System.String.op_Implicit(newHost.$v), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(pString.Add(start), ((end - start) | 0)));
                    }
                }
                else if (((syntaxFlags & 512/*UriSyntaxFlags.AllowDnsHost*/) !== 0) && !$.$spu.System.Uri.IriParsingStatic(syntax) && $.$spu.System.DomainNameHelper.IsValid(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(pString.Add(start), ((end - start) | 0)), false, $.$spu.System.Uri.StaticNotAny(flags.$v, 35184372088832n), $.$ref(() => domainNameLength, ($v) => domainNameLength = $v, $.$spc.System.Int32)))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!hasUnicode, "!hasUnicode");
                    end = ((start + domainNameLength) | 0);
                    flags.$v |= 12884901888n;
                    if (!$.$spc.System.MemoryExtensions.ContainsAnyInRange$1($.$spc.System.Char, new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(pString.Add(start), domainNameLength), /*A*/ 65, /*Z*/ 90))
                    {
                        flags.$v |= 2199023255552n;
                    }
                }
                else if (((syntaxFlags & 512/*UriSyntaxFlags.AllowDnsHost*/) !== 0) && (hasUnicode || syntax.InFact(67108864/*UriSyntaxFlags.AllowIdn*/)) && $.$spu.System.DomainNameHelper.IsValid(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(pString.Add(start), ((end - start) | 0)), true, $.$spu.System.Uri.StaticNotAny(flags.$v, 35184372088832n), $.$ref(() => domainNameLength, ($v) => domainNameLength = $v, $.$spc.System.Int32)))
                {
                    end = ((start + domainNameLength) | 0);
                    $.$spu.System.Uri.CheckAuthorityHelperHandleDnsIri(pString, start, end, hasUnicode, flags, newHost, err);
                }
                else if ((syntaxFlags & 256/*UriSyntaxFlags.AllowUncHost*/) !== 0)
                {
                    if ($.$spu.System.UncNameHelper.IsValid(pString, start, $.$ref(() => end, ($v) => end = $v, $.$spc.System.Int32), $.$spu.System.Uri.StaticNotAny(flags.$v, 35184372088832n)))
                    {
                        if (((end - start) | 0) <= 256/*UncNameHelper.MaximumInternetNameLength*/)
                        {
                            flags.$v |= 17179869184n;
                            if (hasUnicode)
                            {
                                newHost.$v = $.$spc.System.String.Concat$10($.$spc.System.String.op_Implicit(newHost.$v), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(pString.Add(start), ((end - start) | 0)));
                            }
                        }
                    }
                }
                if (end < length && pString.GetAt(end) === /*\\*/ 92 && (flags.$v & 30064771072n) !== 0n && !$.$spu.System.Uri.StaticIsFile(syntax))
                {
                    if (syntax.InFact(65536/*UriSyntaxFlags.V1_UnknownUri*/))
                    {
                        err.$v = 8/*ParsingError.BadHostName*/;
                        flags.$v |= 30064771072n;
                        return end;
                    }
                    flags.$v &= ~30064771072n;
                }
                else if (end < length && pString.GetAt(end) === /*:*/ 58)
                {
                    if (syntax.InFact(8/*UriSyntaxFlags.MayHavePort*/))
                    {
                        /*int*/ let port = 0;
                        /*int*/ let startPort = end;
                        for(idx = ((end + 1) | 0); idx < length; ++idx)
                        {
                            /*int*/ let val = pString.GetAt(idx) - /*0*/ 48;
                            if ((val >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                            {
                                if ((port = (((((port * 10) | 0) + val) | 0))) > 65535)
                                {
                                    break;
                                }
                            }
                            else if (val === (/*/*/ 47 - /*0*/ 48) || val === (/*?*/ 63 - /*0*/ 48) || val === (/*#*/ 35 - /*0*/ 48))
                            {
                                break;
                            }
                            else 
                            {
                                if (syntax.InFact(4096/*UriSyntaxFlags.AllowAnyOtherHost*/) && syntax.NotAny(65536/*UriSyntaxFlags.V1_UnknownUri*/))
                                {
                                    flags.$v &= ~30064771072n;
                                    break;
                                }
                                else 
                                {
                                    err.$v = 10/*ParsingError.BadPort*/;
                                    return idx;
                                }
                            }
                        }
                        if (port > 65535)
                        {
                            if (syntax.InFact(4096/*UriSyntaxFlags.AllowAnyOtherHost*/))
                            {
                                flags.$v &= ~30064771072n;
                            }
                            else 
                            {
                                err.$v = 10/*ParsingError.BadPort*/;
                                return idx;
                            }
                        }
                        if (hasUnicode)
                        {
                            newHost.$v = $.$spc.System.String.Concat$10($.$spc.System.String.op_Implicit(newHost.$v), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(pString.Add(startPort), ((idx - startPort) | 0)));
                        }
                    }
                    else 
                    {
                        flags.$v &= ~30064771072n;
                    }
                }
                if ((flags.$v & 30064771072n) === 0n)
                {
                    flags.$v &= ~137438953472n;
                    if (syntax.InFact(4096/*UriSyntaxFlags.AllowAnyOtherHost*/))
                    {
                        flags.$v |= 21474836480n;
                        for(end = idx; end < length; ++end)
                        {
                            if (pString.GetAt(end) === /*/*/ 47 || (pString.GetAt(end) === /*?*/ 63 || pString.GetAt(end) === /*#*/ 35))
                            {
                                break;
                            }
                        }
                        if (hasUnicode)
                        {
                            try
                            {
                                newHost.$v = $.$spu.System.UriHelper.NormalizeAndConcat(newHost.$v, new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(pString.Add(startInput), ((end - startInput) | 0)));
                            }
                            catch($e)
                            {
                                err.$v = 8/*ParsingError.BadHostName*/;
                            }
                        }
                    }
                    else 
                    {
                        if (syntax.InFact(65536/*UriSyntaxFlags.V1_UnknownUri*/))
                        {
                            /*bool*/ let dotFound = false;
                            /*int*/ let startOtherHost = idx;
                            for(end = idx; end < length; ++end)
                            {
                                if (dotFound && (pString.GetAt(end) === /*/*/ 47 || pString.GetAt(end) === /*?*/ 63 || pString.GetAt(end) === /*#*/ 35))
                                {
                                    break;
                                }
                                else if (end < (((idx + 2) | 0)) && pString.GetAt(end) === /*.*/ 46)
                                {
                                    dotFound = true;
                                }
                                else 
                                {
                                    err.$v = 8/*ParsingError.BadHostName*/;
                                    flags.$v |= 30064771072n;
                                    return idx;
                                }
                            }
                            flags.$v |= 21474836480n;
                            if (hasUnicode)
                            {
                                try
                                {
                                    newHost.$v = $.$spu.System.UriHelper.NormalizeAndConcat(newHost.$v, new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(pString.Add(startOtherHost), ((end - startOtherHost) | 0)));
                                }
                                catch($e)
                                {
                                    err.$v = 1/*ParsingError.BadFormat*/;
                                    return idx;
                                }
                            }
                        }
                        else if (syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/) || (syntax.InFact(16384/*UriSyntaxFlags.MailToLikeUri*/)))
                        {
                            err.$v = 8/*ParsingError.BadHostName*/;
                            flags.$v |= 30064771072n;
                            return idx;
                        }
                    }
                }
                return end;
            }
            static /*void */ CheckAuthorityHelperHandleDnsIri(/*char**/ pString, /*int*/ start, /*int*/ end, /*bool*/ hasUnicode, /*ref Flags*/ flags, /*ref string?*/ newHost, /*ref ParsingError*/ err)
            {
                flags.$v |= 12884901888n;
                if (hasUnicode)
                {
                    /*ReadOnlySpan<char>*/ let host = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(pString.Add(start), ((end - start) | 0));
                    /*string?*/ let stripped;
                    if ($.$spu.System.UriHelper.StripBidiControlCharacters$1(host, $.$ref(() => stripped, ($v) => stripped = $v, $.$spc.System.String)))
                    {
                        host = $.$spc.System.String.op_Implicit(stripped);
                    }
                    try
                    {
                        newHost.$v = $.$spu.System.UriHelper.NormalizeAndConcat(newHost.$v, host);
                    }
                    catch($e)
                    {
                        err.$v = 8/*ParsingError.BadHostName*/;
                    }
                }
            }
            /*char*/ static c_DummyChar = /*\uFFFF*/ 65535;
            /*char*/ static c_EOL = /*\uFFFE*/ 65534;
            static $_Check;
            static get Check()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_Check ??= $asm.$nstr("$spu.System.Uri.Check", ($self) => class Check extends $.$spc.System.Enum
                {
                    static None = 0;
                    static EscapedCanonical = 1;
                    static DisplayCanonical = 2;
                    static DotSlashAttn = 4;
                    static DotSlashEscaped = 128;
                    static BackslashInPath = 16;
                    static ReservedFound = 32;
                    static NotIriCanonical = 64;
                    static FoundNonAscii = 8;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "EscapedCanonical": 1n,
                            "DisplayCanonical": 2n,
                            "DotSlashAttn": 4n,
                            "DotSlashEscaped": 128n,
                            "BackslashInPath": 16n,
                            "ReservedFound": 32n,
                            "NotIriCanonical": 64n,
                            "FoundNonAscii": 8n
                        };
                    }
                    static $h = 1808532;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1808532,"n":"None","d":1808532,"h":4296775828,"f":33},{"t":1808532,"n":"EscapedCanonical","d":1808532,"h":8591743124,"f":33},{"t":1808532,"n":"DisplayCanonical","d":1808532,"h":12886710420,"f":33},{"t":1808532,"n":"DotSlashAttn","d":1808532,"h":17181677716,"f":33},{"t":1808532,"n":"DotSlashEscaped","d":1808532,"h":21476645012,"f":33},{"t":1808532,"n":"BackslashInPath","d":1808532,"h":25771612308,"f":33},{"t":1808532,"n":"ReservedFound","d":1808532,"h":30066579604,"f":33},{"t":1808532,"n":"NotIriCanonical","d":1808532,"h":34361546900,"f":33},{"t":1808532,"n":"FoundNonAscii","d":1808532,"h":38656514196,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1808532,"h":42951481492,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":1742996,"h":1808532,"a":[{"t":47710209,"c":4342677505}]}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Uri.Check`; }
                }, $cls, ($v) => $cls.$_Check = $v);
            }
            /*Check */ CheckCanonical(/*char**/ str, /*ref int*/ idx, /*int*/ end, /*char*/ delim)
            {
                /*Check*/ let res = 0/*Check.None*/;
                /*bool*/ let needsEscaping = false;
                /*bool*/ let foundEscaping = false;
                /*bool*/ let iriParsing = this.IriParsing;
                /*char*/ let c;
                /*int*/ let i = idx.$v;
                for(; i < end; ++i)
                {
                    c = str.GetAt(i);
                    if (c <= /*\u001F*/ 31 || (c >= /*\u007F*/ 127 && c <= /*\u009F*/ 159))
                    {
                        needsEscaping = true;
                        foundEscaping = true;
                        res |= 32/*Check.ReservedFound*/;
                    }
                    else if (c > /*~*/ 126)
                    {
                        if (iriParsing)
                        {
                            /*bool*/ let valid = false;
                            res |= 8/*Check.FoundNonAscii*/;
                            if ($.$spc.System.Char.IsHighSurrogate(c))
                            {
                                if ((((i + 1) | 0)) < end)
                                {
                                    valid = $.$spu.System.IriHelper.CheckIriUnicodeRange$1(c, str.GetAt(((i + 1) | 0)), $.$discardRef(), true);
                                }
                            }
                            else 
                            {
                                valid = $.$spu.System.IriHelper.CheckIriUnicodeRange(c, true);
                            }
                            if (!valid)
                            {
                                res |= 64/*Check.NotIriCanonical*/;
                            }
                        }
                        if (!needsEscaping)
                        {
                            needsEscaping = true;
                        }
                    }
                    else if (c === delim)
                    {
                        break;
                    }
                    else if (delim === /*?*/ 63 && c === /*#*/ 35 && (this._syntax !== null && this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/)))
                    {
                        break;
                    }
                    else if (c === /*?*/ 63)
                    {
                        if (this.IsImplicitFile || (this._syntax !== null && !this._syntax.InFact(32/*UriSyntaxFlags.MayHaveQuery*/) && delim !== /*\uFFFE*/ 65534))
                        {
                            res |= 32/*Check.ReservedFound*/;
                            foundEscaping = true;
                            needsEscaping = true;
                        }
                    }
                    else if (c === /*#*/ 35)
                    {
                        needsEscaping = true;
                        if (this.IsImplicitFile || (this._syntax !== null && !this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/)))
                        {
                            res |= 32/*Check.ReservedFound*/;
                            foundEscaping = true;
                        }
                    }
                    else if (c === /*/*/ 47 || c === /*\\*/ 92)
                    {
                        if ((res & 16/*Check.BackslashInPath*/) === 0 && c === /*\\*/ 92)
                        {
                            res |= 16/*Check.BackslashInPath*/;
                        }
                        if ((res & 4/*Check.DotSlashAttn*/) === 0 && ((i + 1) | 0) !== end && (str.GetAt(((i + 1) | 0)) === /*/*/ 47 || str.GetAt(((i + 1) | 0)) === /*\\*/ 92))
                        {
                            res |= 4/*Check.DotSlashAttn*/;
                        }
                    }
                    else if (c === /*.*/ 46)
                    {
                        if ((res & 4/*Check.DotSlashAttn*/) === 0 && ((i + 1) | 0) === end || str.GetAt(((i + 1) | 0)) === /*.*/ 46 || str.GetAt(((i + 1) | 0)) === /*/*/ 47 || str.GetAt(((i + 1) | 0)) === /*\\*/ 92 || str.GetAt(((i + 1) | 0)) === /*?*/ 63 || str.GetAt(((i + 1) | 0)) === /*#*/ 35)
                        {
                            res |= 4/*Check.DotSlashAttn*/;
                        }
                    }
                    else if ((c <= /*\"*/ 34 && c !== /*!*/ 33) || (c >= /*[*/ 91 && c <= /*^*/ 94) || c === /*>*/ 62 || c === /*<*/ 60 || c === /*`*/ 96)
                    {
                        if (!needsEscaping)
                        {
                            needsEscaping = true;
                        }
                        if ((this._flags & 562949953421312n) !== 0n)
                        {
                            res |= 64/*Check.NotIriCanonical*/;
                        }
                    }
                    else if (c >= /*{*/ 123 && c <= /*}*/ 125)
                    {
                        needsEscaping = true;
                    }
                    else if (c === /*%*/ 37)
                    {
                        if (!foundEscaping)
                        {
                            foundEscaping = true;
                        }
                        if (((i + 2) | 0) < end && (c = $.$spu.System.UriHelper.DecodeHexChars(str.GetAt(((i + 1) | 0)), str.GetAt(((i + 2) | 0)))) !== /*\uFFFF*/ 65535)
                        {
                            if (c === /*.*/ 46 || c === /*/*/ 47 || c === /*\\*/ 92)
                            {
                                res |= 128/*Check.DotSlashEscaped*/;
                            }
                            i += 2;
                            continue;
                        }
                        if (!needsEscaping)
                        {
                            needsEscaping = true;
                        }
                    }
                }
                if (foundEscaping)
                {
                    if (!needsEscaping)
                    {
                        res |= 1/*Check.EscapedCanonical*/;
                    }
                }
                else 
                {
                    res |= 2/*Check.DisplayCanonical*/;
                    if (!needsEscaping)
                    {
                        res |= 1/*Check.EscapedCanonical*/;
                    }
                }
                idx.$v = i;
                return res;
            }
            /*void */ GetCanonicalPath(/*ref ValueStringBuilder*/ dest, /*UriFormat*/ formatAs)
            {
                if (this.InFact(16384n))
                {
                    dest.$v.Append$1(/*/*/ 47);
                }
                if (this._info.Offset.Path === this._info.Offset.Query)
                {
                    return;
                }
                /*int*/ let start = dest.$v.Length;
                /*int*/ let dosPathIdx = this.SecuredPathIndex;
                if (formatAs === 1/*UriFormat.UriEscaped*/)
                {
                    if (this.InFact(8192n))
                    {
                        dest.$v.Append$4($.$spc.System.MemoryExtensions.AsSpan$7(this._string, this._info.Offset.Path, ((this._info.Offset.Query - this._info.Offset.Path) | 0)));
                        if (this._syntax.InFact(33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/) && this.InFact(16n) && !this.IsImplicitFile)
                        {
                            /*fixed*/ 
                            {
                                /*char**/ let pdest = dest.$v.GetPinnableReference();
                                /*int*/ let end = dest.$v.Length;
                                $.$spu.System.Uri.UnescapeOnly(pdest, start, $.$ref(() => end, ($v) => end = $v, $.$spc.System.Int32), /*.*/ 46, /*/*/ 47, this._syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/) ? /*\\*/ 92 : /*\uFFFF*/ 65535);
                                dest.$v.Length = end;
                            }
                        }
                    }
                    else 
                    {
                        if (this.InFact(1024n) && this.NotAny(34359738368n))
                        {
                            /*ReadOnlySpan<char>*/ let str = $.$spc.System.String.op_Implicit(this._string);
                            if (dosPathIdx !== 0 && str.get_Item(((((dosPathIdx + this._info.Offset.Path) | 0) - 1) | 0)).$v === /*|*/ 124)
                            {
                                /*char[]*/ let chars = str.ToArray();
                                $.$spc.System.Array.$WriteT1.call(chars, /*:*/ 58, ((((dosPathIdx + this._info.Offset.Path) | 0) - 1) | 0));
                                str = $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).op_Implicit(chars);
                            }
                            $.$spu.System.UriHelper.EscapeString$2(str.Slice$1(this._info.Offset.Path, ((this._info.Offset.Query - this._info.Offset.Path) | 0)), dest, !this.IsImplicitFile, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
                        }
                        else 
                        {
                            dest.$v.Append$4($.$spc.System.MemoryExtensions.AsSpan$7(this._string, this._info.Offset.Path, ((this._info.Offset.Query - this._info.Offset.Path) | 0)));
                        }
                    }
                    if (!$.$spc.System.OperatingSystem.IsWindows() && this.InFact(32768n) && this._syntax.NotAny(4194304/*UriSyntaxFlags.ConvertPathSlashes*/) && this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/) && !this.IsImplicitFile)
                    {
                        /*var*/ let copy = new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*StackallocThreshold*/, null));
                        copy.Append$4(dest.$v.AsSpan$3(start, ((dest.$v.Length - start) | 0)));
                        dest.$v.Length = start;
                        $.$spu.System.UriHelper.EscapeString$2(copy.AsSpan$1(), dest, true, $.$spu.System.UriHelper.UnreservedReserved);
                        start = dest.$v.Length;
                        copy.Dispose();
                    }
                }
                else 
                {
                    dest.$v.Append$4($.$spc.System.MemoryExtensions.AsSpan$7(this._string, this._info.Offset.Path, ((this._info.Offset.Query - this._info.Offset.Path) | 0)));
                    if (this.InFact(8192n))
                    {
                        if (this._syntax.InFact(33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/) && this.InFact(16n) && !this.IsImplicitFile)
                        {
                            /*fixed*/ 
                            {
                                /*char**/ let pdest = dest.$v.GetPinnableReference();
                                /*int*/ let end = dest.$v.Length;
                                $.$spu.System.Uri.UnescapeOnly(pdest, start, $.$ref(() => end, ($v) => end = $v, $.$spc.System.Int32), /*.*/ 46, /*/*/ 47, this._syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/) ? /*\\*/ 92 : /*\uFFFF*/ 65535);
                                dest.$v.Length = end;
                            }
                        }
                    }
                }
                /*int*/ let offset = ((start + dosPathIdx) | 0);
                if (dosPathIdx !== 0 && dest.$v.get_Item(((offset - 1) | 0)).$v === /*|*/ 124)
                {
                    dest.$v.get_Item(((offset - 1) | 0)).$v = /*:*/ 58;
                }
                if (this.InFact(8192n) && ((dest.$v.Length - offset) | 0) > 0)
                {
                    dest.$v.Length = ((offset + $.$spu.System.UriHelper.Compress(dest.$v.RawChars.Slice$1(offset, ((dest.$v.Length - offset) | 0)), this._syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/), this._syntax.InFact(16777216/*UriSyntaxFlags.CanonicalizeAsFilePath*/))) | 0);
                    if (dest.$v.get_Item(start).$v === /*\\*/ 92)
                    {
                        dest.$v.get_Item(start).$v = /*/*/ 47;
                    }
                    if (formatAs === 1/*UriFormat.UriEscaped*/ && this.NotAny(34359738368n) && this.InFact(1024n))
                    {
                        /*var*/ let copy = new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*StackallocThreshold*/, null));
                        copy.Append$4(dest.$v.AsSpan$3(start, ((dest.$v.Length - start) | 0)));
                        dest.$v.Length = start;
                        $.$spu.System.UriHelper.EscapeString$2(copy.AsSpan$1(), dest, !this.IsImplicitFile, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
                        start = dest.$v.Length;
                        copy.Dispose();
                    }
                }
                if (formatAs !== 1/*UriFormat.UriEscaped*/ && this.InFact(16n))
                {
                    /*UnescapeMode*/ let mode;
                    switch(formatAs)
                    {
                        case 32767/*V1ToStringUnescape*/:
                        mode = (this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/) | 4/*UnescapeMode.V1ToStringFlag*/;
                        if (this.IsImplicitFile)
                        {
                            mode &= ~2/*UnescapeMode.Unescape*/;
                        }
                        break;
                        case 2/*UriFormat.Unescaped*/:
                        mode = this.IsImplicitFile ? 0/*UnescapeMode.CopyOnly*/ : 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/;
                        break;
                        default:
                        mode = this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/;
                        if (this.IsImplicitFile)
                        {
                            mode &= ~2/*UnescapeMode.Unescape*/;
                        }
                        break;
                    }
                    if (mode !== 0/*UnescapeMode.CopyOnly*/)
                    {
                        /*var*/ let copy = new $.$spu.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512/*StackallocThreshold*/, null));
                        copy.Append$4(dest.$v.AsSpan$3(start, ((dest.$v.Length - start) | 0)));
                        dest.$v.Length = start;
                        /*fixed*/ 
                        {
                            /*char**/ let pCopy = copy.GetPinnableReference();
                            $.$spu.System.UriHelper.UnescapeString$4(pCopy, 0, copy.Length, dest, /*?*/ 63, /*#*/ 35, /*\uFFFF*/ 65535, mode, this._syntax, false);
                        }
                        copy.Dispose();
                    }
                }
            }
            static /*void */ UnescapeOnly(/*char**/ pch, /*int*/ start, /*ref int*/ end, /*char*/ ch1, /*char*/ ch2, /*char*/ ch3)
            {
                /*char**/ let pend;
                /*char**/ let pnew;
                /*char*/ let ch;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            if (((end.$v - start) | 0) < 3)
                            {
                                return;
                            }
                            pend = pch.Add(end.$v).Add(-2);
                            pch = pch.Add(start);
                            pnew = null;
                        }
                        case 1: /*over*/
                        if ($.$spc.NetJs.RefOrPointer.Compare(pch, pend) >= 0)
                        {
                            $gotoJumpState1 = 3; /*goto done*/
                            continue $gotoJumpStart1;
                        }
                        if ((() =>
                        {
                            var $oldp = pch.Clone();
                            pch = pch.Add(1);
                            return $oldp;
                        })().$v !== /*%*/ 37)
                        {
                            $gotoJumpState1 = 1; /*goto over*/
                            continue $gotoJumpStart1;
                        }
                        ch = $.$spu.System.UriHelper.DecodeHexChars((() =>
                        {
                            var $oldp = pch.Clone();
                            pch = pch.Add(1);
                            return $oldp;
                        })().$v, (() =>
                        {
                            var $oldp = pch.Clone();
                            pch = pch.Add(1);
                            return $oldp;
                        })().$v);
                        if (!(ch === ch1 || ch === ch2 || ch === ch3))
                        {
                            $gotoJumpState1 = 1; /*goto over*/
                            continue $gotoJumpStart1;
                        }
                        pnew = pch.Add(-2);
                        (pnew.Add(-1)).$v = ch;
                        case 2: /*over_new*/
                        if ($.$spc.NetJs.RefOrPointer.Compare(pch, pend) >= 0)
                        {
                            $gotoJumpState1 = 3; /*goto done*/
                            continue $gotoJumpStart1;
                        }
                        if (((() =>
                        {
                            var $oldp = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $oldp;
                        })().$v = (() =>
                        {
                            var $oldp = pch.Clone();
                            pch = pch.Add(1);
                            return $oldp;
                        })().$v) !== /*%*/ 37)
                        {
                            $gotoJumpState1 = 2; /*goto over_new*/
                            continue $gotoJumpStart1;
                        }
                        ch = $.$spu.System.UriHelper.DecodeHexChars(((() =>
                        {
                            var $oldp = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $oldp;
                        })().$v = (() =>
                        {
                            var $oldp = pch.Clone();
                            pch = pch.Add(1);
                            return $oldp;
                        })().$v), ((() =>
                        {
                            var $oldp = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $oldp;
                        })().$v = (() =>
                        {
                            var $oldp = pch.Clone();
                            pch = pch.Add(1);
                            return $oldp;
                        })().$v));
                        if (!(ch === ch1 || ch === ch2 || ch === ch3))
                        {
                            $gotoJumpState1 = 2; /*goto over_new*/
                            continue $gotoJumpStart1;
                        }
                        pnew = pnew.Add(-2);
                        (pnew.Add(-1)).$v = ch;
                        $gotoJumpState1 = 2; /*goto over_new*/
                        continue $gotoJumpStart1;
                        case 3: /*done*/
                        pend = pend.Add(2);
                        if (pnew === null)
                        {
                            return;
                        }
                        if ($.$spc.NetJs.RefOrPointer.Compare(pch, pend) == 0)
                        {
                            end.$v -= $.$cast((pch.Subtract(pnew)), $.$spc.System.Int32);
                            return;
                        }
                        (() =>
                        {
                            var $oldp = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $oldp;
                        })().$v = (() =>
                        {
                            var $oldp = pch.Clone();
                            pch = pch.Add(1);
                            return $oldp;
                        })().$v;
                        if ($.$spc.NetJs.RefOrPointer.Compare(pch, pend) == 0)
                        {
                            end.$v -= $.$cast((pch.Subtract(pnew)), $.$spc.System.Int32);
                            return;
                        }
                        (() =>
                        {
                            var $oldp = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $oldp;
                        })().$v = (() =>
                        {
                            var $oldp = pch.Clone();
                            pch = pch.Add(1);
                            return $oldp;
                        })().$v;
                        end.$v -= $.$cast((pch.Subtract(pnew)), $.$spc.System.Int32);
                    }
                    break;
                }
            }
            static /*void */ Compress(/*char[]*/ dest, /*int*/ start, /*ref int*/ destLength, /*UriParser*/ syntax)
            {
                destLength.$v = ((start + $.$spu.System.UriHelper.Compress($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Char, dest, start, ((destLength.$v - start) | 0)), syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/), syntax.InFact(16777216/*UriSyntaxFlags.CanonicalizeAsFilePath*/))) | 0);
            }
            static /*string */ CombineUri(/*Uri*/ basePart, /*string*/ relativePart, /*UriFormat*/ uriFormat)
            {
                /*char*/ let c1 = $.$spc.System.String.get_Chars.call(relativePart, 0);
                if (basePart.IsDosPath && (c1 === /*/*/ 47 || c1 === /*\\*/ 92) && (relativePart.length === 1 || ($.$spc.System.String.get_Chars.call(relativePart, 1) !== /*/*/ 47 && $.$spc.System.String.get_Chars.call(relativePart, 1) !== /*\\*/ 92)))
                {
                    /*int*/ let idx = $.$spc.System.String.IndexOf.call(basePart.OriginalString, /*:*/ 58);
                    if (basePart.IsImplicitFile)
                    {
                        return $.$spc.System.String.Concat$10($.$spc.System.MemoryExtensions.AsSpan$7(basePart.OriginalString, 0, ((idx + 1) | 0)), $.$spc.System.String.op_Implicit(relativePart));
                    }
                    idx = $.$spc.System.String.IndexOf$1.call(basePart.OriginalString, /*:*/ 58, ((idx + 1) | 0));
                    return $.$spc.System.String.Concat$10($.$spc.System.MemoryExtensions.AsSpan$7(basePart.OriginalString, 0, ((idx + 1) | 0)), $.$spc.System.String.op_Implicit(relativePart));
                }
                if ($.$spu.System.Uri.StaticIsFile(basePart.Syntax))
                {
                    if (c1 === /*\\*/ 92 || c1 === /*/*/ 47)
                    {
                        if (relativePart.length >= 2 && ($.$spc.System.String.get_Chars.call(relativePart, 1) === /*\\*/ 92 || $.$spc.System.String.get_Chars.call(relativePart, 1) === /*/*/ 47))
                        {
                            return basePart.IsImplicitFile ? relativePart : "file:" + relativePart;
                        }
                        if (basePart.IsUnc)
                        {
                            /*ReadOnlySpan<char>*/ let share = $.$spc.System.String.op_Implicit(basePart.GetParts(16/*UriComponents.Path*/ | 1073741824/*UriComponents.KeepDelimiter*/, 2/*UriFormat.Unescaped*/));
                            /*int*/ let i = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, share.Slice(1), /*/*/ 47);
                            if (i >= 0)
                            {
                                share = share.Slice$1(0, ((i + 1) | 0));
                            }
                            if (basePart.IsImplicitFile)
                            {
                                return $.$spc.System.String.Concat$12($.$spc.System.String.op_Implicit("\\\\"), $.$spc.System.String.op_Implicit(basePart.GetParts(4/*UriComponents.Host*/, 2/*UriFormat.Unescaped*/)), share, $.$spc.System.String.op_Implicit(relativePart));
                            }
                            return $.$spc.System.String.Concat$12($.$spc.System.String.op_Implicit("file://"), $.$spc.System.String.op_Implicit(basePart.GetParts(4/*UriComponents.Host*/, uriFormat)), share, $.$spc.System.String.op_Implicit(relativePart));
                        }
                        return "file://" + relativePart;
                    }
                }
                /*bool*/ let convBackSlashes = basePart.Syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/);
                /*string?*/ let left;
                if (c1 === /*/*/ 47 || (c1 === /*\\*/ 92 && convBackSlashes))
                {
                    if (relativePart.length >= 2 && $.$spc.System.String.get_Chars.call(relativePart, 1) === /*/*/ 47)
                    {
                        return basePart.Scheme + /*:*/ 58 + relativePart;
                    }
                    if (basePart.HostType === 4294967296n)
                    {
                        left = `${basePart.GetParts(1/*UriComponents.Scheme*/ | 2/*UriComponents.UserInfo*/, uriFormat)}[${basePart.DnsSafeHost}]${basePart.GetParts(1073741824/*UriComponents.KeepDelimiter*/ | 8/*UriComponents.Port*/, uriFormat)}`;
                    }
                    else 
                    {
                        left = basePart.GetParts(13/*UriComponents.SchemeAndServer*/ | 2/*UriComponents.UserInfo*/, uriFormat);
                    }
                    return convBackSlashes && c1 === /*\\*/ 92 ? $.$spc.System.String.Concat$11($.$spc.System.String.op_Implicit(left), $.$spc.System.String.op_Implicit("/"), $.$spc.System.MemoryExtensions.AsSpan$4(relativePart, 1)) : left + relativePart;
                }
                left = basePart.GetParts(16/*UriComponents.Path*/ | 1073741824/*UriComponents.KeepDelimiter*/, basePart.IsImplicitFile ? 2/*UriFormat.Unescaped*/ : uriFormat);
                /*int*/ let length = left.length;
                /*char[]*/ let path = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), null, [((length + relativePart.length) | 0)], null);
                if (length > 0)
                {
                    $.$spc.System.String.CopyTo.call(left, 0, path, 0, length);
                    while(length > 0)
                    {
                        if ($.$spc.System.Array.$ReadT1.call(path, --length) === /*/*/ 47)
                        {
                            ++length;
                            break;
                        }
                    }
                }
                $.$spc.System.String.CopyTo.call(relativePart, 0, path, length, relativePart.length);
                c1 = basePart.Syntax.InFact(32/*UriSyntaxFlags.MayHaveQuery*/) ? /*?*/ 63 : /*\uFFFF*/ 65535;
                /*char*/ let c2 = (!basePart.IsImplicitFile && basePart.Syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/)) ? /*#*/ 35 : /*\uFFFF*/ 65535;
                /*ReadOnlySpan<char>*/ let extra = $.$spc.System.String.op_Implicit($.$spc.System.String.Empty);
                if (!(c1 === /*\uFFFF*/ 65535 && c2 === /*\uFFFF*/ 65535))
                {
                    /*int*/ let i = 0;
                    for(; i < relativePart.length; ++i)
                    {
                        if ($.$spc.System.Array.$ReadT1.call(path, ((length + i) | 0)) === c1 || $.$spc.System.Array.$ReadT1.call(path, ((length + i) | 0)) === c2)
                        {
                            break;
                        }
                    }
                    if (i === 0)
                    {
                        extra = $.$spc.System.String.op_Implicit(relativePart);
                    }
                    else if (i < relativePart.length)
                    {
                        extra = $.$spc.System.MemoryExtensions.AsSpan$4(relativePart, i);
                    }
                    length += i;
                }
                else 
                {
                    length += relativePart.length;
                }
                if (basePart.HostType === 4294967296n)
                {
                    if (basePart.IsImplicitFile)
                    {
                        left = "\\\\[" + basePart.DnsSafeHost + /*]*/ 93;
                    }
                    else 
                    {
                        left = basePart.GetParts(1/*UriComponents.Scheme*/ | 2/*UriComponents.UserInfo*/, uriFormat) + /*[*/ 91 + basePart.DnsSafeHost + /*]*/ 93 + basePart.GetParts(1073741824/*UriComponents.KeepDelimiter*/ | 8/*UriComponents.Port*/, uriFormat);
                    }
                }
                else 
                {
                    if (basePart.IsImplicitFile)
                    {
                        if (basePart.IsDosPath)
                        {
                            $.$spu.System.Uri.Compress(path, 3, $.$ref(() => length, ($v) => length = $v, $.$spc.System.Int32), basePart.Syntax);
                            return $.$spc.System.String.Concat$10($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Char, path, 1, ((length - 1) | 0))), extra);
                        }
                        else if (!$.$spc.System.OperatingSystem.IsWindows() && basePart.IsUnixPath)
                        {
                            left = basePart.GetParts(4/*UriComponents.Host*/, 2/*UriFormat.Unescaped*/);
                        }
                        else 
                        {
                            left = "\\\\" + basePart.GetParts(4/*UriComponents.Host*/, 2/*UriFormat.Unescaped*/);
                        }
                    }
                    else 
                    {
                        left = basePart.GetParts(13/*UriComponents.SchemeAndServer*/ | 2/*UriComponents.UserInfo*/, uriFormat);
                    }
                }
                $.$spu.System.Uri.Compress(path, basePart.SecuredPathIndex, $.$ref(() => length, ($v) => length = $v, $.$spc.System.Int32), basePart.Syntax);
                return $.$spc.System.String.Concat$11($.$spc.System.String.op_Implicit(left), $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Char, path, 0, length)), extra);
            }
            static /*string */ PathDifference(/*string*/ path1, /*string*/ path2, /*bool*/ compareCase)
            {
                /*int*/ let i;
                /*int*/ let si = -1;
                for(i = 0; (i < path1.length) && (i < path2.length); ++i)
                {
                    if (($.$spc.System.String.get_Chars.call(path1, i) !== $.$spc.System.String.get_Chars.call(path2, i)) && (compareCase || ($.$spc.System.Char.ToLowerInvariant($.$spc.System.String.get_Chars.call(path1, i)) !== $.$spc.System.Char.ToLowerInvariant($.$spc.System.String.get_Chars.call(path2, i)))))
                    {
                        break;
                    }
                    else if ($.$spc.System.String.get_Chars.call(path1, i) === /*/*/ 47)
                    {
                        si = i;
                    }
                }
                if (i === 0)
                {
                    return path2;
                }
                if ((i === path1.length) && (i === path2.length))
                {
                    return $.$spc.System.String.Empty;
                }
                /*StringBuilder*/ let relPath = new $.$spc.System.Text.StringBuilder().$ctor$1();
                for(; i < path1.length; ++i)
                {
                    if ($.$spc.System.String.get_Chars.call(path1, i) === /*/*/ 47)
                    {
                        relPath.Append$2("../");
                    }
                }
                if (relPath.Length === 0 && ((path2.length - 1) | 0) === si)
                {
                    return "./";
                }
                return $.$spc.System.Text.StringBuilder.ToString.call(relPath.Append$21($.$spc.System.MemoryExtensions.AsSpan$4(path2, ((si + 1) | 0))));
            }
            /*string */ MakeRelative(/*Uri*/ toUri)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(toUri, "toUri");
                if (this.IsNotAbsoluteUri || toUri.IsNotAbsoluteUri)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (($.$spc.System.String.op_Equality(this.Scheme, toUri.Scheme)) && ($.$spc.System.String.op_Equality(this.Host, toUri.Host)) && (this.Port === toUri.Port))
                {
                    return $.$spu.System.Uri.PathDifference(this.AbsolutePath, toUri.AbsolutePath, !this.IsUncOrDosPath);
                }
                return $.$spu.System.Uri.ToString.call(toUri);
            }
            /*void */ Canonicalize()
            {
            }
            /*void */ Parse()
            {
            }
            /*void */ Escape()
            {
            }
            /*string */ Unescape(/*string*/ path)
            {
                /*char[]*/ let dest = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), null, [path.length], null);
                /*int*/ let count = 0;
                dest = $.$spu.System.UriHelper.UnescapeString(path, 0, path.length, dest, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, null, false);
                return $.$spc.System.String.Create$1(dest, 0, count);
            }
            static /*string */ EscapeString(/*string?*/ str)
            {
                return str === null ? $.$spc.System.String.Empty : $.$spu.System.UriHelper.EscapeString(str, true, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
            }
            /*void */ CheckSecurity()
            {
            }
            /*bool */ IsReservedCharacter(/*char*/ character)
            {
                return (character === /*;*/ 59) || (character === /*/*/ 47) || (character === /*:*/ 58) || (character === /*@*/ 64) || (character === /*&*/ 38) || (character === /*=*/ 61) || (character === /*+*/ 43) || (character === /*$*/ 36) || (character === /*,*/ 44);
            }
            static /*bool */ IsExcludedCharacter(/*char*/ character)
            {
                return (character <= 32) || (character >= 127) || (character === /*<*/ 60) || (character === /*>*/ 62) || (character === /*#*/ 35) || (character === /*%*/ 37) || (character === /*\"*/ 34) || (character === /*{*/ 123) || (character === /*}*/ 125) || (character === /*|*/ 124) || (character === /*\\*/ 92) || (character === /*^*/ 94) || (character === /*[*/ 91) || (character === /*]*/ 93) || (character === /*`*/ 96);
            }
            /*bool */ IsBadFileSystemCharacter(/*char*/ character)
            {
                return (character < 32) || (character === /*;*/ 59) || (character === /*/*/ 47) || (character === /*?*/ 63) || (character === /*:*/ 58) || (character === /*&*/ 38) || (character === /*=*/ 61) || (character === /*,*/ 44) || (character === /***/ 42) || (character === /*<*/ 60) || (character === /*>*/ 62) || (character === /*\"*/ 34) || (character === /*|*/ 124) || (character === /*\\*/ 92) || (character === /*^*/ 94);
            }
            /*bool */ get HasAuthority()
            {
                return this.InFact(68719476736n);
            }
            //Generated interface implemetation for System.IEquatable<System.Uri>.Equals(System.Uri?)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._originalUnicodeString = null;
                this._syntax = null;
                this._info = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_asciiOtherThanPercent = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\u0008\t\n\u000B\u000C\r\u000E\u000F" + "\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001A\u001B\u001C\u001D\u001E\u001F" + " !\"#$" + "&'()*+,-./" + "0123456789:;<=>?" + "@ABCDEFGHIJKLMNO" + "PQRSTUVWXYZ[\\]^_" + "`abcdefghijklmno" + "pqrstuvwxyz{|}~\u007F"));
                }
                {
                    this.UriSchemeFile = $.$spu.System.UriParser.FileUri.SchemeName;
                }
                {
                    this.UriSchemeFtp = $.$spu.System.UriParser.FtpUri.SchemeName;
                }
                {
                    this.UriSchemeSftp = "sftp";
                }
                {
                    this.UriSchemeFtps = "ftps";
                }
                {
                    this.UriSchemeGopher = $.$spu.System.UriParser.GopherUri.SchemeName;
                }
                {
                    this.UriSchemeHttp = $.$spu.System.UriParser.HttpUri.SchemeName;
                }
                {
                    this.UriSchemeHttps = $.$spu.System.UriParser.HttpsUri.SchemeName;
                }
                {
                    this.UriSchemeWs = $.$spu.System.UriParser.WsUri.SchemeName;
                }
                {
                    this.UriSchemeWss = $.$spu.System.UriParser.WssUri.SchemeName;
                }
                {
                    this.UriSchemeMailto = $.$spu.System.UriParser.MailToUri.SchemeName;
                }
                {
                    this.UriSchemeNews = $.$spu.System.UriParser.NewsUri.SchemeName;
                }
                {
                    this.UriSchemeNntp = $.$spu.System.UriParser.NntpUri.SchemeName;
                }
                {
                    this.UriSchemeSsh = "ssh";
                }
                {
                    this.UriSchemeTelnet = $.$spu.System.UriParser.TelnetUri.SchemeName;
                }
                {
                    this.UriSchemeNetTcp = $.$spu.System.UriParser.NetTcpUri.SchemeName;
                }
                {
                    this.UriSchemeNetPipe = $.$spu.System.UriParser.NetPipeUri.SchemeName;
                }
                {
                    this.SchemeDelimiter = "://";
                }
                {
                    this.s_schemeChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("+-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"));
                }
                {
                    this.s_segmentSeparatorChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit(":\\/?#"));
                }
            }
            static $h = 1742996;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":279174617236,"f":2},"n":"IsImplicitFile","d":1742996,"h":274879649940,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":287764551828,"f":2},"n":"IsUncOrDosPath","d":1742996,"h":283469584532,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":296354486420,"f":2},"n":"IsDosPath","d":1742996,"h":292059519124,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":304944421012,"f":2},"n":"IsUncPath","d":1742996,"h":300649453716,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":313534355604,"f":2},"n":"IsUnixPath","d":1742996,"h":309239388308,"f":2},{"p":1874068,"g":{"r":0,"d":0,"h":322124290196,"f":2},"n":"HostType","d":1742996,"h":317829322900,"f":2},{"p":2660500,"g":{"r":0,"d":0,"h":330714224788,"f":2},"n":"Syntax","d":1742996,"h":326419257492,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":339304159380,"f":2},"n":"IsNotAbsoluteUri","d":1742996,"h":335009192084,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":347894093972,"f":2},"n":"IriParsing","d":1742996,"h":343599126676,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":360778995860,"f":8},"n":"DisablePathAndQueryCanonicalization","d":1742996,"h":356484028564,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":369368930452,"f":8},"n":"UserDrivenParsing","d":1742996,"h":365073963156,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":377958865044,"f":2},"n":"SecuredPathIndex","d":1742996,"h":373663897748,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":472448145556,"f":1},"n":"AbsolutePath","d":1742996,"h":468153178260,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":481038080148,"f":2},"n":"PrivateAbsolutePath","d":1742996,"h":476743112852,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":489628014740,"f":1},"n":"AbsoluteUri","d":1742996,"h":485333047444,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":498217949332,"f":1},"n":"LocalPath","d":1742996,"h":493922982036,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":506807883924,"f":1},"n":"Authority","d":1742996,"h":502512916628,"f":1},{"p":2529428,"g":{"r":0,"d":0,"h":515397818516,"f":1},"n":"HostNameType","d":1742996,"h":511102851220,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":523987753108,"f":1},"n":"IsDefaultPort","d":1742996,"h":519692785812,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":532577687700,"f":1},"n":"IsFile","d":1742996,"h":528282720404,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":541167622292,"f":1},"n":"IsLoopback","d":1742996,"h":536872654996,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":549757556884,"f":1},"n":"PathAndQuery","d":1742996,"h":545462589588,"f":1},{"p":0,"g":{"r":0,"d":0,"h":558347491476,"f":1},"n":"Segments","d":1742996,"h":554052524180,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":566937426068,"f":1},"n":"IsUnc","d":1742996,"h":562642458772,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":575527360660,"f":1},"n":"Host","d":1742996,"h":571232393364,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":592707229844,"f":1},"n":"Port","d":1742996,"h":588412262548,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":601297164436,"f":1},"n":"Query","d":1742996,"h":597002197140,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":609887099028,"f":1},"n":"Fragment","d":1742996,"h":605592131732,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":618477033620,"f":1},"n":"Scheme","d":1742996,"h":614182066324,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":627066968212,"f":1},"n":"OriginalString","d":1742996,"h":622772000916,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":635656902804,"f":1},"n":"DnsSafeHost","d":1742996,"h":631361935508,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":644246837396,"f":1},"n":"IdnHost","d":1742996,"h":639951870100,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":652836771988,"f":1},"n":"IsAbsoluteUri","d":1742996,"h":648541804692,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":661426706580,"f":1},"n":"UserEscaped","d":1742996,"h":657131739284,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":670016641172,"f":1},"n":"UserInfo","d":1742996,"h":665721673876,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":944894548116,"f":8},"n":"HasAuthority","d":1742996,"h":940599580820,"f":8}],"m":[{"r":65537,"p":[{"n":"uri","p":1310721},{"n":"dontEscape","p":262145},{"n":"uriKind","p":2594964},{"n":"creationOptions","p":2267284,"f":73}],"n":"CreateThis","d":1742996,"h":4296710292,"f":2},{"r":65537,"p":[{"n":"err","p":1349780},{"n":"uriKind","p":2594964},{"n":"e","p":2398356,"f":2}],"n":"InitializeUri","d":1742996,"h":8591677588,"f":2},{"r":262145,"p":[{"n":"data","p":1310721}],"n":"CheckForUnicodeOrEscapedUnreserved","d":1742996,"h":17181612180,"f":34},{"r":262145,"p":[{"n":"uriString","p":1310721},{"n":"uriKind","p":2594964},{"n":"result","p":1742996,"f":2}],"n":"TryCreate","d":1742996,"h":21476579476,"f":33},{"r":262145,"p":[{"n":"uriString","p":1310721},{"n":"creationOptions","p":2267284,"f":8},{"n":"result","p":1742996,"f":2}],"n":"TryCreate","o":"@$1","d":1742996,"h":25771546772,"f":33},{"r":262145,"p":[{"n":"baseUri","p":1742996},{"n":"relativeUri","p":1310721},{"n":"result","p":1742996,"f":2}],"n":"TryCreate","o":"@$2","d":1742996,"h":30066514068,"f":33},{"r":262145,"p":[{"n":"baseUri","p":1742996},{"n":"relativeUri","p":1742996},{"n":"result","p":1742996,"f":2}],"n":"TryCreate","o":"@$3","d":1742996,"h":34361481364,"f":33},{"r":1310721,"p":[{"n":"components","p":2201748},{"n":"format","p":2332820}],"n":"GetComponents","d":1742996,"h":38656448660,"f":1},{"r":1310721,"p":[{"n":"components","p":2201748},{"n":"format","p":2332820}],"n":"InternalGetComponents","d":1742996,"h":42951415956,"f":2},{"r":655361,"p":[{"n":"uri1","p":1742996},{"n":"uri2","p":1742996},{"n":"partsToCompare","p":2201748},{"n":"compareFormat","p":2332820},{"n":"comparisonType","p":119472129}],"n":"Compare","d":1742996,"h":47246383252,"f":33},{"r":262145,"n":"IsWellFormedOriginalString","d":1742996,"h":51541350548,"f":1},{"r":262145,"p":[{"n":"uriString","p":1310721},{"n":"uriKind","p":2594964}],"n":"IsWellFormedUriString","d":1742996,"h":55836317844,"f":33},{"r":262145,"n":"InternalIsWellFormedOriginalString","d":1742996,"h":60131285140,"f":8},{"r":1310721,"p":[{"n":"stringToUnescape","p":1310721}],"n":"UnescapeDataString","d":1742996,"h":64426252436,"f":33},{"r":1310721,"p":[{"n":"charsToUnescape","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"UnescapeDataString","o":"@$1","d":1742996,"h":68721219732,"f":33},{"r":1310721,"p":[{"n":"charsToUnescape","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"backingString","p":1310721,"f":65}],"n":"UnescapeDataString","o":"@$2","d":1742996,"h":73016187028,"f":34},{"r":262145,"p":[{"n":"charsToUnescape","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryUnescapeDataString","d":1742996,"h":77311154324,"f":33},{"r":1310721,"p":[{"n":"stringToEscape","p":1310721}],"n":"EscapeUriString","d":1742996,"h":81606121620,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0013","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"r":1310721,"p":[{"n":"stringToEscape","p":1310721}],"n":"EscapeDataString","d":1742996,"h":85901088916,"f":33},{"r":1310721,"p":[{"n":"charsToEscape","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"EscapeDataString","o":"@$1","d":1742996,"h":90196056212,"f":33},{"r":262145,"p":[{"n":"charsToEscape","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryEscapeDataString","d":1742996,"h":94491023508,"f":33},{"r":1310721,"p":[{"n":"input","p":1310721},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"component","p":2201748}],"n":"EscapeUnescapeIri","d":1742996,"h":98785990804,"f":8},{"r":1742996,"p":[{"n":"uriString","p":1310721},{"n":"dontEscape","p":262145},{"n":"uriKind","p":2594964},{"n":"e","p":2398356,"f":4},{"n":"creationOptions","p":2267284,"f":73}],"n":"CreateHelper","d":1742996,"h":107375925396,"f":40},{"r":1742996,"p":[{"n":"baseUri","p":1742996},{"n":"relativeUri","p":1742996},{"n":"newUriString","p":1310721,"f":4},{"n":"userEscaped","p":262145,"f":4}],"n":"ResolveHelper","d":1742996,"h":111670892692,"f":40},{"r":1310721,"p":[{"n":"format","p":2332820}],"n":"GetRelativeSerializationString","d":1742996,"h":115965859988,"f":2},{"r":1310721,"p":[{"n":"uriComponents","p":2201748},{"n":"uriFormat","p":2332820}],"n":"GetComponentsHelper","d":1742996,"h":120260827284,"f":8},{"r":262145,"p":[{"n":"uri","p":1742996}],"n":"IsBaseOf","d":1742996,"h":124555794580,"f":1},{"r":262145,"p":[{"n":"uriLink","p":1742996}],"n":"IsBaseOfHelper","d":1742996,"h":128850761876,"f":8},{"r":65537,"p":[{"n":"otherUri","p":1742996}],"n":"CreateThisFromUri","d":1742996,"h":133145729172,"f":2},{"r":65537,"n":"DebugSetLeftCtor","d":1742996,"h":244814878868,"f":2,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"n":"AssertInvariants","d":1742996,"h":249109846164,"f":2,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"n":"DebugAssertInCtor","d":1742996,"h":253404813460,"f":8,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"flags","p":1874068}],"n":"InterlockedSetFlags","d":1742996,"h":270584682644,"f":2},{"r":262145,"p":[{"n":"syntax","p":2660500}],"n":"IriParsingStatic","d":1742996,"h":352189061268,"f":40},{"r":262145,"p":[{"n":"flags","p":1874068}],"n":"NotAny","d":1742996,"h":382253832340,"f":2},{"r":262145,"p":[{"n":"flags","p":1874068}],"n":"InFact","d":1742996,"h":386548799636,"f":2},{"r":262145,"p":[{"n":"allFlags","p":1874068},{"n":"checkFlags","p":1874068}],"n":"StaticNotAny","d":1742996,"h":390843766932,"f":34},{"r":262145,"p":[{"n":"allFlags","p":1874068},{"n":"checkFlags","p":1874068}],"n":"StaticInFact","d":1742996,"h":395138734228,"f":34},{"r":2070676,"n":"EnsureUriInfo","d":1742996,"h":399433701524,"f":2},{"r":65537,"n":"EnsureParseRemaining","d":1742996,"h":403728668820,"f":2},{"r":65537,"p":[{"n":"allowDnsOptimization","p":262145}],"n":"EnsureHostString","d":1742996,"h":408023636116,"f":2},{"r":65537,"p":[{"n":"serializationInfo","p":113967105},{"n":"streamingContext","p":114098177}],"n":"GetObjectData","d":1742996,"h":446678341780,"f":4},{"r":65537,"p":[{"n":"baseUri","p":1742996},{"n":"relativeUri","p":1310721},{"n":"dontEscape","p":262145}],"n":"CreateUri","d":1742996,"h":450973309076,"f":2},{"r":65537,"p":[{"n":"baseUri","p":1742996},{"n":"relativeStr","p":1310721},{"n":"dontEscape","p":262145},{"n":"result","p":1310721,"f":4}],"n":"GetCombinedString","d":1742996,"h":459563243668,"f":34},{"r":2398356,"p":[{"n":"err","p":1349780}],"n":"GetException","d":1742996,"h":463858210964,"f":34},{"r":262145,"p":[{"n":"syntax","p":2660500}],"n":"StaticIsFile","d":1742996,"h":579822327956,"f":34},{"r":1310721,"n":"GetLocalPath","d":1742996,"h":584117295252,"f":2},{"r":2529428,"p":[{"n":"name","p":1310721}],"n":"CheckHostName","d":1742996,"h":674311608468,"f":33},{"r":1310721,"p":[{"n":"part","p":2791572}],"n":"GetLeftPart","d":1742996,"h":678606575764,"f":1},{"r":1310721,"p":[{"n":"character","p":458753}],"n":"HexEscape","d":1742996,"h":682901543060,"f":33},{"r":458753,"p":[{"n":"pattern","p":1310721},{"n":"index","p":655361,"f":4}],"n":"HexUnescape","d":1742996,"h":687196510356,"f":33},{"r":262145,"p":[{"n":"pattern","p":1310721},{"n":"index","p":655361}],"n":"IsHexEncoding","d":1742996,"h":691491477652,"f":33},{"r":262145,"p":[{"n":"schemeName","p":1310721}],"n":"CheckSchemeName","d":1742996,"h":700081412244,"f":33},{"r":262145,"p":[{"n":"character","p":458753}],"n":"IsHexDigit","d":1742996,"h":704376379540,"f":33},{"r":655361,"p":[{"n":"digit","p":458753}],"n":"FromHex","d":1742996,"h":708671346836,"f":33},{"r":655361,"n":"GetHashCode","d":1742996,"h":712966314132,"f":32769},{"r":1310721,"n":"ToString","d":1742996,"h":721556248724,"f":32769},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryFormat","d":1742996,"h":725851216020,"f":1},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":1742996,"h":747326052500,"f":32769},{"r":262145,"p":[{"n":"other","p":1742996}],"n":"Equals","o":"@$2","d":1742996,"h":751621019796,"f":1},{"r":1742996,"p":[{"n":"uri","p":1742996}],"n":"MakeRelativeUri","d":1742996,"h":755915987092,"f":1},{"r":262145,"p":[{"n":"uriString","p":1310721}],"n":"CheckForColonInFirstPathSegment","d":1742996,"h":764505921684,"f":34},{"r":1310721,"p":[{"n":"rawString","p":1310721}],"n":"InternalEscapeString","d":1742996,"h":768800888980,"f":40},{"r":1349780,"p":[{"n":"uriString","p":1310721},{"n":"flags","p":1874068,"f":4},{"n":"syntax","p":2660500,"f":4}],"n":"ParseScheme","d":1742996,"h":773095856276,"f":34},{"r":2398356,"n":"ParseMinimal","d":1742996,"h":777390823572,"f":8},{"r":1349780,"n":"PrivateParseMinimal","d":1742996,"h":781685790868,"f":2},{"r":65537,"p":[{"n":"cF","p":1874068}],"n":"CreateUriInfo","d":1742996,"h":785980758164,"f":2},{"r":65537,"n":"CreateHostString","d":1742996,"h":790275725460,"f":2},{"r":1310721,"p":[{"n":"str","p":1310721},{"n":"idx","p":655361},{"n":"end","p":655361},{"n":"flags","p":1874068,"f":4},{"n":"info","p":2070676}],"n":"CreateHostStringHelper","d":1742996,"h":794570692756,"f":34},{"r":65537,"n":"GetHostViaCustomSyntax","d":1742996,"h":798865660052,"f":2},{"r":1310721,"p":[{"n":"uriParts","p":2201748},{"n":"formatAs","p":2332820}],"n":"GetParts","d":1742996,"h":803160627348,"f":8},{"r":1310721,"p":[{"n":"uriParts","p":2201748}],"n":"GetEscapedParts","d":1742996,"h":807455594644,"f":2},{"r":1310721,"p":[{"n":"uriParts","p":2201748},{"n":"formatAs","p":2332820}],"n":"GetUnescapedParts","d":1742996,"h":811750561940,"f":2},{"r":1310721,"p":[{"n":"parts","p":2201748},{"n":"nonCanonical","p":589825},{"n":"formatAs","p":2332820}],"n":"RecreateParts","d":1742996,"h":816045529236,"f":2},{"r":262145,"p":[{"n":"span","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2},{"n":"parts","p":2201748},{"n":"nonCanonical","p":589825},{"n":"formatAs","p":2332820}],"n":"TryRecreateParts","d":1742996,"h":820340496532,"f":2},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"dest","p":1546388,"f":4},{"n":"str","p":1310721},{"n":"parts","p":2201748},{"n":"nonCanonical","p":589825},{"n":"formatAs","p":2332820}],"n":"RecreateParts","o":"@$1","d":1742996,"h":824635463828,"f":2},{"r":1310721,"p":[{"n":"uriParts","p":2201748}],"n":"GetUriPartsFromUserString","d":1742996,"h":828930431124,"f":2},{"r":65537,"p":[{"n":"str","p":1310721},{"n":"length","p":655361,"f":4},{"n":"idx","p":655361}],"n":"GetLengthWithoutTrailingSpaces","d":1742996,"h":833225398420,"f":34},{"r":65537,"n":"ParseRemaining","d":1742996,"h":837520365716,"f":2},{"r":655361,"p":[{"n":"uriString","p":1310721},{"n":"err","p":1349780,"f":4},{"n":"flags","p":1874068,"f":4},{"n":"syntax","p":2660500,"f":4}],"n":"ParseSchemeCheckImplicitFile","d":1742996,"h":841815333012,"f":34},{"r":2660500,"p":[{"n":"scheme","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"error","p":1349780,"f":4}],"n":"CheckSchemeSyntax","d":1742996,"h":846110300308,"f":34},{"r":655361,"p":[{"n":"pString","p":0},{"n":"idx","p":655361},{"n":"length","p":655361},{"n":"err","p":1349780,"f":4},{"n":"flags","p":1874068,"f":4},{"n":"syntax","p":2660500},{"n":"newHost","p":1310721,"f":4}],"n":"CheckAuthorityHelper","d":1742996,"h":850405267604,"f":2},{"r":65537,"p":[{"n":"pString","p":0},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"hasUnicode","p":262145},{"n":"flags","p":1874068,"f":4},{"n":"newHost","p":1310721,"f":4},{"n":"err","p":1349780,"f":4}],"n":"CheckAuthorityHelperHandleDnsIri","d":1742996,"h":854700234900,"f":34},{"r":1808532,"p":[{"n":"str","p":0},{"n":"idx","p":655361,"f":4},{"n":"end","p":655361},{"n":"delim","p":458753}],"n":"CheckCanonical","d":1742996,"h":871880104084,"f":2},{"r":65537,"p":[{"n":"dest","p":1546388,"f":4},{"n":"formatAs","p":2332820}],"n":"GetCanonicalPath","d":1742996,"h":876175071380,"f":2},{"r":65537,"p":[{"n":"pch","p":0},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"ch1","p":458753},{"n":"ch2","p":458753},{"n":"ch3","p":458753}],"n":"UnescapeOnly","d":1742996,"h":880470038676,"f":34},{"r":65537,"p":[{"n":"dest","p":0},{"n":"start","p":655361},{"n":"destLength","p":655361,"f":4},{"n":"syntax","p":2660500}],"n":"Compress","d":1742996,"h":884765005972,"f":34},{"r":1310721,"p":[{"n":"basePart","p":1742996},{"n":"relativePart","p":1310721},{"n":"uriFormat","p":2332820}],"n":"CombineUri","d":1742996,"h":889059973268,"f":34},{"r":1310721,"p":[{"n":"path1","p":1310721},{"n":"path2","p":1310721},{"n":"compareCase","p":262145}],"n":"PathDifference","d":1742996,"h":893354940564,"f":34},{"r":1310721,"p":[{"n":"toUri","p":1742996}],"n":"MakeRelative","d":1742996,"h":897649907860,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.MakeRelative has been deprecated. Use MakeRelativeUri(Uri uri) instead.","t":1310721}]}]},{"r":65537,"n":"Canonicalize","d":1742996,"h":901944875156,"f":132,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.Canonicalize has been deprecated and is not supported.","t":1310721}]}]},{"r":65537,"n":"Parse","d":1742996,"h":906239842452,"f":132,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.Parse has been deprecated and is not supported.","t":1310721}]}]},{"r":65537,"n":"Escape","d":1742996,"h":910534809748,"f":132,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.Escape has been deprecated and is not supported.","t":1310721}]}]},{"r":1310721,"p":[{"n":"path","p":1310721}],"n":"Unescape","d":1742996,"h":914829777044,"f":132,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.Unescape has been deprecated. Use GetComponents() or Uri.UnescapeDataString() to unescape a Uri component or a string.","t":1310721}]}]},{"r":1310721,"p":[{"n":"str","p":1310721}],"n":"EscapeString","d":1742996,"h":919124744340,"f":36,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.EscapeString has been deprecated. Use GetComponents() or Uri.EscapeDataString to escape a Uri component or a string.","t":1310721}]}]},{"r":65537,"n":"CheckSecurity","d":1742996,"h":923419711636,"f":132,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.CheckSecurity has been deprecated and is not supported.","t":1310721}]}]},{"r":262145,"p":[{"n":"character","p":458753}],"n":"IsReservedCharacter","d":1742996,"h":927714678932,"f":132,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.IsReservedCharacter has been deprecated and is not supported.","t":1310721}]}]},{"r":262145,"p":[{"n":"character","p":458753}],"n":"IsExcludedCharacter","d":1742996,"h":932009646228,"f":36,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.IsExcludedCharacter has been deprecated and is not supported.","t":1310721}]}]},{"r":262145,"p":[{"n":"character","p":458753}],"n":"IsBadFileSystemCharacter","d":1742996,"h":936304613524,"f":132,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.IsBadFileSystemCharacter has been deprecated and is not supported.","t":1310721}]}]}],"l":[{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"s_asciiOtherThanPercent","d":1742996,"h":12886644884,"f":34},{"t":1310721,"n":"UriSchemeFile","d":1742996,"h":137440696468,"f":33},{"t":1310721,"n":"UriSchemeFtp","d":1742996,"h":141735663764,"f":33},{"t":1310721,"n":"UriSchemeSftp","d":1742996,"h":146030631060,"f":33},{"t":1310721,"n":"UriSchemeFtps","d":1742996,"h":150325598356,"f":33},{"t":1310721,"n":"UriSchemeGopher","d":1742996,"h":154620565652,"f":33},{"t":1310721,"n":"UriSchemeHttp","d":1742996,"h":158915532948,"f":33},{"t":1310721,"n":"UriSchemeHttps","d":1742996,"h":163210500244,"f":33},{"t":1310721,"n":"UriSchemeWs","d":1742996,"h":167505467540,"f":33},{"t":1310721,"n":"UriSchemeWss","d":1742996,"h":171800434836,"f":33},{"t":1310721,"n":"UriSchemeMailto","d":1742996,"h":176095402132,"f":33},{"t":1310721,"n":"UriSchemeNews","d":1742996,"h":180390369428,"f":33},{"t":1310721,"n":"UriSchemeNntp","d":1742996,"h":184685336724,"f":33},{"t":1310721,"n":"UriSchemeSsh","d":1742996,"h":188980304020,"f":33},{"t":1310721,"n":"UriSchemeTelnet","d":1742996,"h":193275271316,"f":33},{"t":1310721,"n":"UriSchemeNetTcp","d":1742996,"h":197570238612,"f":33},{"t":1310721,"n":"UriSchemeNetPipe","d":1742996,"h":201865205908,"f":33},{"t":1310721,"n":"SchemeDelimiter","d":1742996,"h":206160173204,"f":33},{"t":655361,"n":"SchemeLengthLimit","d":1742996,"h":210455140500,"f":34},{"t":655361,"n":"StackallocThreshold","d":1742996,"h":214750107796,"f":40},{"t":1310721,"n":"_string","d":1742996,"h":219045075092,"f":2},{"t":1310721,"n":"_originalUnicodeString","d":1742996,"h":223340042388,"f":2},{"t":2660500,"n":"_syntax","d":1742996,"h":227635009684,"f":8},{"t":1874068,"n":"_flags","d":1742996,"h":231929976980,"f":8},{"t":2070676,"n":"_info","d":1742996,"h":236224944276,"f":2},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"s_schemeChars","d":1742996,"h":695786444948,"f":34},{"t":2332820,"n":"V1ToStringUnescape","d":1742996,"h":717261281428,"f":34},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"s_segmentSeparatorChars","d":1742996,"h":760210954388,"f":34},{"t":458753,"n":"c_DummyChar","d":1742996,"h":858995202196,"f":40},{"t":458753,"n":"c_EOL","d":1742996,"h":863290169492,"f":40}],"c":[{"p":[{"n":"flags","p":1874068},{"n":"uriParser","p":2660500},{"n":"uri","p":1310721}],"n":".ctor","o":"$ctor$1","d":1742996,"h":103080958100,"f":2},{"p":[{"n":"uriString","p":1310721}],"n":".ctor","o":"$ctor$2","d":1742996,"h":412318603412,"f":1},{"p":[{"n":"uriString","p":1310721},{"n":"dontEscape","p":262145}],"n":".ctor","o":"$ctor$3","d":1742996,"h":416613570708,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor has been deprecated; the dontEscape parameter is always false. Use Uri(string) instead.","t":1310721}]}]},{"p":[{"n":"baseUri","p":1742996},{"n":"relativeUri","p":1310721},{"n":"dontEscape","p":262145}],"n":".ctor","o":"$ctor$4","d":1742996,"h":420908538004,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor has been deprecated; the dontEscape parameter is always false. Use Uri(Uri, string) instead.","t":1310721}]}]},{"p":[{"n":"uriString","p":1310721},{"n":"uriKind","p":2594964}],"n":".ctor","o":"$ctor$5","d":1742996,"h":425203505300,"f":1},{"p":[{"n":"uriString","p":1310721},{"n":"creationOptions","p":2267284,"f":8}],"n":".ctor","o":"$ctor$6","d":1742996,"h":429498472596,"f":1},{"p":[{"n":"baseUri","p":1742996},{"n":"relativeUri","p":1310721}],"n":".ctor","o":"$ctor$7","d":1742996,"h":433793439892,"f":1},{"p":[{"n":"serializationInfo","p":113967105},{"n":"streamingContext","p":114098177}],"n":".ctor","o":"$ctor$8","d":1742996,"h":438088407188,"f":4,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"p":[{"n":"baseUri","p":1742996},{"n":"relativeUri","p":1742996}],"n":".ctor","o":"$ctor$9","d":1742996,"h":455268276372,"f":1}],"i":[63832065,57737217,$.$spc.System.IEquatable$$($.$spu.System.Uri).$h,113377281],"j":[1874068,2070676,2005140,1939604,1808532],"h":1742996,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IEquatable$$($.$spu.System.Uri), $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Uri`; }
        });
        
        $asm.$cls("$spu.System.HttpStyleUriParser", ($self) => class HttpStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.HttpUri.Flags);
                {
                }
                return this;
            }
            static $h = 759956;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2660500,"c":[{"n":".ctor","o":"$ctor$3","d":759956,"h":4295727252,"f":1}],"h":759956}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.HttpStyleUriParser`; }
        });
        
        $asm.$str("$spu.System.UriCreationOptions", ($self) => class UriCreationOptions extends $.$spc.System.ValueType
        {
            /*bool*/  get _disablePathAndQueryCanonicalization() { return this.$getField(0, 1); }
            /*bool*/  set _disablePathAndQueryCanonicalization(value) { this.$setField(0, 1, value); }
            /*bool */ get DangerousDisablePathAndQueryCanonicalization()
            {
                return this._disablePathAndQueryCanonicalization;
            }
            /*bool */ set DangerousDisablePathAndQueryCanonicalization(value)
            {
                this._disablePathAndQueryCanonicalization = value;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._disablePathAndQueryCanonicalization = this._disablePathAndQueryCanonicalization;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._disablePathAndQueryCanonicalization = false;
            }
            static $h = 2267284;
            static $z = 1;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12887169172,"f":1},"s":{"r":0,"d":0,"h":17182136468,"f":1},"n":"DangerousDisablePathAndQueryCanonicalization","d":2267284,"h":8592201876,"f":1}],"l":[{"t":262145,"n":"_disablePathAndQueryCanonicalization","d":2267284,"h":4297234580,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":2267284,"h":21477103764,"f":1}],"h":2267284}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.UriCreationOptions`; }
        });
        
        $asm.$cls("$spu.System.FtpStyleUriParser", ($self) => class FtpStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.FtpUri.Flags);
                {
                }
                return this;
            }
            static $h = 301204;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2660500,"c":[{"n":".ctor","o":"$ctor$3","d":301204,"h":4295268500,"f":1}],"h":301204}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.FtpStyleUriParser`; }
        });
        
        $asm.$cls("$spu.System.GenericUriParser", ($self) => class GenericUriParser extends $.$spu.System.UriParser
        {
            $ctor$3(/*GenericUriParserOptions*/ options)
            {
                super.$ctor$2($.$spu.System.GenericUriParser.MapGenericParserOptions(options));
                {
                }
                return this;
            }
            static /*UriSyntaxFlags */ MapGenericParserOptions(/*GenericUriParserOptions*/ options)
            {
                /*UriSyntaxFlags*/ let flags = 65015677/*DefaultGenericUriParserFlags*/;
                if ((options & 1/*GenericUriParserOptions.GenericAuthority*/) !== 0)
                {
                    flags &= ~(4/*UriSyntaxFlags.MayHaveUserInfo*/ | 8/*UriSyntaxFlags.MayHavePort*/ | 256/*UriSyntaxFlags.AllowUncHost*/ | 3584/*UriSyntaxFlags.AllowAnInternetHost*/);
                    flags |= 4096/*UriSyntaxFlags.AllowAnyOtherHost*/;
                }
                if ((options & 2/*GenericUriParserOptions.AllowEmptyAuthority*/) !== 0)
                {
                    flags |= 128/*UriSyntaxFlags.AllowEmptyHost*/;
                }
                if ((options & 4/*GenericUriParserOptions.NoUserInfo*/) !== 0)
                {
                    flags &= ~4/*UriSyntaxFlags.MayHaveUserInfo*/;
                }
                if ((options & 8/*GenericUriParserOptions.NoPort*/) !== 0)
                {
                    flags &= ~8/*UriSyntaxFlags.MayHavePort*/;
                }
                if ((options & 16/*GenericUriParserOptions.NoQuery*/) !== 0)
                {
                    flags &= ~32/*UriSyntaxFlags.MayHaveQuery*/;
                }
                if ((options & 32/*GenericUriParserOptions.NoFragment*/) !== 0)
                {
                    flags &= ~64/*UriSyntaxFlags.MayHaveFragment*/;
                }
                if ((options & 64/*GenericUriParserOptions.DontConvertPathBackslashes*/) !== 0)
                {
                    flags &= ~4194304/*UriSyntaxFlags.ConvertPathSlashes*/;
                }
                if ((options & 128/*GenericUriParserOptions.DontCompressPath*/) !== 0)
                {
                    flags &= ~(8388608/*UriSyntaxFlags.CompressPath*/ | 16777216/*UriSyntaxFlags.CanonicalizeAsFilePath*/);
                }
                if ((options & 256/*GenericUriParserOptions.DontUnescapePathDotsAndSlashes*/) !== 0)
                {
                    flags &= ~33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/;
                }
                if ((options & 512/*GenericUriParserOptions.Idn*/) !== 0)
                {
                    flags |= 67108864/*UriSyntaxFlags.AllowIdn*/;
                }
                if ((options & 1024/*GenericUriParserOptions.IriParsing*/) !== 0)
                {
                    flags |= 268435456/*UriSyntaxFlags.AllowIriParsing*/;
                }
                return flags;
            }
            /*UriSyntaxFlags*/ static DefaultGenericUriParserFlags = 65015677;
            static $h = 366740;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2660500,"m":[{"r":2857108,"p":[{"n":"options","p":432276}],"n":"MapGenericParserOptions","d":366740,"h":8590301332,"f":34}],"l":[{"t":2857108,"n":"DefaultGenericUriParserFlags","d":366740,"h":12885268628,"f":34}],"c":[{"p":[{"n":"options","p":432276}],"n":".ctor","o":"$ctor$3","d":366740,"h":4295334036,"f":1}],"h":366740}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.GenericUriParser`; }
        });
        
        $asm.$cls("$spu.System.FileStyleUriParser", ($self) => class FileStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.FileUri.Flags);
                {
                }
                return this;
            }
            static $h = 235668;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2660500,"c":[{"n":".ctor","o":"$ctor$3","d":235668,"h":4295202964,"f":1}],"h":235668}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.FileStyleUriParser`; }
        });
        
        $asm.$str("$spu.System.Text.ValueStringBuilder", ($self) => class ValueStringBuilder extends $.$spc.System.ValueType
        {
            /*void */ Append(/*Rune*/ rune)
            {
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if (((((pos + 1) | 0)) >>> 0) < (chars.Length >>> 0) && (pos >>> 0) < (chars.Length >>> 0))
                {
                    if (rune.Value <= 65535)
                    {
                        chars.get_Item(pos).$v = $.$cast(rune.Value, $.$spc.System.Char);
                        this._pos = ((pos + 1) | 0);
                    }
                    else 
                    {
                        chars.get_Item(pos).$v = $.$cast(((BigInt(rune.Value) + (BigInt(((((55296 - 64) >>> 0)) << 10) >>> 0))) >> 10n), $.$spc.System.Char);
                        chars.get_Item(((pos + 1) | 0)).$v = $.$cast(((BigInt(rune.Value) & 1023n) + 56320n), $.$spc.System.Char);
                        this._pos = ((pos + 2) | 0);
                    }
                }
                else 
                {
                    this.GrowAndAppend(rune);
                }
            }
            /*void */ GrowAndAppend(/*Rune*/ rune)
            {
                if (rune.Value <= 65535)
                {
                    this.Append$1($.$cast(rune.Value, $.$spc.System.Char));
                }
                else 
                {
                    this.Grow(2);
                    this.Append(rune);
                }
            }
            /*char[]?*/  get _arrayToReturnToPool() { return this.$getField(0, 4); }
            /*char[]?*/  set _arrayToReturnToPool(value) { this.$setField(0, 4, value); }
            /*Span<char>*/  get _chars() { return this.$getField(4, 6); }
            /*Span<char>*/  set _chars(value) { this.$setField(4, 6, value); }
            /*int*/  get _pos() { return this.$getField(10, 4); }
            /*int*/  set _pos(value) { this.$setField(10, 4, value); }
            $ctor$2(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            /*int */ get Length()
            {
                return this._pos;
            }
            /*int */ set Length(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value >= 0, "value >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            /*ref char */ GetPinnableReference()
            {
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, this._chars);
            }
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, this._chars);
            }
            /*ref char*/ get_Item(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string*/ let s = $.$spc.System.Span$$($.$spc.System.Char).ToString.call(this._chars.Slice$1(0, this._pos));
                this.Dispose();
                return s;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spu.System.Text.ValueStringBuilder.ToString.apply(this, arguments); }
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            /*ReadOnlySpan<char> */ AsSpan(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$1()
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start)
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(start, ((this._pos - start) | 0)));
            }
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start, /*int*/ length)
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(start, length));
            }
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                if (this._chars.Slice$1(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice$1(index, remaining).CopyTo(this._chars.Slice(((index + count) | 0)));
                this._chars.Slice$1(index, count).Fill(value);
                this._pos += count;
            }
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice$1(index, remaining).CopyTo(this._chars.Slice(((index + count) | 0)));
                $.$spc.System.String.CopyTo$1.call(s, this._chars.Slice(index));
                this._pos += count;
            }
            /*void */ Append$1(/*char*/ c)
            {
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars.get_Item(pos).$v = c;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend$1(c);
                }
            }
            /*void */ Append$2(/*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars.get_Item(pos).$v = $.$spc.System.String.get_Chars.call(s, 0);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            /*void */ AppendSlow(/*string*/ s)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$spc.System.String.CopyTo$1.call(s, this._chars.Slice(pos));
                this._pos += s.length;
            }
            /*void */ Append$3(/*char*/ c, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice$1(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst.get_Item(i).$v = c;
                }
                this._pos += count;
            }
            /*void */ Append$4(/*scoped ReadOnlySpan<char>*/ value)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice(this._pos));
                this._pos += value.Length;
            }
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice$1(origPos, length);
            }
            /*void */ GrowAndAppend$1(/*char*/ c)
            {
                this.Grow(1);
                this.Append$1(c);
            }
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$spc.System.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$spc.System.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(newCapacity);
                this._chars.Slice$1(0, this._pos).CopyTo($.$spc.System.Span$$($.$spc.System.Char).op_Implicit(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(toReturn, false);
                }
            }
            /*void */ Dispose()
            {
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$spu.System.Text.ValueStringBuilder().Clone(this);
                if (toReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(toReturn, false);
                }
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.Clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._arrayToReturnToPool = null;
                this._chars = $.$default($.$spc.System.Span$$($.$spc.System.Char));
                this._pos = 0;
            }
            static $h = 1546388;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":38656252052,"f":1},"s":{"r":0,"d":0,"h":42951219348,"f":1},"n":"Length","d":1546388,"h":34361284756,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51541153940,"f":1},"n":"Capacity","d":1546388,"h":47246186644,"f":1},{"p":458753,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":73015990420,"f":1},"n":"Item","o":"@$2","d":1546388,"h":68721023124,"f":1},{"p":$.$spc.System.Span$$($.$spc.System.Char).$h,"g":{"r":0,"d":0,"h":85900892308,"f":1},"n":"RawChars","d":1546388,"h":81605925012,"f":1}],"m":[{"r":65537,"p":[{"n":"rune","p":122748929}],"n":"Append","d":1546388,"h":4296513684,"f":1},{"r":65537,"p":[{"n":"rune","p":122748929}],"n":"GrowAndAppend","d":1546388,"h":8591480980,"f":2},{"r":65537,"p":[{"n":"capacity","p":655361}],"n":"EnsureCapacity","d":1546388,"h":55836121236,"f":1},{"r":458753,"n":"GetPinnableReference","d":1546388,"h":60131088532,"f":1},{"r":458753,"p":[{"n":"terminate","p":262145}],"n":"GetPinnableReference","o":"@$1","d":1546388,"h":64426055828,"f":1},{"r":1310721,"n":"ToString","d":1546388,"h":77310957716,"f":32769},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"terminate","p":262145}],"n":"AsSpan","d":1546388,"h":90195859604,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"n":"AsSpan","o":"@$1","d":1546388,"h":94490826900,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"start","p":655361}],"n":"AsSpan","o":"@$2","d":1546388,"h":98785794196,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"start","p":655361},{"n":"length","p":655361}],"n":"AsSpan","o":"@$3","d":1546388,"h":103080761492,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryCopyTo","d":1546388,"h":107375728788,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":458753},{"n":"count","p":655361}],"n":"Insert","d":1546388,"h":111670696084,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"s","p":1310721}],"n":"Insert","o":"@$1","d":1546388,"h":115965663380,"f":1},{"r":65537,"p":[{"n":"c","p":458753}],"n":"Append","o":"@$1","d":1546388,"h":120260630676,"f":1},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"Append","o":"@$2","d":1546388,"h":124555597972,"f":1},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AppendSlow","d":1546388,"h":128850565268,"f":2},{"r":65537,"p":[{"n":"c","p":458753},{"n":"count","p":655361}],"n":"Append","o":"@$3","d":1546388,"h":133145532564,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Append","o":"@$4","d":1546388,"h":137440499860,"f":1},{"r":$.$spc.System.Span$$($.$spc.System.Char).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpan","d":1546388,"h":141735467156,"f":1},{"r":65537,"p":[{"n":"c","p":458753}],"n":"GrowAndAppend","o":"@$1","d":1546388,"h":146030434452,"f":2},{"r":65537,"p":[{"n":"additionalCapacityBeyondPos","p":655361}],"n":"Grow","d":1546388,"h":150325401748,"f":2},{"r":65537,"n":"Dispose","d":1546388,"h":154620369044,"f":1}],"l":[{"t":0,"n":"_arrayToReturnToPool","d":1546388,"h":12886448276,"f":2},{"t":$.$spc.System.Span$$($.$spc.System.Char).$h,"n":"_chars","d":1546388,"h":17181415572,"f":2},{"t":655361,"n":"_pos","d":1546388,"h":21476382868,"f":2}],"c":[{"p":[{"n":"initialBuffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h}],"n":".ctor","o":"$ctor$2","d":1546388,"h":25771350164,"f":1},{"p":[{"n":"initialCapacity","p":655361}],"n":".ctor","o":"$ctor$3","d":1546388,"h":30066317460,"f":1},{"n":".ctor","o":"$ctor$4","d":1546388,"h":158915336340,"f":1}],"h":1546388}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Text.ValueStringBuilder`; }
        });
        
        $asm.$cls("$spu.System.NewsStyleUriParser", ($self) => class NewsStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.NewsUri.Flags);
                {
                }
                return this;
            }
            static $h = 1218708;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2660500,"c":[{"n":".ctor","o":"$ctor$3","d":1218708,"h":4296186004,"f":1}],"h":1218708}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.NewsStyleUriParser`; }
        });
        
        $asm.$str("$spu.System.Collections.Generic.ValueListBuilder<>", (T) => $asm.$gt("$spu.System.Collections.Generic.ValueListBuilder<>", [T], ($self) => class ValueListBuilder$$ extends $.$spc.System.ValueType
        {
            /*Span<T>*/  get _span() { return this.$getField(0, 8); }
            /*Span<T>*/  set _span(value) { this.$setField(0, 8, value); }
            /*T[]?*/  get _arrayFromPool() { return this.$getField(8, 4); }
            /*T[]?*/  set _arrayFromPool(value) { this.$setField(8, 4, value); }
            /*int*/  get _pos() { return this.$getField(12, 4); }
            /*int*/  set _pos(value) { this.$setField(12, 4, value); }
            $ctor$2(/*Span<T?>*/ scratchBuffer)
            {
                super.$ctor$1();
                {
                    this._span = scratchBuffer;
                }
                return this;
            }
            $ctor$3(/*int*/ capacity)
            {
                super.$ctor$1();
                {
                    this.Grow(capacity);
                }
                return this;
            }
            /*int */ get Length()
            {
                return this._pos;
            }
            /*int */ set Length(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value >= 0, "value >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(value <= this._span.Length, "value <= _span.Length");
                this._pos = value;
            }
            /*ref T*/ get_Item(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index < this._pos, "index < _pos");
                return this._span.get_Item(index);
            }
            /*void */ Append(/*T*/ item)
            {
                /*int*/ let pos = this._pos;
                /*Span<T>*/ let span = this._span;
                if ((pos >>> 0) < (span.Length >>> 0))
                {
                    span.get_Item(pos).$v = item;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AddWithResize(item);
                }
            }
            /*void */ Append$1(/*scoped ReadOnlySpan<T>*/ source)
            {
                /*int*/ let pos = this._pos;
                /*Span<T>*/ let span = this._span;
                if (source.Length === 1 && (pos >>> 0) < (span.Length >>> 0))
                {
                    span.get_Item(pos).$v = source.get_Item(0).$v;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendMultiChar(source);
                }
            }
            /*void */ AppendMultiChar(/*scoped ReadOnlySpan<T>*/ source)
            {
                if (((((this._pos + source.Length) | 0)) >>> 0) > (this._span.Length >>> 0))
                {
                    this.Grow(((((this._span.Length - this._pos) | 0) + source.Length) | 0));
                }
                source.CopyTo(this._span.Slice(this._pos));
                this._pos += source.Length;
            }
            /*void */ Insert(/*int*/ index, /*scoped ReadOnlySpan<T>*/ source)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index === 0, "Implementation currently only supports index == 0");
                if (((((this._pos + source.Length) | 0)) >>> 0) > (this._span.Length >>> 0))
                {
                    this.Grow(source.Length);
                }
                this._span.Slice$1(0, this._pos).CopyTo(this._span.Slice(source.Length));
                source.CopyTo(this._span);
                this._pos += source.Length;
            }
            /*Span<T> */ AppendSpan(/*int*/ length)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 0, "length >= 0");
                /*int*/ let pos = this._pos;
                /*Span<T>*/ let span = this._span;
                if ($.$cast((pos >>> 0), $.$spc.System.UInt64) + $.$cast((length >>> 0), $.$spc.System.UInt64) <= $.$cast((span.Length >>> 0), $.$spc.System.UInt64))
                {
                    this._pos = ((pos + length) | 0);
                    return span.Slice$1(pos, length);
                }
                else 
                {
                    return this.AppendSpanWithGrow(length);
                }
            }
            /*Span<T> */ AppendSpanWithGrow(/*int*/ length)
            {
                /*int*/ let pos = this._pos;
                this.Grow(((((this._span.Length - pos) | 0) + length) | 0));
                this._pos += length;
                return this._span.Slice$1(pos, length);
            }
            /*void */ AddWithResize(/*T*/ item)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._pos === this._span.Length, "_pos == _span.Length");
                /*int*/ let pos = this._pos;
                this.Grow(1);
                this._span.get_Item(pos).$v = item;
                this._pos = ((pos + 1) | 0);
            }
            /*ReadOnlySpan<T> */ AsSpan()
            {
                return $.$spc.System.Span$$(T).op_Implicit$2(this._span.Slice$1(0, this._pos));
            }
            /*bool */ TryCopyTo(/*Span<T>*/ destination, /*out int*/ itemsWritten)
            {
                if (this._span.Slice$1(0, this._pos).TryCopyTo(destination))
                {
                    itemsWritten.$v = this._pos;
                    return true;
                }
                itemsWritten.$v = 0;
                return false;
            }
            /*void */ Dispose()
            {
                /*T[]?*/ let toReturn = this._arrayFromPool;
                if (toReturn !== null)
                {
                    this._arrayFromPool = null;
                    if (!T.$type.IsPrimitive)
                    {
                        $.$spc.System.Array.Clear$1(toReturn, 0, this._pos);
                    }
                    $.$spc.System.Buffers.ArrayPool$$(T).Shared.Return(toReturn, false);
                }
            }
            /*void */ Grow(/*int*/ additionalCapacityRequired)
            {
                /*int*/ let ArrayMaxLength = 2147483591;
                /*int*/ let nextCapacity = $.$spc.System.Math.Max$4(this._span.Length !== 0 ? ((this._span.Length * 2) | 0) : 4, ((this._span.Length + additionalCapacityRequired) | 0));
                if ((nextCapacity >>> 0) > ArrayMaxLength)
                {
                    nextCapacity = $.$spc.System.Math.Max$4($.$spc.System.Math.Max$4(((this._span.Length + 1) | 0), ArrayMaxLength), this._span.Length);
                }
                /*T[]*/ let array = $.$spc.System.Buffers.ArrayPool$$(T).Shared.Rent(nextCapacity);
                this._span.CopyTo($.$spc.System.Span$$(T).op_Implicit(array));
                /*T[]?*/ let toReturn = this._arrayFromPool;
                this._span = $.$spc.System.Span$$(T).op_Implicit(this._arrayFromPool = array);
                if (toReturn !== null)
                {
                    if (!T.$type.IsPrimitive)
                    {
                        $.$spc.System.Array.Clear$1(toReturn, 0, this._pos);
                    }
                    $.$spc.System.Buffers.ArrayPool$$(T).Shared.Return(toReturn, false);
                }
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._span = this._span.Clone();
                copy._arrayFromPool = this._arrayFromPool;
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._span = $.$default($.$spc.System.Span$$(T));
                this._arrayFromPool = null;
                this._pos = 0;
            }
            static $h = 104596;
            static $g = 1;
            static $z = 16;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":1},"n":"Length","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},{"p":T?.$h??1507328,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":1}],"m":[{"r":65537,"p":[{"n":"item","p":T?.$h??1507328}],"n":"Append","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$(T).$h}],"n":"Append","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":1},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$(T).$h}],"n":"AppendMultiChar","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2},{"r":65537,"p":[{"n":"index","p":655361},{"n":"source","p":$.$spc.System.ReadOnlySpan$$(T).$h}],"n":"Insert","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":1},{"r":$.$spc.System.Span$$(T).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpan","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":1},{"r":$.$spc.System.Span$$(T).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpanWithGrow","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":2},{"r":65537,"p":[{"n":"item","p":T?.$h??1507328}],"n":"AddWithResize","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":2},{"r":$.$spc.System.ReadOnlySpan$$(T).$h,"n":"AsSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$(T).$h},{"n":"itemsWritten","p":655361,"f":2}],"n":"TryCopyTo","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":1},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":1},{"r":65537,"p":[{"n":"additionalCapacityRequired","p":655361,"f":65,"v":1}],"n":"Grow","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":2}],"l":[{"t":$.$spc.System.Span$$(T).$h,"n":"_span","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":0,"n":"_arrayFromPool","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":655361,"n":"_pos","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"scratchBuffer","p":$.$spc.System.Span$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},{"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Collections.Generic.ValueListBuilder<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$spu.System.GopherStyleUriParser", ($self) => class GopherStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.GopherUri.Flags);
                {
                }
                return this;
            }
            static $h = 497812;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2660500,"c":[{"n":".ctor","o":"$ctor$3","d":497812,"h":4295465108,"f":1}],"h":497812}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.GopherStyleUriParser`; }
        });
        
        $asm.$cls("$spu.System.LdapStyleUriParser", ($self) => class LdapStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.LdapUri.Flags);
                {
                }
                return this;
            }
            static $h = 891028;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2660500,"c":[{"n":".ctor","o":"$ctor$3","d":891028,"h":4295858324,"f":1}],"h":891028}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.LdapStyleUriParser`; }
        });
        
        $asm.$cls("$spu.System.NetPipeStyleUriParser", ($self) => class NetPipeStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.NetPipeUri.Flags);
                {
                }
                return this;
            }
            static $h = 1087636;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2660500,"c":[{"n":".ctor","o":"$ctor$3","d":1087636,"h":4296054932,"f":1}],"h":1087636}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.NetPipeStyleUriParser`; }
        });
        
        $asm.$cls("$spu.System.NetTcpStyleUriParser", ($self) => class NetTcpStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.NetTcpUri.Flags);
                {
                }
                return this;
            }
            static $h = 1153172;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2660500,"c":[{"n":".ctor","o":"$ctor$3","d":1153172,"h":4296120468,"f":1}],"h":1153172}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.NetTcpStyleUriParser`; }
        });
        
        $asm.$str("$spu.System.UriHostNameType", ($self) => class UriHostNameType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Basic = 1;
            static Dns = 2;
            static IPv4 = 3;
            static IPv6 = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Basic": 1n,
                    "Dns": 2n,
                    "IPv4": 3n,
                    "IPv6": 4n
                };
            }
            static $h = 2529428;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2529428,"n":"Unknown","d":2529428,"h":4297496724,"f":33},{"t":2529428,"n":"Basic","d":2529428,"h":8592464020,"f":33},{"t":2529428,"n":"Dns","d":2529428,"h":12887431316,"f":33},{"t":2529428,"n":"IPv4","d":2529428,"h":17182398612,"f":33},{"t":2529428,"n":"IPv6","d":2529428,"h":21477365908,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2529428,"h":25772333204,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2529428}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.UriHostNameType`; }
        });
        
        $asm.$str("$spu.System.UriKind", ($self) => class UriKind extends $.$spc.System.Enum
        {
            static RelativeOrAbsolute = 0;
            static Absolute = 1;
            static Relative = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "RelativeOrAbsolute": 0n,
                    "Absolute": 1n,
                    "Relative": 2n
                };
            }
            static $h = 2594964;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2594964,"n":"RelativeOrAbsolute","d":2594964,"h":4297562260,"f":33},{"t":2594964,"n":"Absolute","d":2594964,"h":8592529556,"f":33},{"t":2594964,"n":"Relative","d":2594964,"h":12887496852,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2594964,"h":17182464148,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2594964}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.UriKind`; }
        });
        
        $asm.$str("$spu.System.UriPartial", ($self) => class UriPartial extends $.$spc.System.Enum
        {
            static Scheme = 0;
            static Authority = 1;
            static Path = 2;
            static Query = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Scheme": 0n,
                    "Authority": 1n,
                    "Path": 2n,
                    "Query": 3n
                };
            }
            static $h = 2791572;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2791572,"n":"Scheme","d":2791572,"h":4297758868,"f":33},{"t":2791572,"n":"Authority","d":2791572,"h":8592726164,"f":33},{"t":2791572,"n":"Path","d":2791572,"h":12887693460,"f":33},{"t":2791572,"n":"Query","d":2791572,"h":17182660756,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2791572,"h":21477628052,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2791572}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.UriPartial`; }
        });
        
        $asm.$str("$spu.System.GenericUriParserOptions", ($self) => class GenericUriParserOptions extends $.$spc.System.Enum
        {
            static Default = 0;
            static GenericAuthority = 1;
            static AllowEmptyAuthority = 2;
            static NoUserInfo = 4;
            static NoPort = 8;
            static NoQuery = 16;
            static NoFragment = 32;
            static DontConvertPathBackslashes = 64;
            static DontCompressPath = 128;
            static DontUnescapePathDotsAndSlashes = 256;
            static Idn = 512;
            static IriParsing = 1024;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "GenericAuthority": 1n,
                    "AllowEmptyAuthority": 2n,
                    "NoUserInfo": 4n,
                    "NoPort": 8n,
                    "NoQuery": 16n,
                    "NoFragment": 32n,
                    "DontConvertPathBackslashes": 64n,
                    "DontCompressPath": 128n,
                    "DontUnescapePathDotsAndSlashes": 256n,
                    "Idn": 512n,
                    "IriParsing": 1024n
                };
            }
            static $h = 432276;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":432276,"n":"Default","d":432276,"h":4295399572,"f":33},{"t":432276,"n":"GenericAuthority","d":432276,"h":8590366868,"f":33},{"t":432276,"n":"AllowEmptyAuthority","d":432276,"h":12885334164,"f":33},{"t":432276,"n":"NoUserInfo","d":432276,"h":17180301460,"f":33},{"t":432276,"n":"NoPort","d":432276,"h":21475268756,"f":33},{"t":432276,"n":"NoQuery","d":432276,"h":25770236052,"f":33},{"t":432276,"n":"NoFragment","d":432276,"h":30065203348,"f":33},{"t":432276,"n":"DontConvertPathBackslashes","d":432276,"h":34360170644,"f":33},{"t":432276,"n":"DontCompressPath","d":432276,"h":38655137940,"f":33},{"t":432276,"n":"DontUnescapePathDotsAndSlashes","d":432276,"h":42950105236,"f":33},{"t":432276,"n":"Idn","d":432276,"h":47245072532,"f":33},{"t":432276,"n":"IriParsing","d":432276,"h":51540039828,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":432276,"h":55835007124,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":432276,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.GenericUriParserOptions`; }
        });
        
        $asm.$str("$spu.System.UriComponents", ($self) => class UriComponents extends $.$spc.System.Enum
        {
            static Scheme = 1;
            static UserInfo = 2;
            static Host = 4;
            static Port = 8;
            static Path = 16;
            static Query = 32;
            static Fragment = 64;
            static StrongPort = 128;
            static NormalizedHost = 256;
            static KeepDelimiter = 1073741824;
            static SerializationInfoString = -2147483648;
            static AbsoluteUri = 127;
            static HostAndPort = 132;
            static StrongAuthority = 134;
            static SchemeAndServer = 13;
            static HttpRequestUrl = 61;
            static PathAndQuery = 48;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Scheme": 1n,
                    "UserInfo": 2n,
                    "Host": 4n,
                    "Port": 8n,
                    "Path": 16n,
                    "Query": 32n,
                    "Fragment": 64n,
                    "StrongPort": 128n,
                    "NormalizedHost": 256n,
                    "KeepDelimiter": 1073741824n,
                    "SerializationInfoString": -2147483648n,
                    "AbsoluteUri": 127n,
                    "HostAndPort": 132n,
                    "StrongAuthority": 134n,
                    "SchemeAndServer": 13n,
                    "HttpRequestUrl": 61n,
                    "PathAndQuery": 48n
                };
            }
            static $h = 2201748;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2201748,"n":"Scheme","d":2201748,"h":4297169044,"f":33},{"t":2201748,"n":"UserInfo","d":2201748,"h":8592136340,"f":33},{"t":2201748,"n":"Host","d":2201748,"h":12887103636,"f":33},{"t":2201748,"n":"Port","d":2201748,"h":17182070932,"f":33},{"t":2201748,"n":"Path","d":2201748,"h":21477038228,"f":33},{"t":2201748,"n":"Query","d":2201748,"h":25772005524,"f":33},{"t":2201748,"n":"Fragment","d":2201748,"h":30066972820,"f":33},{"t":2201748,"n":"StrongPort","d":2201748,"h":34361940116,"f":33},{"t":2201748,"n":"NormalizedHost","d":2201748,"h":38656907412,"f":33},{"t":2201748,"n":"KeepDelimiter","d":2201748,"h":42951874708,"f":33},{"t":2201748,"n":"SerializationInfoString","d":2201748,"h":47246842004,"f":33},{"t":2201748,"n":"AbsoluteUri","d":2201748,"h":51541809300,"f":33},{"t":2201748,"n":"HostAndPort","d":2201748,"h":55836776596,"f":33},{"t":2201748,"n":"StrongAuthority","d":2201748,"h":60131743892,"f":33},{"t":2201748,"n":"SchemeAndServer","d":2201748,"h":64426711188,"f":33},{"t":2201748,"n":"HttpRequestUrl","d":2201748,"h":68721678484,"f":33},{"t":2201748,"n":"PathAndQuery","d":2201748,"h":73016645780,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2201748,"h":77311613076,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2201748,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.UriComponents`; }
        });
        
        $asm.$str("$spu.System.UriFormat", ($self) => class UriFormat extends $.$spc.System.Enum
        {
            static UriEscaped = 1;
            static Unescaped = 2;
            static SafeUnescaped = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "UriEscaped": 1n,
                    "Unescaped": 2n,
                    "SafeUnescaped": 3n
                };
            }
            static $h = 2332820;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2332820,"n":"UriEscaped","d":2332820,"h":4297300116,"f":33},{"t":2332820,"n":"Unescaped","d":2332820,"h":8592267412,"f":33},{"t":2332820,"n":"SafeUnescaped","d":2332820,"h":12887234708,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2332820,"h":17182202004,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2332820}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.UriFormat`; }
        });
        
        $asm.$str("$spu.System.ParsingError", ($self) => class ParsingError extends $.$spc.System.Enum
        {
            static None = 0;
            static BadFormat = 1;
            static BadScheme = 2;
            static BadAuthority = 3;
            static EmptyUriString = 4;
            static LastErrorOkayForRelativeUris = 5;
            static SchemeLimit = 6;
            static MustRootedPath = 7;
            static BadHostName = 8;
            static NonEmptyHost = 9;
            static BadPort = 10;
            static BadAuthorityTerminator = 11;
            static CannotCreateRelative = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "BadFormat": 1n,
                    "BadScheme": 2n,
                    "BadAuthority": 3n,
                    "EmptyUriString": 4n,
                    "LastErrorOkayForRelativeUris": 5n,
                    "SchemeLimit": 6n,
                    "MustRootedPath": 7n,
                    "BadHostName": 8n,
                    "NonEmptyHost": 9n,
                    "BadPort": 10n,
                    "BadAuthorityTerminator": 11n,
                    "CannotCreateRelative": 12n
                };
            }
            static $h = 1349780;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1349780,"n":"None","d":1349780,"h":4296317076,"f":33},{"t":1349780,"n":"BadFormat","d":1349780,"h":8591284372,"f":33},{"t":1349780,"n":"BadScheme","d":1349780,"h":12886251668,"f":33},{"t":1349780,"n":"BadAuthority","d":1349780,"h":17181218964,"f":33},{"t":1349780,"n":"EmptyUriString","d":1349780,"h":21476186260,"f":33},{"t":1349780,"n":"LastErrorOkayForRelativeUris","d":1349780,"h":25771153556,"f":33},{"t":1349780,"n":"SchemeLimit","d":1349780,"h":30066120852,"f":33},{"t":1349780,"n":"MustRootedPath","d":1349780,"h":34361088148,"f":33},{"t":1349780,"n":"BadHostName","d":1349780,"h":38656055444,"f":33},{"t":1349780,"n":"NonEmptyHost","d":1349780,"h":42951022740,"f":33},{"t":1349780,"n":"BadPort","d":1349780,"h":47245990036,"f":33},{"t":1349780,"n":"BadAuthorityTerminator","d":1349780,"h":51540957332,"f":33},{"t":1349780,"n":"CannotCreateRelative","d":1349780,"h":55835924628,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1349780,"h":60130891924,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1349780}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.ParsingError`; }
        });
        
        $asm.$str("$spu.System.UnescapeMode", ($self) => class UnescapeMode extends $.$spc.System.Enum
        {
            static CopyOnly = 0;
            static Escape = 1;
            static Unescape = 2;
            static EscapeUnescape = 3;
            static V1ToStringFlag = 4;
            static UnescapeAll = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "CopyOnly": 0n,
                    "Escape": 1n,
                    "Unescape": 2n,
                    "EscapeUnescape": 3n,
                    "V1ToStringFlag": 4n,
                    "UnescapeAll": 8n
                };
            }
            static $h = 1677460;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1677460,"n":"CopyOnly","d":1677460,"h":4296644756,"f":33},{"t":1677460,"n":"Escape","d":1677460,"h":8591612052,"f":33},{"t":1677460,"n":"Unescape","d":1677460,"h":12886579348,"f":33},{"t":1677460,"n":"EscapeUnescape","d":1677460,"h":17181546644,"f":33},{"t":1677460,"n":"V1ToStringFlag","d":1677460,"h":21476513940,"f":33},{"t":1677460,"n":"UnescapeAll","d":1677460,"h":25771481236,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1677460,"h":30066448532,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1677460,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.UnescapeMode`; }
        });
        
        $asm.$str("$spu.System.UriSyntaxFlags", ($self) => class UriSyntaxFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static MustHaveAuthority = 1;
            static OptionalAuthority = 2;
            static MayHaveUserInfo = 4;
            static MayHavePort = 8;
            static MayHavePath = 16;
            static MayHaveQuery = 32;
            static MayHaveFragment = 64;
            static AllowEmptyHost = 128;
            static AllowUncHost = 256;
            static AllowDnsHost = 512;
            static AllowIPv4Host = 1024;
            static AllowIPv6Host = 2048;
            static AllowAnInternetHost = 3584;
            static AllowAnyOtherHost = 4096;
            static FileLikeUri = 8192;
            static MailToLikeUri = 16384;
            static V1_UnknownUri = 65536;
            static SimpleUserSyntax = 131072;
            static AllowDOSPath = 1048576;
            static PathIsRooted = 2097152;
            static ConvertPathSlashes = 4194304;
            static CompressPath = 8388608;
            static CanonicalizeAsFilePath = 16777216;
            static UnEscapeDotsAndSlashes = 33554432;
            static AllowIdn = 67108864;
            static AllowIriParsing = 268435456;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "MustHaveAuthority": 1n,
                    "OptionalAuthority": 2n,
                    "MayHaveUserInfo": 4n,
                    "MayHavePort": 8n,
                    "MayHavePath": 16n,
                    "MayHaveQuery": 32n,
                    "MayHaveFragment": 64n,
                    "AllowEmptyHost": 128n,
                    "AllowUncHost": 256n,
                    "AllowDnsHost": 512n,
                    "AllowIPv4Host": 1024n,
                    "AllowIPv6Host": 2048n,
                    "AllowAnInternetHost": 3584n,
                    "AllowAnyOtherHost": 4096n,
                    "FileLikeUri": 8192n,
                    "MailToLikeUri": 16384n,
                    "V1_UnknownUri": 65536n,
                    "SimpleUserSyntax": 131072n,
                    "AllowDOSPath": 1048576n,
                    "PathIsRooted": 2097152n,
                    "ConvertPathSlashes": 4194304n,
                    "CompressPath": 8388608n,
                    "CanonicalizeAsFilePath": 16777216n,
                    "UnEscapeDotsAndSlashes": 33554432n,
                    "AllowIdn": 67108864n,
                    "AllowIriParsing": 268435456n
                };
            }
            static $h = 2857108;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2857108,"n":"None","d":2857108,"h":4297824404,"f":33},{"t":2857108,"n":"MustHaveAuthority","d":2857108,"h":8592791700,"f":33},{"t":2857108,"n":"OptionalAuthority","d":2857108,"h":12887758996,"f":33},{"t":2857108,"n":"MayHaveUserInfo","d":2857108,"h":17182726292,"f":33},{"t":2857108,"n":"MayHavePort","d":2857108,"h":21477693588,"f":33},{"t":2857108,"n":"MayHavePath","d":2857108,"h":25772660884,"f":33},{"t":2857108,"n":"MayHaveQuery","d":2857108,"h":30067628180,"f":33},{"t":2857108,"n":"MayHaveFragment","d":2857108,"h":34362595476,"f":33},{"t":2857108,"n":"AllowEmptyHost","d":2857108,"h":38657562772,"f":33},{"t":2857108,"n":"AllowUncHost","d":2857108,"h":42952530068,"f":33},{"t":2857108,"n":"AllowDnsHost","d":2857108,"h":47247497364,"f":33},{"t":2857108,"n":"AllowIPv4Host","d":2857108,"h":51542464660,"f":33},{"t":2857108,"n":"AllowIPv6Host","d":2857108,"h":55837431956,"f":33},{"t":2857108,"n":"AllowAnInternetHost","d":2857108,"h":60132399252,"f":33},{"t":2857108,"n":"AllowAnyOtherHost","d":2857108,"h":64427366548,"f":33},{"t":2857108,"n":"FileLikeUri","d":2857108,"h":68722333844,"f":33},{"t":2857108,"n":"MailToLikeUri","d":2857108,"h":73017301140,"f":33},{"t":2857108,"n":"V1_UnknownUri","d":2857108,"h":77312268436,"f":33},{"t":2857108,"n":"SimpleUserSyntax","d":2857108,"h":81607235732,"f":33},{"t":2857108,"n":"AllowDOSPath","d":2857108,"h":85902203028,"f":33},{"t":2857108,"n":"PathIsRooted","d":2857108,"h":90197170324,"f":33},{"t":2857108,"n":"ConvertPathSlashes","d":2857108,"h":94492137620,"f":33},{"t":2857108,"n":"CompressPath","d":2857108,"h":98787104916,"f":33},{"t":2857108,"n":"CanonicalizeAsFilePath","d":2857108,"h":103082072212,"f":33},{"t":2857108,"n":"UnEscapeDotsAndSlashes","d":2857108,"h":107377039508,"f":33},{"t":2857108,"n":"AllowIdn","d":2857108,"h":111672006804,"f":33},{"t":2857108,"n":"AllowIriParsing","d":2857108,"h":115966974100,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2857108,"h":120261941396,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2857108,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.UriSyntaxFlags`; }
        });
        
        $asm.$cls("$spu.System.UriFormatException", ($self) => class UriFormatException extends $.$spc.System.FormatException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ textString)
            {
                super.$ctor$10(textString);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ textString, /*Exception?*/ e)
            {
                super.$ctor$11(textString, e);
                {
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.$ctor$12(serializationInfo, streamingContext);
                {
                }
                return this;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.GetObjectData(serializationInfo, streamingContext);
            }
            static $h = 2398356;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47775745,"h":2398356}; }
            static get $b() { return $.$spc.System.FormatException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.UriFormatException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))