
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Private.Uri", 
    {"h":42284,"f":"System.Private.Uri","v":"1.0.35.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Private.Uri","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Private.Uri","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$spu.System.UriParser", ($self) => class UriParser extends $.$$.System.Object
        {
            /*string */ get SchemeName()
            {
                return this._scheme;
            }
            /*int */ get DefaultPort()
            {
                return this._port;
            }
            /*UriSyntaxFlags*/ static SchemeOnlyFlags = 16;
            $ctor$1()
            {
                this.$ctor$2(16/*SchemeOnlyFlags*/);
                {
                }
                return this;
            }
            /*UriParser */ OnNewUri()
            {
                return this;
            }
            /*void */ OnRegister(/*string*/ schemeName, /*int*/ defaultPort)
            {
            }
            /*void */ InitializeAndValidate(/*Uri*/ uri, /*out UriFormatException?*/ parsingError)
            {
                if (uri._syntax === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (!$.$$.System.Object.ReferenceEquals(uri._syntax, this))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_UserDrivenParsing, $.$$.System.Object.GetType.call(uri._syntax)));
                }
                $.$$.System.Diagnostics.Debug.Assert$2($.$spu.System.Uri.Flags.$z === $.$$.System.UInt64.$z, "sizeof(Uri.Flags) == sizeof(ulong)");
                /*ulong*/ let previous = $.$$.System.Threading.Interlocked.Or$3($.$$.System.Runtime.CompilerServices.Unsafe.As($.$spu.System.Uri.Flags, $.$$.System.UInt64, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => uri._flags, ($v) => uri._flags = $v, null)), 72057594037927936n);
                if (($.$cast(previous, $.$spu.System.Uri.Flags) & 72057594037927936n) !== 0n)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_InitializeCalledAlreadyOrTooLate);
                }
                parsingError.$v = uri.ParseMinimal();
            }
            /*string? */ Resolve(/*Uri*/ baseUri, /*Uri?*/ relativeUri, /*out UriFormatException?*/ parsingError)
            {
                if (baseUri.UserDrivenParsing)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_UserDrivenParsing, $.$$.System.Object.GetType.call(this)));
                }
                if (!baseUri.IsAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*string?*/ let newUriString = null;
                /*bool*/ let userEscaped = false;
                parsingError.$v = null;
                /*Uri?*/ let result = $.$spu.System.Uri.ResolveHelper(baseUri, relativeUri, $.$ref(() => newUriString, ($v) => newUriString = $v, $.$$.System.String), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => userEscaped, ($v) => userEscaped = $v, null));
                if ($.$spu.System.Uri.op_Inequality(result, null))
                {
                    return result.OriginalString;
                }
                return newUriString;
            }
            /*bool */ IsBaseOf(/*Uri*/ baseUri, /*Uri*/ relativeUri)
            {
                return baseUri.IsBaseOfHelper(relativeUri);
            }
            /*string */ GetComponents(/*Uri*/ uri, /*UriComponents*/ components, /*UriFormat*/ format)
            {
                if (((components & -2147483648/*UriComponents.SerializationInfoString*/) !== 0) && components !== -2147483648/*UriComponents.SerializationInfoString*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("components", $.$box(components, $.$spu.System.UriComponents), $.$spu.System.SR.net_uri_NotJustSerialization);
                }
                if ((format & ~3/*UriFormat.SafeUnescaped*/) !== 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("format");
                }
                if (uri.UserDrivenParsing)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_UserDrivenParsing, $.$$.System.Object.GetType.call(this)));
                }
                if (!uri.IsAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (uri.DisablePathAndQueryCanonicalization && (components & (16/*UriComponents.Path*/ | 32/*UriComponents.Query*/)) !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_GetComponentsCalledWhenCanonicalizationDisabled);
                }
                return uri.GetComponentsHelper(components, format);
            }
            /*bool */ IsWellFormedOriginalString(/*Uri*/ uri)
            {
                return uri.InternalIsWellFormedOriginalString();
            }
            static /*void */ Register(/*UriParser*/ uriParser, /*string*/ schemeName, /*int*/ defaultPort)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uriParser, "uriParser");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(schemeName, "schemeName");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfEqual($.$$.System.Int32, schemeName.length, 1, "schemeName.Length");
                if (!$.$spu.System.Uri.CheckSchemeName(schemeName))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("schemeName");
                }
                if ((defaultPort >>> 0) > 65535 && defaultPort !== -1)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("defaultPort");
                }
                schemeName = $.$$.System.String.ToLowerInvariant.call(schemeName);
                $.$spu.System.UriParser.FetchSyntax(uriParser, schemeName, defaultPort);
            }
            static /*bool */ IsKnownScheme(/*string*/ schemeName)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(schemeName, "schemeName");
                if (!$.$spu.System.Uri.CheckSchemeName(schemeName))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("schemeName");
                }
                /*UriParser?*/ let syntax = $.$spu.System.UriParser.GetSyntax($.$$.System.String.ToLowerInvariant.call(schemeName));
                return syntax !== null && syntax.NotAny(65536/*UriSyntaxFlags.V1_UnknownUri*/);
            }
            /*UriParser*/ static HttpUri = null;
            /*UriParser*/ static HttpsUri = null;
            /*UriParser*/ static WsUri = null;
            /*UriParser*/ static WssUri = null;
            /*UriParser*/ static FtpUri = null;
            /*UriParser*/ static FileUri = null;
            /*UriParser*/ static UnixFileUri = null;
            /*UriParser*/ static GopherUri = null;
            /*UriParser*/ static NntpUri = null;
            /*UriParser*/ static NewsUri = null;
            /*UriParser*/ static MailToUri = null;
            /*UriParser*/ static UuidUri = null;
            /*UriParser*/ static TelnetUri = null;
            /*UriParser*/ static LdapUri = null;
            /*UriParser*/ static NetTcpUri = null;
            /*UriParser*/ static NetPipeUri = null;
            /*UriParser*/ static VsMacrosUri = null;
            /*Hashtable*/ static s_table = null;
            /*Hashtable*/ static s_tempTable = null;
            /*UriSyntaxFlags*/ _flags = 0;
            /*int*/ _port = 0;
            /*string*/ _scheme = null;
            /*int*/ static NoDefaultPort = -1;
            /*int*/ static c_InitialTableSize = 25;
            static $_BuiltInUriParser;
            static get BuiltInUriParser()
            {
                let $cls = $.$spu.System.UriParser;
                return $cls.$_BuiltInUriParser ??= $asm.$ncls("$spu.System.UriParser.BuiltInUriParser", ($self) => class BuiltInUriParser extends $.$spu.System.UriParser
                {
                    $ctor$3(/*string*/ lwrCaseScheme, /*int*/ defaultPort, /*UriSyntaxFlags*/ syntaxFlags)
                    {
                        super.$ctor$2(syntaxFlags | 131072/*UriSyntaxFlags.SimpleUserSyntax*/);
                        {
                            this._scheme = lwrCaseScheme;
                            this._port = defaultPort;
                        }
                        return this;
                    }
                    static $h = 2729260;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2663724,"c":[{"p":[{"n":"lwrCaseScheme","p":1310721},{"n":"defaultPort","p":655361},{"n":"syntaxFlags","p":2860332}],"n":".ctor","o":"$ctor$3","d":2729260,"h":4297696556,"f":16777224}],"d":2663724,"h":2729260}; }
                    static get $b() { return $.$spu.System.UriParser; }
                    static get $fullName() { return `System.UriParser.BuiltInUriParser`; }
                }, $cls, ($v) => $cls.$_BuiltInUriParser = $v);
            }
            /*UriSyntaxFlags */ get Flags()
            {
                return this._flags;
            }
            /*bool */ NotAny(/*UriSyntaxFlags*/ flags)
            {
                return this.IsFullMatch(flags, 0/*UriSyntaxFlags.None*/);
            }
            /*bool */ InFact(/*UriSyntaxFlags*/ flags)
            {
                return !this.IsFullMatch(flags, 0/*UriSyntaxFlags.None*/);
            }
            /*bool */ IsAllSet(/*UriSyntaxFlags*/ flags)
            {
                return this.IsFullMatch(flags, flags);
            }
            /*bool */ IsFullMatch(/*UriSyntaxFlags*/ flags, /*UriSyntaxFlags*/ expected)
            {
                return (this._flags & flags) === expected;
            }
            $ctor$2(/*UriSyntaxFlags*/ flags)
            {
                super.$ctor();
                {
                    this._flags = flags;
                    this._scheme = $.$$.System.String.Empty;
                }
                return this;
            }
            static /*void */ FetchSyntax(/*UriParser*/ syntax, /*string*/ lwrCaseSchemeName, /*int*/ defaultPort)
            {
                if (syntax.SchemeName.length !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_NeedFreshParser, syntax.SchemeName));
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$spu.System.UriParser.s_table)
                    {
                        syntax._flags &= ~65536/*UriSyntaxFlags.V1_UnknownUri*/;
                        /*UriParser?*/ let oldSyntax = $.$cast($.$spu.System.UriParser.s_table.get_Item(lwrCaseSchemeName), $.$spu.System.UriParser);
                        if (oldSyntax !== null)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_AlreadyRegistered, oldSyntax.SchemeName));
                        }
                        oldSyntax = $.$cast($.$spu.System.UriParser.s_tempTable.get_Item(syntax.SchemeName), $.$spu.System.UriParser);
                        if (oldSyntax !== null)
                        {
                            lwrCaseSchemeName = oldSyntax._scheme;
                            $.$spu.System.UriParser.s_tempTable.Remove(lwrCaseSchemeName);
                        }
                        syntax.OnRegister(lwrCaseSchemeName, defaultPort);
                        syntax._scheme = lwrCaseSchemeName;
                        syntax.CheckSetIsSimpleFlag();
                        syntax._port = defaultPort;
                        $.$spu.System.UriParser.s_table.set_Item(syntax.SchemeName, syntax);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$spu.System.UriParser.s_table)
                }
            }
            /*int*/ static c_MaxCapacity = 512;
            static /*UriParser */ FindOrFetchAsUnknownV1Syntax(/*string*/ lwrCaseScheme)
            {
                /*UriParser?*/ let syntax = $.$cast($.$spu.System.UriParser.s_table.get_Item(lwrCaseScheme), $.$spu.System.UriParser);
                if (syntax !== null)
                {
                    return syntax;
                }
                syntax = $.$cast($.$spu.System.UriParser.s_tempTable.get_Item(lwrCaseScheme), $.$spu.System.UriParser);
                if (syntax !== null)
                {
                    return syntax;
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$spu.System.UriParser.s_table)
                    {
                        if ($.$spu.System.UriParser.s_tempTable.Count >= 512/*c_MaxCapacity*/)
                        {
                            $.$spu.System.UriParser.s_tempTable = new $.$$.System.Collections.Hashtable().$ctor$16(25/*c_InitialTableSize*/);
                        }
                        syntax = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3(lwrCaseScheme, -1/*NoDefaultPort*/, 351342590/*UnknownV1SyntaxFlags*/);
                        $.$spu.System.UriParser.s_tempTable.set_Item(lwrCaseScheme, syntax);
                        return syntax;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$spu.System.UriParser.s_table)
                }
            }
            static /*UriParser? */ GetSyntax(/*string*/ lwrCaseScheme)
            {
                return $.$cast(($.$spu.System.UriParser.s_table.get_Item(lwrCaseScheme) ?? $.$spu.System.UriParser.s_tempTable.get_Item(lwrCaseScheme)), $.$spu.System.UriParser);
            }
            /*bool */ get IsSimple()
            {
                return this.InFact(131072/*UriSyntaxFlags.SimpleUserSyntax*/);
            }
            /*void */ CheckSetIsSimpleFlag()
            {
                /*Type*/ let type = $.$$.System.Object.GetType.call(this);
                if ($.$$.System.Type.op_Equality$1(type, $.$spu.System.GenericUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.HttpStyleUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.FtpStyleUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.FileStyleUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.NewsStyleUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.GopherStyleUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.NetPipeStyleUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.NetTcpStyleUriParser.$type) || $.$$.System.Type.op_Equality$1(type, $.$spu.System.LdapStyleUriParser.$type))
                {
                    this._flags |= 131072/*UriSyntaxFlags.SimpleUserSyntax*/;
                }
            }
            /*UriParser */ InternalOnNewUri()
            {
                /*UriParser*/ let effectiveParser = this.OnNewUri();
                if (this !== effectiveParser)
                {
                    effectiveParser._scheme = this._scheme;
                    effectiveParser._port = this._port;
                    effectiveParser._flags = this._flags;
                }
                return effectiveParser;
            }
            /*void */ InternalValidate(/*Uri*/ thisUri, /*out UriFormatException?*/ parsingError)
            {
                thisUri.DebugAssertInCtor();
                this.InitializeAndValidate(thisUri, parsingError);
                $.$$.System.Diagnostics.Debug.Assert$2($.$spu.System.Uri.Flags.$z === $.$$.System.UInt64.$z, "sizeof(Uri.Flags) == sizeof(ulong)");
                $.$$.System.Threading.Interlocked.Or$3($.$$.System.Runtime.CompilerServices.Unsafe.As($.$spu.System.Uri.Flags, $.$$.System.UInt64, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => thisUri._flags, ($v) => thisUri._flags = $v, null)), 72057594037927936n);
            }
            /*string? */ InternalResolve(/*Uri*/ thisBaseUri, /*Uri*/ uriLink, /*out UriFormatException?*/ parsingError)
            {
                return this.Resolve(thisBaseUri, uriLink, parsingError);
            }
            /*bool */ InternalIsBaseOf(/*Uri*/ thisBaseUri, /*Uri*/ uriLink)
            {
                return this.IsBaseOf(thisBaseUri, uriLink);
            }
            /*string */ InternalGetComponents(/*Uri*/ thisUri, /*UriComponents*/ uriComponents, /*UriFormat*/ uriFormat)
            {
                return this.GetComponents(thisUri, uriComponents, uriFormat);
            }
            /*bool */ InternalIsWellFormedOriginalString(/*Uri*/ thisUri)
            {
                return this.IsWellFormedOriginalString(thisUri);
            }
            /*UriSyntaxFlags*/ static UnknownV1SyntaxFlags = 351342590;
            /*UriSyntaxFlags*/ static HttpSyntaxFlags = 367005565;
            /*UriSyntaxFlags*/ static FtpSyntaxFlags = 367005533;
            /*UriSyntaxFlags*/ static FileSyntaxFlags = 401616881;
            /*UriSyntaxFlags*/ static UnixFileSyntaxFlags = 397422577;
            /*UriSyntaxFlags*/ static VsmacrosSyntaxFlags = 399519697;
            /*UriSyntaxFlags*/ static GopherSyntaxFlags = 337645405;
            /*UriSyntaxFlags*/ static NewsSyntaxFlags = 268435536;
            /*UriSyntaxFlags*/ static NntpSyntaxFlags = 337645405;
            /*UriSyntaxFlags*/ static TelnetSyntaxFlags = 337645405;
            /*UriSyntaxFlags*/ static LdapSyntaxFlags = 337645565;
            /*UriSyntaxFlags*/ static MailtoSyntaxFlags = 335564796;
            /*UriSyntaxFlags*/ static NetPipeSyntaxFlags = 400559729;
            /*UriSyntaxFlags*/ static NetTcpSyntaxFlags = 400559737;
            //Static Initializer
            static $sinit()
            {
                {
                    this.HttpUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("http", 80, 367005565/*HttpSyntaxFlags*/);
                }
                {
                    this.HttpsUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("https", 443, $.$spu.System.UriParser.HttpUri._flags);
                }
                {
                    this.WsUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("ws", 80, 367005565/*HttpSyntaxFlags*/);
                }
                {
                    this.WssUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("wss", 443, 367005565/*HttpSyntaxFlags*/);
                }
                {
                    this.FtpUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("ftp", 21, 367005533/*FtpSyntaxFlags*/);
                }
                {
                    this.FileUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("file", -1/*NoDefaultPort*/, 401616881/*FileSyntaxFlags*/);
                }
                {
                    this.UnixFileUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("file", -1/*NoDefaultPort*/, 397422577/*UnixFileSyntaxFlags*/);
                }
                {
                    this.GopherUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("gopher", 70, 337645405/*GopherSyntaxFlags*/);
                }
                {
                    this.NntpUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("nntp", 119, 337645405/*NntpSyntaxFlags*/);
                }
                {
                    this.NewsUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("news", -1/*NoDefaultPort*/, 268435536/*NewsSyntaxFlags*/);
                }
                {
                    this.MailToUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("mailto", 25, 335564796/*MailtoSyntaxFlags*/);
                }
                {
                    this.UuidUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("uuid", -1/*NoDefaultPort*/, $.$spu.System.UriParser.NewsUri._flags);
                }
                {
                    this.TelnetUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("telnet", 23, 337645405/*TelnetSyntaxFlags*/);
                }
                {
                    this.LdapUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("ldap", 389, 337645565/*LdapSyntaxFlags*/);
                }
                {
                    this.NetTcpUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("net.tcp", 808, 400559737/*NetTcpSyntaxFlags*/);
                }
                {
                    this.NetPipeUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("net.pipe", -1/*NoDefaultPort*/, 400559729/*NetPipeSyntaxFlags*/);
                }
                {
                    this.VsMacrosUri = new $.$spu.System.UriParser.BuiltInUriParser().$ctor$3("vsmacros", -1/*NoDefaultPort*/, 399519697/*VsmacrosSyntaxFlags*/);
                }
                {
                    this.s_table = (() =>
                    {
                        //new $.$$.System.Collections.Hashtable()
                        const $t1 = $.$$.System.Collections.Hashtable;
                        const $i1 = new $t1();
                        $i1.$ctor$16(16);
                        $i1.Add($.$spu.System.UriParser.HttpUri.SchemeName, $.$spu.System.UriParser.HttpUri);
                        $i1.Add($.$spu.System.UriParser.HttpsUri.SchemeName, $.$spu.System.UriParser.HttpsUri);
                        $i1.Add($.$spu.System.UriParser.WsUri.SchemeName, $.$spu.System.UriParser.WsUri);
                        $i1.Add($.$spu.System.UriParser.WssUri.SchemeName, $.$spu.System.UriParser.WssUri);
                        $i1.Add($.$spu.System.UriParser.FtpUri.SchemeName, $.$spu.System.UriParser.FtpUri);
                        $i1.Add($.$spu.System.UriParser.FileUri.SchemeName, $.$spu.System.UriParser.FileUri);
                        $i1.Add($.$spu.System.UriParser.GopherUri.SchemeName, $.$spu.System.UriParser.GopherUri);
                        $i1.Add($.$spu.System.UriParser.NntpUri.SchemeName, $.$spu.System.UriParser.NntpUri);
                        $i1.Add($.$spu.System.UriParser.NewsUri.SchemeName, $.$spu.System.UriParser.NewsUri);
                        $i1.Add($.$spu.System.UriParser.MailToUri.SchemeName, $.$spu.System.UriParser.MailToUri);
                        $i1.Add($.$spu.System.UriParser.UuidUri.SchemeName, $.$spu.System.UriParser.UuidUri);
                        $i1.Add($.$spu.System.UriParser.TelnetUri.SchemeName, $.$spu.System.UriParser.TelnetUri);
                        $i1.Add($.$spu.System.UriParser.LdapUri.SchemeName, $.$spu.System.UriParser.LdapUri);
                        $i1.Add($.$spu.System.UriParser.NetTcpUri.SchemeName, $.$spu.System.UriParser.NetTcpUri);
                        $i1.Add($.$spu.System.UriParser.NetPipeUri.SchemeName, $.$spu.System.UriParser.NetPipeUri);
                        $i1.Add($.$spu.System.UriParser.VsMacrosUri.SchemeName, $.$spu.System.UriParser.VsMacrosUri);
                        return $i1;
                    })();
                }
                {
                    this.s_tempTable = new $.$$.System.Collections.Hashtable().$ctor$16(25/*c_InitialTableSize*/);
                }
            }
            static $h = 2663724;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8592598316,"f":50331656},"n":"SchemeName","d":2663724,"h":4297631020,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":17182532908,"f":50331656},"n":"DefaultPort","d":2663724,"h":12887565612,"f":2097160},{"p":2860332,"g":{"r":0,"d":0,"h":180391290156,"f":50331656},"n":"Flags","d":2663724,"h":176096322860,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":227635930412,"f":50331656},"n":"IsSimple","d":2663724,"h":223340963116,"f":2097160}],"m":[{"r":2663724,"n":"OnNewUri","d":2663724,"h":30067434796,"f":16777348},{"r":65537,"p":[{"n":"schemeName","p":1310721},{"n":"defaultPort","p":655361}],"n":"OnRegister","d":2663724,"h":34362402092,"f":16777348},{"r":65537,"p":[{"n":"uri","p":1746220},{"n":"parsingError","p":2401580,"f":2}],"n":"InitializeAndValidate","d":2663724,"h":38657369388,"f":16777348},{"r":1310721,"p":[{"n":"baseUri","p":1746220},{"n":"relativeUri","p":1746220},{"n":"parsingError","p":2401580,"f":2}],"n":"Resolve","d":2663724,"h":42952336684,"f":16777348},{"r":262145,"p":[{"n":"baseUri","p":1746220},{"n":"relativeUri","p":1746220}],"n":"IsBaseOf","d":2663724,"h":47247303980,"f":16777348},{"r":1310721,"p":[{"n":"uri","p":1746220},{"n":"components","p":2204972},{"n":"format","p":2336044}],"n":"GetComponents","d":2663724,"h":51542271276,"f":16777348},{"r":262145,"p":[{"n":"uri","p":1746220}],"n":"IsWellFormedOriginalString","d":2663724,"h":55837238572,"f":16777348},{"r":65537,"p":[{"n":"uriParser","p":2663724},{"n":"schemeName","p":1310721},{"n":"defaultPort","p":655361}],"n":"Register","d":2663724,"h":60132205868,"f":16777249},{"r":262145,"p":[{"n":"schemeName","p":1310721}],"n":"IsKnownScheme","d":2663724,"h":64427173164,"f":16777249},{"r":262145,"p":[{"n":"flags","p":2860332}],"n":"NotAny","d":2663724,"h":184686257452,"f":16777224},{"r":262145,"p":[{"n":"flags","p":2860332}],"n":"InFact","d":2663724,"h":188981224748,"f":16777224},{"r":262145,"p":[{"n":"flags","p":2860332}],"n":"IsAllSet","d":2663724,"h":193276192044,"f":16777224},{"r":262145,"p":[{"n":"flags","p":2860332},{"n":"expected","p":2860332}],"n":"IsFullMatch","d":2663724,"h":197571159340,"f":16777218},{"r":65537,"p":[{"n":"syntax","p":2663724},{"n":"lwrCaseSchemeName","p":1310721},{"n":"defaultPort","p":655361}],"n":"FetchSyntax","d":2663724,"h":206161093932,"f":16777250},{"r":2663724,"p":[{"n":"lwrCaseScheme","p":1310721}],"n":"FindOrFetchAsUnknownV1Syntax","d":2663724,"h":214751028524,"f":16777256},{"r":2663724,"p":[{"n":"lwrCaseScheme","p":1310721}],"n":"GetSyntax","d":2663724,"h":219045995820,"f":16777256},{"r":65537,"n":"CheckSetIsSimpleFlag","d":2663724,"h":231930897708,"f":16777224},{"r":2663724,"n":"InternalOnNewUri","d":2663724,"h":236225865004,"f":16777224},{"r":65537,"p":[{"n":"thisUri","p":1746220},{"n":"parsingError","p":2401580,"f":2}],"n":"InternalValidate","d":2663724,"h":240520832300,"f":16777224},{"r":1310721,"p":[{"n":"thisBaseUri","p":1746220},{"n":"uriLink","p":1746220},{"n":"parsingError","p":2401580,"f":2}],"n":"InternalResolve","d":2663724,"h":244815799596,"f":16777224},{"r":262145,"p":[{"n":"thisBaseUri","p":1746220},{"n":"uriLink","p":1746220}],"n":"InternalIsBaseOf","d":2663724,"h":249110766892,"f":16777224},{"r":1310721,"p":[{"n":"thisUri","p":1746220},{"n":"uriComponents","p":2204972},{"n":"uriFormat","p":2336044}],"n":"InternalGetComponents","d":2663724,"h":253405734188,"f":16777224},{"r":262145,"p":[{"n":"thisUri","p":1746220}],"n":"InternalIsWellFormedOriginalString","d":2663724,"h":257700701484,"f":16777224}],"l":[{"t":2860332,"n":"SchemeOnlyFlags","d":2663724,"h":21477500204,"f":4194338},{"t":2663724,"n":"HttpUri","d":2663724,"h":68722140460,"f":4194344},{"t":2663724,"n":"HttpsUri","d":2663724,"h":73017107756,"f":4194344},{"t":2663724,"n":"WsUri","d":2663724,"h":77312075052,"f":4194344},{"t":2663724,"n":"WssUri","d":2663724,"h":81607042348,"f":4194344},{"t":2663724,"n":"FtpUri","d":2663724,"h":85902009644,"f":4194344},{"t":2663724,"n":"FileUri","d":2663724,"h":90196976940,"f":4194344},{"t":2663724,"n":"UnixFileUri","d":2663724,"h":94491944236,"f":4194344},{"t":2663724,"n":"GopherUri","d":2663724,"h":98786911532,"f":4194344},{"t":2663724,"n":"NntpUri","d":2663724,"h":103081878828,"f":4194344},{"t":2663724,"n":"NewsUri","d":2663724,"h":107376846124,"f":4194344},{"t":2663724,"n":"MailToUri","d":2663724,"h":111671813420,"f":4194344},{"t":2663724,"n":"UuidUri","d":2663724,"h":115966780716,"f":4194344},{"t":2663724,"n":"TelnetUri","d":2663724,"h":120261748012,"f":4194344},{"t":2663724,"n":"LdapUri","d":2663724,"h":124556715308,"f":4194344},{"t":2663724,"n":"NetTcpUri","d":2663724,"h":128851682604,"f":4194344},{"t":2663724,"n":"NetPipeUri","d":2663724,"h":133146649900,"f":4194344},{"t":2663724,"n":"VsMacrosUri","d":2663724,"h":137441617196,"f":4194344},{"t":31064065,"n":"s_table","d":2663724,"h":141736584492,"f":4194338},{"t":31064065,"n":"s_tempTable","d":2663724,"h":146031551788,"f":4194338},{"t":2860332,"n":"_flags","d":2663724,"h":150326519084,"f":4194306},{"t":655361,"n":"_port","d":2663724,"h":154621486380,"f":4194306},{"t":1310721,"n":"_scheme","d":2663724,"h":158916453676,"f":4194306},{"t":655361,"n":"NoDefaultPort","d":2663724,"h":163211420972,"f":4194344},{"t":655361,"n":"c_InitialTableSize","d":2663724,"h":167506388268,"f":4194338},{"t":655361,"n":"c_MaxCapacity","d":2663724,"h":210456061228,"f":4194338},{"t":2860332,"n":"UnknownV1SyntaxFlags","d":2663724,"h":261995668780,"f":4194338},{"t":2860332,"n":"HttpSyntaxFlags","d":2663724,"h":266290636076,"f":4194338},{"t":2860332,"n":"FtpSyntaxFlags","d":2663724,"h":270585603372,"f":4194338},{"t":2860332,"n":"FileSyntaxFlags","d":2663724,"h":274880570668,"f":4194338},{"t":2860332,"n":"UnixFileSyntaxFlags","d":2663724,"h":279175537964,"f":4194338},{"t":2860332,"n":"VsmacrosSyntaxFlags","d":2663724,"h":283470505260,"f":4194338},{"t":2860332,"n":"GopherSyntaxFlags","d":2663724,"h":287765472556,"f":4194338},{"t":2860332,"n":"NewsSyntaxFlags","d":2663724,"h":292060439852,"f":4194338},{"t":2860332,"n":"NntpSyntaxFlags","d":2663724,"h":296355407148,"f":4194338},{"t":2860332,"n":"TelnetSyntaxFlags","d":2663724,"h":300650374444,"f":4194338},{"t":2860332,"n":"LdapSyntaxFlags","d":2663724,"h":304945341740,"f":4194338},{"t":2860332,"n":"MailtoSyntaxFlags","d":2663724,"h":309240309036,"f":4194338},{"t":2860332,"n":"NetPipeSyntaxFlags","d":2663724,"h":313535276332,"f":4194338},{"t":2860332,"n":"NetTcpSyntaxFlags","d":2663724,"h":317830243628,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":2663724,"h":25772467500,"f":16777220},{"p":[{"n":"flags","p":2860332}],"n":".ctor","o":"$ctor$2","d":2663724,"h":201866126636,"f":16777224}],"j":[2729260],"h":2663724}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.UriParser`; }
        });
        
        $asm.$cls("$spu.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 1287468;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":1287468,"h":4296254764,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":1287468,"h":8591222060,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":1287468,"h":12886189356,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":1287468,"h":17181156652,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":1287468,"h":21476123948,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityMessage","d":1287468,"h":25771091244,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":1287468,"h":30066058540,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":1287468,"h":34361025836,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":1287468,"h":38655993132,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":1287468,"h":42950960428,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":1287468,"h":47245927724,"f":4194344},{"t":1310721,"n":"ThreadAbortMessage","d":1287468,"h":51540895020,"f":4194344},{"t":1310721,"n":"ThreadResetAbortMessage","d":1287468,"h":55835862316,"f":4194344},{"t":1310721,"n":"ThreadAbortDiagId","d":1287468,"h":60130829612,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":1287468,"h":64425796908,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":1287468,"h":68720764204,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":1287468,"h":73015731500,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":1287468,"h":77310698796,"f":4194344},{"t":1310721,"n":"AuthenticationManagerMessage","d":1287468,"h":81605666092,"f":4194344},{"t":1310721,"n":"AuthenticationManagerDiagId","d":1287468,"h":85900633388,"f":4194344},{"t":1310721,"n":"RemotingApisMessage","d":1287468,"h":90195600684,"f":4194344},{"t":1310721,"n":"RemotingApisDiagId","d":1287468,"h":94490567980,"f":4194344},{"t":1310721,"n":"BinaryFormatterMessage","d":1287468,"h":98785535276,"f":4194344},{"t":1310721,"n":"BinaryFormatterDiagId","d":1287468,"h":103080502572,"f":4194344},{"t":1310721,"n":"CodeBaseMessage","d":1287468,"h":107375469868,"f":4194344},{"t":1310721,"n":"CodeBaseDiagId","d":1287468,"h":111670437164,"f":4194344},{"t":1310721,"n":"EscapeUriStringMessage","d":1287468,"h":115965404460,"f":4194344},{"t":1310721,"n":"EscapeUriStringDiagId","d":1287468,"h":120260371756,"f":4194344},{"t":1310721,"n":"WebRequestMessage","d":1287468,"h":124555339052,"f":4194344},{"t":1310721,"n":"WebRequestDiagId","d":1287468,"h":128850306348,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":1287468,"h":133145273644,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":1287468,"h":137440240940,"f":4194344},{"t":1310721,"n":"GetContextInfoMessage","d":1287468,"h":141735208236,"f":4194344},{"t":1310721,"n":"GetContextInfoDiagId","d":1287468,"h":146030175532,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairMessage","d":1287468,"h":150325142828,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":1287468,"h":154620110124,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":1287468,"h":158915077420,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":1287468,"h":163210044716,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":1287468,"h":167505012012,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":1287468,"h":171799979308,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":1287468,"h":176094946604,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":1287468,"h":180389913900,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":1287468,"h":184684881196,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":1287468,"h":188979848492,"f":4194344},{"t":1310721,"n":"RijndaelMessage","d":1287468,"h":193274815788,"f":4194344},{"t":1310721,"n":"RijndaelDiagId","d":1287468,"h":197569783084,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":1287468,"h":201864750380,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":1287468,"h":206159717676,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":1287468,"h":210454684972,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":1287468,"h":214749652268,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":1287468,"h":219044619564,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":1287468,"h":223339586860,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableMessage","d":1287468,"h":227634554156,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":1287468,"h":231929521452,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyMessage","d":1287468,"h":236224488748,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":1287468,"h":240519456044,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":1287468,"h":244814423340,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":1287468,"h":249109390636,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":1287468,"h":253404357932,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":1287468,"h":257699325228,"f":4194344},{"t":1310721,"n":"UseManagedSha1Message","d":1287468,"h":261994292524,"f":4194344},{"t":1310721,"n":"UseManagedSha1DiagId","d":1287468,"h":266289259820,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":1287468,"h":270584227116,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":1287468,"h":274879194412,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":1287468,"h":279174161708,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":1287468,"h":283469129004,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":1287468,"h":287764096300,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":1287468,"h":292059063596,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":1287468,"h":296354030892,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":1287468,"h":300648998188,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":1287468,"h":304943965484,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":1287468,"h":309238932780,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":1287468,"h":313533900076,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":1287468,"h":317828867372,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersMessage","d":1287468,"h":322123834668,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":1287468,"h":326418801964,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":1287468,"h":330713769260,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":1287468,"h":335008736556,"f":4194344},{"t":1310721,"n":"TlsVersion10and11Message","d":1287468,"h":339303703852,"f":4194344},{"t":1310721,"n":"TlsVersion10and11DiagId","d":1287468,"h":343598671148,"f":4194344},{"t":1310721,"n":"EncryptionPolicyMessage","d":1287468,"h":347893638444,"f":4194344},{"t":1310721,"n":"EncryptionPolicyDiagId","d":1287468,"h":352188605740,"f":4194344},{"t":1310721,"n":"EccXmlExportImportMessage","d":1287468,"h":356483573036,"f":4194344},{"t":1310721,"n":"EccXmlExportImportDiagId","d":1287468,"h":360778540332,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":1287468,"h":365073507628,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":1287468,"h":369368474924,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":1287468,"h":373663442220,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":1287468,"h":377958409516,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryMessage","d":1287468,"h":382253376812,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":1287468,"h":386548344108,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunMessage","d":1287468,"h":390843311404,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":1287468,"h":395138278700,"f":4194344},{"t":1310721,"n":"XmlSecureResolverMessage","d":1287468,"h":399433245996,"f":4194344},{"t":1310721,"n":"XmlSecureResolverDiagId","d":1287468,"h":403728213292,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":1287468,"h":408023180588,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":1287468,"h":412318147884,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":1287468,"h":416613115180,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":1287468,"h":420908082476,"f":4194344},{"t":1310721,"n":"LegacyFormatterMessage","d":1287468,"h":425203049772,"f":4194344},{"t":1310721,"n":"LegacyFormatterDiagId","d":1287468,"h":429498017068,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplMessage","d":1287468,"h":433792984364,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":1287468,"h":438087951660,"f":4194344},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":1287468,"h":442382918956,"f":4194344},{"t":1310721,"n":"RegexExtensibilityDiagId","d":1287468,"h":446677886252,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":1287468,"h":450972853548,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":1287468,"h":455267820844,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":1287468,"h":459562788140,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":1287468,"h":463857755436,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":1287468,"h":468152722732,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":1287468,"h":472447690028,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":1287468,"h":476742657324,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":1287468,"h":481037624620,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":1287468,"h":485332591916,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":1287468,"h":489627559212,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":1287468,"h":493922526508,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":1287468,"h":498217493804,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":1287468,"h":502512461100,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":1287468,"h":506807428396,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":1287468,"h":511102395692,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":1287468,"h":515397362988,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":1287468,"h":519692330284,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":1287468,"h":523987297580,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":1287468,"h":528282264876,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":1287468,"h":532577232172,"f":4194344}],"h":1287468}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$spu.System.Net.IPv6AddressHelper", ($self) => class IPv6AddressHelper
        {
            static /*string */ ParseCanonicalName(/*ReadOnlySpan<char>*/ str, /*ref bool*/ isLoopback, /*out ReadOnlySpan<char>*/ scopeId)
            {
                /*Span<ushort>*/ let numbers = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.UInt16, 8/*NumberOfLabels*/, null);
                numbers.Clear();
                $.$spu.System.Net.IPv6AddressHelper.Parse($.$$.System.Char, str, numbers, scopeId);
                isLoopback.$v = $.$spu.System.Net.IPv6AddressHelper.IsLoopback($.$$.System.Span$$($.$$.System.UInt16).op_Implicit(numbers));
                const { Item1: rangeStart, Item2: rangeEnd } = $.$spu.System.Net.IPv6AddressHelper.FindCompressionRange($.$$.System.Span$$($.$$.System.UInt16).op_Implicit(numbers));
                /*bool*/ let ipv4Embedded = $.$spu.System.Net.IPv6AddressHelper.ShouldHaveIpv4Embedded($.$$.System.Span$$($.$$.System.UInt16).op_Implicit(numbers));
                /*Span<char>*/ let stackSpace = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 48, null);
                stackSpace.get_Item(0).$v = /*[*/ 91;
                /*int*/ let pos = 1;
                /*int*/ let charsWritten;
                /*bool*/ let success;
                for(/*int*/ let i = 0; i < 8/*NumberOfLabels*/; i++)
                {
                    if (ipv4Embedded && i === (((8/*NumberOfLabels*/ - 2) | 0)))
                    {
                        stackSpace.get_Item(pos++).$v = /*:*/ 58;
                        success = $.$$.System.Int32.TryFormat$1.call((numbers.get_Item(i).$v >>> 8), stackSpace.Slice$1(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                        $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                        pos += charsWritten;
                        stackSpace.get_Item(pos++).$v = /*.*/ 46;
                        success = $.$$.System.Int32.TryFormat$1.call((numbers.get_Item(i).$v & 255), stackSpace.Slice$1(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                        $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                        pos += charsWritten;
                        stackSpace.get_Item(pos++).$v = /*.*/ 46;
                        success = $.$$.System.Int32.TryFormat$1.call((numbers.get_Item(((i + 1) | 0)).$v >>> 8), stackSpace.Slice$1(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                        $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                        pos += charsWritten;
                        stackSpace.get_Item(pos++).$v = /*.*/ 46;
                        success = $.$$.System.Int32.TryFormat$1.call((numbers.get_Item(((i + 1) | 0)).$v & 255), stackSpace.Slice$1(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                        $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                        pos += charsWritten;
                        break;
                    }
                    if (rangeStart === i)
                    {
                        stackSpace.get_Item(pos++).$v = /*:*/ 58;
                    }
                    if (rangeStart <= i && rangeEnd === 8/*NumberOfLabels*/)
                    {
                        stackSpace.get_Item(pos++).$v = /*:*/ 58;
                        break;
                    }
                    if (rangeStart <= i && i < rangeEnd)
                    {
                        continue;
                    }
                    if (i !== 0)
                    {
                        stackSpace.get_Item(pos++).$v = /*:*/ 58;
                    }
                    success = $.$$.System.UInt16.TryFormat$1.call(numbers.get_Item(i).$v, stackSpace.Slice$1(pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), $.$$.System.String.op_Implicit("x"), null);
                    $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                    pos += charsWritten;
                }
                stackSpace.get_Item(pos++).$v = /*]*/ 93;
                return $.$$.System.String.Create$2($.$$.System.Span$$($.$$.System.Char).op_Implicit(stackSpace.Slice(0, pos)));
            }
            static /*bool */ IsLoopback(/*ReadOnlySpan<ushort>*/ numbers)
            {
                return ((numbers.get_Item(0).$v === 0) && (numbers.get_Item(1).$v === 0) && (numbers.get_Item(2).$v === 0) && (numbers.get_Item(3).$v === 0) && (numbers.get_Item(4).$v === 0)) && (((numbers.get_Item(5).$v === 0) && (numbers.get_Item(6).$v === 0) && (numbers.get_Item(7).$v === 1)) || (((numbers.get_Item(6).$v === 32512) && (numbers.get_Item(7).$v === 1)) && ((numbers.get_Item(5).$v === 0) || (numbers.get_Item(5).$v === 65535))));
            }
            static /*bool */ InternalIsValid(/*char**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ validateStrictAddress)
            {
                /*int*/ let sequenceCount = 0;
                /*int*/ let sequenceLength = 0;
                /*bool*/ let haveCompressor = false;
                /*bool*/ let haveIPv4Address = false;
                /*bool*/ let havePrefix = false;
                /*bool*/ let expectingNumber = true;
                /*int*/ let lastSequence = 1;
                if (name.GetAt(start) === /*:*/ 58 && (((start + 1) | 0) >= end.$v || name.GetAt(((start + 1) | 0)) !== /*:*/ 58))
                {
                    return false;
                }
                /*int*/ let i;
                for(i = start; i < end.$v; ++i)
                {
                    if (havePrefix ? $.$$.System.Char.IsAsciiDigit(name.GetAt(i)) : $.$$.System.Char.IsAsciiHexDigit(name.GetAt(i)))
                    {
                        ++sequenceLength;
                        expectingNumber = false;
                    }
                    else 
                    {
                        if (sequenceLength > 4)
                        {
                            return false;
                        }
                        if (sequenceLength !== 0)
                        {
                            ++sequenceCount;
                            lastSequence = ((i - sequenceLength) | 0);
                        }
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            let $switch1 = $switchJumpState1 ?? (name.get_Item(i).$v);
                            switch($switch1)
                            {
                                case /*%*/ 37:
                                while(true)
                                {
                                    if (++i === end.$v)
                                    {
                                        return false;
                                    }
                                    if (name.GetAt(i) === /*]*/ 93)
                                    {
                                        $switchJumpState1 = /*]*/ 93; /*goto case ']'*/
                                        continue $switchJumpStart1;
                                    }
                                    else if (name.GetAt(i) === /*/*/ 47)
                                    {
                                        $switchJumpState1 = /*/*/ 47; /*goto case '/'*/
                                        continue $switchJumpStart1;
                                    }
                                }
                                case /*]*/ 93:
                                start = i;
                                i = end.$v;
                                continue;
                                case /*:*/ 58:
                                if ((i > 0) && (name.GetAt(((i - 1) | 0)) === /*:*/ 58))
                                {
                                    if (haveCompressor)
                                    {
                                        return false;
                                    }
                                    haveCompressor = true;
                                    expectingNumber = false;
                                }
                                else 
                                {
                                    expectingNumber = true;
                                }
                                break;
                                case /*/*/ 47:
                                if (validateStrictAddress)
                                {
                                    return false;
                                }
                                if ((sequenceCount === 0) || havePrefix)
                                {
                                    return false;
                                }
                                havePrefix = true;
                                expectingNumber = true;
                                break;
                                case /*.*/ 46:
                                if (haveIPv4Address)
                                {
                                    return false;
                                }
                                i = end.$v;
                                if (!$.$spu.System.Net.IPv4AddressHelper.IsValid($.$$.System.Char, name, lastSequence, $.$ref(() => i, ($v) => i = $v, $.$$.System.Int32), true, false, false))
                                {
                                    return false;
                                }
                                ++sequenceCount;
                                haveIPv4Address = true;
                                --i;
                                break;
                                default:
                                return false;
                            }
                            break;
                        }
                        sequenceLength = 0;
                    }
                }
                if (havePrefix && ((sequenceLength < 1) || (sequenceLength > 2)))
                {
                    return false;
                }
                /*int*/ let expectedSequenceCount = ((8 + (havePrefix ? 1 : 0)) | 0);
                if (!expectingNumber && (sequenceLength <= 4) && (haveCompressor ? (sequenceCount < expectedSequenceCount) : (sequenceCount === expectedSequenceCount)))
                {
                    if (i === ((end.$v + 1) | 0))
                    {
                        end.$v = ((start + 1) | 0);
                        return true;
                    }
                    return false;
                }
                return false;
            }
            static /*bool */ IsValid(/*char**/ name, /*int*/ start, /*ref int*/ end)
            {
                return $.$spu.System.Net.IPv6AddressHelper.InternalIsValid(name, start, end, false);
            }
            /*int*/ static Hex = 16;
            /*int*/ static NumberOfLabels = 8;
            static /*(int longestSequenceStart, int longestSequenceLength) */ FindCompressionRange(/*ReadOnlySpan<ushort>*/ numbers)
            {
                /*int*/ let longestSequenceLength = 0, longestSequenceStart = -1, currentSequenceLength = 0;
                for(/*int*/ let i = 0; i < numbers.Length; i++)
                {
                    if (numbers.get_Item(i).$v === 0)
                    {
                        currentSequenceLength++;
                        if (currentSequenceLength > longestSequenceLength)
                        {
                            longestSequenceLength = currentSequenceLength;
                            longestSequenceStart = ((((i - currentSequenceLength) | 0) + 1) | 0);
                        }
                    }
                    else 
                    {
                        currentSequenceLength = 0;
                    }
                }
                return longestSequenceLength > 1 ? new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(longestSequenceStart, ((longestSequenceStart + longestSequenceLength) | 0)) : new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(-1, 0);
            }
            static /*bool */ ShouldHaveIpv4Embedded(/*ReadOnlySpan<ushort>*/ numbers)
            {
                if (numbers.get_Item(0).$v === 0 && numbers.get_Item(1).$v === 0 && numbers.get_Item(2).$v === 0 && numbers.get_Item(3).$v === 0 && numbers.get_Item(6).$v !== 0)
                {
                    if (numbers.get_Item(4).$v === 0 && (numbers.get_Item(5).$v === 0 || numbers.get_Item(5).$v === 65535))
                    {
                        return true;
                    }
                    else if (numbers.get_Item(4).$v === 65535 && numbers.get_Item(5).$v === 0)
                    {
                        return true;
                    }
                }
                return numbers.get_Item(4).$v === 0 && numbers.get_Item(5).$v === 24318;
            }
            static /*bool */ IsValidStrict(TChar, /*TChar**/ name, /*int*/ start, /*int*/ end)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let sequenceCount = 0;
                /*int*/ let sequenceLength = 0;
                /*bool*/ let haveCompressor = false;
                /*bool*/ let haveIPv4Address = false;
                /*bool*/ let expectingNumber = true;
                /*int*/ let lastSequence = 1;
                /*bool*/ let needsClosingBracket = false;
                if (start < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(start), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*[*/ 91)))
                {
                    start++;
                    needsClosingBracket = true;
                    $.$$.System.Diagnostics.Debug.Assert$2(start < end, "start < end");
                }
                if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(start), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58)) && (((start + 1) | 0) >= end || TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(name.GetAt(((start + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58))))
                {
                    return false;
                }
                /*int*/ let i;
                for(i = start; i < end; ++i)
                {
                    /*int*/ let currentCh = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i));
                    if ($.$spu.System.HexConverter.IsHexChar(currentCh))
                    {
                        ++sequenceLength;
                        expectingNumber = false;
                    }
                    else 
                    {
                        if (sequenceLength > 4)
                        {
                            return false;
                        }
                        if (sequenceLength !== 0)
                        {
                            ++sequenceCount;
                            lastSequence = ((i - sequenceLength) | 0);
                            sequenceLength = 0;
                        }
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? currentCh)
                            {
                                case /*%*/ 37:
                                while(((i + 1) | 0) < end)
                                {
                                    i++;
                                    if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(i), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)))
                                    {
                                        $switchJumpState1 = /*]*/ 93; /*goto case ']'*/
                                        continue $switchJumpStart1;
                                    }
                                    else if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(i), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*/*/ 47)))
                                    {
                                        $switchJumpState1 = /*/*/ 47; /*goto case '/'*/
                                        continue $switchJumpStart1;
                                    }
                                }
                                break;
                                case /*]*/ 93:
                                if (!needsClosingBracket)
                                {
                                    return false;
                                }
                                needsClosingBracket = false;
                                if (((i + 1) | 0) < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(name.GetAt(((i + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58)))
                                {
                                    return false;
                                }
                                if (((i + 3) | 0) < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i + 2) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*0*/ 48)) && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i + 3) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*x*/ 120)))
                                {
                                    i += 4;
                                    for(; i < end; i++)
                                    {
                                        /*int*/ let ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i));
                                        if (!$.$spu.System.HexConverter.IsHexChar(ch))
                                        {
                                            return false;
                                        }
                                    }
                                }
                                else 
                                {
                                    i += 2;
                                    for(; i < end; i++)
                                    {
                                        if (!$.$$.System.Char.IsAsciiDigit($.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i))))
                                        {
                                            return false;
                                        }
                                    }
                                }
                                continue;
                                case /*:*/ 58:
                                if ((i > 0) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i - 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58))))
                                {
                                    if (haveCompressor)
                                    {
                                        return false;
                                    }
                                    haveCompressor = true;
                                    expectingNumber = false;
                                }
                                else 
                                {
                                    expectingNumber = true;
                                }
                                break;
                                case /*/*/ 47:
                                return false;
                                case /*.*/ 46:
                                if (haveIPv4Address)
                                {
                                    return false;
                                }
                                i = end;
                                if (!$.$spu.System.Net.IPv4AddressHelper.IsValid(TChar, name, lastSequence, $.$ref(() => i, ($v) => i = $v, $.$$.System.Int32), true, false, false))
                                {
                                    return false;
                                }
                                ++sequenceCount;
                                lastSequence = ((i - sequenceLength) | 0);
                                sequenceLength = 0;
                                haveIPv4Address = true;
                                --i;
                                break;
                                default:
                                return false;
                            }
                            break;
                        }
                        sequenceLength = 0;
                    }
                }
                if (sequenceLength !== 0)
                {
                    if (sequenceLength > 4)
                    {
                        return false;
                    }
                    ++sequenceCount;
                }
                /*int*/ let ExpectedSequenceCount = 8;
                return !expectingNumber && (haveCompressor ? (sequenceCount < ExpectedSequenceCount) : (sequenceCount === ExpectedSequenceCount)) && !needsClosingBracket;
            }
            static /*void */ Parse(TChar, /*ReadOnlySpan<TChar>*/ address, /*scoped Span<ushort>*/ numbers, /*out ReadOnlySpan<TChar>*/ scopeId)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let number = 0;
                /*int*/ let currentCh;
                /*int*/ let index = 0;
                /*int*/ let compressorIndex = -1;
                /*bool*/ let numberIsValid = true;
                scopeId.$v = $.$$.System.ReadOnlySpan$$(TChar).Empty;
                for(/*int*/ let i = (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(0).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*[*/ 91)) ? 1 : 0); i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)); )
                {
                    currentCh = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, address.get_Item(i).$v);
                    switch(currentCh)
                    {
                        case /*%*/ 37:
                        if (numberIsValid)
                        {
                            numbers.get_Item(index++).$v = $.$cast(number, $.$$.System.UInt16);
                            numberIsValid = false;
                        }
                        /*int*/ let scopeStart = i;
                        for(++i; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)) && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*/*/ 47)); ++i)
                        {
                        }
                        scopeId.$v = address.Slice(scopeStart, ((i - scopeStart) | 0));
                        for(; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)); ++i)
                        {
                        }
                        break;
                        case /*:*/ 58:
                        numbers.get_Item(index++).$v = $.$cast(number, $.$$.System.UInt16);
                        number = 0;
                        ++i;
                        if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58)))
                        {
                            compressorIndex = index;
                            ++i;
                        }
                        else if ((compressorIndex < 0) && (index < 6))
                        {
                            break;
                        }
                        for(/*int*/ let j = i; j < address.Length && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*%*/ 37))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*/*/ 47))) && (j < ((i + 4) | 0)); ++j)
                        {
                            if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*.*/ 46)))
                            {
                                while(j < address.Length && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*/*/ 47))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*%*/ 37))))
                                {
                                    ++j;
                                }
                                /*int*/ let ipv4Address = $.$spu.System.Net.IPv4AddressHelper.ParseHostNumber(TChar, address, i, j);
                                numbers.get_Item(index++).$v = $.$cast((ipv4Address >> 16), $.$$.System.UInt16);
                                numbers.get_Item(index++).$v = $.$cast((ipv4Address & 65535), $.$$.System.UInt16);
                                i = j;
                                number = 0;
                                numberIsValid = false;
                                break;
                            }
                        }
                        break;
                        case /*/*/ 47:
                        if (numberIsValid)
                        {
                            numbers.get_Item(index++).$v = $.$cast(number, $.$$.System.UInt16);
                            numberIsValid = false;
                        }
                        for(++i; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)); i++)
                        {
                        }
                        break;
                        default:
                        /*int*/ let characterValue = $.$spu.System.HexConverter.FromChar(currentCh);
                        number = ((((number * 16/*IPv6AddressHelper.Hex*/) | 0) + characterValue) | 0);
                        i++;
                        break;
                    }
                }
                if (numberIsValid)
                {
                    numbers.get_Item(index++).$v = $.$cast(number, $.$$.System.UInt16);
                }
                if (compressorIndex > 0)
                {
                    /*int*/ let toIndex = ((8/*NumberOfLabels*/ - 1) | 0);
                    /*int*/ let fromIndex = ((index - 1) | 0);
                    if (fromIndex !== toIndex)
                    {
                        for(/*int*/ let i = ((index - compressorIndex) | 0); i > 0; --i)
                        {
                            numbers.get_Item(toIndex--).$v = numbers.get_Item(fromIndex).$v;
                            numbers.get_Item(fromIndex--).$v = 0;
                        }
                    }
                }
            }
            static $h = 1025324;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"str","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"isLoopback","p":262145,"f":4},{"n":"scopeId","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"f":2}],"n":"ParseCanonicalName","d":1025324,"h":4295992620,"f":16777256},{"r":262145,"p":[{"n":"numbers","p":$.$$.System.ReadOnlySpan$$($.$$.System.UInt16).$h}],"n":"IsLoopback","d":1025324,"h":8590959916,"f":16777250},{"r":262145,"p":[{"n":"name","p":$.$typePointer($.$$.System.Char).$h},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"validateStrictAddress","p":262145}],"n":"InternalIsValid","d":1025324,"h":12885927212,"f":16777250},{"r":262145,"p":[{"n":"name","p":$.$typePointer($.$$.System.Char).$h},{"n":"start","p":655361},{"n":"end","p":655361,"f":4}],"n":"IsValid","d":1025324,"h":17180894508,"f":16777256},{"r":$.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32).$h,"p":[{"n":"numbers","p":$.$$.System.ReadOnlySpan$$($.$$.System.UInt16).$h}],"n":"FindCompressionRange","d":1025324,"h":30065796396,"f":16777256},{"r":262145,"p":[{"n":"numbers","p":$.$$.System.ReadOnlySpan$$($.$$.System.UInt16).$h}],"n":"ShouldHaveIpv4Embedded","d":1025324,"h":34360763692,"f":16777256},{"r":262145,"p":[{"n":"name","p":(TChar) => $.$typePointer(TChar).$h},{"n":"start","p":655361},{"n":"end","p":655361}],"g":["TChar"],"n":"IsValidStrict","d":1025324,"h":38655730988,"f":16908328},{"r":65537,"p":[{"n":"address","p":(TChar) => $.$$.System.ReadOnlySpan$$(TChar).$h},{"n":"numbers","p":$.$$.System.Span$$($.$$.System.UInt16).$h},{"n":"scopeId","p":(TChar) => $.$$.System.ReadOnlySpan$$(TChar).$h,"f":2}],"g":["TChar"],"n":"Parse","d":1025324,"h":42950698284,"f":16908328}],"l":[{"t":655361,"n":"Hex","d":1025324,"h":21475861804,"f":4194338},{"t":655361,"n":"NumberOfLabels","d":1025324,"h":25770829100,"f":4194338}],"h":1025324}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.IPv6AddressHelper`; }
        });
        
        $asm.$cls("$spu.System.IriHelper", ($self) => class IriHelper
        {
            static /*bool */ CheckIriUnicodeRange(/*char*/ unicode, /*bool*/ isQuery)
            {
                return $.$spu.System.IriHelper.IsInInclusiveRange(unicode, /*\u00A0*/ 160, /*\uD7FF*/ 55295) || $.$spu.System.IriHelper.IsInInclusiveRange(unicode, /*\uF900*/ 63744, /*\uFDCF*/ 64975) || $.$spu.System.IriHelper.IsInInclusiveRange(unicode, /*\uFDF0*/ 65008, /*\uFFEF*/ 65519) || (isQuery && $.$spu.System.IriHelper.IsInInclusiveRange(unicode, /*\uE000*/ 57344, /*\uF8FF*/ 63743));
            }
            static /*bool */ CheckIriUnicodeRange$1(/*char*/ highSurr, /*char*/ lowSurr, /*out bool*/ isSurrogatePair, /*bool*/ isQuery)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Char.IsHighSurrogate(highSurr), "char.IsHighSurrogate(highSurr)");
                /*Rune*/ let rune;
                if ($.$$.System.Text.Rune.TryCreate(highSurr, lowSurr, $.$ref(() => rune, ($v) => rune = $v, $.$$.System.Text.Rune)))
                {
                    isSurrogatePair.$v = true;
                    return ((rune.Value & 65535) < 65534) && (((((rune.Value - 917504) | 0)) >>> 0) >= (((921600 - 917504) | 0))) && (isQuery || rune.Value < 983040);
                }
                isSurrogatePair.$v = false;
                return false;
            }
            static /*bool */ CheckIriUnicodeRange$2(/*uint*/ value, /*bool*/ isQuery)
            {
                if (value <= 65535)
                {
                    return $.$spu.System.IriHelper.IsInInclusiveRange(value, /*\u00A0*/ 160, /*\uD7FF*/ 55295) || $.$spu.System.IriHelper.IsInInclusiveRange(value, /*\uF900*/ 63744, /*\uFDCF*/ 64975) || $.$spu.System.IriHelper.IsInInclusiveRange(value, /*\uFDF0*/ 65008, /*\uFFEF*/ 65519) || (isQuery && $.$spu.System.IriHelper.IsInInclusiveRange(value, /*\uE000*/ 57344, /*\uF8FF*/ 63743));
                }
                else 
                {
                    return ((value & 65535) < 65534) && !$.$spu.System.IriHelper.IsInInclusiveRange(value, 917504, 921599) && (isQuery || value < 983040);
                }
            }
            static /*bool */ IsInInclusiveRange(/*uint*/ value, /*uint*/ min, /*uint*/ max)
            {
                return ((((value - min) >>> 0)) >>> 0) <= ((((max - min) >>> 0)) >>> 0);
            }
            static /*bool */ CheckIsReserved(/*char*/ ch, /*UriComponents*/ component)
            {
                if ((127/*UriComponents.AbsoluteUri*/ & component) === 0)
                {
                    return component === 0 && $.$spu.System.UriHelper.IsGenDelim(ch);
                }
                return $.$$.System.String.Contains$1.call(";/?:@&=+$,#[]!'()*"/*UriHelper.RFC3986ReservedMarks*/, ch);
            }
            static /*string */ EscapeUnescapeIri(/*char**/ pInput, /*int*/ start, /*int*/ end, /*UriComponents*/ component)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(end >= 0 && start >= 0 && start <= end, "end >= 0 && start >= 0 && start <= end");
                /*int*/ let size = ((end - start) | 0);
                /*var*/ let dest = size <= 512/*Uri.StackallocThreshold*/ ? new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*Uri.StackallocThreshold*/, null)) : new $.$spu.System.Text.ValueStringBuilder().$ctor$3(size);
                /*Span<byte>*/ let maxUtf8EncodedSpan = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 4, null);
                for(/*int*/ let i = start; i < end; ++i)
                {
                    /*char*/ let ch = pInput.GetAt(i);
                    if (ch === /*%*/ 37)
                    {
                        if (((end - i) | 0) > 2)
                        {
                            ch = $.$spu.System.UriHelper.DecodeHexChars(pInput.GetAt(((i + 1) | 0)), pInput.GetAt(((i + 2) | 0)));
                            if (ch === /*\uFFFF*/ 65535 || ch === /*%*/ 37 || $.$spu.System.IriHelper.CheckIsReserved(ch, component) || $.$spu.System.UriHelper.IsNotSafeForUnescape(ch))
                            {
                                dest.Append$1(pInput.GetAt(i++));
                                dest.Append$1(pInput.GetAt(i++));
                                dest.Append$1(pInput.GetAt(i));
                                continue;
                            }
                            else if (ch <= /*\u007F*/ 127)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(ch < 255, "Expecting ASCII character.");
                                dest.Append$1(ch);
                                i += 2;
                                continue;
                            }
                            else 
                            {
                                /*int*/ let charactersRead = $.$spu.System.PercentEncodingHelper.UnescapePercentEncodedUTF8Sequence(pInput.Add(i), ((end - i) | 0), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null), component === 32/*UriComponents.Query*/, true);
                                $.$$.System.Diagnostics.Debug.Assert$2(charactersRead > 0, "charactersRead > 0");
                                i += ((charactersRead - 1) | 0);
                            }
                        }
                        else 
                        {
                            dest.Append$1(pInput.GetAt(i));
                        }
                    }
                    else if (ch > /*\u007F*/ 127)
                    {
                        /*bool*/ let isInIriUnicodeRange;
                        /*bool*/ let surrogatePair = false;
                        /*char*/ let ch2 = /*\u0000*/ 0;
                        if (($.$$.System.Char.IsHighSurrogate(ch)) && (((i + 1) | 0) < end))
                        {
                            ch2 = pInput.GetAt(((i + 1) | 0));
                            isInIriUnicodeRange = $.$spu.System.IriHelper.CheckIriUnicodeRange$1(ch, ch2, $.$ref(() => surrogatePair, ($v) => surrogatePair = $v, $.$$.System.Boolean), component === 32/*UriComponents.Query*/);
                        }
                        else 
                        {
                            isInIriUnicodeRange = $.$spu.System.IriHelper.CheckIriUnicodeRange(ch, component === 32/*UriComponents.Query*/);
                        }
                        if (isInIriUnicodeRange)
                        {
                            dest.Append$1(ch);
                            if (surrogatePair)
                            {
                                dest.Append$1(ch2);
                            }
                        }
                        else 
                        {
                            /*Rune*/ let rune;
                            if (surrogatePair)
                            {
                                rune = new $.$$.System.Text.Rune().$ctor$3(ch, ch2);
                            }
                            else if (!$.$$.System.Text.Rune.TryCreate$1(ch, $.$ref(() => rune, ($v) => rune = $v, $.$$.System.Text.Rune)))
                            {
                                rune = $.$$.System.Text.Rune.ReplacementChar;
                            }
                            /*int*/ let bytesWritten = rune.EncodeToUtf8(maxUtf8EncodedSpan);
                            /*ReadOnlySpan<byte>*/ let encodedBytes = $.$$.System.Span$$($.$$.System.Byte).op_Implicit(maxUtf8EncodedSpan.Slice(0, bytesWritten));
                            var $en5 = encodedBytes.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var b = $en5.Current.$v;
                                {
                                    $.$spu.System.UriHelper.PercentEncodeByte(b, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null));
                                }
                            }
                        }
                        if (surrogatePair)
                        {
                            i++;
                        }
                    }
                    else 
                    {
                        dest.Append$1(pInput.GetAt(i));
                    }
                }
                return $.$spu.System.Text.ValueStringBuilder.ToString.call(dest);
            }
            static $h = 828716;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"unicode","p":458753},{"n":"isQuery","p":262145}],"n":"CheckIriUnicodeRange","d":828716,"h":4295796012,"f":16777256},{"r":262145,"p":[{"n":"highSurr","p":458753},{"n":"lowSurr","p":458753},{"n":"isSurrogatePair","p":262145,"f":2},{"n":"isQuery","p":262145}],"n":"CheckIriUnicodeRange","o":"@$1","d":828716,"h":8590763308,"f":16777256},{"r":262145,"p":[{"n":"value","p":720897},{"n":"isQuery","p":262145}],"n":"CheckIriUnicodeRange","o":"@$2","d":828716,"h":12885730604,"f":16777256},{"r":262145,"p":[{"n":"value","p":720897},{"n":"min","p":720897},{"n":"max","p":720897}],"n":"IsInInclusiveRange","d":828716,"h":17180697900,"f":16777249},{"r":262145,"p":[{"n":"ch","p":458753},{"n":"component","p":2204972}],"n":"CheckIsReserved","d":828716,"h":21475665196,"f":16777256},{"r":1310721,"p":[{"n":"pInput","p":$.$typePointer($.$$.System.Char).$h},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"component","p":2204972}],"n":"EscapeUnescapeIri","d":828716,"h":25770632492,"f":16777256}],"h":828716}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IriHelper`; }
        });
        
        $asm.$cls("$spu.System.Net.IPv4AddressHelper", ($self) => class IPv4AddressHelper
        {
            static /*string */ ParseCanonicalName(/*string*/ str, /*int*/ start, /*int*/ end, /*ref bool*/ isLoopback)
            {
                /*int*/ let changedEnd = end;
                /*long*/ let result;
                {
                    /*fixed*/ 
                    {
                        /*char**/ let ipString = $.$$.System.String.GetPinnableReference.call(str);
                        result = $.$spu.System.Net.IPv4AddressHelper.ParseNonCanonical($.$$.System.Char, ipString, start, $.$ref(() => changedEnd, ($v) => changedEnd = $v, $.$$.System.Int32), true);
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$4(result !== -1n, `Failed to parse after already validated: ${str}`);
                /*Span<byte>*/ let numbers = $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), [$.$cast((result >> 24n), $.$$.System.Byte), $.$cast((result >> 16n), $.$$.System.Byte), $.$cast((result >> 8n), $.$$.System.Byte), $.$cast((result), $.$$.System.Byte)], null, null));
                isLoopback.$v = numbers.get_Item(0).$v === 127;
                /*Span<char>*/ let stackSpace = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, ((((4/*NumberOfLabels*/ * 3) | 0) + 3) | 0), null);
                /*int*/ let totalChars = 0, charsWritten;
                for(/*int*/ let i = 0; i < ((4/*NumberOfLabels*/ - 1) | 0); i++)
                {
                    $.$$.System.Byte.TryFormat$1.call(numbers.get_Item(i).$v, stackSpace.Slice$1(totalChars), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                    /*int*/ let periodPos = ((totalChars + charsWritten) | 0);
                    stackSpace.get_Item(periodPos).$v = /*.*/ 46;
                    totalChars = ((periodPos + 1) | 0);
                }
                $.$$.System.Byte.TryFormat$1.call(numbers.get_Item(3).$v, stackSpace.Slice$1(totalChars), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                return $.$$.System.String.Create$2($.$$.System.Span$$($.$$.System.Char).op_Implicit(stackSpace.Slice(0, ((totalChars + charsWritten) | 0))));
            }
            /*long*/ static Invalid = -1n;
            /*long*/ static MaxIPv4Value = 4294967295n;
            /*int*/ static Octal = 8;
            /*int*/ static Decimal = 10;
            /*int*/ static Hex = 16;
            /*int*/ static NumberOfLabels = 4;
            static /*ushort */ ToUShort(TChar, /*TChar*/ value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                return $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) ? $.$cast($.$box(value, TChar), $.$$.System.Char) : $.$cast($.$box(value, TChar), $.$$.System.Byte);
            }
            static /*int */ ParseHostNumber(TChar, /*ReadOnlySpan<TChar>*/ str, /*int*/ start, /*int*/ end)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*Span<byte>*/ let numbers = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 4/*NumberOfLabels*/, null);
                for(/*int*/ let i = 0; i < numbers.Length; ++i)
                {
                    /*int*/ let b = 0;
                    /*int*/ let ch;
                    for(; (start < end) && (ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, str.get_Item(start).$v)) !== /*.*/ 46 && ch !== /*:*/ 58; ++start)
                    {
                        b = (((((((b * 10) | 0)) + ch) | 0) - /*0*/ 48) | 0);
                    }
                    numbers.get_Item(i).$v = $.$cast(b, $.$$.System.Byte);
                    ++start;
                }
                return $.$$.System.Buffers.Binary.BinaryPrimitives.ReadInt32BigEndian($.$$.System.Span$$($.$$.System.Byte).op_Implicit(numbers));
            }
            static /*bool */ IsValid(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ allowIPv6, /*bool*/ notImplicitFile, /*bool*/ unknownScheme)
            {
                if (allowIPv6 || unknownScheme)
                {
                    return $.$spu.System.Net.IPv4AddressHelper.IsValidCanonical(TChar, name, start, end, allowIPv6, notImplicitFile);
                }
                else 
                {
                    return $.$spu.System.Net.IPv4AddressHelper.ParseNonCanonical(TChar, name, start, end, notImplicitFile) !== -1n;
                }
            }
            static /*bool */ IsValidCanonical(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ allowIPv6, /*bool*/ notImplicitFile)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let dots = 0;
                /*long*/ let number = 0n;
                /*bool*/ let haveNumber = false;
                /*bool*/ let firstCharIsZero = false;
                while(start < end.$v)
                {
                    /*int*/ let ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(start));
                    if (allowIPv6)
                    {
                        if (ch === /*]*/ 93 || ch === /*/*/ 47 || ch === /*%*/ 37)
                        {
                            break;
                        }
                    }
                    else if (ch === /*/*/ 47 || ch === /*\\*/ 92 || (notImplicitFile && (ch === /*:*/ 58 || ch === /*?*/ 63 || ch === /*#*/ 35)))
                    {
                        break;
                    }
                    /*uint*/ let parsedCharacter = ((((ch - /*0*/ 48) | 0)) >>> 0);
                    if (parsedCharacter < 10/*IPv4AddressHelper.Decimal*/)
                    {
                        if (!haveNumber && parsedCharacter === 0)
                        {
                            if ((((start + 1) | 0) < end.$v) && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((start + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*0*/ 48)))
                            {
                                return false;
                            }
                            firstCharIsZero = true;
                        }
                        haveNumber = true;
                        number = number * BigInt(10/*IPv4AddressHelper.Decimal*/) + BigInt(parsedCharacter);
                        if (number > BigInt(255/*byte.MaxValue*/))
                        {
                            return false;
                        }
                    }
                    else if (ch === /*.*/ 46)
                    {
                        if (!haveNumber || (number > 0n && firstCharIsZero))
                        {
                            return false;
                        }
                        ++dots;
                        haveNumber = false;
                        number = 0n;
                        firstCharIsZero = false;
                    }
                    else 
                    {
                        return false;
                    }
                    ++start;
                }
                /*bool*/ let res = (dots === 3) && haveNumber;
                if (res)
                {
                    end.$v = start;
                }
                return res;
            }
            static /*long */ ParseNonCanonical(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ notImplicitFile)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let numberBase = 10/*IPv4AddressHelper.Decimal*/;
                /*int*/ let ch = 0;
                /*Span<long>*/ let parts = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Int64, 3, null);
                /*long*/ let currentValue = 0n;
                /*bool*/ let atLeastOneChar = false;
                /*int*/ let dotCount = 0;
                /*int*/ let current = start;
                for(; current < end.$v; current++)
                {
                    ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                    currentValue = 0n;
                    numberBase = 10/*IPv4AddressHelper.Decimal*/;
                    if (ch === /*0*/ 48)
                    {
                        current++;
                        atLeastOneChar = true;
                        if (current < end.$v)
                        {
                            ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                            if (ch === /*x*/ 120 || ch === /*X*/ 88)
                            {
                                numberBase = 16/*IPv4AddressHelper.Hex*/;
                                current++;
                                atLeastOneChar = false;
                            }
                            else 
                            {
                                numberBase = 8/*IPv4AddressHelper.Octal*/;
                            }
                        }
                    }
                    for(; current < end.$v; current++)
                    {
                        ch = $.$spu.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                        /*int*/ let digitValue = $.$spu.System.HexConverter.FromChar(ch);
                        if (digitValue >= numberBase)
                        {
                            break;
                        }
                        currentValue = (currentValue * BigInt(numberBase)) + BigInt(digitValue);
                        if (currentValue > 4294967295n)
                        {
                            return -1n;
                        }
                        atLeastOneChar = true;
                    }
                    if (current < end.$v && ch === /*.*/ 46)
                    {
                        if (dotCount >= 3 || !atLeastOneChar || currentValue > 255n)
                        {
                            return -1n;
                        }
                        parts.get_Item(dotCount).$v = currentValue;
                        dotCount++;
                        atLeastOneChar = false;
                        continue;
                    }
                    break;
                }
                if (!atLeastOneChar)
                {
                    return -1n;
                }
                else if (current >= end.$v)
                {
                }
                else if (ch === /*/*/ 47 || ch === /*\\*/ 92 || (notImplicitFile && (ch === /*:*/ 58 || ch === /*?*/ 63 || ch === /*#*/ 35)))
                {
                    end.$v = current;
                }
                else 
                {
                    return -1n;
                }
                switch(dotCount)
                {
                    case 0:
                    return currentValue;
                    case 1:
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    if (currentValue > 16777215n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | currentValue;
                    case 2:
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(1).$v <= 255n, "parts[1] <= 0xFF");
                    if (currentValue > 65535n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | (BigInt.asIntN(64, parts.get_Item(1).$v << 16n)) | currentValue;
                    case 3:
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(1).$v <= 255n, "parts[1] <= 0xFF");
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(2).$v <= 255n, "parts[2] <= 0xFF");
                    if (currentValue > 255n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | (BigInt.asIntN(64, parts.get_Item(1).$v << 16n)) | (BigInt.asIntN(64, parts.get_Item(2).$v << 8n)) | currentValue;
                    default:
                    return -1n;
                }
            }
            static $h = 959788;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"str","p":1310721},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"isLoopback","p":262145,"f":4}],"n":"ParseCanonicalName","d":959788,"h":4295927084,"f":16777256},{"r":589825,"p":[{"n":"value","p":(TChar) => TChar.$h}],"g":["TChar"],"n":"ToUShort","d":959788,"h":34360698156,"f":16908328},{"r":655361,"p":[{"n":"str","p":(TChar) => $.$$.System.ReadOnlySpan$$(TChar).$h},{"n":"start","p":655361},{"n":"end","p":655361}],"g":["TChar"],"n":"ParseHostNumber","d":959788,"h":38655665452,"f":16908328},{"r":262145,"p":[{"n":"name","p":(TChar) => $.$typePointer(TChar).$h},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"allowIPv6","p":262145},{"n":"notImplicitFile","p":262145},{"n":"unknownScheme","p":262145}],"g":["TChar"],"n":"IsValid","d":959788,"h":42950632748,"f":16908328},{"r":262145,"p":[{"n":"name","p":(TChar) => $.$typePointer(TChar).$h},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"allowIPv6","p":262145},{"n":"notImplicitFile","p":262145}],"g":["TChar"],"n":"IsValidCanonical","d":959788,"h":47245600044,"f":16908328},{"r":917505,"p":[{"n":"name","p":(TChar) => $.$typePointer(TChar).$h},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"notImplicitFile","p":262145}],"g":["TChar"],"n":"ParseNonCanonical","d":959788,"h":51540567340,"f":16908328}],"l":[{"t":917505,"n":"Invalid","d":959788,"h":8590894380,"f":4194344},{"t":917505,"n":"MaxIPv4Value","d":959788,"h":12885861676,"f":4194338},{"t":655361,"n":"Octal","d":959788,"h":17180828972,"f":4194338},{"t":655361,"n":"Decimal","d":959788,"h":21475796268,"f":4194338},{"t":655361,"n":"Hex","d":959788,"h":25770763564,"f":4194338},{"t":655361,"n":"NumberOfLabels","d":959788,"h":30065730860,"f":4194338}],"h":959788}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.IPv4AddressHelper`; }
        });
        
        $asm.$cls("$spu.System.PercentEncodingHelper", ($self) => class PercentEncodingHelper
        {
            static /*int */ UnescapePercentEncodedUTF8Sequence(/*char**/ input, /*int*/ length, /*ref ValueStringBuilder*/ dest, /*bool*/ isQuery, /*bool*/ iriParsing)
            {
                /*uint*/ let fourByteBuffer;
                /*int*/ let bytesLeftInBuffer;
                /*int*/ let totalCharsConsumed;
                /*int*/ let charsToCopy;
                /*int*/ let bytesConsumed;
                /*uint*/ let value;
                /*uint*/ let second;
                /*uint*/ let temp;
                /*int*/ let i;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(length >= 3, "length >= 3");
                            $.$$.System.Diagnostics.Debug.Assert$2(input.GetAt(0) === /*%*/ 37, "input[0] == '%'");
                            $.$$.System.Diagnostics.Debug.Assert$2($.$spu.System.UriHelper.DecodeHexChars(input.GetAt(1), input.GetAt(2)) !== /*\uFFFF*/ 65535, "UriHelper.DecodeHexChars(input[1], input[2]) != Uri.c_DummyChar");
                            $.$$.System.Diagnostics.Debug.Assert$2($.$spu.System.UriHelper.DecodeHexChars(input.GetAt(1), input.GetAt(2)) >= 128, "UriHelper.DecodeHexChars(input[1], input[2]) >= 128");
                            fourByteBuffer = 0;
                            bytesLeftInBuffer = 0;
                            totalCharsConsumed = 0;
                            charsToCopy = 0;
                            bytesConsumed = 0;
                        }
                        case 1: /*RefillBuffer*/
                        i = ((totalCharsConsumed + (((bytesLeftInBuffer * 3) | 0))) | 0);
                        case 2: /*ReadByteFromInput*/
                        if (((((length - i) | 0)) >>> 0) <= 2 || input.GetAt(i) !== /*%*/ 37)
                        {
                            $gotoJumpState1 = 5; /*goto NoMoreOrInvalidInput*/
                            continue $gotoJumpStart1;
                        }
                        value = input.GetAt(((i + 1) | 0));
                        if ($.$cast(((BigInt(value - /*A*/ 65)) & BigInt(~32)), $.$$.System.UInt32) <= (/*F*/ 70 - /*A*/ 65))
                        {
                            value = (((((value | 32) - /*a*/ 97) >>> 0) + 10) >>> 0);
                        }
                        else if ((((value - /*8*/ 56) >>> 0)) <= (/*9*/ 57 - /*8*/ 56))
                        {
                            value -= /*0*/ 48;
                        }
                        else 
                        {
                            $gotoJumpState1 = 5; /*goto NoMoreOrInvalidInput*/
                            continue $gotoJumpStart1;
                        }
                        second = ((input.GetAt(((i + 2) | 0)) - /*0*/ 48) >>> 0);
                        if (second <= 9)
                        {
                        }
                        else if ($.$cast(((BigInt(second - (/*A*/ 65 - /*0*/ 48))) & BigInt(~32)), $.$$.System.UInt32) <= (/*F*/ 70 - /*A*/ 65))
                        {
                            second = ((((((((second + /*0*/ 48) >>> 0)) | 32) - /*a*/ 97) >>> 0) + 10) >>> 0);
                        }
                        else 
                        {
                            $gotoJumpState1 = 5; /*goto NoMoreOrInvalidInput*/
                            continue $gotoJumpStart1;
                        }
                        value = ((value << 4) >>> 0) | second;
                        $.$$.System.Diagnostics.Debug.Assert$2(value >= 128, "value >= 128");
                        if ($.$$.System.BitConverter.IsLittleEndian)
                        {
                            fourByteBuffer = (fourByteBuffer >>> 8) | ((value << 24) >>> 0);
                        }
                        else 
                        {
                            fourByteBuffer = ((fourByteBuffer << 8) >>> 0) | value;
                        }
                        if (++bytesLeftInBuffer !== 4)
                        {
                            i += 3;
                            $gotoJumpState1 = 2; /*goto ReadByteFromInput*/
                            continue $gotoJumpStart1;
                        }
                        case 3: /*DecodeRune*/
                        $.$$.System.Diagnostics.Debug.Assert$2(totalCharsConsumed % 3 === 0, "totalCharsConsumed % 3 == 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(bytesLeftInBuffer === 2 || bytesLeftInBuffer === 3 || bytesLeftInBuffer === 4, "bytesLeftInBuffer == 2 || bytesLeftInBuffer == 3 || bytesLeftInBuffer == 4");
                        $.$$.System.Diagnostics.Debug.Assert$2((fourByteBuffer & ($.$$.System.BitConverter.IsLittleEndian ? 128 : 2147483648)) !== 0, "(fourByteBuffer & (BitConverter.IsLittleEndian ? 0x00000080 : 0x80000000)) != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2((BigInt(fourByteBuffer) & (BigInt($.$$.System.BitConverter.IsLittleEndian ? 32768 : 8388608))) !== 0n, "(fourByteBuffer & (BitConverter.IsLittleEndian ? 0x00008000 : 0x00800000)) != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(bytesLeftInBuffer < 3 || (BigInt(fourByteBuffer) & (BigInt($.$$.System.BitConverter.IsLittleEndian ? 8388608 : 32768))) !== 0n, "bytesLeftInBuffer < 3 || (fourByteBuffer & (BitConverter.IsLittleEndian ? 0x00800000 : 0x00008000)) != 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(bytesLeftInBuffer < 4 || (fourByteBuffer & ($.$$.System.BitConverter.IsLittleEndian ? 2147483648 : 128)) !== 0, "bytesLeftInBuffer < 4 || (fourByteBuffer & (BitConverter.IsLittleEndian ? 0x80000000 : 0x00000080)) != 0");
                        temp = fourByteBuffer;
                        /*Rune*/ let rune;
                        if ($.$$.System.Text.Rune.DecodeFromUtf8(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$5($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.UInt32, () => temp, ($v) => temp = $v, null), bytesLeftInBuffer), $.$ref(() => rune, ($v) => rune = $v, $.$$.System.Text.Rune), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.System.Int32)) === 0/*OperationStatus.Done*/)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$4(bytesConsumed >= 2, `Rune.DecodeFromUtf8 consumed ${bytesConsumed} bytes, likely indicating input was modified concurrently during UnescapePercentEncodedUTF8Sequence's execution`);
                            if (!iriParsing || $.$spu.System.IriHelper.CheckIriUnicodeRange$2((rune.Value >>> 0), isQuery))
                            {
                                if (charsToCopy !== 0)
                                {
                                    dest.$v.Append$2(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(input.Add(totalCharsConsumed).Add(-charsToCopy), charsToCopy));
                                    charsToCopy = 0;
                                }
                                dest.$v.Append$4(rune);
                                $gotoJumpState1 = 4; /*goto AfterDecodeRune*/
                                continue $gotoJumpStart1;
                            }
                        }
                        else 
                        {
                            $.$$.System.Diagnostics.Debug.Assert$4(bytesConsumed > 0, `Rune.DecodeFromUtf8 consumed ${bytesConsumed} bytes when decoding ${bytesLeftInBuffer} bytes`);
                        }
                        charsToCopy += ((bytesConsumed * 3) | 0);
                        case 4: /*AfterDecodeRune*/
                        bytesLeftInBuffer -= bytesConsumed;
                        totalCharsConsumed += ((bytesConsumed * 3) | 0);
                        $gotoJumpState1 = 1; /*goto RefillBuffer*/
                        continue $gotoJumpStart1;
                        case 5: /*NoMoreOrInvalidInput*/
                        $.$$.System.Diagnostics.Debug.Assert$2(bytesLeftInBuffer < 4, "bytesLeftInBuffer < 4");
                        if (bytesLeftInBuffer > 1)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(bytesLeftInBuffer === 2 || bytesLeftInBuffer === 3, "bytesLeftInBuffer == 2 || bytesLeftInBuffer == 3");
                            if (bytesConsumed === 1)
                            {
                                if ($.$$.System.BitConverter.IsLittleEndian)
                                {
                                    fourByteBuffer >>= 8;
                                }
                                else 
                                {
                                    fourByteBuffer <<= 8;
                                }
                            }
                            else 
                            {
                                if ($.$$.System.BitConverter.IsLittleEndian)
                                {
                                    fourByteBuffer >>= (((32 - (bytesLeftInBuffer << 3)) | 0));
                                }
                                else 
                                {
                                    fourByteBuffer <<= (((32 - (bytesLeftInBuffer << 3)) | 0));
                                }
                            }
                            $gotoJumpState1 = 3; /*goto DecodeRune*/
                            continue $gotoJumpStart1;
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(bytesLeftInBuffer === 0 || bytesLeftInBuffer === 1, "bytesLeftInBuffer == 0 || bytesLeftInBuffer == 1");
                        if ((bytesLeftInBuffer | charsToCopy) === 0)
                        {
                            return totalCharsConsumed;
                        }
                        bytesLeftInBuffer *= 3;
                        dest.$v.Append$2(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(input.Add(totalCharsConsumed).Add(-charsToCopy), ((charsToCopy + bytesLeftInBuffer) | 0)));
                        return ((totalCharsConsumed + bytesLeftInBuffer) | 0);
                    }
                    break;
                }
            }
            static $h = 1418540;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"input","p":$.$typePointer($.$$.System.Char).$h},{"n":"length","p":655361},{"n":"dest","p":1549612,"f":4},{"n":"isQuery","p":262145},{"n":"iriParsing","p":262145}],"n":"UnescapePercentEncodedUTF8Sequence","d":1418540,"h":4296385836,"f":16777249}],"h":1418540}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.PercentEncodingHelper`; }
        });
        
        $asm.$cls("$spu.System.DomainNameHelper", ($self) => class DomainNameHelper
        {
            /*string*/ static IriDotCharacters = null;
            /*SearchValues<char>*/ static s_unsafeForNormalizedHostChars = null;
            /*SearchValues<char>*/ static s_validChars = null;
            /*SearchValues<char>*/ static s_iriInvalidChars = null;
            /*SearchValues<char>*/ static s_asciiLetterUpperOrColonChars = null;
            /*IdnMapping*/ static s_idnMapping = null;
            /*string*/ static Localhost = null;
            /*string*/ static Loopback = null;
            static /*string */ ParseCanonicalName(/*string*/ str, /*int*/ start, /*int*/ end, /*ref bool*/ loopback)
            {
                /*int*/ let index = $.$$.System.MemoryExtensions.LastIndexOfAny($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$1(str, start, ((end - start) | 0)), $.$spu.System.DomainNameHelper.s_asciiLetterUpperOrColonChars);
                if (index >= 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!$.$$.System.MemoryExtensions.Contains$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$1(str, start, index), /*:*/ 58), "A colon should appear at most once, and must never be followed by letters.");
                    if ($.$$.System.String.get_Chars.call(str, ((start + index) | 0)) === /*:*/ 58)
                    {
                        end = ((start + index) | 0);
                        index = $.$$.System.MemoryExtensions.IndexOfAnyInRange($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$1(str, start, index), /*A*/ 65, /*Z*/ 90);
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$2(index === -1 || $.$$.System.Char.IsAsciiLetterUpper($.$$.System.String.get_Chars.call(str, ((start + index) | 0))), "index == -1 || char.IsAsciiLetterUpper(str[start + index])");
                /*ReadOnlySpan<char>*/ let span = $.$$.System.MemoryExtensions.AsSpan$1(str, start, ((end - start) | 0));
                if (index >= 0)
                {
                    if ($.$$.System.MemoryExtensions.Equals$2(span, $.$$.System.String.op_Implicit("localhost"/*Localhost*/), 5/*StringComparison.OrdinalIgnoreCase*/) || $.$$.System.MemoryExtensions.Equals$2(span, $.$$.System.String.op_Implicit("loopback"/*Loopback*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        loopback.$v = true;
                        return "localhost"/*Localhost*/;
                    }
                    return $.$spu.System.UriHelper.SpanToLowerInvariantString(span);
                }
                if ((span === "localhost"/*Localhost*/) || (span === "loopback"/*Loopback*/))
                {
                    loopback.$v = true;
                    return "localhost"/*Localhost*/;
                }
                return $.$$.System.String.Substring.call(str, start, ((end - start) | 0));
            }
            static /*bool */ IsValid(/*ReadOnlySpan<char>*/ hostname, /*bool*/ iri, /*bool*/ notImplicitFile, /*out int*/ length)
            {
                /*int*/ let invalidCharOrDelimiterIndex = iri ? $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, hostname, $.$spu.System.DomainNameHelper.s_iriInvalidChars) : $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, hostname, $.$spu.System.DomainNameHelper.s_validChars);
                if (invalidCharOrDelimiterIndex >= 0)
                {
                    /*char*/ let c = hostname.get_Item(invalidCharOrDelimiterIndex).$v;
                    if ((c === /*/*/ 47) || (c === /*\\*/ 92) || (notImplicitFile && (((c === /*:*/ 58) || (c === /*?*/ 63)) || (c === /*#*/ 35))))
                    {
                        hostname = hostname.Slice(0, invalidCharOrDelimiterIndex);
                    }
                    else 
                    {
                        length.$v = 0;
                        return false;
                    }
                }
                length.$v = hostname.Length;
                if (length.$v === 0)
                {
                    return false;
                }
                while(true)
                {
                    /*char*/ let firstChar = hostname.get_Item(0).$v;
                    if ((!iri || firstChar < 160) && !$.$$.System.Char.IsAsciiLetterOrDigit(firstChar))
                    {
                        return false;
                    }
                    /*int*/ let dotIndex = iri ? $.$$.System.MemoryExtensions.IndexOfAny$4($.$$.System.Char, hostname, $.$$.System.String.op_Implicit(".\u3002\uFF0E\uFF61"/*IriDotCharacters*/)) : $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, hostname, /*.*/ 46);
                    /*int*/ let labelLength = dotIndex < 0 ? hostname.Length : dotIndex;
                    if (iri)
                    {
                        /*ReadOnlySpan<char>*/ let label = hostname.Slice(0, labelLength);
                        if (!$.$$.System.Text.Ascii.IsValid$3(label))
                        {
                            labelLength += 4;
                            var $en5 = label.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var c = $en5.Current.$v;
                                {
                                    if (c > 255)
                                    {
                                        labelLength++;
                                    }
                                }
                            }
                        }
                    }
                    if (!$.$spu.System.IriHelper.IsInInclusiveRange((labelLength >>> 0), 1, 63))
                    {
                        return false;
                    }
                    if (dotIndex < 0)
                    {
                        return true;
                    }
                    hostname = hostname.Slice$1(((dotIndex + 1) | 0));
                    if (hostname.IsEmpty)
                    {
                        return true;
                    }
                }
            }
            static /*string */ IdnEquivalent(/*string*/ hostname)
            {
                if ($.$$.System.Text.Ascii.IsValid$3($.$$.System.String.op_Implicit(hostname)))
                {
                    return $.$$.System.String.ToLowerInvariant.call(hostname);
                }
                /*string*/ let bidiStrippedHost = $.$spu.System.UriHelper.StripBidiControlCharacters($.$$.System.String.op_Implicit(hostname), hostname);
                try
                {
                    /*string*/ let asciiForm = $.$spu.System.DomainNameHelper.s_idnMapping.GetAscii$2(bidiStrippedHost);
                    if ($.$$.System.MemoryExtensions.ContainsAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(asciiForm), $.$spu.System.DomainNameHelper.s_unsafeForNormalizedHostChars))
                    {
                        throw new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadUnicodeHostForIdn);
                    }
                    return asciiForm;
                }
                catch($e)
                {
                    throw new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadUnicodeHostForIdn);
                }
            }
            static /*bool */ TryGetUnicodeEquivalent(/*string*/ hostname, /*ref ValueStringBuilder*/ dest)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Object.ReferenceEquals(hostname, $.$spu.System.UriHelper.StripBidiControlCharacters($.$$.System.String.op_Implicit(hostname), hostname)), "ReferenceEquals(hostname, UriHelper.StripBidiControlCharacters(hostname, hostname))");
                for(/*int*/ let i = 0; i < hostname.length; i++)
                {
                    if (i !== 0)
                    {
                        dest.$v.Append$1(/*.*/ 46);
                    }
                    /*ReadOnlySpan<char>*/ let label = $.$$.System.MemoryExtensions.AsSpan$2(hostname, i);
                    /*int*/ let dotIndex = $.$$.System.MemoryExtensions.IndexOfAny$4($.$$.System.Char, label, $.$$.System.String.op_Implicit(".\u3002\uFF0E\uFF61"/*IriDotCharacters*/));
                    if (dotIndex >= 0)
                    {
                        label = label.Slice(0, dotIndex);
                    }
                    if (!$.$$.System.Text.Ascii.IsValid$3(label))
                    {
                        try
                        {
                            /*string*/ let asciiForm = $.$spu.System.DomainNameHelper.s_idnMapping.GetAscii(hostname, i, label.Length);
                            dest.$v.Append$3($.$spu.System.DomainNameHelper.s_idnMapping.GetUnicode$2(asciiForm));
                        }
                        catch($e)
                        {
                            return false;
                        }
                    }
                    else 
                    {
                        /*bool*/ let aceValid = false;
                        if ($.$$.System.MemoryExtensions.StartsWith(label, $.$$.System.String.op_Implicit("xn--"), 4/*StringComparison.Ordinal*/))
                        {
                            try
                            {
                                dest.$v.Append$3($.$spu.System.DomainNameHelper.s_idnMapping.GetUnicode(hostname, i, label.Length));
                                aceValid = true;
                            }
                            catch($e)
                            {
                            }
                        }
                        if (!aceValid)
                        {
                            /*int*/ let charsWritten = $.$$.System.MemoryExtensions.ToLowerInvariant(label, dest.$v.AppendSpan(label.Length));
                            $.$$.System.Diagnostics.Debug.Assert$2(charsWritten === label.Length, "charsWritten == label.Length");
                        }
                    }
                    i += label.Length;
                }
                return true;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.IriDotCharacters = ".\u3002\uFF0E\uFF61";
                }
                {
                    this.s_unsafeForNormalizedHostChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("\\/?@#:[]"));
                }
                {
                    this.s_validChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz."));
                }
                {
                    this.s_iriInvalidChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\u0008\t\n\u000B\u000C\r\u000E\u000F" + "\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001A\u001B\u001C\u001D\u001E\u001F" + " !\"#$%&'()*+,/:;<=>?@[\\]^`{|}~\u007F" + "\u0080\u0081\u0082\u0083\u0084\u0085\u0086\u0087\u0088\u0089\u008A\u008B\u008C\u008D\u008E\u008F" + "\u0090\u0091\u0092\u0093\u0094\u0095\u0096\u0097\u0098\u0099\u009A\u009B\u009C\u009D\u009E\u009F"));
                }
                {
                    this.s_asciiLetterUpperOrColonChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("ABCDEFGHIJKLMNOPQRSTUVWXYZ:"));
                }
                {
                    this.s_idnMapping = new $.$$.System.Globalization.IdnMapping().$ctor$1();
                }
                {
                    this.Localhost = "localhost";
                }
                {
                    this.Loopback = "loopback";
                }
            }
            static $h = 173356;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"str","p":1310721},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"loopback","p":262145,"f":4}],"n":"ParseCanonicalName","d":173356,"h":38654879020,"f":16777256},{"r":262145,"p":[{"n":"hostname","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"iri","p":262145},{"n":"notImplicitFile","p":262145},{"n":"length","p":655361,"f":2}],"n":"IsValid","d":173356,"h":42949846316,"f":16777249},{"r":1310721,"p":[{"n":"hostname","p":1310721}],"n":"IdnEquivalent","d":173356,"h":47244813612,"f":16777249},{"r":262145,"p":[{"n":"hostname","p":1310721},{"n":"dest","p":1549612,"f":4}],"n":"TryGetUnicodeEquivalent","d":173356,"h":51539780908,"f":16777249}],"l":[{"t":1310721,"n":"IriDotCharacters","d":173356,"h":4295140652,"f":4194338},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"s_unsafeForNormalizedHostChars","d":173356,"h":8590107948,"f":4194338},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"s_validChars","d":173356,"h":12885075244,"f":4194338},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"s_iriInvalidChars","d":173356,"h":17180042540,"f":4194338},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"s_asciiLetterUpperOrColonChars","d":173356,"h":21475009836,"f":4194338},{"t":53346305,"n":"s_idnMapping","d":173356,"h":25769977132,"f":4194338},{"t":1310721,"n":"Localhost","d":173356,"h":30064944428,"f":4194338},{"t":1310721,"n":"Loopback","d":173356,"h":34359911724,"f":4194338}],"h":173356}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.DomainNameHelper`; }
        });
        
        $asm.$cls("$spu.System.UriBuilder", ($self) => class UriBuilder extends $.$$.System.Object
        {
            /*string*/ _scheme = null;
            /*string*/ _username = null;
            /*string*/ _password = null;
            /*string*/ _host = null;
            /*int*/ _port = -1;
            /*string*/ _path = null;
            /*string*/ _query = null;
            /*string*/ _fragment = null;
            /*bool*/ _changed = true;
            /*Uri?*/ _uri = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$6(/*string*/ uri)
            {
                super.$ctor();
                {
                    this._uri = new $.$spu.System.Uri().$ctor$3(uri, 0/*UriKind.RelativeOrAbsolute*/);
                    if (!this._uri.IsAbsoluteUri)
                    {
                        this._uri = new $.$spu.System.Uri().$ctor$5($.$spu.System.Uri.UriSchemeHttp + $.$spu.System.Uri.SchemeDelimiter + uri);
                    }
                    this.SetFieldsFromUri();
                }
                return this;
            }
            $ctor$7(/*Uri*/ uri)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                    this._uri = uri;
                    this.SetFieldsFromUri();
                }
                return this;
            }
            $ctor$5(/*string?*/ schemeName, /*string?*/ hostName)
            {
                super.$ctor();
                {
                    this.Scheme = schemeName;
                    this.Host = hostName;
                }
                return this;
            }
            $ctor$4(/*string?*/ scheme, /*string?*/ host, /*int*/ portNumber)
            {
                this.$ctor$5(scheme, host);
                {
                    this.Port = portNumber;
                }
                return this;
            }
            $ctor$3(/*string?*/ scheme, /*string?*/ host, /*int*/ port, /*string?*/ pathValue)
            {
                this.$ctor$4(scheme, host, port);
                {
                    this.Path = pathValue;
                }
                return this;
            }
            $ctor$2(/*string?*/ scheme, /*string?*/ host, /*int*/ port, /*string?*/ path, /*string?*/ extraValue)
            {
                this.$ctor$3(scheme, host, port, path);
                {
                    if (!$.$$.System.String.IsNullOrEmpty(extraValue))
                    {
                        if ($.$$.System.String.get_Chars.call(extraValue, 0) === /*#*/ 35)
                        {
                            this._fragment = extraValue;
                        }
                        else if ($.$$.System.String.get_Chars.call(extraValue, 0) === /*?*/ 63)
                        {
                            /*int*/ let fragmentIndex = $.$$.System.String.IndexOf$3.call(extraValue, /*#*/ 35);
                            if (fragmentIndex === -1)
                            {
                                this._query = extraValue;
                            }
                            else 
                            {
                                this._query = $.$$.System.String.Substring.call(extraValue, 0, fragmentIndex);
                                this._fragment = $.$$.System.String.Substring$1.call(extraValue, fragmentIndex);
                            }
                        }
                        else 
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$spu.System.SR.Argument_ExtraNotValid, "extraValue");
                        }
                        if (this._query.length === 1)
                        {
                            this._query = $.$$.System.String.Empty;
                        }
                        if (this._fragment.length === 1)
                        {
                            this._fragment = $.$$.System.String.Empty;
                        }
                    }
                }
                return this;
            }
            /*string */ get Scheme()
            {
                return this._scheme;
            }
            /*string */ set Scheme(value)
            {
                value ??= $.$$.System.String.Empty;
                if (value.length !== 0)
                {
                    if (!$.$spu.System.Uri.CheckSchemeName(value))
                    {
                        /*int*/ let index = $.$$.System.String.IndexOf$3.call(value, /*:*/ 58);
                        if (index !== -1)
                        {
                            value = $.$$.System.String.Substring.call(value, 0, index);
                        }
                        if (!$.$spu.System.Uri.CheckSchemeName(value))
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$spu.System.SR.net_uri_BadScheme, "value");
                        }
                    }
                    value = $.$$.System.String.ToLowerInvariant.call(value);
                }
                this._scheme = value;
                this._changed = true;
            }
            /*string */ get UserName()
            {
                return this._username;
            }
            /*string */ set UserName(value)
            {
                this._username = value ?? $.$$.System.String.Empty;
                this._changed = true;
            }
            /*string */ get Password()
            {
                return this._password;
            }
            /*string */ set Password(value)
            {
                this._password = value ?? $.$$.System.String.Empty;
                this._changed = true;
            }
            /*string */ get Host()
            {
                return this._host;
            }
            /*string */ set Host(value)
            {
                if (!$.$$.System.String.IsNullOrEmpty(value) && $.$$.System.String.Contains$1.call(value, /*:*/ 58) && $.$$.System.String.get_Chars.call(value, 0) !== /*[*/ 91)
                {
                    value = "[" + value + "]";
                }
                this._host = value ?? $.$$.System.String.Empty;
                this._changed = true;
            }
            /*int */ get Port()
            {
                return this._port;
            }
            /*int */ set Port(value)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, value, -1, "value");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, value, 65535, "value");
                this._port = value;
                this._changed = true;
            }
            /*string */ get Path()
            {
                return this._path;
            }
            /*string */ set Path(value)
            {
                this._path = $.$$.System.String.IsNullOrEmpty(value) ? "/" : $.$spu.System.Uri.InternalEscapeString($.$$.System.String.Replace.call(value, /*\\*/ 92, /*/*/ 47));
                this._changed = true;
            }
            /*string */ get Query()
            {
                return this._query;
            }
            /*string */ set Query(value)
            {
                if (!$.$$.System.String.IsNullOrEmpty(value) && $.$$.System.String.get_Chars.call(value, 0) !== /*?*/ 63)
                {
                    value = /*?*/ 63 + value;
                }
                this._query = value ?? $.$$.System.String.Empty;
                this._changed = true;
            }
            /*string */ get Fragment()
            {
                return this._fragment;
            }
            /*string */ set Fragment(value)
            {
                if (!$.$$.System.String.IsNullOrEmpty(value) && $.$$.System.String.get_Chars.call(value, 0) !== /*#*/ 35)
                {
                    value = /*#*/ 35 + value;
                }
                this._fragment = value ?? $.$$.System.String.Empty;
                this._changed = true;
            }
            /*Uri */ get Uri()
            {
                if (this._changed)
                {
                    this._uri = new $.$spu.System.Uri().$ctor$5($.$spu.System.UriBuilder.ToString.call(this));
                    this.SetFieldsFromUri();
                    this._changed = false;
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._uri === null), "_uri is not null");
                }
                return this._uri;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ rparam)
            {
                return !(rparam === null) && $.$spu.System.Uri.Equals$1.call(this.Uri, $.$$.System.Object.ToString.call(rparam));
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$spu.System.UriBuilder.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spu.System.Uri.GetHashCode.call(this.Uri);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$spu.System.UriBuilder.GetHashCode.apply(this, arguments); }
            /*SearchValues<char>*/ static s_userInfoReservedChars = null;
            static /*string */ EncodeUserInfo(/*string*/ input)
            {
                if (!$.$$.System.MemoryExtensions.ContainsAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(input), $.$spu.System.UriBuilder.s_userInfoReservedChars))
                {
                    return input;
                }
                return $.$$.System.String.Replace$2.call($.$$.System.String.Replace$2.call($.$$.System.String.Replace$2.call($.$$.System.String.Replace$2.call($.$$.System.String.Replace$2.call(input, "/", "%2F", 4/*StringComparison.Ordinal*/), "\\", "%5C", 4/*StringComparison.Ordinal*/), "?", "%3F", 4/*StringComparison.Ordinal*/), "#", "%23", 4/*StringComparison.Ordinal*/), "@", "%40", 4/*StringComparison.Ordinal*/);
            }
            /*void */ SetFieldsFromUri()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!(this._uri === null), "_uri is not null");
                this._scheme = this._uri.Scheme;
                this._host = this._uri.Host;
                this._port = this._uri.Port;
                this._path = this._uri.AbsolutePath;
                this._query = this._uri.Query;
                this._fragment = this._uri.Fragment;
                /*string*/ let userInfo = this._uri.UserInfo;
                if (userInfo.length > 0)
                {
                    /*int*/ let index = $.$$.System.String.IndexOf$3.call(userInfo, /*:*/ 58);
                    if (index !== -1)
                    {
                        this._password = $.$$.System.String.Substring$1.call(userInfo, ((index + 1) | 0));
                        this._username = $.$$.System.String.Substring.call(userInfo, 0, index);
                    }
                    else 
                    {
                        this._username = userInfo;
                    }
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                if (this.UserName.length === 0 && this.Password.length !== 0)
                {
                    throw new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadUserPassword);
                }
                /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*Uri.StackallocThreshold*/, null));
                /*string*/ let scheme = this.Scheme;
                /*string*/ let host = this.Host;
                if (scheme.length !== 0)
                {
                    /*UriParser?*/ let syntax = $.$spu.System.UriParser.GetSyntax(scheme);
                    /*string*/ let schemeDelimiter;
                    if (syntax === null)
                    {
                        schemeDelimiter = host.length === 0 ? ":" : $.$spu.System.Uri.SchemeDelimiter;
                    }
                    else 
                    {
                        schemeDelimiter = syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/) || (host.length !== 0 && syntax.NotAny(16384/*UriSyntaxFlags.MailToLikeUri*/) && syntax.InFact(2/*UriSyntaxFlags.OptionalAuthority*/)) ? $.$spu.System.Uri.SchemeDelimiter : ":";
                    }
                    vsb.Append$3(scheme);
                    vsb.Append$3(schemeDelimiter);
                }
                /*string*/ let username = $.$spu.System.UriBuilder.EncodeUserInfo(this.UserName);
                if (username.length !== 0)
                {
                    vsb.Append$3(username);
                    /*string*/ let password = $.$spu.System.UriBuilder.EncodeUserInfo(this.Password);
                    if (password.length !== 0)
                    {
                        vsb.Append$1(/*:*/ 58);
                        vsb.Append$3(password);
                    }
                    vsb.Append$1(/*@*/ 64);
                }
                if (host.length !== 0)
                {
                    vsb.Append$3(host);
                    if (this._port !== -1)
                    {
                        vsb.Append$1(/*:*/ 58);
                        /*int*/ let MaxUshortLength = 5;
                        /*int*/ let charsWritten;
                        /*bool*/ let success = $.$$.System.Int32.TryFormat$1.call(this._port, vsb.AppendSpan(MaxUshortLength), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                        $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                        vsb.Length -= ((MaxUshortLength - charsWritten) | 0);
                    }
                }
                /*var*/ let path = this.Path;
                if (path.length !== 0)
                {
                    if (!$.$$.System.String.StartsWith.call(path, /*/*/ 47) && host.length !== 0)
                    {
                        vsb.Append$1(/*/*/ 47);
                    }
                    vsb.Append$3(path);
                }
                vsb.Append$3(this.Query);
                vsb.Append$3(this.Fragment);
                return $.$spu.System.Text.ValueStringBuilder.ToString.call(vsb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spu.System.UriBuilder.ToString.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this._scheme = "http";
                this._username = $.$$.System.String.Empty;
                this._password = $.$$.System.String.Empty;
                this._host = "localhost";
                this._path = "/";
                this._query = $.$$.System.String.Empty;
                this._fragment = $.$$.System.String.Empty;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_userInfoReservedChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("/\\?#@"));
                }
            }
            static $h = 2139436;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":81606518060,"f":50331649},"s":{"r":0,"d":0,"h":85901485356,"f":83886081},"n":"Scheme","d":2139436,"h":77311550764,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":94491419948,"f":50331649},"s":{"r":0,"d":0,"h":98786387244,"f":83886081},"n":"UserName","d":2139436,"h":90196452652,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":107376321836,"f":50331649},"s":{"r":0,"d":0,"h":111671289132,"f":83886081},"n":"Password","d":2139436,"h":103081354540,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":120261223724,"f":50331649},"s":{"r":0,"d":0,"h":124556191020,"f":83886081},"n":"Host","d":2139436,"h":115966256428,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":133146125612,"f":50331649},"s":{"r":0,"d":0,"h":137441092908,"f":83886081},"n":"Port","d":2139436,"h":128851158316,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":146031027500,"f":50331649},"s":{"r":0,"d":0,"h":150325994796,"f":83886081},"n":"Path","d":2139436,"h":141736060204,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":158915929388,"f":50331649},"s":{"r":0,"d":0,"h":163210896684,"f":83886081},"n":"Query","d":2139436,"h":154620962092,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":171800831276,"f":50331649},"s":{"r":0,"d":0,"h":176095798572,"f":83886081},"n":"Fragment","d":2139436,"h":167505863980,"f":2097153},{"p":1746220,"g":{"r":0,"d":0,"h":184685733164,"f":50331649},"n":"Uri","d":2139436,"h":180390765868,"f":2097153}],"m":[{"r":262145,"p":[{"n":"rparam","p":131073}],"n":"Equals","o":"@$1","d":2139436,"h":188980700460,"f":16809985},{"r":655361,"n":"GetHashCode","d":2139436,"h":193275667756,"f":16809985},{"r":1310721,"p":[{"n":"input","p":1310721}],"n":"EncodeUserInfo","d":2139436,"h":201865602348,"f":16777250},{"r":65537,"n":"SetFieldsFromUri","d":2139436,"h":206160569644,"f":16777218},{"r":1310721,"n":"ToString","d":2139436,"h":210455536940,"f":16809985}],"l":[{"t":1310721,"n":"_scheme","d":2139436,"h":4297106732,"f":4194306},{"t":1310721,"n":"_username","d":2139436,"h":8592074028,"f":4194306},{"t":1310721,"n":"_password","d":2139436,"h":12887041324,"f":4194306},{"t":1310721,"n":"_host","d":2139436,"h":17182008620,"f":4194306},{"t":655361,"n":"_port","d":2139436,"h":21476975916,"f":4194306},{"t":1310721,"n":"_path","d":2139436,"h":25771943212,"f":4194306},{"t":1310721,"n":"_query","d":2139436,"h":30066910508,"f":4194306},{"t":1310721,"n":"_fragment","d":2139436,"h":34361877804,"f":4194306},{"t":262145,"n":"_changed","d":2139436,"h":38656845100,"f":4194306},{"t":1746220,"n":"_uri","d":2139436,"h":42951812396,"f":4194306},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"s_userInfoReservedChars","d":2139436,"h":197570635052,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":2139436,"h":47246779692,"f":16777217},{"p":[{"n":"uri","p":1310721}],"n":".ctor","o":"$ctor$6","d":2139436,"h":51541746988,"f":16777217},{"p":[{"n":"uri","p":1746220}],"n":".ctor","o":"$ctor$7","d":2139436,"h":55836714284,"f":16777217},{"p":[{"n":"schemeName","p":1310721},{"n":"hostName","p":1310721}],"n":".ctor","o":"$ctor$5","d":2139436,"h":60131681580,"f":16777217},{"p":[{"n":"scheme","p":1310721},{"n":"host","p":1310721},{"n":"portNumber","p":655361}],"n":".ctor","o":"$ctor$4","d":2139436,"h":64426648876,"f":16777217},{"p":[{"n":"scheme","p":1310721},{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"pathValue","p":1310721}],"n":".ctor","o":"$ctor$3","d":2139436,"h":68721616172,"f":16777217},{"p":[{"n":"scheme","p":1310721},{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"path","p":1310721},{"n":"extraValue","p":1310721}],"n":".ctor","o":"$ctor$2","d":2139436,"h":73016583468,"f":16777217}],"h":2139436}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.UriBuilder`; }
        });
        
        $asm.$cls("$spu.System.UncNameHelper", ($self) => class UncNameHelper
        {
            /*int*/ static MaximumInternetNameLength = 256;
            static /*string */ ParseCanonicalName(/*string*/ str, /*int*/ start, /*int*/ end, /*ref bool*/ loopback)
            {
                return $.$spu.System.DomainNameHelper.ParseCanonicalName(str, start, end, loopback);
            }
            static /*bool */ IsValid(/*char**/ name, /*int*/ start, /*ref int*/ returnedEnd, /*bool*/ notImplicitFile)
            {
                /*int*/ let end = returnedEnd.$v;
                if (start === end)
                {
                    return false;
                }
                /*bool*/ let validShortName = false;
                /*int*/ let i = start;
                for(; i < end; ++i)
                {
                    if (name.GetAt(i) === /*/*/ 47 || name.GetAt(i) === /*\\*/ 92 || (notImplicitFile && (name.GetAt(i) === /*:*/ 58 || name.GetAt(i) === /*?*/ 63 || name.GetAt(i) === /*#*/ 35)))
                    {
                        end = i;
                        break;
                    }
                    else if (name.GetAt(i) === /*.*/ 46)
                    {
                        ++i;
                        break;
                    }
                    if ($.$$.System.Char.IsLetter(name.GetAt(i)) || name.GetAt(i) === /*-*/ 45 || name.GetAt(i) === /*_*/ 95)
                    {
                        validShortName = true;
                    }
                    else if (!$.$$.System.Char.IsAsciiDigit(name.GetAt(i)))
                    {
                        return false;
                    }
                }
                if (!validShortName)
                {
                    return false;
                }
                for(; i < end; ++i)
                {
                    if (name.GetAt(i) === /*/*/ 47 || name.GetAt(i) === /*\\*/ 92 || (notImplicitFile && (name.GetAt(i) === /*:*/ 58 || name.GetAt(i) === /*?*/ 63 || name.GetAt(i) === /*#*/ 35)))
                    {
                        end = i;
                        break;
                    }
                    else if (name.GetAt(i) === /*.*/ 46)
                    {
                        if (!validShortName || ((((i - 1) | 0)) >= start && name.GetAt(((i - 1) | 0)) === /*.*/ 46))
                        {
                            return false;
                        }
                        validShortName = false;
                    }
                    else if (name.GetAt(i) === /*-*/ 45 || name.GetAt(i) === /*_*/ 95)
                    {
                        if (!validShortName)
                        {
                            return false;
                        }
                    }
                    else if ($.$$.System.Char.IsLetter(name.GetAt(i)) || $.$$.System.Char.IsAsciiDigit(name.GetAt(i)))
                    {
                        if (!validShortName)
                        {
                            validShortName = true;
                        }
                    }
                    else 
                    {
                        return false;
                    }
                }
                if ((((i - 1) | 0)) >= start && name.GetAt(((i - 1) | 0)) === /*.*/ 46)
                {
                    validShortName = true;
                }
                if (!validShortName)
                {
                    return false;
                }
                returnedEnd.$v = end;
                return true;
            }
            static $h = 1615148;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"str","p":1310721},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"loopback","p":262145,"f":4}],"n":"ParseCanonicalName","d":1615148,"h":8591549740,"f":16777249},{"r":262145,"p":[{"n":"name","p":$.$typePointer($.$$.System.Char).$h},{"n":"start","p":655361},{"n":"returnedEnd","p":655361,"f":4},{"n":"notImplicitFile","p":262145}],"n":"IsValid","d":1615148,"h":12886517036,"f":16777249}],"l":[{"t":655361,"n":"MaximumInternetNameLength","d":1615148,"h":4296582444,"f":4194337}],"h":1615148}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.UncNameHelper`; }
        });
        
        $asm.$cls("$spu.System.SR", ($self) => class SR
        {
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$spu.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$spu.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$spu.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$spu.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$spu.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$spu.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$spu.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Private.Uri", $.$spu.System.SR.$type.Assembly);
                    $.$spu.System.SR.s_resourceManager = temp;
                }
                return $.$spu.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$spu.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$spu.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_AddingDuplicate()
            {
                return "An item with the same key has already been added. Key: {0}";
            }
            static /*string */ FormatArgument_AddingDuplicate(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("An item with the same key has already been added. Key: {0}", arg1);
            }
            static /*string */ get net_uri_BadAuthority()
            {
                return "Invalid URI: The Authority/Host could not be parsed.";
            }
            static /*string */ get net_uri_BadAuthorityTerminator()
            {
                return "Invalid URI: The Authority/Host cannot end with a backslash character ('\\\\').";
            }
            static /*string */ get net_uri_BadFormat()
            {
                return "Invalid URI: The format of the URI could not be determined.";
            }
            static /*string */ get net_uri_NeedFreshParser()
            {
                return "The URI parser instance passed into 'uriParser' parameter is already registered with the scheme name '{0}'.";
            }
            static /*string */ Formatnet_uri_NeedFreshParser(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The URI parser instance passed into 'uriParser' parameter is already registered with the scheme name '{0}'.", arg1);
            }
            static /*string */ get net_uri_AlreadyRegistered()
            {
                return "A URI scheme name '{0}' already has a registered custom parser.";
            }
            static /*string */ Formatnet_uri_AlreadyRegistered(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("A URI scheme name '{0}' already has a registered custom parser.", arg1);
            }
            static /*string */ get net_uri_BadHostName()
            {
                return "Invalid URI: The hostname could not be parsed.";
            }
            static /*string */ get net_uri_BadPort()
            {
                return "Invalid URI: Invalid port specified.";
            }
            static /*string */ get net_uri_BadScheme()
            {
                return "Invalid URI: The URI scheme is not valid.";
            }
            static /*string */ get net_uri_BadUserPassword()
            {
                return "Invalid URI: The username:password construct is badly formed.";
            }
            static /*string */ get net_uri_CannotCreateRelative()
            {
                return "A relative URI cannot be created because the 'uriString' parameter represents an absolute URI.";
            }
            static /*string */ get net_uri_SchemeLimit()
            {
                return "Invalid URI: The Uri scheme is too long.";
            }
            static /*string */ get net_uri_EmptyUri()
            {
                return "Invalid URI: The URI is empty.";
            }
            static /*string */ get net_uri_InvalidUriKind()
            {
                return "The value '{0}' passed for the UriKind parameter is invalid.";
            }
            static /*string */ Formatnet_uri_InvalidUriKind(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The value '{0}' passed for the UriKind parameter is invalid.", arg1);
            }
            static /*string */ get net_uri_MustRootedPath()
            {
                return "Invalid URI: A Dos path must be rooted, for example, 'c:\\\\'.";
            }
            static /*string */ get net_uri_NotAbsolute()
            {
                return "This operation is not supported for a relative URI.";
            }
            static /*string */ get net_uri_PortOutOfRange()
            {
                return "A derived type '{0}' has reported an invalid value for the Uri port '{1}'.";
            }
            static /*string */ Formatnet_uri_PortOutOfRange(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("A derived type '{0}' has reported an invalid value for the Uri port '{1}'.", arg1, arg2);
            }
            static /*string */ get net_uri_UserDrivenParsing()
            {
                return "A derived type '{0}' is responsible for parsing this Uri instance. The base implementation must not be used.";
            }
            static /*string */ Formatnet_uri_UserDrivenParsing(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("A derived type '{0}' is responsible for parsing this Uri instance. The base implementation must not be used.", arg1);
            }
            static /*string */ get net_uri_NotJustSerialization()
            {
                return "UriComponents.SerializationInfoString must not be combined with other UriComponents.";
            }
            static /*string */ get net_uri_BadUnicodeHostForIdn()
            {
                return "An invalid Unicode character by IDN standards was specified in the host.";
            }
            static /*string */ get Argument_ExtraNotValid()
            {
                return "Extra portion of URI not valid.";
            }
            static /*string */ get Argument_InvalidUriSubcomponent()
            {
                return "The subcomponent, {0}, of this uri is not valid.";
            }
            static /*string */ FormatArgument_InvalidUriSubcomponent(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The subcomponent, {0}, of this uri is not valid.", arg1);
            }
            static /*string */ get Arg_KeyNotFoundWithKey()
            {
                return "The given key '{0}' was not present in the dictionary.";
            }
            static /*string */ FormatArg_KeyNotFoundWithKey(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The given key '{0}' was not present in the dictionary.", arg1);
            }
            static /*string */ get InvalidNullArgument()
            {
                return "Null is not a valid value for {0}.";
            }
            static /*string */ FormatInvalidNullArgument(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Null is not a valid value for {0}.", arg1);
            }
            static /*string */ get net_uri_InitializeCalledAlreadyOrTooLate()
            {
                return "UriParser's base InitializeAndValidate may only be called once on a single Uri instance and only from an override of InitializeAndValidate.";
            }
            static /*string */ get net_uri_GetComponentsCalledWhenCanonicalizationDisabled()
            {
                return "GetComponents() may not be used for Path/Query on a Uri instance created with UriCreationOptions.DangerousDisablePathAndQueryCanonicalization.";
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$spu.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1484076;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1484076}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$spu.System.HexConverter", ($self) => class HexConverter
        {
            static $_Casing;
            static get Casing()
            {
                let $cls = $.$spu.System.HexConverter;
                return $cls.$_Casing ??= $asm.$nstr("$spu.System.HexConverter.Casing", ($self) => class Casing extends $.$$.System.Enum
                {
                    static Upper = 0;
                    static Lower = 8224;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Upper": 0n,
                            "Lower": 8224n
                        };
                    }
                    static $h = 632108;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$$.System.UInt32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":720897,"l":[{"t":632108,"n":"Upper","d":632108,"h":4295599404,"f":4194337},{"t":632108,"n":"Lower","d":632108,"h":8590566700,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":632108,"h":12885533996,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":566572,"h":632108}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.HexConverter.Casing`; }
                }, $cls, ($v) => $cls.$_Casing = $v);
            }
            static /*void */ ToBytesBuffer(/*byte*/ value, /*Span<byte>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast(packedResult, $.$$.System.Byte);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$$.System.Byte);
            }
            static /*void */ ToCharsBuffer(/*byte*/ value, /*Span<char>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast((packedResult & 255), $.$$.System.Char);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$$.System.Char);
            }
            static /*void */ EncodeToUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ utf8Destination, /*Casing*/ casing)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(utf8Destination.Length >= (((source.Length * 2) | 0)), "utf8Destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$spu.System.HexConverter.ToBytesBuffer(source.get_Item(pos).$v, utf8Destination, ((pos * 2) | 0), casing);
                }
            }
            static /*void */ EncodeToUtf16(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Casing*/ casing)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(destination.Length >= (((source.Length * 2) | 0)), "destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$spu.System.HexConverter.ToCharsBuffer(source.get_Item(pos).$v, destination, ((pos * 2) | 0), casing);
                }
            }
            static /*string */ ToString$1(/*ReadOnlySpan<byte>*/ bytes, /*Casing*/ casing)
            {
                /*SpanCasingPair*/ let args = (() =>
                {
                    //new $.$spu.System.HexConverter.SpanCasingPair()
                    const $t1 = $.$spu.System.HexConverter.SpanCasingPair;
                    const $i1 = new $t1();
                    $i1.Bytes = bytes;
                    $i1.Casing = casing;
                    return $i1;
                })();
                return $.$$.System.String.Create$10($.$spu.System.HexConverter.SpanCasingPair, ((bytes.Length * 2) | 0), args.Clone(), new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$spu.System.HexConverter.SpanCasingPair))().$ctor($.$spu.System.HexConverter, /*static*/ (/*chars*/ chars, /*args*/ args) =>
                {
                    return $.$spu.System.HexConverter.EncodeToUtf16(args.Bytes, chars, args.Casing);
                }, {"r":65537,"p":[{"n":"chars","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"args","p":697644}],"n":"","d":566572,"h":0,"f":17825826}));
            }
            static $_SpanCasingPair;
            static get SpanCasingPair()
            {
                let $cls = $.$spu.System.HexConverter;
                return $cls.$_SpanCasingPair ??= $asm.$nstr("$spu.System.HexConverter.SpanCasingPair", ($self) => class SpanCasingPair extends $.$$.System.ValueType
                {
                    /*ReadOnlySpan<byte>*/ Bytes;
                    /*Casing*/ Casing = 0;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Bytes = this.Bytes.Clone();
                        copy.Casing = this.Casing;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Bytes = $.$default($.$$.System.ReadOnlySpan$$($.$$.System.Byte));
                        this.Casing = 0;
                    }
                    static $h = 697644;
                    static $z = 9;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":12885599532,"f":50331649},"s":{"r":0,"d":0,"h":17180566828,"f":83886081},"n":"Bytes","d":697644,"h":8590632236,"f":2097153},{"p":632108,"g":{"r":0,"d":0,"h":30065468716,"f":50331649},"s":{"r":0,"d":0,"h":34360436012,"f":83886081},"n":"Casing","d":697644,"h":25770501420,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":697644,"h":38655403308,"f":16777217}],"d":566572,"h":697644}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.HexConverter.SpanCasingPair`; }
                }, $cls, ($v) => $cls.$_SpanCasingPair = $v);
            }
            static /*char */ ToCharUpper(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*A*/ 65 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$$.System.Char);
            }
            static /*char */ ToCharLower(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*a*/ 97 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$$.System.Char);
            }
            static /*bool */ TryDecodeFromUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                return $.$spu.System.HexConverter.TryDecodeFromUtf8_Scalar(utf8Source, destination, bytesProcessed);
            }
            static /*bool */ TryDecodeFromUtf16(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                return $.$spu.System.HexConverter.TryDecodeFromUtf16_Scalar(source, destination, charsProcessed);
            }
            static /*bool */ TryDecodeFromUtf8_Scalar(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                $.$$.System.Diagnostics.Debug.Assert$2((utf8Source.Length % 2) === 0, "Un-even number of characters provided");
                $.$$.System.Diagnostics.Debug.Assert$2(($.trunc(utf8Source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$spu.System.HexConverter.FromChar(utf8Source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$spu.System.HexConverter.FromChar(utf8Source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$$.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                bytesProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*bool */ TryDecodeFromUtf16_Scalar(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                $.$$.System.Diagnostics.Debug.Assert$2((source.Length % 2) === 0, "Un-even number of characters provided");
                $.$$.System.Diagnostics.Debug.Assert$2(($.trunc(source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$spu.System.HexConverter.FromChar(source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$spu.System.HexConverter.FromChar(source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$$.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                charsProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*int */ FromChar(/*int*/ c)
            {
                return (c >= $.$spu.System.HexConverter.CharToHexLookup.Length) ? 255 : $.$spu.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromUpperChar(/*int*/ c)
            {
                return (c > 71) ? 255 : $.$spu.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromLowerChar(/*int*/ c)
            {
                if (((((c - /*0*/ 48) | 0)) >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                {
                    return ((c - /*0*/ 48) | 0);
                }
                if (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97))
                {
                    return ((((c - /*a*/ 97) | 0) + 10) | 0);
                }
                return 255;
            }
            static /*bool */ IsHexChar(/*int*/ c)
            {
                //if (IntPtr.Size == 8) { ... }
                return $.$spu.System.HexConverter.FromChar(c) !== 255;
            }
            static /*bool */ IsHexUpperChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*A*/ 65) | 0)) >>> 0) <= (/*F*/ 70 - /*A*/ 65));
            }
            static /*bool */ IsHexLowerChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97));
            }
            static /*ReadOnlySpan<byte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([ 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255 ]);
            }
            static $h = 566572;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":90194879788,"f":50331681},"n":"CharToHexLookup","d":566572,"h":85899912492,"f":2097185}],"m":[{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":632108,"f":65,"v":0}],"n":"ToBytesBuffer","d":566572,"h":8590501164,"f":16777249},{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":632108,"f":65,"v":0}],"n":"ToCharsBuffer","d":566572,"h":12885468460,"f":16777249},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"utf8Destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"casing","p":632108,"f":65,"v":0}],"n":"EncodeToUtf8","d":566572,"h":17180435756,"f":16777249},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"casing","p":632108,"f":65,"v":0}],"n":"EncodeToUtf16","d":566572,"h":21475403052,"f":16777249},{"r":1310721,"p":[{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"casing","p":632108,"f":65,"v":0}],"n":"ToString","o":"@$1","d":566572,"h":25770370348,"f":16777249},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharUpper","d":566572,"h":34360304940,"f":16777249},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharLower","d":566572,"h":38655272236,"f":16777249},{"r":262145,"p":[{"n":"utf8Source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8","d":566572,"h":42950239532,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16","d":566572,"h":47245206828,"f":16777249},{"r":262145,"p":[{"n":"utf8Source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8_Scalar","d":566572,"h":51540174124,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16_Scalar","d":566572,"h":55835141420,"f":16777250},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromChar","d":566572,"h":60130108716,"f":16777249},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromUpperChar","d":566572,"h":64425076012,"f":16777249},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromLowerChar","d":566572,"h":68720043308,"f":16777249},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexChar","d":566572,"h":73015010604,"f":16777249},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexUpperChar","d":566572,"h":77309977900,"f":16777249},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexLowerChar","d":566572,"h":81604945196,"f":16777249}],"j":[632108,697644],"h":566572}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.HexConverter`; }
        });
        
        $asm.$cls("$spu.System.UriHelper", ($self) => class UriHelper
        {
            static /*string */ SpanToLowerInvariantString(/*ReadOnlySpan<char>*/ span)
            {
                return $.$$.System.String.Create$10($.$$.System.ReadOnlySpan$$($.$$.System.Char), span.Length, span, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.ReadOnlySpan$$($.$$.System.Char)))().$ctor($.$spu.System.UriHelper, /*static*/ (/*buffer*/ buffer, /*span*/ span) =>
                {
                    /*int*/ let charsWritten = $.$$.System.MemoryExtensions.ToLowerInvariant(span, buffer);
                    $.$$.System.Diagnostics.Debug.Assert$2(charsWritten === buffer.Length, "charsWritten == buffer.Length");
                }, {"r":65537,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"span","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"","d":2467116,"h":0,"f":17825826}));
            }
            static /*string */ NormalizeAndConcat(/*string?*/ start, /*ReadOnlySpan<char>*/ toNormalize)
            {
                /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*Uri.StackallocThreshold*/, null));
                /*int*/ let charsWritten;
                while(!$.$$.System.StringNormalizationExtensions.TryNormalize(toNormalize, vsb.RawChars, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), 1/*NormalizationForm.FormC*/))
                {
                    vsb.EnsureCapacity(((vsb.Capacity + 1) | 0));
                }
                /*string*/ let result = $.$$.System.String.Concat$8($.$$.System.String.op_Implicit(start), $.$$.System.Span$$($.$$.System.Char).op_Implicit(vsb.RawChars.Slice(0, charsWritten)));
                vsb.Dispose();
                return result;
            }
            static /*bool */ TestForSubPath(/*char**/ selfPtr, /*int*/ selfLength, /*char**/ otherPtr, /*int*/ otherLength, /*bool*/ ignoreCase)
            {
                /*int*/ let i = 0;
                /*char*/ let chSelf;
                /*char*/ let chOther;
                /*bool*/ let AllSameBeforeSlash = true;
                for(; i < selfLength && i < otherLength; ++i)
                {
                    chSelf = (selfPtr.Add(i)).$v;
                    chOther = (otherPtr.Add(i)).$v;
                    if (chSelf === /*?*/ 63 || chSelf === /*#*/ 35)
                    {
                        return true;
                    }
                    if (chSelf === /*/*/ 47)
                    {
                        if (chOther !== /*/*/ 47)
                        {
                            return false;
                        }
                        if (!AllSameBeforeSlash)
                        {
                            return false;
                        }
                        AllSameBeforeSlash = true;
                        continue;
                    }
                    if (chOther === /*?*/ 63 || chOther === /*#*/ 35)
                    {
                        break;
                    }
                    if (!ignoreCase)
                    {
                        if (chSelf !== chOther)
                        {
                            AllSameBeforeSlash = false;
                        }
                    }
                    else 
                    {
                        if ($.$$.System.Char.ToLowerInvariant(chSelf) !== $.$$.System.Char.ToLowerInvariant(chOther))
                        {
                            AllSameBeforeSlash = false;
                        }
                    }
                }
                for(; i < selfLength; ++i)
                {
                    if ((chSelf = (selfPtr.Add(i)).$v) === /*?*/ 63 || chSelf === /*#*/ 35)
                    {
                        return true;
                    }
                    if (chSelf === /*/*/ 47)
                    {
                        return false;
                    }
                }
                return true;
            }
            static /*bool */ TryEscapeDataString(/*ReadOnlySpan<char>*/ charsToEscape, /*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                if (destination.Length < charsToEscape.Length)
                {
                    charsWritten.$v = 0;
                    return false;
                }
                /*int*/ let indexOfFirstToEscape = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, charsToEscape, $.$spu.System.UriHelper.Unreserved);
                if (indexOfFirstToEscape < 0)
                {
                    charsToEscape.CopyTo(destination);
                    charsWritten.$v = charsToEscape.Length;
                    return true;
                }
                /*scoped ValueStringBuilder*/ let vsb;
                /*bool*/ let overlapped = $.$$.System.MemoryExtensions.Overlaps$1($.$$.System.Char, charsToEscape, $.$$.System.Span$$($.$$.System.Char).op_Implicit(destination));
                if (overlapped)
                {
                    vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*Uri.StackallocThreshold*/, null));
                    vsb.EnsureCapacity(charsToEscape.Length);
                }
                else 
                {
                    vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4(destination.Slice$1(indexOfFirstToEscape));
                }
                $.$spu.System.UriHelper.EscapeStringToBuilder(charsToEscape.Slice$1(indexOfFirstToEscape), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), $.$spu.System.UriHelper.Unreserved, false);
                /*int*/ let newLength = $.$checked(indexOfFirstToEscape + vsb.Length, 1);
                $.$$.System.Diagnostics.Debug.Assert$2(newLength > charsToEscape.Length, "newLength > charsToEscape.Length");
                if (destination.Length >= newLength)
                {
                    charsToEscape.Slice(0, indexOfFirstToEscape).CopyTo(destination);
                    if (overlapped)
                    {
                        vsb.AsSpan().CopyTo(destination.Slice$1(indexOfFirstToEscape));
                        vsb.Dispose();
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.MemoryExtensions.Overlaps$1($.$$.System.Char, $.$$.System.Span$$($.$$.System.Char).op_Implicit(vsb.RawChars), $.$$.System.Span$$($.$$.System.Char).op_Implicit(destination)), "vsb.RawChars.Overlaps(destination)");
                    }
                    charsWritten.$v = newLength;
                    return true;
                }
                vsb.Dispose();
                charsWritten.$v = 0;
                return false;
            }
            static /*string */ EscapeString$2(/*string*/ stringToEscape, /*bool*/ checkExistingEscaped, /*SearchValues<char>*/ noEscape)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(stringToEscape, "stringToEscape");
                return $.$spu.System.UriHelper.EscapeString($.$$.System.String.op_Implicit(stringToEscape), checkExistingEscaped, noEscape, stringToEscape);
            }
            static /*string */ EscapeString(/*ReadOnlySpan<char>*/ charsToEscape, /*bool*/ checkExistingEscaped, /*SearchValues<char>*/ noEscape, /*string?*/ backingString)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!noEscape.Contains(/*%*/ 37), "Need to treat % specially; it should be part of any escaped set");
                $.$$.System.Diagnostics.Debug.Assert$2(backingString === null || backingString.length === charsToEscape.Length, "backingString is null || backingString.Length == charsToEscape.Length");
                /*int*/ let indexOfFirstToEscape = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, charsToEscape, noEscape);
                if (indexOfFirstToEscape < 0)
                {
                    return backingString ?? $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(charsToEscape);
                }
                /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*Uri.StackallocThreshold*/, null));
                vsb.EnsureCapacity(charsToEscape.Length);
                $.$spu.System.UriHelper.EscapeStringToBuilder(charsToEscape.Slice$1(indexOfFirstToEscape), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), noEscape, checkExistingEscaped);
                /*string*/ let result = $.$$.System.String.Concat$8(charsToEscape.Slice(0, indexOfFirstToEscape), vsb.AsSpan());
                vsb.Dispose();
                return result;
            }
            static /*void */ EscapeString$1(/*scoped ReadOnlySpan<char>*/ stringToEscape, /*ref ValueStringBuilder*/ dest, /*bool*/ checkExistingEscaped, /*SearchValues<char>*/ noEscape)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!noEscape.Contains(/*%*/ 37), "Need to treat % specially; it should be part of any escaped set");
                /*int*/ let indexOfFirstToEscape = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, stringToEscape, noEscape);
                if (indexOfFirstToEscape < 0)
                {
                    dest.$v.Append$2(stringToEscape);
                }
                else 
                {
                    dest.$v.Append$2(stringToEscape.Slice(0, indexOfFirstToEscape));
                    $.$spu.System.UriHelper.EscapeStringToBuilder(stringToEscape.Slice$1(indexOfFirstToEscape), dest, noEscape, checkExistingEscaped);
                }
            }
            static /*void */ EscapeStringToBuilder(/*scoped ReadOnlySpan<char>*/ stringToEscape, /*ref ValueStringBuilder*/ vsb, /*SearchValues<char>*/ noEscape, /*bool*/ checkExistingEscaped)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!stringToEscape.IsEmpty && !noEscape.Contains(stringToEscape.get_Item(0).$v), "!stringToEscape.IsEmpty && !noEscape.Contains(stringToEscape[0])");
                /*Span<byte>*/ let utf8Bytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 4, null);
                while(!stringToEscape.IsEmpty)
                {
                    /*char*/ let c = stringToEscape.get_Item(0).$v;
                    if (!$.$$.System.Char.IsAscii(c))
                    {
                        /*Rune*/ let r;
                        /*int*/ let charsConsumed;
                        if ($.$$.System.Text.Rune.DecodeFromUtf16(stringToEscape, $.$ref(() => r, ($v) => r = $v, $.$$.System.Text.Rune), $.$ref(() => charsConsumed, ($v) => charsConsumed = $v, $.$$.System.Int32)) !== 0/*OperationStatus.Done*/)
                        {
                            r = $.$$.System.Text.Rune.ReplacementChar;
                        }
                        let e;
                        $.$$.System.Diagnostics.Debug.Assert$2((e = $.$$.System.MemoryExtensions.EnumerateRunes(stringToEscape), e != null && true) && e.MoveNext() && $.$$.System.Text.Rune.op_Equality(e.Current, r), "stringToEscape.EnumerateRunes() is { } e && e.MoveNext() && e.Current == r");
                        $.$$.System.Diagnostics.Debug.Assert$2((charsConsumed === 1) || (charsConsumed === 2), "charsConsumed is 1 or 2");
                        stringToEscape = stringToEscape.Slice$1(charsConsumed);
                        /*int*/ let bytesWritten;
                        r.TryEncodeToUtf8(utf8Bytes, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32));
                        var $en4 = utf8Bytes.Slice(0, bytesWritten).GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var b = $en4.Current.$v;
                            {
                                $.$spu.System.UriHelper.PercentEncodeByte(b, vsb);
                            }
                        }
                        continue;
                    }
                    if (!noEscape.Contains(c))
                    {
                        if (c === /*%*/ 37 && checkExistingEscaped)
                        {
                            if (stringToEscape.Length > 2 && $.$$.System.Char.IsAsciiHexDigit(stringToEscape.get_Item(1).$v) && $.$$.System.Char.IsAsciiHexDigit(stringToEscape.get_Item(2).$v))
                            {
                                vsb.$v.Append$1(/*%*/ 37);
                                vsb.$v.Append$1(stringToEscape.get_Item(1).$v);
                                vsb.$v.Append$1(stringToEscape.get_Item(2).$v);
                                stringToEscape = stringToEscape.Slice$1(3);
                                continue;
                            }
                        }
                        $.$spu.System.UriHelper.PercentEncodeByte($.$cast(c, $.$$.System.Byte), vsb);
                        stringToEscape = stringToEscape.Slice$1(1);
                        continue;
                    }
                    /*int*/ let charsToCopy = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, stringToEscape, noEscape);
                    if (charsToCopy < 0)
                    {
                        charsToCopy = stringToEscape.Length;
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(charsToCopy > 0, "charsToCopy > 0");
                    vsb.$v.Append$2(stringToEscape.Slice(0, charsToCopy));
                    stringToEscape = stringToEscape.Slice$1(charsToCopy);
                }
            }
            static /*char[] */ UnescapeString$3(/*string*/ input, /*int*/ start, /*int*/ end, /*char[]*/ dest, /*ref int*/ destPosition, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                /*fixed*/ 
                {
                    /*char**/ let pStr = $.$$.System.String.GetPinnableReference.call(input);
                    return $.$spu.System.UriHelper.UnescapeString(pStr, start, end, dest, destPosition, rsvd1, rsvd2, rsvd3, unescapeMode, syntax, isQuery);
                }
            }
            static /*char[] */ UnescapeString(/*char**/ pStr, /*int*/ start, /*int*/ end, /*char[]*/ dest, /*ref int*/ destPosition, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                /*ValueStringBuilder*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$3(dest.length);
                vsb.Append$2($.$$.System.Span$$($.$$.System.Char).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, dest, 0, destPosition.$v)));
                $.$spu.System.UriHelper.UnescapeString$1(pStr, start, end, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), rsvd1, rsvd2, rsvd3, unescapeMode, syntax, isQuery);
                if (vsb.Length > dest.length)
                {
                    dest = vsb.AsSpan().ToArray();
                }
                else 
                {
                    vsb.AsSpan$3(destPosition.$v).TryCopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, dest, destPosition.$v));
                }
                destPosition.$v = vsb.Length;
                vsb.Dispose();
                return dest;
            }
            static /*void */ UnescapeString$4(/*string*/ input, /*int*/ start, /*int*/ end, /*ref ValueStringBuilder*/ dest, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                /*fixed*/ 
                {
                    /*char**/ let pStr = $.$$.System.String.GetPinnableReference.call(input);
                    $.$spu.System.UriHelper.UnescapeString$1(pStr, start, end, dest, rsvd1, rsvd2, rsvd3, unescapeMode, syntax, isQuery);
                }
            }
            static /*void */ UnescapeString$2(/*scoped ReadOnlySpan<char>*/ input, /*scoped ref ValueStringBuilder*/ dest, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                /*fixed*/ 
                {
                    /*char**/ let pStr = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Char, input);
                    $.$spu.System.UriHelper.UnescapeString$1(pStr, 0, input.Length, dest, rsvd1, rsvd2, rsvd3, unescapeMode, syntax, isQuery);
                }
            }
            static /*void */ UnescapeString$1(/*char**/ pStr, /*int*/ start, /*int*/ end, /*ref ValueStringBuilder*/ dest, /*char*/ rsvd1, /*char*/ rsvd2, /*char*/ rsvd3, /*UnescapeMode*/ unescapeMode, /*UriParser?*/ syntax, /*bool*/ isQuery)
            {
                if ((unescapeMode & 3/*UnescapeMode.EscapeUnescape*/) === 0/*UnescapeMode.CopyOnly*/)
                {
                    dest.$v.Append$2(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pStr.Add(start), ((end - start) | 0)));
                    return;
                }
                /*bool*/ let escapeReserved = false;
                /*bool*/ let iriParsing = $.$spu.System.Uri.IriParsingStatic(syntax) && ((unescapeMode & 3/*UnescapeMode.EscapeUnescape*/) === 3/*UnescapeMode.EscapeUnescape*/);
                for(/*int*/ let next = start; next < end; )
                {
                    /*char*/ let ch = 0;
                    for(; next < end; ++next)
                    {
                        if ((ch = pStr.GetAt(next)) === /*%*/ 37)
                        {
                            if ((unescapeMode & 2/*UnescapeMode.Unescape*/) === 0)
                            {
                                escapeReserved = true;
                            }
                            else if (((next + 2) | 0) < end)
                            {
                                ch = $.$spu.System.UriHelper.DecodeHexChars(pStr.GetAt(((next + 1) | 0)), pStr.GetAt(((next + 2) | 0)));
                                if (unescapeMode >= 8/*UnescapeMode.UnescapeAll*/)
                                {
                                    if (ch === /*\uFFFF*/ 65535)
                                    {
                                        continue;
                                    }
                                }
                                else if (ch === /*\uFFFF*/ 65535)
                                {
                                    if ((unescapeMode & 1/*UnescapeMode.Escape*/) !== 0)
                                    {
                                        escapeReserved = true;
                                    }
                                    else 
                                    {
                                        continue;
                                    }
                                }
                                else if (ch === /*%*/ 37)
                                {
                                    next += 2;
                                    continue;
                                }
                                else if (ch === rsvd1 || ch === rsvd2 || ch === rsvd3)
                                {
                                    next += 2;
                                    continue;
                                }
                                else if ((unescapeMode & 4/*UnescapeMode.V1ToStringFlag*/) === 0 && $.$spu.System.UriHelper.IsNotSafeForUnescape(ch))
                                {
                                    next += 2;
                                    continue;
                                }
                                else if (iriParsing && ((ch <= /*\u009F*/ 159 && $.$spu.System.UriHelper.IsNotSafeForUnescape(ch)) || (ch > /*\u009F*/ 159 && !$.$spu.System.IriHelper.CheckIriUnicodeRange(ch, isQuery))))
                                {
                                    next += 2;
                                    continue;
                                }
                                break;
                            }
                            else if (unescapeMode >= 8/*UnescapeMode.UnescapeAll*/)
                            {
                                continue;
                            }
                            else 
                            {
                                escapeReserved = true;
                            }
                            break;
                        }
                        else if ((unescapeMode & (2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/)) === (2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/))
                        {
                            continue;
                        }
                        else if ((unescapeMode & 1/*UnescapeMode.Escape*/) !== 0)
                        {
                            if (ch === rsvd1 || ch === rsvd2 || ch === rsvd3)
                            {
                                escapeReserved = true;
                                break;
                            }
                            else if ((unescapeMode & 4/*UnescapeMode.V1ToStringFlag*/) === 0 && (ch <= /*\u001F*/ 31 || (ch >= /*\u007F*/ 127 && ch <= /*\u009F*/ 159)))
                            {
                                escapeReserved = true;
                                break;
                            }
                        }
                    }
                    while(start < next)
                    {
                        dest.$v.Append$1(pStr.GetAt(start++));
                    }
                    if (next !== end)
                    {
                        if (escapeReserved)
                        {
                            $.$spu.System.UriHelper.PercentEncodeByte($.$cast(pStr.GetAt(next), $.$$.System.Byte), dest);
                            escapeReserved = false;
                            next++;
                        }
                        else if (ch <= 127)
                        {
                            dest.$v.Append$1(ch);
                            next += 3;
                        }
                        else 
                        {
                            /*int*/ let charactersRead = $.$spu.System.PercentEncodingHelper.UnescapePercentEncodedUTF8Sequence(pStr.Add(next), ((end - next) | 0), dest, isQuery, iriParsing);
                            $.$$.System.Diagnostics.Debug.Assert$2(charactersRead > 0, "charactersRead > 0");
                            next += charactersRead;
                        }
                        start = next;
                    }
                }
            }
            static /*void */ PercentEncodeByte(/*byte*/ b, /*ref ValueStringBuilder*/ to)
            {
                to.$v.Append$1(/*%*/ 37);
                $.$spu.System.HexConverter.ToCharsBuffer(b, to.$v.AppendSpan(2), 0, 0/*HexConverter.Casing.Upper*/);
            }
            static /*char */ DecodeHexChars(/*int*/ first, /*int*/ second)
            {
                /*int*/ let a = $.$spu.System.HexConverter.FromChar(first);
                /*int*/ let b = $.$spu.System.HexConverter.FromChar(second);
                if ((a | b) === 255)
                {
                    return /*\uFFFF*/ 65535;
                }
                return $.$cast(((a << 4) | b), $.$$.System.Char);
            }
            /*string*/ static RFC3986ReservedMarks = null;
            /*string*/ static AdditionalUnsafeToUnescape = null;
            static /*bool */ IsNotSafeForUnescape(/*char*/ ch)
            {
                if (ch <= /*\u001F*/ 31 || (ch >= /*\u007F*/ 127 && ch <= /*\u009F*/ 159))
                {
                    return true;
                }
                /*string*/ let NotSafeForUnescape = ";/?:@&=+$,#[]!'()*"/*RFC3986ReservedMarks*/ + "%\\#"/*AdditionalUnsafeToUnescape*/;
                return $.$$.System.String.Contains$1.call(NotSafeForUnescape, ch);
            }
            /*SearchValues<char>*/ static Unreserved = null;
            /*SearchValues<char>*/ static UnreservedReserved = null;
            /*SearchValues<char>*/ static UnreservedReservedExceptHash = null;
            /*SearchValues<char>*/ static UnreservedReservedExceptQuestionMarkHash = null;
            static /*bool */ IsGenDelim(/*char*/ ch)
            {
                return (ch === /*:*/ 58 || ch === /*/*/ 47 || ch === /*?*/ 63 || ch === /*#*/ 35 || ch === /*[*/ 91 || ch === /*]*/ 93 || ch === /*@*/ 64);
            }
            /*char[]*/ static s_WSchars = null;
            static /*bool */ IsLWS(/*char*/ ch)
            {
                return (ch <= /* */ 32) && (ch === /* */ 32 || ch === /*\n*/ 10 || ch === /*\r*/ 13 || ch === /*\t*/ 9);
            }
            static /*bool */ IsBidiControlCharacter(/*char*/ ch)
            {
                return $.$$.System.Char.IsBetween(ch, /*\u200E*/ 8206, /*\u202E*/ 8238) && !$.$$.System.Char.IsBetween(ch, /*\u2010*/ 8208, /*\u2029*/ 8233);
            }
            static /*string */ StripBidiControlCharacters(/*ReadOnlySpan<char>*/ strToClean, /*string?*/ backingString)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(backingString === null || strToClean.Length === backingString.length, "backingString is null || strToClean.Length == backingString.Length");
                /*string?*/ let stripped;
                if ($.$spu.System.UriHelper.StripBidiControlCharacters$1(strToClean, $.$ref(() => stripped, ($v) => stripped = $v, $.$$.System.String)))
                {
                    return stripped;
                }
                return backingString ?? $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(strToClean);
            }
            static /*bool */ StripBidiControlCharacters$1(/*ReadOnlySpan<char>*/ strToClean, /*out string?*/ stripped)
            {
                /*int*/ let charsToRemove = 0;
                /*int*/ let indexOfPossibleCharToRemove = $.$$.System.MemoryExtensions.IndexOfAnyInRange($.$$.System.Char, strToClean, /*\u200E*/ 8206, /*\u202E*/ 8238);
                if (indexOfPossibleCharToRemove >= 0)
                {
                    var $en3 = strToClean.Slice$1(indexOfPossibleCharToRemove).GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var c = $en3.Current.$v;
                        {
                            if ($.$spu.System.UriHelper.IsBidiControlCharacter(c))
                            {
                                charsToRemove++;
                            }
                        }
                    }
                }
                if (charsToRemove === 0)
                {
                    stripped.$v = null;
                    return false;
                }
                stripped.$v = $.$$.System.String.Create$10($.$$.System.ReadOnlySpan$$($.$$.System.Char), ((strToClean.Length - charsToRemove) | 0), strToClean, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.ReadOnlySpan$$($.$$.System.Char)))().$ctor($.$spu.System.UriHelper, /*static*/ (/*buffer*/ buffer, /*strToClean*/ strToClean) =>
                {
                    /*int*/ let destIndex = 0;
                    var $en3 = strToClean.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var c = $en3.Current.$v;
                        {
                            if (!$.$spu.System.UriHelper.IsBidiControlCharacter(c))
                            {
                                buffer.get_Item(destIndex++).$v = c;
                            }
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(buffer.Length === destIndex, "buffer.Length == destIndex");
                }, {"r":65537,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"strToClean","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"","d":2467116,"h":0,"f":17825826}));
                return true;
            }
            static /*int */ Compress(/*Span<char>*/ span, /*bool*/ convertPathSlashes, /*bool*/ canonicalizeAsFilePath)
            {
                if (span.IsEmpty)
                {
                    return 0;
                }
                if (convertPathSlashes)
                {
                    $.$$.System.MemoryExtensions.Replace$3($.$$.System.Char, span, /*\\*/ 92, /*/*/ 47);
                }
                /*ValueListBuilder<(int Start, int Length)>*/ let removedSegments = new ($.$spu.System.Collections.Generic.ValueListBuilder$$($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32)))();
                /*int*/ let slashCount = 0;
                /*int*/ let lastSlash = 0;
                /*int*/ let dotCount = 0;
                /*int*/ let removeSegments = 0;
                for(/*int*/ let i = ((span.Length - 1) | 0); i >= 0; i--)
                {
                    /*char*/ let ch = span.get_Item(i).$v;
                    if (ch === /*/*/ 47)
                    {
                        ++slashCount;
                    }
                    else 
                    {
                        if (slashCount > 1)
                        {
                            lastSlash = ((i + 1) | 0);
                        }
                        slashCount = 0;
                    }
                    if (ch === /*.*/ 46)
                    {
                        ++dotCount;
                        continue;
                    }
                    else if (dotCount !== 0)
                    {
                        /*bool*/ let skipSegment = canonicalizeAsFilePath && (dotCount > 2 || ch !== /*/*/ 47);
                        if (!skipSegment && ch === /*/*/ 47)
                        {
                            if ((lastSlash === ((((i + dotCount) | 0) + 1) | 0) || (lastSlash === 0 && ((((i + dotCount) | 0) + 1) | 0) === span.Length)) && (dotCount <= 2))
                            {
                                removedSegments.Append$1(new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(((i + 1) | 0), ((dotCount + (lastSlash === 0 ? 0 : 1)) | 0)));
                                lastSlash = i;
                                if (dotCount === 2)
                                {
                                    ++removeSegments;
                                }
                                dotCount = 0;
                                continue;
                            }
                        }
                        dotCount = 0;
                    }
                    if (ch === /*/*/ 47)
                    {
                        if (removeSegments !== 0)
                        {
                            removeSegments--;
                            removedSegments.Append$1(new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(((i + 1) | 0), ((lastSlash - i) | 0)));
                        }
                        lastSlash = i;
                    }
                }
                if (canonicalizeAsFilePath)
                {
                    if (slashCount <= 1)
                    {
                        if (removeSegments !== 0 && span.get_Item(0).$v !== /*/*/ 47)
                        {
                            removedSegments.Append$1(new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(0, ((lastSlash + 1) | 0)));
                        }
                        else if (dotCount !== 0)
                        {
                            if (lastSlash === dotCount || (lastSlash === 0 && dotCount === span.Length))
                            {
                                removedSegments.Append$1(new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(0, ((dotCount + (lastSlash === 0 ? 0 : 1)) | 0)));
                            }
                        }
                    }
                }
                if (removedSegments.Length === 0)
                {
                    return span.Length;
                }
                /*int*/ let writeOffset = removedSegments.get_Item(removedSegments.Length - 1).$v.Item1;
                /*int*/ let readOffset = writeOffset;
                for(/*int*/ let i = ((removedSegments.Length - 1) | 0); i >= 0; i--)
                {
                    const { Item1: start, Item2: length } = removedSegments.get_Item(i).$v;
                    $.$$.System.Diagnostics.Debug.Assert$2(start >= readOffset && length > 0 && ((start + length) | 0) <= span.Length, "start >= readOffset && length > 0 && start + length <= span.Length");
                    if (readOffset !== start)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(readOffset > writeOffset, "readOffset > writeOffset");
                        /*int*/ let segmentLength = ((start - readOffset) | 0);
                        span.Slice(readOffset, segmentLength).CopyTo(span.Slice$1(writeOffset));
                        writeOffset += segmentLength;
                    }
                    readOffset = ((start + length) | 0);
                }
                if (readOffset !== span.Length)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(readOffset > writeOffset, "readOffset > writeOffset");
                    span.Slice$1(readOffset).CopyTo(span.Slice$1(writeOffset));
                    writeOffset += ((span.Length - readOffset) | 0);
                }
                removedSegments.Dispose();
                return writeOffset;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.RFC3986ReservedMarks = ";/?:@&=+$,#[]!'()*";
                }
                {
                    this.AdditionalUnsafeToUnescape = "%\\#";
                }
                {
                    this.Unreserved = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz~"));
                }
                {
                    this.UnreservedReserved = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("!#$&'()*+,-./0123456789:;=?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]_abcdefghijklmnopqrstuvwxyz~"));
                }
                {
                    this.UnreservedReservedExceptHash = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("!$&'()*+,-./0123456789:;=?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]_abcdefghijklmnopqrstuvwxyz~"));
                }
                {
                    this.UnreservedReservedExceptQuestionMarkHash = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("!$&'()*+,-./0123456789:;=@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]_abcdefghijklmnopqrstuvwxyz~"));
                }
                {
                    this.s_WSchars = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/* */ 32, /*\n*/ 10, /*\r*/ 13, /*\t*/ 9], [-1], null);
                }
            }
            static $h = 2467116;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"span","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"SpanToLowerInvariantString","d":2467116,"h":4297434412,"f":16777249},{"r":1310721,"p":[{"n":"start","p":1310721},{"n":"toNormalize","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"NormalizeAndConcat","d":2467116,"h":8592401708,"f":16777249},{"r":262145,"p":[{"n":"selfPtr","p":$.$typePointer($.$$.System.Char).$h},{"n":"selfLength","p":655361},{"n":"otherPtr","p":$.$typePointer($.$$.System.Char).$h},{"n":"otherLength","p":655361},{"n":"ignoreCase","p":262145}],"n":"TestForSubPath","d":2467116,"h":12887369004,"f":16777256},{"r":262145,"p":[{"n":"charsToEscape","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryEscapeDataString","d":2467116,"h":17182336300,"f":16777249},{"r":1310721,"p":[{"n":"stringToEscape","p":1310721},{"n":"checkExistingEscaped","p":262145},{"n":"noEscape","p":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h}],"n":"EscapeString","o":"@$2","d":2467116,"h":21477303596,"f":16777249},{"r":1310721,"p":[{"n":"charsToEscape","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"checkExistingEscaped","p":262145},{"n":"noEscape","p":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h},{"n":"backingString","p":1310721}],"n":"EscapeString","d":2467116,"h":25772270892,"f":16777249},{"r":65537,"p":[{"n":"stringToEscape","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"dest","p":1549612,"f":4},{"n":"checkExistingEscaped","p":262145},{"n":"noEscape","p":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h}],"n":"EscapeString","o":"@$1","d":2467116,"h":30067238188,"f":16777256},{"r":65537,"p":[{"n":"stringToEscape","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"vsb","p":1549612,"f":4},{"n":"noEscape","p":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h},{"n":"checkExistingEscaped","p":262145}],"n":"EscapeStringToBuilder","d":2467116,"h":34362205484,"f":16777250},{"r":$.$typeArray($.$$.System.Char).$h,"p":[{"n":"input","p":1310721},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"dest","p":$.$typeArray($.$$.System.Char).$h},{"n":"destPosition","p":655361,"f":4},{"n":"rsvd1","p":458753},{"n":"rsvd2","p":458753},{"n":"rsvd3","p":458753},{"n":"unescapeMode","p":1680684},{"n":"syntax","p":2663724},{"n":"isQuery","p":262145}],"n":"UnescapeString","o":"@$3","d":2467116,"h":38657172780,"f":16777256},{"r":$.$typeArray($.$$.System.Char).$h,"p":[{"n":"pStr","p":$.$typePointer($.$$.System.Char).$h},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"dest","p":$.$typeArray($.$$.System.Char).$h},{"n":"destPosition","p":655361,"f":4},{"n":"rsvd1","p":458753},{"n":"rsvd2","p":458753},{"n":"rsvd3","p":458753},{"n":"unescapeMode","p":1680684},{"n":"syntax","p":2663724},{"n":"isQuery","p":262145}],"n":"UnescapeString","d":2467116,"h":42952140076,"f":16777256},{"r":65537,"p":[{"n":"input","p":1310721},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"dest","p":1549612,"f":4},{"n":"rsvd1","p":458753},{"n":"rsvd2","p":458753},{"n":"rsvd3","p":458753},{"n":"unescapeMode","p":1680684},{"n":"syntax","p":2663724},{"n":"isQuery","p":262145}],"n":"UnescapeString","o":"@$4","d":2467116,"h":47247107372,"f":16777256},{"r":65537,"p":[{"n":"input","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"dest","p":1549612,"f":4},{"n":"rsvd1","p":458753},{"n":"rsvd2","p":458753},{"n":"rsvd3","p":458753},{"n":"unescapeMode","p":1680684},{"n":"syntax","p":2663724},{"n":"isQuery","p":262145}],"n":"UnescapeString","o":"@$2","d":2467116,"h":51542074668,"f":16777256},{"r":65537,"p":[{"n":"pStr","p":$.$typePointer($.$$.System.Char).$h},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"dest","p":1549612,"f":4},{"n":"rsvd1","p":458753},{"n":"rsvd2","p":458753},{"n":"rsvd3","p":458753},{"n":"unescapeMode","p":1680684},{"n":"syntax","p":2663724},{"n":"isQuery","p":262145}],"n":"UnescapeString","o":"@$1","d":2467116,"h":55837041964,"f":16777256},{"r":65537,"p":[{"n":"b","p":393217},{"n":"to","p":1549612,"f":4}],"n":"PercentEncodeByte","d":2467116,"h":60132009260,"f":16777256},{"r":458753,"p":[{"n":"first","p":655361},{"n":"second","p":655361}],"n":"DecodeHexChars","d":2467116,"h":64426976556,"f":16777256},{"r":262145,"p":[{"n":"ch","p":458753}],"n":"IsNotSafeForUnescape","d":2467116,"h":77311878444,"f":16777256},{"r":262145,"p":[{"n":"ch","p":458753}],"n":"IsGenDelim","d":2467116,"h":98786714924,"f":16777256},{"r":262145,"p":[{"n":"ch","p":458753}],"n":"IsLWS","d":2467116,"h":107376649516,"f":16777256},{"r":262145,"p":[{"n":"ch","p":458753}],"n":"IsBidiControlCharacter","d":2467116,"h":111671616812,"f":16777256},{"r":1310721,"p":[{"n":"strToClean","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"backingString","p":1310721,"f":65}],"n":"StripBidiControlCharacters","d":2467116,"h":115966584108,"f":16777249},{"r":262145,"p":[{"n":"strToClean","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"stripped","p":1310721,"f":2}],"n":"StripBidiControlCharacters","o":"@$1","d":2467116,"h":120261551404,"f":16777249},{"r":655361,"p":[{"n":"span","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"convertPathSlashes","p":262145},{"n":"canonicalizeAsFilePath","p":262145}],"n":"Compress","d":2467116,"h":124556518700,"f":16777249}],"l":[{"t":1310721,"n":"RFC3986ReservedMarks","d":2467116,"h":68721943852,"f":4194344},{"t":1310721,"n":"AdditionalUnsafeToUnescape","d":2467116,"h":73016911148,"f":4194338},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"Unreserved","d":2467116,"h":81606845740,"f":4194337},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"UnreservedReserved","d":2467116,"h":85901813036,"f":4194337},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"UnreservedReservedExceptHash","d":2467116,"h":90196780332,"f":4194337},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"UnreservedReservedExceptQuestionMarkHash","d":2467116,"h":94491747628,"f":4194337},{"t":$.$typeArray($.$$.System.Char).$h,"n":"s_WSchars","d":2467116,"h":103081682220,"f":4194344}],"h":2467116}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.UriHelper`; }
        });
        
        $asm.$cls("$spu.System.Uri", ($self) => class Uri extends $.$$.System.Object
        {
            /*void */ CreateThis(/*string?*/ uri, /*bool*/ dontEscape, /*UriKind*/ uriKind, /*in UriCreationOptions*/ creationOptions)
            {
                this.DebugAssertInCtor();
                if (uriKind < 0/*UriKind.RelativeOrAbsolute*/ || uriKind > 2/*UriKind.Relative*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_InvalidUriKind, $.$box(uriKind, $.$spu.System.UriKind)));
                }
                this._string = uri ?? $.$$.System.String.Empty;
                $.$$.System.Diagnostics.Debug.Assert$2(this._originalUnicodeString === null && this._info === null && this._syntax === null && this._flags === 0n, "_originalUnicodeString is null && _info is null && _syntax is null && _flags == Flags.Zero");
                if (dontEscape)
                {
                    this._flags |= 34359738368n;
                }
                if (creationOptions.$v.DangerousDisablePathAndQueryCanonicalization)
                {
                    this._flags |= 36028797018963968n;
                }
                /*ParsingError*/ let err = $.$spu.System.Uri.ParseScheme(this._string, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => this._flags, ($v) => this._flags = $v, null), $.$ref(() => this._syntax, ($v) => this._syntax = $v, $.$spu.System.UriParser));
                /*UriFormatException?*/ let e;
                this.InitializeUri(err, uriKind, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException));
                if (e !== null)
                {
                    throw e;
                }
            }
            /*void */ InitializeUri(/*ParsingError*/ err, /*UriKind*/ uriKind, /*out UriFormatException?*/ e)
            {
                this.DebugAssertInCtor();
                if (err === 0/*ParsingError.None*/)
                {
                    if (this.IsImplicitFile)
                    {
                        if (this.NotAny(8796093022208n) && uriKind !== 1/*UriKind.Absolute*/ && ((uriKind === 2/*UriKind.Relative*/ || (this._string.length >= 2 && ($.$$.System.String.get_Chars.call(this._string, 0) !== /*\\*/ 92 || $.$$.System.String.get_Chars.call(this._string, 1) !== /*\\*/ 92))) || (!$.$$.System.OperatingSystem.IsWindows() && this.InFact(18014398509481984n))))
                        {
                            this._syntax = null;
                            this._flags &= 34359738368n;
                            e.$v = null;
                            return;
                        }
                        else if (uriKind === 2/*UriKind.Relative*/ && this.InFact(8796093022208n))
                        {
                            this._syntax = null;
                            this._flags &= 34359738368n;
                            e.$v = null;
                            return;
                        }
                    }
                }
                else if (err > 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                {
                    this._string = null;
                    e.$v = $.$spu.System.Uri.GetException(err);
                    return;
                }
                /*bool*/ let hasUnicode = false;
                if (this.IriParsing && $.$spu.System.Uri.CheckForUnicodeOrEscapedUnreserved(this._string))
                {
                    this._flags |= 562949953421312n;
                    hasUnicode = true;
                    this._originalUnicodeString = this._string;
                }
                if (this._syntax !== null)
                {
                    if (this._syntax.IsSimple)
                    {
                        if ((err = this.PrivateParseMinimal()) !== 0/*ParsingError.None*/)
                        {
                            if (uriKind !== 1/*UriKind.Absolute*/ && err <= 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                            {
                                this._syntax = null;
                                e.$v = null;
                                this._flags &= 34359738368n;
                                return;
                            }
                            else 
                            {
                                e.$v = $.$spu.System.Uri.GetException(err);
                            }
                        }
                        else if (uriKind === 2/*UriKind.Relative*/)
                        {
                            e.$v = $.$spu.System.Uri.GetException(12/*ParsingError.CannotCreateRelative*/);
                        }
                        else 
                        {
                            e.$v = null;
                        }
                        if (hasUnicode)
                        {
                            try
                            {
                                this.EnsureParseRemaining();
                            }
                            catch(ex)
                            {
                                e.$v = ex;
                                return;
                            }
                        }
                    }
                    else 
                    {
                        this._syntax = this._syntax.InternalOnNewUri();
                        this._flags |= 1099511627776n;
                        this._syntax.InternalValidate(this, e);
                        if (e.$v !== null)
                        {
                            if (uriKind !== 1/*UriKind.Absolute*/ && err !== 0/*ParsingError.None*/ && err <= 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                            {
                                this._syntax = null;
                                e.$v = null;
                                this._flags &= 34359738368n;
                            }
                        }
                        else 
                        {
                            if (err !== 0/*ParsingError.None*/ || this.InFact(4398046511104n))
                            {
                                this._flags = 1099511627776n | (this._flags & 34359738368n);
                            }
                            else if (uriKind === 2/*UriKind.Relative*/)
                            {
                                e.$v = $.$spu.System.Uri.GetException(12/*ParsingError.CannotCreateRelative*/);
                            }
                            if (hasUnicode)
                            {
                                try
                                {
                                    this.EnsureParseRemaining();
                                }
                                catch(ex)
                                {
                                    e.$v = ex;
                                    return;
                                }
                            }
                        }
                    }
                }
                else if (err !== 0/*ParsingError.None*/ && uriKind !== 1/*UriKind.Absolute*/ && err <= 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                {
                    e.$v = null;
                    this._flags &= (34359738368n | 562949953421312n);
                    if (hasUnicode)
                    {
                        this._string = this.EscapeUnescapeIri(this._originalUnicodeString, 0, this._originalUnicodeString.length, $.$cast(0, $.$spu.System.UriComponents));
                    }
                }
                else 
                {
                    this._string = null;
                    e.$v = $.$spu.System.Uri.GetException(err);
                }
            }
            /*SearchValues<char>*/ static s_asciiOtherThanPercent = null;
            static /*bool */ CheckForUnicodeOrEscapedUnreserved(/*string*/ data)
            {
                /*int*/ let i = $.$$.System.MemoryExtensions.IndexOfAnyExcept($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(data), $.$spu.System.Uri.s_asciiOtherThanPercent);
                if (i >= 0)
                {
                    for(; i < data.length; i++)
                    {
                        /*char*/ let c = $.$$.System.String.get_Chars.call(data, i);
                        if (c === /*%*/ 37)
                        {
                            if (((((i + 2) | 0)) >>> 0) < (data.length >>> 0))
                            {
                                /*char*/ let value = $.$spu.System.UriHelper.DecodeHexChars($.$$.System.String.get_Chars.call(data, ((i + 1) | 0)), $.$$.System.String.get_Chars.call(data, ((i + 2) | 0)));
                                if (!$.$$.System.Char.IsAscii(value) || $.$spu.System.UriHelper.Unreserved.Contains(value))
                                {
                                    return true;
                                }
                                i += 2;
                            }
                        }
                        else if (c > 127)
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            static /*bool */ TryCreate(/*string?*/ uriString, /*UriKind*/ uriKind, /*out Uri?*/ result)
            {
                if (uriString === null)
                {
                    result.$v = null;
                    return false;
                }
                /*UriFormatException?*/ let e = null;
                let $v2 = new $.$spu.System.UriCreationOptions();
                result.$v = $.$spu.System.Uri.CreateHelper(uriString, false, uriKind, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException), $.$ref(() => $v2, ($v) => $v2 = $v));
                result.$v?.DebugSetLeftCtor();
                return e === null && $.$spu.System.Uri.op_Inequality(result.$v, null);
            }
            static /*bool */ TryCreate$1(/*string?*/ uriString, /*in UriCreationOptions*/ creationOptions, /*out Uri?*/ result)
            {
                if (uriString === null)
                {
                    result.$v = null;
                    return false;
                }
                /*UriFormatException?*/ let e = null;
                result.$v = $.$spu.System.Uri.CreateHelper(uriString, false, 1/*UriKind.Absolute*/, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException), creationOptions);
                result.$v?.DebugSetLeftCtor();
                return e === null && $.$spu.System.Uri.op_Inequality(result.$v, null);
            }
            static /*bool */ TryCreate$2(/*Uri?*/ baseUri, /*string?*/ relativeUri, /*out Uri?*/ result)
            {
                /*Uri?*/ let relativeLink;
                if ($.$spu.System.Uri.TryCreate(relativeUri, 0/*UriKind.RelativeOrAbsolute*/, $.$ref(() => relativeLink, ($v) => relativeLink = $v, $.$spu.System.Uri)))
                {
                    if (!relativeLink.IsAbsoluteUri)
                    {
                        return $.$spu.System.Uri.TryCreate$3(baseUri, relativeLink, result);
                    }
                    result.$v = relativeLink;
                    return true;
                }
                result.$v = null;
                return false;
            }
            static /*bool */ TryCreate$3(/*Uri?*/ baseUri, /*Uri?*/ relativeUri, /*out Uri?*/ result)
            {
                result.$v = null;
                if (baseUri === null || relativeUri === null)
                {
                    return false;
                }
                if (baseUri.IsNotAbsoluteUri)
                {
                    return false;
                }
                /*UriFormatException?*/ let e = null;
                /*string?*/ let newUriString = null;
                /*bool*/ let dontEscape;
                if (baseUri.Syntax.IsSimple)
                {
                    dontEscape = relativeUri.UserEscaped;
                    result.$v = $.$spu.System.Uri.ResolveHelper(baseUri, relativeUri, $.$ref(() => newUriString, ($v) => newUriString = $v, $.$$.System.String), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => dontEscape, ($v) => dontEscape = $v, null));
                }
                else 
                {
                    dontEscape = false;
                    newUriString = baseUri.Syntax.InternalResolve(baseUri, relativeUri, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException));
                    if (e !== null)
                    {
                        return false;
                    }
                }
                let $v2 = new $.$spu.System.UriCreationOptions();
                result.$v ??= $.$spu.System.Uri.CreateHelper(newUriString, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException), $.$ref(() => $v2, ($v) => $v2 = $v));
                result.$v?.DebugSetLeftCtor();
                return e === null && $.$spu.System.Uri.op_Inequality(result.$v, null) && result.$v.IsAbsoluteUri;
            }
            /*string */ GetComponents(/*UriComponents*/ components, /*UriFormat*/ format)
            {
                if (this.DisablePathAndQueryCanonicalization && (components & (16/*UriComponents.Path*/ | 32/*UriComponents.Query*/)) !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_GetComponentsCalledWhenCanonicalizationDisabled);
                }
                return this.InternalGetComponents(components, format);
            }
            /*string */ InternalGetComponents(/*UriComponents*/ components, /*UriFormat*/ format)
            {
                if (((components & -2147483648/*UriComponents.SerializationInfoString*/) !== 0) && components !== -2147483648/*UriComponents.SerializationInfoString*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("components", $.$box(components, $.$spu.System.UriComponents), $.$spu.System.SR.net_uri_NotJustSerialization);
                }
                if ((format & ~3/*UriFormat.SafeUnescaped*/) !== 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("format");
                }
                if (this.IsNotAbsoluteUri)
                {
                    if (components === -2147483648/*UriComponents.SerializationInfoString*/)
                    {
                        return this.GetRelativeSerializationString(format);
                    }
                    else 
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                    }
                }
                if (this.Syntax.IsSimple)
                {
                    return this.GetComponentsHelper(components, format);
                }
                return this.Syntax.InternalGetComponents(this, components, format);
            }
            static /*int */ Compare(/*Uri?*/ uri1, /*Uri?*/ uri2, /*UriComponents*/ partsToCompare, /*UriFormat*/ compareFormat, /*StringComparison*/ comparisonType)
            {
                if (uri1 === null)
                {
                    if (uri2 === null)
                    {
                        return 0;
                    }
                    return -1;
                }
                if (uri2 === null)
                {
                    return 1;
                }
                if (!uri1.IsAbsoluteUri || !uri2.IsAbsoluteUri)
                {
                    return uri1.IsAbsoluteUri ? 1 : uri2.IsAbsoluteUri ? -1 : $.$$.System.String.Compare$8(uri1.OriginalString, uri2.OriginalString, comparisonType);
                }
                return $.$$.System.String.Compare$8(uri1.GetParts(partsToCompare, compareFormat), uri2.GetParts(partsToCompare, compareFormat), comparisonType);
            }
            /*bool */ IsWellFormedOriginalString()
            {
                if (this.IsNotAbsoluteUri || this.Syntax.IsSimple)
                {
                    return this.InternalIsWellFormedOriginalString();
                }
                return this.Syntax.InternalIsWellFormedOriginalString(this);
            }
            static /*bool */ IsWellFormedUriString(/*string?*/ uriString, /*UriKind*/ uriKind)
            {
                /*Uri?*/ let result;
                if (!$.$spu.System.Uri.TryCreate(uriString, uriKind, $.$ref(() => result, ($v) => result = $v, $.$spu.System.Uri)))
                {
                    return false;
                }
                return result.IsWellFormedOriginalString();
            }
            /*bool */ InternalIsWellFormedOriginalString()
            {
                if (this.UserDrivenParsing)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_UserDrivenParsing, $.$$.System.Object.GetType.call(this)));
                }
                /*fixed*/ 
                {
                    /*char**/ let str = $.$$.System.String.GetPinnableReference.call(this._string);
                    /*int*/ let idx = 0;
                    if (!this.IsAbsoluteUri)
                    {
                        if ($.$spu.System.Uri.CheckForColonInFirstPathSegment(this._string))
                        {
                            return false;
                        }
                        return (this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), this._string.length, /*\uFFFE*/ 65534) & (16/*Check.BackslashInPath*/ | 1/*Check.EscapedCanonical*/)) === 1/*Check.EscapedCanonical*/;
                    }
                    if (this.IsImplicitFile)
                    {
                        return false;
                    }
                    this.EnsureParseRemaining();
                    /*Flags*/ let nonCanonical = (this._flags & (8064n | 16888498602639360n));
                    if ((nonCanonical & (1125899906842624n | 2251799813685248n | 4503599627370496n | 9007199254740992n)) !== 0n)
                    {
                        if ((nonCanonical & (128n | 1125899906842624n)) === (128n | 1125899906842624n))
                        {
                            nonCanonical &= ~(128n | 1125899906842624n);
                        }
                        if ((nonCanonical & (1024n | 2251799813685248n)) === (1024n | 2251799813685248n))
                        {
                            nonCanonical &= ~(1024n | 2251799813685248n);
                        }
                        if ((nonCanonical & (2048n | 4503599627370496n)) === (2048n | 4503599627370496n))
                        {
                            nonCanonical &= ~(2048n | 4503599627370496n);
                        }
                        if ((nonCanonical & (4096n | 9007199254740992n)) === (4096n | 9007199254740992n))
                        {
                            nonCanonical &= ~(4096n | 9007199254740992n);
                        }
                    }
                    if ((nonCanonical & 8064n & (128n | 1024n | 2048n | 4096n)) !== 0n)
                    {
                        return false;
                    }
                    if (this.InFact(68719476736n))
                    {
                        idx = ((((this._info.Offset.Scheme + this._syntax.SchemeName.length) | 0) + 2) | 0);
                        if (idx >= this._info.Offset.User || $.$$.System.String.get_Chars.call(this._string, ((idx - 1) | 0)) === /*\\*/ 92 || $.$$.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92)
                        {
                            return false;
                        }
                        if (this.InFact(17592186044416n | 8796093022208n))
                        {
                            while(++idx < this._info.Offset.User && ($.$$.System.String.get_Chars.call(this._string, idx) === /*/*/ 47 || $.$$.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92))
                            {
                                return false;
                            }
                        }
                    }
                    if (this.InFact(16384n) && this._info.Offset.Query > this._info.Offset.Path)
                    {
                        return false;
                    }
                    if (this.InFact(32768n))
                    {
                        return false;
                    }
                    if (this.IsDosPath && $.$$.System.String.get_Chars.call(this._string, ((((this._info.Offset.Path + this.SecuredPathIndex) | 0) - 1) | 0)) === /*|*/ 124)
                    {
                        return false;
                    }
                    if ((this._flags & 2199023255552n) === 0n && this.HostType !== 4294967296n)
                    {
                        idx = this._info.Offset.User;
                        /*Check*/ let result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), this._info.Offset.Path, /*/*/ 47);
                        if (((result & (32/*Check.ReservedFound*/ | 16/*Check.BackslashInPath*/ | 1/*Check.EscapedCanonical*/)) !== 1/*Check.EscapedCanonical*/) && (!this.IriParsing || (result & (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) !== (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                        {
                            return false;
                        }
                    }
                    if ((this._flags & (1n | 68719476736n)) === (1n | 68719476736n))
                    {
                        idx = this._syntax.SchemeName.length;
                        while(str.GetAt(idx++) !== /*:*/ 58)
                        {
                        }
                        if (((idx + 1) | 0) >= this._string.length || str.GetAt(idx) !== /*/*/ 47 || str.GetAt(((idx + 1) | 0)) !== /*/*/ 47)
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            static /*string */ UnescapeDataString$2(/*string*/ stringToUnescape)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(stringToUnescape, "stringToUnescape");
                return $.$spu.System.Uri.UnescapeDataString($.$$.System.String.op_Implicit(stringToUnescape), stringToUnescape);
            }
            static /*string */ UnescapeDataString$1(/*ReadOnlySpan<char>*/ charsToUnescape)
            {
                return $.$spu.System.Uri.UnescapeDataString(charsToUnescape, null);
            }
            static /*string */ UnescapeDataString(/*ReadOnlySpan<char>*/ charsToUnescape, /*string?*/ backingString)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(backingString === null || backingString.length === charsToUnescape.Length, "backingString is null || backingString.Length == charsToUnescape.Length");
                /*int*/ let indexOfFirstToUnescape = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, charsToUnescape, /*%*/ 37);
                if (indexOfFirstToUnescape < 0)
                {
                    return backingString ?? $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(charsToUnescape);
                }
                /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                vsb.EnsureCapacity(((charsToUnescape.Length - indexOfFirstToUnescape) | 0));
                $.$spu.System.UriHelper.UnescapeString$2(charsToUnescape.Slice$1(indexOfFirstToUnescape), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, null, false);
                /*string*/ let result = $.$$.System.String.Concat$8(charsToUnescape.Slice(0, indexOfFirstToUnescape), vsb.AsSpan());
                vsb.Dispose();
                return result;
            }
            static /*bool */ TryUnescapeDataString(/*ReadOnlySpan<char>*/ charsToUnescape, /*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                /*int*/ let indexOfFirstToUnescape = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, charsToUnescape, /*%*/ 37);
                if (indexOfFirstToUnescape < 0)
                {
                    if (charsToUnescape.TryCopyTo(destination))
                    {
                        charsWritten.$v = charsToUnescape.Length;
                        return true;
                    }
                    charsWritten.$v = 0;
                    return false;
                }
                /*scoped ValueStringBuilder*/ let vsb;
                /*bool*/ let overlapped = $.$$.System.MemoryExtensions.Overlaps$1($.$$.System.Char, charsToUnescape, $.$$.System.Span$$($.$$.System.Char).op_Implicit(destination)) && !$.$$.System.Runtime.CompilerServices.Unsafe.AreSame($.$$.System.Char, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Char, charsToUnescape), $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, destination));
                if (overlapped)
                {
                    vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                    vsb.EnsureCapacity(((charsToUnescape.Length - indexOfFirstToUnescape) | 0));
                }
                else 
                {
                    vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4(destination.Slice$1(indexOfFirstToUnescape));
                }
                $.$spu.System.UriHelper.UnescapeString$2(charsToUnescape.Slice$1(indexOfFirstToUnescape), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, null, false);
                /*int*/ let newLength = ((indexOfFirstToUnescape + vsb.Length) | 0);
                $.$$.System.Diagnostics.Debug.Assert$2(newLength <= charsToUnescape.Length, "newLength <= charsToUnescape.Length");
                if (destination.Length >= newLength)
                {
                    charsToUnescape.Slice(0, indexOfFirstToUnescape).CopyTo(destination);
                    if (overlapped)
                    {
                        vsb.AsSpan().CopyTo(destination.Slice$1(indexOfFirstToUnescape));
                        vsb.Dispose();
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.MemoryExtensions.Overlaps$1($.$$.System.Char, $.$$.System.Span$$($.$$.System.Char).op_Implicit(vsb.RawChars), $.$$.System.Span$$($.$$.System.Char).op_Implicit(destination)), "vsb.RawChars.Overlaps(destination)");
                    }
                    charsWritten.$v = newLength;
                    return true;
                }
                vsb.Dispose();
                charsWritten.$v = 0;
                return false;
            }
            static /*string */ EscapeUriString(/*string*/ stringToEscape)
            {
                return $.$spu.System.UriHelper.EscapeString$2(stringToEscape, false, $.$spu.System.UriHelper.UnreservedReserved);
            }
            static /*string */ EscapeDataString$1(/*string*/ stringToEscape)
            {
                return $.$spu.System.UriHelper.EscapeString$2(stringToEscape, false, $.$spu.System.UriHelper.Unreserved);
            }
            static /*string */ EscapeDataString(/*ReadOnlySpan<char>*/ charsToEscape)
            {
                return $.$spu.System.UriHelper.EscapeString(charsToEscape, false, $.$spu.System.UriHelper.Unreserved, null);
            }
            static /*bool */ TryEscapeDataString(/*ReadOnlySpan<char>*/ charsToEscape, /*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                return $.$spu.System.UriHelper.TryEscapeDataString(charsToEscape, destination, charsWritten);
            }
            /*string */ EscapeUnescapeIri(/*string*/ input, /*int*/ start, /*int*/ end, /*UriComponents*/ component)
            {
                /*fixed*/ 
                {
                    /*char**/ let pInput = $.$$.System.String.GetPinnableReference.call(input);
                    return $.$spu.System.IriHelper.EscapeUnescapeIri(pInput, start, end, component);
                }
            }
            $ctor$9(/*Flags*/ flags, /*UriParser?*/ uriParser, /*string*/ uri)
            {
                super.$ctor();
                {
                    this._flags = flags;
                    this._syntax = uriParser;
                    this._string = uri;
                    if (uriParser === null)
                    {
                        this.DebugSetLeftCtor();
                    }
                }
                return this;
            }
            static /*Uri? */ CreateHelper(/*string*/ uriString, /*bool*/ dontEscape, /*UriKind*/ uriKind, /*ref UriFormatException?*/ e, /*in UriCreationOptions*/ creationOptions)
            {
                if (uriKind < 0/*UriKind.RelativeOrAbsolute*/ || uriKind > 2/*UriKind.Relative*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_InvalidUriKind, $.$box(uriKind, $.$spu.System.UriKind)));
                }
                /*UriParser?*/ let syntax = null;
                /*Flags*/ let flags = 0n;
                /*ParsingError*/ let err = $.$spu.System.Uri.ParseScheme(uriString, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => flags, ($v) => flags = $v, null), $.$ref(() => syntax, ($v) => syntax = $v, $.$spu.System.UriParser));
                if (dontEscape)
                {
                    flags |= 34359738368n;
                }
                if (creationOptions.$v.DangerousDisablePathAndQueryCanonicalization)
                {
                    flags |= 36028797018963968n;
                }
                if (err !== 0/*ParsingError.None*/)
                {
                    if (uriKind !== 1/*UriKind.Absolute*/ && err <= 5/*ParsingError.LastErrorOkayForRelativeUris*/)
                    {
                        return new $.$spu.System.Uri().$ctor$9((flags & 34359738368n), null, uriString);
                    }
                    return null;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(syntax !== null, "syntax != null");
                /*Uri*/ let result = new $.$spu.System.Uri().$ctor$9(flags, syntax, uriString);
                try
                {
                    result.InitializeUri(err, uriKind, e);
                    if (e.$v === null)
                    {
                        result.DebugSetLeftCtor();
                        return result;
                    }
                    return null;
                }
                catch(ee)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!syntax.IsSimple, "A UriPraser threw on InitializeAndValidate.");
                    e.$v = ee;
                    return null;
                }
            }
            static /*Uri? */ ResolveHelper(/*Uri*/ baseUri, /*Uri?*/ relativeUri, /*ref string?*/ newUriString, /*ref bool*/ userEscaped)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!baseUri.IsNotAbsoluteUri && !baseUri.UserDrivenParsing, "Uri::ResolveHelper()|baseUri is not Absolute or is controlled by User Parser.");
                /*string*/ let relativeStr;
                if (!(relativeUri === null))
                {
                    if (relativeUri.IsAbsoluteUri)
                    {
                        return relativeUri;
                    }
                    relativeStr = relativeUri.OriginalString;
                    userEscaped.$v = relativeUri.UserEscaped;
                }
                else 
                {
                    relativeStr = $.$$.System.String.Empty;
                }
                if (relativeStr.length > 0 && ($.$spu.System.UriHelper.IsLWS($.$$.System.String.get_Chars.call(relativeStr, 0)) || $.$spu.System.UriHelper.IsLWS($.$$.System.String.get_Chars.call(relativeStr, ((relativeStr.length - 1) | 0)))))
                {
                    relativeStr = $.$$.System.String.Trim$2.call(relativeStr, $.$spu.System.UriHelper.s_WSchars);
                }
                if (relativeStr.length === 0)
                {
                    newUriString.$v = baseUri.GetParts(127/*UriComponents.AbsoluteUri*/, baseUri.UserEscaped ? 1/*UriFormat.UriEscaped*/ : 3/*UriFormat.SafeUnescaped*/);
                    return null;
                }
                if ($.$$.System.String.get_Chars.call(relativeStr, 0) === /*#*/ 35 && !baseUri.IsImplicitFile && baseUri.Syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/))
                {
                    newUriString.$v = baseUri.GetParts(127/*UriComponents.AbsoluteUri*/ & ~64/*UriComponents.Fragment*/, 1/*UriFormat.UriEscaped*/) + relativeStr;
                    return null;
                }
                if ($.$$.System.String.get_Chars.call(relativeStr, 0) === /*?*/ 63 && !baseUri.IsImplicitFile && baseUri.Syntax.InFact(32/*UriSyntaxFlags.MayHaveQuery*/))
                {
                    newUriString.$v = baseUri.GetParts(127/*UriComponents.AbsoluteUri*/ & ~32/*UriComponents.Query*/ & ~64/*UriComponents.Fragment*/, 1/*UriFormat.UriEscaped*/) + relativeStr;
                    return null;
                }
                if (relativeStr.length >= 3 && ($.$$.System.String.get_Chars.call(relativeStr, 1) === /*:*/ 58 || $.$$.System.String.get_Chars.call(relativeStr, 1) === /*|*/ 124) && $.$$.System.Char.IsAsciiLetter($.$$.System.String.get_Chars.call(relativeStr, 0)) && ($.$$.System.String.get_Chars.call(relativeStr, 2) === /*\\*/ 92 || $.$$.System.String.get_Chars.call(relativeStr, 2) === /*/*/ 47))
                {
                    if (baseUri.IsImplicitFile)
                    {
                        newUriString.$v = relativeStr;
                        return null;
                    }
                    else if (baseUri.Syntax.InFact(1048576/*UriSyntaxFlags.AllowDOSPath*/))
                    {
                        /*string*/ let prefix;
                        if (baseUri.InFact(68719476736n))
                        {
                            prefix = baseUri.Syntax.InFact(2097152/*UriSyntaxFlags.PathIsRooted*/) ? ":///" : "://";
                        }
                        else 
                        {
                            prefix = baseUri.Syntax.InFact(2097152/*UriSyntaxFlags.PathIsRooted*/) ? ":/" : ":";
                        }
                        newUriString.$v = baseUri.Scheme + prefix + relativeStr;
                        return null;
                    }
                }
                $.$spu.System.Uri.GetCombinedString(baseUri, relativeStr, userEscaped.$v, newUriString);
                if ($.$$.System.Object.ReferenceEquals(newUriString.$v, baseUri._string))
                {
                    return baseUri;
                }
                return null;
            }
            /*string */ GetRelativeSerializationString(/*UriFormat*/ format)
            {
                if (format === 1/*UriFormat.UriEscaped*/)
                {
                    return $.$spu.System.UriHelper.EscapeString$2(this._string, true, $.$spu.System.UriHelper.UnreservedReserved);
                }
                else if (format === 2/*UriFormat.Unescaped*/)
                {
                    return $.$spu.System.Uri.UnescapeDataString$2(this._string);
                }
                else if (format === 3/*UriFormat.SafeUnescaped*/)
                {
                    if (this._string.length === 0)
                    {
                        return $.$$.System.String.Empty;
                    }
                    /*var*/ let vsb = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                    $.$spu.System.UriHelper.UnescapeString$2($.$$.System.String.op_Implicit(this._string), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 3/*UnescapeMode.EscapeUnescape*/, null, false);
                    return $.$spu.System.Text.ValueStringBuilder.ToString.call(vsb);
                }
                else 
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("format");
                }
            }
            /*string */ GetComponentsHelper(/*UriComponents*/ uriComponents, /*UriFormat*/ uriFormat)
            {
                if (uriComponents === 1/*UriComponents.Scheme*/)
                {
                    return this._syntax.SchemeName;
                }
                if ((uriComponents & -2147483648/*UriComponents.SerializationInfoString*/) !== 0)
                {
                    uriComponents |= 127/*UriComponents.AbsoluteUri*/;
                }
                this.EnsureParseRemaining();
                if ((uriComponents & 256/*UriComponents.NormalizedHost*/) !== 0)
                {
                    uriComponents |= 4/*UriComponents.Host*/;
                }
                if ((uriComponents & 4/*UriComponents.Host*/) !== 0)
                {
                    this.EnsureHostString(true);
                }
                if (uriComponents === 8/*UriComponents.Port*/ || uriComponents === 128/*UriComponents.StrongPort*/)
                {
                    if (((this._flags & 549755813888n) !== 0n) || (uriComponents === 128/*UriComponents.StrongPort*/ && this._syntax.DefaultPort !== -1/*UriParser.NoDefaultPort*/))
                    {
                        return $.$$.System.UInt16.ToString$1.call(this._info.Offset.PortValue, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    }
                    return $.$$.System.String.Empty;
                }
                if ((uriComponents & 128/*UriComponents.StrongPort*/) !== 0)
                {
                    uriComponents |= 8/*UriComponents.Port*/;
                }
                if (uriComponents === 4/*UriComponents.Host*/ && (uriFormat === 1/*UriFormat.UriEscaped*/ || ((this._flags & (4n | 256n)) === 0n)))
                {
                    this.EnsureHostString(false);
                    return this._info.Host;
                }
                switch(uriFormat)
                {
                    case 1/*UriFormat.UriEscaped*/:
                    return this.GetEscapedParts(uriComponents);
                    case 32767/*V1ToStringUnescape*/:
                    case 3/*UriFormat.SafeUnescaped*/:
                    case 2/*UriFormat.Unescaped*/:
                    return this.GetUnescapedParts(uriComponents, uriFormat);
                    default:
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("uriFormat");
                }
            }
            /*bool */ IsBaseOf(/*Uri*/ uri)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                if (!this.IsAbsoluteUri)
                {
                    return false;
                }
                if (this.Syntax.IsSimple)
                {
                    return this.IsBaseOfHelper(uri);
                }
                return this.Syntax.InternalIsBaseOf(this, uri);
            }
            /*bool */ IsBaseOfHelper(/*Uri*/ uriLink)
            {
                /*UriComponents*/ let ComponentsToCompare = 127/*UriComponents.AbsoluteUri*/ & ~64/*UriComponents.Fragment*/ & ~2/*UriComponents.UserInfo*/;
                if (!this.IsAbsoluteUri || this.UserDrivenParsing)
                {
                    return false;
                }
                if (!uriLink.IsAbsoluteUri)
                {
                    /*string?*/ let newUriString = null;
                    /*bool*/ let dontEscape = false;
                    uriLink = $.$spu.System.Uri.ResolveHelper(this, uriLink, $.$ref(() => newUriString, ($v) => newUriString = $v, $.$$.System.String), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => dontEscape, ($v) => dontEscape = $v, null));
                    if (uriLink === null)
                    {
                        /*UriFormatException?*/ let e = null;
                        let $v4 = new $.$spu.System.UriCreationOptions();
                        uriLink = $.$spu.System.Uri.CreateHelper(newUriString, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException), $.$ref(() => $v4, ($v) => $v4 = $v));
                        if (e !== null)
                        {
                            return false;
                        }
                    }
                }
                if ($.$$.System.String.op_Inequality(this.Syntax.SchemeName, uriLink.Syntax.SchemeName))
                {
                    return false;
                }
                /*string*/ let self = this.GetParts(ComponentsToCompare, 3/*UriFormat.SafeUnescaped*/);
                /*string*/ let other = uriLink.GetParts(ComponentsToCompare, 3/*UriFormat.SafeUnescaped*/);
                {
                    /*fixed*/ 
                    {
                        /*char**/ let selfPtr = $.$$.System.String.GetPinnableReference.call(self);
                        /*fixed*/ 
                        {
                            /*char**/ let otherPtr = $.$$.System.String.GetPinnableReference.call(other);
                            return $.$spu.System.UriHelper.TestForSubPath(selfPtr, self.length, otherPtr, other.length, this.IsUncOrDosPath || uriLink.IsUncOrDosPath);
                        }
                    }
                }
            }
            /*void */ CreateThisFromUri(/*Uri*/ otherUri)
            {
                this.DebugAssertInCtor();
                this._flags = otherUri._flags;
                if (this.InFact(140737488355328n))
                {
                    this._info = otherUri._info;
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!this.InFact(562949953421312n) || otherUri.IsNotAbsoluteUri, "!InFact(Flags.HasUnicode) || otherUri.IsNotAbsoluteUri");
                    this._info = null;
                    if (this.InFact(70368744177664n))
                    {
                        this._flags &= ~(70368744177664n | 140737488355328n | 4294967295n);
                        /*int*/ let portIndex = otherUri._info.Offset.Path;
                        if (this.InFact(549755813888n))
                        {
                            while($.$$.System.String.get_Chars.call(otherUri._string, portIndex) !== /*:*/ 58 && portIndex > otherUri._info.Offset.Host)
                            {
                                portIndex--;
                            }
                            if ($.$$.System.String.get_Chars.call(otherUri._string, portIndex) !== /*:*/ 58)
                            {
                                $.$$.System.Diagnostics.Debug.Fail$1("Uri failed to locate custom port at index: " + portIndex);
                                portIndex = otherUri._info.Offset.Path;
                            }
                        }
                        this._flags |= $.$cast(portIndex, $.$spu.System.Uri.Flags);
                    }
                }
                this._syntax = otherUri._syntax;
                this._string = otherUri._string;
                this._originalUnicodeString = otherUri._originalUnicodeString;
            }
            /*string*/ static UriSchemeFile = null;
            /*string*/ static UriSchemeFtp = null;
            /*string*/ static UriSchemeSftp = null;
            /*string*/ static UriSchemeFtps = null;
            /*string*/ static UriSchemeGopher = null;
            /*string*/ static UriSchemeHttp = null;
            /*string*/ static UriSchemeHttps = null;
            /*string*/ static UriSchemeWs = null;
            /*string*/ static UriSchemeWss = null;
            /*string*/ static UriSchemeMailto = null;
            /*string*/ static UriSchemeNews = null;
            /*string*/ static UriSchemeNntp = null;
            /*string*/ static UriSchemeSsh = null;
            /*string*/ static UriSchemeTelnet = null;
            /*string*/ static UriSchemeNetTcp = null;
            /*string*/ static UriSchemeNetPipe = null;
            /*string*/ static SchemeDelimiter = null;
            /*int*/ static SchemeLengthLimit = 1024;
            /*int*/ static StackallocThreshold = 512;
            /*string*/ _string = null;
            /*string*/ _originalUnicodeString = null;
            /*UriParser*/ _syntax = null;
            /*Flags*/ _flags = 0n;
            /*UriInfo*/ _info = null;
            static $_Flags;
            static get Flags()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_Flags ??= $asm.$nstr("$spu.System.Uri.Flags", ($self) => class Flags extends $.$$.System.Enum
                {
                    static Zero = 0n;
                    static SchemeNotCanonical = 1n;
                    static UserNotCanonical = 2n;
                    static HostNotCanonical = 4n;
                    static PortNotCanonical = 8n;
                    static PathNotCanonical = 16n;
                    static QueryNotCanonical = 32n;
                    static FragmentNotCanonical = 64n;
                    static CannotDisplayCanonical = 127n;
                    static E_UserNotCanonical = 128n;
                    static E_HostNotCanonical = 256n;
                    static E_PortNotCanonical = 512n;
                    static E_PathNotCanonical = 1024n;
                    static E_QueryNotCanonical = 2048n;
                    static E_FragmentNotCanonical = 4096n;
                    static E_CannotDisplayCanonical = 8064n;
                    static ShouldBeCompressed = 8192n;
                    static FirstSlashAbsent = 16384n;
                    static BackslashInPath = 32768n;
                    static IndexMask = 4294967295n;
                    static HostTypeMask = 30064771072n;
                    static HostNotParsed = 0n;
                    static IPv6HostType = 4294967296n;
                    static IPv4HostType = 8589934592n;
                    static DnsHostType = 12884901888n;
                    static UncHostType = 17179869184n;
                    static BasicHostType = 21474836480n;
                    static UnusedHostType = 25769803776n;
                    static UnknownHostType = 30064771072n;
                    static UserEscaped = 34359738368n;
                    static AuthorityFound = 68719476736n;
                    static HasUserInfo = 137438953472n;
                    static LoopbackHost = 274877906944n;
                    static NotDefaultPort = 549755813888n;
                    static UserDrivenParsing = 1099511627776n;
                    static CanonicalDnsHost = 2199023255552n;
                    static ErrorOrParsingRecursion = 4398046511104n;
                    static DosPath = 8796093022208n;
                    static UncPath = 17592186044416n;
                    static ImplicitFile = 35184372088832n;
                    static MinimalUriInfoSet = 70368744177664n;
                    static AllUriInfoSet = 140737488355328n;
                    static IdnHost = 281474976710656n;
                    static HasUnicode = 562949953421312n;
                    static UserIriCanonical = 1125899906842624n;
                    static PathIriCanonical = 2251799813685248n;
                    static QueryIriCanonical = 4503599627370496n;
                    static FragmentIriCanonical = 9007199254740992n;
                    static IriCanonical = 16888498602639360n;
                    static UnixPath = 18014398509481984n;
                    static DisablePathAndQueryCanonicalization = 36028797018963968n;
                    static CustomParser_ParseMinimalAlreadyCalled = 72057594037927936n;
                    static Debug_LeftConstructor = 144115188075855872n;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Zero": 0n,
                            "SchemeNotCanonical": 1n,
                            "UserNotCanonical": 2n,
                            "HostNotCanonical": 4n,
                            "PortNotCanonical": 8n,
                            "PathNotCanonical": 16n,
                            "QueryNotCanonical": 32n,
                            "FragmentNotCanonical": 64n,
                            "CannotDisplayCanonical": 127n,
                            "E_UserNotCanonical": 128n,
                            "E_HostNotCanonical": 256n,
                            "E_PortNotCanonical": 512n,
                            "E_PathNotCanonical": 1024n,
                            "E_QueryNotCanonical": 2048n,
                            "E_FragmentNotCanonical": 4096n,
                            "E_CannotDisplayCanonical": 8064n,
                            "ShouldBeCompressed": 8192n,
                            "FirstSlashAbsent": 16384n,
                            "BackslashInPath": 32768n,
                            "IndexMask": 4294967295n,
                            "HostTypeMask": 30064771072n,
                            "HostNotParsed": 0n,
                            "IPv6HostType": 4294967296n,
                            "IPv4HostType": 8589934592n,
                            "DnsHostType": 12884901888n,
                            "UncHostType": 17179869184n,
                            "BasicHostType": 21474836480n,
                            "UnusedHostType": 25769803776n,
                            "UnknownHostType": 30064771072n,
                            "UserEscaped": 34359738368n,
                            "AuthorityFound": 68719476736n,
                            "HasUserInfo": 137438953472n,
                            "LoopbackHost": 274877906944n,
                            "NotDefaultPort": 549755813888n,
                            "UserDrivenParsing": 1099511627776n,
                            "CanonicalDnsHost": 2199023255552n,
                            "ErrorOrParsingRecursion": 4398046511104n,
                            "DosPath": 8796093022208n,
                            "UncPath": 17592186044416n,
                            "ImplicitFile": 35184372088832n,
                            "MinimalUriInfoSet": 70368744177664n,
                            "AllUriInfoSet": 140737488355328n,
                            "IdnHost": 281474976710656n,
                            "HasUnicode": 562949953421312n,
                            "UserIriCanonical": 1125899906842624n,
                            "PathIriCanonical": 2251799813685248n,
                            "QueryIriCanonical": 4503599627370496n,
                            "FragmentIriCanonical": 9007199254740992n,
                            "IriCanonical": 16888498602639360n,
                            "UnixPath": 18014398509481984n,
                            "DisablePathAndQueryCanonicalization": 36028797018963968n,
                            "CustomParser_ParseMinimalAlreadyCalled": 72057594037927936n,
                            "Debug_LeftConstructor": 144115188075855872n
                        };
                    }
                    static $h = 1877292;
                    static $z = 8;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.UInt64; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":983041,"l":[{"t":1877292,"n":"Zero","d":1877292,"h":4296844588,"f":4194337},{"t":1877292,"n":"SchemeNotCanonical","d":1877292,"h":8591811884,"f":4194337},{"t":1877292,"n":"UserNotCanonical","d":1877292,"h":12886779180,"f":4194337},{"t":1877292,"n":"HostNotCanonical","d":1877292,"h":17181746476,"f":4194337},{"t":1877292,"n":"PortNotCanonical","d":1877292,"h":21476713772,"f":4194337},{"t":1877292,"n":"PathNotCanonical","d":1877292,"h":25771681068,"f":4194337},{"t":1877292,"n":"QueryNotCanonical","d":1877292,"h":30066648364,"f":4194337},{"t":1877292,"n":"FragmentNotCanonical","d":1877292,"h":34361615660,"f":4194337},{"t":1877292,"n":"CannotDisplayCanonical","d":1877292,"h":38656582956,"f":4194337},{"t":1877292,"n":"E_UserNotCanonical","d":1877292,"h":42951550252,"f":4194337},{"t":1877292,"n":"E_HostNotCanonical","d":1877292,"h":47246517548,"f":4194337},{"t":1877292,"n":"E_PortNotCanonical","d":1877292,"h":51541484844,"f":4194337},{"t":1877292,"n":"E_PathNotCanonical","d":1877292,"h":55836452140,"f":4194337},{"t":1877292,"n":"E_QueryNotCanonical","d":1877292,"h":60131419436,"f":4194337},{"t":1877292,"n":"E_FragmentNotCanonical","d":1877292,"h":64426386732,"f":4194337},{"t":1877292,"n":"E_CannotDisplayCanonical","d":1877292,"h":68721354028,"f":4194337},{"t":1877292,"n":"ShouldBeCompressed","d":1877292,"h":73016321324,"f":4194337},{"t":1877292,"n":"FirstSlashAbsent","d":1877292,"h":77311288620,"f":4194337},{"t":1877292,"n":"BackslashInPath","d":1877292,"h":81606255916,"f":4194337},{"t":1877292,"n":"IndexMask","d":1877292,"h":85901223212,"f":4194337},{"t":1877292,"n":"HostTypeMask","d":1877292,"h":90196190508,"f":4194337},{"t":1877292,"n":"HostNotParsed","d":1877292,"h":94491157804,"f":4194337},{"t":1877292,"n":"IPv6HostType","d":1877292,"h":98786125100,"f":4194337},{"t":1877292,"n":"IPv4HostType","d":1877292,"h":103081092396,"f":4194337},{"t":1877292,"n":"DnsHostType","d":1877292,"h":107376059692,"f":4194337},{"t":1877292,"n":"UncHostType","d":1877292,"h":111671026988,"f":4194337},{"t":1877292,"n":"BasicHostType","d":1877292,"h":115965994284,"f":4194337},{"t":1877292,"n":"UnusedHostType","d":1877292,"h":120260961580,"f":4194337},{"t":1877292,"n":"UnknownHostType","d":1877292,"h":124555928876,"f":4194337},{"t":1877292,"n":"UserEscaped","d":1877292,"h":128850896172,"f":4194337},{"t":1877292,"n":"AuthorityFound","d":1877292,"h":133145863468,"f":4194337},{"t":1877292,"n":"HasUserInfo","d":1877292,"h":137440830764,"f":4194337},{"t":1877292,"n":"LoopbackHost","d":1877292,"h":141735798060,"f":4194337},{"t":1877292,"n":"NotDefaultPort","d":1877292,"h":146030765356,"f":4194337},{"t":1877292,"n":"UserDrivenParsing","d":1877292,"h":150325732652,"f":4194337},{"t":1877292,"n":"CanonicalDnsHost","d":1877292,"h":154620699948,"f":4194337},{"t":1877292,"n":"ErrorOrParsingRecursion","d":1877292,"h":158915667244,"f":4194337},{"t":1877292,"n":"DosPath","d":1877292,"h":163210634540,"f":4194337},{"t":1877292,"n":"UncPath","d":1877292,"h":167505601836,"f":4194337},{"t":1877292,"n":"ImplicitFile","d":1877292,"h":171800569132,"f":4194337},{"t":1877292,"n":"MinimalUriInfoSet","d":1877292,"h":176095536428,"f":4194337},{"t":1877292,"n":"AllUriInfoSet","d":1877292,"h":180390503724,"f":4194337},{"t":1877292,"n":"IdnHost","d":1877292,"h":184685471020,"f":4194337},{"t":1877292,"n":"HasUnicode","d":1877292,"h":188980438316,"f":4194337},{"t":1877292,"n":"UserIriCanonical","d":1877292,"h":193275405612,"f":4194337},{"t":1877292,"n":"PathIriCanonical","d":1877292,"h":197570372908,"f":4194337},{"t":1877292,"n":"QueryIriCanonical","d":1877292,"h":201865340204,"f":4194337},{"t":1877292,"n":"FragmentIriCanonical","d":1877292,"h":206160307500,"f":4194337},{"t":1877292,"n":"IriCanonical","d":1877292,"h":210455274796,"f":4194337},{"t":1877292,"n":"UnixPath","d":1877292,"h":214750242092,"f":4194337},{"t":1877292,"n":"DisablePathAndQueryCanonicalization","d":1877292,"h":219045209388,"f":4194337},{"t":1877292,"n":"CustomParser_ParseMinimalAlreadyCalled","d":1877292,"h":223340176684,"f":4194337},{"t":1877292,"n":"Debug_LeftConstructor","d":1877292,"h":227635143980,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1877292,"h":231930111276,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":1746220,"h":1877292,"a":[{"t":47710209,"c":4342677505}]}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Uri.Flags`; }
                }, $cls, ($v) => $cls.$_Flags = $v);
            }
            /*void */ DebugSetLeftCtor()
            {
                this._flags |= 144115188075855872n;
                this.AssertInvariants();
            }
            /*void */ AssertInvariants()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.InFact(70368744177664n) === (!(this._info === null)), "InFact(Flags.MinimalUriInfoSet) == (_info is not null)");
                let info;
                if ($.$is(this._info, $.$spu.System.Uri.UriInfo, { set $v(v){ info = v; } }))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this.IsAbsoluteUri, "IsAbsoluteUri");
                    /*Offset*/ let offset = info.Offset;
                    $.$$.System.Diagnostics.Debug.Assert$2(offset.Scheme >= 0, "offset.Scheme >= 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(offset.User >= 0 && offset.User >= offset.Scheme, "offset.User >= 0 && offset.User >= offset.Scheme");
                    $.$$.System.Diagnostics.Debug.Assert$2(offset.Host >= 0 && offset.Host >= offset.User, "offset.Host >= 0 && offset.Host >= offset.User");
                    $.$$.System.Diagnostics.Debug.Assert$2(offset.Path >= 0, "offset.Path >= 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(offset.End >= 0 && offset.End >= offset.Path, "offset.End >= 0 && offset.End >= offset.Path");
                    if (this.InFact(140737488355328n))
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(offset.Path >= offset.Host, "offset.Path >= offset.Host");
                        $.$$.System.Diagnostics.Debug.Assert$2(offset.Query >= 0 && offset.Query >= offset.Path, "offset.Query >= 0 && offset.Query >= offset.Path");
                        $.$$.System.Diagnostics.Debug.Assert$2(offset.Fragment >= 0 && offset.Fragment >= offset.Query, "offset.Fragment >= 0 && offset.Fragment >= offset.Query");
                        $.$$.System.Diagnostics.Debug.Assert$2(offset.End >= offset.Fragment && offset.End <= this._string.length, "offset.End >= offset.Fragment && offset.End <= _string.Length");
                    }
                    else 
                    {
                        if (!this.InFact(562949953421312n))
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(offset.Path >= offset.Host, "offset.Path >= offset.Host");
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(offset.Query === 0, "offset.Query == 0");
                        $.$$.System.Diagnostics.Debug.Assert$2(offset.Fragment === 0, "offset.Fragment == 0");
                    }
                }
                else 
                {
                    if (this.IsAbsoluteUri && this.IriParsing)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Text.Ascii.IsValid$3($.$$.System.String.op_Implicit(this._string)), "Ascii.IsValid(_string)");
                    }
                }
            }
            /*void */ DebugAssertInCtor()
            {
                $.$$.System.Diagnostics.Debug.Assert$2((this._flags & 144115188075855872n) === 0n, "(_flags & Flags.Debug_LeftConstructor) == 0");
            }
            static $_UriInfo;
            static get UriInfo()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_UriInfo ??= $asm.$ncls("$spu.System.Uri.UriInfo", ($self) => class UriInfo extends $.$$.System.Object
                {
                    /*Offset*/ Offset;
                    /*string?*/ String = null;
                    /*string?*/ Host = null;
                    /*string?*/ IdnHost = null;
                    /*string?*/ PathAndQuery = null;
                    /*MoreInfo?*/ _moreInfo = null;
                    /*MoreInfo */ get MoreInfo()
                    {
                        if (this._moreInfo === null)
                        {
                            $.$$.System.Threading.Interlocked.CompareExchange$14($.$spu.System.Uri.MoreInfo, $.$ref(() => this._moreInfo, ($v) => this._moreInfo = $v, $.$spu.System.Uri.MoreInfo), new $.$spu.System.Uri.MoreInfo().$ctor$1(), null);
                        }
                        return this._moreInfo;
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Offset = $.$default($.$spu.System.Uri.Offset);
                    }
                    static $h = 2073900;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1942828,"g":{"r":0,"d":0,"h":34361812268,"f":50331649},"n":"MoreInfo","d":2073900,"h":30066844972,"f":2097153}],"l":[{"t":2008364,"n":"Offset","d":2073900,"h":4297041196,"f":4194305},{"t":1310721,"n":"String","d":2073900,"h":8592008492,"f":4194305},{"t":1310721,"n":"Host","d":2073900,"h":12886975788,"f":4194305},{"t":1310721,"n":"IdnHost","d":2073900,"h":17181943084,"f":4194305},{"t":1310721,"n":"PathAndQuery","d":2073900,"h":21476910380,"f":4194305},{"t":1942828,"n":"_moreInfo","d":2073900,"h":25771877676,"f":4194305}],"c":[{"n":".ctor","o":"$ctor$1","d":2073900,"h":38656779564,"f":16777217}],"d":1746220,"h":2073900}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Uri.UriInfo`; }
                }, $cls, ($v) => $cls.$_UriInfo = $v);
            }
            static $_Offset;
            static get Offset()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_Offset ??= $asm.$nstr("$spu.System.Uri.Offset", ($self) => class Offset extends $.$$.System.ValueType
                {
                    /*int*/  get Scheme() { return this.$getField(0, $.$$.System.Int32); }
                    /*int*/  set Scheme(value) { this.$setField(0, $.$$.System.Int32, value); }
                    /*int*/  get User() { return this.$getField(4, $.$$.System.Int32); }
                    /*int*/  set User(value) { this.$setField(4, $.$$.System.Int32, value); }
                    /*int*/  get Host() { return this.$getField(8, $.$$.System.Int32); }
                    /*int*/  set Host(value) { this.$setField(8, $.$$.System.Int32, value); }
                    /*ushort*/  get PortValue() { return this.$getField(12, $.$$.System.UInt16); }
                    /*ushort*/  set PortValue(value) { this.$setField(12, $.$$.System.UInt16, value); }
                    /*int*/  get Path() { return this.$getField(14, $.$$.System.Int32); }
                    /*int*/  set Path(value) { this.$setField(14, $.$$.System.Int32, value); }
                    /*int*/  get Query() { return this.$getField(18, $.$$.System.Int32); }
                    /*int*/  set Query(value) { this.$setField(18, $.$$.System.Int32, value); }
                    /*int*/  get Fragment() { return this.$getField(22, $.$$.System.Int32); }
                    /*int*/  set Fragment(value) { this.$setField(22, $.$$.System.Int32, value); }
                    /*int*/  get End() { return this.$getField(26, $.$$.System.Int32); }
                    /*int*/  set End(value) { this.$setField(26, $.$$.System.Int32, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Scheme = this.Scheme;
                        copy.User = this.User;
                        copy.Host = this.Host;
                        copy.PortValue = this.PortValue;
                        copy.Path = this.Path;
                        copy.Query = this.Query;
                        copy.Fragment = this.Fragment;
                        copy.End = this.End;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Scheme = 0;
                        this.User = 0;
                        this.Host = 0;
                        this.PortValue = 0;
                        this.Path = 0;
                        this.Query = 0;
                        this.Fragment = 0;
                        this.End = 0;
                    }
                    static $h = 2008364;
                    static $z = 30;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"Scheme","d":2008364,"h":4296975660,"f":4194305},{"t":655361,"n":"User","d":2008364,"h":8591942956,"f":4194305},{"t":655361,"n":"Host","d":2008364,"h":12886910252,"f":4194305},{"t":589825,"n":"PortValue","d":2008364,"h":17181877548,"f":4194305},{"t":655361,"n":"Path","d":2008364,"h":21476844844,"f":4194305},{"t":655361,"n":"Query","d":2008364,"h":25771812140,"f":4194305},{"t":655361,"n":"Fragment","d":2008364,"h":30066779436,"f":4194305},{"t":655361,"n":"End","d":2008364,"h":34361746732,"f":4194305}],"c":[{"n":".ctor","o":"$ctor$2","d":2008364,"h":38656714028,"f":16777217}],"d":1746220,"h":2008364}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Uri.Offset`; }
                }, $cls, ($v) => $cls.$_Offset = $v);
            }
            static $_MoreInfo;
            static get MoreInfo()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_MoreInfo ??= $asm.$ncls("$spu.System.Uri.MoreInfo", ($self) => class MoreInfo extends $.$$.System.Object
                {
                    /*string?*/ Path = null;
                    /*string?*/ Query = null;
                    /*string?*/ Fragment = null;
                    /*string?*/ AbsoluteUri = null;
                    /*string?*/ RemoteUrl = null;
                    /*string?*/ ScopeId = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 1942828;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"Path","d":1942828,"h":4296910124,"f":4194305},{"t":1310721,"n":"Query","d":1942828,"h":8591877420,"f":4194305},{"t":1310721,"n":"Fragment","d":1942828,"h":12886844716,"f":4194305},{"t":1310721,"n":"AbsoluteUri","d":1942828,"h":17181812012,"f":4194305},{"t":1310721,"n":"RemoteUrl","d":1942828,"h":21476779308,"f":4194305},{"t":1310721,"n":"ScopeId","d":1942828,"h":25771746604,"f":4194305}],"c":[{"n":".ctor","o":"$ctor$1","d":1942828,"h":30066713900,"f":16777217}],"d":1746220,"h":1942828}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Uri.MoreInfo`; }
                }, $cls, ($v) => $cls.$_MoreInfo = $v);
            }
            /*void */ InterlockedSetFlags(/*Flags*/ flags)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._syntax !== null, "_syntax != null");
                if (this._syntax.IsSimple)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$spu.System.Uri.Flags.$z === $.$$.System.UInt64.$z, "sizeof(Flags) == sizeof(ulong)");
                    $.$$.System.Threading.Interlocked.Or$3($.$$.System.Runtime.CompilerServices.Unsafe.As($.$spu.System.Uri.Flags, $.$$.System.UInt64, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => this._flags, ($v) => this._flags = $v, null)), flags);
                }
                else 
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._info)
                        {
                            this._flags |= flags;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._info)
                    }
                }
            }
            /*bool */ get IsImplicitFile()
            {
                return (this._flags & 35184372088832n) !== 0n;
            }
            /*bool */ get IsUncOrDosPath()
            {
                return (this._flags & (17592186044416n | 8796093022208n)) !== 0n;
            }
            /*bool */ get IsDosPath()
            {
                return (this._flags & 8796093022208n) !== 0n;
            }
            /*bool */ get IsUncPath()
            {
                return (this._flags & 17592186044416n) !== 0n;
            }
            /*bool */ get IsUnixPath()
            {
                return (this._flags & 18014398509481984n) !== 0n;
            }
            /*Flags */ get HostType()
            {
                return this._flags & 30064771072n;
            }
            /*UriParser */ get Syntax()
            {
                return this._syntax;
            }
            /*bool */ get IsNotAbsoluteUri()
            {
                return this._syntax === null;
            }
            /*bool */ get IriParsing()
            {
                return $.$spu.System.Uri.IriParsingStatic(this._syntax);
            }
            static /*bool */ IriParsingStatic(/*UriParser?*/ syntax)
            {
                return syntax === null || syntax.InFact(268435456/*UriSyntaxFlags.AllowIriParsing*/);
            }
            /*bool */ get DisablePathAndQueryCanonicalization()
            {
                return (this._flags & 36028797018963968n) !== 0n;
            }
            /*bool */ get UserDrivenParsing()
            {
                return (this._flags & 1099511627776n) !== 0n;
            }
            /*int */ get SecuredPathIndex()
            {
                if (this.IsDosPath)
                {
                    /*char*/ let ch = $.$$.System.String.get_Chars.call(this._string, this._info.Offset.Path);
                    return (ch === /*/*/ 47 || ch === /*\\*/ 92) ? 3 : 2;
                }
                return 0;
            }
            /*bool */ NotAny(/*Flags*/ flags)
            {
                return (this._flags & flags) === 0n;
            }
            /*bool */ InFact(/*Flags*/ flags)
            {
                return (this._flags & flags) !== 0n;
            }
            static /*bool */ StaticNotAny(/*Flags*/ allFlags, /*Flags*/ checkFlags)
            {
                return (allFlags & checkFlags) === 0n;
            }
            static /*bool */ StaticInFact(/*Flags*/ allFlags, /*Flags*/ checkFlags)
            {
                return (allFlags & checkFlags) !== 0n;
            }
            /*UriInfo */ EnsureUriInfo()
            {
                /*Flags*/ let cF = this._flags;
                if ((cF & 70368744177664n) === 0n)
                {
                    this.CreateUriInfo(cF);
                    this.AssertInvariants();
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this._info !== null && (this._flags & 70368744177664n) !== 0n, "_info != null && (_flags & Flags.MinimalUriInfoSet) != 0");
                return this._info;
            }
            /*void */ EnsureParseRemaining()
            {
                if ((this._flags & 140737488355328n) === 0n)
                {
                    this.ParseRemaining();
                    this.AssertInvariants();
                }
            }
            /*void */ EnsureHostString(/*bool*/ allowDnsOptimization)
            {
                /*UriInfo*/ let info = this.EnsureUriInfo();
                if (info.Host === null)
                {
                    if (allowDnsOptimization && this.InFact(2199023255552n))
                    {
                        return;
                    }
                    this.CreateHostString();
                }
            }
            $ctor$5(/*string*/ uriString)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(uriString, "uriString");
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(uriString, false, 1/*UriKind.Absolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            $ctor$2(/*string*/ uriString, /*bool*/ dontEscape)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(uriString, "uriString");
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(uriString, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            $ctor$6(/*Uri*/ baseUri, /*string?*/ relativeUri, /*bool*/ dontEscape)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseUri, "baseUri");
                    if (!baseUri.IsAbsoluteUri)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("baseUri");
                    }
                    this.CreateUri(baseUri, relativeUri, dontEscape);
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            $ctor$3(/*string*/ uriString, /*UriKind*/ uriKind)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(uriString, "uriString");
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(uriString, false, uriKind, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            $ctor$4(/*string*/ uriString, /*in UriCreationOptions*/ creationOptions)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(uriString, "uriString");
                    this.CreateThis(uriString, false, 1/*UriKind.Absolute*/, creationOptions);
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            $ctor$7(/*Uri*/ baseUri, /*string?*/ relativeUri)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseUri, "baseUri");
                    if (!baseUri.IsAbsoluteUri)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("baseUri");
                    }
                    this.CreateUri(baseUri, relativeUri, false);
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            $ctor$1(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.$ctor();
                {
                    /*string?*/ let uriString = serializationInfo.GetString("AbsoluteUri");
                    if (uriString.length !== 0)
                    {
                        let $v1 = new $.$spu.System.UriCreationOptions();
                        this.CreateThis(uriString, false, 1/*UriKind.Absolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                        this.DebugSetLeftCtor();
                        return this;
                    }
                    uriString = serializationInfo.GetString("RelativeUri");
                    if (uriString === null)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$spu.System.SR.Format$6($.$spu.System.SR.InvalidNullArgument, "RelativeUri"), "serializationInfo");
                    }
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(uriString, false, 2/*UriKind.Relative*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                this.GetObjectData(serializationInfo, streamingContext);
            }
            /*void */ GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                if (this.IsAbsoluteUri)
                {
                    serializationInfo.AddValue$10("AbsoluteUri", this.GetParts(-2147483648/*UriComponents.SerializationInfoString*/, 1/*UriFormat.UriEscaped*/));
                }
                else 
                {
                    serializationInfo.AddValue$10("AbsoluteUri", $.$$.System.String.Empty);
                    serializationInfo.AddValue$10("RelativeUri", this.GetParts(-2147483648/*UriComponents.SerializationInfoString*/, 1/*UriFormat.UriEscaped*/));
                }
            }
            /*void */ CreateUri(/*Uri*/ baseUri, /*string?*/ relativeUri, /*bool*/ dontEscape)
            {
                this.DebugAssertInCtor();
                let $v1 = new $.$spu.System.UriCreationOptions();
                this.CreateThis(relativeUri, dontEscape, 0/*UriKind.RelativeOrAbsolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                if (baseUri.Syntax.IsSimple)
                {
                    /*Uri?*/ let uriResult = $.$spu.System.Uri.ResolveHelper(baseUri, this, $.$ref(() => relativeUri, ($v) => relativeUri = $v, $.$$.System.String), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => dontEscape, ($v) => dontEscape = $v, null));
                    if ($.$spu.System.Uri.op_Inequality(uriResult, null))
                    {
                        if (!$.$$.System.Object.ReferenceEquals(this, uriResult))
                        {
                            this.CreateThisFromUri(uriResult);
                        }
                        return;
                    }
                }
                else 
                {
                    dontEscape = false;
                    /*UriFormatException?*/ let e;
                    relativeUri = baseUri.Syntax.InternalResolve(baseUri, this, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException));
                    if (e !== null)
                    {
                        throw e;
                    }
                }
                this._flags = 0n;
                this._info = null;
                this._syntax = null;
                this._originalUnicodeString = null;
                let $v2 = new $.$spu.System.UriCreationOptions();
                this.CreateThis(relativeUri, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => $v2, ($v) => $v2 = $v));
            }
            $ctor$8(/*Uri*/ baseUri, /*Uri*/ relativeUri)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseUri, "baseUri");
                    if (!baseUri.IsAbsoluteUri)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("baseUri");
                    }
                    this.CreateThisFromUri(relativeUri);
                    /*string?*/ let newUriString = null;
                    /*bool*/ let dontEscape;
                    if (baseUri.Syntax.IsSimple)
                    {
                        dontEscape = this.InFact(34359738368n);
                        /*Uri?*/ let resolvedRelativeUri = $.$spu.System.Uri.ResolveHelper(baseUri, this, $.$ref(() => newUriString, ($v) => newUriString = $v, $.$$.System.String), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => dontEscape, ($v) => dontEscape = $v, null));
                        if ($.$spu.System.Uri.op_Inequality(resolvedRelativeUri, null))
                        {
                            if (!$.$$.System.Object.ReferenceEquals(this, resolvedRelativeUri))
                            {
                                this.CreateThisFromUri(resolvedRelativeUri);
                            }
                            this.DebugSetLeftCtor();
                            return this;
                        }
                    }
                    else 
                    {
                        dontEscape = false;
                        /*UriFormatException?*/ let e;
                        newUriString = baseUri.Syntax.InternalResolve(baseUri, this, $.$ref(() => e, ($v) => e = $v, $.$spu.System.UriFormatException));
                        if (e !== null)
                        {
                            throw e;
                        }
                    }
                    this._flags = 0n;
                    this._info = null;
                    this._syntax = null;
                    this._originalUnicodeString = null;
                    let $v1 = new $.$spu.System.UriCreationOptions();
                    this.CreateThis(newUriString, dontEscape, 1/*UriKind.Absolute*/, $.$ref(() => $v1, ($v) => $v1 = $v));
                    this.DebugSetLeftCtor();
                }
                return this;
            }
            static /*void */ GetCombinedString(/*Uri*/ baseUri, /*string*/ relativeStr, /*bool*/ dontEscape, /*ref string?*/ result)
            {
                for(/*int*/ let i = 0; i < relativeStr.length; ++i)
                {
                    if ($.$$.System.String.get_Chars.call(relativeStr, i) === /*/*/ 47 || $.$$.System.String.get_Chars.call(relativeStr, i) === /*\\*/ 92 || $.$$.System.String.get_Chars.call(relativeStr, i) === /*?*/ 63 || $.$$.System.String.get_Chars.call(relativeStr, i) === /*#*/ 35)
                    {
                        break;
                    }
                    else if ($.$$.System.String.get_Chars.call(relativeStr, i) === /*:*/ 58)
                    {
                        if (i < 2)
                        {
                            break;
                        }
                        /*ParsingError*/ let error = 0/*ParsingError.None*/;
                        /*UriParser?*/ let syntax = $.$spu.System.Uri.CheckSchemeSyntax($.$$.System.MemoryExtensions.AsSpan$1(relativeStr, 0, i), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.ParsingError, () => error, ($v) => error = $v, null));
                        if (error === 0/*ParsingError.None*/)
                        {
                            if (baseUri.Syntax === syntax)
                            {
                                if (((i + 1) | 0) < relativeStr.length)
                                {
                                    relativeStr = $.$$.System.String.Substring$1.call(relativeStr, ((i + 1) | 0));
                                }
                                else 
                                {
                                    relativeStr = $.$$.System.String.Empty;
                                }
                            }
                            else 
                            {
                                result.$v = relativeStr;
                                return;
                            }
                        }
                        break;
                    }
                }
                if (relativeStr.length === 0)
                {
                    result.$v = baseUri.OriginalString;
                }
                else 
                {
                    result.$v = $.$spu.System.Uri.CombineUri(baseUri, relativeStr, dontEscape ? 1/*UriFormat.UriEscaped*/ : 3/*UriFormat.SafeUnescaped*/);
                }
            }
            static /*UriFormatException? */ GetException(/*ParsingError*/ err)
            {
                switch(err)
                {
                    case 0/*ParsingError.None*/:
                    return null;
                    case 1/*ParsingError.BadFormat*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadFormat);
                    case 2/*ParsingError.BadScheme*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadScheme);
                    case 3/*ParsingError.BadAuthority*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadAuthority);
                    case 4/*ParsingError.EmptyUriString*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_EmptyUri);
                    case 6/*ParsingError.SchemeLimit*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_SchemeLimit);
                    case 7/*ParsingError.MustRootedPath*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_MustRootedPath);
                    case 8/*ParsingError.BadHostName*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadHostName);
                    case 9/*ParsingError.NonEmptyHost*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadFormat);
                    case 10/*ParsingError.BadPort*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadPort);
                    case 11/*ParsingError.BadAuthorityTerminator*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadAuthorityTerminator);
                    case 12/*ParsingError.CannotCreateRelative*/:
                    return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_CannotCreateRelative);
                    default:
                    break;
                }
                return new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.net_uri_BadFormat);
            }
            /*string */ get AbsolutePath()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*string*/ let path = this.PrivateAbsolutePath;
                if (this.IsDosPath && $.$$.System.String.get_Chars.call(path, 0) === /*/*/ 47)
                {
                    path = $.$$.System.String.Substring$1.call(path, 1);
                }
                return path;
            }
            /*string */ get PrivateAbsolutePath()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.IsAbsoluteUri, "IsAbsoluteUri");
                /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                return info.Path ??= this.GetParts(16/*UriComponents.Path*/ | 1073741824/*UriComponents.KeepDelimiter*/, 1/*UriFormat.UriEscaped*/);
            }
            /*string */ get AbsoluteUri()
            {
                if (this._syntax === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                return info.AbsoluteUri ??= this.GetParts(127/*UriComponents.AbsoluteUri*/, 1/*UriFormat.UriEscaped*/);
            }
            /*string */ get LocalPath()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.GetLocalPath();
            }
            /*string */ get Authority()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.GetParts(4/*UriComponents.Host*/ | 8/*UriComponents.Port*/, 1/*UriFormat.UriEscaped*/);
            }
            /*UriHostNameType */ get HostNameType()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (this._syntax.IsSimple)
                {
                    this.EnsureUriInfo();
                }
                else 
                {
                    this.EnsureHostString(false);
                }
                switch(this.HostType)
                {
                    case 12884901888n:
                    return 2/*UriHostNameType.Dns*/;
                    case 8589934592n:
                    return 3/*UriHostNameType.IPv4*/;
                    case 4294967296n:
                    return 4/*UriHostNameType.IPv6*/;
                    case 21474836480n:
                    return 1/*UriHostNameType.Basic*/;
                    case 17179869184n:
                    return 1/*UriHostNameType.Basic*/;
                    case 30064771072n:
                    return 0/*UriHostNameType.Unknown*/;
                    default:
                    break;
                }
                return 0/*UriHostNameType.Unknown*/;
            }
            /*bool */ get IsDefaultPort()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (this._syntax.IsSimple)
                {
                    this.EnsureUriInfo();
                }
                else 
                {
                    this.EnsureHostString(false);
                }
                return this.NotAny(549755813888n);
            }
            /*bool */ get IsFile()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this._syntax.SchemeName === $.$spu.System.Uri.UriSchemeFile;
            }
            /*bool */ get IsLoopback()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                this.EnsureHostString(false);
                return this.InFact(274877906944n);
            }
            /*string */ get PathAndQuery()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*UriInfo*/ let info = this.EnsureUriInfo();
                if (info.PathAndQuery === null)
                {
                    /*string*/ let result = this.GetParts(48/*UriComponents.PathAndQuery*/, 1/*UriFormat.UriEscaped*/);
                    if (this.IsDosPath && $.$$.System.String.get_Chars.call(result, 0) === /*/*/ 47)
                    {
                        result = $.$$.System.String.Substring$1.call(result, 1);
                    }
                    info.PathAndQuery = result;
                }
                return info.PathAndQuery;
            }
            /*string[] */ get Segments()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*string[]*/ let segments;
                /*string*/ let path = this.PrivateAbsolutePath;
                if (path.length === 0)
                {
                    segments = $.$$.System.Array.Empty($.$$.System.String);
                }
                else 
                {
                    /*var*/ let pathSegments = new ($.$spu.System.Collections.Generic.ValueListBuilder$$($.$$.System.String))().$ctor$3(4);
                    /*int*/ let current = 0;
                    while(current < path.length)
                    {
                        /*int*/ let next = $.$$.System.String.IndexOf$1.call(path, /*/*/ 47, current);
                        if (next === -1)
                        {
                            next = ((path.length - 1) | 0);
                        }
                        pathSegments.Append$1($.$$.System.String.Substring.call(path, current, (((((next - current) | 0)) + 1) | 0)));
                        current = ((next + 1) | 0);
                    }
                    segments = pathSegments.AsSpan().ToArray();
                    pathSegments.Dispose();
                }
                return segments;
            }
            /*bool */ get IsUnc()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.IsUncPath;
            }
            /*string */ get Host()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.GetParts(4/*UriComponents.Host*/, 1/*UriFormat.UriEscaped*/);
            }
            static /*bool */ StaticIsFile(/*UriParser*/ syntax)
            {
                return syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/);
            }
            /*string */ GetLocalPath()
            {
                this.EnsureParseRemaining();
                if (this.IsUncOrDosPath)
                {
                    this.EnsureHostString(false);
                    $.$$.System.Diagnostics.Debug.Assert$2(this._info !== null, "_info != null");
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Inequality(this._info.Host, null), "_info.Host != null");
                    /*int*/ let start;
                    if (this.NotAny(4n | 16n | 8192n))
                    {
                        start = this.IsUncPath ? ((this._info.Offset.Host - 2) | 0) : this._info.Offset.Path;
                        /*string*/ let str = (this.IsImplicitFile && this._info.Offset.Host === (this.IsDosPath ? 0 : 2) && this._info.Offset.Query === this._info.Offset.End) ? this._string : (this.IsDosPath && ($.$$.System.String.get_Chars.call(this._string, start) === /*/*/ 47 || $.$$.System.String.get_Chars.call(this._string, start) === /*\\*/ 92)) ? $.$$.System.String.Substring.call(this._string, ((start + 1) | 0), ((((this._info.Offset.Query - start) | 0) - 1) | 0)) : $.$$.System.String.Substring.call(this._string, start, ((this._info.Offset.Query - start) | 0));
                        if (this.IsDosPath && $.$$.System.String.get_Chars.call(str, 1) === /*|*/ 124)
                        {
                            str = $.$$.System.String.Remove.call(str, 1, 1);
                            str = $.$$.System.String.Insert.call(str, 1, ":");
                        }
                        str = $.$$.System.String.Replace.call(str, /*/*/ 47, /*\\*/ 92);
                        return str;
                    }
                    /*char[]*/ let result;
                    /*int*/ let count = 0;
                    start = this._info.Offset.Path;
                    /*string*/ let host = this._info.Host;
                    result = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [((((((host.length + 3) | 0) + this._info.Offset.Fragment) | 0) - this._info.Offset.Path) | 0)], null);
                    if (this.IsUncPath)
                    {
                        $.$$.System.Array.$WriteT1.call(result, /*\\*/ 92, 0);
                        $.$$.System.Array.$WriteT1.call(result, /*\\*/ 92, 1);
                        count = 2;
                        $.$spu.System.UriHelper.UnescapeString$3(host, 0, host.length, result, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 0/*UnescapeMode.CopyOnly*/, this._syntax, false);
                    }
                    else 
                    {
                        if ($.$$.System.String.get_Chars.call(this._string, start) === /*/*/ 47 || $.$$.System.String.get_Chars.call(this._string, start) === /*\\*/ 92)
                        {
                            ++start;
                        }
                    }
                    /*int*/ let pathStart = count;
                    /*UnescapeMode*/ let mode = (this.InFact(16n) && !this.IsImplicitFile) ? (2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/) : 0/*UnescapeMode.CopyOnly*/;
                    $.$spu.System.UriHelper.UnescapeString$3(this._string, start, this._info.Offset.Query, result, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, mode, this._syntax, true);
                    if ($.$$.System.Array.$ReadT1.call(result, 1) === /*|*/ 124)
                    {
                        $.$$.System.Array.$WriteT1.call(result, /*:*/ 58, 1);
                    }
                    if (this.InFact(8192n))
                    {
                        $.$spu.System.Uri.Compress(result, this.IsDosPath ? ((pathStart + 2) | 0) : pathStart, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32), this._syntax);
                    }
                    /*Span<char>*/ let slashSpan = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, result, 0, count);
                    $.$$.System.MemoryExtensions.Replace$3($.$$.System.Char, slashSpan, /*/*/ 47, /*\\*/ 92);
                    return $.$$.System.String.Create$1(result, 0, count);
                }
                else 
                {
                    return this.GetUnescapedParts(16/*UriComponents.Path*/ | 1073741824/*UriComponents.KeepDelimiter*/, 2/*UriFormat.Unescaped*/);
                }
            }
            /*int */ get Port()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (this._syntax.IsSimple)
                {
                    this.EnsureUriInfo();
                }
                else 
                {
                    this.EnsureHostString(false);
                }
                if (this.InFact(549755813888n))
                {
                    return $.$cast(this._info.Offset.PortValue, $.$$.System.Int32);
                }
                return this._syntax.DefaultPort;
            }
            /*string */ get Query()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                return info.Query ??= this.GetParts(32/*UriComponents.Query*/ | 1073741824/*UriComponents.KeepDelimiter*/, 1/*UriFormat.UriEscaped*/);
            }
            /*string */ get Fragment()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                return info.Fragment ??= this.GetParts(64/*UriComponents.Fragment*/ | 1073741824/*UriComponents.KeepDelimiter*/, 1/*UriFormat.UriEscaped*/);
            }
            /*string */ get Scheme()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this._syntax.SchemeName;
            }
            /*string */ get OriginalString()
            {
                return this._originalUnicodeString ?? this._string;
            }
            /*string */ get DnsSafeHost()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                this.EnsureHostString(false);
                /*Flags*/ let hostType = this.HostType;
                if (hostType === 4294967296n || (hostType === 21474836480n && this.InFact(4n | 256n)))
                {
                    return this.IdnHost;
                }
                else 
                {
                    return this._info.Host;
                }
            }
            /*string */ get IdnHost()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if ((this._info?.IdnHost ?? null) === null)
                {
                    this.EnsureHostString(false);
                    /*string*/ let host = this._info.Host;
                    /*Flags*/ let hostType = this.HostType;
                    if (hostType === 12884901888n)
                    {
                        host = $.$spu.System.DomainNameHelper.IdnEquivalent(host);
                    }
                    else if (hostType === 4294967296n)
                    {
                        let scopeId;
                        host = $.$is((this._info._moreInfo?.ScopeId ?? null), $.$$.System.String, { set $v(v){ scopeId = v; } }) ? $.$$.System.String.Concat$8($.$$.System.MemoryExtensions.AsSpan$1(host, 1, ((host.length - 2) | 0)), $.$$.System.String.op_Implicit(scopeId)) : $.$$.System.String.Substring.call(host, 1, ((host.length - 2) | 0));
                    }
                    else if (hostType === 21474836480n && this.InFact(4n | 256n))
                    {
                        /*var*/ let dest = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                        $.$spu.System.UriHelper.UnescapeString$4(host, 0, host.length, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, this._syntax, false);
                        host = $.$spu.System.Text.ValueStringBuilder.ToString.call(dest);
                    }
                    this._info.IdnHost = host;
                }
                return this._info.IdnHost;
            }
            /*bool */ get IsAbsoluteUri()
            {
                return this._syntax !== null;
            }
            /*bool */ get UserEscaped()
            {
                return this.InFact(34359738368n);
            }
            /*string */ get UserInfo()
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                return this.GetParts(2/*UriComponents.UserInfo*/, 1/*UriFormat.UriEscaped*/);
            }
            static /*UriHostNameType */ CheckHostName(/*string?*/ name)
            {
                if ($.$$.System.String.IsNullOrEmpty(name))
                {
                    return 0/*UriHostNameType.Unknown*/;
                }
                /*int*/ let end = name.length;
                {
                    /*fixed*/ 
                    {
                        /*char**/ let fixedName = $.$$.System.String.GetPinnableReference.call(name);
                        if ($.$$.System.String.StartsWith.call(name, /*[*/ 91) && $.$$.System.String.EndsWith.call(name, /*]*/ 93))
                        {
                            if ($.$spu.System.Net.IPv6AddressHelper.IsValid(fixedName, 1, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32)) && end === name.length)
                            {
                                return 4/*UriHostNameType.IPv6*/;
                            }
                        }
                        end = name.length;
                        if ($.$spu.System.Net.IPv4AddressHelper.IsValid($.$$.System.Char, fixedName, 0, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32), false, false, false) && end === name.length)
                        {
                            return 3/*UriHostNameType.IPv4*/;
                        }
                    }
                    /*int*/ let length;
                    if ($.$spu.System.DomainNameHelper.IsValid($.$$.System.String.op_Implicit(name), false, false, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)) && length === name.length)
                    {
                        return 2/*UriHostNameType.Dns*/;
                    }
                    if ($.$spu.System.DomainNameHelper.IsValid($.$$.System.String.op_Implicit(name), true, false, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)) && length === name.length)
                    {
                        return 2/*UriHostNameType.Dns*/;
                    }
                    end = ((name.length + 2) | 0);
                    name = "[" + name + "]";
                    /*fixed*/ 
                    {
                        /*char**/ let newFixedName = $.$$.System.String.GetPinnableReference.call(name);
                        if ($.$spu.System.Net.IPv6AddressHelper.IsValid(newFixedName, 1, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32)) && end === name.length)
                        {
                            return 4/*UriHostNameType.IPv6*/;
                        }
                    }
                }
                return 0/*UriHostNameType.Unknown*/;
            }
            /*string */ GetLeftPart(/*UriPartial*/ part)
            {
                if (this.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                this.EnsureUriInfo();
                /*UriComponents*/ let NonPathPart = (1/*UriComponents.Scheme*/ | 2/*UriComponents.UserInfo*/ | 4/*UriComponents.Host*/ | 8/*UriComponents.Port*/);
                switch(part)
                {
                    case 0/*UriPartial.Scheme*/:
                    return this.GetParts(1/*UriComponents.Scheme*/ | 1073741824/*UriComponents.KeepDelimiter*/, 1/*UriFormat.UriEscaped*/);
                    case 1/*UriPartial.Authority*/:
                    if (this.NotAny(68719476736n) || this.IsDosPath)
                    {
                        return $.$$.System.String.Empty;
                    }
                    return this.GetParts(NonPathPart, 1/*UriFormat.UriEscaped*/);
                    case 2/*UriPartial.Path*/:
                    return this.GetParts(NonPathPart | 16/*UriComponents.Path*/, 1/*UriFormat.UriEscaped*/);
                    case 3/*UriPartial.Query*/:
                    return this.GetParts(NonPathPart | 16/*UriComponents.Path*/ | 32/*UriComponents.Query*/, 1/*UriFormat.UriEscaped*/);
                }
                throw new $.$$.System.ArgumentException().$ctor$13($.$spu.System.SR.Format$6($.$spu.System.SR.Argument_InvalidUriSubcomponent, $.$box(part, $.$spu.System.UriPartial)), "part");
            }
            static /*string */ HexEscape(/*char*/ character)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Char, character, /*\u00FF*/ 255, "character");
                return $.$$.System.String.Create$10($.$$.System.Byte, 3, $.$cast(character, $.$$.System.Byte), new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.Byte))().$ctor(this,  (/*Span<char>*/ chars, /*byte*/ b) =>
                {
                    chars.get_Item(0).$v = /*%*/ 37;
                    $.$spu.System.HexConverter.ToCharsBuffer(b, chars, 1, 0/*HexConverter.Casing.Upper*/);
                }, {"r":65537,"p":[{"n":"chars","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"b","p":393217}],"n":"","d":1746220,"h":0,"f":17825794}));
            }
            static /*char */ HexUnescape(/*string*/ pattern, /*ref int*/ index)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index.$v, "index");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual($.$$.System.Int32, index.$v, pattern.length, "index");
                if (($.$$.System.String.get_Chars.call(pattern, index.$v) === /*%*/ 37) && (((pattern.length - index.$v) | 0) >= 3))
                {
                    /*char*/ let ret = $.$spu.System.UriHelper.DecodeHexChars($.$$.System.String.get_Chars.call(pattern, ((index.$v + 1) | 0)), $.$$.System.String.get_Chars.call(pattern, ((index.$v + 2) | 0)));
                    if (ret !== /*\uFFFF*/ 65535)
                    {
                        index.$v += 3;
                        return ret;
                    }
                }
                return $.$$.System.String.get_Chars.call(pattern, index.$v++);
            }
            static /*bool */ IsHexEncoding(/*string*/ pattern, /*int*/ index)
            {
                return (((pattern.length - index) | 0)) >= 3 && $.$$.System.String.get_Chars.call(pattern, index) === /*%*/ 37 && $.$$.System.Char.IsAsciiHexDigit($.$$.System.String.get_Chars.call(pattern, ((index + 1) | 0))) && $.$$.System.Char.IsAsciiHexDigit($.$$.System.String.get_Chars.call(pattern, ((index + 2) | 0)));
            }
            /*SearchValues<char>*/ static s_schemeChars = null;
            static /*bool */ CheckSchemeName(/*string?*/ schemeName)
            {
                return !$.$$.System.String.IsNullOrEmpty(schemeName) && $.$$.System.Char.IsAsciiLetter($.$$.System.String.get_Chars.call(schemeName, 0)) && !$.$$.System.MemoryExtensions.ContainsAnyExcept($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(schemeName), $.$spu.System.Uri.s_schemeChars);
            }
            static /*bool */ IsHexDigit(/*char*/ character)
            {
                return $.$$.System.Char.IsAsciiHexDigit(character);
            }
            static /*int */ FromHex(/*char*/ digit)
            {
                /*int*/ let result = $.$spu.System.HexConverter.FromChar(digit);
                if (result === 255)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13(null, "digit");
                }
                return result;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                if (this.IsNotAbsoluteUri)
                {
                    return $.$$.System.String.GetHashCode.call(this.OriginalString);
                }
                else 
                {
                    /*MoreInfo*/ let info = this.EnsureUriInfo().MoreInfo;
                    /*UriComponents*/ let components = 61/*UriComponents.HttpRequestUrl*/;
                    if (this._syntax.InFact(16384/*UriSyntaxFlags.MailToLikeUri*/))
                    {
                        components |= 2/*UriComponents.UserInfo*/;
                    }
                    /*string*/ let remoteUrl = info.RemoteUrl ??= this.GetParts(components, 3/*UriFormat.SafeUnescaped*/);
                    if (this.IsUncOrDosPath)
                    {
                        return $.$$.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(remoteUrl);
                    }
                    else 
                    {
                        return $.$$.System.String.GetHashCode.call(remoteUrl);
                    }
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$spu.System.Uri.GetHashCode.apply(this, arguments); }
            /*UriFormat*/ static V1ToStringUnescape = 32767;
            static/*conventional*/ /*string */ ToString()
            {
                if (this._syntax === null)
                {
                    return this._string;
                }
                this.EnsureUriInfo();
                return this._info.String ??= this._syntax.IsSimple ? this.GetComponentsHelper(127/*UriComponents.AbsoluteUri*/, 32767/*V1ToStringUnescape*/) : this.GetParts(127/*UriComponents.AbsoluteUri*/, 3/*UriFormat.SafeUnescaped*/);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spu.System.Uri.ToString.apply(this, arguments); }
            /*bool */ TryFormat(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                /*ReadOnlySpan<char>*/ let result;
                if (this._syntax === null)
                {
                    result = $.$$.System.String.op_Implicit(this._string);
                }
                else 
                {
                    this.EnsureUriInfo();
                    if (!(this._info.String === null))
                    {
                        result = $.$$.System.String.op_Implicit(this._info.String);
                    }
                    else 
                    {
                        /*UriFormat*/ let uriFormat = 32767/*V1ToStringUnescape*/;
                        if (!this._syntax.IsSimple)
                        {
                            if (this.IsNotAbsoluteUri)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                            }
                            if (this.UserDrivenParsing)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.Format$6($.$spu.System.SR.net_uri_UserDrivenParsing, $.$$.System.Object.GetType.call(this)));
                            }
                            if (this.DisablePathAndQueryCanonicalization)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_GetComponentsCalledWhenCanonicalizationDisabled);
                            }
                            uriFormat = 3/*UriFormat.SafeUnescaped*/;
                        }
                        this.EnsureParseRemaining();
                        this.EnsureHostString(true);
                        /*ushort*/ let nonCanonical = $.$cast(($.$cast(this._flags, $.$$.System.UInt16) & $.$cast(127n, $.$$.System.UInt16)), $.$$.System.UInt16);
                        if (((this._flags & (8192n | 16384n | 32768n)) !== 0n) || (this.IsDosPath && $.$$.System.String.get_Chars.call(this._string, ((((this._info.Offset.Path + this.SecuredPathIndex) | 0) - 1) | 0)) === /*|*/ 124))
                        {
                            nonCanonical |= $.$cast(16n, $.$$.System.UInt16);
                        }
                        if (($.$cast(127/*UriComponents.AbsoluteUri*/, $.$$.System.UInt16) & nonCanonical) !== 0)
                        {
                            return this.TryRecreateParts(destination, charsWritten, 127/*UriComponents.AbsoluteUri*/, nonCanonical, uriFormat);
                        }
                        result = $.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Scheme, ((this._info.Offset.End - this._info.Offset.Scheme) | 0));
                    }
                }
                if (result.TryCopyTo(destination))
                {
                    charsWritten.$v = result.Length;
                    return true;
                }
                charsWritten.$v = 0;
                return false;
            }
            /*bool */ System$ISpanFormattable$TryFormat(/*Span<char>*/ destination, /*out int*/ charsWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                return this.TryFormat(destination, charsWritten);
            }
            /*string */ System$IFormattable$ToString(/*string?*/ format, /*IFormatProvider?*/ formatProvider)
            {
                return $.$spu.System.Uri.ToString.call(this);
            }
            static /*bool */ op_Equality(/*Uri?*/ uri1, /*Uri?*/ uri2)
            {
                if ($.$$.System.Object.ReferenceEquals(uri1, uri2))
                {
                    return true;
                }
                if (uri1 === null || uri2 === null)
                {
                    return false;
                }
                return uri1.Equals$2(uri2);
            }
            static /*bool */ op_Inequality(/*Uri?*/ uri1, /*Uri?*/ uri2)
            {
                if ($.$$.System.Object.ReferenceEquals(uri1, uri2))
                {
                    return false;
                }
                if (uri1 === null || uri2 === null)
                {
                    return true;
                }
                return !uri1.Equals$2(uri2);
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ comparand)
            {
                if (comparand === null)
                {
                    return false;
                }
                if ($.$$.System.Object.ReferenceEquals(this, comparand))
                {
                    return true;
                }
                /*Uri?*/ let other = $.$as(comparand, $.$spu.System.Uri);
                if (other === null)
                {
                    if (this.DisablePathAndQueryCanonicalization)
                    {
                        return false;
                    }
                    let s;
                    if (!($.$is(comparand, $.$$.System.String, { set $v(v){ s = v; } })))
                    {
                        return false;
                    }
                    if ($.$$.System.Object.ReferenceEquals(s, this.OriginalString))
                    {
                        return true;
                    }
                    if (!$.$spu.System.Uri.TryCreate(s, 0/*UriKind.RelativeOrAbsolute*/, $.$ref(() => other, ($v) => other = $v, $.$spu.System.Uri)))
                    {
                        return false;
                    }
                }
                return this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$spu.System.Uri.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*Uri?*/ other)
            {
                if (other === null)
                {
                    return false;
                }
                if ($.$$.System.Object.ReferenceEquals(this, other))
                {
                    return true;
                }
                if (this.DisablePathAndQueryCanonicalization !== other.DisablePathAndQueryCanonicalization)
                {
                    return false;
                }
                if ($.$$.System.Object.ReferenceEquals(this.OriginalString, other.OriginalString))
                {
                    return true;
                }
                if (this.IsAbsoluteUri !== other.IsAbsoluteUri)
                {
                    return false;
                }
                if (this.IsNotAbsoluteUri)
                {
                    return $.$$.System.String.Equals$5.call(this.OriginalString, other.OriginalString);
                }
                if (this.NotAny(140737488355328n) || other.NotAny(140737488355328n))
                {
                    if ($.$$.System.String.Equals$2(this._string, other._string, this.IsUncOrDosPath ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                    {
                        return true;
                    }
                }
                this.EnsureUriInfo();
                other.EnsureUriInfo();
                if (!this.UserDrivenParsing && !other.UserDrivenParsing && this.Syntax.IsSimple && other.Syntax.IsSimple)
                {
                    if (this.InFact(2199023255552n) && other.InFact(2199023255552n))
                    {
                        /*int*/ let i1 = this._info.Offset.Host;
                        /*int*/ let end1 = this._info.Offset.Path;
                        /*int*/ let i2 = other._info.Offset.Host;
                        /*int*/ let end2 = other._info.Offset.Path;
                        /*string*/ let str = other._string;
                        if (((end1 - i1) | 0) > ((end2 - i2) | 0))
                        {
                            end1 = ((((i1 + end2) | 0) - i2) | 0);
                        }
                        while(i1 < end1)
                        {
                            if ($.$$.System.String.get_Chars.call(this._string, i1) !== $.$$.System.String.get_Chars.call(str, i2))
                            {
                                return false;
                            }
                            if ($.$$.System.String.get_Chars.call(str, i2) === /*:*/ 58)
                            {
                                break;
                            }
                            ++i1;
                            ++i2;
                        }
                        if (i1 < this._info.Offset.Path && $.$$.System.String.get_Chars.call(this._string, i1) !== /*:*/ 58)
                        {
                            return false;
                        }
                        if (i2 < end2 && $.$$.System.String.get_Chars.call(str, i2) !== /*:*/ 58)
                        {
                            return false;
                        }
                    }
                    else 
                    {
                        this.EnsureHostString(false);
                        other.EnsureHostString(false);
                        if (!$.$$.System.String.Equals$5.call(this._info.Host, other._info.Host))
                        {
                            return false;
                        }
                    }
                    if (this.Port !== other.Port)
                    {
                        return false;
                    }
                }
                /*MoreInfo*/ let selfInfo = this._info.MoreInfo;
                /*MoreInfo*/ let otherInfo = other._info.MoreInfo;
                /*UriComponents*/ let components = 61/*UriComponents.HttpRequestUrl*/;
                if (this._syntax.InFact(16384/*UriSyntaxFlags.MailToLikeUri*/))
                {
                    if (!other._syntax.InFact(16384/*UriSyntaxFlags.MailToLikeUri*/))
                    {
                        return false;
                    }
                    components |= 2/*UriComponents.UserInfo*/;
                }
                /*string*/ let selfUrl = selfInfo.RemoteUrl ??= this.GetParts(components, 3/*UriFormat.SafeUnescaped*/);
                /*string*/ let otherUrl = otherInfo.RemoteUrl ??= other.GetParts(components, 3/*UriFormat.SafeUnescaped*/);
                return $.$$.System.String.Equals$2(selfUrl, otherUrl, this.IsUncOrDosPath ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/);
            }
            /*Uri */ MakeRelativeUri(/*Uri*/ uri)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                if (this.IsNotAbsoluteUri || uri.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (($.$$.System.String.op_Equality(this.Scheme, uri.Scheme)) && ($.$$.System.String.op_Equality(this.Host, uri.Host)) && (this.Port === uri.Port))
                {
                    /*string*/ let otherPath = uri.AbsolutePath;
                    /*string*/ let relativeUriString = $.$spu.System.Uri.PathDifference(this.AbsolutePath, otherPath, !this.IsUncOrDosPath);
                    if ($.$spu.System.Uri.CheckForColonInFirstPathSegment(relativeUriString) && !(uri.IsDosPath && $.$$.System.String.Equals$4.call(otherPath, relativeUriString, 4/*StringComparison.Ordinal*/)))
                    {
                        relativeUriString = "./" + relativeUriString;
                    }
                    relativeUriString += uri.GetParts(32/*UriComponents.Query*/ | 64/*UriComponents.Fragment*/, 1/*UriFormat.UriEscaped*/);
                    return new $.$spu.System.Uri().$ctor$3(relativeUriString, 2/*UriKind.Relative*/);
                }
                return uri;
            }
            /*SearchValues<char>*/ static s_segmentSeparatorChars = null;
            static /*bool */ CheckForColonInFirstPathSegment(/*string*/ uriString)
            {
                /*int*/ let index = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(uriString), $.$spu.System.Uri.s_segmentSeparatorChars);
                return (index >>> 0) < (uriString.length >>> 0) && $.$$.System.String.get_Chars.call(uriString, index) === /*:*/ 58;
            }
            static /*string */ InternalEscapeString(/*string*/ rawString)
            {
                return rawString === null ? $.$$.System.String.Empty : $.$spu.System.UriHelper.EscapeString$2(rawString, true, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
            }
            static /*ParsingError */ ParseScheme(/*string*/ uriString, /*ref Flags*/ flags, /*ref UriParser?*/ syntax)
            {
                $.$$.System.Diagnostics.Debug.Assert$2((flags.$v & 144115188075855872n) === 0n, "(flags & Flags.Debug_LeftConstructor) == 0");
                /*int*/ let length = uriString.length;
                if (length === 0)
                {
                    return 4/*ParsingError.EmptyUriString*/;
                }
                if ($.$$.System.String.StartsWith$2.call(uriString, "https:", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    syntax.$v = $.$spu.System.UriParser.HttpsUri;
                    flags.$v |= $.$cast(6n, $.$spu.System.Uri.Flags);
                }
                else if ($.$$.System.String.StartsWith$2.call(uriString, "http:", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    syntax.$v = $.$spu.System.UriParser.HttpUri;
                    flags.$v |= $.$cast(5n, $.$spu.System.Uri.Flags);
                }
                else 
                {
                    /*ParsingError*/ let err = 0/*ParsingError.None*/;
                    /*int*/ let idx = $.$spu.System.Uri.ParseSchemeCheckImplicitFile(uriString, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.ParsingError, () => err, ($v) => err = $v, null), flags, syntax);
                    $.$$.System.Diagnostics.Debug.Assert$2((err === 0) === (!(syntax.$v === null)), "(err is ParsingError.None) == (syntax is not null)");
                    if (err !== 0/*ParsingError.None*/)
                    {
                        return err;
                    }
                    flags.$v |= $.$cast(idx, $.$spu.System.Uri.Flags);
                }
                return 0/*ParsingError.None*/;
            }
            /*UriFormatException? */ ParseMinimal()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._syntax !== null && !this._syntax.IsSimple, "_syntax != null && !_syntax.IsSimple");
                $.$$.System.Diagnostics.Debug.Assert$2((this._flags & 72057594037927936n) !== 0n, "(_flags & Flags.CustomParser_ParseMinimalAlreadyCalled) != 0");
                this.DebugAssertInCtor();
                /*ParsingError*/ let result = this.PrivateParseMinimal();
                if (result === 0/*ParsingError.None*/)
                {
                    return null;
                }
                this._flags |= 4398046511104n;
                return $.$spu.System.Uri.GetException(result);
            }
            /*ParsingError */ PrivateParseMinimal()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._syntax !== null, "_syntax != null");
                this.DebugAssertInCtor();
                /*int*/ let idx = $.$cast((this._flags & 4294967295n), $.$$.System.Int32);
                /*int*/ let length = this._string.length;
                this._flags &= ~(4294967295n | 1099511627776n);
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Object.ReferenceEquals(this._string, this.OriginalString), "ReferenceEquals(_string, OriginalString)");
                /*fixed*/ 
                {
                    /*char**/ let pUriString = $.$$.System.String.GetPinnableReference.call(this._string);
                    if (length > idx && $.$spu.System.UriHelper.IsLWS(pUriString.GetAt(((length - 1) | 0))))
                    {
                        --length;
                        while(length !== idx && $.$spu.System.UriHelper.IsLWS(pUriString.GetAt(--length)))
                        {
                        }
                        ++length;
                    }
                    if (!$.$$.System.OperatingSystem.IsWindows() && this.InFact(18014398509481984n))
                    {
                        this._flags |= 21474836480n;
                        this._flags |= $.$cast(idx, $.$spu.System.Uri.Flags);
                        return 0/*ParsingError.None*/;
                    }
                    if (this._syntax.IsAllSet(128/*UriSyntaxFlags.AllowEmptyHost*/ | 1048576/*UriSyntaxFlags.AllowDOSPath*/) && this.NotAny(35184372088832n) && (((idx + 1) | 0) < length))
                    {
                        /*char*/ let c;
                        /*int*/ let i = idx;
                        for(; i < length; ++i)
                        {
                            if (!((c = pUriString.GetAt(i)) === /*\\*/ 92 || c === /*/*/ 47))
                            {
                                break;
                            }
                        }
                        if (this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/) || ((i - idx) | 0) <= 3)
                        {
                            if (((i - idx) | 0) >= 2)
                            {
                                this._flags |= 68719476736n;
                            }
                            if (((i + 1) | 0) < length && ((c = pUriString.GetAt(((i + 1) | 0))) === /*:*/ 58 || c === /*|*/ 124) && $.$$.System.Char.IsAsciiLetter(pUriString.GetAt(i)))
                            {
                                if (((i + 2) | 0) >= length || ((c = pUriString.GetAt(((i + 2) | 0))) !== /*\\*/ 92 && c !== /*/*/ 47))
                                {
                                    if (this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/))
                                    {
                                        return 7/*ParsingError.MustRootedPath*/;
                                    }
                                }
                                else 
                                {
                                    this._flags |= 8796093022208n;
                                    if (this._syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/))
                                    {
                                        this._flags |= 68719476736n;
                                    }
                                    if (i !== idx && ((i - idx) | 0) !== 2)
                                    {
                                        idx = ((i - 1) | 0);
                                    }
                                    else 
                                    {
                                        idx = i;
                                    }
                                }
                            }
                            else if (this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/) && (((i - idx) | 0) >= 2 && ((i - idx) | 0) !== 3 && i < length && pUriString.GetAt(i) !== /*?*/ 63 && pUriString.GetAt(i) !== /*#*/ 35))
                            {
                                this._flags |= 17592186044416n;
                                idx = i;
                            }
                            else if (!$.$$.System.OperatingSystem.IsWindows() && this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/) && pUriString.GetAt(((i - 1) | 0)) === /*/*/ 47 && ((i - idx) | 0) === 3)
                            {
                                this._syntax = $.$spu.System.UriParser.UnixFileUri;
                                this._flags |= 18014398509481984n | 68719476736n;
                                idx += 2;
                            }
                        }
                    }
                    if ((this._flags & (17592186044416n | 8796093022208n | 18014398509481984n)) !== 0n)
                    {
                    }
                    else if ((((idx + 2) | 0)) <= length)
                    {
                        /*char*/ let first = pUriString.GetAt(idx);
                        /*char*/ let second = pUriString.GetAt(((idx + 1) | 0));
                        if (this._syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/))
                        {
                            if ((first === /*/*/ 47 || first === /*\\*/ 92) && (second === /*/*/ 47 || second === /*\\*/ 92))
                            {
                                this._flags |= 68719476736n;
                                idx += 2;
                            }
                            else 
                            {
                                return 3/*ParsingError.BadAuthority*/;
                            }
                        }
                        else if (this._syntax.InFact(2/*UriSyntaxFlags.OptionalAuthority*/) && (this.InFact(68719476736n) || (first === /*/*/ 47 && second === /*/*/ 47)))
                        {
                            this._flags |= 68719476736n;
                            idx += 2;
                        }
                        else if (this._syntax.NotAny(16384/*UriSyntaxFlags.MailToLikeUri*/))
                        {
                            if (this.InFact(562949953421312n))
                            {
                                this._string = $.$$.System.String.Substring.call(this._string, 0, idx);
                            }
                            this._flags |= ($.$cast(idx, $.$spu.System.Uri.Flags) | 30064771072n);
                            return 0/*ParsingError.None*/;
                        }
                    }
                    else if (this._syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/))
                    {
                        return 3/*ParsingError.BadAuthority*/;
                    }
                    else if (this._syntax.NotAny(16384/*UriSyntaxFlags.MailToLikeUri*/))
                    {
                        if (this.InFact(562949953421312n))
                        {
                            this._string = $.$$.System.String.Substring.call(this._string, 0, idx);
                        }
                        this._flags |= ($.$cast(idx, $.$spu.System.Uri.Flags) | 30064771072n);
                        return 0/*ParsingError.None*/;
                    }
                    if (this.InFact(8796093022208n))
                    {
                        this._flags |= (((this._flags & 68719476736n) !== 0n) ? 21474836480n : 30064771072n);
                        this._flags |= $.$cast(idx, $.$spu.System.Uri.Flags);
                        return 0/*ParsingError.None*/;
                    }
                    {
                        /*ParsingError*/ let err = 0/*ParsingError.None*/;
                        /*string?*/ let newHost = null;
                        idx = this.CheckAuthorityHelper(pUriString, idx, length, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.ParsingError, () => err, ($v) => err = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => this._flags, ($v) => this._flags = $v, null), this._syntax, $.$ref(() => newHost, ($v) => newHost = $v, $.$$.System.String));
                        if (err !== 0/*ParsingError.None*/)
                        {
                            return err;
                        }
                        if (idx < length)
                        {
                            /*char*/ let hostTerminator = pUriString.GetAt(idx);
                            if (hostTerminator === /*\\*/ 92 && this.NotAny(35184372088832n) && this._syntax.NotAny(1048576/*UriSyntaxFlags.AllowDOSPath*/))
                            {
                                return 11/*ParsingError.BadAuthorityTerminator*/;
                            }
                            else if (!$.$$.System.OperatingSystem.IsWindows() && hostTerminator === /*/*/ 47 && this.NotAny(35184372088832n) && this.InFact(17592186044416n) && this._syntax === $.$spu.System.UriParser.FileUri)
                            {
                                this._syntax = $.$spu.System.UriParser.UnixFileUri;
                            }
                        }
                        if (!(newHost === null))
                        {
                            this._string = newHost;
                        }
                    }
                    this._flags |= $.$cast(idx, $.$spu.System.Uri.Flags);
                }
                return 0/*ParsingError.None*/;
            }
            /*void */ CreateUriInfo(/*Flags*/ cF)
            {
                /*UriInfo*/ let info;
                /*int*/ let idx;
                /*bool*/ let notCanonicalScheme;
                /*bool*/ let notEmpty;
                /*Flags*/ let current;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            info = new $.$spu.System.Uri.UriInfo().$ctor$1();
                            info.Offset.End = this._string.length;
                            if (this.UserDrivenParsing)
                            {
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            notCanonicalScheme = false;
                            if ((cF & 35184372088832n) !== 0n)
                            {
                                idx = 0;
                                while($.$spu.System.UriHelper.IsLWS($.$$.System.String.get_Chars.call(this._string, idx)))
                                {
                                    ++idx;
                                    ++info.Offset.Scheme;
                                }
                                if ($.$spu.System.Uri.StaticInFact(cF, 17592186044416n))
                                {
                                    idx += 2;
                                    /*int*/ let end = $.$cast((cF & 4294967295n), $.$$.System.Int32);
                                    while(idx < end && ($.$$.System.String.get_Chars.call(this._string, idx) === /*/*/ 47 || $.$$.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92))
                                    {
                                        ++idx;
                                    }
                                }
                            }
                            else 
                            {
                                idx = this._syntax.SchemeName.length;
                                while($.$$.System.String.get_Chars.call(this._string, idx++) !== /*:*/ 58)
                                {
                                    ++info.Offset.Scheme;
                                }
                                if ((cF & 68719476736n) !== 0n)
                                {
                                    if ($.$$.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92 || $.$$.System.String.get_Chars.call(this._string, ((idx + 1) | 0)) === /*\\*/ 92)
                                    {
                                        notCanonicalScheme = true;
                                    }
                                    idx += 2;
                                    if ((cF & (17592186044416n | 8796093022208n)) !== 0n)
                                    {
                                        /*int*/ let end = $.$cast((cF & 4294967295n), $.$$.System.Int32);
                                        while(idx < end && ($.$$.System.String.get_Chars.call(this._string, idx) === /*/*/ 47 || $.$$.System.String.get_Chars.call(this._string, idx) === /*\\*/ 92))
                                        {
                                            notCanonicalScheme = true;
                                            ++idx;
                                        }
                                    }
                                }
                            }
                            if (this._syntax.DefaultPort !== -1/*UriParser.NoDefaultPort*/)
                            {
                                info.Offset.PortValue = $.$cast(this._syntax.DefaultPort, $.$$.System.UInt16);
                            }
                            if ((cF & 30064771072n) === 30064771072n || $.$spu.System.Uri.StaticInFact(cF, 8796093022208n))
                            {
                                info.Offset.User = $.$cast((cF & 4294967295n), $.$$.System.Int32);
                                info.Offset.Host = info.Offset.User;
                                info.Offset.Path = info.Offset.User;
                                cF &= ~4294967295n;
                                if (notCanonicalScheme)
                                {
                                    cF |= 1n;
                                }
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            info.Offset.User = idx;
                            if (this.HostType === 21474836480n)
                            {
                                info.Offset.Host = idx;
                                info.Offset.Path = $.$cast((cF & 4294967295n), $.$$.System.Int32);
                                cF &= ~4294967295n;
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            if ((cF & 137438953472n) !== 0n)
                            {
                                while($.$$.System.String.get_Chars.call(this._string, idx) !== /*@*/ 64)
                                {
                                    ++idx;
                                }
                                ++idx;
                                info.Offset.Host = idx;
                            }
                            else 
                            {
                                info.Offset.Host = idx;
                            }
                            idx = $.$cast((cF & 4294967295n), $.$$.System.Int32);
                            cF &= ~4294967295n;
                            if (notCanonicalScheme)
                            {
                                cF |= 1n;
                            }
                            info.Offset.Path = idx;
                            notEmpty = false;
                            if ((cF & 562949953421312n) !== 0n)
                            {
                                info.Offset.End = this._originalUnicodeString.length;
                            }
                            if (idx < info.Offset.End)
                            {
                                /*fixed*/ 
                                {
                                    /*char**/ let userString = $.$$.System.String.GetPinnableReference.call(this.OriginalString);
                                    if (userString.GetAt(idx) === /*:*/ 58)
                                    {
                                        /*int*/ let port = 0;
                                        if (++idx < info.Offset.End)
                                        {
                                            port = userString.GetAt(idx) - /*0*/ 48;
                                            if ((port >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                                            {
                                                notEmpty = true;
                                                if (port === 0)
                                                {
                                                    cF |= (8n | 512n);
                                                }
                                                for(++idx; idx < info.Offset.End; ++idx)
                                                {
                                                    /*int*/ let val = userString.GetAt(idx) - /*0*/ 48;
                                                    if ((val >>> 0) > (/*9*/ 57 - /*0*/ 48))
                                                    {
                                                        break;
                                                    }
                                                    port = (((((port * 10) | 0) + val) | 0));
                                                }
                                            }
                                        }
                                        if (notEmpty && this._syntax.DefaultPort !== port)
                                        {
                                            info.Offset.PortValue = $.$cast(port, $.$$.System.UInt16);
                                            cF |= 549755813888n;
                                        }
                                        else 
                                        {
                                            cF |= (8n | 512n);
                                        }
                                        info.Offset.Path = idx;
                                    }
                                }
                            }
                        }
                        case 1: /*Done*/
                        cF |= 70368744177664n;
                        $.$$.System.Threading.Interlocked.CompareExchange$14($.$spu.System.Uri.UriInfo, $.$ref(() => this._info, ($v) => this._info = $v, $.$spu.System.Uri.UriInfo), info, null);
                        current = this._flags;
                        while((current & 70368744177664n) === 0n)
                        {
                            /*Flags*/ let oldValue = $.$$.System.Threading.Interlocked.CompareExchange$14($.$spu.System.Uri.Flags, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => this._flags, ($v) => this._flags = $v, null), (current & ~4294967295n) | cF, current);
                            if (oldValue === current)
                            {
                                return;
                            }
                            current = oldValue;
                        }
                    }
                    break;
                }
            }
            /*void */ CreateHostString()
            {
                if (!this._syntax.IsSimple)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._info)
                        {
                            if (this.NotAny(4398046511104n))
                            {
                                this._flags |= 4398046511104n;
                                this.GetHostViaCustomSyntax();
                                this._flags &= ~4398046511104n;
                                return;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._info)
                    }
                }
                /*Flags*/ let flags = this._flags;
                /*string*/ let host = $.$spu.System.Uri.CreateHostStringHelper(this._string, this._info.Offset.Host, this._info.Offset.Path, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => flags, ($v) => flags = $v, null), this._info);
                if (host.length !== 0)
                {
                    if (this.HostType === 21474836480n)
                    {
                        /*int*/ let idx = 0;
                        /*Check*/ let result;
                        /*fixed*/ 
                        {
                            /*char**/ let pHost = $.$$.System.String.GetPinnableReference.call(host);
                            result = this.CheckCanonical(pHost, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), host.length, /*\uFFFF*/ 65535);
                        }
                        if ((result & 2/*Check.DisplayCanonical*/) === 0)
                        {
                            if (this.NotAny(35184372088832n) || (result & 32/*Check.ReservedFound*/) !== 0)
                            {
                                flags |= 4n;
                            }
                        }
                        if (this.InFact(35184372088832n) && (result & (32/*Check.ReservedFound*/ | 1/*Check.EscapedCanonical*/)) !== 0)
                        {
                            result &= ~1/*Check.EscapedCanonical*/;
                        }
                        if ((result & (1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/)) !== 1/*Check.EscapedCanonical*/)
                        {
                            flags |= 256n;
                            if (this.NotAny(34359738368n))
                            {
                                host = $.$spu.System.UriHelper.EscapeString$2(host, !this.IsImplicitFile, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
                            }
                            else 
                            {
                            }
                        }
                    }
                    else if (this.NotAny(2199023255552n))
                    {
                        if (!((this._info._moreInfo?.ScopeId ?? null) === null))
                        {
                            flags |= (4n | 256n);
                        }
                        else 
                        {
                            for(/*int*/ let i = 0; i < host.length; ++i)
                            {
                                if ((((this._info.Offset.Host + i) | 0)) >= this._info.Offset.End || $.$$.System.String.get_Chars.call(host, i) !== $.$$.System.String.get_Chars.call(this._string, ((this._info.Offset.Host + i) | 0)))
                                {
                                    flags |= (4n | 256n);
                                    break;
                                }
                            }
                        }
                    }
                }
                this._info.Host = host;
                this.InterlockedSetFlags(flags);
            }
            static /*string */ CreateHostStringHelper(/*string*/ str, /*int*/ idx, /*int*/ end, /*ref Flags*/ flags, /*UriInfo*/ info)
            {
                /*bool*/ let loopback = false;
                /*string*/ let host;
                let $switch1 = flags.$v & 30064771072n;
                switch($switch1)
                {
                    case 12884901888n:
                    host = $.$spu.System.DomainNameHelper.ParseCanonicalName(str, idx, end, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => loopback, ($v) => loopback = $v, null));
                    break;
                    case 4294967296n:
                    /*ReadOnlySpan<char>*/ let scopeIdSpan;
                    host = $.$spu.System.Net.IPv6AddressHelper.ParseCanonicalName($.$$.System.MemoryExtensions.AsSpan$2(str, idx), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => loopback, ($v) => loopback = $v, null), $.$ref(() => scopeIdSpan, ($v) => scopeIdSpan = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Char)));
                    if (!scopeIdSpan.IsEmpty)
                    {
                        info.MoreInfo.ScopeId = $.$$.System.String.Create$7(scopeIdSpan);
                    }
                    break;
                    case 8589934592n:
                    host = $.$spu.System.Net.IPv4AddressHelper.ParseCanonicalName(str, idx, end, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => loopback, ($v) => loopback = $v, null));
                    break;
                    case 17179869184n:
                    host = $.$spu.System.UncNameHelper.ParseCanonicalName(str, idx, end, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => loopback, ($v) => loopback = $v, null));
                    break;
                    case 21474836480n:
                    if ($.$spu.System.Uri.StaticInFact(flags.$v, 8796093022208n))
                    {
                        host = $.$$.System.String.Empty;
                    }
                    else 
                    {
                        host = $.$$.System.String.Substring.call(str, idx, ((end - idx) | 0));
                    }
                    if (host.length === 0)
                    {
                        loopback = true;
                    }
                    break;
                    case 30064771072n:
                    host = $.$$.System.String.Empty;
                    break;
                    default:
                    throw $.$spu.System.Uri.GetException(8/*ParsingError.BadHostName*/);
                }
                if (loopback)
                {
                    flags.$v |= 274877906944n;
                }
                return host;
            }
            /*void */ GetHostViaCustomSyntax()
            {
                if ($.$$.System.String.op_Inequality(this._info.Host, null))
                {
                    return;
                }
                /*string*/ let host = this._syntax.InternalGetComponents(this, 4/*UriComponents.Host*/, 1/*UriFormat.UriEscaped*/);
                if (this._info.Host === null)
                {
                    /*ParsingError*/ let err = 0/*ParsingError.None*/;
                    /*Flags*/ let flags = this._flags & ~30064771072n;
                    /*fixed*/ 
                    {
                        /*char**/ let pHost = $.$$.System.String.GetPinnableReference.call(host);
                        /*string?*/ let newHost = null;
                        if (this.CheckAuthorityHelper(pHost, 0, host.length, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.ParsingError, () => err, ($v) => err = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => flags, ($v) => flags = $v, null), this._syntax, $.$ref(() => newHost, ($v) => newHost = $v, $.$$.System.String)) !== host.length)
                        {
                            flags &= ~30064771072n;
                            flags |= 30064771072n;
                        }
                    }
                    if (err !== 0/*ParsingError.None*/ || (flags & 30064771072n) === 30064771072n)
                    {
                        this._flags = (this._flags & ~30064771072n) | 21474836480n;
                    }
                    else 
                    {
                        host = $.$spu.System.Uri.CreateHostStringHelper(host, 0, host.length, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Uri.Flags, () => flags, ($v) => flags = $v, null), this._info);
                        for(/*int*/ let i = 0; i < host.length; ++i)
                        {
                            if ((((this._info.Offset.Host + i) | 0)) >= this._info.Offset.End || $.$$.System.String.get_Chars.call(host, i) !== $.$$.System.String.get_Chars.call(this._string, ((this._info.Offset.Host + i) | 0)))
                            {
                                this._flags |= (4n | 256n);
                                break;
                            }
                        }
                        this._flags = (this._flags & ~30064771072n) | (flags & 30064771072n);
                    }
                }
                /*string*/ let portStr = this._syntax.InternalGetComponents(this, 128/*UriComponents.StrongPort*/, 1/*UriFormat.UriEscaped*/);
                /*int*/ let port = 0;
                if ($.$$.System.String.IsNullOrEmpty(portStr))
                {
                    this._flags &= ~549755813888n;
                    this._flags |= (8n | 512n);
                    this._info.Offset.PortValue = 0;
                }
                else 
                {
                    for(/*int*/ let idx = 0; idx < portStr.length; ++idx)
                    {
                        /*int*/ let val = $.$$.System.String.get_Chars.call(portStr, idx) - /*0*/ 48;
                        if (val < 0 || val > 9 || (port = (((((port * 10) | 0) + val) | 0))) > 65535)
                        {
                            throw new $.$spu.System.UriFormatException().$ctor$16($.$spu.System.SR.Format$5($.$spu.System.SR.net_uri_PortOutOfRange, $.$$.System.Object.GetType.call(this._syntax), portStr));
                        }
                    }
                    if (port !== this._info.Offset.PortValue)
                    {
                        if (port === this._syntax.DefaultPort)
                        {
                            this._flags &= ~549755813888n;
                        }
                        else 
                        {
                            this._flags |= 549755813888n;
                        }
                        this._flags |= (8n | 512n);
                        this._info.Offset.PortValue = $.$cast(port, $.$$.System.UInt16);
                    }
                }
                this._info.Host = host;
            }
            /*string */ GetParts(/*UriComponents*/ uriParts, /*UriFormat*/ formatAs)
            {
                return this.InternalGetComponents(uriParts, formatAs);
            }
            /*string */ GetEscapedParts(/*UriComponents*/ uriParts)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._info !== null && (this._flags & 70368744177664n) !== 0n, "_info != null && (_flags & Flags.MinimalUriInfoSet) != 0");
                /*ushort*/ let nonCanonical = $.$cast((($.$cast(this._flags, $.$$.System.UInt16) & (($.$cast(127n, $.$$.System.UInt16) << 7) >>> 0)) >> 6), $.$$.System.UInt16);
                if (this.InFact(1n))
                {
                    nonCanonical |= $.$cast(1n, $.$$.System.UInt16);
                }
                if ((uriParts & 16/*UriComponents.Path*/) !== 0)
                {
                    if (this.InFact(8192n | 16384n | 32768n))
                    {
                        nonCanonical |= $.$cast(16n, $.$$.System.UInt16);
                    }
                    else if (this.IsDosPath && $.$$.System.String.get_Chars.call(this._string, ((((this._info.Offset.Path + this.SecuredPathIndex) | 0) - 1) | 0)) === /*|*/ 124)
                    {
                        nonCanonical |= $.$cast(16n, $.$$.System.UInt16);
                    }
                }
                if (($.$cast(uriParts, $.$$.System.UInt16) & nonCanonical) === 0)
                {
                    /*string?*/ let ret = this.GetUriPartsFromUserString(uriParts);
                    if (!(ret === null))
                    {
                        return ret;
                    }
                }
                return this.RecreateParts(uriParts, nonCanonical, 1/*UriFormat.UriEscaped*/);
            }
            /*string */ GetUnescapedParts(/*UriComponents*/ uriParts, /*UriFormat*/ formatAs)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._info !== null && (this._flags & 70368744177664n) !== 0n, "_info != null && (_flags & Flags.MinimalUriInfoSet) != 0");
                /*ushort*/ let nonCanonical = $.$cast(($.$cast(this._flags, $.$$.System.UInt16) & $.$cast(127n, $.$$.System.UInt16)), $.$$.System.UInt16);
                if ((uriParts & 16/*UriComponents.Path*/) !== 0)
                {
                    if ((this._flags & (8192n | 16384n | 32768n)) !== 0n)
                    {
                        nonCanonical |= $.$cast(16n, $.$$.System.UInt16);
                    }
                    else if (this.IsDosPath && $.$$.System.String.get_Chars.call(this._string, ((((this._info.Offset.Path + this.SecuredPathIndex) | 0) - 1) | 0)) === /*|*/ 124)
                    {
                        nonCanonical |= $.$cast(16n, $.$$.System.UInt16);
                    }
                }
                if (($.$cast(uriParts, $.$$.System.UInt16) & nonCanonical) === 0)
                {
                    /*string?*/ let ret = this.GetUriPartsFromUserString(uriParts);
                    if (!(ret === null))
                    {
                        return ret;
                    }
                }
                return this.RecreateParts(uriParts, nonCanonical, formatAs);
            }
            /*string */ RecreateParts(/*UriComponents*/ parts, /*ushort*/ nonCanonical, /*UriFormat*/ formatAs)
            {
                this.EnsureHostString(false);
                /*string*/ let str = this._string;
                /*var*/ let dest = str.length <= 512/*StackallocThreshold*/ ? new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null)) : new $.$spu.System.Text.ValueStringBuilder().$ctor$3(str.length);
                /*scoped ReadOnlySpan<char>*/ let result = this.RecreateParts$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null), str, parts, nonCanonical, formatAs);
                /*string*/ let s = $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(result);
                dest.Dispose();
                return s;
            }
            /*bool */ TryRecreateParts(/*scoped Span<char>*/ span, /*out int*/ charsWritten, /*UriComponents*/ parts, /*ushort*/ nonCanonical, /*UriFormat*/ formatAs)
            {
                this.EnsureHostString(false);
                /*string*/ let str = this._string;
                /*var*/ let dest = str.length <= 512/*StackallocThreshold*/ ? new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null)) : new $.$spu.System.Text.ValueStringBuilder().$ctor$3(str.length);
                /*scoped ReadOnlySpan<char>*/ let result = this.RecreateParts$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => dest, ($v) => dest = $v, null), str, parts, nonCanonical, formatAs);
                /*bool*/ let copied = result.TryCopyTo(span);
                charsWritten.$v = copied ? result.Length : 0;
                dest.Dispose();
                return copied;
            }
            /*ReadOnlySpan<char> */ RecreateParts$1(/*scoped ref ValueStringBuilder*/ dest, /*string*/ str, /*UriComponents*/ parts, /*ushort*/ nonCanonical, /*UriFormat*/ formatAs)
            {
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(this.InFact(140737488355328n), "InFact(Flags.AllUriInfoSet)");
                            if ((parts & 1/*UriComponents.Scheme*/) !== 0)
                            {
                                dest.$v.Append$3(this._syntax.SchemeName);
                                if (parts !== 1/*UriComponents.Scheme*/)
                                {
                                    dest.$v.Append$1(/*:*/ 58);
                                    if (this.InFact(68719476736n))
                                    {
                                        dest.$v.Append$1(/*/*/ 47);
                                        dest.$v.Append$1(/*/*/ 47);
                                    }
                                }
                            }
                            if ((parts & 2/*UriComponents.UserInfo*/) !== 0 && this.InFact(137438953472n))
                            {
                                /*ReadOnlySpan<char>*/ let slice = $.$$.System.MemoryExtensions.AsSpan$1(str, this._info.Offset.User, ((this._info.Offset.Host - this._info.Offset.User) | 0));
                                if ((nonCanonical & $.$cast(2/*UriComponents.UserInfo*/, $.$$.System.UInt16)) !== 0)
                                {
                                    switch(formatAs)
                                    {
                                        case 1/*UriFormat.UriEscaped*/:
                                        if (this.NotAny(34359738368n))
                                        {
                                            $.$spu.System.UriHelper.EscapeString$1(slice, dest, true, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
                                        }
                                        else 
                                        {
                                            dest.$v.Append$2(slice);
                                        }
                                        break;
                                        case 3/*UriFormat.SafeUnescaped*/:
                                        let $t3 = slice;
                                        $.$spu.System.UriHelper.UnescapeString$2($t3.Slice(0, $t3.Length - 1), dest, /*@*/ 64, /*/*/ 47, /*\\*/ 92, this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/, this._syntax, false);
                                        dest.$v.Append$1(/*@*/ 64);
                                        break;
                                        case 2/*UriFormat.Unescaped*/:
                                        $.$spu.System.UriHelper.UnescapeString$2(slice, dest, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, this._syntax, false);
                                        break;
                                        default:
                                        dest.$v.Append$2(slice);
                                        break;
                                    }
                                }
                                else 
                                {
                                    dest.$v.Append$2(slice);
                                }
                                if (parts === 2/*UriComponents.UserInfo*/)
                                {
                                    dest.$v.Length--;
                                }
                            }
                            if ((parts & 4/*UriComponents.Host*/) !== 0)
                            {
                                /*string*/ let host = this._info.Host;
                                if (host.length !== 0)
                                {
                                    /*UnescapeMode*/ let mode;
                                    if (formatAs !== 1/*UriFormat.UriEscaped*/ && this.HostType === 21474836480n && (nonCanonical & $.$cast(4/*UriComponents.Host*/, $.$$.System.UInt16)) !== 0)
                                    {
                                        mode = formatAs === 2/*UriFormat.Unescaped*/ ? (2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/) : (this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/);
                                    }
                                    else 
                                    {
                                        mode = 0/*UnescapeMode.CopyOnly*/;
                                    }
                                    /*var*/ let hostBuilder = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                                    if ((parts & 256/*UriComponents.NormalizedHost*/) !== 0)
                                    {
                                        host = $.$spu.System.UriHelper.StripBidiControlCharacters($.$$.System.String.op_Implicit(host), host);
                                        if (!$.$spu.System.DomainNameHelper.TryGetUnicodeEquivalent(host, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spu.System.Text.ValueStringBuilder, () => hostBuilder, ($v) => hostBuilder = $v, null)))
                                        {
                                            hostBuilder.Length = 0;
                                        }
                                    }
                                    $.$spu.System.UriHelper.UnescapeString$2(hostBuilder.Length === 0 ? $.$$.System.String.op_Implicit(host) : hostBuilder.AsSpan(), dest, /*/*/ 47, /*?*/ 63, /*#*/ 35, mode, this._syntax, false);
                                    hostBuilder.Dispose();
                                    let scopeId;
                                    if ((parts & -2147483648/*UriComponents.SerializationInfoString*/) !== 0 && this.HostType === 4294967296n && $.$is((this._info._moreInfo?.ScopeId ?? null), $.$$.System.String, { set $v(v){ scopeId = v; } }))
                                    {
                                        dest.$v.Length--;
                                        dest.$v.Append$3(scopeId);
                                        dest.$v.Append$1(/*]*/ 93);
                                    }
                                }
                            }
                            if ((parts & 8/*UriComponents.Port*/) !== 0 && (this.InFact(549755813888n) || ((parts & 128/*UriComponents.StrongPort*/) !== 0 && this._syntax.DefaultPort !== -1/*UriParser.NoDefaultPort*/)))
                            {
                                dest.$v.Append$1(/*:*/ 58);
                                /*int*/ let MaxUshortLength = 5;
                                /*int*/ let charsWritten;
                                /*bool*/ let success = $.$$.System.UInt16.TryFormat$1.call(this._info.Offset.PortValue, dest.$v.AppendSpan(MaxUshortLength), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                                $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                                dest.$v.Length -= ((MaxUshortLength - charsWritten) | 0);
                            }
                            if ((parts & 16/*UriComponents.Path*/) !== 0)
                            {
                                this.GetCanonicalPath(dest, formatAs);
                                if (parts === 16/*UriComponents.Path*/)
                                {
                                    /*int*/ let offset;
                                    if (this.InFact(68719476736n) && dest.$v.Length !== 0 && dest.$v.get_Item(0).$v === /*/*/ 47)
                                    {
                                        offset = 1;
                                    }
                                    else 
                                    {
                                        offset = 0;
                                    }
                                    return dest.$v.AsSpan$3(offset);
                                }
                            }
                            if ((parts & 32/*UriComponents.Query*/) !== 0 && this._info.Offset.Query < this._info.Offset.Fragment)
                            {
                                /*int*/ let offset = (((this._info.Offset.Query + 1) | 0));
                                if (parts !== 32/*UriComponents.Query*/)
                                {
                                    dest.$v.Append$1(/*?*/ 63);
                                }
                                /*UnescapeMode*/ let mode = 0/*UnescapeMode.CopyOnly*/;
                                if ((nonCanonical & $.$cast(32/*UriComponents.Query*/, $.$$.System.UInt16)) !== 0)
                                {
                                    if (formatAs === 1/*UriFormat.UriEscaped*/)
                                    {
                                        if (this.NotAny(34359738368n))
                                        {
                                            $.$spu.System.UriHelper.EscapeString$1($.$$.System.MemoryExtensions.AsSpan$1(str, offset, ((this._info.Offset.Fragment - offset) | 0)), dest, true, $.$spu.System.UriHelper.UnreservedReservedExceptHash);
                                            $gotoJumpState1 = 1; /*goto AfterQuery*/
                                            continue $gotoJumpStart1;
                                        }
                                    }
                                    else 
                                    {
                                        mode = (() =>
                                        {
                                            if (formatAs === 32767/*V1ToStringUnescape*/)
                                            {
                                                return (this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/) | 4/*UnescapeMode.V1ToStringFlag*/;
                                            }
                                            if (formatAs === 2/*UriFormat.Unescaped*/)
                                            {
                                                return 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/;
                                            }
                                            return this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/;
                                        })();
                                    }
                                }
                                $.$spu.System.UriHelper.UnescapeString$4(str, offset, this._info.Offset.Fragment, dest, /*#*/ 35, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, mode, this._syntax, true);
                            }
                        }
                        case 1: /*AfterQuery*/
                        if ((parts & 64/*UriComponents.Fragment*/) !== 0 && this._info.Offset.Fragment < this._info.Offset.End)
                        {
                            /*int*/ let offset = ((this._info.Offset.Fragment + 1) | 0);
                            if (parts !== 64/*UriComponents.Fragment*/)
                            {
                                dest.$v.Append$1(/*#*/ 35);
                            }
                            /*UnescapeMode*/ let mode = 0/*UnescapeMode.CopyOnly*/;
                            if ((nonCanonical & $.$cast(64/*UriComponents.Fragment*/, $.$$.System.UInt16)) !== 0)
                            {
                                if (formatAs === 1/*UriFormat.UriEscaped*/)
                                {
                                    if (this.NotAny(34359738368n))
                                    {
                                        $.$spu.System.UriHelper.EscapeString$1($.$$.System.MemoryExtensions.AsSpan$1(str, offset, ((this._info.Offset.End - offset) | 0)), dest, true, $.$spu.System.UriHelper.UnreservedReserved);
                                        $gotoJumpState1 = 2; /*goto AfterFragment*/
                                        continue $gotoJumpStart1;
                                    }
                                }
                                else 
                                {
                                    mode = (() =>
                                    {
                                        if (formatAs === 32767/*V1ToStringUnescape*/)
                                        {
                                            return (this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/) | 4/*UnescapeMode.V1ToStringFlag*/;
                                        }
                                        if (formatAs === 2/*UriFormat.Unescaped*/)
                                        {
                                            return 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/;
                                        }
                                        return this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/;
                                    })();
                                }
                            }
                            $.$spu.System.UriHelper.UnescapeString$4(str, offset, this._info.Offset.End, dest, /*#*/ 35, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, mode, this._syntax, false);
                        }
                        case 2: /*AfterFragment*/
                        return dest.$v.AsSpan();
                    }
                    break;
                }
            }
            /*string? */ GetUriPartsFromUserString(/*UriComponents*/ uriParts)
            {
                /*int*/ let delimiterAwareIdx;
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    let $switch1 = $switchJumpState1 ?? (uriParts & ~1073741824/*UriComponents.KeepDelimiter*/);
                    switch($switch1)
                    {
                        case 1/*UriComponents.Scheme*/ | 4/*UriComponents.Host*/ | 8/*UriComponents.Port*/:
                        if (!this.InFact(137438953472n))
                        {
                            return $.$$.System.String.Substring.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.Path - this._info.Offset.Scheme) | 0));
                        }
                        return $.$$.System.String.Concat$8($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Scheme, ((this._info.Offset.User - this._info.Offset.Scheme) | 0)), $.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Host, ((this._info.Offset.Path - this._info.Offset.Host) | 0)));
                        case 132/*UriComponents.HostAndPort*/:
                        if (!this.InFact(137438953472n))
                        {
                            $switchJumpState1 = 134/*UriComponents.StrongAuthority*/; /*goto case UriComponents.StrongAuthority*/
                            continue $switchJumpStart1;
                        }
                        if (this.InFact(549755813888n) || this._syntax.DefaultPort === -1/*UriParser.NoDefaultPort*/)
                        {
                            return $.$$.System.String.Substring.call(this._string, this._info.Offset.Host, ((this._info.Offset.Path - this._info.Offset.Host) | 0));
                        }
                        return $.$$.System.String.Concat$7($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Host, ((this._info.Offset.Path - this._info.Offset.Host) | 0)), $.$$.System.String.op_Implicit(":"), $.$$.System.String.op_Implicit($.$$.System.UInt16.ToString$1.call(this._info.Offset.PortValue, $.$$.System.Globalization.CultureInfo.InvariantCulture)));
                        case 127/*UriComponents.AbsoluteUri*/:
                        if (this._info.Offset.Scheme === 0 && this._info.Offset.End === this._string.length)
                        {
                            return this._string;
                        }
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.End - this._info.Offset.Scheme) | 0));
                        case 61/*UriComponents.HttpRequestUrl*/:
                        if (this.InFact(137438953472n))
                        {
                            return $.$$.System.String.Concat$8($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Scheme, ((this._info.Offset.User - this._info.Offset.Scheme) | 0)), $.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Host, ((this._info.Offset.Fragment - this._info.Offset.Host) | 0)));
                        }
                        if (this._info.Offset.Scheme === 0 && this._info.Offset.Fragment === this._string.length)
                        {
                            return this._string;
                        }
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.Fragment - this._info.Offset.Scheme) | 0));
                        case 13/*UriComponents.SchemeAndServer*/ | 2/*UriComponents.UserInfo*/:
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.Path - this._info.Offset.Scheme) | 0));
                        case (127/*UriComponents.AbsoluteUri*/ & ~64/*UriComponents.Fragment*/):
                        if (this._info.Offset.Scheme === 0 && this._info.Offset.Fragment === this._string.length)
                        {
                            return this._string;
                        }
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.Fragment - this._info.Offset.Scheme) | 0));
                        case 1/*UriComponents.Scheme*/:
                        if (uriParts !== 1/*UriComponents.Scheme*/)
                        {
                            return $.$$.System.String.Substring.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.User - this._info.Offset.Scheme) | 0));
                        }
                        return this._syntax.SchemeName;
                        case 4/*UriComponents.Host*/:
                        /*int*/ let idx = this._info.Offset.Path;
                        if (this.InFact(549755813888n | 8n))
                        {
                            while($.$$.System.String.get_Chars.call(this._string, --idx) !== /*:*/ 58)
                            {
                            }
                        }
                        return (((idx - this._info.Offset.Host) | 0) === 0) ? $.$$.System.String.Empty : $.$$.System.String.Substring.call(this._string, this._info.Offset.Host, ((idx - this._info.Offset.Host) | 0));
                        case 16/*UriComponents.Path*/:
                        if (uriParts === 16/*UriComponents.Path*/ && this.InFact(68719476736n) && this._info.Offset.End > this._info.Offset.Path && $.$$.System.String.get_Chars.call(this._string, this._info.Offset.Path) === /*/*/ 47)
                        {
                            delimiterAwareIdx = ((this._info.Offset.Path + 1) | 0);
                        }
                        else 
                        {
                            delimiterAwareIdx = this._info.Offset.Path;
                        }
                        if (delimiterAwareIdx >= this._info.Offset.Query)
                        {
                            return $.$$.System.String.Empty;
                        }
                        return $.$$.System.String.Substring.call(this._string, delimiterAwareIdx, ((this._info.Offset.Query - delimiterAwareIdx) | 0));
                        case 32/*UriComponents.Query*/:
                        if (uriParts === 32/*UriComponents.Query*/)
                        {
                            delimiterAwareIdx = ((this._info.Offset.Query + 1) | 0);
                        }
                        else 
                        {
                            delimiterAwareIdx = this._info.Offset.Query;
                        }
                        if (delimiterAwareIdx >= this._info.Offset.Fragment)
                        {
                            return $.$$.System.String.Empty;
                        }
                        return $.$$.System.String.Substring.call(this._string, delimiterAwareIdx, ((this._info.Offset.Fragment - delimiterAwareIdx) | 0));
                        case 64/*UriComponents.Fragment*/:
                        if (uriParts === 64/*UriComponents.Fragment*/)
                        {
                            delimiterAwareIdx = ((this._info.Offset.Fragment + 1) | 0);
                        }
                        else 
                        {
                            delimiterAwareIdx = this._info.Offset.Fragment;
                        }
                        if (delimiterAwareIdx >= this._info.Offset.End)
                        {
                            return $.$$.System.String.Empty;
                        }
                        return $.$$.System.String.Substring.call(this._string, delimiterAwareIdx, ((this._info.Offset.End - delimiterAwareIdx) | 0));
                        case 2/*UriComponents.UserInfo*/ | 4/*UriComponents.Host*/ | 8/*UriComponents.Port*/:
                        return (((this._info.Offset.Path - this._info.Offset.User) | 0) === 0) ? $.$$.System.String.Empty : $.$$.System.String.Substring.call(this._string, this._info.Offset.User, ((this._info.Offset.Path - this._info.Offset.User) | 0));
                        case 134/*UriComponents.StrongAuthority*/:
                        if (this.InFact(549755813888n) || this._syntax.DefaultPort === -1/*UriParser.NoDefaultPort*/)
                        {
                            $switchJumpState1 = 2/*UriComponents.UserInfo*/ | 4/*UriComponents.Host*/ | 8/*UriComponents.Port*/; /*goto case UriComponents.UserInfo | UriComponents.Host | UriComponents.Port*/
                            continue $switchJumpStart1;
                        }
                        return $.$$.System.String.Concat$7($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.User, ((this._info.Offset.Path - this._info.Offset.User) | 0)), $.$$.System.String.op_Implicit(":"), $.$$.System.String.op_Implicit($.$$.System.UInt16.ToString$1.call(this._info.Offset.PortValue, $.$$.System.Globalization.CultureInfo.InvariantCulture)));
                        case 48/*UriComponents.PathAndQuery*/:
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.Path, ((this._info.Offset.Fragment - this._info.Offset.Path) | 0));
                        case 61/*UriComponents.HttpRequestUrl*/ | 64/*UriComponents.Fragment*/:
                        if (this.InFact(137438953472n))
                        {
                            return $.$$.System.String.Concat$8($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Scheme, ((this._info.Offset.User - this._info.Offset.Scheme) | 0)), $.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Host, ((this._info.Offset.End - this._info.Offset.Host) | 0)));
                        }
                        if (this._info.Offset.Scheme === 0 && this._info.Offset.End === this._string.length)
                        {
                            return this._string;
                        }
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.Scheme, ((this._info.Offset.End - this._info.Offset.Scheme) | 0));
                        case 48/*UriComponents.PathAndQuery*/ | 64/*UriComponents.Fragment*/:
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.Path, ((this._info.Offset.End - this._info.Offset.Path) | 0));
                        case 2/*UriComponents.UserInfo*/:
                        if (this.NotAny(137438953472n))
                        {
                            return $.$$.System.String.Empty;
                        }
                        if (uriParts === 2/*UriComponents.UserInfo*/)
                        {
                            delimiterAwareIdx = ((this._info.Offset.Host - 1) | 0);
                        }
                        else 
                        {
                            delimiterAwareIdx = this._info.Offset.Host;
                        }
                        if (this._info.Offset.User >= delimiterAwareIdx)
                        {
                            return $.$$.System.String.Empty;
                        }
                        return $.$$.System.String.Substring.call(this._string, this._info.Offset.User, ((delimiterAwareIdx - this._info.Offset.User) | 0));
                        default:
                        return null;
                    }
                    break;
                }
            }
            static /*void */ GetLengthWithoutTrailingSpaces(/*string*/ str, /*ref int*/ length, /*int*/ idx)
            {
                /*int*/ let local = length.$v;
                while(local > idx && $.$spu.System.UriHelper.IsLWS($.$$.System.String.get_Chars.call(str, ((local - 1) | 0))))
                {
                    --local;
                }
                length.$v = local;
            }
            /*void */ ParseRemaining()
            {
                /*Flags*/ let cF;
                /*bool*/ let buildIriStringFromPath;
                /*int*/ let origIdx;
                /*int*/ let idx;
                /*int*/ let length;
                /*Check*/ let result;
                /*UriSyntaxFlags*/ let syntaxFlags;
                /*bool*/ let nonCanonical;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            this.EnsureUriInfo();
                            cF = 0n;
                            if (this.UserDrivenParsing)
                            {
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            buildIriStringFromPath = this.InFact(562949953421312n);
                            idx = this._info.Offset.Scheme;
                            length = this._string.length;
                            result = 0/*Check.None*/;
                            syntaxFlags = this._syntax.Flags;
                            /*fixed*/ 
                            {
                                /*char**/ let str = $.$$.System.String.GetPinnableReference.call(this._string);
                                $.$spu.System.Uri.GetLengthWithoutTrailingSpaces(this._string, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32), idx);
                                if (this.IsImplicitFile)
                                {
                                    cF |= 1n;
                                }
                                else 
                                {
                                    /*int*/ let i;
                                    /*string*/ let schemeName = this._syntax.SchemeName;
                                    for(i = 0; i < schemeName.length; ++i)
                                    {
                                        if ($.$$.System.String.get_Chars.call(schemeName, i) !== str.GetAt(((idx + i) | 0)))
                                        {
                                            cF |= 1n;
                                        }
                                    }
                                    if (((this._flags & 68719476736n) !== 0n) && (((((idx + i) | 0) + 3) | 0) >= length || str.GetAt(((((idx + i) | 0) + 1) | 0)) !== /*/*/ 47 || str.GetAt(((((idx + i) | 0) + 2) | 0)) !== /*/*/ 47))
                                    {
                                        cF |= 1n;
                                    }
                                }
                                if ((this._flags & 137438953472n) !== 0n)
                                {
                                    idx = this._info.Offset.User;
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), this._info.Offset.Host, /*@*/ 64);
                                    if ((result & 2/*Check.DisplayCanonical*/) === 0)
                                    {
                                        cF |= 2n;
                                    }
                                    if ((result & (1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/)) !== 1/*Check.EscapedCanonical*/)
                                    {
                                        cF |= 128n;
                                    }
                                    if (this.IriParsing && ((result & (2/*Check.DisplayCanonical*/ | 1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) === (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                                    {
                                        cF |= 1125899906842624n;
                                    }
                                }
                            }
                            idx = this._info.Offset.Path;
                            origIdx = this._info.Offset.Path;
                            if (buildIriStringFromPath)
                            {
                                this.DebugAssertInCtor();
                                if (this.IsFile && !this.IsUncPath)
                                {
                                    if (this.IsImplicitFile)
                                    {
                                        this._string = $.$$.System.String.Empty;
                                    }
                                    else 
                                    {
                                        this._string = this._syntax.SchemeName + $.$spu.System.Uri.SchemeDelimiter;
                                    }
                                    this._info.Offset.Scheme = 0;
                                    this._info.Offset.User = this._string.length;
                                    this._info.Offset.Host = this._string.length;
                                }
                                this._info.Offset.Path = this._string.length;
                                idx = this._info.Offset.Path;
                            }
                            if (this.DisablePathAndQueryCanonicalization)
                            {
                                if (buildIriStringFromPath)
                                {
                                    this.DebugAssertInCtor();
                                    this._string = $.$$.System.String.Concat$8($.$$.System.String.op_Implicit(this._string), $.$$.System.MemoryExtensions.AsSpan$2(this._originalUnicodeString, origIdx));
                                }
                                /*string*/ let str = this._string;
                                if (this.IsImplicitFile || (syntaxFlags & 32/*UriSyntaxFlags.MayHaveQuery*/) === 0)
                                {
                                    idx = str.length;
                                }
                                else 
                                {
                                    idx = $.$$.System.String.IndexOf$3.call(str, /*?*/ 63);
                                    if (idx === -1)
                                    {
                                        idx = str.length;
                                    }
                                }
                                this._info.Offset.Query = idx;
                                this._info.Offset.Fragment = str.length;
                                this._info.Offset.End = str.length;
                                $gotoJumpState1 = 1; /*goto Done*/
                                continue $gotoJumpStart1;
                            }
                            if (buildIriStringFromPath)
                            {
                                this.DebugAssertInCtor();
                                /*int*/ let offset = origIdx;
                                if (this.IsImplicitFile || ((syntaxFlags & (32/*UriSyntaxFlags.MayHaveQuery*/ | 64/*UriSyntaxFlags.MayHaveFragment*/)) === 0))
                                {
                                    origIdx = this._originalUnicodeString.length;
                                }
                                else 
                                {
                                    /*ReadOnlySpan<char>*/ let span = $.$$.System.MemoryExtensions.AsSpan$2(this._originalUnicodeString, origIdx);
                                    /*int*/ let index;
                                    if (this._syntax.InFact(32/*UriSyntaxFlags.MayHaveQuery*/))
                                    {
                                        if (this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/))
                                        {
                                            index = $.$$.System.MemoryExtensions.IndexOfAny$8($.$$.System.Char, span, /*?*/ 63, /*#*/ 35);
                                        }
                                        else 
                                        {
                                            index = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, span, /*?*/ 63);
                                        }
                                    }
                                    else 
                                    {
                                        $.$$.System.Diagnostics.Debug.Assert$2(this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/), "_syntax.InFact(UriSyntaxFlags.MayHaveFragment)");
                                        index = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, span, /*#*/ 35);
                                    }
                                    origIdx = index === -1 ? this._originalUnicodeString.length : (((index + origIdx) | 0));
                                }
                                this._string += this.EscapeUnescapeIri(this._originalUnicodeString, offset, origIdx, 16/*UriComponents.Path*/);
                                length = this._string.length;
                                if ($.$$.System.String.op_Equality(this._string, this._originalUnicodeString))
                                {
                                    $.$spu.System.Uri.GetLengthWithoutTrailingSpaces(this._string, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32), idx);
                                }
                            }
                            /*fixed*/ 
                            {
                                /*char**/ let str = $.$$.System.String.GetPinnableReference.call(this._string);
                                if (this.IsImplicitFile || ((syntaxFlags & (32/*UriSyntaxFlags.MayHaveQuery*/ | 64/*UriSyntaxFlags.MayHaveFragment*/)) === 0))
                                {
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), length, /*\uFFFF*/ 65535);
                                }
                                else 
                                {
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), length, (((syntaxFlags & 32/*UriSyntaxFlags.MayHaveQuery*/) !== 0) ? /*?*/ 63 : this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/) ? /*#*/ 35 : /*\uFFFE*/ 65534));
                                }
                                if (((this._flags & 68719476736n) !== 0n) && ((syntaxFlags & 2097152/*UriSyntaxFlags.PathIsRooted*/) !== 0) && (this._info.Offset.Path === length || (str.GetAt(this._info.Offset.Path) !== /*/*/ 47 && str.GetAt(this._info.Offset.Path) !== /*\\*/ 92)))
                                {
                                    cF |= 16384n;
                                }
                            }
                            nonCanonical = false;
                            if (this.IsDosPath || (((this._flags & 68719476736n) !== 0n) && (((syntaxFlags & (8388608/*UriSyntaxFlags.CompressPath*/ | 4194304/*UriSyntaxFlags.ConvertPathSlashes*/)) !== 0) || this._syntax.InFact(33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/))))
                            {
                                if (((result & 128/*Check.DotSlashEscaped*/) !== 0) && this._syntax.InFact(33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/))
                                {
                                    cF |= (1024n | 16n);
                                    nonCanonical = true;
                                }
                                if (((syntaxFlags & (4194304/*UriSyntaxFlags.ConvertPathSlashes*/)) !== 0) && (result & 16/*Check.BackslashInPath*/) !== 0)
                                {
                                    cF |= (1024n | 16n);
                                    nonCanonical = true;
                                }
                                if (((syntaxFlags & (8388608/*UriSyntaxFlags.CompressPath*/)) !== 0) && ((cF & 1024n) !== 0n || (result & 4/*Check.DotSlashAttn*/) !== 0))
                                {
                                    cF |= 8192n;
                                }
                                if ((result & 16/*Check.BackslashInPath*/) !== 0)
                                {
                                    cF |= 32768n;
                                }
                            }
                            else if ((result & 16/*Check.BackslashInPath*/) !== 0)
                            {
                                cF |= 1024n;
                                nonCanonical = true;
                            }
                            if ((result & 2/*Check.DisplayCanonical*/) === 0)
                            {
                                if (((this._flags & 35184372088832n) === 0n) || ((this._flags & 34359738368n) !== 0n) || (result & 32/*Check.ReservedFound*/) !== 0)
                                {
                                    cF |= 16n;
                                    nonCanonical = true;
                                }
                            }
                            if (((this._flags & 35184372088832n) !== 0n) && (result & (32/*Check.ReservedFound*/ | 1/*Check.EscapedCanonical*/)) !== 0)
                            {
                                result &= ~1/*Check.EscapedCanonical*/;
                            }
                            if ((result & 1/*Check.EscapedCanonical*/) === 0)
                            {
                                cF |= 1024n;
                            }
                            if (this.IriParsing && !nonCanonical && ((result & (2/*Check.DisplayCanonical*/ | 1/*Check.EscapedCanonical*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) === (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                            {
                                cF |= 2251799813685248n;
                            }
                            if (buildIriStringFromPath)
                            {
                                this.DebugAssertInCtor();
                                /*int*/ let offset = origIdx;
                                if (origIdx < this._originalUnicodeString.length && $.$$.System.String.get_Chars.call(this._originalUnicodeString, origIdx) === /*?*/ 63)
                                {
                                    if ((syntaxFlags & (64/*UriSyntaxFlags.MayHaveFragment*/)) !== 0)
                                    {
                                        ++origIdx;
                                        /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$2(this._originalUnicodeString, origIdx), /*#*/ 35);
                                        origIdx = index === -1 ? this._originalUnicodeString.length : (((index + origIdx) | 0));
                                    }
                                    else 
                                    {
                                        origIdx = this._originalUnicodeString.length;
                                    }
                                    this._string += this.EscapeUnescapeIri(this._originalUnicodeString, offset, origIdx, 32/*UriComponents.Query*/);
                                    length = this._string.length;
                                    if ($.$$.System.String.op_Equality(this._string, this._originalUnicodeString))
                                    {
                                        $.$spu.System.Uri.GetLengthWithoutTrailingSpaces(this._string, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32), idx);
                                    }
                                }
                            }
                            this._info.Offset.Query = idx;
                            /*fixed*/ 
                            {
                                /*char**/ let str = $.$$.System.String.GetPinnableReference.call(this._string);
                                if (idx < length && str.GetAt(idx) === /*?*/ 63)
                                {
                                    ++idx;
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), length, ((syntaxFlags & (64/*UriSyntaxFlags.MayHaveFragment*/)) !== 0) ? /*#*/ 35 : /*\uFFFE*/ 65534);
                                    if ((result & 2/*Check.DisplayCanonical*/) === 0)
                                    {
                                        cF |= 32n;
                                    }
                                    if ((result & (1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/)) !== 1/*Check.EscapedCanonical*/)
                                    {
                                        cF |= 2048n;
                                    }
                                    if (this.IriParsing && ((result & (2/*Check.DisplayCanonical*/ | 1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) === (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                                    {
                                        cF |= 4503599627370496n;
                                    }
                                }
                            }
                            if (buildIriStringFromPath)
                            {
                                this.DebugAssertInCtor();
                                /*int*/ let offset = origIdx;
                                if (origIdx < this._originalUnicodeString.length && $.$$.System.String.get_Chars.call(this._originalUnicodeString, origIdx) === /*#*/ 35)
                                {
                                    origIdx = this._originalUnicodeString.length;
                                    this._string += this.EscapeUnescapeIri(this._originalUnicodeString, offset, origIdx, 64/*UriComponents.Fragment*/);
                                    length = this._string.length;
                                    $.$spu.System.Uri.GetLengthWithoutTrailingSpaces(this._string, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32), idx);
                                }
                            }
                            this._info.Offset.Fragment = idx;
                            /*fixed*/ 
                            {
                                /*char**/ let str = $.$$.System.String.GetPinnableReference.call(this._string);
                                if (idx < length && str.GetAt(idx) === /*#*/ 35)
                                {
                                    ++idx;
                                    result = this.CheckCanonical(str, $.$ref(() => idx, ($v) => idx = $v, $.$$.System.Int32), length, /*\uFFFE*/ 65534);
                                    if ((result & 2/*Check.DisplayCanonical*/) === 0)
                                    {
                                        cF |= 64n;
                                    }
                                    if ((result & (1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/)) !== 1/*Check.EscapedCanonical*/)
                                    {
                                        cF |= 4096n;
                                    }
                                    if (this.IriParsing && ((result & (2/*Check.DisplayCanonical*/ | 1/*Check.EscapedCanonical*/ | 16/*Check.BackslashInPath*/ | 8/*Check.FoundNonAscii*/ | 64/*Check.NotIriCanonical*/)) === (2/*Check.DisplayCanonical*/ | 8/*Check.FoundNonAscii*/)))
                                    {
                                        cF |= 9007199254740992n;
                                    }
                                }
                            }
                            this._info.Offset.End = idx;
                        }
                        case 1: /*Done*/
                        cF |= 140737488355328n;
                        this.InterlockedSetFlags(cF);
                    }
                    break;
                }
            }
            static /*int */ ParseSchemeCheckImplicitFile(/*string*/ uriString, /*ref ParsingError*/ err, /*ref Flags*/ flags, /*ref UriParser?*/ syntax)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(err.$v === 0/*ParsingError.None*/, "err == ParsingError.None");
                $.$$.System.Diagnostics.Debug.Assert$2((flags.$v & 144115188075855872n) === 0n, "(flags & Flags.Debug_LeftConstructor) == 0");
                /*int*/ let i = 0;
                while((i >>> 0) < (uriString.length >>> 0) && $.$spu.System.UriHelper.IsLWS($.$$.System.String.get_Chars.call(uriString, i)))
                {
                    i++;
                }
                if (!$.$$.System.OperatingSystem.IsWindows() && (i >>> 0) < (uriString.length >>> 0) && $.$$.System.String.get_Chars.call(uriString, i) === /*/*/ 47 && (((((i + 1) | 0)) >>> 0) >= (uriString.length >>> 0) || !(($.$$.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*/*/ 47) || ($.$$.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*\\*/ 92))))
                {
                    flags.$v |= (18014398509481984n | 35184372088832n | 68719476736n);
                    syntax.$v = $.$spu.System.UriParser.UnixFileUri;
                    return i;
                }
                /*int*/ let colonOffset = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$2(uriString, i), /*:*/ 58);
                if (((((i + 2) | 0)) >>> 0) >= (uriString.length >>> 0) || colonOffset === 0 || (i >>> 0) >= (uriString.length >>> 0) || ((((i + 1) | 0)) >>> 0) >= (uriString.length >>> 0))
                {
                    err.$v = 1/*ParsingError.BadFormat*/;
                    return 0;
                }
                if (($.$$.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*:*/ 58) || ($.$$.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*|*/ 124))
                {
                    if ($.$$.System.Char.IsAsciiLetter($.$$.System.String.get_Chars.call(uriString, i)))
                    {
                        if (($.$$.System.String.get_Chars.call(uriString, ((i + 2) | 0)) === /*\\*/ 92) || ($.$$.System.String.get_Chars.call(uriString, ((i + 2) | 0)) === /*/*/ 47))
                        {
                            flags.$v |= (8796093022208n | 35184372088832n | 68719476736n);
                            syntax.$v = $.$spu.System.UriParser.FileUri;
                            return i;
                        }
                        err.$v = 7/*ParsingError.MustRootedPath*/;
                        return 0;
                    }
                    err.$v = $.$$.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*:*/ 58 ? 2/*ParsingError.BadScheme*/ : 1/*ParsingError.BadFormat*/;
                    return 0;
                }
                else if (($.$$.System.String.get_Chars.call(uriString, i) === /*/*/ 47) || ($.$$.System.String.get_Chars.call(uriString, i) === /*\\*/ 92))
                {
                    if (($.$$.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*\\*/ 92) || ($.$$.System.String.get_Chars.call(uriString, ((i + 1) | 0)) === /*/*/ 47))
                    {
                        flags.$v |= (17592186044416n | 35184372088832n | 68719476736n);
                        syntax.$v = $.$spu.System.UriParser.FileUri;
                        i += 2;
                        while((i >>> 0) < (uriString.length >>> 0) && ($.$$.System.String.get_Chars.call(uriString, i) === /*/*/ 47) || ($.$$.System.String.get_Chars.call(uriString, i) === /*\\*/ 92))
                        {
                            i++;
                        }
                        return i;
                    }
                    err.$v = 1/*ParsingError.BadFormat*/;
                    return 0;
                }
                if (colonOffset < 0)
                {
                    err.$v = 1/*ParsingError.BadFormat*/;
                    return 0;
                }
                syntax.$v = $.$spu.System.Uri.CheckSchemeSyntax($.$$.System.MemoryExtensions.AsSpan$1(uriString, i, colonOffset), err);
                if (syntax.$v === null)
                {
                    return 0;
                }
                return ((((i + colonOffset) | 0) + 1) | 0);
            }
            static /*UriParser? */ CheckSchemeSyntax(/*ReadOnlySpan<char>*/ scheme, /*ref ParsingError*/ error)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(error.$v === 0/*ParsingError.None*/, "error == ParsingError.None");
                let $switch1 = scheme.Length;
                switch($switch1)
                {
                    case 2:
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("ws"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.WsUri;
                    }
                    break;
                    case 3:
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("wss"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.WssUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("ftp"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.FtpUri;
                    }
                    break;
                    case 4:
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("http"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.HttpUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("file"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.FileUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("uuid"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.UuidUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("nntp"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.NntpUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("ldap"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.LdapUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("news"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.NewsUri;
                    }
                    break;
                    case 5:
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("https"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.HttpsUri;
                    }
                    break;
                    case 6:
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("mailto"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.MailToUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("gopher"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.GopherUri;
                    }
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("telnet"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.TelnetUri;
                    }
                    break;
                    case 7:
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("net.tcp"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.NetTcpUri;
                    }
                    break;
                    case 8:
                    if ($.$$.System.MemoryExtensions.Equals$2(scheme, $.$$.System.String.op_Implicit("net.pipe"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spu.System.UriParser.NetPipeUri;
                    }
                    break;
                }
                if (scheme.Length === 0 || !$.$$.System.Char.IsAsciiLetter(scheme.get_Item(0).$v) || $.$$.System.MemoryExtensions.ContainsAnyExcept($.$$.System.Char, scheme, $.$spu.System.Uri.s_schemeChars))
                {
                    error.$v = 2/*ParsingError.BadScheme*/;
                    return null;
                }
                if (scheme.Length > 1024/*SchemeLengthLimit*/)
                {
                    error.$v = 6/*ParsingError.SchemeLimit*/;
                    return null;
                }
                return $.$spu.System.UriParser.FindOrFetchAsUnknownV1Syntax($.$spu.System.UriHelper.SpanToLowerInvariantString(scheme));
            }
            /*int */ CheckAuthorityHelper(/*char**/ pString, /*int*/ idx, /*int*/ length, /*ref ParsingError*/ err, /*ref Flags*/ flags, /*UriParser*/ syntax, /*ref string?*/ newHost)
            {
                $.$$.System.Diagnostics.Debug.Assert$2((this._flags & 144115188075855872n) === 0n || (!this._syntax.IsSimple && $.$$.System.Threading.Monitor.IsEntered(this._info)), "(_flags & Flags.Debug_LeftConstructor) == 0 || (!_syntax.IsSimple && Monitor.IsEntered(_info))");
                /*int*/ let end = length;
                /*char*/ let ch;
                /*int*/ let startInput = idx;
                /*int*/ let start = idx;
                newHost.$v = null;
                /*bool*/ let hasUnicode = ((flags.$v & 562949953421312n) !== 0n);
                /*UriSyntaxFlags*/ let syntaxFlags = syntax.Flags;
                $.$$.System.Diagnostics.Debug.Assert$2((this._flags & 137438953472n) === 0n && (this._flags & 30064771072n) === 0n, "(_flags & Flags.HasUserInfo) == 0 && (_flags & Flags.HostTypeMask) == 0");
                if (hasUnicode)
                {
                    newHost.$v = $.$$.System.String.Substring.call(this._originalUnicodeString, 0, startInput);
                }
                if (idx === length || ((ch = pString.GetAt(idx)) === /*/*/ 47 || (ch === /*\\*/ 92 && $.$spu.System.Uri.StaticIsFile(syntax)) || ch === /*#*/ 35 || ch === /*?*/ 63))
                {
                    if (syntax.InFact(128/*UriSyntaxFlags.AllowEmptyHost*/))
                    {
                        flags.$v &= ~17592186044416n;
                        if ($.$spu.System.Uri.StaticInFact(flags.$v, 35184372088832n))
                        {
                            err.$v = 8/*ParsingError.BadHostName*/;
                        }
                        else 
                        {
                            flags.$v |= 21474836480n;
                        }
                    }
                    else 
                    {
                        err.$v = 8/*ParsingError.BadHostName*/;
                    }
                    return idx;
                }
                if ((syntaxFlags & 4/*UriSyntaxFlags.MayHaveUserInfo*/) !== 0)
                {
                    for(; start < end; ++start)
                    {
                        if (start === ((end - 1) | 0) || pString.GetAt(start) === /*?*/ 63 || pString.GetAt(start) === /*#*/ 35 || pString.GetAt(start) === /*\\*/ 92 || pString.GetAt(start) === /*/*/ 47)
                        {
                            start = idx;
                            break;
                        }
                        else if (pString.GetAt(start) === /*@*/ 64)
                        {
                            flags.$v |= 137438953472n;
                            if (hasUnicode)
                            {
                                newHost.$v += $.$spu.System.IriHelper.EscapeUnescapeIri(pString, startInput, ((start + 1) | 0), 2/*UriComponents.UserInfo*/);
                            }
                            ++start;
                            ch = pString.GetAt(start);
                            break;
                        }
                    }
                }
                /*int*/ let domainNameLength;
                if (ch === /*[*/ 91 && syntax.InFact(2048/*UriSyntaxFlags.AllowIPv6Host*/) && $.$spu.System.Net.IPv6AddressHelper.IsValid(pString, ((start + 1) | 0), $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32)))
                {
                    flags.$v |= 4294967296n;
                    if (hasUnicode)
                    {
                        newHost.$v = $.$$.System.String.Concat$8($.$$.System.String.op_Implicit(newHost.$v), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(start), ((end - start) | 0)));
                    }
                }
                else if ($.$$.System.Char.IsAsciiDigit(ch) && syntax.InFact(1024/*UriSyntaxFlags.AllowIPv4Host*/) && $.$spu.System.Net.IPv4AddressHelper.IsValid($.$$.System.Char, pString, start, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32), false, $.$spu.System.Uri.StaticNotAny(flags.$v, 35184372088832n), syntax.InFact(65536/*UriSyntaxFlags.V1_UnknownUri*/)))
                {
                    flags.$v |= 8589934592n;
                    if (hasUnicode)
                    {
                        newHost.$v = $.$$.System.String.Concat$8($.$$.System.String.op_Implicit(newHost.$v), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(start), ((end - start) | 0)));
                    }
                }
                else if (((syntaxFlags & 512/*UriSyntaxFlags.AllowDnsHost*/) !== 0) && !$.$spu.System.Uri.IriParsingStatic(syntax) && $.$spu.System.DomainNameHelper.IsValid(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(start), ((end - start) | 0)), false, $.$spu.System.Uri.StaticNotAny(flags.$v, 35184372088832n), $.$ref(() => domainNameLength, ($v) => domainNameLength = $v, $.$$.System.Int32)))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!hasUnicode, "!hasUnicode");
                    end = ((start + domainNameLength) | 0);
                    flags.$v |= 12884901888n;
                    if (!$.$$.System.MemoryExtensions.ContainsAnyInRange($.$$.System.Char, new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(start), domainNameLength), /*A*/ 65, /*Z*/ 90))
                    {
                        flags.$v |= 2199023255552n;
                    }
                }
                else if (((syntaxFlags & 512/*UriSyntaxFlags.AllowDnsHost*/) !== 0) && (hasUnicode || syntax.InFact(67108864/*UriSyntaxFlags.AllowIdn*/)) && $.$spu.System.DomainNameHelper.IsValid(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(start), ((end - start) | 0)), true, $.$spu.System.Uri.StaticNotAny(flags.$v, 35184372088832n), $.$ref(() => domainNameLength, ($v) => domainNameLength = $v, $.$$.System.Int32)))
                {
                    end = ((start + domainNameLength) | 0);
                    $.$spu.System.Uri.CheckAuthorityHelperHandleDnsIri(pString, start, end, hasUnicode, flags, newHost, err);
                }
                else if ((syntaxFlags & 256/*UriSyntaxFlags.AllowUncHost*/) !== 0)
                {
                    if ($.$spu.System.UncNameHelper.IsValid(pString, start, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32), $.$spu.System.Uri.StaticNotAny(flags.$v, 35184372088832n)))
                    {
                        if (((end - start) | 0) <= 256/*UncNameHelper.MaximumInternetNameLength*/)
                        {
                            flags.$v |= 17179869184n;
                            if (hasUnicode)
                            {
                                newHost.$v = $.$$.System.String.Concat$8($.$$.System.String.op_Implicit(newHost.$v), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(start), ((end - start) | 0)));
                            }
                        }
                    }
                }
                if (end < length && pString.GetAt(end) === /*\\*/ 92 && (flags.$v & 30064771072n) !== 0n && !$.$spu.System.Uri.StaticIsFile(syntax))
                {
                    if (syntax.InFact(65536/*UriSyntaxFlags.V1_UnknownUri*/))
                    {
                        err.$v = 8/*ParsingError.BadHostName*/;
                        flags.$v |= 30064771072n;
                        return end;
                    }
                    flags.$v &= ~30064771072n;
                }
                else if (end < length && pString.GetAt(end) === /*:*/ 58)
                {
                    if (syntax.InFact(8/*UriSyntaxFlags.MayHavePort*/))
                    {
                        /*int*/ let port = 0;
                        /*int*/ let startPort = end;
                        for(idx = ((end + 1) | 0); idx < length; ++idx)
                        {
                            /*int*/ let val = pString.GetAt(idx) - /*0*/ 48;
                            if ((val >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                            {
                                if ((port = (((((port * 10) | 0) + val) | 0))) > 65535)
                                {
                                    break;
                                }
                            }
                            else if (val === (/*/*/ 47 - /*0*/ 48) || val === (/*?*/ 63 - /*0*/ 48) || val === (/*#*/ 35 - /*0*/ 48))
                            {
                                break;
                            }
                            else 
                            {
                                if (syntax.InFact(4096/*UriSyntaxFlags.AllowAnyOtherHost*/) && syntax.NotAny(65536/*UriSyntaxFlags.V1_UnknownUri*/))
                                {
                                    flags.$v &= ~30064771072n;
                                    break;
                                }
                                else 
                                {
                                    err.$v = 10/*ParsingError.BadPort*/;
                                    return idx;
                                }
                            }
                        }
                        if (port > 65535)
                        {
                            if (syntax.InFact(4096/*UriSyntaxFlags.AllowAnyOtherHost*/))
                            {
                                flags.$v &= ~30064771072n;
                            }
                            else 
                            {
                                err.$v = 10/*ParsingError.BadPort*/;
                                return idx;
                            }
                        }
                        if (hasUnicode)
                        {
                            newHost.$v = $.$$.System.String.Concat$8($.$$.System.String.op_Implicit(newHost.$v), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(startPort), ((idx - startPort) | 0)));
                        }
                    }
                    else 
                    {
                        flags.$v &= ~30064771072n;
                    }
                }
                if ((flags.$v & 30064771072n) === 0n)
                {
                    flags.$v &= ~137438953472n;
                    if (syntax.InFact(4096/*UriSyntaxFlags.AllowAnyOtherHost*/))
                    {
                        flags.$v |= 21474836480n;
                        for(end = idx; end < length; ++end)
                        {
                            if (pString.GetAt(end) === /*/*/ 47 || (pString.GetAt(end) === /*?*/ 63 || pString.GetAt(end) === /*#*/ 35))
                            {
                                break;
                            }
                        }
                        if (hasUnicode)
                        {
                            try
                            {
                                newHost.$v = $.$spu.System.UriHelper.NormalizeAndConcat(newHost.$v, new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(startInput), ((end - startInput) | 0)));
                            }
                            catch($e)
                            {
                                err.$v = 8/*ParsingError.BadHostName*/;
                            }
                        }
                    }
                    else 
                    {
                        if (syntax.InFact(65536/*UriSyntaxFlags.V1_UnknownUri*/))
                        {
                            /*bool*/ let dotFound = false;
                            /*int*/ let startOtherHost = idx;
                            for(end = idx; end < length; ++end)
                            {
                                if (dotFound && (pString.GetAt(end) === /*/*/ 47 || pString.GetAt(end) === /*?*/ 63 || pString.GetAt(end) === /*#*/ 35))
                                {
                                    break;
                                }
                                else if (end < (((idx + 2) | 0)) && pString.GetAt(end) === /*.*/ 46)
                                {
                                    dotFound = true;
                                }
                                else 
                                {
                                    err.$v = 8/*ParsingError.BadHostName*/;
                                    flags.$v |= 30064771072n;
                                    return idx;
                                }
                            }
                            flags.$v |= 21474836480n;
                            if (hasUnicode)
                            {
                                try
                                {
                                    newHost.$v = $.$spu.System.UriHelper.NormalizeAndConcat(newHost.$v, new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(startOtherHost), ((end - startOtherHost) | 0)));
                                }
                                catch($e)
                                {
                                    err.$v = 1/*ParsingError.BadFormat*/;
                                    return idx;
                                }
                            }
                        }
                        else if (syntax.InFact(1/*UriSyntaxFlags.MustHaveAuthority*/) || (syntax.InFact(16384/*UriSyntaxFlags.MailToLikeUri*/)))
                        {
                            err.$v = 8/*ParsingError.BadHostName*/;
                            flags.$v |= 30064771072n;
                            return idx;
                        }
                    }
                }
                return end;
            }
            static /*void */ CheckAuthorityHelperHandleDnsIri(/*char**/ pString, /*int*/ start, /*int*/ end, /*bool*/ hasUnicode, /*ref Flags*/ flags, /*ref string?*/ newHost, /*ref ParsingError*/ err)
            {
                flags.$v |= 12884901888n;
                if (hasUnicode)
                {
                    /*ReadOnlySpan<char>*/ let host = new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(pString.Add(start), ((end - start) | 0));
                    /*string?*/ let stripped;
                    if ($.$spu.System.UriHelper.StripBidiControlCharacters$1(host, $.$ref(() => stripped, ($v) => stripped = $v, $.$$.System.String)))
                    {
                        host = $.$$.System.String.op_Implicit(stripped);
                    }
                    try
                    {
                        newHost.$v = $.$spu.System.UriHelper.NormalizeAndConcat(newHost.$v, host);
                    }
                    catch($e)
                    {
                        err.$v = 8/*ParsingError.BadHostName*/;
                    }
                }
            }
            /*char*/ static c_DummyChar = /*\uFFFF*/ 65535;
            /*char*/ static c_EOL = /*\uFFFE*/ 65534;
            static $_Check;
            static get Check()
            {
                let $cls = $.$spu.System.Uri;
                return $cls.$_Check ??= $asm.$nstr("$spu.System.Uri.Check", ($self) => class Check extends $.$$.System.Enum
                {
                    static None = 0;
                    static EscapedCanonical = 1;
                    static DisplayCanonical = 2;
                    static DotSlashAttn = 4;
                    static DotSlashEscaped = 128;
                    static BackslashInPath = 16;
                    static ReservedFound = 32;
                    static NotIriCanonical = 64;
                    static FoundNonAscii = 8;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "EscapedCanonical": 1n,
                            "DisplayCanonical": 2n,
                            "DotSlashAttn": 4n,
                            "DotSlashEscaped": 128n,
                            "BackslashInPath": 16n,
                            "ReservedFound": 32n,
                            "NotIriCanonical": 64n,
                            "FoundNonAscii": 8n
                        };
                    }
                    static $h = 1811756;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1811756,"n":"None","d":1811756,"h":4296779052,"f":4194337},{"t":1811756,"n":"EscapedCanonical","d":1811756,"h":8591746348,"f":4194337},{"t":1811756,"n":"DisplayCanonical","d":1811756,"h":12886713644,"f":4194337},{"t":1811756,"n":"DotSlashAttn","d":1811756,"h":17181680940,"f":4194337},{"t":1811756,"n":"DotSlashEscaped","d":1811756,"h":21476648236,"f":4194337},{"t":1811756,"n":"BackslashInPath","d":1811756,"h":25771615532,"f":4194337},{"t":1811756,"n":"ReservedFound","d":1811756,"h":30066582828,"f":4194337},{"t":1811756,"n":"NotIriCanonical","d":1811756,"h":34361550124,"f":4194337},{"t":1811756,"n":"FoundNonAscii","d":1811756,"h":38656517420,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1811756,"h":42951484716,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":1746220,"h":1811756,"a":[{"t":47710209,"c":4342677505}]}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Uri.Check`; }
                }, $cls, ($v) => $cls.$_Check = $v);
            }
            /*Check */ CheckCanonical(/*char**/ str, /*ref int*/ idx, /*int*/ end, /*char*/ delim)
            {
                /*Check*/ let res = 0/*Check.None*/;
                /*bool*/ let needsEscaping = false;
                /*bool*/ let foundEscaping = false;
                /*bool*/ let iriParsing = this.IriParsing;
                /*char*/ let c;
                /*int*/ let i = idx.$v;
                for(; i < end; ++i)
                {
                    c = str.GetAt(i);
                    if (c <= /*\u001F*/ 31 || (c >= /*\u007F*/ 127 && c <= /*\u009F*/ 159))
                    {
                        needsEscaping = true;
                        foundEscaping = true;
                        res |= 32/*Check.ReservedFound*/;
                    }
                    else if (c > /*~*/ 126)
                    {
                        if (iriParsing)
                        {
                            /*bool*/ let valid = false;
                            res |= 8/*Check.FoundNonAscii*/;
                            if ($.$$.System.Char.IsHighSurrogate(c))
                            {
                                if ((((i + 1) | 0)) < end)
                                {
                                    valid = $.$spu.System.IriHelper.CheckIriUnicodeRange$1(c, str.GetAt(((i + 1) | 0)), $.$discardRef(), true);
                                }
                            }
                            else 
                            {
                                valid = $.$spu.System.IriHelper.CheckIriUnicodeRange(c, true);
                            }
                            if (!valid)
                            {
                                res |= 64/*Check.NotIriCanonical*/;
                            }
                        }
                        if (!needsEscaping)
                        {
                            needsEscaping = true;
                        }
                    }
                    else if (c === delim)
                    {
                        break;
                    }
                    else if (delim === /*?*/ 63 && c === /*#*/ 35 && (this._syntax !== null && this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/)))
                    {
                        break;
                    }
                    else if (c === /*?*/ 63)
                    {
                        if (this.IsImplicitFile || (this._syntax !== null && !this._syntax.InFact(32/*UriSyntaxFlags.MayHaveQuery*/) && delim !== /*\uFFFE*/ 65534))
                        {
                            res |= 32/*Check.ReservedFound*/;
                            foundEscaping = true;
                            needsEscaping = true;
                        }
                    }
                    else if (c === /*#*/ 35)
                    {
                        needsEscaping = true;
                        if (this.IsImplicitFile || (this._syntax !== null && !this._syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/)))
                        {
                            res |= 32/*Check.ReservedFound*/;
                            foundEscaping = true;
                        }
                    }
                    else if (c === /*/*/ 47 || c === /*\\*/ 92)
                    {
                        if ((res & 16/*Check.BackslashInPath*/) === 0 && c === /*\\*/ 92)
                        {
                            res |= 16/*Check.BackslashInPath*/;
                        }
                        if ((res & 4/*Check.DotSlashAttn*/) === 0 && ((i + 1) | 0) !== end && (str.GetAt(((i + 1) | 0)) === /*/*/ 47 || str.GetAt(((i + 1) | 0)) === /*\\*/ 92))
                        {
                            res |= 4/*Check.DotSlashAttn*/;
                        }
                    }
                    else if (c === /*.*/ 46)
                    {
                        if ((res & 4/*Check.DotSlashAttn*/) === 0 && ((i + 1) | 0) === end || str.GetAt(((i + 1) | 0)) === /*.*/ 46 || str.GetAt(((i + 1) | 0)) === /*/*/ 47 || str.GetAt(((i + 1) | 0)) === /*\\*/ 92 || str.GetAt(((i + 1) | 0)) === /*?*/ 63 || str.GetAt(((i + 1) | 0)) === /*#*/ 35)
                        {
                            res |= 4/*Check.DotSlashAttn*/;
                        }
                    }
                    else if ((c <= /*\"*/ 34 && c !== /*!*/ 33) || (c >= /*[*/ 91 && c <= /*^*/ 94) || c === /*>*/ 62 || c === /*<*/ 60 || c === /*`*/ 96)
                    {
                        if (!needsEscaping)
                        {
                            needsEscaping = true;
                        }
                        if ((this._flags & 562949953421312n) !== 0n)
                        {
                            res |= 64/*Check.NotIriCanonical*/;
                        }
                    }
                    else if (c >= /*{*/ 123 && c <= /*}*/ 125)
                    {
                        needsEscaping = true;
                    }
                    else if (c === /*%*/ 37)
                    {
                        if (!foundEscaping)
                        {
                            foundEscaping = true;
                        }
                        if (((i + 2) | 0) < end && (c = $.$spu.System.UriHelper.DecodeHexChars(str.GetAt(((i + 1) | 0)), str.GetAt(((i + 2) | 0)))) !== /*\uFFFF*/ 65535)
                        {
                            if (c === /*.*/ 46 || c === /*/*/ 47 || c === /*\\*/ 92)
                            {
                                res |= 128/*Check.DotSlashEscaped*/;
                            }
                            i += 2;
                            continue;
                        }
                        if (!needsEscaping)
                        {
                            needsEscaping = true;
                        }
                    }
                }
                if (foundEscaping)
                {
                    if (!needsEscaping)
                    {
                        res |= 1/*Check.EscapedCanonical*/;
                    }
                }
                else 
                {
                    res |= 2/*Check.DisplayCanonical*/;
                    if (!needsEscaping)
                    {
                        res |= 1/*Check.EscapedCanonical*/;
                    }
                }
                idx.$v = i;
                return res;
            }
            /*void */ GetCanonicalPath(/*ref ValueStringBuilder*/ dest, /*UriFormat*/ formatAs)
            {
                if (this.InFact(16384n))
                {
                    dest.$v.Append$1(/*/*/ 47);
                }
                if (this._info.Offset.Path === this._info.Offset.Query)
                {
                    return;
                }
                /*int*/ let start = dest.$v.Length;
                /*int*/ let dosPathIdx = this.SecuredPathIndex;
                if (formatAs === 1/*UriFormat.UriEscaped*/)
                {
                    if (this.InFact(8192n))
                    {
                        dest.$v.Append$2($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Path, ((this._info.Offset.Query - this._info.Offset.Path) | 0)));
                        if (this._syntax.InFact(33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/) && this.InFact(16n) && !this.IsImplicitFile)
                        {
                            /*fixed*/ 
                            {
                                /*char**/ let pdest = dest.$v.GetPinnableReference();
                                /*int*/ let end = dest.$v.Length;
                                $.$spu.System.Uri.UnescapeOnly(pdest, start, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32), /*.*/ 46, /*/*/ 47, this._syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/) ? /*\\*/ 92 : /*\uFFFF*/ 65535);
                                dest.$v.Length = end;
                            }
                        }
                    }
                    else 
                    {
                        if (this.InFact(1024n) && this.NotAny(34359738368n))
                        {
                            /*ReadOnlySpan<char>*/ let str = $.$$.System.String.op_Implicit(this._string);
                            if (dosPathIdx !== 0 && str.get_Item(((((dosPathIdx + this._info.Offset.Path) | 0) - 1) | 0)).$v === /*|*/ 124)
                            {
                                /*char[]*/ let chars = str.ToArray();
                                $.$$.System.Array.$WriteT1.call(chars, /*:*/ 58, ((((dosPathIdx + this._info.Offset.Path) | 0) - 1) | 0));
                                str = $.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1(chars);
                            }
                            $.$spu.System.UriHelper.EscapeString$1(str.Slice(this._info.Offset.Path, ((this._info.Offset.Query - this._info.Offset.Path) | 0)), dest, !this.IsImplicitFile, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
                        }
                        else 
                        {
                            dest.$v.Append$2($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Path, ((this._info.Offset.Query - this._info.Offset.Path) | 0)));
                        }
                    }
                    if (!$.$$.System.OperatingSystem.IsWindows() && this.InFact(32768n) && this._syntax.NotAny(4194304/*UriSyntaxFlags.ConvertPathSlashes*/) && this._syntax.InFact(8192/*UriSyntaxFlags.FileLikeUri*/) && !this.IsImplicitFile)
                    {
                        /*var*/ let copy = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                        copy.Append$2(dest.$v.AsSpan$2(start, ((dest.$v.Length - start) | 0)));
                        dest.$v.Length = start;
                        $.$spu.System.UriHelper.EscapeString$1(copy.AsSpan(), dest, true, $.$spu.System.UriHelper.UnreservedReserved);
                        start = dest.$v.Length;
                        copy.Dispose();
                    }
                }
                else 
                {
                    dest.$v.Append$2($.$$.System.MemoryExtensions.AsSpan$1(this._string, this._info.Offset.Path, ((this._info.Offset.Query - this._info.Offset.Path) | 0)));
                    if (this.InFact(8192n))
                    {
                        if (this._syntax.InFact(33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/) && this.InFact(16n) && !this.IsImplicitFile)
                        {
                            /*fixed*/ 
                            {
                                /*char**/ let pdest = dest.$v.GetPinnableReference();
                                /*int*/ let end = dest.$v.Length;
                                $.$spu.System.Uri.UnescapeOnly(pdest, start, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32), /*.*/ 46, /*/*/ 47, this._syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/) ? /*\\*/ 92 : /*\uFFFF*/ 65535);
                                dest.$v.Length = end;
                            }
                        }
                    }
                }
                /*int*/ let offset = ((start + dosPathIdx) | 0);
                if (dosPathIdx !== 0 && dest.$v.get_Item(((offset - 1) | 0)).$v === /*|*/ 124)
                {
                    dest.$v.get_Item(((offset - 1) | 0)).$v = /*:*/ 58;
                }
                if (this.InFact(8192n) && ((dest.$v.Length - offset) | 0) > 0)
                {
                    dest.$v.Length = ((offset + $.$spu.System.UriHelper.Compress(dest.$v.RawChars.Slice(offset, ((dest.$v.Length - offset) | 0)), this._syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/), this._syntax.InFact(16777216/*UriSyntaxFlags.CanonicalizeAsFilePath*/))) | 0);
                    if (dest.$v.get_Item(start).$v === /*\\*/ 92)
                    {
                        dest.$v.get_Item(start).$v = /*/*/ 47;
                    }
                    if (formatAs === 1/*UriFormat.UriEscaped*/ && this.NotAny(34359738368n) && this.InFact(1024n))
                    {
                        /*var*/ let copy = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                        copy.Append$2(dest.$v.AsSpan$2(start, ((dest.$v.Length - start) | 0)));
                        dest.$v.Length = start;
                        $.$spu.System.UriHelper.EscapeString$1(copy.AsSpan(), dest, !this.IsImplicitFile, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
                        start = dest.$v.Length;
                        copy.Dispose();
                    }
                }
                if (formatAs !== 1/*UriFormat.UriEscaped*/ && this.InFact(16n))
                {
                    /*UnescapeMode*/ let mode;
                    switch(formatAs)
                    {
                        case 32767/*V1ToStringUnescape*/:
                        mode = (this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/) | 4/*UnescapeMode.V1ToStringFlag*/;
                        if (this.IsImplicitFile)
                        {
                            mode &= ~2/*UnescapeMode.Unescape*/;
                        }
                        break;
                        case 2/*UriFormat.Unescaped*/:
                        mode = this.IsImplicitFile ? 0/*UnescapeMode.CopyOnly*/ : 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/;
                        break;
                        default:
                        mode = this.InFact(34359738368n) ? 2/*UnescapeMode.Unescape*/ : 3/*UnescapeMode.EscapeUnescape*/;
                        if (this.IsImplicitFile)
                        {
                            mode &= ~2/*UnescapeMode.Unescape*/;
                        }
                        break;
                    }
                    if (mode !== 0/*UnescapeMode.CopyOnly*/)
                    {
                        /*var*/ let copy = new $.$spu.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512/*StackallocThreshold*/, null));
                        copy.Append$2(dest.$v.AsSpan$2(start, ((dest.$v.Length - start) | 0)));
                        dest.$v.Length = start;
                        /*fixed*/ 
                        {
                            /*char**/ let pCopy = copy.GetPinnableReference();
                            $.$spu.System.UriHelper.UnescapeString$1(pCopy, 0, copy.Length, dest, /*?*/ 63, /*#*/ 35, /*\uFFFF*/ 65535, mode, this._syntax, false);
                        }
                        copy.Dispose();
                    }
                }
            }
            static /*void */ UnescapeOnly(/*char**/ pch, /*int*/ start, /*ref int*/ end, /*char*/ ch1, /*char*/ ch2, /*char*/ ch3)
            {
                /*char**/ let pend;
                /*char**/ let pnew;
                /*char*/ let ch;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            if (((end.$v - start) | 0) < 3)
                            {
                                return;
                            }
                            pend = pch.Add(end.$v).Add(-2);
                            pch = pch.Add(start);
                            pnew = null;
                        }
                        case 1: /*over*/
                        if ($.$$.NetJs.RefOrPointer.Compare(pch, pend) >= 0)
                        {
                            $gotoJumpState1 = 3; /*goto done*/
                            continue $gotoJumpStart1;
                        }
                        if ((() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v !== /*%*/ 37)
                        {
                            $gotoJumpState1 = 1; /*goto over*/
                            continue $gotoJumpStart1;
                        }
                        ch = $.$spu.System.UriHelper.DecodeHexChars((() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v, (() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v);
                        if (!(ch === ch1 || ch === ch2 || ch === ch3))
                        {
                            $gotoJumpState1 = 1; /*goto over*/
                            continue $gotoJumpStart1;
                        }
                        pnew = pch.Add(-2);
                        (pnew.Add(-1)).$v = ch;
                        case 2: /*over_new*/
                        if ($.$$.NetJs.RefOrPointer.Compare(pch, pend) >= 0)
                        {
                            $gotoJumpState1 = 3; /*goto done*/
                            continue $gotoJumpStart1;
                        }
                        if (((() =>
                        {
                            var $old = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $old;
                        })().$v = (() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v) !== /*%*/ 37)
                        {
                            $gotoJumpState1 = 2; /*goto over_new*/
                            continue $gotoJumpStart1;
                        }
                        ch = $.$spu.System.UriHelper.DecodeHexChars(((() =>
                        {
                            var $old = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $old;
                        })().$v = (() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v), ((() =>
                        {
                            var $old = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $old;
                        })().$v = (() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v));
                        if (!(ch === ch1 || ch === ch2 || ch === ch3))
                        {
                            $gotoJumpState1 = 2; /*goto over_new*/
                            continue $gotoJumpStart1;
                        }
                        pnew = pnew.Add(-2);
                        (pnew.Add(-1)).$v = ch;
                        $gotoJumpState1 = 2; /*goto over_new*/
                        continue $gotoJumpStart1;
                        case 3: /*done*/
                        pend = pend.Add(2);
                        if (pnew === null)
                        {
                            return;
                        }
                        if ($.$$.NetJs.RefOrPointer.Compare(pch, pend) == 0)
                        {
                            end.$v -= $.$cast((pch.Subtract(pnew)), $.$$.System.Int32);
                            return;
                        }
                        (() =>
                        {
                            var $old = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $old;
                        })().$v = (() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v;
                        if ($.$$.NetJs.RefOrPointer.Compare(pch, pend) == 0)
                        {
                            end.$v -= $.$cast((pch.Subtract(pnew)), $.$$.System.Int32);
                            return;
                        }
                        (() =>
                        {
                            var $old = pnew.Clone();
                            pnew = pnew.Add(1);
                            return $old;
                        })().$v = (() =>
                        {
                            var $old = pch.Clone();
                            pch = pch.Add(1);
                            return $old;
                        })().$v;
                        end.$v -= $.$cast((pch.Subtract(pnew)), $.$$.System.Int32);
                    }
                    break;
                }
            }
            static /*void */ Compress(/*char[]*/ dest, /*int*/ start, /*ref int*/ destLength, /*UriParser*/ syntax)
            {
                destLength.$v = ((start + $.$spu.System.UriHelper.Compress($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, dest, start, ((destLength.$v - start) | 0)), syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/), syntax.InFact(16777216/*UriSyntaxFlags.CanonicalizeAsFilePath*/))) | 0);
            }
            static /*string */ CombineUri(/*Uri*/ basePart, /*string*/ relativePart, /*UriFormat*/ uriFormat)
            {
                /*char*/ let c1 = $.$$.System.String.get_Chars.call(relativePart, 0);
                if (basePart.IsDosPath && (c1 === /*/*/ 47 || c1 === /*\\*/ 92) && (relativePart.length === 1 || ($.$$.System.String.get_Chars.call(relativePart, 1) !== /*/*/ 47 && $.$$.System.String.get_Chars.call(relativePart, 1) !== /*\\*/ 92)))
                {
                    /*int*/ let idx = $.$$.System.String.IndexOf$3.call(basePart.OriginalString, /*:*/ 58);
                    if (basePart.IsImplicitFile)
                    {
                        return $.$$.System.String.Concat$8($.$$.System.MemoryExtensions.AsSpan$1(basePart.OriginalString, 0, ((idx + 1) | 0)), $.$$.System.String.op_Implicit(relativePart));
                    }
                    idx = $.$$.System.String.IndexOf$1.call(basePart.OriginalString, /*:*/ 58, ((idx + 1) | 0));
                    return $.$$.System.String.Concat$8($.$$.System.MemoryExtensions.AsSpan$1(basePart.OriginalString, 0, ((idx + 1) | 0)), $.$$.System.String.op_Implicit(relativePart));
                }
                if ($.$spu.System.Uri.StaticIsFile(basePart.Syntax))
                {
                    if (c1 === /*\\*/ 92 || c1 === /*/*/ 47)
                    {
                        if (relativePart.length >= 2 && ($.$$.System.String.get_Chars.call(relativePart, 1) === /*\\*/ 92 || $.$$.System.String.get_Chars.call(relativePart, 1) === /*/*/ 47))
                        {
                            return basePart.IsImplicitFile ? relativePart : "file:" + relativePart;
                        }
                        if (basePart.IsUnc)
                        {
                            /*ReadOnlySpan<char>*/ let share = $.$$.System.String.op_Implicit(basePart.GetParts(16/*UriComponents.Path*/ | 1073741824/*UriComponents.KeepDelimiter*/, 2/*UriFormat.Unescaped*/));
                            /*int*/ let i = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, share.Slice$1(1), /*/*/ 47);
                            if (i >= 0)
                            {
                                share = share.Slice(0, ((i + 1) | 0));
                            }
                            if (basePart.IsImplicitFile)
                            {
                                return $.$$.System.String.Concat$6($.$$.System.String.op_Implicit("\\\\"), $.$$.System.String.op_Implicit(basePart.GetParts(4/*UriComponents.Host*/, 2/*UriFormat.Unescaped*/)), share, $.$$.System.String.op_Implicit(relativePart));
                            }
                            return $.$$.System.String.Concat$6($.$$.System.String.op_Implicit("file://"), $.$$.System.String.op_Implicit(basePart.GetParts(4/*UriComponents.Host*/, uriFormat)), share, $.$$.System.String.op_Implicit(relativePart));
                        }
                        return "file://" + relativePart;
                    }
                }
                /*bool*/ let convBackSlashes = basePart.Syntax.InFact(4194304/*UriSyntaxFlags.ConvertPathSlashes*/);
                /*string?*/ let left;
                if (c1 === /*/*/ 47 || (c1 === /*\\*/ 92 && convBackSlashes))
                {
                    if (relativePart.length >= 2 && $.$$.System.String.get_Chars.call(relativePart, 1) === /*/*/ 47)
                    {
                        return basePart.Scheme + /*:*/ 58 + relativePart;
                    }
                    if (basePart.HostType === 4294967296n)
                    {
                        left = `${basePart.GetParts(1/*UriComponents.Scheme*/ | 2/*UriComponents.UserInfo*/, uriFormat)}[${basePart.DnsSafeHost}]${basePart.GetParts(1073741824/*UriComponents.KeepDelimiter*/ | 8/*UriComponents.Port*/, uriFormat)}`;
                    }
                    else 
                    {
                        left = basePart.GetParts(13/*UriComponents.SchemeAndServer*/ | 2/*UriComponents.UserInfo*/, uriFormat);
                    }
                    return convBackSlashes && c1 === /*\\*/ 92 ? $.$$.System.String.Concat$7($.$$.System.String.op_Implicit(left), $.$$.System.String.op_Implicit("/"), $.$$.System.MemoryExtensions.AsSpan$2(relativePart, 1)) : left + relativePart;
                }
                left = basePart.GetParts(16/*UriComponents.Path*/ | 1073741824/*UriComponents.KeepDelimiter*/, basePart.IsImplicitFile ? 2/*UriFormat.Unescaped*/ : uriFormat);
                /*int*/ let length = left.length;
                /*char[]*/ let path = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [((length + relativePart.length) | 0)], null);
                if (length > 0)
                {
                    $.$$.System.String.CopyTo.call(left, 0, path, 0, length);
                    while(length > 0)
                    {
                        if ($.$$.System.Array.$ReadT1.call(path, --length) === /*/*/ 47)
                        {
                            ++length;
                            break;
                        }
                    }
                }
                $.$$.System.String.CopyTo.call(relativePart, 0, path, length, relativePart.length);
                c1 = basePart.Syntax.InFact(32/*UriSyntaxFlags.MayHaveQuery*/) ? /*?*/ 63 : /*\uFFFF*/ 65535;
                /*char*/ let c2 = (!basePart.IsImplicitFile && basePart.Syntax.InFact(64/*UriSyntaxFlags.MayHaveFragment*/)) ? /*#*/ 35 : /*\uFFFF*/ 65535;
                /*ReadOnlySpan<char>*/ let extra = $.$$.System.String.op_Implicit($.$$.System.String.Empty);
                if (!(c1 === /*\uFFFF*/ 65535 && c2 === /*\uFFFF*/ 65535))
                {
                    /*int*/ let i = 0;
                    for(; i < relativePart.length; ++i)
                    {
                        if ($.$$.System.Array.$ReadT1.call(path, ((length + i) | 0)) === c1 || $.$$.System.Array.$ReadT1.call(path, ((length + i) | 0)) === c2)
                        {
                            break;
                        }
                    }
                    if (i === 0)
                    {
                        extra = $.$$.System.String.op_Implicit(relativePart);
                    }
                    else if (i < relativePart.length)
                    {
                        extra = $.$$.System.MemoryExtensions.AsSpan$2(relativePart, i);
                    }
                    length += i;
                }
                else 
                {
                    length += relativePart.length;
                }
                if (basePart.HostType === 4294967296n)
                {
                    if (basePart.IsImplicitFile)
                    {
                        left = "\\\\[" + basePart.DnsSafeHost + /*]*/ 93;
                    }
                    else 
                    {
                        left = basePart.GetParts(1/*UriComponents.Scheme*/ | 2/*UriComponents.UserInfo*/, uriFormat) + /*[*/ 91 + basePart.DnsSafeHost + /*]*/ 93 + basePart.GetParts(1073741824/*UriComponents.KeepDelimiter*/ | 8/*UriComponents.Port*/, uriFormat);
                    }
                }
                else 
                {
                    if (basePart.IsImplicitFile)
                    {
                        if (basePart.IsDosPath)
                        {
                            $.$spu.System.Uri.Compress(path, 3, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32), basePart.Syntax);
                            return $.$$.System.String.Concat$8($.$$.System.Span$$($.$$.System.Char).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, path, 1, ((length - 1) | 0))), extra);
                        }
                        else if (!$.$$.System.OperatingSystem.IsWindows() && basePart.IsUnixPath)
                        {
                            left = basePart.GetParts(4/*UriComponents.Host*/, 2/*UriFormat.Unescaped*/);
                        }
                        else 
                        {
                            left = "\\\\" + basePart.GetParts(4/*UriComponents.Host*/, 2/*UriFormat.Unescaped*/);
                        }
                    }
                    else 
                    {
                        left = basePart.GetParts(13/*UriComponents.SchemeAndServer*/ | 2/*UriComponents.UserInfo*/, uriFormat);
                    }
                }
                $.$spu.System.Uri.Compress(path, basePart.SecuredPathIndex, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32), basePart.Syntax);
                return $.$$.System.String.Concat$7($.$$.System.String.op_Implicit(left), $.$$.System.Span$$($.$$.System.Char).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, path, 0, length)), extra);
            }
            static /*string */ PathDifference(/*string*/ path1, /*string*/ path2, /*bool*/ compareCase)
            {
                /*int*/ let i;
                /*int*/ let si = -1;
                for(i = 0; (i < path1.length) && (i < path2.length); ++i)
                {
                    if (($.$$.System.String.get_Chars.call(path1, i) !== $.$$.System.String.get_Chars.call(path2, i)) && (compareCase || ($.$$.System.Char.ToLowerInvariant($.$$.System.String.get_Chars.call(path1, i)) !== $.$$.System.Char.ToLowerInvariant($.$$.System.String.get_Chars.call(path2, i)))))
                    {
                        break;
                    }
                    else if ($.$$.System.String.get_Chars.call(path1, i) === /*/*/ 47)
                    {
                        si = i;
                    }
                }
                if (i === 0)
                {
                    return path2;
                }
                if ((i === path1.length) && (i === path2.length))
                {
                    return $.$$.System.String.Empty;
                }
                /*StringBuilder*/ let relPath = new $.$$.System.Text.StringBuilder().$ctor$1();
                for(; i < path1.length; ++i)
                {
                    if ($.$$.System.String.get_Chars.call(path1, i) === /*/*/ 47)
                    {
                        relPath.Append$19("../");
                    }
                }
                if (relPath.Length === 0 && ((path2.length - 1) | 0) === si)
                {
                    return "./";
                }
                return $.$$.System.Text.StringBuilder.ToString.call(relPath.Append$15($.$$.System.MemoryExtensions.AsSpan$2(path2, ((si + 1) | 0))));
            }
            /*string */ MakeRelative(/*Uri*/ toUri)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(toUri, "toUri");
                if (this.IsNotAbsoluteUri || toUri.IsNotAbsoluteUri)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spu.System.SR.net_uri_NotAbsolute);
                }
                if (($.$$.System.String.op_Equality(this.Scheme, toUri.Scheme)) && ($.$$.System.String.op_Equality(this.Host, toUri.Host)) && (this.Port === toUri.Port))
                {
                    return $.$spu.System.Uri.PathDifference(this.AbsolutePath, toUri.AbsolutePath, !this.IsUncOrDosPath);
                }
                return $.$spu.System.Uri.ToString.call(toUri);
            }
            /*void */ Canonicalize()
            {
            }
            /*void */ Parse()
            {
            }
            /*void */ Escape()
            {
            }
            /*string */ Unescape(/*string*/ path)
            {
                /*char[]*/ let dest = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [path.length], null);
                /*int*/ let count = 0;
                dest = $.$spu.System.UriHelper.UnescapeString$3(path, 0, path.length, dest, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32), /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, /*\uFFFF*/ 65535, 2/*UnescapeMode.Unescape*/ | 8/*UnescapeMode.UnescapeAll*/, null, false);
                return $.$$.System.String.Create$1(dest, 0, count);
            }
            static /*string */ EscapeString(/*string?*/ str)
            {
                return str === null ? $.$$.System.String.Empty : $.$spu.System.UriHelper.EscapeString$2(str, true, $.$spu.System.UriHelper.UnreservedReservedExceptQuestionMarkHash);
            }
            /*void */ CheckSecurity()
            {
            }
            /*bool */ IsReservedCharacter(/*char*/ character)
            {
                return (character === /*;*/ 59) || (character === /*/*/ 47) || (character === /*:*/ 58) || (character === /*@*/ 64) || (character === /*&*/ 38) || (character === /*=*/ 61) || (character === /*+*/ 43) || (character === /*$*/ 36) || (character === /*,*/ 44);
            }
            static /*bool */ IsExcludedCharacter(/*char*/ character)
            {
                return (character <= 32) || (character >= 127) || (character === /*<*/ 60) || (character === /*>*/ 62) || (character === /*#*/ 35) || (character === /*%*/ 37) || (character === /*\"*/ 34) || (character === /*{*/ 123) || (character === /*}*/ 125) || (character === /*|*/ 124) || (character === /*\\*/ 92) || (character === /*^*/ 94) || (character === /*[*/ 91) || (character === /*]*/ 93) || (character === /*`*/ 96);
            }
            /*bool */ IsBadFileSystemCharacter(/*char*/ character)
            {
                return (character < 32) || (character === /*;*/ 59) || (character === /*/*/ 47) || (character === /*?*/ 63) || (character === /*:*/ 58) || (character === /*&*/ 38) || (character === /*=*/ 61) || (character === /*,*/ 44) || (character === /***/ 42) || (character === /*<*/ 60) || (character === /*>*/ 62) || (character === /*\"*/ 34) || (character === /*|*/ 124) || (character === /*\\*/ 92) || (character === /*^*/ 94);
            }
            /*bool */ get HasAuthority()
            {
                return this.InFact(68719476736n);
            }
            //Generated interface implemetation for System.IEquatable<System.Uri>.Equals(System.Uri?)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._originalUnicodeString = null;
                this._syntax = null;
                this._info = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_asciiOtherThanPercent = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\u0008\t\n\u000B\u000C\r\u000E\u000F" + "\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001A\u001B\u001C\u001D\u001E\u001F" + " !\"#$" + "&'()*+,-./" + "0123456789:;<=>?" + "@ABCDEFGHIJKLMNO" + "PQRSTUVWXYZ[\\]^_" + "`abcdefghijklmno" + "pqrstuvwxyz{|}~\u007F"));
                }
                {
                    this.UriSchemeFile = $.$spu.System.UriParser.FileUri.SchemeName;
                }
                {
                    this.UriSchemeFtp = $.$spu.System.UriParser.FtpUri.SchemeName;
                }
                {
                    this.UriSchemeSftp = "sftp";
                }
                {
                    this.UriSchemeFtps = "ftps";
                }
                {
                    this.UriSchemeGopher = $.$spu.System.UriParser.GopherUri.SchemeName;
                }
                {
                    this.UriSchemeHttp = $.$spu.System.UriParser.HttpUri.SchemeName;
                }
                {
                    this.UriSchemeHttps = $.$spu.System.UriParser.HttpsUri.SchemeName;
                }
                {
                    this.UriSchemeWs = $.$spu.System.UriParser.WsUri.SchemeName;
                }
                {
                    this.UriSchemeWss = $.$spu.System.UriParser.WssUri.SchemeName;
                }
                {
                    this.UriSchemeMailto = $.$spu.System.UriParser.MailToUri.SchemeName;
                }
                {
                    this.UriSchemeNews = $.$spu.System.UriParser.NewsUri.SchemeName;
                }
                {
                    this.UriSchemeNntp = $.$spu.System.UriParser.NntpUri.SchemeName;
                }
                {
                    this.UriSchemeSsh = "ssh";
                }
                {
                    this.UriSchemeTelnet = $.$spu.System.UriParser.TelnetUri.SchemeName;
                }
                {
                    this.UriSchemeNetTcp = $.$spu.System.UriParser.NetTcpUri.SchemeName;
                }
                {
                    this.UriSchemeNetPipe = $.$spu.System.UriParser.NetPipeUri.SchemeName;
                }
                {
                    this.SchemeDelimiter = "://";
                }
                {
                    this.s_schemeChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("+-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"));
                }
                {
                    this.s_segmentSeparatorChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit(":\\/?#"));
                }
            }
            static $h = 1746220;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":279174620460,"f":50331650},"n":"IsImplicitFile","d":1746220,"h":274879653164,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":287764555052,"f":50331650},"n":"IsUncOrDosPath","d":1746220,"h":283469587756,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":296354489644,"f":50331650},"n":"IsDosPath","d":1746220,"h":292059522348,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":304944424236,"f":50331650},"n":"IsUncPath","d":1746220,"h":300649456940,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":313534358828,"f":50331650},"n":"IsUnixPath","d":1746220,"h":309239391532,"f":2097154},{"p":1877292,"g":{"r":0,"d":0,"h":322124293420,"f":50331650},"n":"HostType","d":1746220,"h":317829326124,"f":2097154},{"p":2663724,"g":{"r":0,"d":0,"h":330714228012,"f":50331650},"n":"Syntax","d":1746220,"h":326419260716,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":339304162604,"f":50331650},"n":"IsNotAbsoluteUri","d":1746220,"h":335009195308,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":347894097196,"f":50331650},"n":"IriParsing","d":1746220,"h":343599129900,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":360778999084,"f":50331656},"n":"DisablePathAndQueryCanonicalization","d":1746220,"h":356484031788,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":369368933676,"f":50331656},"n":"UserDrivenParsing","d":1746220,"h":365073966380,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":377958868268,"f":50331650},"n":"SecuredPathIndex","d":1746220,"h":373663900972,"f":2097154},{"p":1310721,"g":{"r":0,"d":0,"h":472448148780,"f":50331649},"n":"AbsolutePath","d":1746220,"h":468153181484,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":481038083372,"f":50331650},"n":"PrivateAbsolutePath","d":1746220,"h":476743116076,"f":2097154},{"p":1310721,"g":{"r":0,"d":0,"h":489628017964,"f":50331649},"n":"AbsoluteUri","d":1746220,"h":485333050668,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":498217952556,"f":50331649},"n":"LocalPath","d":1746220,"h":493922985260,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":506807887148,"f":50331649},"n":"Authority","d":1746220,"h":502512919852,"f":2097153},{"p":2532652,"g":{"r":0,"d":0,"h":515397821740,"f":50331649},"n":"HostNameType","d":1746220,"h":511102854444,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":523987756332,"f":50331649},"n":"IsDefaultPort","d":1746220,"h":519692789036,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":532577690924,"f":50331649},"n":"IsFile","d":1746220,"h":528282723628,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":541167625516,"f":50331649},"n":"IsLoopback","d":1746220,"h":536872658220,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":549757560108,"f":50331649},"n":"PathAndQuery","d":1746220,"h":545462592812,"f":2097153},{"p":$.$typeArray($.$$.System.String).$h,"g":{"r":0,"d":0,"h":558347494700,"f":50331649},"n":"Segments","d":1746220,"h":554052527404,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":566937429292,"f":50331649},"n":"IsUnc","d":1746220,"h":562642461996,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":575527363884,"f":50331649},"n":"Host","d":1746220,"h":571232396588,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":592707233068,"f":50331649},"n":"Port","d":1746220,"h":588412265772,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":601297167660,"f":50331649},"n":"Query","d":1746220,"h":597002200364,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":609887102252,"f":50331649},"n":"Fragment","d":1746220,"h":605592134956,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":618477036844,"f":50331649},"n":"Scheme","d":1746220,"h":614182069548,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":627066971436,"f":50331649},"n":"OriginalString","d":1746220,"h":622772004140,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":635656906028,"f":50331649},"n":"DnsSafeHost","d":1746220,"h":631361938732,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":644246840620,"f":50331649},"n":"IdnHost","d":1746220,"h":639951873324,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":652836775212,"f":50331649},"n":"IsAbsoluteUri","d":1746220,"h":648541807916,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":661426709804,"f":50331649},"n":"UserEscaped","d":1746220,"h":657131742508,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":670016644396,"f":50331649},"n":"UserInfo","d":1746220,"h":665721677100,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":944894551340,"f":50331656},"n":"HasAuthority","d":1746220,"h":940599584044,"f":2097160}],"m":[{"r":65537,"p":[{"n":"uri","p":1310721},{"n":"dontEscape","p":262145},{"n":"uriKind","p":2598188},{"n":"creationOptions","p":2270508,"f":73}],"n":"CreateThis","d":1746220,"h":4296713516,"f":16777218},{"r":65537,"p":[{"n":"err","p":1353004},{"n":"uriKind","p":2598188},{"n":"e","p":2401580,"f":2}],"n":"InitializeUri","d":1746220,"h":8591680812,"f":16777218},{"r":262145,"p":[{"n":"data","p":1310721}],"n":"CheckForUnicodeOrEscapedUnreserved","d":1746220,"h":17181615404,"f":16777250},{"r":262145,"p":[{"n":"uriString","p":1310721},{"n":"uriKind","p":2598188},{"n":"result","p":1746220,"f":2}],"n":"TryCreate","d":1746220,"h":21476582700,"f":16777249},{"r":262145,"p":[{"n":"uriString","p":1310721},{"n":"creationOptions","p":2270508,"f":8},{"n":"result","p":1746220,"f":2}],"n":"TryCreate","o":"@$1","d":1746220,"h":25771549996,"f":16777249},{"r":262145,"p":[{"n":"baseUri","p":1746220},{"n":"relativeUri","p":1310721},{"n":"result","p":1746220,"f":2}],"n":"TryCreate","o":"@$2","d":1746220,"h":30066517292,"f":16777249},{"r":262145,"p":[{"n":"baseUri","p":1746220},{"n":"relativeUri","p":1746220},{"n":"result","p":1746220,"f":2}],"n":"TryCreate","o":"@$3","d":1746220,"h":34361484588,"f":16777249},{"r":1310721,"p":[{"n":"components","p":2204972},{"n":"format","p":2336044}],"n":"GetComponents","d":1746220,"h":38656451884,"f":16777217},{"r":1310721,"p":[{"n":"components","p":2204972},{"n":"format","p":2336044}],"n":"InternalGetComponents","d":1746220,"h":42951419180,"f":16777218},{"r":655361,"p":[{"n":"uri1","p":1746220},{"n":"uri2","p":1746220},{"n":"partsToCompare","p":2204972},{"n":"compareFormat","p":2336044},{"n":"comparisonType","p":119341057}],"n":"Compare","d":1746220,"h":47246386476,"f":16777249},{"r":262145,"n":"IsWellFormedOriginalString","d":1746220,"h":51541353772,"f":16777217},{"r":262145,"p":[{"n":"uriString","p":1310721},{"n":"uriKind","p":2598188}],"n":"IsWellFormedUriString","d":1746220,"h":55836321068,"f":16777249},{"r":262145,"n":"InternalIsWellFormedOriginalString","d":1746220,"h":60131288364,"f":16777224},{"r":1310721,"p":[{"n":"stringToUnescape","p":1310721}],"n":"UnescapeDataString","o":"@$2","d":1746220,"h":64426255660,"f":16777249},{"r":1310721,"p":[{"n":"charsToUnescape","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"UnescapeDataString","o":"@$1","d":1746220,"h":68721222956,"f":16777249},{"r":1310721,"p":[{"n":"charsToUnescape","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"backingString","p":1310721,"f":65}],"n":"UnescapeDataString","d":1746220,"h":73016190252,"f":16777250},{"r":262145,"p":[{"n":"charsToUnescape","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryUnescapeDataString","d":1746220,"h":77311157548,"f":16777249},{"r":1310721,"p":[{"n":"stringToEscape","p":1310721}],"n":"EscapeUriString","d":1746220,"h":81606124844,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0013","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"r":1310721,"p":[{"n":"stringToEscape","p":1310721}],"n":"EscapeDataString","o":"@$1","d":1746220,"h":85901092140,"f":16777249},{"r":1310721,"p":[{"n":"charsToEscape","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"EscapeDataString","d":1746220,"h":90196059436,"f":16777249},{"r":262145,"p":[{"n":"charsToEscape","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryEscapeDataString","d":1746220,"h":94491026732,"f":16777249},{"r":1310721,"p":[{"n":"input","p":1310721},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"component","p":2204972}],"n":"EscapeUnescapeIri","d":1746220,"h":98785994028,"f":16777224},{"r":1746220,"p":[{"n":"uriString","p":1310721},{"n":"dontEscape","p":262145},{"n":"uriKind","p":2598188},{"n":"e","p":2401580,"f":4},{"n":"creationOptions","p":2270508,"f":73}],"n":"CreateHelper","d":1746220,"h":107375928620,"f":16777256},{"r":1746220,"p":[{"n":"baseUri","p":1746220},{"n":"relativeUri","p":1746220},{"n":"newUriString","p":1310721,"f":4},{"n":"userEscaped","p":262145,"f":4}],"n":"ResolveHelper","d":1746220,"h":111670895916,"f":16777256},{"r":1310721,"p":[{"n":"format","p":2336044}],"n":"GetRelativeSerializationString","d":1746220,"h":115965863212,"f":16777218},{"r":1310721,"p":[{"n":"uriComponents","p":2204972},{"n":"uriFormat","p":2336044}],"n":"GetComponentsHelper","d":1746220,"h":120260830508,"f":16777224},{"r":262145,"p":[{"n":"uri","p":1746220}],"n":"IsBaseOf","d":1746220,"h":124555797804,"f":16777217},{"r":262145,"p":[{"n":"uriLink","p":1746220}],"n":"IsBaseOfHelper","d":1746220,"h":128850765100,"f":16777224},{"r":65537,"p":[{"n":"otherUri","p":1746220}],"n":"CreateThisFromUri","d":1746220,"h":133145732396,"f":16777218},{"r":65537,"n":"DebugSetLeftCtor","d":1746220,"h":244814882092,"f":16777218,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"n":"AssertInvariants","d":1746220,"h":249109849388,"f":16777218,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"n":"DebugAssertInCtor","d":1746220,"h":253404816684,"f":16777224,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"flags","p":1877292}],"n":"InterlockedSetFlags","d":1746220,"h":270584685868,"f":16777218},{"r":262145,"p":[{"n":"syntax","p":2663724}],"n":"IriParsingStatic","d":1746220,"h":352189064492,"f":16777256},{"r":262145,"p":[{"n":"flags","p":1877292}],"n":"NotAny","d":1746220,"h":382253835564,"f":16777218},{"r":262145,"p":[{"n":"flags","p":1877292}],"n":"InFact","d":1746220,"h":386548802860,"f":16777218},{"r":262145,"p":[{"n":"allFlags","p":1877292},{"n":"checkFlags","p":1877292}],"n":"StaticNotAny","d":1746220,"h":390843770156,"f":16777250},{"r":262145,"p":[{"n":"allFlags","p":1877292},{"n":"checkFlags","p":1877292}],"n":"StaticInFact","d":1746220,"h":395138737452,"f":16777250},{"r":2073900,"n":"EnsureUriInfo","d":1746220,"h":399433704748,"f":16777218},{"r":65537,"n":"EnsureParseRemaining","d":1746220,"h":403728672044,"f":16777218},{"r":65537,"p":[{"n":"allowDnsOptimization","p":262145}],"n":"EnsureHostString","d":1746220,"h":408023639340,"f":16777218},{"r":65537,"p":[{"n":"serializationInfo","p":113836033},{"n":"streamingContext","p":113967105}],"n":"GetObjectData","d":1746220,"h":446678345004,"f":16777220},{"r":65537,"p":[{"n":"baseUri","p":1746220},{"n":"relativeUri","p":1310721},{"n":"dontEscape","p":262145}],"n":"CreateUri","d":1746220,"h":450973312300,"f":16777218},{"r":65537,"p":[{"n":"baseUri","p":1746220},{"n":"relativeStr","p":1310721},{"n":"dontEscape","p":262145},{"n":"result","p":1310721,"f":4}],"n":"GetCombinedString","d":1746220,"h":459563246892,"f":16777250},{"r":2401580,"p":[{"n":"err","p":1353004}],"n":"GetException","d":1746220,"h":463858214188,"f":16777250},{"r":262145,"p":[{"n":"syntax","p":2663724}],"n":"StaticIsFile","d":1746220,"h":579822331180,"f":16777250},{"r":1310721,"n":"GetLocalPath","d":1746220,"h":584117298476,"f":16777218},{"r":2532652,"p":[{"n":"name","p":1310721}],"n":"CheckHostName","d":1746220,"h":674311611692,"f":16777249},{"r":1310721,"p":[{"n":"part","p":2794796}],"n":"GetLeftPart","d":1746220,"h":678606578988,"f":16777217},{"r":1310721,"p":[{"n":"character","p":458753}],"n":"HexEscape","d":1746220,"h":682901546284,"f":16777249},{"r":458753,"p":[{"n":"pattern","p":1310721},{"n":"index","p":655361,"f":4}],"n":"HexUnescape","d":1746220,"h":687196513580,"f":16777249},{"r":262145,"p":[{"n":"pattern","p":1310721},{"n":"index","p":655361}],"n":"IsHexEncoding","d":1746220,"h":691491480876,"f":16777249},{"r":262145,"p":[{"n":"schemeName","p":1310721}],"n":"CheckSchemeName","d":1746220,"h":700081415468,"f":16777249},{"r":262145,"p":[{"n":"character","p":458753}],"n":"IsHexDigit","d":1746220,"h":704376382764,"f":16777249},{"r":655361,"p":[{"n":"digit","p":458753}],"n":"FromHex","d":1746220,"h":708671350060,"f":16777249},{"r":655361,"n":"GetHashCode","d":1746220,"h":712966317356,"f":16809985},{"r":1310721,"n":"ToString","d":1746220,"h":721556251948,"f":16809985},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryFormat","d":1746220,"h":725851219244,"f":16777217},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","o":"@$1","d":1746220,"h":747326055724,"f":16809985},{"r":262145,"p":[{"n":"other","p":1746220}],"n":"Equals","o":"@$2","d":1746220,"h":751621023020,"f":16777217},{"r":1746220,"p":[{"n":"uri","p":1746220}],"n":"MakeRelativeUri","d":1746220,"h":755915990316,"f":16777217},{"r":262145,"p":[{"n":"uriString","p":1310721}],"n":"CheckForColonInFirstPathSegment","d":1746220,"h":764505924908,"f":16777250},{"r":1310721,"p":[{"n":"rawString","p":1310721}],"n":"InternalEscapeString","d":1746220,"h":768800892204,"f":16777256},{"r":1353004,"p":[{"n":"uriString","p":1310721},{"n":"flags","p":1877292,"f":4},{"n":"syntax","p":2663724,"f":4}],"n":"ParseScheme","d":1746220,"h":773095859500,"f":16777250},{"r":2401580,"n":"ParseMinimal","d":1746220,"h":777390826796,"f":16777224},{"r":1353004,"n":"PrivateParseMinimal","d":1746220,"h":781685794092,"f":16777218},{"r":65537,"p":[{"n":"cF","p":1877292}],"n":"CreateUriInfo","d":1746220,"h":785980761388,"f":16777218},{"r":65537,"n":"CreateHostString","d":1746220,"h":790275728684,"f":16777218},{"r":1310721,"p":[{"n":"str","p":1310721},{"n":"idx","p":655361},{"n":"end","p":655361},{"n":"flags","p":1877292,"f":4},{"n":"info","p":2073900}],"n":"CreateHostStringHelper","d":1746220,"h":794570695980,"f":16777250},{"r":65537,"n":"GetHostViaCustomSyntax","d":1746220,"h":798865663276,"f":16777218},{"r":1310721,"p":[{"n":"uriParts","p":2204972},{"n":"formatAs","p":2336044}],"n":"GetParts","d":1746220,"h":803160630572,"f":16777224},{"r":1310721,"p":[{"n":"uriParts","p":2204972}],"n":"GetEscapedParts","d":1746220,"h":807455597868,"f":16777218},{"r":1310721,"p":[{"n":"uriParts","p":2204972},{"n":"formatAs","p":2336044}],"n":"GetUnescapedParts","d":1746220,"h":811750565164,"f":16777218},{"r":1310721,"p":[{"n":"parts","p":2204972},{"n":"nonCanonical","p":589825},{"n":"formatAs","p":2336044}],"n":"RecreateParts","d":1746220,"h":816045532460,"f":16777218},{"r":262145,"p":[{"n":"span","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsWritten","p":655361,"f":2},{"n":"parts","p":2204972},{"n":"nonCanonical","p":589825},{"n":"formatAs","p":2336044}],"n":"TryRecreateParts","d":1746220,"h":820340499756,"f":16777218},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"p":[{"n":"dest","p":1549612,"f":4},{"n":"str","p":1310721},{"n":"parts","p":2204972},{"n":"nonCanonical","p":589825},{"n":"formatAs","p":2336044}],"n":"RecreateParts","o":"@$1","d":1746220,"h":824635467052,"f":16777218},{"r":1310721,"p":[{"n":"uriParts","p":2204972}],"n":"GetUriPartsFromUserString","d":1746220,"h":828930434348,"f":16777218},{"r":65537,"p":[{"n":"str","p":1310721},{"n":"length","p":655361,"f":4},{"n":"idx","p":655361}],"n":"GetLengthWithoutTrailingSpaces","d":1746220,"h":833225401644,"f":16777250},{"r":65537,"n":"ParseRemaining","d":1746220,"h":837520368940,"f":16777218},{"r":655361,"p":[{"n":"uriString","p":1310721},{"n":"err","p":1353004,"f":4},{"n":"flags","p":1877292,"f":4},{"n":"syntax","p":2663724,"f":4}],"n":"ParseSchemeCheckImplicitFile","d":1746220,"h":841815336236,"f":16777250},{"r":2663724,"p":[{"n":"scheme","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"error","p":1353004,"f":4}],"n":"CheckSchemeSyntax","d":1746220,"h":846110303532,"f":16777250},{"r":655361,"p":[{"n":"pString","p":$.$typePointer($.$$.System.Char).$h},{"n":"idx","p":655361},{"n":"length","p":655361},{"n":"err","p":1353004,"f":4},{"n":"flags","p":1877292,"f":4},{"n":"syntax","p":2663724},{"n":"newHost","p":1310721,"f":4}],"n":"CheckAuthorityHelper","d":1746220,"h":850405270828,"f":16777218},{"r":65537,"p":[{"n":"pString","p":$.$typePointer($.$$.System.Char).$h},{"n":"start","p":655361},{"n":"end","p":655361},{"n":"hasUnicode","p":262145},{"n":"flags","p":1877292,"f":4},{"n":"newHost","p":1310721,"f":4},{"n":"err","p":1353004,"f":4}],"n":"CheckAuthorityHelperHandleDnsIri","d":1746220,"h":854700238124,"f":16777250},{"r":1811756,"p":[{"n":"str","p":$.$typePointer($.$$.System.Char).$h},{"n":"idx","p":655361,"f":4},{"n":"end","p":655361},{"n":"delim","p":458753}],"n":"CheckCanonical","d":1746220,"h":871880107308,"f":16777218},{"r":65537,"p":[{"n":"dest","p":1549612,"f":4},{"n":"formatAs","p":2336044}],"n":"GetCanonicalPath","d":1746220,"h":876175074604,"f":16777218},{"r":65537,"p":[{"n":"pch","p":$.$typePointer($.$$.System.Char).$h},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"ch1","p":458753},{"n":"ch2","p":458753},{"n":"ch3","p":458753}],"n":"UnescapeOnly","d":1746220,"h":880470041900,"f":16777250},{"r":65537,"p":[{"n":"dest","p":$.$typeArray($.$$.System.Char).$h},{"n":"start","p":655361},{"n":"destLength","p":655361,"f":4},{"n":"syntax","p":2663724}],"n":"Compress","d":1746220,"h":884765009196,"f":16777250},{"r":1310721,"p":[{"n":"basePart","p":1746220},{"n":"relativePart","p":1310721},{"n":"uriFormat","p":2336044}],"n":"CombineUri","d":1746220,"h":889059976492,"f":16777250},{"r":1310721,"p":[{"n":"path1","p":1310721},{"n":"path2","p":1310721},{"n":"compareCase","p":262145}],"n":"PathDifference","d":1746220,"h":893354943788,"f":16777250},{"r":1310721,"p":[{"n":"toUri","p":1746220}],"n":"MakeRelative","d":1746220,"h":897649911084,"f":16777217,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.MakeRelative has been deprecated. Use MakeRelativeUri(Uri uri) instead.","t":1310721}]}]},{"r":65537,"n":"Canonicalize","d":1746220,"h":901944878380,"f":16777348,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.Canonicalize has been deprecated and is not supported.","t":1310721}]}]},{"r":65537,"n":"Parse","d":1746220,"h":906239845676,"f":16777348,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.Parse has been deprecated and is not supported.","t":1310721}]}]},{"r":65537,"n":"Escape","d":1746220,"h":910534812972,"f":16777348,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.Escape has been deprecated and is not supported.","t":1310721}]}]},{"r":1310721,"p":[{"n":"path","p":1310721}],"n":"Unescape","d":1746220,"h":914829780268,"f":16777348,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.Unescape has been deprecated. Use GetComponents() or Uri.UnescapeDataString() to unescape a Uri component or a string.","t":1310721}]}]},{"r":1310721,"p":[{"n":"str","p":1310721}],"n":"EscapeString","d":1746220,"h":919124747564,"f":16777252,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.EscapeString has been deprecated. Use GetComponents() or Uri.EscapeDataString to escape a Uri component or a string.","t":1310721}]}]},{"r":65537,"n":"CheckSecurity","d":1746220,"h":923419714860,"f":16777348,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.CheckSecurity has been deprecated and is not supported.","t":1310721}]}]},{"r":262145,"p":[{"n":"character","p":458753}],"n":"IsReservedCharacter","d":1746220,"h":927714682156,"f":16777348,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.IsReservedCharacter has been deprecated and is not supported.","t":1310721}]}]},{"r":262145,"p":[{"n":"character","p":458753}],"n":"IsExcludedCharacter","d":1746220,"h":932009649452,"f":16777252,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.IsExcludedCharacter has been deprecated and is not supported.","t":1310721}]}]},{"r":262145,"p":[{"n":"character","p":458753}],"n":"IsBadFileSystemCharacter","d":1746220,"h":936304616748,"f":16777348,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Uri.IsBadFileSystemCharacter has been deprecated and is not supported.","t":1310721}]}]}],"l":[{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"s_asciiOtherThanPercent","d":1746220,"h":12886648108,"f":4194338},{"t":1310721,"n":"UriSchemeFile","d":1746220,"h":137440699692,"f":4194337},{"t":1310721,"n":"UriSchemeFtp","d":1746220,"h":141735666988,"f":4194337},{"t":1310721,"n":"UriSchemeSftp","d":1746220,"h":146030634284,"f":4194337},{"t":1310721,"n":"UriSchemeFtps","d":1746220,"h":150325601580,"f":4194337},{"t":1310721,"n":"UriSchemeGopher","d":1746220,"h":154620568876,"f":4194337},{"t":1310721,"n":"UriSchemeHttp","d":1746220,"h":158915536172,"f":4194337},{"t":1310721,"n":"UriSchemeHttps","d":1746220,"h":163210503468,"f":4194337},{"t":1310721,"n":"UriSchemeWs","d":1746220,"h":167505470764,"f":4194337},{"t":1310721,"n":"UriSchemeWss","d":1746220,"h":171800438060,"f":4194337},{"t":1310721,"n":"UriSchemeMailto","d":1746220,"h":176095405356,"f":4194337},{"t":1310721,"n":"UriSchemeNews","d":1746220,"h":180390372652,"f":4194337},{"t":1310721,"n":"UriSchemeNntp","d":1746220,"h":184685339948,"f":4194337},{"t":1310721,"n":"UriSchemeSsh","d":1746220,"h":188980307244,"f":4194337},{"t":1310721,"n":"UriSchemeTelnet","d":1746220,"h":193275274540,"f":4194337},{"t":1310721,"n":"UriSchemeNetTcp","d":1746220,"h":197570241836,"f":4194337},{"t":1310721,"n":"UriSchemeNetPipe","d":1746220,"h":201865209132,"f":4194337},{"t":1310721,"n":"SchemeDelimiter","d":1746220,"h":206160176428,"f":4194337},{"t":655361,"n":"SchemeLengthLimit","d":1746220,"h":210455143724,"f":4194338},{"t":655361,"n":"StackallocThreshold","d":1746220,"h":214750111020,"f":4194344},{"t":1310721,"n":"_string","d":1746220,"h":219045078316,"f":4194306},{"t":1310721,"n":"_originalUnicodeString","d":1746220,"h":223340045612,"f":4194306},{"t":2663724,"n":"_syntax","d":1746220,"h":227635012908,"f":4194312},{"t":1877292,"n":"_flags","d":1746220,"h":231929980204,"f":4194312},{"t":2073900,"n":"_info","d":1746220,"h":236224947500,"f":4194306},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"s_schemeChars","d":1746220,"h":695786448172,"f":4194338},{"t":2336044,"n":"V1ToStringUnescape","d":1746220,"h":717261284652,"f":4194338},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"s_segmentSeparatorChars","d":1746220,"h":760210957612,"f":4194338},{"t":458753,"n":"c_DummyChar","d":1746220,"h":858995205420,"f":4194344},{"t":458753,"n":"c_EOL","d":1746220,"h":863290172716,"f":4194344}],"c":[{"p":[{"n":"flags","p":1877292},{"n":"uriParser","p":2663724},{"n":"uri","p":1310721}],"n":".ctor","o":"$ctor$9","d":1746220,"h":103080961324,"f":16777218},{"p":[{"n":"uriString","p":1310721}],"n":".ctor","o":"$ctor$5","d":1746220,"h":412318606636,"f":16777217},{"p":[{"n":"uriString","p":1310721},{"n":"dontEscape","p":262145}],"n":".ctor","o":"$ctor$2","d":1746220,"h":416613573932,"f":16777217,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor has been deprecated; the dontEscape parameter is always false. Use Uri(string) instead.","t":1310721}]}]},{"p":[{"n":"baseUri","p":1746220},{"n":"relativeUri","p":1310721},{"n":"dontEscape","p":262145}],"n":".ctor","o":"$ctor$6","d":1746220,"h":420908541228,"f":16777217,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor has been deprecated; the dontEscape parameter is always false. Use Uri(Uri, string) instead.","t":1310721}]}]},{"p":[{"n":"uriString","p":1310721},{"n":"uriKind","p":2598188}],"n":".ctor","o":"$ctor$3","d":1746220,"h":425203508524,"f":16777217},{"p":[{"n":"uriString","p":1310721},{"n":"creationOptions","p":2270508,"f":8}],"n":".ctor","o":"$ctor$4","d":1746220,"h":429498475820,"f":16777217},{"p":[{"n":"baseUri","p":1746220},{"n":"relativeUri","p":1310721}],"n":".ctor","o":"$ctor$7","d":1746220,"h":433793443116,"f":16777217},{"p":[{"n":"serializationInfo","p":113836033},{"n":"streamingContext","p":113967105}],"n":".ctor","o":"$ctor$1","d":1746220,"h":438088410412,"f":16777220,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"p":[{"n":"baseUri","p":1746220},{"n":"relativeUri","p":1746220}],"n":".ctor","o":"$ctor$8","d":1746220,"h":455268279596,"f":16777217}],"i":[63832065,57737217,$.$$.System.IEquatable$$($.$spu.System.Uri).$h,113246209],"j":[1877292,2073900,2008364,1942828,1811756],"h":1746220,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IEquatable$$($.$spu.System.Uri), $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Uri`; }
        });
        
        $asm.$str("$spu.System.UriCreationOptions", ($self) => class UriCreationOptions extends $.$$.System.ValueType
        {
            /*bool*/  get _disablePathAndQueryCanonicalization() { return this.$getField(0, 1); }
            /*bool*/  set _disablePathAndQueryCanonicalization(value) { this.$setField(0, 1, value); }
            /*bool */ get DangerousDisablePathAndQueryCanonicalization()
            {
                return this._disablePathAndQueryCanonicalization;
            }
            /*bool */ set DangerousDisablePathAndQueryCanonicalization(value)
            {
                this._disablePathAndQueryCanonicalization = value;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._disablePathAndQueryCanonicalization = this._disablePathAndQueryCanonicalization;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._disablePathAndQueryCanonicalization = false;
            }
            static $h = 2270508;
            static $z = 1;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12887172396,"f":50331649},"s":{"r":0,"d":0,"h":17182139692,"f":83886081},"n":"DangerousDisablePathAndQueryCanonicalization","d":2270508,"h":8592205100,"f":2097153}],"l":[{"t":262145,"n":"_disablePathAndQueryCanonicalization","d":2270508,"h":4297237804,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":2270508,"h":21477106988,"f":16777217}],"h":2270508}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.UriCreationOptions`; }
        });
        
        $asm.$cls("$spu.System.HttpStyleUriParser", ($self) => class HttpStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.HttpUri.Flags);
                {
                }
                return this;
            }
            static $h = 763180;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2663724,"c":[{"n":".ctor","o":"$ctor$3","d":763180,"h":4295730476,"f":16777217}],"h":763180}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.HttpStyleUriParser`; }
        });
        
        $asm.$cls("$spu.System.FtpStyleUriParser", ($self) => class FtpStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.FtpUri.Flags);
                {
                }
                return this;
            }
            static $h = 304428;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2663724,"c":[{"n":".ctor","o":"$ctor$3","d":304428,"h":4295271724,"f":16777217}],"h":304428}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.FtpStyleUriParser`; }
        });
        
        $asm.$cls("$spu.System.GenericUriParser", ($self) => class GenericUriParser extends $.$spu.System.UriParser
        {
            $ctor$3(/*GenericUriParserOptions*/ options)
            {
                super.$ctor$2($.$spu.System.GenericUriParser.MapGenericParserOptions(options));
                {
                }
                return this;
            }
            static /*UriSyntaxFlags */ MapGenericParserOptions(/*GenericUriParserOptions*/ options)
            {
                /*UriSyntaxFlags*/ let flags = 65015677/*DefaultGenericUriParserFlags*/;
                if ((options & 1/*GenericUriParserOptions.GenericAuthority*/) !== 0)
                {
                    flags &= ~(4/*UriSyntaxFlags.MayHaveUserInfo*/ | 8/*UriSyntaxFlags.MayHavePort*/ | 256/*UriSyntaxFlags.AllowUncHost*/ | 3584/*UriSyntaxFlags.AllowAnInternetHost*/);
                    flags |= 4096/*UriSyntaxFlags.AllowAnyOtherHost*/;
                }
                if ((options & 2/*GenericUriParserOptions.AllowEmptyAuthority*/) !== 0)
                {
                    flags |= 128/*UriSyntaxFlags.AllowEmptyHost*/;
                }
                if ((options & 4/*GenericUriParserOptions.NoUserInfo*/) !== 0)
                {
                    flags &= ~4/*UriSyntaxFlags.MayHaveUserInfo*/;
                }
                if ((options & 8/*GenericUriParserOptions.NoPort*/) !== 0)
                {
                    flags &= ~8/*UriSyntaxFlags.MayHavePort*/;
                }
                if ((options & 16/*GenericUriParserOptions.NoQuery*/) !== 0)
                {
                    flags &= ~32/*UriSyntaxFlags.MayHaveQuery*/;
                }
                if ((options & 32/*GenericUriParserOptions.NoFragment*/) !== 0)
                {
                    flags &= ~64/*UriSyntaxFlags.MayHaveFragment*/;
                }
                if ((options & 64/*GenericUriParserOptions.DontConvertPathBackslashes*/) !== 0)
                {
                    flags &= ~4194304/*UriSyntaxFlags.ConvertPathSlashes*/;
                }
                if ((options & 128/*GenericUriParserOptions.DontCompressPath*/) !== 0)
                {
                    flags &= ~(8388608/*UriSyntaxFlags.CompressPath*/ | 16777216/*UriSyntaxFlags.CanonicalizeAsFilePath*/);
                }
                if ((options & 256/*GenericUriParserOptions.DontUnescapePathDotsAndSlashes*/) !== 0)
                {
                    flags &= ~33554432/*UriSyntaxFlags.UnEscapeDotsAndSlashes*/;
                }
                if ((options & 512/*GenericUriParserOptions.Idn*/) !== 0)
                {
                    flags |= 67108864/*UriSyntaxFlags.AllowIdn*/;
                }
                if ((options & 1024/*GenericUriParserOptions.IriParsing*/) !== 0)
                {
                    flags |= 268435456/*UriSyntaxFlags.AllowIriParsing*/;
                }
                return flags;
            }
            /*UriSyntaxFlags*/ static DefaultGenericUriParserFlags = 65015677;
            static $h = 369964;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2663724,"m":[{"r":2860332,"p":[{"n":"options","p":435500}],"n":"MapGenericParserOptions","d":369964,"h":8590304556,"f":16777250}],"l":[{"t":2860332,"n":"DefaultGenericUriParserFlags","d":369964,"h":12885271852,"f":4194338}],"c":[{"p":[{"n":"options","p":435500}],"n":".ctor","o":"$ctor$3","d":369964,"h":4295337260,"f":16777217}],"h":369964}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.GenericUriParser`; }
        });
        
        $asm.$str("$spu.System.Text.ValueStringBuilder", ($self) => class ValueStringBuilder extends $.$$.System.ValueType
        {
            /*void */ Append$4(/*Rune*/ rune)
            {
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if (((((pos + 1) | 0)) >>> 0) < (chars.Length >>> 0) && (pos >>> 0) < (chars.Length >>> 0))
                {
                    if (rune.Value <= 65535)
                    {
                        chars.get_Item(pos).$v = $.$cast(rune.Value, $.$$.System.Char);
                        this._pos = ((pos + 1) | 0);
                    }
                    else 
                    {
                        chars.get_Item(pos).$v = $.$cast(((BigInt(rune.Value) + (BigInt(((((55296 - 64) >>> 0)) << 10) >>> 0))) >> 10n), $.$$.System.Char);
                        chars.get_Item(((pos + 1) | 0)).$v = $.$cast(((BigInt(rune.Value) & 1023n) + 56320n), $.$$.System.Char);
                        this._pos = ((pos + 2) | 0);
                    }
                }
                else 
                {
                    this.GrowAndAppend$1(rune);
                }
            }
            /*void */ GrowAndAppend$1(/*Rune*/ rune)
            {
                if (rune.Value <= 65535)
                {
                    this.Append$1($.$cast(rune.Value, $.$$.System.Char));
                }
                else 
                {
                    this.Grow(2);
                    this.Append$4(rune);
                }
            }
            /*char[]?*/  get _arrayToReturnToPool() { return this.$getField(0, 4); }
            /*char[]?*/  set _arrayToReturnToPool(value) { this.$setField(0, 4, value); }
            /*Span<char>*/  get _chars() { return this.$getField(4, 6); }
            /*Span<char>*/  set _chars(value) { this.$setField(4, 6, value); }
            /*int*/  get _pos() { return this.$getField(10, 4); }
            /*int*/  set _pos(value) { this.$setField(10, 4, value); }
            $ctor$4(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            /*int */ get Length()
            {
                return this._pos;
            }
            /*int */ set Length(value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(value >= 0, "value >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            /*ref char */ GetPinnableReference()
            {
                return $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, this._chars);
            }
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, this._chars);
            }
            /*ref char*/ get_Item(/*int*/ index)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string*/ let s = $.$$.System.Span$$($.$$.System.Char).ToString.call(this._chars.Slice(0, this._pos));
                this.Dispose();
                return s;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spu.System.Text.ValueStringBuilder.ToString.apply(this, arguments); }
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            /*ReadOnlySpan<char> */ AsSpan$1(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan()
            {
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start)
            {
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(start, ((this._pos - start) | 0)));
            }
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start, /*int*/ length)
            {
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(start, length));
            }
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                if (this._chars.Slice(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                this._chars.Slice(index, count).Fill(value);
                this._pos += count;
            }
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                $.$$.System.String.CopyTo$1.call(s, this._chars.Slice$1(index));
                this._pos += count;
            }
            /*void */ Append$1(/*char*/ c)
            {
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars.get_Item(pos).$v = c;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend(c);
                }
            }
            /*void */ Append$3(/*string?*/ s)
            {
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars.get_Item(pos).$v = $.$$.System.String.get_Chars.call(s, 0);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            /*void */ AppendSlow(/*string*/ s)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$$.System.String.CopyTo$1.call(s, this._chars.Slice$1(pos));
                this._pos += s.length;
            }
            /*void */ Append(/*char*/ c, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst.get_Item(i).$v = c;
                }
                this._pos += count;
            }
            /*void */ Append$2(/*scoped ReadOnlySpan<char>*/ value)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice$1(this._pos));
                this._pos += value.Length;
            }
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice(origPos, length);
            }
            /*void */ GrowAndAppend(/*char*/ c)
            {
                this.Grow(1);
                this.Append$1(c);
            }
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$$.System.Diagnostics.Debug.Assert$2(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$$.System.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$$.System.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(newCapacity);
                this._chars.Slice(0, this._pos).CopyTo($.$$.System.Span$$($.$$.System.Char).op_Implicit$2(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(toReturn, false);
                }
            }
            /*void */ Dispose()
            {
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$spu.System.Text.ValueStringBuilder().Clone(this);
                if (toReturn !== null)
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(toReturn, false);
                }
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.Clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._arrayToReturnToPool = null;
                this._chars = $.$default($.$$.System.Span$$($.$$.System.Char));
                this._pos = 0;
            }
            static $h = 1549612;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":38656255276,"f":50331649},"s":{"r":0,"d":0,"h":42951222572,"f":83886081},"n":"Length","d":1549612,"h":34361287980,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":51541157164,"f":50331649},"n":"Capacity","d":1549612,"h":47246189868,"f":2097153},{"p":458753,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":73015993644,"f":50331649},"n":"Item","o":"@$2","d":1549612,"h":68721026348,"f":2097153},{"p":$.$$.System.Span$$($.$$.System.Char).$h,"g":{"r":0,"d":0,"h":85900895532,"f":50331649},"n":"RawChars","d":1549612,"h":81605928236,"f":2097153}],"m":[{"r":65537,"p":[{"n":"rune","p":122617857}],"n":"Append","o":"@$4","d":1549612,"h":4296516908,"f":16777217},{"r":65537,"p":[{"n":"rune","p":122617857}],"n":"GrowAndAppend","o":"@$1","d":1549612,"h":8591484204,"f":16777218},{"r":65537,"p":[{"n":"capacity","p":655361}],"n":"EnsureCapacity","d":1549612,"h":55836124460,"f":16777217},{"r":458753,"n":"GetPinnableReference","d":1549612,"h":60131091756,"f":16777217},{"r":458753,"p":[{"n":"terminate","p":262145}],"n":"GetPinnableReference","o":"@$1","d":1549612,"h":64426059052,"f":16777217},{"r":1310721,"n":"ToString","d":1549612,"h":77310960940,"f":16809985},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"p":[{"n":"terminate","p":262145}],"n":"AsSpan","o":"@$1","d":1549612,"h":90195862828,"f":16777217},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"n":"AsSpan","d":1549612,"h":94490830124,"f":16777217},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"p":[{"n":"start","p":655361}],"n":"AsSpan","o":"@$3","d":1549612,"h":98785797420,"f":16777217},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"p":[{"n":"start","p":655361},{"n":"length","p":655361}],"n":"AsSpan","o":"@$2","d":1549612,"h":103080764716,"f":16777217},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryCopyTo","d":1549612,"h":107375732012,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":458753},{"n":"count","p":655361}],"n":"Insert","d":1549612,"h":111670699308,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361},{"n":"s","p":1310721}],"n":"Insert","o":"@$1","d":1549612,"h":115965666604,"f":16777217},{"r":65537,"p":[{"n":"c","p":458753}],"n":"Append","o":"@$1","d":1549612,"h":120260633900,"f":16777217},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"Append","o":"@$3","d":1549612,"h":124555601196,"f":16777217},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AppendSlow","d":1549612,"h":128850568492,"f":16777218},{"r":65537,"p":[{"n":"c","p":458753},{"n":"count","p":655361}],"n":"Append","d":1549612,"h":133145535788,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"Append","o":"@$2","d":1549612,"h":137440503084,"f":16777217},{"r":$.$$.System.Span$$($.$$.System.Char).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpan","d":1549612,"h":141735470380,"f":16777217},{"r":65537,"p":[{"n":"c","p":458753}],"n":"GrowAndAppend","d":1549612,"h":146030437676,"f":16777218},{"r":65537,"p":[{"n":"additionalCapacityBeyondPos","p":655361}],"n":"Grow","d":1549612,"h":150325404972,"f":16777218},{"r":65537,"n":"Dispose","d":1549612,"h":154620372268,"f":16777217}],"l":[{"t":$.$typeArray($.$$.System.Char).$h,"n":"_arrayToReturnToPool","d":1549612,"h":12886451500,"f":4194306},{"t":$.$$.System.Span$$($.$$.System.Char).$h,"n":"_chars","d":1549612,"h":17181418796,"f":4194306},{"t":655361,"n":"_pos","d":1549612,"h":21476386092,"f":4194306}],"c":[{"p":[{"n":"initialBuffer","p":$.$$.System.Span$$($.$$.System.Char).$h}],"n":".ctor","o":"$ctor$4","d":1549612,"h":25771353388,"f":16777217},{"p":[{"n":"initialCapacity","p":655361}],"n":".ctor","o":"$ctor$3","d":1549612,"h":30066320684,"f":16777217},{"n":".ctor","o":"$ctor$2","d":1549612,"h":158915339564,"f":16777217}],"h":1549612}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Text.ValueStringBuilder`; }
        });
        
        $asm.$str("$spu.System.Collections.Generic.ValueListBuilder<>", (T) => $asm.$gt("$spu.System.Collections.Generic.ValueListBuilder<>", [T], ($self) => class ValueListBuilder$$ extends $.$$.System.ValueType
        {
            /*Span<T>*/  get _span() { return this.$getField(0, 8); }
            /*Span<T>*/  set _span(value) { this.$setField(0, 8, value); }
            /*T[]?*/  get _arrayFromPool() { return this.$getField(8, 4); }
            /*T[]?*/  set _arrayFromPool(value) { this.$setField(8, 4, value); }
            /*int*/  get _pos() { return this.$getField(12, 4); }
            /*int*/  set _pos(value) { this.$setField(12, 4, value); }
            $ctor$4(/*Span<T?>*/ scratchBuffer)
            {
                super.$ctor$1();
                {
                    this._span = scratchBuffer;
                }
                return this;
            }
            $ctor$3(/*int*/ capacity)
            {
                super.$ctor$1();
                {
                    this.Grow(capacity);
                }
                return this;
            }
            /*int */ get Length()
            {
                return this._pos;
            }
            /*int */ set Length(value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(value >= 0, "value >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(value <= this._span.Length, "value <= _span.Length");
                this._pos = value;
            }
            /*ref T*/ get_Item(/*int*/ index)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(index < this._pos, "index < _pos");
                return this._span.get_Item(index);
            }
            /*void */ Append$1(/*T*/ item)
            {
                /*int*/ let pos = this._pos;
                /*Span<T>*/ let span = this._span;
                if ((pos >>> 0) < (span.Length >>> 0))
                {
                    span.get_Item(pos).$v = item;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AddWithResize(item);
                }
            }
            /*void */ Append(/*scoped ReadOnlySpan<T>*/ source)
            {
                /*int*/ let pos = this._pos;
                /*Span<T>*/ let span = this._span;
                if (source.Length === 1 && (pos >>> 0) < (span.Length >>> 0))
                {
                    span.get_Item(pos).$v = source.get_Item(0).$v;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendMultiChar(source);
                }
            }
            /*void */ AppendMultiChar(/*scoped ReadOnlySpan<T>*/ source)
            {
                if (((((this._pos + source.Length) | 0)) >>> 0) > (this._span.Length >>> 0))
                {
                    this.Grow(((((this._span.Length - this._pos) | 0) + source.Length) | 0));
                }
                source.CopyTo(this._span.Slice$1(this._pos));
                this._pos += source.Length;
            }
            /*void */ Insert(/*int*/ index, /*scoped ReadOnlySpan<T>*/ source)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(index === 0, "Implementation currently only supports index == 0");
                if (((((this._pos + source.Length) | 0)) >>> 0) > (this._span.Length >>> 0))
                {
                    this.Grow(source.Length);
                }
                this._span.Slice(0, this._pos).CopyTo(this._span.Slice$1(source.Length));
                source.CopyTo(this._span);
                this._pos += source.Length;
            }
            /*Span<T> */ AppendSpan(/*int*/ length)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(length >= 0, "length >= 0");
                /*int*/ let pos = this._pos;
                /*Span<T>*/ let span = this._span;
                if ($.$cast((pos >>> 0), $.$$.System.UInt64) + $.$cast((length >>> 0), $.$$.System.UInt64) <= $.$cast((span.Length >>> 0), $.$$.System.UInt64))
                {
                    this._pos = ((pos + length) | 0);
                    return span.Slice(pos, length);
                }
                else 
                {
                    return this.AppendSpanWithGrow(length);
                }
            }
            /*Span<T> */ AppendSpanWithGrow(/*int*/ length)
            {
                /*int*/ let pos = this._pos;
                this.Grow(((((this._span.Length - pos) | 0) + length) | 0));
                this._pos += length;
                return this._span.Slice(pos, length);
            }
            /*void */ AddWithResize(/*T*/ item)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._pos === this._span.Length, "_pos == _span.Length");
                /*int*/ let pos = this._pos;
                this.Grow(1);
                this._span.get_Item(pos).$v = item;
                this._pos = ((pos + 1) | 0);
            }
            /*ReadOnlySpan<T> */ AsSpan()
            {
                return $.$$.System.Span$$(T).op_Implicit(this._span.Slice(0, this._pos));
            }
            /*bool */ TryCopyTo(/*Span<T>*/ destination, /*out int*/ itemsWritten)
            {
                if (this._span.Slice(0, this._pos).TryCopyTo(destination))
                {
                    itemsWritten.$v = this._pos;
                    return true;
                }
                itemsWritten.$v = 0;
                return false;
            }
            /*void */ Dispose()
            {
                /*T[]?*/ let toReturn = this._arrayFromPool;
                if (toReturn !== null)
                {
                    this._arrayFromPool = null;
                    if (!T.$type.IsPrimitive)
                    {
                        $.$$.System.Array.Clear(toReturn, 0, this._pos);
                    }
                    $.$$.System.Buffers.ArrayPool$$(T).Shared.Return(toReturn, false);
                }
            }
            /*void */ Grow(/*int*/ additionalCapacityRequired)
            {
                /*int*/ let ArrayMaxLength = 2147483591;
                /*int*/ let nextCapacity = $.$$.System.Math.Max$4(this._span.Length !== 0 ? ((this._span.Length * 2) | 0) : 4, ((this._span.Length + additionalCapacityRequired) | 0));
                if ((nextCapacity >>> 0) > ArrayMaxLength)
                {
                    nextCapacity = $.$$.System.Math.Max$4($.$$.System.Math.Max$4(((this._span.Length + 1) | 0), ArrayMaxLength), this._span.Length);
                }
                /*T[]*/ let array = $.$$.System.Buffers.ArrayPool$$(T).Shared.Rent(nextCapacity);
                this._span.CopyTo($.$$.System.Span$$(T).op_Implicit$2(array));
                /*T[]?*/ let toReturn = this._arrayFromPool;
                this._span = $.$$.System.Span$$(T).op_Implicit$2(this._arrayFromPool = array);
                if (toReturn !== null)
                {
                    if (!T.$type.IsPrimitive)
                    {
                        $.$$.System.Array.Clear(toReturn, 0, this._pos);
                    }
                    $.$$.System.Buffers.ArrayPool$$(T).Shared.Return(toReturn, false);
                }
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._span = this._span.Clone();
                copy._arrayFromPool = this._arrayFromPool;
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._span = $.$default($.$$.System.Span$$(T));
                this._arrayFromPool = null;
                this._pos = 0;
            }
            static $h = 107820;
            static $g = 1;
            static $z = 16;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":83886081},"n":"Length","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":T?.$h??1507328,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153}],"m":[{"r":65537,"p":[{"n":"item","p":T?.$h??1507328}],"n":"Append","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777217},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$(T).$h}],"n":"Append","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777217},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$(T).$h}],"n":"AppendMultiChar","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777218},{"r":65537,"p":[{"n":"index","p":655361},{"n":"source","p":$.$$.System.ReadOnlySpan$$(T).$h}],"n":"Insert","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777217},{"r":$.$$.System.Span$$(T).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpan","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16777217},{"r":$.$$.System.Span$$(T).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpanWithGrow","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16777218},{"r":65537,"p":[{"n":"item","p":T?.$h??1507328}],"n":"AddWithResize","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777218},{"r":$.$$.System.ReadOnlySpan$$(T).$h,"n":"AsSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777217},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$(T).$h},{"n":"itemsWritten","p":655361,"f":2}],"n":"TryCopyTo","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16777217},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777217},{"r":65537,"p":[{"n":"additionalCapacityRequired","p":655361,"f":65,"v":1}],"n":"Grow","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777218}],"l":[{"t":$.$$.System.Span$$(T).$h,"n":"_span","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$typeArray(T).$h,"n":"_arrayFromPool","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":655361,"n":"_pos","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306}],"c":[{"p":[{"n":"scratchBuffer","p":$.$$.System.Span$$(T).$h}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217},{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":16777217}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Collections.Generic.ValueListBuilder<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$spu.System.FileStyleUriParser", ($self) => class FileStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.FileUri.Flags);
                {
                }
                return this;
            }
            static $h = 238892;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2663724,"c":[{"n":".ctor","o":"$ctor$3","d":238892,"h":4295206188,"f":16777217}],"h":238892}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.FileStyleUriParser`; }
        });
        
        $asm.$cls("$spu.System.NewsStyleUriParser", ($self) => class NewsStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.NewsUri.Flags);
                {
                }
                return this;
            }
            static $h = 1221932;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2663724,"c":[{"n":".ctor","o":"$ctor$3","d":1221932,"h":4296189228,"f":16777217}],"h":1221932}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.NewsStyleUriParser`; }
        });
        
        $asm.$cls("$spu.System.GopherStyleUriParser", ($self) => class GopherStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.GopherUri.Flags);
                {
                }
                return this;
            }
            static $h = 501036;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2663724,"c":[{"n":".ctor","o":"$ctor$3","d":501036,"h":4295468332,"f":16777217}],"h":501036}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.GopherStyleUriParser`; }
        });
        
        $asm.$cls("$spu.System.LdapStyleUriParser", ($self) => class LdapStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.LdapUri.Flags);
                {
                }
                return this;
            }
            static $h = 894252;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2663724,"c":[{"n":".ctor","o":"$ctor$3","d":894252,"h":4295861548,"f":16777217}],"h":894252}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.LdapStyleUriParser`; }
        });
        
        $asm.$cls("$spu.System.NetPipeStyleUriParser", ($self) => class NetPipeStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.NetPipeUri.Flags);
                {
                }
                return this;
            }
            static $h = 1090860;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2663724,"c":[{"n":".ctor","o":"$ctor$3","d":1090860,"h":4296058156,"f":16777217}],"h":1090860}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.NetPipeStyleUriParser`; }
        });
        
        $asm.$cls("$spu.System.NetTcpStyleUriParser", ($self) => class NetTcpStyleUriParser extends $.$spu.System.UriParser
        {
            $ctor$3()
            {
                super.$ctor$2($.$spu.System.UriParser.NetTcpUri.Flags);
                {
                }
                return this;
            }
            static $h = 1156396;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2663724,"c":[{"n":".ctor","o":"$ctor$3","d":1156396,"h":4296123692,"f":16777217}],"h":1156396}; }
            static get $b() { return $.$spu.System.UriParser; }
            static get $fullName() { return `System.NetTcpStyleUriParser`; }
        });
        
        $asm.$str("$spu.System.UriKind", ($self) => class UriKind extends $.$$.System.Enum
        {
            static RelativeOrAbsolute = 0;
            static Absolute = 1;
            static Relative = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "RelativeOrAbsolute": 0n,
                    "Absolute": 1n,
                    "Relative": 2n
                };
            }
            static $h = 2598188;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2598188,"n":"RelativeOrAbsolute","d":2598188,"h":4297565484,"f":4194337},{"t":2598188,"n":"Absolute","d":2598188,"h":8592532780,"f":4194337},{"t":2598188,"n":"Relative","d":2598188,"h":12887500076,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2598188,"h":17182467372,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2598188}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.UriKind`; }
        });
        
        $asm.$str("$spu.System.UriHostNameType", ($self) => class UriHostNameType extends $.$$.System.Enum
        {
            static Unknown = 0;
            static Basic = 1;
            static Dns = 2;
            static IPv4 = 3;
            static IPv6 = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Basic": 1n,
                    "Dns": 2n,
                    "IPv4": 3n,
                    "IPv6": 4n
                };
            }
            static $h = 2532652;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2532652,"n":"Unknown","d":2532652,"h":4297499948,"f":4194337},{"t":2532652,"n":"Basic","d":2532652,"h":8592467244,"f":4194337},{"t":2532652,"n":"Dns","d":2532652,"h":12887434540,"f":4194337},{"t":2532652,"n":"IPv4","d":2532652,"h":17182401836,"f":4194337},{"t":2532652,"n":"IPv6","d":2532652,"h":21477369132,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2532652,"h":25772336428,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2532652}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.UriHostNameType`; }
        });
        
        $asm.$str("$spu.System.UriPartial", ($self) => class UriPartial extends $.$$.System.Enum
        {
            static Scheme = 0;
            static Authority = 1;
            static Path = 2;
            static Query = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Scheme": 0n,
                    "Authority": 1n,
                    "Path": 2n,
                    "Query": 3n
                };
            }
            static $h = 2794796;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2794796,"n":"Scheme","d":2794796,"h":4297762092,"f":4194337},{"t":2794796,"n":"Authority","d":2794796,"h":8592729388,"f":4194337},{"t":2794796,"n":"Path","d":2794796,"h":12887696684,"f":4194337},{"t":2794796,"n":"Query","d":2794796,"h":17182663980,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2794796,"h":21477631276,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2794796}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.UriPartial`; }
        });
        
        $asm.$str("$spu.System.GenericUriParserOptions", ($self) => class GenericUriParserOptions extends $.$$.System.Enum
        {
            static Default = 0;
            static GenericAuthority = 1;
            static AllowEmptyAuthority = 2;
            static NoUserInfo = 4;
            static NoPort = 8;
            static NoQuery = 16;
            static NoFragment = 32;
            static DontConvertPathBackslashes = 64;
            static DontCompressPath = 128;
            static DontUnescapePathDotsAndSlashes = 256;
            static Idn = 512;
            static IriParsing = 1024;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "GenericAuthority": 1n,
                    "AllowEmptyAuthority": 2n,
                    "NoUserInfo": 4n,
                    "NoPort": 8n,
                    "NoQuery": 16n,
                    "NoFragment": 32n,
                    "DontConvertPathBackslashes": 64n,
                    "DontCompressPath": 128n,
                    "DontUnescapePathDotsAndSlashes": 256n,
                    "Idn": 512n,
                    "IriParsing": 1024n
                };
            }
            static $h = 435500;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":435500,"n":"Default","d":435500,"h":4295402796,"f":4194337},{"t":435500,"n":"GenericAuthority","d":435500,"h":8590370092,"f":4194337},{"t":435500,"n":"AllowEmptyAuthority","d":435500,"h":12885337388,"f":4194337},{"t":435500,"n":"NoUserInfo","d":435500,"h":17180304684,"f":4194337},{"t":435500,"n":"NoPort","d":435500,"h":21475271980,"f":4194337},{"t":435500,"n":"NoQuery","d":435500,"h":25770239276,"f":4194337},{"t":435500,"n":"NoFragment","d":435500,"h":30065206572,"f":4194337},{"t":435500,"n":"DontConvertPathBackslashes","d":435500,"h":34360173868,"f":4194337},{"t":435500,"n":"DontCompressPath","d":435500,"h":38655141164,"f":4194337},{"t":435500,"n":"DontUnescapePathDotsAndSlashes","d":435500,"h":42950108460,"f":4194337},{"t":435500,"n":"Idn","d":435500,"h":47245075756,"f":4194337},{"t":435500,"n":"IriParsing","d":435500,"h":51540043052,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":435500,"h":55835010348,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":435500,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.GenericUriParserOptions`; }
        });
        
        $asm.$str("$spu.System.UriComponents", ($self) => class UriComponents extends $.$$.System.Enum
        {
            static Scheme = 1;
            static UserInfo = 2;
            static Host = 4;
            static Port = 8;
            static Path = 16;
            static Query = 32;
            static Fragment = 64;
            static StrongPort = 128;
            static NormalizedHost = 256;
            static KeepDelimiter = 1073741824;
            static SerializationInfoString = -2147483648;
            static AbsoluteUri = 127;
            static HostAndPort = 132;
            static StrongAuthority = 134;
            static SchemeAndServer = 13;
            static HttpRequestUrl = 61;
            static PathAndQuery = 48;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Scheme": 1n,
                    "UserInfo": 2n,
                    "Host": 4n,
                    "Port": 8n,
                    "Path": 16n,
                    "Query": 32n,
                    "Fragment": 64n,
                    "StrongPort": 128n,
                    "NormalizedHost": 256n,
                    "KeepDelimiter": 1073741824n,
                    "SerializationInfoString": -2147483648n,
                    "AbsoluteUri": 127n,
                    "HostAndPort": 132n,
                    "StrongAuthority": 134n,
                    "SchemeAndServer": 13n,
                    "HttpRequestUrl": 61n,
                    "PathAndQuery": 48n
                };
            }
            static $h = 2204972;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2204972,"n":"Scheme","d":2204972,"h":4297172268,"f":4194337},{"t":2204972,"n":"UserInfo","d":2204972,"h":8592139564,"f":4194337},{"t":2204972,"n":"Host","d":2204972,"h":12887106860,"f":4194337},{"t":2204972,"n":"Port","d":2204972,"h":17182074156,"f":4194337},{"t":2204972,"n":"Path","d":2204972,"h":21477041452,"f":4194337},{"t":2204972,"n":"Query","d":2204972,"h":25772008748,"f":4194337},{"t":2204972,"n":"Fragment","d":2204972,"h":30066976044,"f":4194337},{"t":2204972,"n":"StrongPort","d":2204972,"h":34361943340,"f":4194337},{"t":2204972,"n":"NormalizedHost","d":2204972,"h":38656910636,"f":4194337},{"t":2204972,"n":"KeepDelimiter","d":2204972,"h":42951877932,"f":4194337},{"t":2204972,"n":"SerializationInfoString","d":2204972,"h":47246845228,"f":4194337},{"t":2204972,"n":"AbsoluteUri","d":2204972,"h":51541812524,"f":4194337},{"t":2204972,"n":"HostAndPort","d":2204972,"h":55836779820,"f":4194337},{"t":2204972,"n":"StrongAuthority","d":2204972,"h":60131747116,"f":4194337},{"t":2204972,"n":"SchemeAndServer","d":2204972,"h":64426714412,"f":4194337},{"t":2204972,"n":"HttpRequestUrl","d":2204972,"h":68721681708,"f":4194337},{"t":2204972,"n":"PathAndQuery","d":2204972,"h":73016649004,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2204972,"h":77311616300,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2204972,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.UriComponents`; }
        });
        
        $asm.$str("$spu.System.UriFormat", ($self) => class UriFormat extends $.$$.System.Enum
        {
            static UriEscaped = 1;
            static Unescaped = 2;
            static SafeUnescaped = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "UriEscaped": 1n,
                    "Unescaped": 2n,
                    "SafeUnescaped": 3n
                };
            }
            static $h = 2336044;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2336044,"n":"UriEscaped","d":2336044,"h":4297303340,"f":4194337},{"t":2336044,"n":"Unescaped","d":2336044,"h":8592270636,"f":4194337},{"t":2336044,"n":"SafeUnescaped","d":2336044,"h":12887237932,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2336044,"h":17182205228,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2336044}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.UriFormat`; }
        });
        
        $asm.$str("$spu.System.ParsingError", ($self) => class ParsingError extends $.$$.System.Enum
        {
            static None = 0;
            static BadFormat = 1;
            static BadScheme = 2;
            static BadAuthority = 3;
            static EmptyUriString = 4;
            static LastErrorOkayForRelativeUris = 5;
            static SchemeLimit = 6;
            static MustRootedPath = 7;
            static BadHostName = 8;
            static NonEmptyHost = 9;
            static BadPort = 10;
            static BadAuthorityTerminator = 11;
            static CannotCreateRelative = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "BadFormat": 1n,
                    "BadScheme": 2n,
                    "BadAuthority": 3n,
                    "EmptyUriString": 4n,
                    "LastErrorOkayForRelativeUris": 5n,
                    "SchemeLimit": 6n,
                    "MustRootedPath": 7n,
                    "BadHostName": 8n,
                    "NonEmptyHost": 9n,
                    "BadPort": 10n,
                    "BadAuthorityTerminator": 11n,
                    "CannotCreateRelative": 12n
                };
            }
            static $h = 1353004;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1353004,"n":"None","d":1353004,"h":4296320300,"f":4194337},{"t":1353004,"n":"BadFormat","d":1353004,"h":8591287596,"f":4194337},{"t":1353004,"n":"BadScheme","d":1353004,"h":12886254892,"f":4194337},{"t":1353004,"n":"BadAuthority","d":1353004,"h":17181222188,"f":4194337},{"t":1353004,"n":"EmptyUriString","d":1353004,"h":21476189484,"f":4194337},{"t":1353004,"n":"LastErrorOkayForRelativeUris","d":1353004,"h":25771156780,"f":4194337},{"t":1353004,"n":"SchemeLimit","d":1353004,"h":30066124076,"f":4194337},{"t":1353004,"n":"MustRootedPath","d":1353004,"h":34361091372,"f":4194337},{"t":1353004,"n":"BadHostName","d":1353004,"h":38656058668,"f":4194337},{"t":1353004,"n":"NonEmptyHost","d":1353004,"h":42951025964,"f":4194337},{"t":1353004,"n":"BadPort","d":1353004,"h":47245993260,"f":4194337},{"t":1353004,"n":"BadAuthorityTerminator","d":1353004,"h":51540960556,"f":4194337},{"t":1353004,"n":"CannotCreateRelative","d":1353004,"h":55835927852,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1353004,"h":60130895148,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1353004}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ParsingError`; }
        });
        
        $asm.$str("$spu.System.UnescapeMode", ($self) => class UnescapeMode extends $.$$.System.Enum
        {
            static CopyOnly = 0;
            static Escape = 1;
            static Unescape = 2;
            static EscapeUnescape = 3;
            static V1ToStringFlag = 4;
            static UnescapeAll = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "CopyOnly": 0n,
                    "Escape": 1n,
                    "Unescape": 2n,
                    "EscapeUnescape": 3n,
                    "V1ToStringFlag": 4n,
                    "UnescapeAll": 8n
                };
            }
            static $h = 1680684;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1680684,"n":"CopyOnly","d":1680684,"h":4296647980,"f":4194337},{"t":1680684,"n":"Escape","d":1680684,"h":8591615276,"f":4194337},{"t":1680684,"n":"Unescape","d":1680684,"h":12886582572,"f":4194337},{"t":1680684,"n":"EscapeUnescape","d":1680684,"h":17181549868,"f":4194337},{"t":1680684,"n":"V1ToStringFlag","d":1680684,"h":21476517164,"f":4194337},{"t":1680684,"n":"UnescapeAll","d":1680684,"h":25771484460,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1680684,"h":30066451756,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1680684,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.UnescapeMode`; }
        });
        
        $asm.$str("$spu.System.UriSyntaxFlags", ($self) => class UriSyntaxFlags extends $.$$.System.Enum
        {
            static None = 0;
            static MustHaveAuthority = 1;
            static OptionalAuthority = 2;
            static MayHaveUserInfo = 4;
            static MayHavePort = 8;
            static MayHavePath = 16;
            static MayHaveQuery = 32;
            static MayHaveFragment = 64;
            static AllowEmptyHost = 128;
            static AllowUncHost = 256;
            static AllowDnsHost = 512;
            static AllowIPv4Host = 1024;
            static AllowIPv6Host = 2048;
            static AllowAnInternetHost = 3584;
            static AllowAnyOtherHost = 4096;
            static FileLikeUri = 8192;
            static MailToLikeUri = 16384;
            static V1_UnknownUri = 65536;
            static SimpleUserSyntax = 131072;
            static AllowDOSPath = 1048576;
            static PathIsRooted = 2097152;
            static ConvertPathSlashes = 4194304;
            static CompressPath = 8388608;
            static CanonicalizeAsFilePath = 16777216;
            static UnEscapeDotsAndSlashes = 33554432;
            static AllowIdn = 67108864;
            static AllowIriParsing = 268435456;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "MustHaveAuthority": 1n,
                    "OptionalAuthority": 2n,
                    "MayHaveUserInfo": 4n,
                    "MayHavePort": 8n,
                    "MayHavePath": 16n,
                    "MayHaveQuery": 32n,
                    "MayHaveFragment": 64n,
                    "AllowEmptyHost": 128n,
                    "AllowUncHost": 256n,
                    "AllowDnsHost": 512n,
                    "AllowIPv4Host": 1024n,
                    "AllowIPv6Host": 2048n,
                    "AllowAnInternetHost": 3584n,
                    "AllowAnyOtherHost": 4096n,
                    "FileLikeUri": 8192n,
                    "MailToLikeUri": 16384n,
                    "V1_UnknownUri": 65536n,
                    "SimpleUserSyntax": 131072n,
                    "AllowDOSPath": 1048576n,
                    "PathIsRooted": 2097152n,
                    "ConvertPathSlashes": 4194304n,
                    "CompressPath": 8388608n,
                    "CanonicalizeAsFilePath": 16777216n,
                    "UnEscapeDotsAndSlashes": 33554432n,
                    "AllowIdn": 67108864n,
                    "AllowIriParsing": 268435456n
                };
            }
            static $h = 2860332;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2860332,"n":"None","d":2860332,"h":4297827628,"f":4194337},{"t":2860332,"n":"MustHaveAuthority","d":2860332,"h":8592794924,"f":4194337},{"t":2860332,"n":"OptionalAuthority","d":2860332,"h":12887762220,"f":4194337},{"t":2860332,"n":"MayHaveUserInfo","d":2860332,"h":17182729516,"f":4194337},{"t":2860332,"n":"MayHavePort","d":2860332,"h":21477696812,"f":4194337},{"t":2860332,"n":"MayHavePath","d":2860332,"h":25772664108,"f":4194337},{"t":2860332,"n":"MayHaveQuery","d":2860332,"h":30067631404,"f":4194337},{"t":2860332,"n":"MayHaveFragment","d":2860332,"h":34362598700,"f":4194337},{"t":2860332,"n":"AllowEmptyHost","d":2860332,"h":38657565996,"f":4194337},{"t":2860332,"n":"AllowUncHost","d":2860332,"h":42952533292,"f":4194337},{"t":2860332,"n":"AllowDnsHost","d":2860332,"h":47247500588,"f":4194337},{"t":2860332,"n":"AllowIPv4Host","d":2860332,"h":51542467884,"f":4194337},{"t":2860332,"n":"AllowIPv6Host","d":2860332,"h":55837435180,"f":4194337},{"t":2860332,"n":"AllowAnInternetHost","d":2860332,"h":60132402476,"f":4194337},{"t":2860332,"n":"AllowAnyOtherHost","d":2860332,"h":64427369772,"f":4194337},{"t":2860332,"n":"FileLikeUri","d":2860332,"h":68722337068,"f":4194337},{"t":2860332,"n":"MailToLikeUri","d":2860332,"h":73017304364,"f":4194337},{"t":2860332,"n":"V1_UnknownUri","d":2860332,"h":77312271660,"f":4194337},{"t":2860332,"n":"SimpleUserSyntax","d":2860332,"h":81607238956,"f":4194337},{"t":2860332,"n":"AllowDOSPath","d":2860332,"h":85902206252,"f":4194337},{"t":2860332,"n":"PathIsRooted","d":2860332,"h":90197173548,"f":4194337},{"t":2860332,"n":"ConvertPathSlashes","d":2860332,"h":94492140844,"f":4194337},{"t":2860332,"n":"CompressPath","d":2860332,"h":98787108140,"f":4194337},{"t":2860332,"n":"CanonicalizeAsFilePath","d":2860332,"h":103082075436,"f":4194337},{"t":2860332,"n":"UnEscapeDotsAndSlashes","d":2860332,"h":107377042732,"f":4194337},{"t":2860332,"n":"AllowIdn","d":2860332,"h":111672010028,"f":4194337},{"t":2860332,"n":"AllowIriParsing","d":2860332,"h":115966977324,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2860332,"h":120261944620,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2860332,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.UriSyntaxFlags`; }
        });
        
        $asm.$cls("$spu.System.UriFormatException", ($self) => class UriFormatException extends $.$$.System.FormatException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ textString)
            {
                super.$ctor$12(textString);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ textString, /*Exception?*/ e)
            {
                super.$ctor$11(textString, e);
                {
                }
                return this;
            }
            $ctor$14(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.$ctor$10(serializationInfo, streamingContext);
                {
                }
                return this;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.GetObjectData(serializationInfo, streamingContext);
            }
            static $h = 2401580;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47775745,"h":2401580}; }
            static get $b() { return $.$$.System.FormatException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.UriFormatException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))