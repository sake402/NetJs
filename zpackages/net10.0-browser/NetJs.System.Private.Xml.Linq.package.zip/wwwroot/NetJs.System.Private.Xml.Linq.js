
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Private.Xml.Linq", 
    {"h":59344,"f":"System.Private.Xml.Linq","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Private.Xml.Linq","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Private.Xml.Linq","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$spxl.System.Xml.Linq.XObject", ($self) => class XObject extends $.$$.System.Object
        {
            /*XContainer?*/ parent = null;
            /*object?*/ annotations = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string */ get BaseUri()
            {
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        break;
                    }
                    /*BaseUriAnnotation?*/ let a = o.Annotation$1($.$spxl.System.Xml.Linq.BaseUriAnnotation);
                    if (a !== null)
                    {
                        return a.baseUri;
                    }
                    o = o.parent;
                }
                return $.$$.System.String.Empty;
            }
            /*XDocument? */ get Document()
            {
                /*XObject*/ let n = this;
                while(n.parent !== null)
                {
                    n = n.parent;
                }
                /*XDocument?*/ let doc = $.$as(n, $.$spxl.System.Xml.Linq.XDocument);
                return doc;
            }
            /*XElement? */ get Parent()
            {
                return $.$as(this.parent, $.$spxl.System.Xml.Linq.XElement);
            }
            /*void */ AddAnnotation(/*object*/ annotation)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(annotation, "annotation");
                if (this.annotations === null)
                {
                    this.annotations = $.$is(annotation, $.$typeArray($.$$.System.Object)) ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [annotation], [-1], null) : annotation;
                }
                else 
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                    if (a === null)
                    {
                        this.annotations = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [this.annotations, annotation], [-1], null);
                    }
                    else 
                    {
                        /*int*/ let i = 0;
                        while(i < a.length && $.$$.System.Array.$ReadT1.call(a, i) !== null)
                        {
                            i++;
                        }
                        if (i === a.length)
                        {
                            $.$$.System.Array.Resize($.$$.System.Object, $.$ref(() => a, ($v) => a = $v, $.$typeArray($.$$.System.Object)), ((i * 2) | 0));
                            this.annotations = a;
                        }
                        $.$$.System.Array.$WriteT1.call(a, annotation, i);
                    }
                }
            }
            /*object? */ Annotation(/*Type*/ type)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                    if (a === null)
                    {
                        if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(this.annotations, type))
                        {
                            return this.annotations;
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < a.length; i++)
                        {
                            /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(obj, type))
                            {
                                return obj;
                            }
                        }
                    }
                }
                return null;
            }
            /*object? */ AnnotationForSealedType(/*Type*/ type)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Inequality$1(type, null), "type != null");
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                    if (a === null)
                    {
                        if ($.$$.System.Type.op_Equality$1($.$$.System.Object.GetType.call(this.annotations), type))
                        {
                            return this.annotations;
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < a.length; i++)
                        {
                            /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if ($.$$.System.Type.op_Equality$1($.$$.System.Object.GetType.call(obj), type))
                            {
                                return obj;
                            }
                        }
                    }
                }
                return null;
            }
            /*T? */ Annotation$1(T)
            {
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                    if (a === null)
                    {
                        return $.$as(this.annotations, T);
                    }
                    for(/*int*/ let i = 0; i < a.length; i++)
                    {
                        /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(a, i);
                        if (obj === null)
                        {
                            break;
                        }
                        /*T?*/ let result = $.$as(obj, T);
                        if ($.$box(result, T) !== null)
                        {
                            return result;
                        }
                    }
                }
                return null;
            }
            /*IEnumerable<object> */ Annotations(/*Type*/ type)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                return this.AnnotationsIterator(type);
            }
            /*IEnumerable<object> */ AnnotationsIterator(/*Type*/ type)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (this.annotations !== null)
                    {
                        /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                        if (a === null)
                        {
                            if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(this.annotations, type))
                            {
                                yield this.annotations;
                            }
                        }
                        else 
                        {
                            for(/*int*/ let i = 0; i < a.length; i++)
                            {
                                /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(a, i);
                                if (obj === null)
                                {
                                    break;
                                }
                                if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(obj, type))
                                {
                                    yield obj;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*IEnumerable<T> */ Annotations$1(T)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (this.annotations !== null)
                    {
                        /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                        if (a === null)
                        {
                            /*T?*/ let result = $.$as(this.annotations, T);
                            if ($.$box(result, T) !== null)
                            {
                                yield result;
                            }
                        }
                        else 
                        {
                            for(/*int*/ let i = 0; i < a.length; i++)
                            {
                                /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(a, i);
                                if (obj === null)
                                {
                                    break;
                                }
                                /*T?*/ let result = $.$as(obj, T);
                                if ($.$box(result, T) !== null)
                                {
                                    yield result;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*void */ RemoveAnnotations(/*Type*/ type)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                    if (a === null)
                    {
                        if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(this.annotations, type))
                        {
                            this.annotations = null;
                        }
                    }
                    else 
                    {
                        /*int*/ let i = 0, j = 0;
                        while(i < a.length)
                        {
                            /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if (!$.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(obj, type))
                            {
                                $.$$.System.Array.$WriteT1.call(a, obj, j++);
                            }
                            i++;
                        }
                        if (j === 0)
                        {
                            this.annotations = null;
                        }
                        else 
                        {
                            while(j < i)
                            {
                                $.$$.System.Array.$WriteT1.call(a, null, j++);
                            }
                        }
                    }
                }
            }
            /*void */ RemoveAnnotations$1(T)
            {
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                    if (a === null)
                    {
                        if ($.$is(this.annotations, T))
                        {
                            this.annotations = null;
                        }
                    }
                    else 
                    {
                        /*int*/ let i = 0, j = 0;
                        while(i < a.length)
                        {
                            /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if (!($.$is(obj, T)))
                            {
                                $.$$.System.Array.$WriteT1.call(a, obj, j++);
                            }
                            i++;
                        }
                        if (j === 0)
                        {
                            this.annotations = null;
                        }
                        else 
                        {
                            while(j < i)
                            {
                                $.$$.System.Array.$WriteT1.call(a, null, j++);
                            }
                        }
                    }
                }
            }
            /*EventHandler<XObjectChangeEventArgs>*/ add_Changed(value)
            {
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    a = new $.$spxl.System.Xml.Linq.XObjectChangeAnnotation().$ctor$1();
                    this.AddAnnotation(a);
                }
                a.changed = $.$$.System.Delegate.Combine(a.changed, value);
            }
            /*EventHandler<XObjectChangeEventArgs>*/ remove_Changed(value)
            {
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    return;
                }
                a.changed = $.$$.System.Delegate.Remove(a.changed, value);
                if (a.changing === null && a.changed === null)
                {
                    this.RemoveAnnotations$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                }
            }
            /*EventHandler<XObjectChangeEventArgs>*/ add_Changing(value)
            {
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    a = new $.$spxl.System.Xml.Linq.XObjectChangeAnnotation().$ctor$1();
                    this.AddAnnotation(a);
                }
                a.changing = $.$$.System.Delegate.Combine(a.changing, value);
            }
            /*EventHandler<XObjectChangeEventArgs>*/ remove_Changing(value)
            {
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    return;
                }
                a.changing = $.$$.System.Delegate.Remove(a.changing, value);
                if (a.changing === null && a.changed === null)
                {
                    this.RemoveAnnotations$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                }
            }
            /*bool */ System$Xml$IXmlLineInfo$HasLineInfo()
            {
                return this.Annotation$1($.$spxl.System.Xml.Linq.LineInfoAnnotation) !== null;
            }
            /*int */ get System$Xml$IXmlLineInfo$LineNumber()
            {
                /*LineInfoAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.LineInfoAnnotation);
                if (a !== null)
                {
                    return a.lineNumber;
                }
                return 0;
            }
            /*int */ get System$Xml$IXmlLineInfo$LinePosition()
            {
                /*LineInfoAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.LineInfoAnnotation);
                if (a !== null)
                {
                    return a.linePosition;
                }
                return 0;
            }
            /*bool */ get HasBaseUri()
            {
                return this.Annotation$1($.$spxl.System.Xml.Linq.BaseUriAnnotation) !== null;
            }
            /*bool */ NotifyChanged(/*object*/ sender, /*XObjectChangeEventArgs*/ e)
            {
                /*bool*/ let notify = false;
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        break;
                    }
                    /*XObjectChangeAnnotation?*/ let a = o.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                    if (a !== null)
                    {
                        notify = true;
                        a.changed?.Invoke(sender, e);
                    }
                    o = o.parent;
                }
                return notify;
            }
            /*bool */ NotifyChanging(/*object*/ sender, /*XObjectChangeEventArgs*/ e)
            {
                /*bool*/ let notify = false;
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        break;
                    }
                    /*XObjectChangeAnnotation?*/ let a = o.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                    if (a !== null)
                    {
                        notify = true;
                        a.changing?.Invoke(sender, e);
                    }
                    o = o.parent;
                }
                return notify;
            }
            /*void */ SetBaseUri(/*string*/ baseUri)
            {
                this.AddAnnotation(new $.$spxl.System.Xml.Linq.BaseUriAnnotation().$ctor$1(baseUri));
            }
            /*void */ SetLineInfo(/*int*/ lineNumber, /*int*/ linePosition)
            {
                this.AddAnnotation(new $.$spxl.System.Xml.Linq.LineInfoAnnotation().$ctor$1(lineNumber, linePosition));
            }
            /*bool */ SkipNotify()
            {
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        return true;
                    }
                    if (o.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation) !== null)
                    {
                        return false;
                    }
                    o = o.parent;
                }
            }
            /*SaveOptions */ GetSaveOptionsFromAnnotations()
            {
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        return 0/*SaveOptions.None*/;
                    }
                    /*object?*/ let saveOptions = o.AnnotationForSealedType($.$spxl.System.Xml.Linq.SaveOptions.$type);
                    if (saveOptions !== null)
                    {
                        return $.$cast(saveOptions, $.$spxl.System.Xml.Linq.SaveOptions);
                    }
                    o = o.parent;
                }
            }
            static $h = 2615248;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21477451728,"f":50331649},"n":"BaseUri","d":2615248,"h":17182484432,"f":2097153},{"p":1566672,"g":{"r":0,"d":0,"h":30067386320,"f":50331649},"n":"Document","d":2615248,"h":25772419024,"f":2097153},{"p":52869782,"g":{"r":0,"d":0,"h":38657320912,"f":50331905},"n":"NodeType","d":2615248,"h":34362353616,"f":2097409},{"p":1697744,"g":{"r":0,"d":0,"h":47247255504,"f":50331649},"n":"Parent","d":2615248,"h":42952288208,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":124556666832,"f":50331650},"n":"{13941398}.LineNumber","o":"System$Xml$IXmlLineInfo$LineNumber","d":2615248,"h":120261699536,"f":2097154},{"p":655361,"g":{"r":0,"d":0,"h":133146601424,"f":50331650},"n":"{13941398}.LinePosition","o":"System$Xml$IXmlLineInfo$LinePosition","d":2615248,"h":128851634128,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":141736536016,"f":50331656},"n":"HasBaseUri","d":2615248,"h":137441568720,"f":2097160}],"m":[{"r":65537,"p":[{"n":"annotation","p":131073}],"n":"AddAnnotation","d":2615248,"h":51542222800,"f":16777217},{"r":131073,"p":[{"n":"type","p":142475265}],"n":"Annotation","d":2615248,"h":55837190096,"f":16777217},{"r":131073,"p":[{"n":"type","p":142475265}],"n":"AnnotationForSealedType","d":2615248,"h":60132157392,"f":16777218},{"r":(T) => T.$h,"g":["T"],"n":"Annotation","o":"@$1","d":2615248,"h":64427124688,"f":16908289},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object).$h,"p":[{"n":"type","p":142475265}],"n":"Annotations","d":2615248,"h":68722091984,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object).$h,"p":[{"n":"type","p":142475265}],"n":"AnnotationsIterator","d":2615248,"h":73017059280,"f":16777218},{"r":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h,"g":["T"],"n":"Annotations","o":"@$1","d":2615248,"h":77312026576,"f":16908289},{"r":65537,"p":[{"n":"type","p":142475265}],"n":"RemoveAnnotations","d":2615248,"h":81606993872,"f":16777217},{"r":65537,"g":["T"],"n":"RemoveAnnotations","o":"@$1","d":2615248,"h":85901961168,"f":16908289},{"r":262145,"p":[{"n":"sender","p":131073},{"n":"e","p":2811856}],"n":"NotifyChanged","d":2615248,"h":146031503312,"f":16777224},{"r":262145,"p":[{"n":"sender","p":131073},{"n":"e","p":2811856}],"n":"NotifyChanging","d":2615248,"h":150326470608,"f":16777224},{"r":65537,"p":[{"n":"baseUri","p":1310721}],"n":"SetBaseUri","d":2615248,"h":154621437904,"f":16777224},{"r":65537,"p":[{"n":"lineNumber","p":655361},{"n":"linePosition","p":655361}],"n":"SetLineInfo","d":2615248,"h":158916405200,"f":16777224},{"r":262145,"n":"SkipNotify","d":2615248,"h":163211372496,"f":16777224},{"r":1042384,"n":"GetSaveOptionsFromAnnotations","d":2615248,"h":167506339792,"f":16777224}],"l":[{"t":1370064,"n":"parent","d":2615248,"h":4297582544,"f":4194312},{"t":131073,"n":"annotations","d":2615248,"h":8592549840,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$1","d":2615248,"h":12887517136,"f":16777224}],"e":[{"e":$.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h}],"n":"add_Changed","d":2615248,"h":94491895760,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":$.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h}],"n":"remove_Changed","d":2615248,"h":98786863056,"f":285212673},"n":"Changed","d":2615248,"h":90196928464,"f":8388609},{"e":$.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h}],"n":"add_Changing","d":2615248,"h":107376797648,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":$.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h}],"n":"remove_Changing","d":2615248,"h":111671764944,"f":285212673},"n":"Changing","d":2615248,"h":103081830352,"f":8388609}],"i":[13941398],"h":2615248}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XObject`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNode", ($self) => class XNode extends $.$spxl.System.Xml.Linq.XObject
        {
            /*XNode?*/ next = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*XNode? */ get NextNode()
            {
                return this.parent === null || this === this.parent.content ? null : this.next;
            }
            /*XNode? */ get PreviousNode()
            {
                if (this.parent === null)
                {
                    return null;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this.parent.content !== null, "parent.content != null");
                /*XNode*/ let n = ($.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode)).next;
                /*XNode?*/ let p = null;
                while(n !== this)
                {
                    p = n;
                    n = n.next;
                }
                return p;
            }
            /*XNodeDocumentOrderComparer*/ static DocumentOrderComparer$ = null;
            static /*XNodeDocumentOrderComparer */ get DocumentOrderComparer()
            {
                return $.$spxl.System.Xml.Linq.XNode.DocumentOrderComparer$ ??= new $.$spxl.System.Xml.Linq.XNodeDocumentOrderComparer().$ctor$1();
            }
            /*XNodeEqualityComparer*/ static EqualityComparer$ = null;
            static /*XNodeEqualityComparer */ get EqualityComparer()
            {
                return $.$spxl.System.Xml.Linq.XNode.EqualityComparer$ ??= new $.$spxl.System.Xml.Linq.XNodeEqualityComparer().$ctor$1();
            }
            /*void */ AddAfterSelf(/*object?*/ content)
            {
                if (this.parent === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$3(this.parent, this).Add(content);
            }
            /*void */ AddAfterSelf$1(/*params object?[]*/ content)
            {
                this.AddAfterSelf($.$cast(content, $.$$.System.Object));
            }
            /*void */ AddBeforeSelf(/*object?*/ content)
            {
                if (this.parent === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                /*XNode?*/ let p = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                while(p.next !== this)
                {
                    p = p.next;
                }
                if (p === this.parent.content)
                {
                    p = null;
                }
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$3(this.parent, p).Add(content);
            }
            /*void */ AddBeforeSelf$1(/*params object?[]*/ content)
            {
                this.AddBeforeSelf($.$cast(content, $.$$.System.Object));
            }
            /*IEnumerable<XElement> */ Ancestors()
            {
                return this.GetAncestors(null, false);
            }
            /*IEnumerable<XElement> */ Ancestors$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetAncestors(name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*int */ CompareDocumentOrder(/*XNode?*/ n1, /*XNode?*/ n2)
            {
                if (n1 === n2)
                {
                    return 0;
                }
                if (n1 === null)
                {
                    return -1;
                }
                if (n2 === null)
                {
                    return 1;
                }
                if (n1.parent !== n2.parent)
                {
                    /*int*/ let height = 0;
                    /*XNode*/ let p1 = n1;
                    while(p1.parent !== null)
                    {
                        p1 = p1.parent;
                        height++;
                    }
                    /*XNode*/ let p2 = n2;
                    while(p2.parent !== null)
                    {
                        p2 = p2.parent;
                        height--;
                    }
                    if (p1 !== p2)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingAncestor);
                    }
                    if (height < 0)
                    {
                        do
                        {
                            n2 = n2.parent;
                            height++;
                        }
                        while(height !== 0);
                        if (n1 === n2)
                        {
                            return -1;
                        }
                    }
                    else if (height > 0)
                    {
                        do
                        {
                            n1 = n1.parent;
                            height--;
                        }
                        while(height !== 0);
                        if (n1 === n2)
                        {
                            return 1;
                        }
                    }
                    while(n1.parent !== n2.parent)
                    {
                        n1 = n1.parent;
                        n2 = n2.parent;
                    }
                }
                else if (n1.parent === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingAncestor);
                }
                /*XNode*/ let n = $.$cast(n1.parent.content, $.$spxl.System.Xml.Linq.XNode);
                while(true)
                {
                    n = n.next;
                    if (n === n1)
                    {
                        return -1;
                    }
                    if (n === n2)
                    {
                        return 1;
                    }
                }
            }
            /*XmlReader */ CreateReader()
            {
                return new $.$spxl.System.Xml.Linq.XNodeReader().$ctor$3(this, null);
            }
            /*XmlReader */ CreateReader$1(/*ReaderOptions*/ readerOptions)
            {
                return new $.$spxl.System.Xml.Linq.XNodeReader().$ctor$2(this, null, readerOptions);
            }
            /*IEnumerable<XNode> */ NodesAfterSelf()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*XNode*/ let n = this;
                    while(n.parent !== null && n !== n.parent.content)
                    {
                        n = n.next;
                        yield n;
                    }
                }.bind(this));
            }
            /*IEnumerable<XNode> */ NodesBeforeSelf()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (this.parent !== null)
                    {
                        /*XNode*/ let n = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                        do
                        {
                            n = n.next;
                            if (n === this)
                            {
                                break;
                            }
                            yield n;
                        }
                        while(this.parent !== null && this.parent === n.parent);
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ ElementsAfterSelf()
            {
                return this.GetElementsAfterSelf(null);
            }
            /*IEnumerable<XElement> */ ElementsAfterSelf$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetElementsAfterSelf(name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*IEnumerable<XElement> */ ElementsBeforeSelf()
            {
                return this.GetElementsBeforeSelf(null);
            }
            /*IEnumerable<XElement> */ ElementsBeforeSelf$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetElementsBeforeSelf(name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*bool */ IsAfter(/*XNode?*/ node)
            {
                return $.$spxl.System.Xml.Linq.XNode.CompareDocumentOrder(this, node) > 0;
            }
            /*bool */ IsBefore(/*XNode?*/ node)
            {
                return $.$spxl.System.Xml.Linq.XNode.CompareDocumentOrder(this, node) < 0;
            }
            static /*XNode */ ReadFrom(/*XmlReader*/ reader)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                if (reader.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                let $switch1 = reader.NodeType;
                switch($switch1)
                {
                    case 3/*XmlNodeType.Text*/:
                    case 14/*XmlNodeType.SignificantWhitespace*/:
                    case 13/*XmlNodeType.Whitespace*/:
                    return new $.$spxl.System.Xml.Linq.XText().$ctor$4(reader);
                    case 4/*XmlNodeType.CDATA*/:
                    return new $.$spxl.System.Xml.Linq.XCData().$ctor$7(reader);
                    case 8/*XmlNodeType.Comment*/:
                    return new $.$spxl.System.Xml.Linq.XComment().$ctor$4(reader);
                    case 10/*XmlNodeType.DocumentType*/:
                    return new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$4(reader);
                    case 1/*XmlNodeType.Element*/:
                    return new $.$spxl.System.Xml.Linq.XElement().$ctor$7(reader);
                    case 7/*XmlNodeType.ProcessingInstruction*/:
                    return new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$4(reader);
                    default:
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                }
            }
            static /*Task<XNode> */ ReadFromAsync(/*XmlReader*/ reader, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$3($.$spxl.System.Xml.Linq.XNode, cancellationToken);
                }
                return $.$spxl.System.Xml.Linq.XNode.ReadFromAsyncInternal(reader, cancellationToken);
            }
            static /*Task<XNode> *//*async*/  ReadFromAsyncInternal(/*XmlReader*/ reader, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XNode), $.$spxl.System.Xml.Linq.XNode, async () => 
                {
                    if (reader.ReadState !== 1/*ReadState.Interactive*/)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                    }
                    /*XNode*/ let ret;
                    let $switch1 = reader.NodeType;
                    switch($switch1)
                    {
                        case 3/*XmlNodeType.Text*/:
                        case 14/*XmlNodeType.SignificantWhitespace*/:
                        case 13/*XmlNodeType.Whitespace*/:
                        ret = new $.$spxl.System.Xml.Linq.XText().$ctor$3(reader.Value);
                        break;
                        case 4/*XmlNodeType.CDATA*/:
                        ret = new $.$spxl.System.Xml.Linq.XCData().$ctor$6(reader.Value);
                        break;
                        case 8/*XmlNodeType.Comment*/:
                        ret = new $.$spxl.System.Xml.Linq.XComment().$ctor$3(reader.Value);
                        break;
                        case 10/*XmlNodeType.DocumentType*/:
                        /*var*/ let name = reader.Name;
                        /*var*/ let publicId = reader.GetAttribute$2("PUBLIC");
                        /*var*/ let systemId = reader.GetAttribute$2("SYSTEM");
                        /*var*/ let internalSubset = reader.Value;
                        ret = new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(name, publicId, systemId, internalSubset);
                        break;
                        case 1/*XmlNodeType.Element*/:
                        return await $.$spxl.System.Xml.Linq.XElement.CreateAsync(reader, cancellationToken).ConfigureAwait$2(false);
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        /*var*/ let target = reader.Name;
                        /*var*/ let data = reader.Value;
                        ret = new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(target, data);
                        break;
                        default:
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                    }
                    cancellationToken.ThrowIfCancellationRequested();
                    await reader.ReadAsync().ConfigureAwait$2(false);
                    return ret;
                });
            }
            /*void */ Remove()
            {
                if (this.parent === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                this.parent.RemoveNode(this);
            }
            /*void */ ReplaceWith(/*object?*/ content)
            {
                if (this.parent === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                /*XContainer*/ let c = this.parent;
                /*XNode?*/ let p = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                while(p.next !== this)
                {
                    p = p.next;
                }
                if (p === this.parent.content)
                {
                    p = null;
                }
                this.parent.RemoveNode(this);
                if (p !== null && p.parent !== c)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$3(c, p).Add(content);
            }
            /*void */ ReplaceWith$1(/*params object?[]*/ content)
            {
                this.ReplaceWith($.$cast(content, $.$$.System.Object));
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.GetXmlString(this.GetSaveOptionsFromAnnotations());
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XNode.ToString.apply(this, arguments); }
            /*string */ ToString$1(/*SaveOptions*/ options)
            {
                return this.GetXmlString(options);
            }
            static /*bool */ DeepEquals(/*XNode?*/ n1, /*XNode?*/ n2)
            {
                if (n1 === n2)
                {
                    return true;
                }
                if (n1 === null || n2 === null)
                {
                    return false;
                }
                return n1.DeepEquals$1(n2);
            }
            /*void */ AppendText(/*StringBuilder*/ sb)
            {
            }
            /*IEnumerable<XElement> */ GetAncestors(/*XName?*/ name, /*bool*/ self)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*XElement?*/ let e = $.$as((self ? this : this.parent), $.$spxl.System.Xml.Linq.XElement);
                    while(e !== null)
                    {
                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                        {
                            yield e;
                        }
                        e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ GetElementsAfterSelf(/*XName?*/ name)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*XNode*/ let n = this;
                    while(n.parent !== null && n !== n.parent.content)
                    {
                        n = n.next;
                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                        {
                            yield e;
                        }
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ GetElementsBeforeSelf(/*XName?*/ name)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (this.parent !== null)
                    {
                        /*XNode*/ let n = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                        do
                        {
                            n = n.next;
                            if (n === this)
                            {
                                break;
                            }
                            /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                            if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                            {
                                yield e;
                            }
                        }
                        while(this.parent !== null && this.parent === n.parent);
                    }
                }.bind(this));
            }
            static /*XmlReaderSettings */ GetXmlReaderSettings(/*LoadOptions*/ o)
            {
                /*XmlReaderSettings*/ let rs = new $.$spx.System.Xml.XmlReaderSettings().$ctor$1();
                if ((o & 1/*LoadOptions.PreserveWhitespace*/) === 0)
                {
                    rs.IgnoreWhitespace = true;
                }
                rs.DtdProcessing = $.$cast(2, $.$spx.System.Xml.DtdProcessing);
                rs.MaxCharactersFromEntities = $.$cast(10000000n, $.$$.System.Int64);
                return rs;
            }
            static /*XmlWriterSettings */ GetXmlWriterSettings(/*SaveOptions*/ o)
            {
                /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                if ((o & 1/*SaveOptions.DisableFormatting*/) === 0)
                {
                    ws.Indent = true;
                }
                if ((o & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0)
                {
                    ws.NamespaceHandling |= 1/*NamespaceHandling.OmitDuplicates*/;
                }
                return ws;
            }
            /*string */ GetXmlString(/*SaveOptions*/ o)
            {
                let sw = null;
                try
                {
                    sw = new $.$$.System.IO.StringWriter().$ctor$5($.$$.System.Globalization.CultureInfo.InvariantCulture);
                    /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                    ws.OmitXmlDeclaration = true;
                    if ((o & 1/*SaveOptions.DisableFormatting*/) === 0)
                    {
                        ws.Indent = true;
                    }
                    if ((o & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0)
                    {
                        ws.NamespaceHandling |= 1/*NamespaceHandling.OmitDuplicates*/;
                    }
                    if ($.$is(this, $.$spxl.System.Xml.Linq.XText))
                    {
                        ws.ConformanceLevel = 1/*ConformanceLevel.Fragment*/;
                    }
                    let w = null;
                    try
                    {
                        w = $.$spx.System.Xml.XmlWriter.Create$2(sw, ws);
                        /*XDocument?*/ let n = $.$as(this, $.$spxl.System.Xml.Linq.XDocument);
                        if (n !== null)
                        {
                            n.WriteContentTo(w);
                        }
                        else 
                        {
                            this.WriteTo(w);
                        }
                    }
                    finally
                    {
                        w?.System$IDisposable$Dispose();
                    }
                    return $.$$.System.IO.StringWriter.ToString.call(sw);
                }
                finally
                {
                    sw?.System$IDisposable$Dispose();
                }
            }
            static $h = 2287568;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2615248,"p":[{"p":2287568,"g":{"r":0,"d":0,"h":17182156752,"f":50331649},"n":"NextNode","d":2287568,"h":12887189456,"f":2097153},{"p":2287568,"g":{"r":0,"d":0,"h":25772091344,"f":50331649},"n":"PreviousNode","d":2287568,"h":21477124048,"f":2097153},{"p":2418640,"g":{"r":0,"d":0,"h":38656993232,"f":50331681},"n":"DocumentOrderComparer","d":2287568,"h":34362025936,"f":2097185},{"p":2484176,"g":{"r":0,"d":0,"h":51541895120,"f":50331681},"n":"EqualityComparer","d":2287568,"h":47246927824,"f":2097185}],"m":[{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddAfterSelf","d":2287568,"h":55836862416,"f":16777217},{"r":65537,"p":[{"n":"content","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"AddAfterSelf","o":"@$1","d":2287568,"h":60131829712,"f":16777217},{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddBeforeSelf","d":2287568,"h":64426797008,"f":16777217},{"r":65537,"p":[{"n":"content","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"AddBeforeSelf","o":"@$1","d":2287568,"h":68721764304,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"Ancestors","d":2287568,"h":73016731600,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2156496}],"n":"Ancestors","o":"@$1","d":2287568,"h":77311698896,"f":16777217},{"r":655361,"p":[{"n":"n1","p":2287568},{"n":"n2","p":2287568}],"n":"CompareDocumentOrder","d":2287568,"h":81606666192,"f":16777249},{"r":53394070,"n":"CreateReader","d":2287568,"h":85901633488,"f":16777217},{"r":53394070,"p":[{"n":"readerOptions","p":976848}],"n":"CreateReader","o":"@$1","d":2287568,"h":90196600784,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"NodesAfterSelf","d":2287568,"h":94491568080,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"NodesBeforeSelf","d":2287568,"h":98786535376,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"ElementsAfterSelf","d":2287568,"h":103081502672,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2156496}],"n":"ElementsAfterSelf","o":"@$1","d":2287568,"h":107376469968,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"ElementsBeforeSelf","d":2287568,"h":111671437264,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2156496}],"n":"ElementsBeforeSelf","o":"@$1","d":2287568,"h":115966404560,"f":16777217},{"r":262145,"p":[{"n":"node","p":2287568}],"n":"IsAfter","d":2287568,"h":120261371856,"f":16777217},{"r":262145,"p":[{"n":"node","p":2287568}],"n":"IsBefore","d":2287568,"h":124556339152,"f":16777217},{"r":2287568,"p":[{"n":"reader","p":53394070}],"n":"ReadFrom","d":2287568,"h":128851306448,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"reader","p":53394070},{"n":"cancellationToken","p":125829121}],"n":"ReadFromAsync","d":2287568,"h":133146273744,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"reader","p":53394070},{"n":"cancellationToken","p":125829121}],"n":"ReadFromAsyncInternal","d":2287568,"h":137441241040,"f":16781346},{"r":65537,"n":"Remove","d":2287568,"h":141736208336,"f":16777217},{"r":65537,"p":[{"n":"content","p":131073}],"n":"ReplaceWith","d":2287568,"h":146031175632,"f":16777217},{"r":65537,"p":[{"n":"content","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"ReplaceWith","o":"@$1","d":2287568,"h":150326142928,"f":16777217},{"r":1310721,"n":"ToString","d":2287568,"h":154621110224,"f":16809985},{"r":1310721,"p":[{"n":"options","p":1042384}],"n":"ToString","o":"@$1","d":2287568,"h":158916077520,"f":16777217},{"r":262145,"p":[{"n":"n1","p":2287568},{"n":"n2","p":2287568}],"n":"DeepEquals","d":2287568,"h":163211044816,"f":16777249},{"r":65537,"p":[{"n":"writer","p":58440342}],"n":"WriteTo","d":2287568,"h":167506012112,"f":16777473},{"r":133169153,"p":[{"n":"writer","p":58440342},{"n":"cancellationToken","p":125829121}],"n":"WriteToAsync","d":2287568,"h":171800979408,"f":16777473},{"r":65537,"p":[{"n":"sb","p":122814465}],"n":"AppendText","d":2287568,"h":176095946704,"f":16777352},{"r":2287568,"n":"CloneNode","d":2287568,"h":180390914000,"f":16777480},{"r":262145,"p":[{"n":"node","p":2287568}],"n":"DeepEquals","o":"@$1","d":2287568,"h":184685881296,"f":16777480},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2156496},{"n":"self","p":262145}],"n":"GetAncestors","d":2287568,"h":188980848592,"f":16777224},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2156496}],"n":"GetElementsAfterSelf","d":2287568,"h":193275815888,"f":16777218},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2156496}],"n":"GetElementsBeforeSelf","d":2287568,"h":197570783184,"f":16777218},{"r":655361,"n":"GetDeepHashCode","d":2287568,"h":201865750480,"f":16777480},{"r":53525142,"p":[{"n":"o","p":714704}],"n":"GetXmlReaderSettings","d":2287568,"h":206160717776,"f":16777256},{"r":58505878,"p":[{"n":"o","p":1042384}],"n":"GetXmlWriterSettings","d":2287568,"h":210455685072,"f":16777256},{"r":1310721,"p":[{"n":"o","p":1042384}],"n":"GetXmlString","d":2287568,"h":214750652368,"f":16777218}],"l":[{"t":2287568,"n":"next","d":2287568,"h":4297254864,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$2","d":2287568,"h":8592222160,"f":16777224}],"i":[13941398],"h":2287568}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XObject; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XNode`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XContainer", ($self) => class XContainer extends $.$spxl.System.Xml.Linq.XNode
        {
            /*object?*/ content = null;
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*XContainer*/ other)
            {
                super.$ctor$2();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    if ($.$is(other.content, $.$$.System.String))
                    {
                        this.content = other.content;
                    }
                    else 
                    {
                        /*XNode?*/ let n = $.$cast(other.content, $.$spxl.System.Xml.Linq.XNode);
                        if (n !== null)
                        {
                            do
                            {
                                n = n.next;
                                this.AppendNodeSkipNotify(n.CloneNode());
                            }
                            while(n !== other.content);
                        }
                    }
                }
                return this;
            }
            /*XNode? */ get FirstNode()
            {
                return this.LastNode?.next ?? null;
            }
            /*XNode? */ get LastNode()
            {
                if (this.content === null)
                {
                    return null;
                }
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    return n;
                }
                /*string?*/ let s = $.$as(this.content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    if (s.length === 0)
                    {
                        return null;
                    }
                    /*XText*/ let t = new $.$spxl.System.Xml.Linq.XText().$ctor$3(s);
                    t.parent = this;
                    t.next = t;
                    $.$$.System.Threading.Interlocked.CompareExchange$6($.$ref(() => this.content, ($v) => this.content = $v, $.$$.System.Object), t, s);
                }
                return $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
            }
            /*void */ Add(/*object?*/ content)
            {
                if (this.SkipNotify())
                {
                    this.AddContentSkipNotify(content);
                    return;
                }
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.AddNode(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    this.AddString(s);
                    return;
                }
                /*XAttribute?*/ let a = $.$as(content, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    this.AddAttribute(a);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$13(x));
                    return;
                }
                /*object?[]?*/ let o = $.$as(content, $.$typeArray($.$$.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.Add(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$$.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$IEnumerable$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$IEnumerator$Current;
                        {
                            this.Add(obj);
                        }
                    }
                    return;
                }
                this.AddString($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            /*void */ Add$1(/*params object?[]*/ content)
            {
                this.Add($.$cast(content, $.$$.System.Object));
            }
            /*void */ AddFirst(/*object?*/ content)
            {
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$3(this, null).Add(content);
            }
            /*void */ AddFirst$1(/*params object?[]*/ content)
            {
                this.AddFirst($.$cast(content, $.$$.System.Object));
            }
            /*XmlWriter */ CreateWriter()
            {
                /*XmlWriterSettings*/ let settings = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                settings.ConformanceLevel = $.$is(this, $.$spxl.System.Xml.Linq.XDocument) ? 2/*ConformanceLevel.Document*/ : 1/*ConformanceLevel.Fragment*/;
                return $.$spx.System.Xml.XmlWriter.Create$8(new $.$spxl.System.Xml.Linq.XNodeBuilder().$ctor$2(this), settings);
            }
            /*IEnumerable<XNode> */ DescendantNodes()
            {
                return this.GetDescendantNodes(false);
            }
            /*IEnumerable<XElement> */ Descendants()
            {
                return this.GetDescendants(null, false);
            }
            /*IEnumerable<XElement> */ Descendants$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetDescendants(name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*XElement? */ Element(/*XName*/ name)
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (e !== null && $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                        {
                            return e;
                        }
                    }
                    while(n !== this.content);
                }
                return null;
            }
            /*IEnumerable<XElement> */ Elements()
            {
                return this.GetElements(null);
            }
            /*IEnumerable<XElement> */ Elements$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetElements(name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*IEnumerable<XNode> */ Nodes()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*XNode?*/ let n = this.LastNode;
                    if (n !== null)
                    {
                        do
                        {
                            n = n.next;
                            yield n;
                        }
                        while(n.parent === this && n !== this.content);
                    }
                }.bind(this));
            }
            /*void */ RemoveNodes()
            {
                if (this.SkipNotify())
                {
                    this.RemoveNodesSkipNotify();
                    return;
                }
                while(this.content !== null)
                {
                    /*string?*/ let s = $.$as(this.content, $.$$.System.String);
                    if ($.$$.System.String.op_Inequality(s, null))
                    {
                        if (s.length > 0)
                        {
                            this.ConvertTextToNode();
                        }
                        else 
                        {
                            if ($.$is(this, $.$spxl.System.Xml.Linq.XElement))
                            {
                                this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                                if (s !== this.content)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                                }
                                this.content = null;
                                this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                            }
                            else 
                            {
                                this.content = null;
                            }
                        }
                    }
                    /*XNode?*/ let last = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                    if (last !== null)
                    {
                        /*XNode*/ let n = last.next;
                        this.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                        if (last !== this.content || n !== last.next)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                        }
                        if (n !== last)
                        {
                            last.next = n.next;
                        }
                        else 
                        {
                            this.content = null;
                        }
                        n.parent = null;
                        n.next = null;
                        this.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                    }
                }
            }
            /*void */ ReplaceNodes(/*object?*/ content)
            {
                content = $.$spxl.System.Xml.Linq.XContainer.GetContentSnapshot(content);
                this.RemoveNodes();
                this.Add(content);
            }
            /*void */ ReplaceNodes$1(/*params object?[]*/ content)
            {
                this.ReplaceNodes($.$cast(content, $.$$.System.Object));
            }
            /*void */ AddAttribute(/*XAttribute*/ a)
            {
            }
            /*void */ AddAttributeSkipNotify(/*XAttribute*/ a)
            {
            }
            /*void */ AddContentSkipNotify(/*object?*/ content)
            {
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.AddNodeSkipNotify(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    this.AddStringSkipNotify(s);
                    return;
                }
                /*XAttribute?*/ let a = $.$as(content, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    this.AddAttributeSkipNotify(a);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XElement().$ctor$13(x));
                    return;
                }
                /*object?[]?*/ let o = $.$as(content, $.$typeArray($.$$.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.AddContentSkipNotify(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$$.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$IEnumerable$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$IEnumerator$Current;
                        {
                            this.AddContentSkipNotify(obj);
                        }
                    }
                    return;
                }
                this.AddStringSkipNotify($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            /*void */ AddNode(/*XNode*/ n)
            {
                this.ValidateNode(n, this);
                if (n.parent !== null)
                {
                    n = n.CloneNode();
                }
                else 
                {
                    /*XNode*/ let p = this;
                    while(p.parent !== null)
                    {
                        p = p.parent;
                    }
                    if (n === p)
                    {
                        n = n.CloneNode();
                    }
                }
                this.ConvertTextToNode();
                this.AppendNode(n);
            }
            /*void */ AddNodeSkipNotify(/*XNode*/ n)
            {
                this.ValidateNode(n, this);
                if (n.parent !== null)
                {
                    n = n.CloneNode();
                }
                else 
                {
                    /*XNode*/ let p = this;
                    while(p.parent !== null)
                    {
                        p = p.parent;
                    }
                    if (n === p)
                    {
                        n = n.CloneNode();
                    }
                }
                this.ConvertTextToNode();
                this.AppendNodeSkipNotify(n);
            }
            /*void */ AddString(/*string*/ s)
            {
                this.ValidateString(s);
                if (this.content === null)
                {
                    if (s.length > 0)
                    {
                        this.AppendNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(s));
                    }
                    else 
                    {
                        if ($.$is(this, $.$spxl.System.Xml.Linq.XElement))
                        {
                            this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                            if (this.content !== null)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                            }
                            this.content = s;
                            this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                        }
                        else 
                        {
                            this.content = s;
                        }
                    }
                }
                else if (s.length > 0)
                {
                    this.ConvertTextToNode();
                    /*XText?*/ let tn = $.$as(this.content, $.$spxl.System.Xml.Linq.XText);
                    if (tn !== null && !($.$is(tn, $.$spxl.System.Xml.Linq.XCData)))
                    {
                        tn.Value += s;
                    }
                    else 
                    {
                        this.AppendNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(s));
                    }
                }
            }
            /*void */ AddStringSkipNotify(/*string*/ s)
            {
                this.ValidateString(s);
                if (this.content === null)
                {
                    this.content = s;
                }
                else if (s.length > 0)
                {
                    /*string?*/ let stringContent = $.$as(this.content, $.$$.System.String);
                    if ($.$$.System.String.op_Inequality(stringContent, null))
                    {
                        this.content = stringContent + s;
                    }
                    else 
                    {
                        /*XText?*/ let tn = $.$as(this.content, $.$spxl.System.Xml.Linq.XText);
                        if (tn !== null && !($.$is(tn, $.$spxl.System.Xml.Linq.XCData)))
                        {
                            tn.text += s;
                        }
                        else 
                        {
                            this.AppendNodeSkipNotify(new $.$spxl.System.Xml.Linq.XText().$ctor$3(s));
                        }
                    }
                }
            }
            /*void */ AppendNode(/*XNode*/ n)
            {
                /*bool*/ let notify = this.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                if (n.parent !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                this.AppendNodeSkipNotify(n);
                if (notify)
                {
                    this.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                }
            }
            /*void */ AppendNodeSkipNotify(/*XNode*/ n)
            {
                n.parent = this;
                if (this.content === null || $.$is(this.content, $.$$.System.String))
                {
                    n.next = n;
                }
                else 
                {
                    /*XNode*/ let x = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                    n.next = x.next;
                    x.next = n;
                }
                this.content = n;
            }
            /*void */ AppendText(/*StringBuilder*/ sb)
            {
                /*string?*/ let s = $.$as(this.content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    sb.Append$19(s);
                }
                else 
                {
                    /*XNode?*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                    if (n !== null)
                    {
                        do
                        {
                            n = n.next;
                            n.AppendText(sb);
                        }
                        while(n !== this.content);
                    }
                }
            }
            /*string? */ GetTextOnly()
            {
                if (this.content === null)
                {
                    return null;
                }
                /*string?*/ let s = $.$as(this.content, $.$$.System.String);
                if ($.$$.System.String.op_Equality(s, null))
                {
                    /*XNode*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                    do
                    {
                        n = n.next;
                        if (n.NodeType !== 3/*XmlNodeType.Text*/)
                        {
                            return null;
                        }
                        s += ($.$cast(n, $.$spxl.System.Xml.Linq.XText)).Value;
                    }
                    while(n !== this.content);
                }
                return s;
            }
            /*string */ CollectText(/*ref XNode?*/ n)
            {
                /*string*/ let s = "";
                while(n.$v !== null && n.$v.NodeType === 3/*XmlNodeType.Text*/)
                {
                    s += ($.$cast(n.$v, $.$spxl.System.Xml.Linq.XText)).Value;
                    n.$v = n.$v !== this.content ? n.$v.next : null;
                }
                return s;
            }
            /*bool */ ContentsEqual(/*XContainer*/ e)
            {
                if (this.content === e.content)
                {
                    return true;
                }
                /*string?*/ let s = this.GetTextOnly();
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    return $.$$.System.String.op_Equality(s, e.GetTextOnly());
                }
                /*XNode?*/ let n1 = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                /*XNode?*/ let n2 = $.$as(e.content, $.$spxl.System.Xml.Linq.XNode);
                if (n1 !== null && n2 !== null)
                {
                    n1 = n1.next;
                    n2 = n2.next;
                    while(true)
                    {
                        if ($.$$.System.String.op_Inequality(this.CollectText($.$ref(() => n1, ($v) => n1 = $v, $.$spxl.System.Xml.Linq.XNode)), e.CollectText($.$ref(() => n2, ($v) => n2 = $v, $.$spxl.System.Xml.Linq.XNode))))
                        {
                            break;
                        }
                        if (n1 === null && n2 === null)
                        {
                            return true;
                        }
                        if (n1 === null || n2 === null || !n1.DeepEquals$1(n2))
                        {
                            break;
                        }
                        n1 = n1 !== this.content ? n1.next : null;
                        n2 = n2 !== e.content ? n2.next : null;
                    }
                }
                return false;
            }
            /*int */ ContentsHashCode()
            {
                /*string?*/ let s = this.GetTextOnly();
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    return $.$$.System.String.GetHashCode.call(s);
                }
                /*int*/ let h = 0;
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*string*/ let text = this.CollectText($.$ref(() => n, ($v) => n = $v, $.$spxl.System.Xml.Linq.XNode));
                        if (text.length > 0)
                        {
                            h ^= $.$$.System.String.GetHashCode.call(text);
                        }
                        if (n === null)
                        {
                            break;
                        }
                        h ^= n.GetDeepHashCode();
                    }
                    while(n !== this.content);
                }
                return h;
            }
            /*void */ ConvertTextToNode()
            {
                /*string?*/ let s = $.$as(this.content, $.$$.System.String);
                if (!$.$$.System.String.IsNullOrEmpty(s))
                {
                    /*XText*/ let t = new $.$spxl.System.Xml.Linq.XText().$ctor$3(s);
                    t.parent = this;
                    t.next = t;
                    this.content = t;
                }
            }
            /*IEnumerable<XNode> */ GetDescendantNodes(/*bool*/ self)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (self)
                    {
                        yield this;
                    }
                    /*XNode*/ let n = this;
                    while(true)
                    {
                        /*XContainer?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XContainer);
                        /*XNode?*/ let first;
                        if (c !== null && (first = c.FirstNode) !== null)
                        {
                            n = first;
                        }
                        else 
                        {
                            while(n !== null && n !== this && n === n.parent.content)
                            {
                                n = n.parent;
                            }
                            if (n === null || n === this)
                            {
                                break;
                            }
                            n = n.next;
                        }
                        yield n;
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ GetDescendants(/*XName?*/ name, /*bool*/ self)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (self)
                    {
                        /*XElement*/ let e = $.$cast(this, $.$spxl.System.Xml.Linq.XElement);
                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                        {
                            yield e;
                        }
                    }
                    /*XNode*/ let n = this;
                    /*XContainer?*/ let c = this;
                    while(true)
                    {
                        if (c !== null && $.$is(c.content, $.$spxl.System.Xml.Linq.XNode))
                        {
                            n = ($.$cast(c.content, $.$spxl.System.Xml.Linq.XNode)).next;
                        }
                        else 
                        {
                            while(n !== this && n === n.parent.content)
                            {
                                n = n.parent;
                            }
                            if (n === this)
                            {
                                break;
                            }
                            n = n.next;
                        }
                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                        {
                            yield e;
                        }
                        c = e;
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ GetElements(/*XName?*/ name)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                    if (n !== null)
                    {
                        do
                        {
                            n = n.next;
                            /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                            if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                            {
                                yield e;
                            }
                        }
                        while(n.parent === this && n !== this.content);
                    }
                }.bind(this));
            }
            static /*string */ GetStringValue(/*object*/ value)
            {
                /*string?*/ let s = (() =>
                {
                    {
                        let stringValue;
                        if ((stringValue = value, $.$is(stringValue, $.$$.System.String)))
                        {
                            return stringValue;
                        }
                    }
                    {
                        let intValue;
                        if ((intValue = value, $.$is(intValue, $.$$.System.Int32)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$13(intValue);
                        }
                    }
                    {
                        let doubleValue;
                        if ((doubleValue = value, $.$is(doubleValue, $.$$.System.Double)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$10(doubleValue);
                        }
                    }
                    {
                        let longValue;
                        if ((longValue = value, $.$is(longValue, $.$$.System.Int64)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$14(longValue);
                        }
                    }
                    {
                        let floatValue;
                        if ((floatValue = value, $.$is(floatValue, $.$$.System.Single)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$16(floatValue);
                        }
                    }
                    {
                        let decimalValue;
                        if ((decimalValue = value, $.$is(decimalValue, $.$$.System.Decimal)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$9(decimalValue);
                        }
                    }
                    {
                        let shortValue;
                        if ((shortValue = value, $.$is(shortValue, $.$$.System.Int16)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$12(shortValue);
                        }
                    }
                    {
                        let sbyteValue;
                        if ((sbyteValue = value, $.$is(sbyteValue, $.$$.System.SByte)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$15(sbyteValue);
                        }
                    }
                    {
                        let boolValue;
                        if ((boolValue = value, $.$is(boolValue, $.$$.System.Boolean)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$1(boolValue);
                        }
                    }
                    {
                        let dtValue;
                        if ((dtValue = value, $.$is(dtValue, $.$$.System.DateTime)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$5(dtValue, 3/*XmlDateTimeSerializationMode.RoundtripKind*/);
                        }
                    }
                    {
                        let dtoValue;
                        if ((dtoValue = value, $.$is(dtoValue, $.$$.System.DateTimeOffset)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$8(dtoValue);
                        }
                    }
                    {
                        let tsValue;
                        if ((tsValue = value, $.$is(tsValue, $.$$.System.TimeSpan)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$17(tsValue);
                        }
                    }
                    if (value === $.$spxl.System.Xml.Linq.XObject)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_XObjectValue);
                    }
                    return $.$$.System.Object.ToString.call(value);
                })();
                if ($.$$.System.String.op_Equality(s, null))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_ConvertToString);
                }
                return s;
            }
            /*void */ ReadContentFrom$1(/*XmlReader*/ r)
            {
                if (r.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$2(this);
                while(cr.ReadContentFrom(this, r) && r.Read())
                {
                }
            }
            /*void */ ReadContentFrom(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                if ((o & (2/*LoadOptions.SetBaseUri*/ | 4/*LoadOptions.SetLineInfo*/)) === 0)
                {
                    this.ReadContentFrom$1(r);
                    return;
                }
                if (r.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$1(this, r, o);
                while(cr.ReadContentFromContainer(this, r) && r.Read())
                {
                }
            }
            /*Task *//*async*/  ReadContentFromAsync(/*XmlReader*/ r, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (r.ReadState !== 1/*ReadState.Interactive*/)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                    }
                    /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$2(this);
                    do
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                    while(await cr.ReadContentFromAsync(this, r).ConfigureAwait(false) && await r.ReadAsync().ConfigureAwait$2(false));
                });
            }
            /*Task *//*async*/  ReadContentFromAsync$1(/*XmlReader*/ r, /*LoadOptions*/ o, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if ((o & (2/*LoadOptions.SetBaseUri*/ | 4/*LoadOptions.SetLineInfo*/)) === 0)
                    {
                        await this.ReadContentFromAsync(r, cancellationToken).ConfigureAwait(false);
                        return;
                    }
                    if (r.ReadState !== 1/*ReadState.Interactive*/)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                    }
                    /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$1(this, r, o);
                    do
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                    while(await cr.ReadContentFromContainerAsync(this, r).ConfigureAwait(false) && await r.ReadAsync().ConfigureAwait$2(false));
                });
            }
            static $_ContentReader;
            static get ContentReader()
            {
                let $cls = $.$spxl.System.Xml.Linq.XContainer;
                return $cls.$_ContentReader ??= $asm.$ncls("$spxl.System.Xml.Linq.XContainer.ContentReader", ($self) => class ContentReader extends $.$$.System.Object
                {
                    /*NamespaceCache*/ _eCache;
                    /*NamespaceCache*/ _aCache;
                    /*IXmlLineInfo?*/ _lineInfo = null;
                    /*XContainer*/ _currentContainer = null;
                    /*string?*/ _baseUri = null;
                    $ctor$2(/*XContainer*/ rootContainer)
                    {
                        super.$ctor();
                        {
                            this._currentContainer = rootContainer;
                        }
                        return this;
                    }
                    $ctor$1(/*XContainer*/ rootContainer, /*XmlReader*/ r, /*LoadOptions*/ o)
                    {
                        super.$ctor();
                        {
                            this._currentContainer = rootContainer;
                            this._baseUri = (o & 2/*LoadOptions.SetBaseUri*/) !== 0 ? r.BaseURI : null;
                            this._lineInfo = (o & 4/*LoadOptions.SetLineInfo*/) !== 0 ? $.$as(r, $.$spx.System.Xml.IXmlLineInfo) : null;
                        }
                        return this;
                    }
                    /*bool */ ReadContentFrom(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        let $switch1 = r.NodeType;
                        switch($switch1)
                        {
                            case 1/*XmlNodeType.Element*/:
                            /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$12(this._eCache.Get(r.NamespaceURI).GetName$1(r.LocalName));
                            if (r.MoveToFirstAttribute())
                            {
                                do
                                {
                                    e.AppendAttributeSkipNotify(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(this._aCache.Get(r.Prefix.length === 0 ? $.$$.System.String.Empty : r.NamespaceURI).GetName$1(r.LocalName), r.Value));
                                }
                                while(r.MoveToNextAttribute());
                                r.MoveToElement();
                            }
                            this._currentContainer.AddNodeSkipNotify(e);
                            if (!r.IsEmptyElement)
                            {
                                this._currentContainer = e;
                            }
                            break;
                            case 15/*XmlNodeType.EndElement*/:
                            this._currentContainer.content ??= $.$$.System.String.Empty;
                            if (this._currentContainer === rootContainer)
                            {
                                return false;
                            }
                            this._currentContainer = this._currentContainer.parent;
                            break;
                            case 3/*XmlNodeType.Text*/:
                            case 14/*XmlNodeType.SignificantWhitespace*/:
                            case 13/*XmlNodeType.Whitespace*/:
                            this._currentContainer.AddStringSkipNotify(r.Value);
                            break;
                            case 4/*XmlNodeType.CDATA*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XCData().$ctor$6(r.Value));
                            break;
                            case 8/*XmlNodeType.Comment*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XComment().$ctor$3(r.Value));
                            break;
                            case 7/*XmlNodeType.ProcessingInstruction*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, r.Value));
                            break;
                            case 10/*XmlNodeType.DocumentType*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute$2("PUBLIC"), r.GetAttribute$2("SYSTEM"), r.Value));
                            break;
                            case 5/*XmlNodeType.EntityReference*/:
                            if (!r.CanResolveEntity)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                            }
                            r.ResolveEntity();
                            break;
                            case 16/*XmlNodeType.EndEntity*/:
                            break;
                            default:
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                        }
                        return true;
                    }
                    /*ValueTask<bool> *//*async*/  ReadContentFromAsync(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean), $.$$.System.Boolean, async () => 
                        {
                            let $switch1 = r.NodeType;
                            switch($switch1)
                            {
                                case 1/*XmlNodeType.Element*/:
                                /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$12(this._eCache.Get(r.NamespaceURI).GetName$1(r.LocalName));
                                if (r.MoveToFirstAttribute())
                                {
                                    do
                                    {
                                        e.AppendAttributeSkipNotify(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(this._aCache.Get(r.Prefix.length === 0 ? $.$$.System.String.Empty : r.NamespaceURI).GetName$1(r.LocalName), await r.GetValueAsync().ConfigureAwait$2(false)));
                                    }
                                    while(r.MoveToNextAttribute());
                                    r.MoveToElement();
                                }
                                this._currentContainer.AddNodeSkipNotify(e);
                                if (!r.IsEmptyElement)
                                {
                                    this._currentContainer = e;
                                }
                                break;
                                case 15/*XmlNodeType.EndElement*/:
                                this._currentContainer.content ??= $.$$.System.String.Empty;
                                if (this._currentContainer === rootContainer)
                                {
                                    return false;
                                }
                                this._currentContainer = this._currentContainer.parent;
                                break;
                                case 3/*XmlNodeType.Text*/:
                                case 14/*XmlNodeType.SignificantWhitespace*/:
                                case 13/*XmlNodeType.Whitespace*/:
                                this._currentContainer.AddStringSkipNotify(await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 4/*XmlNodeType.CDATA*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XCData().$ctor$6(await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 8/*XmlNodeType.Comment*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XComment().$ctor$3(await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 7/*XmlNodeType.ProcessingInstruction*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 10/*XmlNodeType.DocumentType*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute$2("PUBLIC"), r.GetAttribute$2("SYSTEM"), await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 5/*XmlNodeType.EntityReference*/:
                                if (!r.CanResolveEntity)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                                }
                                r.ResolveEntity();
                                break;
                                case 16/*XmlNodeType.EndEntity*/:
                                break;
                                default:
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                            }
                            return true;
                        });
                    }
                    /*bool */ ReadContentFromContainer(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        /*XNode?*/ let newNode = null;
                        /*string*/ let baseUri = r.BaseURI;
                        let $switch1 = r.NodeType;
                        switch($switch1)
                        {
                            case 1/*XmlNodeType.Element*/:
                            {
                                /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$12(this._eCache.Get(r.NamespaceURI).GetName$1(r.LocalName));
                                if ($.$$.System.String.op_Inequality(this._baseUri, null) && $.$$.System.String.op_Inequality(this._baseUri, baseUri))
                                {
                                    e.SetBaseUri(baseUri);
                                }
                                if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                {
                                    e.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                }
                                if (r.MoveToFirstAttribute())
                                {
                                    do
                                    {
                                        /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(this._aCache.Get(r.Prefix.length === 0 ? $.$$.System.String.Empty : r.NamespaceURI).GetName$1(r.LocalName), r.Value);
                                        if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                        {
                                            a.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                        }
                                        e.AppendAttributeSkipNotify(a);
                                    }
                                    while(r.MoveToNextAttribute());
                                    r.MoveToElement();
                                }
                                this._currentContainer.AddNodeSkipNotify(e);
                                if (!r.IsEmptyElement)
                                {
                                    this._currentContainer = e;
                                    if ($.$$.System.String.op_Inequality(this._baseUri, null))
                                    {
                                        this._baseUri = baseUri;
                                    }
                                }
                                break;
                            }
                            case 15/*XmlNodeType.EndElement*/:
                            {
                                this._currentContainer.content ??= $.$$.System.String.Empty;
                                /*XElement?*/ let e = $.$as(this._currentContainer, $.$spxl.System.Xml.Linq.XElement);
                                $.$$.System.Diagnostics.Debug.Assert$2(e !== null, "EndElement received but the current container is not an element.");
                                if (e !== null && this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                {
                                    e.SetEndElementLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                }
                                if (this._currentContainer === rootContainer)
                                {
                                    return false;
                                }
                                if ($.$$.System.String.op_Inequality(this._baseUri, null) && this._currentContainer.HasBaseUri)
                                {
                                    this._baseUri = this._currentContainer.parent.BaseUri;
                                }
                                this._currentContainer = this._currentContainer.parent;
                                break;
                            }
                            case 3/*XmlNodeType.Text*/:
                            case 14/*XmlNodeType.SignificantWhitespace*/:
                            case 13/*XmlNodeType.Whitespace*/:
                            if (($.$$.System.String.op_Inequality(this._baseUri, null) && $.$$.System.String.op_Inequality(this._baseUri, baseUri)) || (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo()))
                            {
                                newNode = new $.$spxl.System.Xml.Linq.XText().$ctor$3(r.Value);
                            }
                            else 
                            {
                                this._currentContainer.AddStringSkipNotify(r.Value);
                            }
                            break;
                            case 4/*XmlNodeType.CDATA*/:
                            newNode = new $.$spxl.System.Xml.Linq.XCData().$ctor$6(r.Value);
                            break;
                            case 8/*XmlNodeType.Comment*/:
                            newNode = new $.$spxl.System.Xml.Linq.XComment().$ctor$3(r.Value);
                            break;
                            case 7/*XmlNodeType.ProcessingInstruction*/:
                            newNode = new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, r.Value);
                            break;
                            case 10/*XmlNodeType.DocumentType*/:
                            newNode = new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute$2("PUBLIC"), r.GetAttribute$2("SYSTEM"), r.Value);
                            break;
                            case 5/*XmlNodeType.EntityReference*/:
                            if (!r.CanResolveEntity)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                            }
                            r.ResolveEntity();
                            break;
                            case 16/*XmlNodeType.EndEntity*/:
                            break;
                            default:
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                        }
                        if (newNode !== null)
                        {
                            if ($.$$.System.String.op_Inequality(this._baseUri, null) && $.$$.System.String.op_Inequality(this._baseUri, baseUri))
                            {
                                newNode.SetBaseUri(baseUri);
                            }
                            if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                            {
                                newNode.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                            }
                            this._currentContainer.AddNodeSkipNotify(newNode);
                        }
                        return true;
                    }
                    /*ValueTask<bool> *//*async*/  ReadContentFromContainerAsync(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean), $.$$.System.Boolean, async () => 
                        {
                            /*XNode?*/ let newNode = null;
                            /*string*/ let baseUri = r.BaseURI;
                            let $switch1 = r.NodeType;
                            switch($switch1)
                            {
                                case 1/*XmlNodeType.Element*/:
                                {
                                    /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$12(this._eCache.Get(r.NamespaceURI).GetName$1(r.LocalName));
                                    if ($.$$.System.String.op_Inequality(this._baseUri, null) && $.$$.System.String.op_Inequality(this._baseUri, baseUri))
                                    {
                                        e.SetBaseUri(baseUri);
                                    }
                                    if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                    {
                                        e.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                    }
                                    if (r.MoveToFirstAttribute())
                                    {
                                        do
                                        {
                                            /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(this._aCache.Get(r.Prefix.length === 0 ? $.$$.System.String.Empty : r.NamespaceURI).GetName$1(r.LocalName), await r.GetValueAsync().ConfigureAwait$2(false));
                                            if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                            {
                                                a.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                            }
                                            e.AppendAttributeSkipNotify(a);
                                        }
                                        while(r.MoveToNextAttribute());
                                        r.MoveToElement();
                                    }
                                    this._currentContainer.AddNodeSkipNotify(e);
                                    if (!r.IsEmptyElement)
                                    {
                                        this._currentContainer = e;
                                        if ($.$$.System.String.op_Inequality(this._baseUri, null))
                                        {
                                            this._baseUri = baseUri;
                                        }
                                    }
                                    break;
                                }
                                case 15/*XmlNodeType.EndElement*/:
                                {
                                    this._currentContainer.content ??= $.$$.System.String.Empty;
                                    /*XElement?*/ let e = $.$as(this._currentContainer, $.$spxl.System.Xml.Linq.XElement);
                                    $.$$.System.Diagnostics.Debug.Assert$2(e !== null, "EndElement received but the current container is not an element.");
                                    if (e !== null && this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                    {
                                        e.SetEndElementLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                    }
                                    if (this._currentContainer === rootContainer)
                                    {
                                        return false;
                                    }
                                    if ($.$$.System.String.op_Inequality(this._baseUri, null) && this._currentContainer.HasBaseUri)
                                    {
                                        this._baseUri = this._currentContainer.parent.BaseUri;
                                    }
                                    this._currentContainer = this._currentContainer.parent;
                                    break;
                                }
                                case 3/*XmlNodeType.Text*/:
                                case 14/*XmlNodeType.SignificantWhitespace*/:
                                case 13/*XmlNodeType.Whitespace*/:
                                if (($.$$.System.String.op_Inequality(this._baseUri, null) && $.$$.System.String.op_Inequality(this._baseUri, baseUri)) || (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo()))
                                {
                                    newNode = new $.$spxl.System.Xml.Linq.XText().$ctor$3(await r.GetValueAsync().ConfigureAwait$2(false));
                                }
                                else 
                                {
                                    this._currentContainer.AddStringSkipNotify(await r.GetValueAsync().ConfigureAwait$2(false));
                                }
                                break;
                                case 4/*XmlNodeType.CDATA*/:
                                newNode = new $.$spxl.System.Xml.Linq.XCData().$ctor$6(await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 8/*XmlNodeType.Comment*/:
                                newNode = new $.$spxl.System.Xml.Linq.XComment().$ctor$3(await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 7/*XmlNodeType.ProcessingInstruction*/:
                                newNode = new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 10/*XmlNodeType.DocumentType*/:
                                newNode = new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute$2("PUBLIC"), r.GetAttribute$2("SYSTEM"), await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 5/*XmlNodeType.EntityReference*/:
                                if (!r.CanResolveEntity)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                                }
                                r.ResolveEntity();
                                break;
                                case 16/*XmlNodeType.EndEntity*/:
                                break;
                                default:
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                            }
                            if (newNode !== null)
                            {
                                if ($.$$.System.String.op_Inequality(this._baseUri, null) && $.$$.System.String.op_Inequality(this._baseUri, baseUri))
                                {
                                    newNode.SetBaseUri(baseUri);
                                }
                                if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                {
                                    newNode.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                }
                                this._currentContainer.AddNodeSkipNotify(newNode);
                            }
                            return true;
                        });
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._eCache = $.$default($.$spxl.System.Xml.Linq.NamespaceCache);
                        this._aCache = $.$default($.$spxl.System.Xml.Linq.NamespaceCache);
                    }
                    static $h = 1435600;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"rootContainer","p":1370064},{"n":"r","p":53394070}],"n":"ReadContentFrom","d":1435600,"h":34361173968,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,"p":[{"n":"rootContainer","p":1370064},{"n":"r","p":53394070}],"n":"ReadContentFromAsync","d":1435600,"h":38656141264,"f":16781313},{"r":262145,"p":[{"n":"rootContainer","p":1370064},{"n":"r","p":53394070}],"n":"ReadContentFromContainer","d":1435600,"h":42951108560,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,"p":[{"n":"rootContainer","p":1370064},{"n":"r","p":53394070}],"n":"ReadContentFromContainerAsync","d":1435600,"h":47246075856,"f":16781313}],"l":[{"t":780240,"n":"_eCache","d":1435600,"h":4296402896,"f":4194306},{"t":780240,"n":"_aCache","d":1435600,"h":8591370192,"f":4194306},{"t":13941398,"n":"_lineInfo","d":1435600,"h":12886337488,"f":4194306},{"t":1370064,"n":"_currentContainer","d":1435600,"h":17181304784,"f":4194306},{"t":1310721,"n":"_baseUri","d":1435600,"h":21476272080,"f":4194306}],"c":[{"p":[{"n":"rootContainer","p":1370064}],"n":".ctor","o":"$ctor$2","d":1435600,"h":25771239376,"f":16777217},{"p":[{"n":"rootContainer","p":1370064},{"n":"r","p":53394070},{"n":"o","p":714704}],"n":".ctor","o":"$ctor$1","d":1435600,"h":30066206672,"f":16777217}],"d":1370064,"h":1435600}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Xml.Linq.XContainer.ContentReader`; }
                }, $cls, ($v) => $cls.$_ContentReader = $v);
            }
            /*void */ RemoveNode(/*XNode*/ n)
            {
                /*bool*/ let notify = this.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                if (n.parent !== this)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this.content !== null, "content != null");
                /*XNode*/ let p = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                while(p.next !== n)
                {
                    p = p.next;
                }
                if (p === n)
                {
                    this.content = null;
                }
                else 
                {
                    if (this.content === n)
                    {
                        this.content = p;
                    }
                    p.next = n.next;
                }
                n.parent = null;
                n.next = null;
                if (notify)
                {
                    this.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                }
            }
            /*void */ RemoveNodesSkipNotify()
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        /*XNode*/ let next = n.next;
                        n.parent = null;
                        n.next = null;
                        n = next;
                    }
                    while(n !== this.content);
                }
                this.content = null;
            }
            /*void */ ValidateNode(/*XNode*/ node, /*XNode?*/ previous)
            {
            }
            /*void */ ValidateString(/*string*/ s)
            {
            }
            /*void */ WriteContentTo(/*XmlWriter*/ writer)
            {
                if (this.content !== null)
                {
                    /*string?*/ let stringContent = $.$as(this.content, $.$$.System.String);
                    if ($.$$.System.String.op_Inequality(stringContent, null))
                    {
                        if ($.$is(this, $.$spxl.System.Xml.Linq.XDocument))
                        {
                            writer.WriteWhitespace(stringContent);
                        }
                        else 
                        {
                            writer.WriteString(stringContent);
                        }
                    }
                    else 
                    {
                        /*XNode*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                        do
                        {
                            n = n.next;
                            n.WriteTo(writer);
                        }
                        while(n !== this.content);
                    }
                }
            }
            /*Task *//*async*/  WriteContentToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (this.content !== null)
                    {
                        /*string?*/ let stringContent = $.$as(this.content, $.$$.System.String);
                        if ($.$$.System.String.op_Inequality(stringContent, null))
                        {
                            cancellationToken.ThrowIfCancellationRequested();
                            /*Task*/ let tWrite;
                            if ($.$is(this, $.$spxl.System.Xml.Linq.XDocument))
                            {
                                tWrite = writer.WriteWhitespaceAsync(stringContent);
                            }
                            else 
                            {
                                tWrite = writer.WriteStringAsync(stringContent);
                            }
                            await tWrite.ConfigureAwait(false);
                        }
                        else 
                        {
                            /*XNode*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                            do
                            {
                                n = n.next;
                                await n.WriteToAsync(writer, cancellationToken).ConfigureAwait(false);
                            }
                            while(n !== this.content);
                        }
                    }
                });
            }
            static /*void */ AddContentToList(/*List<object?>*/ list, /*object?*/ content)
            {
                /*IEnumerable?*/ let e = $.$is(content, $.$$.System.String) ? null : $.$as(content, $.$$.System.Collections.IEnumerable);
                if (e === null)
                {
                    list.Add(content);
                }
                else 
                {
                    var $en3 = e.System$Collections$IEnumerable$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (obj !== null)
                            {
                                $.$spxl.System.Xml.Linq.XContainer.AddContentToList(list, obj);
                            }
                        }
                    }
                }
            }
            static /*object? */ GetContentSnapshot(/*object?*/ content)
            {
                if ($.$is(content, $.$$.System.String) || !($.$is(content, $.$$.System.Collections.IEnumerable)))
                {
                    return content;
                }
                /*List<object?>*/ let list = new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                $.$spxl.System.Xml.Linq.XContainer.AddContentToList(list, content);
                return list;
            }
            static $h = 1370064;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2287568,"p":[{"p":2287568,"g":{"r":0,"d":0,"h":21476206544,"f":50331649},"n":"FirstNode","d":1370064,"h":17181239248,"f":2097153},{"p":2287568,"g":{"r":0,"d":0,"h":30066141136,"f":50331649},"n":"LastNode","d":1370064,"h":25771173840,"f":2097153}],"m":[{"r":65537,"p":[{"n":"content","p":131073}],"n":"Add","d":1370064,"h":34361108432,"f":16777217},{"r":65537,"p":[{"n":"content","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"Add","o":"@$1","d":1370064,"h":38656075728,"f":16777217},{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddFirst","d":1370064,"h":42951043024,"f":16777217},{"r":65537,"p":[{"n":"content","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"AddFirst","o":"@$1","d":1370064,"h":47246010320,"f":16777217},{"r":58440342,"n":"CreateWriter","d":1370064,"h":51540977616,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"DescendantNodes","d":1370064,"h":55835944912,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"Descendants","d":1370064,"h":60130912208,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2156496}],"n":"Descendants","o":"@$1","d":1370064,"h":64425879504,"f":16777217},{"r":1697744,"p":[{"n":"name","p":2156496}],"n":"Element","d":1370064,"h":68720846800,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"Elements","d":1370064,"h":73015814096,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2156496}],"n":"Elements","o":"@$1","d":1370064,"h":77310781392,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"Nodes","d":1370064,"h":81605748688,"f":16777217},{"r":65537,"n":"RemoveNodes","d":1370064,"h":85900715984,"f":16777217},{"r":65537,"p":[{"n":"content","p":131073}],"n":"ReplaceNodes","d":1370064,"h":90195683280,"f":16777217},{"r":65537,"p":[{"n":"content","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"ReplaceNodes","o":"@$1","d":1370064,"h":94490650576,"f":16777217},{"r":65537,"p":[{"n":"a","p":1173456}],"n":"AddAttribute","d":1370064,"h":98785617872,"f":16777352},{"r":65537,"p":[{"n":"a","p":1173456}],"n":"AddAttributeSkipNotify","d":1370064,"h":103080585168,"f":16777352},{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddContentSkipNotify","d":1370064,"h":107375552464,"f":16777224},{"r":65537,"p":[{"n":"n","p":2287568}],"n":"AddNode","d":1370064,"h":111670519760,"f":16777224},{"r":65537,"p":[{"n":"n","p":2287568}],"n":"AddNodeSkipNotify","d":1370064,"h":115965487056,"f":16777224},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AddString","d":1370064,"h":120260454352,"f":16777224},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AddStringSkipNotify","d":1370064,"h":124555421648,"f":16777224},{"r":65537,"p":[{"n":"n","p":2287568}],"n":"AppendNode","d":1370064,"h":128850388944,"f":16777224},{"r":65537,"p":[{"n":"n","p":2287568}],"n":"AppendNodeSkipNotify","d":1370064,"h":133145356240,"f":16777224},{"r":65537,"p":[{"n":"sb","p":122814465}],"n":"AppendText","d":1370064,"h":137440323536,"f":16809992},{"r":1310721,"n":"GetTextOnly","d":1370064,"h":141735290832,"f":16777218},{"r":1310721,"p":[{"n":"n","p":2287568,"f":4}],"n":"CollectText","d":1370064,"h":146030258128,"f":16777218},{"r":262145,"p":[{"n":"e","p":1370064}],"n":"ContentsEqual","d":1370064,"h":150325225424,"f":16777224},{"r":655361,"n":"ContentsHashCode","d":1370064,"h":154620192720,"f":16777224},{"r":65537,"n":"ConvertTextToNode","d":1370064,"h":158915160016,"f":16777224},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"self","p":262145}],"n":"GetDescendantNodes","d":1370064,"h":163210127312,"f":16777224},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2156496},{"n":"self","p":262145}],"n":"GetDescendants","d":1370064,"h":167505094608,"f":16777224},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2156496}],"n":"GetElements","d":1370064,"h":171800061904,"f":16777218},{"r":1310721,"p":[{"n":"value","p":131073}],"n":"GetStringValue","d":1370064,"h":176095029200,"f":16777256},{"r":65537,"p":[{"n":"r","p":53394070}],"n":"ReadContentFrom","o":"@$1","d":1370064,"h":180389996496,"f":16777224},{"r":65537,"p":[{"n":"r","p":53394070},{"n":"o","p":714704}],"n":"ReadContentFrom","d":1370064,"h":184684963792,"f":16777224},{"r":133169153,"p":[{"n":"r","p":53394070},{"n":"cancellationToken","p":125829121}],"n":"ReadContentFromAsync","d":1370064,"h":188979931088,"f":16781320},{"r":133169153,"p":[{"n":"r","p":53394070},{"n":"o","p":714704},{"n":"cancellationToken","p":125829121}],"n":"ReadContentFromAsync","o":"@$1","d":1370064,"h":193274898384,"f":16781320},{"r":65537,"p":[{"n":"n","p":2287568}],"n":"RemoveNode","d":1370064,"h":201864832976,"f":16777224},{"r":65537,"n":"RemoveNodesSkipNotify","d":1370064,"h":206159800272,"f":16777218},{"r":65537,"p":[{"n":"node","p":2287568},{"n":"previous","p":2287568}],"n":"ValidateNode","d":1370064,"h":210454767568,"f":16777352},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"ValidateString","d":1370064,"h":214749734864,"f":16777352},{"r":65537,"p":[{"n":"writer","p":58440342}],"n":"WriteContentTo","d":1370064,"h":219044702160,"f":16777224},{"r":133169153,"p":[{"n":"writer","p":58440342},{"n":"cancellationToken","p":125829121}],"n":"WriteContentToAsync","d":1370064,"h":223339669456,"f":16781320},{"r":65537,"p":[{"n":"list","p":$.$$.System.Collections.Generic.List$$($.$$.System.Object).$h},{"n":"content","p":131073}],"n":"AddContentToList","d":1370064,"h":227634636752,"f":16777250},{"r":131073,"p":[{"n":"content","p":131073}],"n":"GetContentSnapshot","d":1370064,"h":231929604048,"f":16777256}],"l":[{"t":131073,"n":"content","d":1370064,"h":4296337360,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$3","d":1370064,"h":8591304656,"f":16777224},{"p":[{"n":"other","p":1370064}],"n":".ctor","o":"$ctor$4","d":1370064,"h":12886271952,"f":16777224}],"i":[13941398],"j":[1435600],"h":1370064}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XContainer`; }
        });
        
        $asm.$cls("$spxl.System.Text.StringBuilderCache", ($self) => class StringBuilderCache
        {
            /*int*/ static MaxBuilderSize = 360;
            /*int*/ static DefaultCapacity = 16;
            /*StringBuilder?*/ static t_cachedInstance = null;
            static /*StringBuilder */ Acquire(/*int*/ capacity)
            {
                if (capacity <= 360/*MaxBuilderSize*/)
                {
                    /*StringBuilder?*/ let sb = $.$spxl.System.Text.StringBuilderCache.t_cachedInstance;
                    if (sb !== null)
                    {
                        if (capacity <= sb.Capacity)
                        {
                            $.$spxl.System.Text.StringBuilderCache.t_cachedInstance = null;
                            sb.Clear();
                            return sb;
                        }
                    }
                }
                return new $.$$.System.Text.StringBuilder().$ctor$4(capacity);
            }
            static /*void */ Release(/*StringBuilder*/ sb)
            {
                if (sb.Capacity <= 360/*MaxBuilderSize*/)
                {
                    $.$spxl.System.Text.StringBuilderCache.t_cachedInstance = sb;
                }
            }
            static /*string */ GetStringAndRelease(/*StringBuilder*/ sb)
            {
                /*string*/ let result = $.$$.System.Text.StringBuilder.ToString.call(sb);
                $.$spxl.System.Text.StringBuilderCache.Release(sb);
                return result;
            }
            static $h = 255952;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":122814465,"p":[{"n":"capacity","p":655361,"f":65,"v":16}],"n":"Acquire","d":255952,"h":17180125136,"f":16777249},{"r":65537,"p":[{"n":"sb","p":122814465}],"n":"Release","d":255952,"h":21475092432,"f":16777249},{"r":1310721,"p":[{"n":"sb","p":122814465}],"n":"GetStringAndRelease","d":255952,"h":25770059728,"f":16777249}],"l":[{"t":655361,"n":"MaxBuilderSize","d":255952,"h":4295223248,"f":4194344},{"t":655361,"n":"DefaultCapacity","d":255952,"h":8590190544,"f":4194338},{"t":122814465,"n":"t_cachedInstance","d":255952,"h":12885157840,"f":4194338,"a":[{"t":140050433,"c":4435017729}]}],"h":255952}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.StringBuilderCache`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.BaseUriAnnotation", ($self) => class BaseUriAnnotation extends $.$$.System.Object
        {
            /*string*/ baseUri = null;
            $ctor$1(/*string*/ baseUri)
            {
                super.$ctor();
                {
                    this.baseUri = baseUri;
                }
                return this;
            }
            static $h = 321488;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"baseUri","d":321488,"h":4295288784,"f":4194312}],"c":[{"p":[{"n":"baseUri","p":1310721}],"n":".ctor","o":"$ctor$1","d":321488,"h":8590256080,"f":16777217}],"h":321488}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.BaseUriAnnotation`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.LineInfoAnnotation", ($self) => class LineInfoAnnotation extends $.$$.System.Object
        {
            /*int*/ lineNumber = 0;
            /*int*/ linePosition = 0;
            $ctor$1(/*int*/ lineNumber, /*int*/ linePosition)
            {
                super.$ctor();
                {
                    this.lineNumber = lineNumber;
                    this.linePosition = linePosition;
                }
                return this;
            }
            static $h = 583632;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"lineNumber","d":583632,"h":4295550928,"f":4194312},{"t":655361,"n":"linePosition","d":583632,"h":8590518224,"f":4194312}],"c":[{"p":[{"n":"lineNumber","p":655361},{"n":"linePosition","p":655361}],"n":".ctor","o":"$ctor$1","d":583632,"h":12885485520,"f":16777217}],"h":583632}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.LineInfoAnnotation`; }
        });
        
        $asm.$cls("$spxl.System.Collections.Generic.EnumerableHelpers", ($self) => class EnumerableHelpers
        {
            static /*void */ Reset(T, /*ref T*/ enumerator)
            {
                return $.$dsp(enumerator.$v, T, ($t) => $t.System$Collections$IEnumerator$Reset,);
            }
            static /*IEnumerator<T> */ GetEmptyEnumerator(T)
            {
                return ($.$$.System.Array.Empty(T)).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            static /*T[] */ ToArray(T, /*IEnumerable<T>*/ source, /*out int*/ length)
            {
                /*int*/ let ArrayMaxLength = 2147483591;
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Array.MaxLength === ArrayMaxLength, "Array.MaxLength == ArrayMaxLength");
                let ic;
                if ($.$is(source, $.$$.System.Collections.Generic.ICollection$$(T), { set $v(v){ ic = v; } }))
                {
                    /*int*/ let count = ic.System$Collections$Generic$ICollection$$$Count;
                    if (count !== 0)
                    {
                        /*T[]*/ let arr = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [count], null);
                        ic.System$Collections$Generic$ICollection$$$CopyTo(arr, 0, [T]);
                        length.$v = count;
                        return arr;
                    }
                }
                else 
                {
                    let en = null;
                    try
                    {
                        en = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                        if (en.System$Collections$IEnumerator$MoveNext())
                        {
                            /*int*/ let DefaultCapacity = 4;
                            /*T[]*/ let arr = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [DefaultCapacity], null);
                            $.$$.System.Array.$WriteT1.call(arr, en.System$Collections$Generic$IEnumerator$$$Current, 0);
                            /*int*/ let count = 1;
                            while(en.System$Collections$IEnumerator$MoveNext())
                            {
                                if (count === arr.length)
                                {
                                    /*int*/ let newLength = count << 1;
                                    if ((newLength >>> 0) > ArrayMaxLength)
                                    {
                                        newLength = ArrayMaxLength <= count ? ((count + 1) | 0) : ArrayMaxLength;
                                    }
                                    $.$$.System.Array.Resize(T, $.$ref(() => arr, ($v) => arr = $v, $.$typeArray(T)), newLength);
                                }
                                $.$$.System.Array.$WriteT1.call(arr, en.System$Collections$Generic$IEnumerator$$$Current, count++);
                            }
                            length.$v = count;
                            return arr;
                        }
                    }
                    finally
                    {
                        en?.System$IDisposable$Dispose();
                    }
                }
                length.$v = 0;
                return $.$$.System.Array.Empty(T);
            }
            static $h = 124880;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"enumerator","p":(T) => T.$h,"f":4}],"g":["T"],"n":"Reset","d":124880,"h":4295092176,"f":16908328},{"r":(T) => $.$$.System.Collections.Generic.IEnumerator$$(T).$h,"g":["T"],"n":"GetEmptyEnumerator","d":124880,"h":8590059472,"f":16908328},{"r":(T) => $.$typeArray(T).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"length","p":655361,"f":2}],"g":["T"],"n":"ToArray","d":124880,"h":12885026768,"f":16908328}],"h":124880}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.EnumerableHelpers`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XDeclaration", ($self) => class XDeclaration extends $.$$.System.Object
        {
            /*string?*/ _version = null;
            /*string?*/ _encoding = null;
            /*string?*/ _standalone = null;
            $ctor$1(/*string?*/ version, /*string?*/ encoding, /*string?*/ standalone)
            {
                super.$ctor();
                {
                    this._version = version;
                    this._encoding = encoding;
                    this._standalone = standalone;
                }
                return this;
            }
            $ctor$3(/*XDeclaration*/ other)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this._version = other._version;
                    this._encoding = other._encoding;
                    this._standalone = other._standalone;
                }
                return this;
            }
            $ctor$2(/*XmlReader*/ r)
            {
                super.$ctor();
                {
                    this._version = r.GetAttribute$2("version");
                    this._encoding = r.GetAttribute$2("encoding");
                    this._standalone = r.GetAttribute$2("standalone");
                    r.Read();
                }
                return this;
            }
            /*string? */ get Encoding()
            {
                return this._encoding;
            }
            /*string? */ set Encoding(value)
            {
                this._encoding = value;
            }
            /*string? */ get Standalone()
            {
                return this._standalone;
            }
            /*string? */ set Standalone(value)
            {
                this._standalone = value;
            }
            /*string? */ get Version()
            {
                return this._version;
            }
            /*string? */ set Version(value)
            {
                this._version = value;
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*StringBuilder*/ let sb = $.$spxl.System.Text.StringBuilderCache.Acquire(16);
                sb.Append$19("<?xml");
                if ($.$$.System.String.op_Inequality(this._version, null))
                {
                    sb.Append$19(" version=\"");
                    sb.Append$19(this._version);
                    sb.Append$3(/*\"*/ 34);
                }
                if ($.$$.System.String.op_Inequality(this._encoding, null))
                {
                    sb.Append$19(" encoding=\"");
                    sb.Append$19(this._encoding);
                    sb.Append$3(/*\"*/ 34);
                }
                if ($.$$.System.String.op_Inequality(this._standalone, null))
                {
                    sb.Append$19(" standalone=\"");
                    sb.Append$19(this._standalone);
                    sb.Append$3(/*\"*/ 34);
                }
                sb.Append$19("?>");
                return $.$spxl.System.Text.StringBuilderCache.GetStringAndRelease(sb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XDeclaration.ToString.apply(this, arguments); }
            static $h = 1501136;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":34361239504,"f":50331649},"s":{"r":0,"d":0,"h":38656206800,"f":83886081},"n":"Encoding","d":1501136,"h":30066272208,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":47246141392,"f":50331649},"s":{"r":0,"d":0,"h":51541108688,"f":83886081},"n":"Standalone","d":1501136,"h":42951174096,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":60131043280,"f":50331649},"s":{"r":0,"d":0,"h":64426010576,"f":83886081},"n":"Version","d":1501136,"h":55836075984,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":1501136,"h":68720977872,"f":16809985}],"l":[{"t":1310721,"n":"_version","d":1501136,"h":4296468432,"f":4194306},{"t":1310721,"n":"_encoding","d":1501136,"h":8591435728,"f":4194306},{"t":1310721,"n":"_standalone","d":1501136,"h":12886403024,"f":4194306}],"c":[{"p":[{"n":"version","p":1310721},{"n":"encoding","p":1310721},{"n":"standalone","p":1310721}],"n":".ctor","o":"$ctor$1","d":1501136,"h":17181370320,"f":16777217},{"p":[{"n":"other","p":1501136}],"n":".ctor","o":"$ctor$3","d":1501136,"h":21476337616,"f":16777217},{"p":[{"n":"r","p":53394070}],"n":".ctor","o":"$ctor$2","d":1501136,"h":25771304912,"f":16777224}],"h":1501136}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XDeclaration`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XHelper", ($self) => class XHelper
        {
            static /*bool */ IsInstanceOfType(/*object?*/ o, /*Type*/ type)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Inequality$1(type, null), "type != null");
                return o !== null && type.IsAssignableFrom($.$$.System.Object.GetType.call(o));
            }
            static $h = 2090960;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"o","p":131073},{"n":"type","p":142475265}],"n":"IsInstanceOfType","d":2090960,"h":4297058256,"f":16777256}],"h":2090960}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XHelper`; }
        });
        
        $asm.$cls("$spxl.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$spxl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Private.Xml.Linq", $.$spxl.System.SR.$type.Assembly);
                    $.$spxl.System.SR.s_resourceManager = temp;
                }
                return $.$spxl.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$spxl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$spxl.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_AddAttribute()
            {
                return "An attribute cannot be added to content.";
            }
            static /*string */ get Argument_AddNode()
            {
                return "A node of type {0} cannot be added to content.";
            }
            static /*string */ FormatArgument_AddNode(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("A node of type {0} cannot be added to content.", arg1);
            }
            static /*string */ get Argument_AddNonWhitespace()
            {
                return "Non-whitespace characters cannot be added to content.";
            }
            static /*string */ get Argument_ConvertToString()
            {
                return "The argument cannot be converted to a string.";
            }
            static /*string */ get Argument_InvalidExpandedName()
            {
                return "'{0}' is an invalid expanded name.";
            }
            static /*string */ FormatArgument_InvalidExpandedName(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("'{0}' is an invalid expanded name.", arg1);
            }
            static /*string */ get Argument_InvalidPIName()
            {
                return "'{0}' is an invalid name for a processing instruction.";
            }
            static /*string */ FormatArgument_InvalidPIName(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("'{0}' is an invalid name for a processing instruction.", arg1);
            }
            static /*string */ get Argument_MustBeDerivedFrom()
            {
                return "The argument must be derived from {0}.";
            }
            static /*string */ FormatArgument_MustBeDerivedFrom(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The argument must be derived from {0}.", arg1);
            }
            static /*string */ get Argument_NamespaceDeclarationPrefixed()
            {
                return "The prefix '{0}' cannot be bound to the empty namespace name.";
            }
            static /*string */ FormatArgument_NamespaceDeclarationPrefixed(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The prefix '{0}' cannot be bound to the empty namespace name.", arg1);
            }
            static /*string */ get Argument_NamespaceDeclarationXml()
            {
                return "The prefix 'xml' is bound to the namespace name 'http://www.w3.org/XML/1998/namespace'. Other prefixes must not be bound to this namespace name, and it must not be declared as the default namespace.";
            }
            static /*string */ get Argument_NamespaceDeclarationXmlns()
            {
                return "The prefix 'xmlns' is bound to the namespace name 'http://www.w3.org/2000/xmlns/'. It must not be declared. Other prefixes must not be bound to this namespace name, and it must not be declared as the default namespace.";
            }
            static /*string */ get Argument_XObjectValue()
            {
                return "An XObject cannot be used as a value.";
            }
            static /*string */ get InvalidOperation_DeserializeInstance()
            {
                return "This instance cannot be deserialized.";
            }
            static /*string */ get InvalidOperation_DocumentStructure()
            {
                return "This operation would create an incorrectly structured document.";
            }
            static /*string */ get InvalidOperation_DuplicateAttribute()
            {
                return "Duplicate attribute.";
            }
            static /*string */ get InvalidOperation_ExpectedEndOfFile()
            {
                return "The XmlReader state should be EndOfFile after this operation.";
            }
            static /*string */ get InvalidOperation_ExpectedInteractive()
            {
                return "The XmlReader state should be Interactive.";
            }
            static /*string */ get InvalidOperation_ExpectedNodeType()
            {
                return "The XmlReader must be on a node of type {0} instead of a node of type {1}.";
            }
            static /*string */ FormatInvalidOperation_ExpectedNodeType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("The XmlReader must be on a node of type {0} instead of a node of type {1}.", arg1, arg2);
            }
            static /*string */ get InvalidOperation_ExternalCode()
            {
                return "This operation was corrupted by external code.";
            }
            static /*string */ get InvalidOperation_MissingAncestor()
            {
                return "A common ancestor is missing.";
            }
            static /*string */ get InvalidOperation_MissingParent()
            {
                return "The parent is missing.";
            }
            static /*string */ get InvalidOperation_MissingRoot()
            {
                return "The root element is missing.";
            }
            static /*string */ get InvalidOperation_UnexpectedNodeType()
            {
                return "The XmlReader should not be on a node of type {0}.";
            }
            static /*string */ FormatInvalidOperation_UnexpectedNodeType(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The XmlReader should not be on a node of type {0}.", arg1);
            }
            static /*string */ get InvalidOperation_UnresolvedEntityReference()
            {
                return "The XmlReader cannot resolve entity references.";
            }
            static /*string */ get InvalidOperation_WriteAttribute()
            {
                return "An attribute cannot be written after content.";
            }
            static /*string */ get NotSupported_WriteBase64()
            {
                return "This XmlWriter does not support base64 encoded data.";
            }
            static /*string */ get NotSupported_WriteEntityRef()
            {
                return "This XmlWriter does not support entity references.";
            }
            static /*string */ get Argument_CreateNavigator()
            {
                return "This XPathNavigator cannot be created on a node of type {0}.";
            }
            static /*string */ FormatArgument_CreateNavigator(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("This XPathNavigator cannot be created on a node of type {0}.", arg1);
            }
            static /*string */ get InvalidOperation_BadNodeType()
            {
                return "This operation is not valid on a node of type {0}.";
            }
            static /*string */ FormatInvalidOperation_BadNodeType(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("This operation is not valid on a node of type {0}.", arg1);
            }
            static /*string */ get InvalidOperation_UnexpectedEvaluation()
            {
                return "The XPath expression evaluated to unexpected type {0}.";
            }
            static /*string */ FormatInvalidOperation_UnexpectedEvaluation(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The XPath expression evaluated to unexpected type {0}.", arg1);
            }
            static /*string */ get NotSupported_MoveToId()
            {
                return "This XPathNavigator does not support IDs.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$spxl.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$spxl.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$spxl.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$spxl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$spxl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$spxl.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 190416;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":190416}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XHashtable<>", (TValue) => $asm.$gt("$spxl.System.Xml.Linq.XHashtable<>", [TValue], ($self) => class XHashtable$$ extends $.$$.System.Object
        {
            /*XHashtableState*/ _state = null;
            static $_ExtractKeyDelegate;
            static get ExtractKeyDelegate()
            {
                let $cls = $.$spxl.System.Xml.Linq.XHashtable$$(TValue);
                return $cls.$_ExtractKeyDelegate ??= $asm.$ncls("$spxl.System.Xml.Linq.XHashtable$$.ExtractKeyDelegate", ($self) => class ExtractKeyDelegate extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*string?*/ Invoke(/**/ value)
                    {
                        return this.$nativeFunction.call(this.$target, value);
                    }
                    static $h = 1894352;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":1310721,"p":[{"n":"value","p":TValue?.$h??1507328}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777345},{"r":57016321,"p":[{"n":"value","p":TValue?.$h??1507328},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777345},{"r":1310721,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[57212929,113246209],"d":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>.ExtractKeyDelegate`; }
                }, $cls, ($v) => $cls.$_ExtractKeyDelegate = $v);
            }
            $ctor$1(/*ExtractKeyDelegate*/ extractKey, /*int*/ capacity)
            {
                super.$ctor();
                {
                    this._state = new ($.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState)().$ctor$1(extractKey, capacity);
                }
                return this;
            }
            /*bool */ TryGetValue(/*string*/ key, /*int*/ index, /*int*/ count, /*out TValue*/ value)
            {
                return this._state.TryGetValue(key, index, count, value);
            }
            /*TValue */ Add(/*TValue*/ value)
            {
                /*TValue*/ let newValue;
                while(true)
                {
                    if (this._state.TryAdd(value, $.$ref(() => newValue, ($v) => newValue = $v, TValue)))
                    {
                        return newValue;
                    }
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this)
                        {
                            /*XHashtableState*/ let newState = this._state.Resize();
                            $.$$.System.Threading.Thread.MemoryBarrier();
                            this._state = newState;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this)
                    }
                }
            }
            static $_XHashtableState;
            static get XHashtableState()
            {
                let $cls = $.$spxl.System.Xml.Linq.XHashtable$$(TValue);
                return $cls.$_XHashtableState ??= $asm.$ncls("$spxl.System.Xml.Linq.XHashtable$$.XHashtableState", ($self) => class XHashtableState extends $.$$.System.Object
                {
                    /*int[]*/ _buckets = null;
                    /*Entry[]*/ _entries = null;
                    /*int*/ _numEntries = 0;
                    /*ExtractKeyDelegate*/ _extractKey = null;
                    /*int*/ static EndOfList = 0;
                    /*int*/ static FullList = -1;
                    $ctor$1(/*ExtractKeyDelegate*/ extractKey, /*int*/ capacity)
                    {
                        super.$ctor();
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Numerics.BitOperations.IsPow2(capacity), "capacity must be a power of 2");
                            $.$$.System.Diagnostics.Debug.Assert$2(extractKey !== null, "extractKey may not be null");
                            this._buckets = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [capacity], null);
                            this._entries = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.Entry), null, [capacity], null);
                            this._extractKey = extractKey;
                        }
                        return this;
                    }
                    /*XHashtableState */ Resize()
                    {
                        if (this._numEntries < this._buckets.length)
                        {
                            return this;
                        }
                        /*int*/ let newSize = 0;
                        for(/*int*/ let bucketIdx = 0; bucketIdx < this._buckets.length; bucketIdx++)
                        {
                            /*int*/ let entryIdx = $.$$.System.Array.$ReadT1.call(this._buckets, bucketIdx);
                            if (entryIdx === 0/*EndOfList*/)
                            {
                                entryIdx = $.$$.System.Threading.Interlocked.CompareExchange$3($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$$.System.Int32, this._buckets, bucketIdx, false, true), -1/*FullList*/, 0/*EndOfList*/);
                            }
                            while(entryIdx > 0/*EndOfList*/)
                            {
                                if ($.$$.System.String.op_Inequality(this._extractKey.Invoke($.$$.System.Array.$ReadT1.call(this._entries, entryIdx).Value), null))
                                {
                                    newSize++;
                                }
                                if ($.$$.System.Array.$ReadT1.call(this._entries, entryIdx).Next === 0/*EndOfList*/)
                                {
                                    entryIdx = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => $.$$.System.Array.$ReadT1.call(this._entries, entryIdx).Next, ($v) => $.$$.System.Array.$ReadT1.call(this._entries, entryIdx).Next = $v, $.$$.System.Int32), -1/*FullList*/, 0/*EndOfList*/);
                                }
                                else 
                                {
                                    entryIdx = $.$$.System.Array.$ReadT1.call(this._entries, entryIdx).Next;
                                }
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(entryIdx === 0/*EndOfList*/, "Resize() should only be called by one thread");
                        }
                        if (newSize < $.trunc(this._buckets.length / 2))
                        {
                            newSize = this._buckets.length;
                        }
                        else 
                        {
                            newSize = ((this._buckets.length * 2) | 0);
                            if (newSize < 0)
                            {
                                throw new $.$$.System.OverflowException().$ctor$13();
                            }
                        }
                        /*XHashtableState*/ let newHashtable = new ($.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState)().$ctor$1(this._extractKey, newSize);
                        for(/*int*/ let bucketIdx = 0; bucketIdx < this._buckets.length; bucketIdx++)
                        {
                            /*int*/ let entryIdx = $.$$.System.Array.$ReadT1.call(this._buckets, bucketIdx);
                            while(entryIdx > 0/*EndOfList*/)
                            {
                                newHashtable.TryAdd($.$$.System.Array.$ReadT1.call(this._entries, entryIdx).Value, $.$discardRef());
                                entryIdx = $.$$.System.Array.$ReadT1.call(this._entries, entryIdx).Next;
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(entryIdx === -1/*FullList*/, "Linked list should have been closed when it was counted");
                        }
                        return newHashtable;
                    }
                    /*bool */ TryGetValue(/*string*/ key, /*int*/ index, /*int*/ count, /*out TValue*/ value)
                    {
                        /*int*/ let hashCode = $.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.ComputeHashCode(key, index, count);
                        /*int*/ let entryIndex = 0;
                        if (this.FindEntry(hashCode, key, index, count, $.$ref(() => entryIndex, ($v) => entryIndex = $v, $.$$.System.Int32)))
                        {
                            value.$v = $.$$.System.Array.$ReadT1.call(this._entries, entryIndex).Value;
                            return true;
                        }
                        value.$v = $.$default(TValue);
                        return false;
                    }
                    /*bool */ TryAdd(/*TValue*/ value, /*out TValue*/ newValue)
                    {
                        /*int*/ let newEntry, entryIndex;
                        /*string?*/ let key;
                        /*int*/ let hashCode;
                        newValue.$v = value;
                        key = this._extractKey.Invoke(value);
                        if ($.$$.System.String.op_Equality(key, null))
                        {
                            return true;
                        }
                        hashCode = $.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.ComputeHashCode(key, 0, key.length);
                        newEntry = $.$$.System.Threading.Interlocked.Increment($.$ref(() => this._numEntries, ($v) => this._numEntries = $v, $.$$.System.Int32));
                        if (newEntry < 0 || newEntry >= this._buckets.length)
                        {
                            return false;
                        }
                        $.$$.System.Array.$ReadT1.call(this._entries, newEntry).Value = value;
                        $.$$.System.Array.$ReadT1.call(this._entries, newEntry).HashCode = hashCode;
                        $.$$.System.Threading.Thread.MemoryBarrier();
                        entryIndex = 0;
                        while(!this.FindEntry(hashCode, key, 0, key.length, $.$ref(() => entryIndex, ($v) => entryIndex = $v, $.$$.System.Int32)))
                        {
                            if (entryIndex === 0)
                            {
                                entryIndex = $.$$.System.Threading.Interlocked.CompareExchange$3($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$$.System.Int32, this._buckets, hashCode & (((this._buckets.length - 1) | 0)), false, true), newEntry, 0/*EndOfList*/);
                            }
                            else 
                            {
                                entryIndex = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => $.$$.System.Array.$ReadT1.call(this._entries, entryIndex).Next, ($v) => $.$$.System.Array.$ReadT1.call(this._entries, entryIndex).Next = $v, $.$$.System.Int32), newEntry, 0/*EndOfList*/);
                            }
                            if (entryIndex <= 0/*EndOfList*/)
                            {
                                return entryIndex === 0/*EndOfList*/;
                            }
                        }
                        newValue.$v = $.$$.System.Array.$ReadT1.call(this._entries, entryIndex).Value;
                        return true;
                    }
                    /*bool */ FindEntry(/*int*/ hashCode, /*string*/ key, /*int*/ index, /*int*/ count, /*ref int*/ entryIndex)
                    {
                        /*int*/ let previousIndex = entryIndex.$v;
                        /*int*/ let currentIndex;
                        if (previousIndex === 0)
                        {
                            currentIndex = $.$$.System.Array.$ReadT1.call(this._buckets, hashCode & (((this._buckets.length - 1) | 0)));
                        }
                        else 
                        {
                            currentIndex = previousIndex;
                        }
                        while(currentIndex > 0/*EndOfList*/)
                        {
                            if ($.$$.System.Array.$ReadT1.call(this._entries, currentIndex).HashCode === hashCode)
                            {
                                /*string?*/ let keyCompare = this._extractKey.Invoke($.$$.System.Array.$ReadT1.call(this._entries, currentIndex).Value);
                                if ($.$$.System.String.op_Equality(keyCompare, null))
                                {
                                    if ($.$$.System.Array.$ReadT1.call(this._entries, currentIndex).Next > 0/*EndOfList*/)
                                    {
                                        $.$$.System.Array.$ReadT1.call(this._entries, currentIndex).Value = $.$default(TValue);
                                        currentIndex = $.$$.System.Array.$ReadT1.call(this._entries, currentIndex).Next;
                                        if (previousIndex === 0)
                                        {
                                            $.$$.System.Array.$WriteT1.call(this._buckets, currentIndex, hashCode & (((this._buckets.length - 1) | 0)));
                                        }
                                        else 
                                        {
                                            $.$$.System.Array.$ReadT1.call(this._entries, previousIndex).Next = currentIndex;
                                        }
                                        continue;
                                    }
                                }
                                else 
                                {
                                    if (count === keyCompare.length && $.$$.System.String.CompareOrdinal$1(key, index, keyCompare, 0, count) === 0)
                                    {
                                        entryIndex.$v = currentIndex;
                                        return true;
                                    }
                                }
                            }
                            previousIndex = currentIndex;
                            currentIndex = $.$$.System.Array.$ReadT1.call(this._entries, currentIndex).Next;
                        }
                        entryIndex.$v = previousIndex;
                        return false;
                    }
                    static /*int */ ComputeHashCode(/*string*/ key, /*int*/ index, /*int*/ count)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Inequality(key, null), "key should have been checked previously for null");
                        return $.$$.System.String.GetHashCode$2($.$$.System.MemoryExtensions.AsSpan$1(key, index, count));
                    }
                    static $_Entry;
                    static get Entry()
                    {
                        let $cls = $.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState;
                        return $cls.$_Entry ??= $asm.$nstr("$spxl.System.Xml.Linq.XHashtable$$.XHashtableState.Entry", ($self) => class Entry extends $.$$.System.ValueType
                        {
                            /*TValue*/  get Value() { return this.$getField(0, 4); }
                            /*TValue*/  set Value(value) { this.$setField(0, 4, value); }
                            /*int*/  get HashCode() { return this.$getField(4, 4); }
                            /*int*/  set HashCode(value) { this.$setField(4, 4, value); }
                            /*int*/  get Next() { return this.$getField(8, 4); }
                            /*int*/  set Next(value) { this.$setField(8, 4, value); }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy.Value = this.Value;
                                copy.HashCode = this.HashCode;
                                copy.Next = this.Next;
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this.Value = $.$default(TValue);
                                this.HashCode = 0;
                                this.Next = 0;
                            }
                            static $h = 2025424;
                            static $z = 12;
                            static $f = 0b10000001011000000;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":TValue?.$h??1507328,"n":"Value","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194305},{"t":655361,"n":"HashCode","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194305},{"t":655361,"n":"Next","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194305}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217}],"d":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.$h,"h":this.$h}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>.XHashtableState.Entry`; }
                        }, $cls, ($v) => $cls.$_Entry = $v);
                    }
                    static $h = 1959888;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":this.$h,"n":"Resize","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777217},{"r":262145,"p":[{"n":"key","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361},{"n":"value","p":TValue?.$h??1507328,"f":2}],"n":"TryGetValue","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777217},{"r":262145,"p":[{"n":"value","p":TValue?.$h??1507328},{"n":"newValue","p":TValue?.$h??1507328,"f":2}],"n":"TryAdd","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":16777217},{"r":262145,"p":[{"n":"hashCode","p":655361},{"n":"key","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361},{"n":"entryIndex","p":655361,"f":4}],"n":"FindEntry","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777218},{"r":655361,"p":[{"n":"key","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"ComputeHashCode","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777250}],"l":[{"t":$.$typeArray($.$$.System.Int32).$h,"n":"_buckets","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$typeArray($.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.Entry).$h,"n":"_entries","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":655361,"n":"_numEntries","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).ExtractKeyDelegate.$h,"n":"_extractKey","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306},{"t":655361,"n":"EndOfList","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4194338},{"t":655361,"n":"FullList","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":4194338}],"c":[{"p":[{"n":"extractKey","p":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).ExtractKeyDelegate.$h},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777217}],"j":[$.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.Entry.$h],"d":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>.XHashtableState`; }
                }, $cls, ($v) => $cls.$_XHashtableState = $v);
            }
            static $h = 1828816;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"key","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361},{"n":"value","p":TValue?.$h??1507328,"f":2}],"n":"TryGetValue","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217},{"r":TValue?.$h??1507328,"p":[{"n":"value","p":TValue?.$h??1507328}],"n":"Add","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"l":[{"t":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.$h,"n":"_state","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"extractKey","p":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).ExtractKeyDelegate.$h},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217}],"g":[TValue?.$h??1507328],"j":[$.$spxl.System.Xml.Linq.XHashtable$$(TValue).ExtractKeyDelegate.$h,$.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.$h],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$spxl.System.Xml.XPath.XObjectExtensions", ($self) => class XObjectExtensions
        {
            static /*XContainer? */ GetParent(/*this XObject*/ obj)
            {
                /*XContainer?*/ let ret = obj.Parent ?? obj.Document;
                if (ret === obj)
                {
                    return null;
                }
                return ret;
            }
            static $h = 3401680;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1370064,"p":[{"n":"obj","p":2615248}],"n":"GetParent","d":3401680,"h":4298368976,"f":16777249}],"h":3401680}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.XPath.XObjectExtensions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XObjectChangeAnnotation", ($self) => class XObjectChangeAnnotation extends $.$$.System.Object
        {
            /*EventHandler<XObjectChangeEventArgs>?*/ changing = null;
            /*EventHandler<XObjectChangeEventArgs>?*/ changed = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2746320;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":$.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,"n":"changing","d":2746320,"h":4297713616,"f":4194312},{"t":$.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,"n":"changed","d":2746320,"h":8592680912,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$1","d":2746320,"h":12887648208,"f":16777217}],"h":2746320}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XObjectChangeAnnotation`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNamespace", ($self) => class XNamespace extends $.$$.System.Object
        {
            /*string*/ static xmlPrefixNamespace = null;
            /*string*/ static xmlnsPrefixNamespace = null;
            /*XHashtable<WeakReference<XNamespace>>?*/ static s_namespaces = null;
            /*WeakReference<XNamespace>?*/ static s_refNone = null;
            /*WeakReference<XNamespace>?*/ static s_refXml = null;
            /*WeakReference<XNamespace>?*/ static s_refXmlns = null;
            /*string*/ _namespaceName = null;
            /*int*/ _hashCode = 0;
            /*XHashtable<XName>*/ _names = null;
            /*int*/ static NamesCapacity = 8;
            /*int*/ static NamespacesCapacity = 32;
            $ctor$1(/*string*/ namespaceName)
            {
                super.$ctor();
                {
                    this._namespaceName = namespaceName;
                    this._hashCode = $.$$.System.String.GetHashCode.call(namespaceName);
                    this._names = new ($.$spxl.System.Xml.Linq.XHashtable$$($.$spxl.System.Xml.Linq.XName))().$ctor$1(new $.$spxl.System.Xml.Linq.XHashtable$$($.$spxl.System.Xml.Linq.XName).ExtractKeyDelegate().$ctor($.$spxl.System.Xml.Linq.XNamespace, $.$spxl.System.Xml.Linq.XNamespace.ExtractLocalName), 8/*NamesCapacity*/);
                }
                return this;
            }
            /*string */ get NamespaceName()
            {
                return this._namespaceName;
            }
            /*XName */ GetName$1(/*string*/ localName)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(localName, "localName");
                return this.GetName(localName, 0, localName.length);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this._namespaceName;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XNamespace.ToString.apply(this, arguments); }
            static /*XNamespace */ get None()
            {
                return $.$spxl.System.Xml.Linq.XNamespace.EnsureNamespace($.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_refNone, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_refNone = $v, $.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), $.$$.System.String.Empty);
            }
            static /*XNamespace */ get Xml()
            {
                return $.$spxl.System.Xml.Linq.XNamespace.EnsureNamespace($.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_refXml, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_refXml = $v, $.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), "http://www.w3.org/XML/1998/namespace"/*xmlPrefixNamespace*/);
            }
            static /*XNamespace */ get Xmlns()
            {
                return $.$spxl.System.Xml.Linq.XNamespace.EnsureNamespace($.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_refXmlns, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_refXmlns = $v, $.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), "http://www.w3.org/2000/xmlns/"/*xmlnsPrefixNamespace*/);
            }
            static /*XNamespace */ Get$1(/*string*/ namespaceName)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(namespaceName, "namespaceName");
                return $.$spxl.System.Xml.Linq.XNamespace.Get(namespaceName, 0, namespaceName.length);
            }
            static /*XNamespace? */ op_Implicit(/*string?*/ namespaceName)
            {
                return $.$$.System.String.op_Inequality(namespaceName, null) ? $.$spxl.System.Xml.Linq.XNamespace.Get$1(namespaceName) : null;
            }
            static /*XName */ op_Addition(/*XNamespace*/ ns, /*string*/ localName)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(ns, "ns");
                return ns.GetName$1(localName);
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                return this === obj;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$spxl.System.Xml.Linq.XNamespace.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._hashCode;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$spxl.System.Xml.Linq.XNamespace.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*XNamespace?*/ left, /*XNamespace?*/ right)
            {
                return left === right;
            }
            static /*bool */ op_Inequality(/*XNamespace?*/ left, /*XNamespace?*/ right)
            {
                return left !== right;
            }
            /*XName */ GetName(/*string*/ localName, /*int*/ index, /*int*/ count)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(index >= 0 && index <= localName.length, "Caller should have checked that index was in bounds");
                $.$$.System.Diagnostics.Debug.Assert$2(count >= 0 && ((index + count) | 0) <= localName.length, "Caller should have checked that count was in bounds");
                /*XName?*/ let name;
                if (this._names.TryGetValue(localName, index, count, $.$ref(() => name, ($v) => name = $v, $.$spxl.System.Xml.Linq.XName)))
                {
                    return name;
                }
                return this._names.Add(new $.$spxl.System.Xml.Linq.XName().$ctor$1(this, $.$$.System.String.Substring.call(localName, index, count)));
            }
            static /*XNamespace */ Get(/*string*/ namespaceName, /*int*/ index, /*int*/ count)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(index >= 0 && index <= namespaceName.length, "Caller should have checked that index was in bounds");
                $.$$.System.Diagnostics.Debug.Assert$2(count >= 0 && ((index + count) | 0) <= namespaceName.length, "Caller should have checked that count was in bounds");
                if (count === 0)
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.None;
                }
                if ($.$spxl.System.Xml.Linq.XNamespace.s_namespaces === null)
                {
                    $.$$.System.Threading.Interlocked.CompareExchange$14($.$spxl.System.Xml.Linq.XHashtable$$($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), $.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_namespaces, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_namespaces = $v, $.$spxl.System.Xml.Linq.XHashtable$$($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))), new ($.$spxl.System.Xml.Linq.XHashtable$$($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)))().$ctor$1(new $.$spxl.System.Xml.Linq.XHashtable$$($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)).ExtractKeyDelegate().$ctor($.$spxl.System.Xml.Linq.XNamespace, $.$spxl.System.Xml.Linq.XNamespace.ExtractNamespace), 32/*NamespacesCapacity*/), null);
                }
                /*WeakReference<XNamespace>?*/ let refNamespace;
                /*XNamespace?*/ let ns;
                do
                {
                    if (!$.$spxl.System.Xml.Linq.XNamespace.s_namespaces.TryGetValue(namespaceName, index, count, $.$ref(() => refNamespace, ($v) => refNamespace = $v, $.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))))
                    {
                        if (count === "http://www.w3.org/XML/1998/namespace"/*xmlPrefixNamespace*/.length && $.$$.System.String.CompareOrdinal$1(namespaceName, index, "http://www.w3.org/XML/1998/namespace"/*xmlPrefixNamespace*/, 0, count) === 0)
                        {
                            return $.$spxl.System.Xml.Linq.XNamespace.Xml;
                        }
                        if (count === "http://www.w3.org/2000/xmlns/"/*xmlnsPrefixNamespace*/.length && $.$$.System.String.CompareOrdinal$1(namespaceName, index, "http://www.w3.org/2000/xmlns/"/*xmlnsPrefixNamespace*/, 0, count) === 0)
                        {
                            return $.$spxl.System.Xml.Linq.XNamespace.Xmlns;
                        }
                        refNamespace = $.$spxl.System.Xml.Linq.XNamespace.s_namespaces.Add(new ($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))().$ctor$3(new $.$spxl.System.Xml.Linq.XNamespace().$ctor$1($.$$.System.String.Substring.call(namespaceName, index, count))));
                    }
                    /*XNamespace?*/ let target;
                    ns = refNamespace !== null && refNamespace.TryGetTarget($.$ref(() => target, ($v) => target = $v, $.$spxl.System.Xml.Linq.XNamespace)) ? target : null;
                }
                while($.$spxl.System.Xml.Linq.XNamespace.op_Equality(ns, null));
                return ns;
            }
            static /*string */ ExtractLocalName(/*XName*/ n)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$spxl.System.Xml.Linq.XName.op_Inequality(n, null), "Null name should never exist here");
                return n.LocalName;
            }
            static /*string? */ ExtractNamespace(/*WeakReference<XNamespace>?*/ r)
            {
                /*XNamespace?*/ let target;
                return !(r === null) && r.TryGetTarget($.$ref(() => target, ($v) => target = $v, $.$spxl.System.Xml.Linq.XNamespace)) ? target.NamespaceName : null;
            }
            static /*XNamespace */ EnsureNamespace(/*ref WeakReference<XNamespace>?*/ refNmsp, /*string*/ namespaceName)
            {
                /*WeakReference<XNamespace>?*/ let refOld;
                while(true)
                {
                    refOld = refNmsp.$v;
                    /*XNamespace?*/ let ns;
                    if (refOld !== null && refOld.TryGetTarget($.$ref(() => ns, ($v) => ns = $v, $.$spxl.System.Xml.Linq.XNamespace)))
                    {
                        return ns;
                    }
                    $.$$.System.Threading.Interlocked.CompareExchange$14($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace), refNmsp, new ($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))().$ctor$3(new $.$spxl.System.Xml.Linq.XNamespace().$ctor$1(namespaceName)), refOld);
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.xmlPrefixNamespace = "http://www.w3.org/XML/1998/namespace";
                }
                {
                    this.xmlnsPrefixNamespace = "http://www.w3.org/2000/xmlns/";
                }
            }
            static $h = 2222032;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":60131764176,"f":50331649},"n":"NamespaceName","d":2222032,"h":55836796880,"f":2097153},{"p":2222032,"g":{"r":0,"d":0,"h":77311633360,"f":50331681},"n":"None","d":2222032,"h":73016666064,"f":2097185},{"p":2222032,"g":{"r":0,"d":0,"h":85901567952,"f":50331681},"n":"Xml","d":2222032,"h":81606600656,"f":2097185},{"p":2222032,"g":{"r":0,"d":0,"h":94491502544,"f":50331681},"n":"Xmlns","d":2222032,"h":90196535248,"f":2097185}],"m":[{"r":2156496,"p":[{"n":"localName","p":1310721}],"n":"GetName","o":"@$1","d":2222032,"h":64426731472,"f":16777217},{"r":1310721,"n":"ToString","d":2222032,"h":68721698768,"f":16809985},{"r":2222032,"p":[{"n":"namespaceName","p":1310721}],"n":"Get","o":"@$1","d":2222032,"h":98786469840,"f":16777249},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":2222032,"h":111671371728,"f":16809985},{"r":655361,"n":"GetHashCode","d":2222032,"h":115966339024,"f":16809985},{"r":2156496,"p":[{"n":"localName","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetName","d":2222032,"h":128851240912,"f":16777224},{"r":2222032,"p":[{"n":"namespaceName","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"Get","d":2222032,"h":133146208208,"f":16777256},{"r":1310721,"p":[{"n":"n","p":2156496}],"n":"ExtractLocalName","d":2222032,"h":137441175504,"f":16777250},{"r":1310721,"p":[{"n":"r","p":$.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h}],"n":"ExtractNamespace","d":2222032,"h":141736142800,"f":16777250},{"r":2222032,"p":[{"n":"refNmsp","p":$.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,"f":4},{"n":"namespaceName","p":1310721}],"n":"EnsureNamespace","d":2222032,"h":146031110096,"f":16777250}],"l":[{"t":1310721,"n":"xmlPrefixNamespace","d":2222032,"h":4297189328,"f":4194344},{"t":1310721,"n":"xmlnsPrefixNamespace","d":2222032,"h":8592156624,"f":4194344},{"t":$.$spxl.System.Xml.Linq.XHashtable$$($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)).$h,"n":"s_namespaces","d":2222032,"h":12887123920,"f":4194338},{"t":$.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,"n":"s_refNone","d":2222032,"h":17182091216,"f":4194338},{"t":$.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,"n":"s_refXml","d":2222032,"h":21477058512,"f":4194338},{"t":$.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,"n":"s_refXmlns","d":2222032,"h":25772025808,"f":4194338},{"t":1310721,"n":"_namespaceName","d":2222032,"h":30066993104,"f":4194306},{"t":655361,"n":"_hashCode","d":2222032,"h":34361960400,"f":4194306},{"t":$.$spxl.System.Xml.Linq.XHashtable$$($.$spxl.System.Xml.Linq.XName).$h,"n":"_names","d":2222032,"h":38656927696,"f":4194306},{"t":655361,"n":"NamesCapacity","d":2222032,"h":42951894992,"f":4194338},{"t":655361,"n":"NamespacesCapacity","d":2222032,"h":47246862288,"f":4194338}],"c":[{"p":[{"n":"namespaceName","p":1310721}],"n":".ctor","o":"$ctor$1","d":2222032,"h":51541829584,"f":16777224}],"h":2222032}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XNamespace`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Schema.XNodeValidator", ($self) => class XNodeValidator extends $.$$.System.Object
        {
            /*XmlSchemaSet*/ schemas = null;
            /*ValidationEventHandler?*/ validationEventHandler = null;
            /*XObject?*/ source = null;
            /*bool*/ addSchemaInfo = false;
            /*XmlNamespaceManager?*/ namespaceManager = null;
            /*XmlSchemaValidator?*/ validator = null;
            /*HashSet<XmlSchemaInfo>?*/ schemaInfos = null;
            /*ArrayList?*/ defaultAttributes = null;
            /*XName*/ xsiTypeName = null;
            /*XName*/ xsiNilName = null;
            $ctor$1(/*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                super.$ctor();
                {
                    this.schemas = schemas;
                    this.validationEventHandler = validationEventHandler;
                    /*XNamespace*/ let xsi = $.$spxl.System.Xml.Linq.XNamespace.Get$1("http://www.w3.org/2001/XMLSchema-instance");
                    this.xsiTypeName = xsi.GetName$1("type");
                    this.xsiNilName = xsi.GetName$1("nil");
                }
                return this;
            }
            /*void */ Validate(/*XObject*/ source, /*XmlSchemaObject?*/ partialValidationType, /*bool*/ addSchemaInfo)
            {
                this.source = source;
                this.addSchemaInfo = addSchemaInfo;
                /*XmlSchemaValidationFlags*/ let validationFlags = 16/*XmlSchemaValidationFlags.AllowXmlAttributes*/;
                /*XmlNodeType*/ let nt = source.NodeType;
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    switch($switchJumpState1 ?? nt)
                    {
                        case 9/*XmlNodeType.Document*/:
                        source = ($.$cast(source, $.$spxl.System.Xml.Linq.XDocument)).Root;
                        if (source === null)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingRoot);
                        }
                        validationFlags |= 8/*XmlSchemaValidationFlags.ProcessIdentityConstraints*/;
                        break;
                        case 1/*XmlNodeType.Element*/:
                        break;
                        case 2/*XmlNodeType.Attribute*/:
                        if (($.$cast(source, $.$spxl.System.Xml.Linq.XAttribute)).IsNamespaceDeclaration)
                        {
                            $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                            continue $switchJumpStart1;
                        }
                        if (source.Parent === null)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingParent);
                        }
                        break;
                        default:
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_BadNodeType, $.$box(nt, $.$spx.System.Xml.XmlNodeType)));
                    }
                    break;
                }
                this.namespaceManager = new $.$spx.System.Xml.XmlNamespaceManager().$ctor$2(this.schemas.NameTable);
                this.PushAncestorsAndSelf(source.Parent);
                this.validator = new $.$spx.System.Xml.Schema.XmlSchemaValidator().$ctor$1(this.schemas.NameTable, this.schemas, this.namespaceManager, validationFlags);
                this.validator.add_ValidationEventHandler(new $.$spx.System.Xml.Schema.ValidationEventHandler().$ctor(this, this.ValidationCallback));
                this.validator.XmlResolver = null;
                if (partialValidationType !== null)
                {
                    this.validator.Initialize$1(partialValidationType);
                }
                else 
                {
                    this.validator.Initialize();
                }
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(source);
                if (nt === 2/*XmlNodeType.Attribute*/)
                {
                    this.ValidateAttribute($.$cast(source, $.$spxl.System.Xml.Linq.XAttribute));
                }
                else 
                {
                    this.ValidateElement($.$cast(source, $.$spxl.System.Xml.Linq.XElement));
                }
                this.validator.EndValidation();
                this.RestoreLineInfo(original);
            }
            /*XmlSchemaInfo */ GetDefaultAttributeSchemaInfo(/*XmlSchemaAttribute*/ sa)
            {
                /*XmlSchemaInfo*/ let si = new $.$spx.System.Xml.Schema.XmlSchemaInfo().$ctor$1();
                si.IsDefault = true;
                si.IsNil = false;
                si.SchemaAttribute = sa;
                $.$$.System.Diagnostics.Debug.Assert$2(sa.AttributeSchemaType !== null, "sa.AttributeSchemaType != null");
                /*XmlSchemaSimpleType*/ let st = sa.AttributeSchemaType;
                si.SchemaType = st;
                $.$$.System.Diagnostics.Debug.Assert$2(st.Datatype !== null, "st.Datatype != null");
                if (st.Datatype.Variety === 2/*XmlSchemaDatatypeVariety.Union*/)
                {
                    /*string?*/ let value = this.GetDefaultValue(sa);
                    $.$$.System.Diagnostics.Debug.Assert$2(st.Content !== null, "st.Content != null");
                    let $i1 = 0;
                    let $arr1 = ($.$cast(st.Content, $.$spx.System.Xml.Schema.XmlSchemaSimpleTypeUnion)).BaseMemberTypes;
                    while ($i1 < $arr1.length)
                    {
                        let mt = $arr1[$i1++];
                        /*object?*/ let typedValue = null;
                        try
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(mt.Datatype !== null, "mt.Datatype != null");
                            $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Inequality(value, null), "value != null");
                            typedValue = mt.Datatype.ParseValue$1(value, this.schemas.NameTable, this.namespaceManager);
                        }
                        catch($e)
                        {
                        }
                        if (typedValue !== null)
                        {
                            si.MemberType = mt;
                            break;
                        }
                    }
                }
                si.Validity = 1/*XmlSchemaValidity.Valid*/;
                return si;
            }
            /*string? */ GetDefaultValue(/*XmlSchemaAttribute*/ sa)
            {
                /*XmlSchemaAttribute?*/ let saCopy = sa;
                /*XmlQualifiedName*/ let name = saCopy.RefName;
                if (!name.IsEmpty)
                {
                    saCopy = $.$as(this.schemas.GlobalAttributes.get_Item(name), $.$spx.System.Xml.Schema.XmlSchemaAttribute);
                    if (saCopy === null)
                    {
                        return null;
                    }
                }
                /*string?*/ let s = saCopy.FixedValue;
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    return s;
                }
                return saCopy.DefaultValue;
            }
            /*string? */ GetDefaultValue$1(/*XmlSchemaElement*/ se)
            {
                /*XmlSchemaElement?*/ let seCopy = se;
                /*XmlQualifiedName*/ let name = seCopy.RefName;
                if (!name.IsEmpty)
                {
                    seCopy = $.$as(this.schemas.GlobalElements.get_Item(name), $.$spx.System.Xml.Schema.XmlSchemaElement);
                    if (seCopy === null)
                    {
                        return null;
                    }
                }
                /*string?*/ let s = seCopy.FixedValue;
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    return s;
                }
                return seCopy.DefaultValue;
            }
            /*void */ ReplaceSchemaInfo(/*XObject*/ o, /*XmlSchemaInfo*/ schemaInfo)
            {
                this.schemaInfos ??= new ($.$$.System.Collections.Generic.HashSet$$($.$spx.System.Xml.Schema.XmlSchemaInfo))().$ctor$4(new $.$spxl.System.Xml.Schema.XmlSchemaInfoEqualityComparer().$ctor$1());
                /*XmlSchemaInfo?*/ let si = o.Annotation$1($.$spx.System.Xml.Schema.XmlSchemaInfo);
                if (si !== null)
                {
                    this.schemaInfos.Add(si);
                    o.RemoveAnnotations$1($.$spx.System.Xml.Schema.XmlSchemaInfo);
                }
                if (!this.schemaInfos.TryGetValue(schemaInfo, $.$ref(() => si, ($v) => si = $v, $.$spx.System.Xml.Schema.XmlSchemaInfo)))
                {
                    si = schemaInfo;
                    this.schemaInfos.Add(si);
                }
                o.AddAnnotation(si);
            }
            /*void */ PushAncestorsAndSelf(/*XElement?*/ e)
            {
                while(e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration)
                            {
                                /*string*/ let localName = a.Name.LocalName;
                                if ($.$$.System.String.op_Equality(localName, "xmlns"))
                                {
                                    localName = $.$$.System.String.Empty;
                                }
                                if (!this.namespaceManager.HasNamespace(localName))
                                {
                                    this.namespaceManager.AddNamespace(localName, a.Value);
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                }
            }
            /*void */ PushElement(/*XElement*/ e, /*ref string?*/ xsiType, /*ref string?*/ xsiNil)
            {
                this.namespaceManager.PushScope();
                /*XAttribute?*/ let a = e.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if (a.IsNamespaceDeclaration)
                        {
                            /*string*/ let localName = a.Name.LocalName;
                            if ($.$$.System.String.op_Equality(localName, "xmlns"))
                            {
                                localName = $.$$.System.String.Empty;
                            }
                            this.namespaceManager.AddNamespace(localName, a.Value);
                        }
                        else 
                        {
                            /*XName*/ let name = a.Name;
                            if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, this.xsiTypeName))
                            {
                                xsiType.$v = a.Value;
                            }
                            else if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, this.xsiNilName))
                            {
                                xsiNil.$v = a.Value;
                            }
                        }
                    }
                    while(a !== e.lastAttr);
                }
            }
            /*IXmlLineInfo */ SaveLineInfo(/*XObject?*/ source)
            {
                /*IXmlLineInfo*/ let previousLineInfo = this.validator.LineInfoProvider;
                this.validator.LineInfoProvider = $.$as(source, $.$spx.System.Xml.IXmlLineInfo);
                return previousLineInfo;
            }
            /*void */ RestoreLineInfo(/*IXmlLineInfo*/ originalLineInfo)
            {
                this.validator.LineInfoProvider = originalLineInfo;
            }
            /*void */ ValidateAttribute(/*XAttribute*/ a)
            {
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(a);
                /*XmlSchemaInfo?*/ let si = this.addSchemaInfo ? new $.$spx.System.Xml.Schema.XmlSchemaInfo().$ctor$1() : null;
                this.source = a;
                this.validator.ValidateAttribute(a.Name.LocalName, a.Name.NamespaceName, a.Value, si);
                if (this.addSchemaInfo)
                {
                    this.ReplaceSchemaInfo(a, si);
                }
                this.RestoreLineInfo(original);
            }
            /*void */ ValidateAttributes(/*XElement*/ e)
            {
                /*XAttribute?*/ let a = e.lastAttr;
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(a);
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if (!a.IsNamespaceDeclaration)
                        {
                            this.ValidateAttribute(a);
                        }
                    }
                    while(a !== e.lastAttr);
                    this.source = e;
                }
                if (this.addSchemaInfo)
                {
                    if (this.defaultAttributes === null)
                    {
                        this.defaultAttributes = new $.$$.System.Collections.ArrayList().$ctor$1();
                    }
                    else 
                    {
                        this.defaultAttributes.Clear();
                    }
                    this.validator.GetUnspecifiedDefaultAttributes$1(this.defaultAttributes);
                    var $en3 = this.defaultAttributes.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var sa = $en3.System$Collections$IEnumerator$Current;
                        {
                            a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3($.$spxl.System.Xml.Linq.XNamespace.Get$1(sa.QualifiedName.Namespace).GetName$1(sa.QualifiedName.Name), this.GetDefaultValue(sa));
                            this.ReplaceSchemaInfo(a, this.GetDefaultAttributeSchemaInfo(sa));
                            e.Add(a);
                        }
                    }
                }
                this.RestoreLineInfo(original);
            }
            /*void */ ValidateElement(/*XElement*/ e)
            {
                /*XmlSchemaInfo?*/ let si = this.addSchemaInfo ? new $.$spx.System.Xml.Schema.XmlSchemaInfo().$ctor$1() : null;
                /*string?*/ let xsiType = null;
                /*string?*/ let xsiNil = null;
                this.PushElement(e, $.$ref(() => xsiType, ($v) => xsiType = $v, $.$$.System.String), $.$ref(() => xsiNil, ($v) => xsiNil = $v, $.$$.System.String));
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(e);
                this.source = e;
                this.validator.ValidateElement(e.Name.LocalName, e.Name.NamespaceName, si, xsiType, xsiNil, null, null);
                this.ValidateAttributes(e);
                this.validator.ValidateEndOfAttributes(si);
                this.ValidateNodes(e);
                this.validator.ValidateEndElement$1(si);
                if (this.addSchemaInfo)
                {
                    if (si.Validity === 1/*XmlSchemaValidity.Valid*/ && si.IsDefault)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(si.SchemaElement !== null, "si.SchemaElement != null");
                        e.Value = this.GetDefaultValue$1(si.SchemaElement);
                    }
                    this.ReplaceSchemaInfo(e, si);
                }
                this.RestoreLineInfo(original);
                this.namespaceManager.PopScope();
            }
            /*void */ ValidateNodes(/*XElement*/ e)
            {
                /*XNode?*/ let n = $.$as(e.content, $.$spxl.System.Xml.Linq.XNode);
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(n);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*XElement?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (c !== null)
                        {
                            this.ValidateElement(c);
                        }
                        else 
                        {
                            /*XText?*/ let t = $.$as(n, $.$spxl.System.Xml.Linq.XText);
                            if (t !== null)
                            {
                                /*string*/ let s = t.Value;
                                if (s.length > 0)
                                {
                                    this.validator.LineInfoProvider = $.$as(t, $.$spx.System.Xml.IXmlLineInfo);
                                    this.validator.ValidateText$1(s);
                                }
                            }
                        }
                    }
                    while(n !== e.content);
                    this.source = e;
                }
                else 
                {
                    /*string?*/ let s = $.$as(e.content, $.$$.System.String);
                    if ($.$$.System.String.op_Inequality(s, null) && s.length > 0)
                    {
                        this.validator.ValidateText$1(s);
                    }
                }
                this.RestoreLineInfo(original);
            }
            /*void */ ValidationCallback(/*object?*/ sender, /*ValidationEventArgs*/ e)
            {
                if (this.validationEventHandler !== null)
                {
                    this.validationEventHandler.Invoke(this.source, e);
                }
                else if (e.Severity === 0/*XmlSeverityType.Error*/)
                {
                    throw e.Exception;
                }
            }
            static $h = 3205072;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"source","p":2615248},{"n":"partialValidationType","p":30915222},{"n":"addSchemaInfo","p":262145}],"n":"Validate","d":3205072,"h":51542812624,"f":16777217},{"r":30128790,"p":[{"n":"sa","p":27769494}],"n":"GetDefaultAttributeSchemaInfo","d":3205072,"h":55837779920,"f":16777218},{"r":1310721,"p":[{"n":"sa","p":27769494}],"n":"GetDefaultValue","d":3205072,"h":60132747216,"f":16777218},{"r":1310721,"p":[{"n":"se","p":29080214}],"n":"GetDefaultValue","o":"@$1","d":3205072,"h":64427714512,"f":16777218},{"r":65537,"p":[{"n":"o","p":2615248},{"n":"schemaInfo","p":30128790}],"n":"ReplaceSchemaInfo","d":3205072,"h":68722681808,"f":16777218},{"r":65537,"p":[{"n":"e","p":1697744}],"n":"PushAncestorsAndSelf","d":3205072,"h":73017649104,"f":16777218},{"r":65537,"p":[{"n":"e","p":1697744},{"n":"xsiType","p":1310721,"f":4},{"n":"xsiNil","p":1310721,"f":4}],"n":"PushElement","d":3205072,"h":77312616400,"f":16777218},{"r":13941398,"p":[{"n":"source","p":2615248}],"n":"SaveLineInfo","d":3205072,"h":81607583696,"f":16777218},{"r":65537,"p":[{"n":"originalLineInfo","p":13941398}],"n":"RestoreLineInfo","d":3205072,"h":85902550992,"f":16777218},{"r":65537,"p":[{"n":"a","p":1173456}],"n":"ValidateAttribute","d":3205072,"h":90197518288,"f":16777218},{"r":65537,"p":[{"n":"e","p":1697744}],"n":"ValidateAttributes","d":3205072,"h":94492485584,"f":16777218},{"r":65537,"p":[{"n":"e","p":1697744}],"n":"ValidateElement","d":3205072,"h":98787452880,"f":16777218},{"r":65537,"p":[{"n":"e","p":1697744}],"n":"ValidateNodes","d":3205072,"h":103082420176,"f":16777218},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":25475734}],"n":"ValidationCallback","d":3205072,"h":107377387472,"f":16777218}],"l":[{"t":31963798,"n":"schemas","d":3205072,"h":4298172368,"f":4194306},{"t":25541270,"n":"validationEventHandler","d":3205072,"h":8593139664,"f":4194306},{"t":2615248,"n":"source","d":3205072,"h":12888106960,"f":4194306},{"t":262145,"n":"addSchemaInfo","d":3205072,"h":17183074256,"f":4194306},{"t":51886742,"n":"namespaceManager","d":3205072,"h":21478041552,"f":4194306},{"t":33077910,"n":"validator","d":3205072,"h":25773008848,"f":4194306},{"t":$.$$.System.Collections.Generic.HashSet$$($.$spx.System.Xml.Schema.XmlSchemaInfo).$h,"n":"schemaInfos","d":3205072,"h":30067976144,"f":4194306},{"t":23724033,"n":"defaultAttributes","d":3205072,"h":34362943440,"f":4194306},{"t":2156496,"n":"xsiTypeName","d":3205072,"h":38657910736,"f":4194306},{"t":2156496,"n":"xsiNilName","d":3205072,"h":42952878032,"f":4194306}],"c":[{"p":[{"n":"schemas","p":31963798},{"n":"validationEventHandler","p":25541270}],"n":".ctor","o":"$ctor$1","d":3205072,"h":47247845328,"f":16777217}],"h":3205072}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Schema.XNodeValidator`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.Extensions", ($self) => class Extensions
        {
            static /*IEnumerable<XAttribute> */ Attributes$1(/*this IEnumerable<XElement?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetAttributes(source, null);
            }
            static /*IEnumerable<XAttribute> */ Attributes(/*this IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetAttributes(source, name) : $.$spxl.System.Xml.Linq.XAttribute.EmptySequence;
            }
            static /*IEnumerable<XElement> */ Ancestors$1(T, /*this IEnumerable<T?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetAncestors(T, source, null, false);
            }
            static /*IEnumerable<XElement> */ Ancestors(T, /*this IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetAncestors(T, source, name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<XElement> */ AncestorsAndSelf$1(/*this IEnumerable<XElement?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetAncestors($.$spxl.System.Xml.Linq.XElement, source, null, true);
            }
            static /*IEnumerable<XElement> */ AncestorsAndSelf(/*this IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetAncestors($.$spxl.System.Xml.Linq.XElement, source, name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<XNode> */ Nodes(T, /*this IEnumerable<T?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.NodesIterator(T, source);
            }
            static /*IEnumerable<XNode> */ NodesIterator(T, /*IEnumerable<T?>*/ source)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                /*XNode?*/ let n = root.LastNode;
                                if (n !== null)
                                {
                                    do
                                    {
                                        n = n.next;
                                        yield n;
                                    }
                                    while(n.parent === root && n !== root.content);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XNode> */ DescendantNodes(T, /*this IEnumerable<T?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendantNodes(T, source, false);
            }
            static /*IEnumerable<XElement> */ Descendants$1(T, /*this IEnumerable<T?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendants(T, source, null, false);
            }
            static /*IEnumerable<XElement> */ Descendants(T, /*this IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetDescendants(T, source, name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<XNode> */ DescendantNodesAndSelf(/*this IEnumerable<XElement?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendantNodes($.$spxl.System.Xml.Linq.XElement, source, true);
            }
            static /*IEnumerable<XElement> */ DescendantsAndSelf$1(/*this IEnumerable<XElement?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendants($.$spxl.System.Xml.Linq.XElement, source, null, true);
            }
            static /*IEnumerable<XElement> */ DescendantsAndSelf(/*this IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetDescendants($.$spxl.System.Xml.Linq.XElement, source, name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<XElement> */ Elements$1(T, /*this IEnumerable<T?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetElements(T, source, null);
            }
            static /*IEnumerable<XElement> */ Elements(T, /*this IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetElements(T, source, name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<T> */ InDocumentOrder(T, /*this IEnumerable<T>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.DocumentOrderIterator(T, source);
            }
            static /*IEnumerable<T> */ DocumentOrderIterator(T, /*IEnumerable<T>*/ source)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*int*/ let count;
                    /*T[]*/ let items = $.$spxl.System.Collections.Generic.EnumerableHelpers.ToArray(T, source, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                    if (count > 0)
                    {
                        $.$$.System.Array.Sort$10($.$spxl.System.Xml.Linq.XNode, items, 0, count, $.$spxl.System.Xml.Linq.XNode.DocumentOrderComparer);
                        for(/*int*/ let i = 0; i !== count; ++i)
                        {
                            yield $.$$.System.Array.$ReadT1.call(items, i);
                        }
                    }
                }.bind(this));
            }
            static /*void */ Remove(/*this IEnumerable<XAttribute?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                /*int*/ let count;
                /*XAttribute?[]*/ let attributes = $.$spxl.System.Collections.Generic.EnumerableHelpers.ToArray($.$spxl.System.Xml.Linq.XAttribute, source, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                for(/*int*/ let i = 0; i < count; i++)
                {
                    $.$$.System.Array.$ReadT1.call(attributes, i)?.Remove();
                }
            }
            static /*void */ Remove$1(T, /*this IEnumerable<T?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                /*int*/ let count;
                /*T?[]*/ let nodes = $.$spxl.System.Collections.Generic.EnumerableHelpers.ToArray(T, source, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                for(/*int*/ let i = 0; i < count; i++)
                {
                    $.$dsp($.$$.System.Array.$ReadT1.call(nodes, i), T, ($t) => $t.Remove,);
                }
            }
            static /*IEnumerable<XAttribute> */ GetAttributes(/*IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var e = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (e !== null)
                            {
                                /*XAttribute?*/ let a = e.lastAttr;
                                if (a !== null)
                                {
                                    do
                                    {
                                        a = a.next;
                                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(a.name, name))
                                        {
                                            yield a;
                                        }
                                    }
                                    while(a.parent === e && a !== e.lastAttr);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XElement> */ GetAncestors(T, /*IEnumerable<T?>*/ source, /*XName?*/ name, /*bool*/ self)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (node !== null)
                            {
                                /*XElement?*/ let e = $.$as((self ? node : node.parent), $.$spxl.System.Xml.Linq.XElement);
                                while(e !== null)
                                {
                                    if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                                    {
                                        yield e;
                                    }
                                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XNode> */ GetDescendantNodes(T, /*IEnumerable<T?>*/ source, /*bool*/ self)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                if (self)
                                {
                                    yield root;
                                }
                                /*XNode?*/ let n = root;
                                while(true)
                                {
                                    /*XContainer?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XContainer);
                                    /*XNode?*/ let first;
                                    if (c !== null && (first = c.FirstNode) !== null)
                                    {
                                        n = first;
                                    }
                                    else 
                                    {
                                        while(n !== null && n !== root && n === n.parent.content)
                                        {
                                            n = n.parent;
                                        }
                                        if (n === null || n === root)
                                        {
                                            break;
                                        }
                                        n = n.next;
                                    }
                                    yield n;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XElement> */ GetDescendants(T, /*IEnumerable<T?>*/ source, /*XName?*/ name, /*bool*/ self)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                if (self)
                                {
                                    /*XElement*/ let e = $.$cast(root, $.$spxl.System.Xml.Linq.XElement);
                                    if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                                    {
                                        yield e;
                                    }
                                }
                                /*XNode?*/ let n = root;
                                /*XContainer?*/ let c = root;
                                while(true)
                                {
                                    if (c !== null && $.$is(c.content, $.$spxl.System.Xml.Linq.XNode))
                                    {
                                        n = ($.$cast(c.content, $.$spxl.System.Xml.Linq.XNode)).next;
                                    }
                                    else 
                                    {
                                        while(n !== null && n !== root && n === n.parent.content)
                                        {
                                            n = n.parent;
                                        }
                                        if (n === null || n === root)
                                        {
                                            break;
                                        }
                                        n = n.next;
                                    }
                                    /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                                    if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                                    {
                                        yield e;
                                    }
                                    c = e;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XElement> */ GetElements(T, /*IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                /*XNode?*/ let n = $.$as(root.content, $.$spxl.System.Xml.Linq.XNode);
                                if (n !== null)
                                {
                                    do
                                    {
                                        n = n.next;
                                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                                        if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                                        {
                                            yield e;
                                        }
                                    }
                                    while(n.parent === root && n !== root.content);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static $h = 452560;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"source","p":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h}],"n":"Attributes","o":"@$1","d":452560,"h":4295419856,"f":16777249},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"source","p":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h},{"n":"name","p":2156496}],"n":"Attributes","d":452560,"h":8590387152,"f":16777249},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Ancestors","o":"@$1","d":452560,"h":12885354448,"f":16908321},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2156496}],"g":["T"],"n":"Ancestors","d":452560,"h":17180321744,"f":16908321},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h}],"n":"AncestorsAndSelf","o":"@$1","d":452560,"h":21475289040,"f":16777249},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h},{"n":"name","p":2156496}],"n":"AncestorsAndSelf","d":452560,"h":25770256336,"f":16777249},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Nodes","d":452560,"h":30065223632,"f":16908321},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"NodesIterator","d":452560,"h":34360190928,"f":16908322},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"DescendantNodes","d":452560,"h":38655158224,"f":16908321},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Descendants","o":"@$1","d":452560,"h":42950125520,"f":16908321},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2156496}],"g":["T"],"n":"Descendants","d":452560,"h":47245092816,"f":16908321},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h}],"n":"DescendantNodesAndSelf","d":452560,"h":51540060112,"f":16777249},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h}],"n":"DescendantsAndSelf","o":"@$1","d":452560,"h":55835027408,"f":16777249},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h},{"n":"name","p":2156496}],"n":"DescendantsAndSelf","d":452560,"h":60129994704,"f":16777249},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Elements","o":"@$1","d":452560,"h":64424962000,"f":16908321},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2156496}],"g":["T"],"n":"Elements","d":452560,"h":68719929296,"f":16908321},{"r":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"InDocumentOrder","d":452560,"h":73014896592,"f":16908321},{"r":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"DocumentOrderIterator","d":452560,"h":77309863888,"f":16908322},{"r":65537,"p":[{"n":"source","p":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h}],"n":"Remove","d":452560,"h":81604831184,"f":16777249},{"r":65537,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Remove","o":"@$1","d":452560,"h":85899798480,"f":16908321},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"source","p":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h},{"n":"name","p":2156496}],"n":"GetAttributes","d":452560,"h":90194765776,"f":16777250},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2156496},{"n":"self","p":262145}],"g":["T"],"n":"GetAncestors","d":452560,"h":94489733072,"f":16908322},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"self","p":262145}],"g":["T"],"n":"GetDescendantNodes","d":452560,"h":98784700368,"f":16908322},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2156496},{"n":"self","p":262145}],"g":["T"],"n":"GetDescendants","d":452560,"h":103079667664,"f":16908322},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2156496}],"g":["T"],"n":"GetElements","d":452560,"h":107374634960,"f":16908322}],"h":452560}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.Extensions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XStreamingElement", ($self) => class XStreamingElement extends $.$$.System.Object
        {
            /*XName*/ name = null;
            /*object?*/ content = null;
            $ctor$3(/*XName*/ name)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                    this.name = name;
                }
                return this;
            }
            $ctor$1(/*XName*/ name, /*object?*/ content)
            {
                this.$ctor$3(name);
                {
                    this.content = $.$is(content, $.$$.System.Collections.Generic.List$$($.$$.System.Object)) ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [content], [-1], null) : content;
                }
                return this;
            }
            $ctor$2(/*XName*/ name, /*params object?[]*/ content)
            {
                this.$ctor$3(name);
                {
                    this.content = content;
                }
                return this;
            }
            /*XName */ get Name()
            {
                return this.name;
            }
            /*XName */ set Name(value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.name = value;
            }
            /*void */ Add(/*object?*/ content)
            {
                if (content !== null)
                {
                    /*List<object>?*/ let list = $.$as(this.content, $.$$.System.Collections.Generic.List$$($.$$.System.Object));
                    if (list === null)
                    {
                        list = new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                        if (this.content !== null)
                        {
                            list.Add(this.content);
                        }
                        this.content = list;
                    }
                    list.Add(content);
                }
            }
            /*void */ Add$1(/*params object?[]*/ content)
            {
                this.Add($.$cast(content, $.$$.System.Object));
            }
            /*void */ Save$1(/*Stream*/ stream)
            {
                this.Save(stream, 0/*SaveOptions.None*/);
            }
            /*void */ Save(/*Stream*/ stream, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create(stream, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*void */ Save$3(/*TextWriter*/ textWriter)
            {
                this.Save$2(textWriter, 0/*SaveOptions.None*/);
            }
            /*void */ Save$2(/*TextWriter*/ textWriter, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$2(textWriter, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*void */ Save$6(/*XmlWriter*/ writer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                writer.WriteStartDocument();
                this.WriteTo(writer);
                writer.WriteEndDocument();
            }
            /*void */ Save$5(/*string*/ fileName)
            {
                this.Save$4(fileName, 0/*SaveOptions.None*/);
            }
            /*void */ Save$4(/*string*/ fileName, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$4(fileName, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.GetXmlString(0/*SaveOptions.None*/);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XStreamingElement.ToString.apply(this, arguments); }
            /*string */ ToString$1(/*SaveOptions*/ options)
            {
                return this.GetXmlString(options);
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                new $.$spxl.System.Xml.Linq.StreamingElementWriter().$ctor$3(writer).WriteStreamingElement(this);
            }
            /*string */ GetXmlString(/*SaveOptions*/ o)
            {
                let sw = null;
                try
                {
                    sw = new $.$$.System.IO.StringWriter().$ctor$5($.$$.System.Globalization.CultureInfo.InvariantCulture);
                    /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                    ws.OmitXmlDeclaration = true;
                    if ((o & 1/*SaveOptions.DisableFormatting*/) === 0)
                    {
                        ws.Indent = true;
                    }
                    if ((o & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0)
                    {
                        ws.NamespaceHandling |= 1/*NamespaceHandling.OmitDuplicates*/;
                    }
                    let w = null;
                    try
                    {
                        w = $.$spx.System.Xml.XmlWriter.Create$2(sw, ws);
                        this.WriteTo(w);
                    }
                    finally
                    {
                        w?.System$IDisposable$Dispose();
                    }
                    return $.$$.System.IO.StringWriter.ToString.call(sw);
                }
                finally
                {
                    sw?.System$IDisposable$Dispose();
                }
            }
            static $h = 2942928;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2156496,"g":{"r":0,"d":0,"h":30067714000,"f":50331649},"s":{"r":0,"d":0,"h":34362681296,"f":83886081},"n":"Name","d":2942928,"h":25772746704,"f":2097153}],"m":[{"r":65537,"p":[{"n":"content","p":131073}],"n":"Add","d":2942928,"h":38657648592,"f":16777217},{"r":65537,"p":[{"n":"content","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"Add","o":"@$1","d":2942928,"h":42952615888,"f":16777217},{"r":65537,"p":[{"n":"stream","p":62193665}],"n":"Save","o":"@$1","d":2942928,"h":47247583184,"f":16777217},{"r":65537,"p":[{"n":"stream","p":62193665},{"n":"options","p":1042384}],"n":"Save","d":2942928,"h":51542550480,"f":16777217},{"r":65537,"p":[{"n":"textWriter","p":63045633}],"n":"Save","o":"@$3","d":2942928,"h":55837517776,"f":16777217},{"r":65537,"p":[{"n":"textWriter","p":63045633},{"n":"options","p":1042384}],"n":"Save","o":"@$2","d":2942928,"h":60132485072,"f":16777217},{"r":65537,"p":[{"n":"writer","p":58440342}],"n":"Save","o":"@$6","d":2942928,"h":64427452368,"f":16777217},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"Save","o":"@$5","d":2942928,"h":68722419664,"f":16777217},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"options","p":1042384}],"n":"Save","o":"@$4","d":2942928,"h":73017386960,"f":16777217},{"r":1310721,"n":"ToString","d":2942928,"h":77312354256,"f":16809985},{"r":1310721,"p":[{"n":"options","p":1042384}],"n":"ToString","o":"@$1","d":2942928,"h":81607321552,"f":16777217},{"r":65537,"p":[{"n":"writer","p":58440342}],"n":"WriteTo","d":2942928,"h":85902288848,"f":16777217},{"r":1310721,"p":[{"n":"o","p":1042384}],"n":"GetXmlString","d":2942928,"h":90197256144,"f":16777218}],"l":[{"t":2156496,"n":"name","d":2942928,"h":4297910224,"f":4194312},{"t":131073,"n":"content","d":2942928,"h":8592877520,"f":4194312}],"c":[{"p":[{"n":"name","p":2156496}],"n":".ctor","o":"$ctor$3","d":2942928,"h":12887844816,"f":16777217},{"p":[{"n":"name","p":2156496},{"n":"content","p":131073}],"n":".ctor","o":"$ctor$1","d":2942928,"h":17182812112,"f":16777217},{"p":[{"n":"name","p":2156496},{"n":"content","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":".ctor","o":"$ctor$2","d":2942928,"h":21477779408,"f":16777217}],"h":2942928}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XStreamingElement`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Schema.Extensions", ($self) => class Extensions
        {
            static /*IXmlSchemaInfo? */ GetSchemaInfo$1(/*this XElement*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.Annotation$1($.$spx.System.Xml.Schema.IXmlSchemaInfo);
            }
            static /*IXmlSchemaInfo? */ GetSchemaInfo(/*this XAttribute*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.Annotation$1($.$spx.System.Xml.Schema.IXmlSchemaInfo);
            }
            static /*void */ Validate$3(/*this XDocument*/ source, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                $.$spxl.System.Xml.Schema.Extensions.Validate$2(source, schemas, validationEventHandler, false);
            }
            static /*void */ Validate$2(/*this XDocument*/ source, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler, /*bool*/ addSchemaInfo)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(schemas, "schemas");
                new $.$spxl.System.Xml.Schema.XNodeValidator().$ctor$1(schemas, validationEventHandler).Validate(source, null, addSchemaInfo);
            }
            static /*void */ Validate$5(/*this XElement*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                $.$spxl.System.Xml.Schema.Extensions.Validate$4(source, partialValidationType, schemas, validationEventHandler, false);
            }
            static /*void */ Validate$4(/*this XElement*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler, /*bool*/ addSchemaInfo)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(partialValidationType, "partialValidationType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(schemas, "schemas");
                new $.$spxl.System.Xml.Schema.XNodeValidator().$ctor$1(schemas, validationEventHandler).Validate(source, partialValidationType, addSchemaInfo);
            }
            static /*void */ Validate$1(/*this XAttribute*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                $.$spxl.System.Xml.Schema.Extensions.Validate(source, partialValidationType, schemas, validationEventHandler, false);
            }
            static /*void */ Validate(/*this XAttribute*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler, /*bool*/ addSchemaInfo)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(partialValidationType, "partialValidationType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(schemas, "schemas");
                new $.$spxl.System.Xml.Schema.XNodeValidator().$ctor$1(schemas, validationEventHandler).Validate(source, partialValidationType, addSchemaInfo);
            }
            static $h = 3074000;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":21805718,"p":[{"n":"source","p":1697744}],"n":"GetSchemaInfo","o":"@$1","d":3074000,"h":4298041296,"f":16777249},{"r":21805718,"p":[{"n":"source","p":1173456}],"n":"GetSchemaInfo","d":3074000,"h":8593008592,"f":16777249},{"r":65537,"p":[{"n":"source","p":1566672},{"n":"schemas","p":31963798},{"n":"validationEventHandler","p":25541270}],"n":"Validate","o":"@$3","d":3074000,"h":12887975888,"f":16777249},{"r":65537,"p":[{"n":"source","p":1566672},{"n":"schemas","p":31963798},{"n":"validationEventHandler","p":25541270},{"n":"addSchemaInfo","p":262145}],"n":"Validate","o":"@$2","d":3074000,"h":17182943184,"f":16777249},{"r":65537,"p":[{"n":"source","p":1697744},{"n":"partialValidationType","p":30915222},{"n":"schemas","p":31963798},{"n":"validationEventHandler","p":25541270}],"n":"Validate","o":"@$5","d":3074000,"h":21477910480,"f":16777249},{"r":65537,"p":[{"n":"source","p":1697744},{"n":"partialValidationType","p":30915222},{"n":"schemas","p":31963798},{"n":"validationEventHandler","p":25541270},{"n":"addSchemaInfo","p":262145}],"n":"Validate","o":"@$4","d":3074000,"h":25772877776,"f":16777249},{"r":65537,"p":[{"n":"source","p":1173456},{"n":"partialValidationType","p":30915222},{"n":"schemas","p":31963798},{"n":"validationEventHandler","p":25541270}],"n":"Validate","o":"@$1","d":3074000,"h":30067845072,"f":16777249},{"r":65537,"p":[{"n":"source","p":1173456},{"n":"partialValidationType","p":30915222},{"n":"schemas","p":31963798},{"n":"validationEventHandler","p":25541270},{"n":"addSchemaInfo","p":262145}],"n":"Validate","d":3074000,"h":34362812368,"f":16777249}],"h":3074000}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Schema.Extensions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.XPath.XPathEvaluator", ($self) => class XPathEvaluator
        {
            static /*object */ Evaluate(T, /*XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                /*XPathNavigator*/ let navigator = $.$spxl.System.Xml.XPath.Extensions.CreateNavigator$1(node);
                /*object*/ let result = navigator.Evaluate(expression, resolver);
                /*XPathNodeIterator?*/ let iterator = $.$as(result, $.$spx.System.Xml.XPath.XPathNodeIterator);
                if (iterator !== null)
                {
                    return $.$spxl.System.Xml.XPath.XPathEvaluator.EvaluateIterator(T, iterator);
                }
                if (!($.$is(result, T)))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedEvaluation, $.$$.System.Object.GetType.call(result)));
                }
                return $.$box($.$cast(result, T), T);
            }
            static /*IEnumerable<T> */ EvaluateIterator(T, /*XPathNodeIterator*/ result)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = result.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var navigator = $en3.System$Collections$IEnumerator$Current;
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(navigator.UnderlyingObject !== null, "navigator.UnderlyingObject != null");
                            /*object*/ let r = navigator.UnderlyingObject;
                            if (!($.$is(r, T)))
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedEvaluation, $.$$.System.Object.GetType.call(r)));
                            }
                            yield $.$cast(r, T);
                            /*XText?*/ let t = $.$as(r, $.$spxl.System.Xml.Linq.XText);
                            if (t !== null && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(t) !== null)
                            {
                                do
                                {
                                    t = $.$as(t.NextNode, $.$spxl.System.Xml.Linq.XText);
                                    if (t === null)
                                    {
                                        break;
                                    }
                                    yield $.$cast($.$cast(t, $.$$.System.Object), T);
                                }
                                while(t !== $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(t).LastNode);
                            }
                        }
                    }
                }.bind(this));
            }
            static $h = 3467216;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131073,"p":[{"n":"node","p":2287568},{"n":"expression","p":1310721},{"n":"resolver","p":14006934}],"g":["T"],"n":"Evaluate","d":3467216,"h":4298434512,"f":16908321},{"r":(T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h,"p":[{"n":"result","p":59751062}],"g":["T"],"n":"EvaluateIterator","d":3467216,"h":8593401808,"f":16908322}],"h":3467216}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.XPath.XPathEvaluator`; }
        });
        
        $asm.$cls("$spxl.System.Xml.XPath.Extensions", ($self) => class Extensions
        {
            static /*XPathNavigator */ CreateNavigator$1(/*this XNode*/ node)
            {
                return $.$spxl.System.Xml.XPath.Extensions.CreateNavigator(node, null);
            }
            static /*XPathNavigator */ CreateNavigator(/*this XNode*/ node, /*XmlNameTable?*/ nameTable)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(node, "node");
                if ($.$is(node, $.$spxl.System.Xml.Linq.XDocumentType))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_CreateNavigator, $.$box(10/*XmlNodeType.DocumentType*/, $.$spx.System.Xml.XmlNodeType)));
                }
                /*XText?*/ let text = $.$as(node, $.$spxl.System.Xml.Linq.XText);
                if (text !== null)
                {
                    if ($.$is($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(text), $.$spxl.System.Xml.Linq.XDocument))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_CreateNavigator, $.$box(13/*XmlNodeType.Whitespace*/, $.$spx.System.Xml.XmlNodeType)));
                    }
                    node = $.$spxl.System.Xml.XPath.Extensions.CalibrateText(text);
                }
                return new $.$spxl.System.Xml.XPath.XNodeNavigator().$ctor$3(node, nameTable);
            }
            static /*object */ XPathEvaluate$1(/*this XNode*/ node, /*string*/ expression)
            {
                return $.$spxl.System.Xml.XPath.Extensions.XPathEvaluate(node, expression, null);
            }
            static /*object */ XPathEvaluate(/*this XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(node, "node");
                return $.$spxl.System.Xml.XPath.XPathEvaluator.Evaluate($.$$.System.Object, node, expression, resolver);
            }
            static /*XElement? */ XPathSelectElement$1(/*this XNode*/ node, /*string*/ expression)
            {
                return $.$spxl.System.Xml.XPath.Extensions.XPathSelectElement(node, expression, null);
            }
            static /*XElement? */ XPathSelectElement(/*this XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                return $.$sl.System.Linq.Enumerable.FirstOrDefault$3($.$spxl.System.Xml.Linq.XElement, $.$spxl.System.Xml.XPath.Extensions.XPathSelectElements(node, expression, resolver));
            }
            static /*IEnumerable<XElement> */ XPathSelectElements$1(/*this XNode*/ node, /*string*/ expression)
            {
                return $.$spxl.System.Xml.XPath.Extensions.XPathSelectElements(node, expression, null);
            }
            static /*IEnumerable<XElement> */ XPathSelectElements(/*this XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(node, "node");
                return $.$cast($.$spxl.System.Xml.XPath.XPathEvaluator.Evaluate($.$spxl.System.Xml.Linq.XElement, node, expression, resolver), $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement));
            }
            static /*XText */ CalibrateText(/*XText*/ n)
            {
                /*XContainer?*/ let parentNode = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n);
                if (parentNode === null)
                {
                    return n;
                }
                var $en2 = parentNode.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var node = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*XText?*/ let t = $.$as(node, $.$spxl.System.Xml.Linq.XText);
                        /*bool*/ let isTextNode = t !== null;
                        if (isTextNode && node === n)
                        {
                            return t;
                        }
                    }
                }
                $.$$.System.Diagnostics.Debug.Fail$1("Parent node doesn't contain itself.");
                return null;
            }
            static $h = 3270608;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":59292310,"p":[{"n":"node","p":2287568}],"n":"CreateNavigator","o":"@$1","d":3270608,"h":4298237904,"f":16777249},{"r":59292310,"p":[{"n":"node","p":2287568},{"n":"nameTable","p":52083350}],"n":"CreateNavigator","d":3270608,"h":8593205200,"f":16777249},{"r":131073,"p":[{"n":"node","p":2287568},{"n":"expression","p":1310721}],"n":"XPathEvaluate","o":"@$1","d":3270608,"h":12888172496,"f":16777249},{"r":131073,"p":[{"n":"node","p":2287568},{"n":"expression","p":1310721},{"n":"resolver","p":14006934}],"n":"XPathEvaluate","d":3270608,"h":17183139792,"f":16777249},{"r":1697744,"p":[{"n":"node","p":2287568},{"n":"expression","p":1310721}],"n":"XPathSelectElement","o":"@$1","d":3270608,"h":21478107088,"f":16777249},{"r":1697744,"p":[{"n":"node","p":2287568},{"n":"expression","p":1310721},{"n":"resolver","p":14006934}],"n":"XPathSelectElement","d":3270608,"h":25773074384,"f":16777249},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"node","p":2287568},{"n":"expression","p":1310721}],"n":"XPathSelectElements","o":"@$1","d":3270608,"h":30068041680,"f":16777249},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"node","p":2287568},{"n":"expression","p":1310721},{"n":"resolver","p":14006934}],"n":"XPathSelectElements","d":3270608,"h":34363008976,"f":16777249},{"r":3008464,"p":[{"n":"n","p":3008464}],"n":"CalibrateText","d":3270608,"h":38657976272,"f":16777250}],"h":3270608}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.XPath.Extensions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XName", ($self) => class XName extends $.$$.System.Object
        {
            /*XNamespace*/ _ns = null;
            /*string*/ _localName = null;
            /*int*/ _hashCode = 0;
            $ctor$1(/*XNamespace*/ ns, /*string*/ localName)
            {
                super.$ctor();
                {
                    this._ns = ns;
                    this._localName = $.$spx.System.Xml.XmlConvert.VerifyNCName$1(localName);
                    this._hashCode = $.$spxl.System.Xml.Linq.XNamespace.GetHashCode.call(ns) ^ $.$$.System.String.GetHashCode.call(localName);
                }
                return this;
            }
            /*string */ get LocalName()
            {
                return this._localName;
            }
            /*XNamespace */ get Namespace()
            {
                return this._ns;
            }
            /*string */ get NamespaceName()
            {
                return this._ns.NamespaceName;
            }
            static/*conventional*/ /*string */ ToString()
            {
                if (this._ns.NamespaceName.length === 0)
                {
                    return this._localName;
                }
                return "{" + this._ns.NamespaceName + "}" + this._localName;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XName.ToString.apply(this, arguments); }
            static /*XName */ Get$1(/*string*/ expandedName)
            {
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(expandedName, "expandedName");
                if ($.$$.System.String.get_Chars.call(expandedName, 0) === /*{*/ 123)
                {
                    /*int*/ let i = $.$$.System.String.LastIndexOf$2.call(expandedName, /*}*/ 125);
                    if (i <= 1 || i === ((expandedName.length - 1) | 0))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_InvalidExpandedName, expandedName));
                    }
                    return $.$spxl.System.Xml.Linq.XNamespace.Get(expandedName, 1, ((i - 1) | 0)).GetName(expandedName, ((i + 1) | 0), ((((expandedName.length - i) | 0) - 1) | 0));
                }
                else 
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.None.GetName$1(expandedName);
                }
            }
            static /*XName */ Get(/*string*/ localName, /*string*/ namespaceName)
            {
                return $.$spxl.System.Xml.Linq.XNamespace.Get$1(namespaceName).GetName$1(localName);
            }
            static /*XName? */ op_Implicit(/*string?*/ expandedName)
            {
                return $.$$.System.String.op_Inequality(expandedName, null) ? $.$spxl.System.Xml.Linq.XName.Get$1(expandedName) : null;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                return this === obj;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$spxl.System.Xml.Linq.XName.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._hashCode;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$spxl.System.Xml.Linq.XName.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*XName?*/ left, /*XName?*/ right)
            {
                return left === right;
            }
            static /*bool */ op_Inequality(/*XName?*/ left, /*XName?*/ right)
            {
                return left !== right;
            }
            /*bool */ System$IEquatable$$$Equals(/*XName?*/ other)
            {
                return this === other;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2156496;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25771960272,"f":50331649},"n":"LocalName","d":2156496,"h":21476992976,"f":2097153},{"p":2222032,"g":{"r":0,"d":0,"h":34361894864,"f":50331649},"n":"Namespace","d":2156496,"h":30066927568,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":42951829456,"f":50331649},"n":"NamespaceName","d":2156496,"h":38656862160,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":2156496,"h":47246796752,"f":16809985},{"r":2156496,"p":[{"n":"expandedName","p":1310721}],"n":"Get","o":"@$1","d":2156496,"h":51541764048,"f":16777249},{"r":2156496,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"Get","d":2156496,"h":55836731344,"f":16777249},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":2156496,"h":64426665936,"f":16809985},{"r":655361,"n":"GetHashCode","d":2156496,"h":68721633232,"f":16809985}],"l":[{"t":2222032,"n":"_ns","d":2156496,"h":4297123792,"f":4194306},{"t":1310721,"n":"_localName","d":2156496,"h":8592091088,"f":4194306},{"t":655361,"n":"_hashCode","d":2156496,"h":12887058384,"f":4194306}],"c":[{"p":[{"n":"ns","p":2222032},{"n":"localName","p":1310721}],"n":".ctor","o":"$ctor$1","d":2156496,"h":17182025680,"f":16777224}],"i":[$.$$.System.IEquatable$$($.$spxl.System.Xml.Linq.XName).$h,113246209],"h":2156496}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$spxl.System.Xml.Linq.XName), $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Xml.Linq.XName`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNodeEqualityComparer", ($self) => class XNodeEqualityComparer extends $.$$.System.Object
        {
            /*bool */ Equals$2(/*XNode?*/ x, /*XNode?*/ y)
            {
                return $.$spxl.System.Xml.Linq.XNode.DeepEquals(x, y);
            }
            /*int */ GetHashCode$1(/*XNode*/ obj)
            {
                return obj !== null ? obj.GetDeepHashCode() : 0;
            }
            /*bool */ System$Collections$IEqualityComparer$Equals(/*object?*/ x, /*object?*/ y)
            {
                /*XNode?*/ let n1 = $.$as(x, $.$spxl.System.Xml.Linq.XNode);
                if (n1 === null && x !== null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "x");
                }
                /*XNode?*/ let n2 = $.$as(y, $.$spxl.System.Xml.Linq.XNode);
                if (n2 === null && y !== null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "y");
                }
                return this.Equals$2(n1, n2);
            }
            /*int */ System$Collections$IEqualityComparer$GetHashCode(/*object*/ obj)
            {
                /*XNode?*/ let n = $.$as(obj, $.$spxl.System.Xml.Linq.XNode);
                if (n === null && obj !== null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "obj");
                }
                return this.GetHashCode$1(n);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Linq.XNode>.Equals(System.Xml.Linq.XNode?, System.Xml.Linq.XNode?)
            System$Collections$Generic$IEqualityComparer$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Linq.XNode>.GetHashCode(System.Xml.Linq.XNode)
            System$Collections$Generic$IEqualityComparer$$$GetHashCode()
            {
                return this.GetHashCode$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2484176;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"x","p":2287568},{"n":"y","p":2287568}],"n":"Equals","o":"@$2","d":2484176,"h":4297451472,"f":16777217},{"r":655361,"p":[{"n":"obj","p":2287568}],"n":"GetHashCode","o":"@$1","d":2484176,"h":8592418768,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":2484176,"h":21477320656,"f":16777217}],"i":[31916033,$.$$.System.Collections.Generic.IEqualityComparer$$($.$spxl.System.Xml.Linq.XNode).$h],"h":2484176}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEqualityComparer, $.$$.System.Collections.Generic.IEqualityComparer$$($.$spxl.System.Xml.Linq.XNode) ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeEqualityComparer`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNodeDocumentOrderComparer", ($self) => class XNodeDocumentOrderComparer extends $.$$.System.Object
        {
            /*int */ Compare(/*XNode?*/ x, /*XNode?*/ y)
            {
                return $.$spxl.System.Xml.Linq.XNode.CompareDocumentOrder(x, y);
            }
            /*int */ System$Collections$IComparer$Compare(/*object?*/ x, /*object?*/ y)
            {
                /*XNode?*/ let n1 = $.$as(x, $.$spxl.System.Xml.Linq.XNode);
                if (n1 === null && x !== null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "x");
                }
                /*XNode?*/ let n2 = $.$as(y, $.$spxl.System.Xml.Linq.XNode);
                if (n2 === null && y !== null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "y");
                }
                return this.Compare(n1, n2);
            }
            //Generated interface implemetation for System.Collections.Generic.IComparer<System.Xml.Linq.XNode?>.Compare(System.Xml.Linq.XNode?, System.Xml.Linq.XNode?)
            System$Collections$Generic$IComparer$$$Compare()
            {
                return this.Compare(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2418640;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"x","p":2287568},{"n":"y","p":2287568}],"n":"Compare","d":2418640,"h":4297385936,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":2418640,"h":12887320528,"f":16777217}],"i":[31522817,$.$$.System.Collections.Generic.IComparer$$($.$spxl.System.Xml.Linq.XNode).$h],"h":2418640}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IComparer, $.$$.System.Collections.Generic.IComparer$$($.$spxl.System.Xml.Linq.XNode) ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeDocumentOrderComparer`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.Inserter", ($self) => class Inserter extends $.$$.System.ValueType
        {
            /*XContainer*/  get _parent() { return this.$getField(0, 4); }
            /*XContainer*/  set _parent(value) { this.$setField(0, 4, value); }
            /*XNode?*/  get _previous() { return this.$getField(4, 4); }
            /*XNode?*/  set _previous(value) { this.$setField(4, 4, value); }
            /*string?*/  get _text() { return this.$getField(8, 4); }
            /*string?*/  set _text(value) { this.$setField(8, 4, value); }
            $ctor$3(/*XContainer*/ parent, /*XNode?*/ anchor)
            {
                super.$ctor$1();
                {
                    this._parent = parent;
                    this._previous = anchor;
                    this._text = null;
                }
                return this;
            }
            /*void */ Add(/*object?*/ content)
            {
                this.AddContent(content);
                if ($.$$.System.String.op_Inequality(this._text, null))
                {
                    if (this._parent.content === null)
                    {
                        if (this._parent.SkipNotify())
                        {
                            this._parent.content = this._text;
                        }
                        else 
                        {
                            if (this._text.length > 0)
                            {
                                this.InsertNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(this._text));
                            }
                            else 
                            {
                                if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XElement))
                                {
                                    this._parent.NotifyChanging(this._parent, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                                    if (this._parent.content !== null)
                                    {
                                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                                    }
                                    this._parent.content = this._text;
                                    this._parent.NotifyChanged(this._parent, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                                }
                                else 
                                {
                                    this._parent.content = this._text;
                                }
                            }
                        }
                    }
                    else if (this._text.length > 0)
                    {
                        /*XText?*/ let prevXText = $.$as(this._previous, $.$spxl.System.Xml.Linq.XText);
                        if (prevXText !== null && !($.$is(this._previous, $.$spxl.System.Xml.Linq.XCData)))
                        {
                            prevXText.Value += this._text;
                        }
                        else 
                        {
                            this._parent.ConvertTextToNode();
                            this.InsertNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(this._text));
                        }
                    }
                }
            }
            /*void */ AddContent(/*object?*/ content)
            {
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.AddNode(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    this.AddString(s);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$13(x));
                    return;
                }
                /*object?[]?*/ let o = $.$as(content, $.$typeArray($.$$.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.AddContent(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$$.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$IEnumerable$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$IEnumerator$Current;
                        {
                            this.AddContent(obj);
                        }
                    }
                    return;
                }
                if ($.$is(content, $.$spxl.System.Xml.Linq.XAttribute))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_AddAttribute);
                }
                this.AddString($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            /*void */ AddNode(/*XNode*/ n)
            {
                this._parent.ValidateNode(n, this._previous);
                if (n.parent !== null)
                {
                    n = n.CloneNode();
                }
                else 
                {
                    /*XNode*/ let p = this._parent;
                    while(p.parent !== null)
                    {
                        p = p.parent;
                    }
                    if (n === p)
                    {
                        n = n.CloneNode();
                    }
                }
                this._parent.ConvertTextToNode();
                if ($.$$.System.String.op_Inequality(this._text, null))
                {
                    if (this._text.length > 0)
                    {
                        /*XText?*/ let prevXText = $.$as(this._previous, $.$spxl.System.Xml.Linq.XText);
                        if (prevXText !== null && !($.$is(this._previous, $.$spxl.System.Xml.Linq.XCData)))
                        {
                            prevXText.Value += this._text;
                        }
                        else 
                        {
                            this.InsertNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(this._text));
                        }
                    }
                    this._text = null;
                }
                this.InsertNode(n);
            }
            /*void */ AddString(/*string*/ s)
            {
                this._parent.ValidateString(s);
                this._text += s;
            }
            /*void */ InsertNode(/*XNode*/ n)
            {
                /*bool*/ let notify = this._parent.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                if (n.parent !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                n.parent = this._parent;
                if (this._parent.content === null || $.$is(this._parent.content, $.$$.System.String))
                {
                    n.next = n;
                    this._parent.content = n;
                }
                else if (this._previous === null)
                {
                    /*XNode*/ let last = $.$cast(this._parent.content, $.$spxl.System.Xml.Linq.XNode);
                    n.next = last.next;
                    last.next = n;
                }
                else 
                {
                    n.next = this._previous.next;
                    this._previous.next = n;
                    if (this._parent.content === this._previous)
                    {
                        this._parent.content = n;
                    }
                }
                this._previous = n;
                if (notify)
                {
                    this._parent.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                }
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._parent = this._parent;
                copy._previous = this._previous;
                copy._text = this._text;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._parent = null;
                this._previous = null;
                this._text = null;
            }
            static $h = 518096;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"content","p":131073}],"n":"Add","d":518096,"h":21475354576,"f":16777217},{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddContent","d":518096,"h":25770321872,"f":16777218},{"r":65537,"p":[{"n":"n","p":2287568}],"n":"AddNode","d":518096,"h":30065289168,"f":16777218},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AddString","d":518096,"h":34360256464,"f":16777218},{"r":65537,"p":[{"n":"n","p":2287568}],"n":"InsertNode","d":518096,"h":38655223760,"f":16777218}],"l":[{"t":1370064,"n":"_parent","d":518096,"h":4295485392,"f":4194306},{"t":2287568,"n":"_previous","d":518096,"h":8590452688,"f":4194306},{"t":1310721,"n":"_text","d":518096,"h":12885419984,"f":4194306}],"c":[{"p":[{"n":"parent","p":1370064},{"n":"anchor","p":2287568}],"n":".ctor","o":"$ctor$3","d":518096,"h":17180387280,"f":16777217},{"n":".ctor","o":"$ctor$2","d":518096,"h":42950191056,"f":16777217}],"h":518096}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.Inserter`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.NamespaceCache", ($self) => class NamespaceCache extends $.$$.System.ValueType
        {
            /*XNamespace*/  get _ns() { return this.$getField(0, 4); }
            /*XNamespace*/  set _ns(value) { this.$setField(0, 4, value); }
            /*string*/  get _namespaceName() { return this.$getField(4, 4); }
            /*string*/  set _namespaceName(value) { this.$setField(4, 4, value); }
            /*XNamespace */ Get(/*string*/ namespaceName)
            {
                if (namespaceName === this._namespaceName)
                {
                    return this._ns;
                }
                this._namespaceName = namespaceName;
                this._ns = $.$spxl.System.Xml.Linq.XNamespace.Get$1(namespaceName);
                return this._ns;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._ns = this._ns;
                copy._namespaceName = this._namespaceName;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._ns = null;
                this._namespaceName = null;
            }
            static $h = 780240;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":2222032,"p":[{"n":"namespaceName","p":1310721}],"n":"Get","d":780240,"h":12885682128,"f":16777217}],"l":[{"t":2222032,"n":"_ns","d":780240,"h":4295747536,"f":4194306},{"t":1310721,"n":"_namespaceName","d":780240,"h":8590714832,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":780240,"h":17180649424,"f":16777217}],"h":780240}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.NamespaceCache`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.ElementWriter", ($self) => class ElementWriter extends $.$$.System.ValueType
        {
            /*XmlWriter*/  get _writer() { return this.$getField(0, 4); }
            /*XmlWriter*/  set _writer(value) { this.$setField(0, 4, value); }
            /*NamespaceResolver*/  get _resolver() { return this.$getField(4, 12); }
            /*NamespaceResolver*/  set _resolver(value) { this.$setField(4, 12, value); }
            $ctor$3(/*XmlWriter*/ writer)
            {
                super.$ctor$1();
                {
                    this._writer = writer;
                    this._resolver = new $.$spxl.System.Xml.Linq.NamespaceResolver();
                }
                return this;
            }
            /*void */ WriteElement(/*XElement*/ e)
            {
                this.PushAncestors(e);
                /*XElement*/ let root = e;
                /*XNode*/ let n = e;
                while(true)
                {
                    /*XElement?*/ let current = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                    if (current !== null)
                    {
                        this.WriteStartElement(current);
                        if (current.content === null)
                        {
                            this.WriteEndElement();
                        }
                        else 
                        {
                            /*string?*/ let s = $.$as(current.content, $.$$.System.String);
                            if ($.$$.System.String.op_Inequality(s, null))
                            {
                                this._writer.WriteString(s);
                                this.WriteFullEndElement();
                            }
                            else 
                            {
                                n = ($.$cast(current.content, $.$spxl.System.Xml.Linq.XNode)).next;
                                continue;
                            }
                        }
                    }
                    else 
                    {
                        n.WriteTo(this._writer);
                    }
                    while(n !== root && n === n.parent.content)
                    {
                        n = n.parent;
                        this.WriteFullEndElement();
                    }
                    if (n === root)
                    {
                        break;
                    }
                    n = n.next;
                }
            }
            /*Task *//*async*/  WriteElementAsync(/*XElement*/ e, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    this.PushAncestors(e);
                    /*XElement*/ let root = e;
                    /*XNode*/ let n = e;
                    while(true)
                    {
                        /*XElement?*/ let current = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (current !== null)
                        {
                            await this.WriteStartElementAsync(current, cancellationToken).ConfigureAwait(false);
                            if (current.content === null)
                            {
                                await this.WriteEndElementAsync(cancellationToken).ConfigureAwait(false);
                            }
                            else 
                            {
                                /*string?*/ let s = $.$as(current.content, $.$$.System.String);
                                if ($.$$.System.String.op_Inequality(s, null))
                                {
                                    cancellationToken.ThrowIfCancellationRequested();
                                    await this._writer.WriteStringAsync(s).ConfigureAwait(false);
                                    await this.WriteFullEndElementAsync(cancellationToken).ConfigureAwait(false);
                                }
                                else 
                                {
                                    n = ($.$cast(current.content, $.$spxl.System.Xml.Linq.XNode)).next;
                                    continue;
                                }
                            }
                        }
                        else 
                        {
                            await n.WriteToAsync(this._writer, cancellationToken).ConfigureAwait(false);
                        }
                        while(n !== root && n === n.parent.content)
                        {
                            n = n.parent;
                            await this.WriteFullEndElementAsync(cancellationToken).ConfigureAwait(false);
                        }
                        if (n === root)
                        {
                            break;
                        }
                        n = n.next;
                    }
                });
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns, /*bool*/ allowDefaultNamespace)
            {
                /*string*/ let namespaceName = ns.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$$.System.String.Empty;
                }
                /*string?*/ let prefix = this._resolver.GetPrefixOfNamespace(ns, allowDefaultNamespace);
                if ($.$$.System.String.op_Inequality(prefix, null))
                {
                    return prefix;
                }
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    return "xml";
                }
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            /*void */ PushAncestors(/*XElement?*/ e)
            {
                while(true)
                {
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    if (e === null)
                    {
                        break;
                    }
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration)
                            {
                                this._resolver.AddFirst(a.Name.NamespaceName.length === 0 ? $.$$.System.String.Empty : a.Name.LocalName, $.$spxl.System.Xml.Linq.XNamespace.Get$1(a.Value));
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
            }
            /*void */ PushElement(/*XElement*/ e)
            {
                this._resolver.PushScope();
                /*XAttribute?*/ let a = e.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if (a.IsNamespaceDeclaration)
                        {
                            this._resolver.Add(a.Name.NamespaceName.length === 0 ? $.$$.System.String.Empty : a.Name.LocalName, $.$spxl.System.Xml.Linq.XNamespace.Get$1(a.Value));
                        }
                    }
                    while(a !== e.lastAttr);
                }
            }
            /*void */ WriteEndElement()
            {
                this._writer.WriteEndElement();
                this._resolver.PopScope();
            }
            /*Task *//*async*/  WriteEndElementAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await this._writer.WriteEndElementAsync().ConfigureAwait(false);
                    this._resolver.PopScope();
                });
            }
            /*void */ WriteFullEndElement()
            {
                this._writer.WriteFullEndElement();
                this._resolver.PopScope();
            }
            /*Task *//*async*/  WriteFullEndElementAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await this._writer.WriteFullEndElementAsync().ConfigureAwait(false);
                    this._resolver.PopScope();
                });
            }
            /*void */ WriteStartElement(/*XElement*/ e)
            {
                this.PushElement(e);
                /*XNamespace*/ let ns = e.Name.Namespace;
                this._writer.WriteStartElement(this.GetPrefixOfNamespace(ns, true), e.Name.LocalName, ns.NamespaceName);
                /*XAttribute?*/ let a = e.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        ns = a.Name.Namespace;
                        /*string*/ let localName = a.Name.LocalName;
                        /*string*/ let namespaceName = ns.NamespaceName;
                        this._writer.WriteAttributeString(this.GetPrefixOfNamespace(ns, false), localName, namespaceName.length === 0 && $.$$.System.String.op_Equality(localName, "xmlns") ? "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/ : namespaceName, a.Value);
                    }
                    while(a !== e.lastAttr);
                }
            }
            /*Task *//*async*/  WriteStartElementAsync(/*XElement*/ e, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    this.PushElement(e);
                    /*XNamespace*/ let ns = e.Name.Namespace;
                    await this._writer.WriteStartElementAsync(this.GetPrefixOfNamespace(ns, true), e.Name.LocalName, ns.NamespaceName).ConfigureAwait(false);
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            ns = a.Name.Namespace;
                            /*string*/ let localName = a.Name.LocalName;
                            /*string*/ let namespaceName = ns.NamespaceName;
                            cancellationToken.ThrowIfCancellationRequested();
                            await this._writer.WriteAttributeStringAsync(this.GetPrefixOfNamespace(ns, false), localName, namespaceName.length === 0 && $.$$.System.String.op_Equality(localName, "xmlns") ? "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/ : namespaceName, a.Value).ConfigureAwait(false);
                        }
                        while(a !== e.lastAttr);
                    }
                });
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._writer = this._writer;
                copy._resolver = this._resolver.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._writer = null;
                this._resolver = $.$default($.$spxl.System.Xml.Linq.NamespaceResolver);
            }
            static $h = 387024;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"e","p":1697744}],"n":"WriteElement","d":387024,"h":17180256208,"f":16777217},{"r":133169153,"p":[{"n":"e","p":1697744},{"n":"cancellationToken","p":125829121}],"n":"WriteElementAsync","d":387024,"h":21475223504,"f":16781313},{"r":1310721,"p":[{"n":"ns","p":2222032},{"n":"allowDefaultNamespace","p":262145}],"n":"GetPrefixOfNamespace","d":387024,"h":25770190800,"f":16777218},{"r":65537,"p":[{"n":"e","p":1697744}],"n":"PushAncestors","d":387024,"h":30065158096,"f":16777218},{"r":65537,"p":[{"n":"e","p":1697744}],"n":"PushElement","d":387024,"h":34360125392,"f":16777218},{"r":65537,"n":"WriteEndElement","d":387024,"h":38655092688,"f":16777218},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121}],"n":"WriteEndElementAsync","d":387024,"h":42950059984,"f":16781314},{"r":65537,"n":"WriteFullEndElement","d":387024,"h":47245027280,"f":16777218},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121}],"n":"WriteFullEndElementAsync","d":387024,"h":51539994576,"f":16781314},{"r":65537,"p":[{"n":"e","p":1697744}],"n":"WriteStartElement","d":387024,"h":55834961872,"f":16777218},{"r":133169153,"p":[{"n":"e","p":1697744},{"n":"cancellationToken","p":125829121}],"n":"WriteStartElementAsync","d":387024,"h":60129929168,"f":16781314}],"l":[{"t":58440342,"n":"_writer","d":387024,"h":4295354320,"f":4194306},{"t":845776,"n":"_resolver","d":387024,"h":8590321616,"f":4194306}],"c":[{"p":[{"n":"writer","p":58440342}],"n":".ctor","o":"$ctor$3","d":387024,"h":12885288912,"f":16777217},{"n":".ctor","o":"$ctor$2","d":387024,"h":64424896464,"f":16777217}],"h":387024}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.ElementWriter`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.NamespaceResolver", ($self) => class NamespaceResolver extends $.$$.System.ValueType
        {
            static $_NamespaceDeclaration;
            static get NamespaceDeclaration()
            {
                let $cls = $.$spxl.System.Xml.Linq.NamespaceResolver;
                return $cls.$_NamespaceDeclaration ??= $asm.$ncls("$spxl.System.Xml.Linq.NamespaceResolver.NamespaceDeclaration", ($self) => class NamespaceDeclaration extends $.$$.System.Object
                {
                    /*string*/ prefix = null;
                    /*XNamespace*/ ns = null;
                    /*int*/ scope = 0;
                    /*NamespaceDeclaration*/ prev = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.prefix = null;
                        this.ns = null;
                        this.prev = null;
                    }
                    static $h = 911312;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"prefix","d":911312,"h":4295878608,"f":4194305},{"t":2222032,"n":"ns","d":911312,"h":8590845904,"f":4194305},{"t":655361,"n":"scope","d":911312,"h":12885813200,"f":4194305},{"t":911312,"n":"prev","d":911312,"h":17180780496,"f":4194305}],"c":[{"n":".ctor","o":"$ctor$1","d":911312,"h":21475747792,"f":16777217}],"d":845776,"h":911312}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Xml.Linq.NamespaceResolver.NamespaceDeclaration`; }
                }, $cls, ($v) => $cls.$_NamespaceDeclaration = $v);
            }
            /*int*/  get _scope() { return this.$getField(0, 4); }
            /*int*/  set _scope(value) { this.$setField(0, 4, value); }
            /*NamespaceDeclaration?*/  get _declaration() { return this.$getField(4, 4); }
            /*NamespaceDeclaration?*/  set _declaration(value) { this.$setField(4, 4, value); }
            /*NamespaceDeclaration?*/  get _rover() { return this.$getField(8, 4); }
            /*NamespaceDeclaration?*/  set _rover(value) { this.$setField(8, 4, value); }
            /*void */ PushScope()
            {
                this._scope++;
            }
            /*void */ PopScope()
            {
                /*NamespaceDeclaration?*/ let d = this._declaration;
                if (d !== null)
                {
                    do
                    {
                        d = d.prev;
                        if (d.scope !== this._scope)
                        {
                            break;
                        }
                        if (d === this._declaration)
                        {
                            this._declaration = null;
                        }
                        else 
                        {
                            this._declaration.prev = d.prev;
                        }
                        this._rover = null;
                    }
                    while(d !== this._declaration && this._declaration !== null);
                }
                this._scope--;
            }
            /*void */ Add(/*string*/ prefix, /*XNamespace*/ ns)
            {
                /*NamespaceDeclaration*/ let d = new $.$spxl.System.Xml.Linq.NamespaceResolver.NamespaceDeclaration().$ctor$1();
                d.prefix = prefix;
                d.ns = ns;
                d.scope = this._scope;
                if (this._declaration === null)
                {
                    this._declaration = d;
                }
                else 
                {
                    d.prev = this._declaration.prev;
                }
                this._declaration.prev = d;
                this._rover = null;
            }
            /*void */ AddFirst(/*string*/ prefix, /*XNamespace*/ ns)
            {
                /*NamespaceDeclaration*/ let d = new $.$spxl.System.Xml.Linq.NamespaceResolver.NamespaceDeclaration().$ctor$1();
                d.prefix = prefix;
                d.ns = ns;
                d.scope = this._scope;
                if (this._declaration === null)
                {
                    d.prev = d;
                }
                else 
                {
                    d.prev = this._declaration.prev;
                    this._declaration.prev = d;
                }
                this._declaration = d;
                this._rover = null;
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns, /*bool*/ allowDefaultNamespace)
            {
                if (this._rover !== null && $.$spxl.System.Xml.Linq.XNamespace.op_Equality(this._rover.ns, ns) && (allowDefaultNamespace || this._rover.prefix.length > 0))
                {
                    return this._rover.prefix;
                }
                /*NamespaceDeclaration?*/ let d = this._declaration;
                if (d !== null)
                {
                    do
                    {
                        d = d.prev;
                        if ($.$spxl.System.Xml.Linq.XNamespace.op_Equality(d.ns, ns))
                        {
                            /*NamespaceDeclaration*/ let x = this._declaration.prev;
                            while(x !== d && $.$$.System.String.op_Inequality(x.prefix, d.prefix))
                            {
                                x = x.prev;
                            }
                            if (x === d)
                            {
                                if (allowDefaultNamespace)
                                {
                                    this._rover = d;
                                    return d.prefix;
                                }
                                else if (d.prefix.length > 0)
                                {
                                    return d.prefix;
                                }
                            }
                        }
                    }
                    while(d !== this._declaration);
                }
                return null;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._scope = this._scope;
                copy._declaration = this._declaration;
                copy._rover = this._rover;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._scope = 0;
                this._declaration = null;
                this._rover = null;
            }
            static $h = 845776;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"n":"PushScope","d":845776,"h":21475682256,"f":16777217},{"r":65537,"n":"PopScope","d":845776,"h":25770649552,"f":16777217},{"r":65537,"p":[{"n":"prefix","p":1310721},{"n":"ns","p":2222032}],"n":"Add","d":845776,"h":30065616848,"f":16777217},{"r":65537,"p":[{"n":"prefix","p":1310721},{"n":"ns","p":2222032}],"n":"AddFirst","d":845776,"h":34360584144,"f":16777217},{"r":1310721,"p":[{"n":"ns","p":2222032},{"n":"allowDefaultNamespace","p":262145}],"n":"GetPrefixOfNamespace","d":845776,"h":38655551440,"f":16777217}],"l":[{"t":655361,"n":"_scope","d":845776,"h":8590780368,"f":4194306},{"t":911312,"n":"_declaration","d":845776,"h":12885747664,"f":4194306},{"t":911312,"n":"_rover","d":845776,"h":17180714960,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":845776,"h":42950518736,"f":16777217}],"j":[911312],"h":845776}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.NamespaceResolver`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.StreamingElementWriter", ($self) => class StreamingElementWriter extends $.$$.System.ValueType
        {
            /*XmlWriter*/  get _writer() { return this.$getField(0, 4); }
            /*XmlWriter*/  set _writer(value) { this.$setField(0, 4, value); }
            /*XStreamingElement?*/  get _element() { return this.$getField(4, 4); }
            /*XStreamingElement?*/  set _element(value) { this.$setField(4, 4, value); }
            /*List<XAttribute>*/  get _attributes() { return this.$getField(8, 4); }
            /*List<XAttribute>*/  set _attributes(value) { this.$setField(8, 4, value); }
            /*NamespaceResolver*/  get _resolver() { return this.$getField(12, 12); }
            /*NamespaceResolver*/  set _resolver(value) { this.$setField(12, 12, value); }
            $ctor$3(/*XmlWriter*/ w)
            {
                super.$ctor$1();
                {
                    this._writer = w;
                    this._element = null;
                    this._attributes = new ($.$$.System.Collections.Generic.List$$($.$spxl.System.Xml.Linq.XAttribute))().$ctor$1();
                    this._resolver = new $.$spxl.System.Xml.Linq.NamespaceResolver();
                }
                return this;
            }
            /*void */ FlushElement()
            {
                if (this._element !== null)
                {
                    this.PushElement();
                    /*XNamespace*/ let ns = this._element.Name.Namespace;
                    this._writer.WriteStartElement(this.GetPrefixOfNamespace(ns, true), this._element.Name.LocalName, ns.NamespaceName);
                    var $en3 = this._attributes.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var a = $en3.Current;
                        {
                            ns = a.Name.Namespace;
                            /*string*/ let localName = a.Name.LocalName;
                            /*string*/ let namespaceName = ns.NamespaceName;
                            this._writer.WriteAttributeString(this.GetPrefixOfNamespace(ns, false), localName, namespaceName.length === 0 && $.$$.System.String.op_Equality(localName, "xmlns") ? "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/ : namespaceName, a.Value);
                        }
                    }
                    this._element = null;
                    this._attributes.Clear();
                }
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns, /*bool*/ allowDefaultNamespace)
            {
                /*string*/ let namespaceName = ns.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$$.System.String.Empty;
                }
                /*string?*/ let prefix = this._resolver.GetPrefixOfNamespace(ns, allowDefaultNamespace);
                if ($.$$.System.String.op_Inequality(prefix, null))
                {
                    return prefix;
                }
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    return "xml";
                }
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            /*void */ PushElement()
            {
                this._resolver.PushScope();
                var $en2 = this._attributes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var a = $en2.Current;
                    {
                        if (a.IsNamespaceDeclaration)
                        {
                            this._resolver.Add(a.Name.NamespaceName.length === 0 ? $.$$.System.String.Empty : a.Name.LocalName, $.$spxl.System.Xml.Linq.XNamespace.Get$1(a.Value));
                        }
                    }
                }
            }
            /*void */ Write(/*object?*/ content)
            {
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.WriteNode(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    this.WriteString(s);
                    return;
                }
                /*XAttribute?*/ let a = $.$as(content, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    this.WriteAttribute(a);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.WriteStreamingElement(x);
                    return;
                }
                /*object[]?*/ let o = $.$as(content, $.$typeArray($.$$.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.Write(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$$.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$IEnumerable$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$IEnumerator$Current;
                        {
                            this.Write(obj);
                        }
                    }
                    return;
                }
                this.WriteString($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            /*void */ WriteAttribute(/*XAttribute*/ a)
            {
                if (this._element === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_WriteAttribute);
                }
                this._attributes.Add(a);
            }
            /*void */ WriteNode(/*XNode*/ n)
            {
                this.FlushElement();
                n.WriteTo(this._writer);
            }
            /*void */ WriteStreamingElement(/*XStreamingElement*/ e)
            {
                this.FlushElement();
                this._element = e;
                this.Write(e.content);
                this.FlushElement();
                this._writer.WriteEndElement();
                this._resolver.PopScope();
            }
            /*void */ WriteString(/*string*/ s)
            {
                this.FlushElement();
                this._writer.WriteString(s);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._writer = this._writer;
                copy._element = this._element;
                copy._attributes = this._attributes;
                copy._resolver = this._resolver.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._writer = null;
                this._element = null;
                this._attributes = null;
                this._resolver = $.$default($.$spxl.System.Xml.Linq.NamespaceResolver);
            }
            static $h = 1107920;
            static $z = 24;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"n":"FlushElement","d":1107920,"h":25770911696,"f":16777218},{"r":1310721,"p":[{"n":"ns","p":2222032},{"n":"allowDefaultNamespace","p":262145}],"n":"GetPrefixOfNamespace","d":1107920,"h":30065878992,"f":16777218},{"r":65537,"n":"PushElement","d":1107920,"h":34360846288,"f":16777218},{"r":65537,"p":[{"n":"content","p":131073}],"n":"Write","d":1107920,"h":38655813584,"f":16777218},{"r":65537,"p":[{"n":"a","p":1173456}],"n":"WriteAttribute","d":1107920,"h":42950780880,"f":16777218},{"r":65537,"p":[{"n":"n","p":2287568}],"n":"WriteNode","d":1107920,"h":47245748176,"f":16777218},{"r":65537,"p":[{"n":"e","p":2942928}],"n":"WriteStreamingElement","d":1107920,"h":51540715472,"f":16777224},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"WriteString","d":1107920,"h":55835682768,"f":16777218}],"l":[{"t":58440342,"n":"_writer","d":1107920,"h":4296075216,"f":4194306},{"t":2942928,"n":"_element","d":1107920,"h":8591042512,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$spxl.System.Xml.Linq.XAttribute).$h,"n":"_attributes","d":1107920,"h":12886009808,"f":4194306},{"t":845776,"n":"_resolver","d":1107920,"h":17180977104,"f":4194306}],"c":[{"p":[{"n":"w","p":58440342}],"n":".ctor","o":"$ctor$3","d":1107920,"h":21475944400,"f":16777217},{"n":".ctor","o":"$ctor$2","d":1107920,"h":60130650064,"f":16777217}],"h":1107920}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.StreamingElementWriter`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XAttribute", ($self) => class XAttribute extends $.$spxl.System.Xml.Linq.XObject
        {
            static /*IEnumerable<XAttribute> */ get EmptySequence()
            {
                return $.$$.System.Array.Empty($.$spxl.System.Xml.Linq.XAttribute);
            }
            /*XAttribute?*/ next = null;
            /*XName*/ name = null;
            /*string*/ value = null;
            $ctor$3(/*XName*/ name, /*object*/ value)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                    /*string*/ let s = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
                    $.$spxl.System.Xml.Linq.XAttribute.ValidateAttribute(name, s);
                    this.name = name;
                    this.value = s;
                }
                return this;
            }
            $ctor$2(/*XAttribute*/ other)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this.name = other.name;
                    this.value = other.value;
                }
                return this;
            }
            /*bool */ get IsNamespaceDeclaration()
            {
                /*string*/ let namespaceName = this.name.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$$.System.String.op_Equality(this.name.LocalName, "xmlns");
                }
                return namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/;
            }
            /*XName */ get Name()
            {
                return this.name;
            }
            /*XAttribute? */ get NextAttribute()
            {
                return this.parent !== null && ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr !== this ? this.next : null;
            }
            /*XmlNodeType */ get NodeType()
            {
                return 2/*XmlNodeType.Attribute*/;
            }
            /*XAttribute? */ get PreviousAttribute()
            {
                if (this.parent === null)
                {
                    return null;
                }
                /*XAttribute*/ let a = ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr;
                while(a.next !== this)
                {
                    a = a.next;
                }
                return a !== ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr ? a : null;
            }
            /*string */ get Value()
            {
                return this.value;
            }
            /*string */ set Value(value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                $.$spxl.System.Xml.Linq.XAttribute.ValidateAttribute(this.name, value);
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.value = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*void */ Remove()
            {
                if (this.parent === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).RemoveAttribute(this);
            }
            /*void */ SetValue(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
            }
            static/*conventional*/ /*string */ ToString()
            {
                let sw = null;
                try
                {
                    sw = new $.$$.System.IO.StringWriter().$ctor$5($.$$.System.Globalization.CultureInfo.InvariantCulture);
                    /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                    ws.ConformanceLevel = 1/*ConformanceLevel.Fragment*/;
                    let w = null;
                    try
                    {
                        w = $.$spx.System.Xml.XmlWriter.Create$2(sw, ws);
                        w.WriteAttributeString(this.GetPrefixOfNamespace(this.name.Namespace), this.name.LocalName, this.name.NamespaceName, this.value);
                    }
                    finally
                    {
                        w?.System$IDisposable$Dispose();
                    }
                    return $.$$.System.String.Trim.call($.$$.System.IO.StringWriter.ToString.call(sw));
                }
                finally
                {
                    sw?.System$IDisposable$Dispose();
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XAttribute.ToString.apply(this, arguments); }
            static /*string? */ op_Explicit$21(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return attribute.value;
            }
            static /*bool */ op_Explicit(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$$.System.String.ToLowerInvariant.call(attribute.value));
            }
            static /*bool? */ op_Explicit$8(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$$.System.String.ToLowerInvariant.call(attribute.value));
            }
            static /*int */ op_Explicit$6(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToInt32(attribute.value);
            }
            static /*int? */ op_Explicit$14(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt32(attribute.value);
            }
            static /*uint */ op_Explicit$23(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToUInt32(attribute.value);
            }
            static /*uint? */ op_Explicit$18(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt32(attribute.value);
            }
            static /*long */ op_Explicit$7(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToInt64(attribute.value);
            }
            static /*long? */ op_Explicit$15(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt64(attribute.value);
            }
            static /*ulong */ op_Explicit$24(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToUInt64(attribute.value);
            }
            static /*ulong? */ op_Explicit$19(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt64(attribute.value);
            }
            static /*float */ op_Explicit$20(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToSingle(attribute.value);
            }
            static /*float? */ op_Explicit$16(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToSingle(attribute.value);
            }
            static /*double */ op_Explicit$4(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToDouble(attribute.value);
            }
            static /*double? */ op_Explicit$12(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDouble(attribute.value);
            }
            static /*decimal */ op_Explicit$3(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToDecimal(attribute.value);
            }
            static /*decimal? */ op_Explicit$11(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDecimal(attribute.value);
            }
            static /*DateTime */ op_Explicit$1(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$$.System.DateTime.Parse$2(attribute.value, $.$$.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            static /*DateTime? */ op_Explicit$9(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$$.System.DateTime.Parse$2(attribute.value, $.$$.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            static /*DateTimeOffset */ op_Explicit$2(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset$2(attribute.value);
            }
            static /*DateTimeOffset? */ op_Explicit$10(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset$2(attribute.value);
            }
            static /*TimeSpan */ op_Explicit$22(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(attribute.value);
            }
            static /*TimeSpan? */ op_Explicit$17(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(attribute.value);
            }
            static /*Guid */ op_Explicit$5(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToGuid(attribute.value);
            }
            static /*Guid? */ op_Explicit$13(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToGuid(attribute.value);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$spxl.System.Xml.Linq.XName.GetHashCode.call(this.name) ^ $.$$.System.String.GetHashCode.call(this.value);
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns)
            {
                /*string*/ let namespaceName = ns.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$$.System.String.Empty;
                }
                if (this.parent !== null)
                {
                    return ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).GetPrefixOfNamespace(ns);
                }
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    return "xml";
                }
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            static /*void */ ValidateAttribute(/*XName*/ name, /*string*/ value)
            {
                /*string*/ let namespaceName = name.NamespaceName;
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    if (value.length === 0)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_NamespaceDeclarationPrefixed, name.LocalName));
                    }
                    else if ($.$$.System.String.op_Equality(value, "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/))
                    {
                        if ($.$$.System.String.op_Inequality(name.LocalName, "xml"))
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_NamespaceDeclarationXml);
                        }
                    }
                    else if ($.$$.System.String.op_Equality(value, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_NamespaceDeclarationXmlns);
                    }
                    else 
                    {
                        /*string*/ let localName = name.LocalName;
                        if ($.$$.System.String.op_Equality(localName, "xml"))
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_NamespaceDeclarationXml);
                        }
                        else if ($.$$.System.String.op_Equality(localName, "xmlns"))
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_NamespaceDeclarationXmlns);
                        }
                    }
                }
                else if (namespaceName.length === 0 && $.$$.System.String.op_Equality(name.LocalName, "xmlns"))
                {
                    if ($.$$.System.String.op_Equality(value, "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_NamespaceDeclarationXml);
                    }
                    else if ($.$$.System.String.op_Equality(value, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_NamespaceDeclarationXmlns);
                    }
                }
            }
            static $h = 1173456;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2615248,"p":[{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"g":{"r":0,"d":0,"h":8591108048,"f":50331681},"n":"EmptySequence","d":1173456,"h":4296140752,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":38655879120,"f":50331649},"n":"IsNamespaceDeclaration","d":1173456,"h":34360911824,"f":2097153},{"p":2156496,"g":{"r":0,"d":0,"h":47245813712,"f":50331649},"n":"Name","d":1173456,"h":42950846416,"f":2097153},{"p":1173456,"g":{"r":0,"d":0,"h":55835748304,"f":50331649},"n":"NextAttribute","d":1173456,"h":51540781008,"f":2097153},{"p":52869782,"g":{"r":0,"d":0,"h":64425682896,"f":50364417},"n":"NodeType","d":1173456,"h":60130715600,"f":2129921},{"p":1173456,"g":{"r":0,"d":0,"h":73015617488,"f":50331649},"n":"PreviousAttribute","d":1173456,"h":68720650192,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":81605552080,"f":50331649},"s":{"r":0,"d":0,"h":85900519376,"f":83886081},"n":"Value","d":1173456,"h":77310584784,"f":2097153}],"m":[{"r":65537,"n":"Remove","d":1173456,"h":90195486672,"f":16777217},{"r":65537,"p":[{"n":"value","p":131073}],"n":"SetValue","d":1173456,"h":94490453968,"f":16777217},{"r":1310721,"n":"ToString","d":1173456,"h":98785421264,"f":16809985},{"r":655361,"n":"GetDeepHashCode","d":1173456,"h":210454570960,"f":16777224},{"r":1310721,"p":[{"n":"ns","p":2222032}],"n":"GetPrefixOfNamespace","d":1173456,"h":214749538256,"f":16777224},{"r":65537,"p":[{"n":"name","p":2156496},{"n":"value","p":1310721}],"n":"ValidateAttribute","d":1173456,"h":219044505552,"f":16777250}],"l":[{"t":1173456,"n":"next","d":1173456,"h":12886075344,"f":4194312},{"t":2156496,"n":"name","d":1173456,"h":17181042640,"f":4194312},{"t":1310721,"n":"value","d":1173456,"h":21476009936,"f":4194312}],"c":[{"p":[{"n":"name","p":2156496},{"n":"value","p":131073}],"n":".ctor","o":"$ctor$3","d":1173456,"h":25770977232,"f":16777217},{"p":[{"n":"other","p":1173456}],"n":".ctor","o":"$ctor$2","d":1173456,"h":30065944528,"f":16777217}],"i":[13941398],"h":1173456,"a":[{"t":1545231,"c":4296512527,"a":[{"v":"MS.Internal.Xml.Linq.ComponentModel.XTypeDescriptionProvider\u00601[[System.Xml.Linq.XAttribute, System.Xml.Linq, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]],System.ComponentModel.TypeConverter","t":1310721}]}]}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XObject; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XAttribute`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNodeBuilder", ($self) => class XNodeBuilder extends $.$spx.System.Xml.XmlWriter
        {
            /*List<object>?*/ _content = null;
            /*XContainer?*/ _parent = null;
            /*XName?*/ _attrName = null;
            /*string?*/ _attrValue = null;
            /*XContainer*/ _root = null;
            $ctor$2(/*XContainer*/ container)
            {
                super.$ctor$1();
                {
                    this._root = container;
                }
                return this;
            }
            /*XmlWriterSettings */ get Settings()
            {
                /*XmlWriterSettings*/ let settings = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                settings.ConformanceLevel = 0/*ConformanceLevel.Auto*/;
                return settings;
            }
            /*WriteState */ get WriteState()
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing)
                {
                    this.Close();
                }
            }
            /*void */ Close()
            {
                this._root.Add(this._content);
            }
            /*void */ Flush()
            {
            }
            /*string */ LookupPrefix(/*string*/ namespaceName)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ WriteBase64(/*byte[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$spxl.System.SR.NotSupported_WriteBase64);
            }
            /*void */ WriteCData(/*string?*/ text)
            {
                this.AddNode(new $.$spxl.System.Xml.Linq.XCData().$ctor$6(text));
            }
            /*void */ WriteCharEntity(/*char*/ ch)
            {
                this.AddString($.$$.System.Char.ToString$1(ch));
            }
            /*void */ WriteChars(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                this.AddString($.$$.System.String.Create$1(buffer, index, count));
            }
            /*void */ WriteComment(/*string?*/ text)
            {
                this.AddNode(new $.$spxl.System.Xml.Linq.XComment().$ctor$3(text));
            }
            /*void */ WriteDocType(/*string*/ name, /*string?*/ pubid, /*string?*/ sysid, /*string?*/ subset)
            {
                this.AddNode(new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(name, pubid, sysid, subset));
            }
            /*void */ WriteEndAttribute()
            {
                /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(this._attrName, this._attrValue);
                this._attrName = null;
                this._attrValue = null;
                if (this._parent !== null)
                {
                    this._parent.Add(a);
                }
                else 
                {
                    this.Add(a);
                }
            }
            /*void */ WriteEndDocument()
            {
            }
            /*void */ WriteEndElement()
            {
                this._parent = ($.$cast(this._parent, $.$spxl.System.Xml.Linq.XElement)).parent;
            }
            /*void */ WriteEntityRef(/*string*/ name)
            {
                switch(name)
                {
                    case "amp":
                    this.AddString("&");
                    break;
                    case "apos":
                    this.AddString("'");
                    break;
                    case "gt":
                    this.AddString(">");
                    break;
                    case "lt":
                    this.AddString("<");
                    break;
                    case "quot":
                    this.AddString("\"");
                    break;
                    default:
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$spxl.System.SR.NotSupported_WriteEntityRef);
                }
            }
            /*void */ WriteFullEndElement()
            {
                /*XElement*/ let e = $.$cast(this._parent, $.$spxl.System.Xml.Linq.XElement);
                if (e.IsEmpty)
                {
                    e.Add($.$$.System.String.Empty);
                }
                this._parent = e.parent;
            }
            /*void */ WriteProcessingInstruction(/*string*/ name, /*string?*/ text)
            {
                if ($.$$.System.String.op_Equality(name, "xml"))
                {
                    return;
                }
                this.AddNode(new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(name, text));
            }
            /*void */ WriteRaw(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                this.AddString($.$$.System.String.Create$1(buffer, index, count));
            }
            /*void */ WriteRaw$1(/*string*/ data)
            {
                this.AddString(data);
            }
            /*void */ WriteStartAttribute(/*string?*/ prefix, /*string*/ localName, /*string?*/ namespaceName)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(prefix, "prefix");
                this._attrName = $.$spxl.System.Xml.Linq.XNamespace.Get$1(prefix.length === 0 ? $.$$.System.String.Empty : namespaceName).GetName$1(localName);
                this._attrValue = $.$$.System.String.Empty;
            }
            /*void */ WriteStartDocument()
            {
            }
            /*void */ WriteStartDocument$1(/*bool*/ standalone)
            {
            }
            /*void */ WriteStartElement(/*string?*/ prefix, /*string*/ localName, /*string?*/ namespaceName)
            {
                this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$12($.$spxl.System.Xml.Linq.XNamespace.Get$1(namespaceName).GetName$1(localName)));
            }
            /*void */ WriteString(/*string?*/ text)
            {
                this.AddString(text);
            }
            /*void */ WriteSurrogateCharEntity(/*char*/ lowCh, /*char*/ highCh)
            {
                this.AddString($.$$.System.String.Create$2($.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [highCh, lowCh], null, null))));
            }
            /*void */ WriteValue$2(/*DateTimeOffset*/ value)
            {
                this.WriteString($.$spx.System.Xml.XmlConvert.ToString$8(value));
            }
            /*void */ WriteWhitespace(/*string?*/ ws)
            {
                this.AddString(ws);
            }
            /*void */ Add(/*object*/ o)
            {
                this._content ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                this._content.Add(o);
            }
            /*void */ AddNode(/*XNode*/ n)
            {
                if (this._parent !== null)
                {
                    this._parent.Add(n);
                }
                else 
                {
                    this.Add(n);
                }
                /*XContainer?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XContainer);
                if (c !== null)
                {
                    this._parent = c;
                }
            }
            /*void */ AddString(/*string?*/ s)
            {
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                if ($.$$.System.String.op_Inequality(this._attrValue, null))
                {
                    this._attrValue += s;
                }
                else if (this._parent !== null)
                {
                    this._parent.Add(s);
                }
                else 
                {
                    this.Add(s);
                }
            }
            static $h = 2353104;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":58440342,"p":[{"p":58505878,"g":{"r":0,"d":0,"h":34362091472,"f":50364417},"n":"Settings","d":2353104,"h":30067124176,"f":2129921},{"p":48609942,"g":{"r":0,"d":0,"h":42952026064,"f":50364417},"n":"WriteState","d":2353104,"h":38657058768,"f":2129921}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":2353104,"h":47246993360,"f":16809988},{"r":65537,"n":"Close","d":2353104,"h":51541960656,"f":16809985},{"r":65537,"n":"Flush","d":2353104,"h":55836927952,"f":16809985},{"r":1310721,"p":[{"n":"namespaceName","p":1310721}],"n":"LookupPrefix","d":2353104,"h":60131895248,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"WriteBase64","d":2353104,"h":64426862544,"f":16809985},{"r":65537,"p":[{"n":"text","p":1310721}],"n":"WriteCData","d":2353104,"h":68721829840,"f":16809985},{"r":65537,"p":[{"n":"ch","p":458753}],"n":"WriteCharEntity","d":2353104,"h":73016797136,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Char).$h},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"WriteChars","d":2353104,"h":77311764432,"f":16809985},{"r":65537,"p":[{"n":"text","p":1310721}],"n":"WriteComment","d":2353104,"h":81606731728,"f":16809985},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"pubid","p":1310721},{"n":"sysid","p":1310721},{"n":"subset","p":1310721}],"n":"WriteDocType","d":2353104,"h":85901699024,"f":16809985},{"r":65537,"n":"WriteEndAttribute","d":2353104,"h":90196666320,"f":16809985},{"r":65537,"n":"WriteEndDocument","d":2353104,"h":94491633616,"f":16809985},{"r":65537,"n":"WriteEndElement","d":2353104,"h":98786600912,"f":16809985},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"WriteEntityRef","d":2353104,"h":103081568208,"f":16809985},{"r":65537,"n":"WriteFullEndElement","d":2353104,"h":107376535504,"f":16809985},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"text","p":1310721}],"n":"WriteProcessingInstruction","d":2353104,"h":111671502800,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Char).$h},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"WriteRaw","d":2353104,"h":115966470096,"f":16809985},{"r":65537,"p":[{"n":"data","p":1310721}],"n":"WriteRaw","o":"@$1","d":2353104,"h":120261437392,"f":16809985},{"r":65537,"p":[{"n":"prefix","p":1310721},{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"WriteStartAttribute","d":2353104,"h":124556404688,"f":16809985},{"r":65537,"n":"WriteStartDocument","d":2353104,"h":128851371984,"f":16809985},{"r":65537,"p":[{"n":"standalone","p":262145}],"n":"WriteStartDocument","o":"@$1","d":2353104,"h":133146339280,"f":16809985},{"r":65537,"p":[{"n":"prefix","p":1310721},{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"WriteStartElement","d":2353104,"h":137441306576,"f":16809985},{"r":65537,"p":[{"n":"text","p":1310721}],"n":"WriteString","d":2353104,"h":141736273872,"f":16809985},{"r":65537,"p":[{"n":"lowCh","p":458753},{"n":"highCh","p":458753}],"n":"WriteSurrogateCharEntity","d":2353104,"h":146031241168,"f":16809985},{"r":65537,"p":[{"n":"value","p":34471937}],"n":"WriteValue","o":"@$2","d":2353104,"h":150326208464,"f":16809985},{"r":65537,"p":[{"n":"ws","p":1310721}],"n":"WriteWhitespace","d":2353104,"h":154621175760,"f":16809985},{"r":65537,"p":[{"n":"o","p":131073}],"n":"Add","d":2353104,"h":158916143056,"f":16777218},{"r":65537,"p":[{"n":"n","p":2287568}],"n":"AddNode","d":2353104,"h":163211110352,"f":16777218},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AddString","d":2353104,"h":167506077648,"f":16777218}],"l":[{"t":$.$$.System.Collections.Generic.List$$($.$$.System.Object).$h,"n":"_content","d":2353104,"h":4297320400,"f":4194306},{"t":1370064,"n":"_parent","d":2353104,"h":8592287696,"f":4194306},{"t":2156496,"n":"_attrName","d":2353104,"h":12887254992,"f":4194306},{"t":1310721,"n":"_attrValue","d":2353104,"h":17182222288,"f":4194306},{"t":1370064,"n":"_root","d":2353104,"h":21477189584,"f":4194306}],"c":[{"p":[{"n":"container","p":1370064}],"n":".ctor","o":"$ctor$2","d":2353104,"h":25772156880,"f":16777217}],"i":[57540609,56950785],"h":2353104}; }
            static get $b() { return $.$spx.System.Xml.XmlWriter; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeBuilder`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNodeReader", ($self) => class XNodeReader extends $.$spx.System.Xml.XmlReader
        {
            /*object*/ _source = null;
            /*object?*/ _parent = null;
            /*ReadState*/ _state = 0;
            /*XNode*/ _root = null;
            /*XmlNameTable*/ _nameTable = null;
            /*bool*/ _omitDuplicateNamespaces = false;
            $ctor$2(/*XNode*/ node, /*XmlNameTable?*/ nameTable, /*ReaderOptions*/ options)
            {
                super.$ctor$1();
                {
                    this._source = node;
                    this._root = node;
                    this._nameTable = nameTable ?? $.$spxl.System.Xml.Linq.XNodeReader.CreateNameTable();
                    this._omitDuplicateNamespaces = (options & 1/*ReaderOptions.OmitDuplicateNamespaces*/) !== 0 ? true : false;
                }
                return this;
            }
            $ctor$3(/*XNode*/ node, /*XmlNameTable?*/ nameTable)
            {
                this.$ctor$2(node, nameTable, (node.GetSaveOptionsFromAnnotations() & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0 ? 1/*ReaderOptions.OmitDuplicateNamespaces*/ : 0/*ReaderOptions.None*/);
                {
                }
                return this;
            }
            /*int */ get AttributeCount()
            {
                if (!this.IsInteractive)
                {
                    return 0;
                }
                /*int*/ let count = 0;
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (!this._omitDuplicateNamespaces || !this.IsDuplicateNamespaceAttribute(a))
                            {
                                count++;
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return count;
            }
            /*string */ get BaseURI()
            {
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return o.BaseUri;
                }
                o = $.$as(this._parent, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return o.BaseUri;
                }
                return $.$$.System.String.Empty;
            }
            /*int */ get Depth()
            {
                if (!this.IsInteractive)
                {
                    return 0;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return $.$spxl.System.Xml.Linq.XNodeReader.GetDepth(o);
                }
                o = $.$as(this._parent, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return (($.$spxl.System.Xml.Linq.XNodeReader.GetDepth(o) + 1) | 0);
                }
                return 0;
            }
            static /*int */ GetDepth(/*XObject*/ o)
            {
                /*int*/ let depth = 0;
                while(o.parent !== null)
                {
                    depth++;
                    o = o.parent;
                }
                if ($.$is(o, $.$spxl.System.Xml.Linq.XDocument))
                {
                    depth--;
                }
                return depth;
            }
            /*bool */ get EOF()
            {
                return this._state === 3/*ReadState.EndOfFile*/;
            }
            /*bool */ get HasAttributes()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null && e.lastAttr !== null)
                {
                    if (this._omitDuplicateNamespaces)
                    {
                        return this.GetFirstNonDuplicateNamespaceAttribute(e.lastAttr.next) !== null;
                    }
                    else 
                    {
                        return true;
                    }
                }
                else 
                {
                    return false;
                }
            }
            /*bool */ get HasValue()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    let $switch1 = o.NodeType;
                    switch($switch1)
                    {
                        case 2/*XmlNodeType.Attribute*/:
                        case 3/*XmlNodeType.Text*/:
                        case 4/*XmlNodeType.CDATA*/:
                        case 8/*XmlNodeType.Comment*/:
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        case 10/*XmlNodeType.DocumentType*/:
                        return true;
                        default:
                        return false;
                    }
                }
                return true;
            }
            /*bool */ get IsEmptyElement()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                return e !== null && e.IsEmpty;
            }
            /*string */ get LocalName()
            {
                return this._nameTable.Add$1(this.GetLocalName());
            }
            /*string */ GetLocalName()
            {
                if (!this.IsInteractive)
                {
                    return $.$$.System.String.Empty;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.LocalName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return a.Name.LocalName;
                }
                /*XProcessingInstruction?*/ let p = $.$as(this._source, $.$spxl.System.Xml.Linq.XProcessingInstruction);
                if (p !== null)
                {
                    return p.Target;
                }
                /*XDocumentType?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XDocumentType);
                if (n !== null)
                {
                    return n.Name;
                }
                return $.$$.System.String.Empty;
            }
            /*string */ get Name()
            {
                /*string*/ let prefix = this.GetPrefix();
                if (prefix.length === 0)
                {
                    return this._nameTable.Add$1(this.GetLocalName());
                }
                return this._nameTable.Add$1($.$$.System.String.Concat$12(prefix, ":", this.GetLocalName()));
            }
            /*string */ get NamespaceURI()
            {
                return this._nameTable.Add$1(this.GetNamespaceURI());
            }
            /*string */ GetNamespaceURI()
            {
                if (!this.IsInteractive)
                {
                    return $.$$.System.String.Empty;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.NamespaceName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    /*string*/ let namespaceName = a.Name.NamespaceName;
                    if (namespaceName.length === 0 && $.$$.System.String.op_Equality(a.Name.LocalName, "xmlns"))
                    {
                        return "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/;
                    }
                    return namespaceName;
                }
                return $.$$.System.String.Empty;
            }
            /*XmlNameTable */ get NameTable()
            {
                return this._nameTable;
            }
            /*XmlNodeType */ get NodeType()
            {
                if (!this.IsInteractive)
                {
                    return 0/*XmlNodeType.None*/;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    if (this.IsEndElement)
                    {
                        return 15/*XmlNodeType.EndElement*/;
                    }
                    /*XmlNodeType*/ let nt = o.NodeType;
                    if (nt !== 3/*XmlNodeType.Text*/)
                    {
                        return nt;
                    }
                    if (o.parent !== null && o.parent.parent === null && $.$is(o.parent, $.$spxl.System.Xml.Linq.XDocument))
                    {
                        return 13/*XmlNodeType.Whitespace*/;
                    }
                    return 3/*XmlNodeType.Text*/;
                }
                if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XDocument))
                {
                    return 13/*XmlNodeType.Whitespace*/;
                }
                return 3/*XmlNodeType.Text*/;
            }
            /*string */ get Prefix()
            {
                return this._nameTable.Add$1(this.GetPrefix());
            }
            /*string */ GetPrefix()
            {
                if (!this.IsInteractive)
                {
                    return $.$$.System.String.Empty;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    /*string?*/ let prefix = e.GetPrefixOfNamespace(e.Name.Namespace);
                    if ($.$$.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                    return $.$$.System.String.Empty;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    /*string?*/ let prefix = a.GetPrefixOfNamespace(a.Name.Namespace);
                    if ($.$$.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                }
                return $.$$.System.String.Empty;
            }
            /*ReadState */ get ReadState()
            {
                return this._state;
            }
            /*XmlReaderSettings */ get Settings()
            {
                /*XmlReaderSettings*/ let settings = new $.$spx.System.Xml.XmlReaderSettings().$ctor$1();
                settings.CheckCharacters = false;
                return settings;
            }
            /*string */ get Value()
            {
                if (!this.IsInteractive)
                {
                    return $.$$.System.String.Empty;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    let $switch1 = o.NodeType;
                    switch($switch1)
                    {
                        case 2/*XmlNodeType.Attribute*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XAttribute)).Value;
                        case 3/*XmlNodeType.Text*/:
                        case 4/*XmlNodeType.CDATA*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XText)).Value;
                        case 8/*XmlNodeType.Comment*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XComment)).Value;
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XProcessingInstruction)).Data;
                        case 10/*XmlNodeType.DocumentType*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XDocumentType)).InternalSubset ?? $.$$.System.String.Empty;
                        default:
                        return $.$$.System.String.Empty;
                    }
                }
                return $.$cast(this._source, $.$$.System.String);
            }
            /*string */ get XmlLang()
            {
                if (!this.IsInteractive)
                {
                    return $.$$.System.String.Empty;
                }
                /*XElement?*/ let e = this.GetElementInScope();
                if (e !== null)
                {
                    /*XName*/ let name = $.$spxl.System.Xml.Linq.XNamespace.Xml.GetName$1("lang");
                    do
                    {
                        /*XAttribute?*/ let a = e.Attribute(name);
                        if (a !== null)
                        {
                            return a.Value;
                        }
                        e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    }
                    while(e !== null);
                }
                return $.$$.System.String.Empty;
            }
            /*XmlSpace */ get XmlSpace()
            {
                if (!this.IsInteractive)
                {
                    return 0/*XmlSpace.None*/;
                }
                /*XElement?*/ let e = this.GetElementInScope();
                if (e !== null)
                {
                    /*XName*/ let name = $.$spxl.System.Xml.Linq.XNamespace.Xml.GetName$1("space");
                    do
                    {
                        /*XAttribute?*/ let a = e.Attribute(name);
                        if (a !== null)
                        {
                            let $switch1 = $.$$.System.MemoryExtensions.Trim$3($.$$.System.MemoryExtensions.AsSpan$4(a.Value), $.$$.System.String.op_Implicit(" \t\n\r"));
                            switch($switch1)
                            {
                                case "preserve":
                                return 2/*XmlSpace.Preserve*/;
                                case $.$default():
                                return 1/*XmlSpace.Default*/;
                                default:
                                break;
                            }
                        }
                        e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    }
                    while(e !== null);
                }
                return 0/*XmlSpace.None*/;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing && this.ReadState !== 4/*ReadState.Closed*/)
                {
                    this.Close();
                }
            }
            /*void */ Close()
            {
                this._source = null;
                this._parent = null;
                this._root = null;
                this._state = 4/*ReadState.Closed*/;
            }
            /*string? */ GetAttribute$2(/*string*/ name)
            {
                if (!this.IsInteractive)
                {
                    return null;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*string?*/ let localName, namespaceName;
                    $.$spxl.System.Xml.Linq.XNodeReader.GetNameInAttributeScope(name, e, $.$ref(() => localName, ($v) => localName = $v, $.$$.System.String), $.$ref(() => namespaceName, ($v) => namespaceName = $v, $.$$.System.String));
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$$.System.String.op_Equality(a.Name.LocalName, localName) && $.$$.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return null;
                                }
                                else 
                                {
                                    return a.Value;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                    return null;
                }
                /*XDocumentType?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XDocumentType);
                if (n !== null)
                {
                    switch(name)
                    {
                        case "PUBLIC":
                        return n.PublicId;
                        case "SYSTEM":
                        return n.SystemId;
                    }
                }
                return null;
            }
            /*string? */ GetAttribute$1(/*string*/ localName, /*string?*/ namespaceName)
            {
                if (!this.IsInteractive)
                {
                    return null;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    if ($.$$.System.String.op_Equality(localName, "xmlns"))
                    {
                        if ($.$$.System.String.op_Inequality(namespaceName, null) && namespaceName.length === 0)
                        {
                            return null;
                        }
                        if ($.$$.System.String.op_Equality(namespaceName, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                        {
                            namespaceName = $.$$.System.String.Empty;
                        }
                    }
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$$.System.String.op_Equality(a.Name.LocalName, localName) && $.$$.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return null;
                                }
                                else 
                                {
                                    return a.Value;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return null;
            }
            /*string */ GetAttribute(/*int*/ index)
            {
                if (!this.IsInteractive)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (!this._omitDuplicateNamespaces || !this.IsDuplicateNamespaceAttribute(a))
                            {
                                if (index-- === 0)
                                {
                                    return a.Value;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("index");
            }
            /*string? */ LookupNamespace(/*string*/ prefix)
            {
                if (!this.IsInteractive)
                {
                    return null;
                }
                if ($.$$.System.String.op_Equality(prefix, null))
                {
                    return null;
                }
                /*XElement?*/ let e = this.GetElementInScope();
                if (e !== null)
                {
                    /*XNamespace?*/ let ns = prefix.length === 0 ? e.GetDefaultNamespace() : e.GetNamespaceOfPrefix(prefix);
                    if ($.$spxl.System.Xml.Linq.XNamespace.op_Inequality(ns, null))
                    {
                        return this._nameTable.Add$1(ns.NamespaceName);
                    }
                }
                return null;
            }
            /*bool */ MoveToAttribute$2(/*string*/ name)
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*string?*/ let localName, namespaceName;
                    $.$spxl.System.Xml.Linq.XNodeReader.GetNameInAttributeScope(name, e, $.$ref(() => localName, ($v) => localName = $v, $.$$.System.String), $.$ref(() => namespaceName, ($v) => namespaceName = $v, $.$$.System.String));
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$$.System.String.op_Equality(a.Name.LocalName, localName) && $.$$.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return false;
                                }
                                else 
                                {
                                    this._source = a;
                                    this._parent = null;
                                    return true;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return false;
            }
            /*bool */ MoveToAttribute$1(/*string*/ localName, /*string?*/ namespaceName)
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    if ($.$$.System.String.op_Equality(localName, "xmlns"))
                    {
                        if ($.$$.System.String.op_Inequality(namespaceName, null) && namespaceName.length === 0)
                        {
                            return false;
                        }
                        if ($.$$.System.String.op_Equality(namespaceName, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                        {
                            namespaceName = $.$$.System.String.Empty;
                        }
                    }
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$$.System.String.op_Equality(a.Name.LocalName, localName) && $.$$.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return false;
                                }
                                else 
                                {
                                    this._source = a;
                                    this._parent = null;
                                    return true;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return false;
            }
            /*void */ MoveToAttribute(/*int*/ index)
            {
                if (!this.IsInteractive)
                {
                    return;
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (!this._omitDuplicateNamespaces || !this.IsDuplicateNamespaceAttribute(a))
                            {
                                if (index-- === 0)
                                {
                                    this._source = a;
                                    this._parent = null;
                                    return;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("index");
            }
            /*bool */ MoveToElement()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute) ?? $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (a.parent !== null)
                    {
                        this._source = a.parent;
                        this._parent = null;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToFirstAttribute()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    if (e.lastAttr !== null)
                    {
                        if (this._omitDuplicateNamespaces)
                        {
                            /*object?*/ let na = this.GetFirstNonDuplicateNamespaceAttribute(e.lastAttr.next);
                            if (na === null)
                            {
                                return false;
                            }
                            this._source = na;
                        }
                        else 
                        {
                            this._source = e.lastAttr.next;
                        }
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToNextAttribute()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (this.IsEndElement)
                    {
                        return false;
                    }
                    if (e.lastAttr !== null)
                    {
                        if (this._omitDuplicateNamespaces)
                        {
                            /*object?*/ let na = this.GetFirstNonDuplicateNamespaceAttribute(e.lastAttr.next);
                            if (na === null)
                            {
                                return false;
                            }
                            this._source = na;
                        }
                        else 
                        {
                            this._source = e.lastAttr.next;
                        }
                        return true;
                    }
                    return false;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute) ?? $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (a.parent !== null && ($.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr !== a)
                    {
                        if (this._omitDuplicateNamespaces)
                        {
                            /*object?*/ let na = this.GetFirstNonDuplicateNamespaceAttribute(a.next);
                            if (na === null)
                            {
                                return false;
                            }
                            this._source = na;
                        }
                        else 
                        {
                            this._source = a.next;
                        }
                        this._parent = null;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ Read()
            {
                switch(this._state)
                {
                    case 0/*ReadState.Initial*/:
                    this._state = 1/*ReadState.Interactive*/;
                    /*XDocument?*/ let d = $.$as(this._source, $.$spxl.System.Xml.Linq.XDocument);
                    if (d !== null)
                    {
                        return this.ReadIntoDocument(d);
                    }
                    return true;
                    case 1/*ReadState.Interactive*/:
                    return this.Read$1(false);
                    default:
                    return false;
                }
            }
            /*bool */ ReadAttributeValue()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return this.ReadIntoAttribute(a);
                }
                return false;
            }
            /*bool */ ReadToDescendant(/*string*/ localName, /*string*/ namespaceName)
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                this.MoveToElement();
                /*XElement?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (c !== null && !c.IsEmpty)
                {
                    if (this.IsEndElement)
                    {
                        return false;
                    }
                    var $en3 = c.Descendants().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var e = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$$.System.String.op_Equality(e.Name.LocalName, localName) && $.$$.System.String.op_Equality(e.Name.NamespaceName, namespaceName))
                            {
                                this._source = e;
                                return true;
                            }
                        }
                    }
                    this.IsEndElement = true;
                }
                return false;
            }
            /*bool */ ReadToFollowing(/*string*/ localName, /*string*/ namespaceName)
            {
                while(this.Read())
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        if (this.IsEndElement)
                        {
                            continue;
                        }
                        if ($.$$.System.String.op_Equality(e.Name.LocalName, localName) && $.$$.System.String.op_Equality(e.Name.NamespaceName, namespaceName))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*bool */ ReadToNextSibling(/*string*/ localName, /*string*/ namespaceName)
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                this.MoveToElement();
                if (this._source !== this._root)
                {
                    /*XNode?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                    if (n !== null)
                    {
                        var $en4 = n.ElementsAfterSelf().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var e = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if ($.$$.System.String.op_Equality(e.Name.LocalName, localName) && $.$$.System.String.op_Equality(e.Name.NamespaceName, namespaceName))
                                {
                                    this._source = e;
                                    this.IsEndElement = false;
                                    return true;
                                }
                            }
                        }
                        if ($.$is(n.parent, $.$spxl.System.Xml.Linq.XElement))
                        {
                            this._source = n.parent;
                            this.IsEndElement = true;
                            return false;
                        }
                    }
                    else 
                    {
                        if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XElement))
                        {
                            this._source = this._parent;
                            this._parent = null;
                            this.IsEndElement = true;
                            return false;
                        }
                    }
                }
                return this.ReadToEnd();
            }
            /*void */ ResolveEntity()
            {
            }
            /*void */ Skip()
            {
                if (!this.IsInteractive)
                {
                    return;
                }
                this.Read$1(true);
            }
            /*bool */ System$Xml$IXmlLineInfo$HasLineInfo()
            {
                if (this.IsEndElement)
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        return e.Annotation$1($.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation) !== null;
                    }
                }
                else 
                {
                    /*IXmlLineInfo?*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null)
                    {
                        return li.System$Xml$IXmlLineInfo$HasLineInfo();
                    }
                }
                return false;
            }
            /*int */ get System$Xml$IXmlLineInfo$LineNumber()
            {
                if (this.IsEndElement)
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        /*LineInfoEndElementAnnotation?*/ let a = e.Annotation$1($.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation);
                        if (a !== null)
                        {
                            return a.lineNumber;
                        }
                    }
                }
                else 
                {
                    /*IXmlLineInfo?*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null)
                    {
                        return li.System$Xml$IXmlLineInfo$LineNumber;
                    }
                }
                return 0;
            }
            /*int */ get System$Xml$IXmlLineInfo$LinePosition()
            {
                if (this.IsEndElement)
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        /*LineInfoEndElementAnnotation?*/ let a = e.Annotation$1($.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation);
                        if (a !== null)
                        {
                            return a.linePosition;
                        }
                    }
                }
                else 
                {
                    /*IXmlLineInfo?*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null)
                    {
                        return li.System$Xml$IXmlLineInfo$LinePosition;
                    }
                }
                return 0;
            }
            /*bool */ get IsEndElement()
            {
                return this._parent === this._source;
            }
            /*bool */ set IsEndElement(value)
            {
                this._parent = value ? this._source : null;
            }
            /*bool */ get IsInteractive()
            {
                return this._state === 1/*ReadState.Interactive*/;
            }
            static /*NameTable */ CreateNameTable()
            {
                /*var*/ let nameTable = new $.$spx.System.Xml.NameTable().$ctor$2();
                nameTable.Add$1($.$$.System.String.Empty);
                nameTable.Add$1("http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/);
                nameTable.Add$1("http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/);
                return nameTable;
            }
            /*XElement? */ GetElementInAttributeScope()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (this.IsEndElement)
                    {
                        return null;
                    }
                    return e;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                a = $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return null;
            }
            /*XElement? */ GetElementInScope()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e;
                }
                /*XNode?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    return $.$as(n.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                e = $.$as(this._parent, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e;
                }
                a = $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return null;
            }
            static /*void */ GetNameInAttributeScope(/*string?*/ qualifiedName, /*XElement*/ e, /*out string?*/ localName, /*out string?*/ namespaceName)
            {
                if (!$.$$.System.String.IsNullOrEmpty(qualifiedName))
                {
                    /*int*/ let i = $.$$.System.String.IndexOf$3.call(qualifiedName, /*:*/ 58);
                    if (i !== 0 && i !== ((qualifiedName.length - 1) | 0))
                    {
                        if (i === -1)
                        {
                            localName.$v = qualifiedName;
                            namespaceName.$v = $.$$.System.String.Empty;
                            return;
                        }
                        /*XNamespace?*/ let ns = e.GetNamespaceOfPrefix($.$$.System.String.Substring.call(qualifiedName, 0, i));
                        if ($.$spxl.System.Xml.Linq.XNamespace.op_Inequality(ns, null))
                        {
                            localName.$v = $.$$.System.String.Substring$1.call(qualifiedName, ((i + 1) | 0));
                            namespaceName.$v = ns.NamespaceName;
                            return;
                        }
                    }
                }
                localName.$v = null;
                namespaceName.$v = null;
            }
            /*bool */ Read$1(/*bool*/ skipContent)
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (e.IsEmpty || this.IsEndElement || skipContent)
                    {
                        return this.ReadOverNode(e);
                    }
                    return this.ReadIntoElement(e);
                }
                /*XNode?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    return this.ReadOverNode(n);
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return this.ReadOverAttribute(a, skipContent);
                }
                return this.ReadOverText(skipContent);
            }
            /*bool */ ReadIntoDocument(/*XDocument*/ d)
            {
                /*XNode?*/ let n = $.$as(d.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this._source = n.next;
                    return true;
                }
                /*string?*/ let s = $.$as(d.content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    if (s.length > 0)
                    {
                        this._source = s;
                        this._parent = d;
                        return true;
                    }
                }
                return this.ReadToEnd();
            }
            /*bool */ ReadIntoElement(/*XElement*/ e)
            {
                /*XNode?*/ let n = $.$as(e.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this._source = n.next;
                    return true;
                }
                /*string?*/ let s = $.$as(e.content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    if (s.length > 0)
                    {
                        this._source = s;
                        this._parent = e;
                    }
                    else 
                    {
                        this._source = e;
                        this.IsEndElement = true;
                    }
                    return true;
                }
                return this.ReadToEnd();
            }
            /*bool */ ReadIntoAttribute(/*XAttribute*/ a)
            {
                this._source = a.value;
                this._parent = a;
                return true;
            }
            /*bool */ ReadOverAttribute(/*XAttribute*/ a, /*bool*/ skipContent)
            {
                /*XElement?*/ let e = $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (e.IsEmpty || skipContent)
                    {
                        return this.ReadOverNode(e);
                    }
                    return this.ReadIntoElement(e);
                }
                return this.ReadToEnd();
            }
            /*bool */ ReadOverNode(/*XNode*/ n)
            {
                if (n === this._root)
                {
                    return this.ReadToEnd();
                }
                /*XNode?*/ let next = n.next;
                if (null === next || next === n || n === n.parent.content)
                {
                    if (n.parent === null || (n.parent.parent === null && $.$is(n.parent, $.$spxl.System.Xml.Linq.XDocument)))
                    {
                        return this.ReadToEnd();
                    }
                    this._source = n.parent;
                    this.IsEndElement = true;
                }
                else 
                {
                    this._source = next;
                    this.IsEndElement = false;
                }
                return true;
            }
            /*bool */ ReadOverText(/*bool*/ skipContent)
            {
                if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XElement))
                {
                    this._source = this._parent;
                    this._parent = null;
                    this.IsEndElement = true;
                    return true;
                }
                /*XAttribute?*/ let parent = $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (parent !== null)
                {
                    this._parent = null;
                    return this.ReadOverAttribute(parent, skipContent);
                }
                return this.ReadToEnd();
            }
            /*bool */ ReadToEnd()
            {
                this._state = 3/*ReadState.EndOfFile*/;
                return false;
            }
            /*bool */ IsDuplicateNamespaceAttribute(/*XAttribute*/ candidateAttribute)
            {
                if (!candidateAttribute.IsNamespaceDeclaration)
                {
                    return false;
                }
                else 
                {
                    return this.IsDuplicateNamespaceAttributeInner(candidateAttribute);
                }
            }
            /*bool */ IsDuplicateNamespaceAttributeInner(/*XAttribute*/ candidateAttribute)
            {
                if ($.$$.System.String.op_Equality(candidateAttribute.Name.LocalName, "xml"))
                {
                    return true;
                }
                /*XElement?*/ let element = $.$as(candidateAttribute.parent, $.$spxl.System.Xml.Linq.XElement);
                if (element === this._root || element === null)
                {
                    return false;
                }
                element = $.$as(element.parent, $.$spxl.System.Xml.Linq.XElement);
                while(element !== null)
                {
                    /*XAttribute?*/ let a = element.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            if ($.$spxl.System.Xml.Linq.XName.op_Equality(a.name, candidateAttribute.name))
                            {
                                if ($.$$.System.String.op_Equality(a.Value, candidateAttribute.Value))
                                {
                                    return true;
                                }
                                else 
                                {
                                    return false;
                                }
                            }
                            a = a.next;
                        }
                        while(a !== element.lastAttr);
                    }
                    if (element === this._root)
                    {
                        return false;
                    }
                    element = $.$as(element.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return false;
            }
            /*XAttribute? */ GetFirstNonDuplicateNamespaceAttribute(/*XAttribute*/ candidate)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._omitDuplicateNamespaces, "This method should only be called if we're omitting duplicate namespace attribute. For perf reason it's better to test this flag in the caller method.");
                if (!this.IsDuplicateNamespaceAttribute(candidate))
                {
                    return candidate;
                }
                /*XElement?*/ let e = $.$as(candidate.parent, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null && candidate !== e.lastAttr)
                {
                    do
                    {
                        candidate = candidate.next;
                        if (!this.IsDuplicateNamespaceAttribute(candidate))
                        {
                            return candidate;
                        }
                    }
                    while(candidate !== e.lastAttr);
                }
                return null;
            }
            static $h = 2549712;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":53394070,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42952222672,"f":50364417},"n":"AttributeCount","d":2549712,"h":38657255376,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":51542157264,"f":50364417},"n":"BaseURI","d":2549712,"h":47247189968,"f":2129921},{"p":655361,"g":{"r":0,"d":0,"h":60132091856,"f":50364417},"n":"Depth","d":2549712,"h":55837124560,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":73016993744,"f":50364417},"n":"EOF","d":2549712,"h":68722026448,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":81606928336,"f":50364417},"n":"HasAttributes","d":2549712,"h":77311961040,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":90196862928,"f":50364417},"n":"HasValue","d":2549712,"h":85901895632,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":98786797520,"f":50364417},"n":"IsEmptyElement","d":2549712,"h":94491830224,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":107376732112,"f":50364417},"n":"LocalName","d":2549712,"h":103081764816,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":120261634000,"f":50364417},"n":"Name","d":2549712,"h":115966666704,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":128851568592,"f":50364417},"n":"NamespaceURI","d":2549712,"h":124556601296,"f":2129921},{"p":52083350,"g":{"r":0,"d":0,"h":141736470480,"f":50364417},"n":"NameTable","d":2549712,"h":137441503184,"f":2129921},{"p":52869782,"g":{"r":0,"d":0,"h":150326405072,"f":50364417},"n":"NodeType","d":2549712,"h":146031437776,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":158916339664,"f":50364417},"n":"Prefix","d":2549712,"h":154621372368,"f":2129921},{"p":14924438,"g":{"r":0,"d":0,"h":171801241552,"f":50364417},"n":"ReadState","d":2549712,"h":167506274256,"f":2129921},{"p":53525142,"g":{"r":0,"d":0,"h":180391176144,"f":50364417},"n":"Settings","d":2549712,"h":176096208848,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":188981110736,"f":50364417},"n":"Value","d":2549712,"h":184686143440,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":197571045328,"f":50364417},"n":"XmlLang","d":2549712,"h":193276078032,"f":2129921},{"p":54049430,"g":{"r":0,"d":0,"h":206160979920,"f":50364417},"n":"XmlSpace","d":2549712,"h":201866012624,"f":2129921},{"p":655361,"g":{"r":0,"d":0,"h":300650260432,"f":50331650},"n":"{13941398}.LineNumber","o":"System$Xml$IXmlLineInfo$LineNumber","d":2549712,"h":296355293136,"f":2097154},{"p":655361,"g":{"r":0,"d":0,"h":309240195024,"f":50331650},"n":"{13941398}.LinePosition","o":"System$Xml$IXmlLineInfo$LinePosition","d":2549712,"h":304945227728,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":317830129616,"f":50331650},"s":{"r":0,"d":0,"h":322125096912,"f":83886082},"n":"IsEndElement","d":2549712,"h":313535162320,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":330715031504,"f":50331650},"n":"IsInteractive","d":2549712,"h":326420064208,"f":2097154}],"m":[{"r":655361,"p":[{"n":"o","p":2615248}],"n":"GetDepth","d":2549712,"h":64427059152,"f":16777250},{"r":1310721,"n":"GetLocalName","d":2549712,"h":111671699408,"f":16777218},{"r":1310721,"n":"GetNamespaceURI","d":2549712,"h":133146535888,"f":16777218},{"r":1310721,"n":"GetPrefix","d":2549712,"h":163211306960,"f":16777218},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":2549712,"h":210455947216,"f":16809988},{"r":65537,"n":"Close","d":2549712,"h":214750914512,"f":16809985},{"r":1310721,"p":[{"n":"name","p":1310721}],"n":"GetAttribute","o":"@$2","d":2549712,"h":219045881808,"f":16809985},{"r":1310721,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"GetAttribute","o":"@$1","d":2549712,"h":223340849104,"f":16809985},{"r":1310721,"p":[{"n":"index","p":655361}],"n":"GetAttribute","d":2549712,"h":227635816400,"f":16809985},{"r":1310721,"p":[{"n":"prefix","p":1310721}],"n":"LookupNamespace","d":2549712,"h":231930783696,"f":16809985},{"r":262145,"p":[{"n":"name","p":1310721}],"n":"MoveToAttribute","o":"@$2","d":2549712,"h":236225750992,"f":16809985},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"MoveToAttribute","o":"@$1","d":2549712,"h":240520718288,"f":16809985},{"r":65537,"p":[{"n":"index","p":655361}],"n":"MoveToAttribute","d":2549712,"h":244815685584,"f":16809985},{"r":262145,"n":"MoveToElement","d":2549712,"h":249110652880,"f":16809985},{"r":262145,"n":"MoveToFirstAttribute","d":2549712,"h":253405620176,"f":16809985},{"r":262145,"n":"MoveToNextAttribute","d":2549712,"h":257700587472,"f":16809985},{"r":262145,"n":"Read","d":2549712,"h":261995554768,"f":16809985},{"r":262145,"n":"ReadAttributeValue","d":2549712,"h":266290522064,"f":16809985},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"ReadToDescendant","d":2549712,"h":270585489360,"f":16809985},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"ReadToFollowing","d":2549712,"h":274880456656,"f":16809985},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"ReadToNextSibling","d":2549712,"h":279175423952,"f":16809985},{"r":65537,"n":"ResolveEntity","d":2549712,"h":283470391248,"f":16809985},{"r":65537,"n":"Skip","d":2549712,"h":287765358544,"f":16809985},{"r":14269078,"n":"CreateNameTable","d":2549712,"h":335009998800,"f":16777250},{"r":1697744,"n":"GetElementInAttributeScope","d":2549712,"h":339304966096,"f":16777218},{"r":1697744,"n":"GetElementInScope","d":2549712,"h":343599933392,"f":16777218},{"r":65537,"p":[{"n":"qualifiedName","p":1310721},{"n":"e","p":1697744},{"n":"localName","p":1310721,"f":2},{"n":"namespaceName","p":1310721,"f":2}],"n":"GetNameInAttributeScope","d":2549712,"h":347894900688,"f":16777250},{"r":262145,"p":[{"n":"skipContent","p":262145}],"n":"Read","o":"@$1","d":2549712,"h":352189867984,"f":16777218},{"r":262145,"p":[{"n":"d","p":1566672}],"n":"ReadIntoDocument","d":2549712,"h":356484835280,"f":16777218},{"r":262145,"p":[{"n":"e","p":1697744}],"n":"ReadIntoElement","d":2549712,"h":360779802576,"f":16777218},{"r":262145,"p":[{"n":"a","p":1173456}],"n":"ReadIntoAttribute","d":2549712,"h":365074769872,"f":16777218},{"r":262145,"p":[{"n":"a","p":1173456},{"n":"skipContent","p":262145}],"n":"ReadOverAttribute","d":2549712,"h":369369737168,"f":16777218},{"r":262145,"p":[{"n":"n","p":2287568}],"n":"ReadOverNode","d":2549712,"h":373664704464,"f":16777218},{"r":262145,"p":[{"n":"skipContent","p":262145}],"n":"ReadOverText","d":2549712,"h":377959671760,"f":16777218},{"r":262145,"n":"ReadToEnd","d":2549712,"h":382254639056,"f":16777218},{"r":262145,"p":[{"n":"candidateAttribute","p":1173456}],"n":"IsDuplicateNamespaceAttribute","d":2549712,"h":386549606352,"f":16777218},{"r":262145,"p":[{"n":"candidateAttribute","p":1173456}],"n":"IsDuplicateNamespaceAttributeInner","d":2549712,"h":390844573648,"f":16777218},{"r":1173456,"p":[{"n":"candidate","p":1173456}],"n":"GetFirstNonDuplicateNamespaceAttribute","d":2549712,"h":395139540944,"f":16777218}],"l":[{"t":131073,"n":"_source","d":2549712,"h":4297517008,"f":4194306},{"t":131073,"n":"_parent","d":2549712,"h":8592484304,"f":4194306},{"t":14924438,"n":"_state","d":2549712,"h":12887451600,"f":4194306},{"t":2287568,"n":"_root","d":2549712,"h":17182418896,"f":4194306},{"t":52083350,"n":"_nameTable","d":2549712,"h":21477386192,"f":4194306},{"t":262145,"n":"_omitDuplicateNamespaces","d":2549712,"h":25772353488,"f":4194306}],"c":[{"p":[{"n":"node","p":2287568},{"n":"nameTable","p":52083350},{"n":"options","p":976848}],"n":".ctor","o":"$ctor$2","d":2549712,"h":30067320784,"f":16777224},{"p":[{"n":"node","p":2287568},{"n":"nameTable","p":52083350}],"n":".ctor","o":"$ctor$3","d":2549712,"h":34362288080,"f":16777224}],"i":[57540609,13941398],"h":2549712}; }
            static get $b() { return $.$spx.System.Xml.XmlReader; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeReader`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XComment", ($self) => class XComment extends $.$spxl.System.Xml.Linq.XNode
        {
            /*string*/ value = null;
            $ctor$3(/*string*/ value)
            {
                super.$ctor$2();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                    this.value = value;
                }
                return this;
            }
            $ctor$5(/*XComment*/ other)
            {
                super.$ctor$2();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this.value = other.value;
                }
                return this;
            }
            $ctor$4(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    this.value = r.Value;
                    r.Read();
                }
                return this;
            }
            /*XmlNodeType */ get NodeType()
            {
                return 8/*XmlNodeType.Comment*/;
            }
            /*string */ get Value()
            {
                return this.value;
            }
            /*string */ set Value(value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.value = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                writer.WriteComment(this.value);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return writer.WriteCommentAsync(this.value);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XComment().$ctor$5(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XComment?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XComment);
                return other !== null && $.$$.System.String.op_Equality(this.value, other.value);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$$.System.String.GetHashCode.call(this.value);
            }
            static $h = 1304528;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2287568,"p":[{"p":52869782,"g":{"r":0,"d":0,"h":25771108304,"f":50364417},"n":"NodeType","d":1304528,"h":21476141008,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":34361042896,"f":50331649},"s":{"r":0,"d":0,"h":38656010192,"f":83886081},"n":"Value","d":1304528,"h":30066075600,"f":2097153}],"m":[{"r":65537,"p":[{"n":"writer","p":58440342}],"n":"WriteTo","d":1304528,"h":42950977488,"f":16809985},{"r":133169153,"p":[{"n":"writer","p":58440342},{"n":"cancellationToken","p":125829121}],"n":"WriteToAsync","d":1304528,"h":47245944784,"f":16809985},{"r":2287568,"n":"CloneNode","d":1304528,"h":51540912080,"f":16809992},{"r":262145,"p":[{"n":"node","p":2287568}],"n":"DeepEquals","o":"@$1","d":1304528,"h":55835879376,"f":16809992},{"r":655361,"n":"GetDeepHashCode","d":1304528,"h":60130846672,"f":16809992}],"l":[{"t":1310721,"n":"value","d":1304528,"h":4296271824,"f":4194312}],"c":[{"p":[{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$3","d":1304528,"h":8591239120,"f":16777217},{"p":[{"n":"other","p":1304528}],"n":".ctor","o":"$ctor$5","d":1304528,"h":12886206416,"f":16777217},{"p":[{"n":"r","p":53394070}],"n":".ctor","o":"$ctor$4","d":1304528,"h":17181173712,"f":16777224}],"i":[13941398],"h":1304528}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XComment`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XDocumentType", ($self) => class XDocumentType extends $.$spxl.System.Xml.Linq.XNode
        {
            /*string*/ _name = null;
            /*string?*/ _publicId = null;
            /*string?*/ _systemId = null;
            /*string?*/ _internalSubset = null;
            $ctor$3(/*string*/ name, /*string?*/ publicId, /*string?*/ systemId, /*string?*/ internalSubset)
            {
                super.$ctor$2();
                {
                    this._name = $.$spx.System.Xml.XmlConvert.VerifyName(name);
                    this._publicId = publicId;
                    this._systemId = systemId;
                    this._internalSubset = internalSubset;
                }
                return this;
            }
            $ctor$5(/*XDocumentType*/ other)
            {
                super.$ctor$2();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this._name = other._name;
                    this._publicId = other._publicId;
                    this._systemId = other._systemId;
                    this._internalSubset = other._internalSubset;
                }
                return this;
            }
            $ctor$4(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    this._name = r.Name;
                    this._publicId = r.GetAttribute$2("PUBLIC");
                    this._systemId = r.GetAttribute$2("SYSTEM");
                    this._internalSubset = r.Value;
                    r.Read();
                }
                return this;
            }
            /*string? */ get InternalSubset()
            {
                return this._internalSubset;
            }
            /*string? */ set InternalSubset(value)
            {
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this._internalSubset = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*string */ get Name()
            {
                return this._name;
            }
            /*string */ set Name(value)
            {
                value = $.$spx.System.Xml.XmlConvert.VerifyName(value);
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                this._name = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                }
            }
            /*XmlNodeType */ get NodeType()
            {
                return 10/*XmlNodeType.DocumentType*/;
            }
            /*string? */ get PublicId()
            {
                return this._publicId;
            }
            /*string? */ set PublicId(value)
            {
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this._publicId = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*string? */ get SystemId()
            {
                return this._systemId;
            }
            /*string? */ set SystemId(value)
            {
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this._systemId = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                writer.WriteDocType(this._name, this._publicId, this._systemId, this._internalSubset);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return writer.WriteDocTypeAsync(this._name, this._publicId, this._systemId, this._internalSubset);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$5(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XDocumentType?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XDocumentType);
                return other !== null && $.$$.System.String.op_Equality(this._name, other._name) && $.$$.System.String.op_Equality(this._publicId, other._publicId) && $.$$.System.String.op_Equality(this._systemId, other.SystemId) && $.$$.System.String.op_Equality(this._internalSubset, other._internalSubset);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$$.System.String.GetHashCode.call(this._name) ^ ($.$$.System.String.op_Inequality(this._publicId, null) ? $.$$.System.String.GetHashCode.call(this._publicId) : 0) ^ ($.$$.System.String.op_Inequality(this._systemId, null) ? $.$$.System.String.GetHashCode.call(this._systemId) : 0) ^ ($.$$.System.String.op_Inequality(this._internalSubset, null) ? $.$$.System.String.GetHashCode.call(this._internalSubset) : 0);
            }
            static $h = 1632208;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2287568,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":38656337872,"f":50331649},"s":{"r":0,"d":0,"h":42951305168,"f":83886081},"n":"InternalSubset","d":1632208,"h":34361370576,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":51541239760,"f":50331649},"s":{"r":0,"d":0,"h":55836207056,"f":83886081},"n":"Name","d":1632208,"h":47246272464,"f":2097153},{"p":52869782,"g":{"r":0,"d":0,"h":64426141648,"f":50364417},"n":"NodeType","d":1632208,"h":60131174352,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":73016076240,"f":50331649},"s":{"r":0,"d":0,"h":77311043536,"f":83886081},"n":"PublicId","d":1632208,"h":68721108944,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":85900978128,"f":50331649},"s":{"r":0,"d":0,"h":90195945424,"f":83886081},"n":"SystemId","d":1632208,"h":81606010832,"f":2097153}],"m":[{"r":65537,"p":[{"n":"writer","p":58440342}],"n":"WriteTo","d":1632208,"h":94490912720,"f":16809985},{"r":133169153,"p":[{"n":"writer","p":58440342},{"n":"cancellationToken","p":125829121}],"n":"WriteToAsync","d":1632208,"h":98785880016,"f":16809985},{"r":2287568,"n":"CloneNode","d":1632208,"h":103080847312,"f":16809992},{"r":262145,"p":[{"n":"node","p":2287568}],"n":"DeepEquals","o":"@$1","d":1632208,"h":107375814608,"f":16809992},{"r":655361,"n":"GetDeepHashCode","d":1632208,"h":111670781904,"f":16809992}],"l":[{"t":1310721,"n":"_name","d":1632208,"h":4296599504,"f":4194306},{"t":1310721,"n":"_publicId","d":1632208,"h":8591566800,"f":4194306},{"t":1310721,"n":"_systemId","d":1632208,"h":12886534096,"f":4194306},{"t":1310721,"n":"_internalSubset","d":1632208,"h":17181501392,"f":4194306}],"c":[{"p":[{"n":"name","p":1310721},{"n":"publicId","p":1310721},{"n":"systemId","p":1310721},{"n":"internalSubset","p":1310721}],"n":".ctor","o":"$ctor$3","d":1632208,"h":21476468688,"f":16777217},{"p":[{"n":"other","p":1632208}],"n":".ctor","o":"$ctor$5","d":1632208,"h":25771435984,"f":16777217},{"p":[{"n":"r","p":53394070}],"n":".ctor","o":"$ctor$4","d":1632208,"h":30066403280,"f":16777224}],"i":[13941398],"h":1632208}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XDocumentType`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XText", ($self) => class XText extends $.$spxl.System.Xml.Linq.XNode
        {
            /*string*/ text = null;
            $ctor$3(/*string*/ value)
            {
                super.$ctor$2();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                    this.text = value;
                }
                return this;
            }
            $ctor$5(/*XText*/ other)
            {
                super.$ctor$2();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this.text = other.text;
                }
                return this;
            }
            $ctor$4(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    this.text = r.Value;
                    r.Read();
                }
                return this;
            }
            /*XmlNodeType */ get NodeType()
            {
                return 3/*XmlNodeType.Text*/;
            }
            /*string */ get Value()
            {
                return this.text;
            }
            /*string */ set Value(value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.text = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if ($.$is(this.parent, $.$spxl.System.Xml.Linq.XDocument))
                {
                    writer.WriteWhitespace(this.text);
                }
                else 
                {
                    writer.WriteString(this.text);
                }
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return $.$is(this.parent, $.$spxl.System.Xml.Linq.XDocument) ? writer.WriteWhitespaceAsync(this.text) : writer.WriteStringAsync(this.text);
            }
            /*void */ AppendText(/*StringBuilder*/ sb)
            {
                sb.Append$19(this.text);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XText().$ctor$5(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                return node !== null && this.NodeType === node.NodeType && $.$$.System.String.op_Equality(this.text, ($.$cast(node, $.$spxl.System.Xml.Linq.XText)).text);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$$.System.String.GetHashCode.call(this.text);
            }
            static $h = 3008464;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2287568,"p":[{"p":52869782,"g":{"r":0,"d":0,"h":25772812240,"f":50364417},"n":"NodeType","d":3008464,"h":21477844944,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":34362746832,"f":50331649},"s":{"r":0,"d":0,"h":38657714128,"f":83886081},"n":"Value","d":3008464,"h":30067779536,"f":2097153}],"m":[{"r":65537,"p":[{"n":"writer","p":58440342}],"n":"WriteTo","d":3008464,"h":42952681424,"f":16809985},{"r":133169153,"p":[{"n":"writer","p":58440342},{"n":"cancellationToken","p":125829121}],"n":"WriteToAsync","d":3008464,"h":47247648720,"f":16809985},{"r":65537,"p":[{"n":"sb","p":122814465}],"n":"AppendText","d":3008464,"h":51542616016,"f":16809992},{"r":2287568,"n":"CloneNode","d":3008464,"h":55837583312,"f":16809992},{"r":262145,"p":[{"n":"node","p":2287568}],"n":"DeepEquals","o":"@$1","d":3008464,"h":60132550608,"f":16809992},{"r":655361,"n":"GetDeepHashCode","d":3008464,"h":64427517904,"f":16809992}],"l":[{"t":1310721,"n":"text","d":3008464,"h":4297975760,"f":4194312}],"c":[{"p":[{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$3","d":3008464,"h":8592943056,"f":16777217},{"p":[{"n":"other","p":3008464}],"n":".ctor","o":"$ctor$5","d":3008464,"h":12887910352,"f":16777217},{"p":[{"n":"r","p":53394070}],"n":".ctor","o":"$ctor$4","d":3008464,"h":17182877648,"f":16777224}],"i":[13941398],"h":3008464}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XText`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XProcessingInstruction", ($self) => class XProcessingInstruction extends $.$spxl.System.Xml.Linq.XNode
        {
            /*string*/ target = null;
            /*string*/ data = null;
            $ctor$3(/*string*/ target, /*string*/ data)
            {
                super.$ctor$2();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(data, "data");
                    $.$spxl.System.Xml.Linq.XProcessingInstruction.ValidateName(target);
                    this.target = target;
                    this.data = data;
                }
                return this;
            }
            $ctor$5(/*XProcessingInstruction*/ other)
            {
                super.$ctor$2();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this.target = other.target;
                    this.data = other.data;
                }
                return this;
            }
            $ctor$4(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    this.target = r.Name;
                    this.data = r.Value;
                    r.Read();
                }
                return this;
            }
            /*string */ get Data()
            {
                return this.data;
            }
            /*string */ set Data(value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.data = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*XmlNodeType */ get NodeType()
            {
                return 7/*XmlNodeType.ProcessingInstruction*/;
            }
            /*string */ get Target()
            {
                return this.target;
            }
            /*string */ set Target(value)
            {
                $.$spxl.System.Xml.Linq.XProcessingInstruction.ValidateName(value);
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                this.target = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                writer.WriteProcessingInstruction(this.target, this.data);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return writer.WriteProcessingInstructionAsync(this.target, this.data);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$5(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XProcessingInstruction?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XProcessingInstruction);
                return other !== null && $.$$.System.String.op_Equality(this.target, other.target) && $.$$.System.String.op_Equality(this.data, other.data);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$$.System.String.GetHashCode.call(this.target) ^ $.$$.System.String.GetHashCode.call(this.data);
            }
            static /*void */ ValidateName(/*string*/ name)
            {
                $.$spx.System.Xml.XmlConvert.VerifyNCName$1(name);
                if ($.$$.System.String.Equals$2(name, "xml", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_InvalidPIName, name));
                }
            }
            static $h = 2877392;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2287568,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30067648464,"f":50331649},"s":{"r":0,"d":0,"h":34362615760,"f":83886081},"n":"Data","d":2877392,"h":25772681168,"f":2097153},{"p":52869782,"g":{"r":0,"d":0,"h":42952550352,"f":50364417},"n":"NodeType","d":2877392,"h":38657583056,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":51542484944,"f":50331649},"s":{"r":0,"d":0,"h":55837452240,"f":83886081},"n":"Target","d":2877392,"h":47247517648,"f":2097153}],"m":[{"r":65537,"p":[{"n":"writer","p":58440342}],"n":"WriteTo","d":2877392,"h":60132419536,"f":16809985},{"r":133169153,"p":[{"n":"writer","p":58440342},{"n":"cancellationToken","p":125829121}],"n":"WriteToAsync","d":2877392,"h":64427386832,"f":16809985},{"r":2287568,"n":"CloneNode","d":2877392,"h":68722354128,"f":16809992},{"r":262145,"p":[{"n":"node","p":2287568}],"n":"DeepEquals","o":"@$1","d":2877392,"h":73017321424,"f":16809992},{"r":655361,"n":"GetDeepHashCode","d":2877392,"h":77312288720,"f":16809992},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"ValidateName","d":2877392,"h":81607256016,"f":16777250}],"l":[{"t":1310721,"n":"target","d":2877392,"h":4297844688,"f":4194312},{"t":1310721,"n":"data","d":2877392,"h":8592811984,"f":4194312}],"c":[{"p":[{"n":"target","p":1310721},{"n":"data","p":1310721}],"n":".ctor","o":"$ctor$3","d":2877392,"h":12887779280,"f":16777217},{"p":[{"n":"other","p":2877392}],"n":".ctor","o":"$ctor$5","d":2877392,"h":17182746576,"f":16777217},{"p":[{"n":"r","p":53394070}],"n":".ctor","o":"$ctor$4","d":2877392,"h":21477713872,"f":16777224}],"i":[13941398],"h":2877392}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XProcessingInstruction`; }
        });
        
        $asm.$cls("$spxl.System.Xml.XPath.XNodeNavigator", ($self) => class XNodeNavigator extends $.$spx.System.Xml.XPath.XPathNavigator
        {
            /*string*/ static xmlPrefixNamespace = null;
            /*string*/ static xmlnsPrefixNamespace = null;
            /*int*/ static DocumentContentMask = 386;
            static /*ReadOnlySpan<int> */ get ElementContentMasks()
            {
                return this.$cacheElementContentMasks ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Int32))().$ctor$4([ 0, (1 << 1/*XmlNodeType.Element*/), 0, 0, (1 << 4/*XmlNodeType.CDATA*/) | (1 << 3/*XmlNodeType.Text*/), 0, 0, (1 << 7/*XmlNodeType.ProcessingInstruction*/), (1 << 8/*XmlNodeType.Comment*/), (1 << 1/*XmlNodeType.Element*/) | (1 << 4/*XmlNodeType.CDATA*/) | (1 << 3/*XmlNodeType.Text*/) | (1 << 7/*XmlNodeType.ProcessingInstruction*/) | (1 << 8/*XmlNodeType.Comment*/) ]);
            }
            /*int*/ static TextMask$1 = 24;
            /*XAttribute?*/ static s_XmlNamespaceDeclaration = null;
            /*XObject*/ _source = null;
            /*XElement?*/ _parent = null;
            /*XmlNameTable*/ _nameTable = null;
            $ctor$3(/*XNode*/ node, /*XmlNameTable?*/ nameTable)
            {
                super.$ctor$2();
                {
                    this._source = node;
                    this._nameTable = nameTable ?? $.$spxl.System.Xml.XPath.XNodeNavigator.CreateNameTable();
                }
                return this;
            }
            $ctor$4(/*XNodeNavigator*/ other)
            {
                super.$ctor$2();
                {
                    this._source = other._source;
                    this._parent = other._parent;
                    this._nameTable = other._nameTable;
                }
                return this;
            }
            /*string */ get BaseURI()
            {
                if (this._source !== null)
                {
                    return this._source.BaseUri;
                }
                if (this._parent !== null)
                {
                    return this._parent.BaseUri;
                }
                return $.$$.System.String.Empty;
            }
            /*bool */ get HasAttributes()
            {
                /*XElement?*/ let element = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (element !== null)
                {
                    var $en3 = element.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var attribute = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!attribute.IsNamespaceDeclaration)
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ get HasChildren()
            {
                /*XContainer?*/ let container = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (container !== null)
                {
                    var $en3 = container.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, node))
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ get IsEmptyElement()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                return e !== null && e.IsEmpty;
            }
            /*string */ get LocalName()
            {
                return this._nameTable.Add$1(this.GetLocalName());
            }
            /*string */ GetLocalName()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.LocalName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (this._parent !== null && a.Name.NamespaceName.length === 0)
                    {
                        return $.$$.System.String.Empty;
                    }
                    return a.Name.LocalName;
                }
                /*XProcessingInstruction?*/ let p = $.$as(this._source, $.$spxl.System.Xml.Linq.XProcessingInstruction);
                if (p !== null)
                {
                    return p.Target;
                }
                return $.$$.System.String.Empty;
            }
            /*string */ get Name()
            {
                /*string*/ let prefix = this.GetPrefix();
                if (prefix.length === 0)
                {
                    return this._nameTable.Add$1(this.GetLocalName());
                }
                return this._nameTable.Add$1($.$$.System.String.Concat$12(prefix, ":", this.GetLocalName()));
            }
            /*string */ get NamespaceURI()
            {
                return this._nameTable.Add$1(this.GetNamespaceURI());
            }
            /*string */ GetNamespaceURI()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.NamespaceName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (this._parent !== null)
                    {
                        return $.$$.System.String.Empty;
                    }
                    return a.Name.NamespaceName;
                }
                return $.$$.System.String.Empty;
            }
            /*XmlNameTable */ get NameTable()
            {
                return this._nameTable;
            }
            /*XPathNodeType */ get NodeType()
            {
                if (this._source !== null)
                {
                    let $switch1 = this._source.NodeType;
                    switch($switch1)
                    {
                        case 1/*XmlNodeType.Element*/:
                        return 1/*XPathNodeType.Element*/;
                        case 2/*XmlNodeType.Attribute*/:
                        /*XAttribute*/ let attribute = $.$cast(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                        return attribute.IsNamespaceDeclaration ? 3/*XPathNodeType.Namespace*/ : 2/*XPathNodeType.Attribute*/;
                        case 9/*XmlNodeType.Document*/:
                        return 0/*XPathNodeType.Root*/;
                        case 8/*XmlNodeType.Comment*/:
                        return 8/*XPathNodeType.Comment*/;
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        return 7/*XPathNodeType.ProcessingInstruction*/;
                        default:
                        return 4/*XPathNodeType.Text*/;
                    }
                }
                return 4/*XPathNodeType.Text*/;
            }
            /*string */ get Prefix()
            {
                return this._nameTable.Add$1(this.GetPrefix());
            }
            /*string */ GetPrefix()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    /*string?*/ let prefix = e.GetPrefixOfNamespace(e.Name.Namespace);
                    if ($.$$.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                    return $.$$.System.String.Empty;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (this._parent !== null)
                    {
                        return $.$$.System.String.Empty;
                    }
                    /*string?*/ let prefix = a.GetPrefixOfNamespace(a.Name.Namespace);
                    if ($.$$.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                }
                return $.$$.System.String.Empty;
            }
            /*object */ get UnderlyingObject()
            {
                return this._source;
            }
            /*string */ get Value()
            {
                if (this._source !== null)
                {
                    let $switch1 = this._source.NodeType;
                    switch($switch1)
                    {
                        case 1/*XmlNodeType.Element*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XElement)).Value;
                        case 2/*XmlNodeType.Attribute*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XAttribute)).Value;
                        case 9/*XmlNodeType.Document*/:
                        /*XElement?*/ let root = ($.$cast(this._source, $.$spxl.System.Xml.Linq.XDocument)).Root;
                        return root !== null ? root.Value : $.$$.System.String.Empty;
                        case 3/*XmlNodeType.Text*/:
                        case 4/*XmlNodeType.CDATA*/:
                        return $.$spxl.System.Xml.XPath.XNodeNavigator.CollectText($.$cast(this._source, $.$spxl.System.Xml.Linq.XText));
                        case 8/*XmlNodeType.Comment*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XComment)).Value;
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XProcessingInstruction)).Data;
                        default:
                        return $.$$.System.String.Empty;
                    }
                }
                return $.$$.System.String.Empty;
            }
            /*XPathNavigator */ Clone()
            {
                return new $.$spxl.System.Xml.XPath.XNodeNavigator().$ctor$4(this);
            }
            /*bool */ IsSamePosition(/*XPathNavigator*/ navigator)
            {
                /*XNodeNavigator?*/ let other = $.$as(navigator, $.$spxl.System.Xml.XPath.XNodeNavigator);
                if (other === null)
                {
                    return false;
                }
                return $.$spxl.System.Xml.XPath.XNodeNavigator.IsSamePosition$1(this, other);
            }
            /*bool */ MoveTo(/*XPathNavigator*/ navigator)
            {
                /*XNodeNavigator?*/ let other = $.$as(navigator, $.$spxl.System.Xml.XPath.XNodeNavigator);
                if (other !== null)
                {
                    this._source = other._source;
                    this._parent = other._parent;
                    return true;
                }
                return false;
            }
            /*bool */ MoveToAttribute(/*string*/ localName, /*string*/ namespaceName)
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    var $en3 = e.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var attribute = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$$.System.String.op_Equality(attribute.Name.LocalName, localName) && $.$$.System.String.op_Equality(attribute.Name.NamespaceName, namespaceName) && !attribute.IsNamespaceDeclaration)
                            {
                                this._source = attribute;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToChild(/*string*/ localName, /*string*/ namespaceName)
            {
                /*XContainer?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (c !== null)
                {
                    var $en3 = c.Elements().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$$.System.String.op_Equality(element.Name.LocalName, localName) && $.$$.System.String.op_Equality(element.Name.NamespaceName, namespaceName))
                            {
                                this._source = element;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToChild$1(/*XPathNodeType*/ type)
            {
                /*XContainer?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (c !== null)
                {
                    /*int*/ let mask = $.$spxl.System.Xml.XPath.XNodeNavigator.GetElementContentMask(type);
                    if ((24/*TextMask*/ & mask) !== 0 && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(c) === null && $.$is(c, $.$spxl.System.Xml.Linq.XDocument))
                    {
                        mask &= ~24/*TextMask*/;
                    }
                    var $en3 = c.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (((1 << node.NodeType) & mask) !== 0)
                            {
                                this._source = node;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToFirstAttribute()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    var $en3 = e.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var attribute = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!attribute.IsNamespaceDeclaration)
                            {
                                this._source = attribute;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToFirstChild()
            {
                /*XContainer?*/ let container = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (container !== null)
                {
                    var $en3 = container.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, node))
                            {
                                this._source = node;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToFirstNamespace$1(/*XPathNamespaceScope*/ scope)
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    /*XAttribute?*/ let a = null;
                    switch(scope)
                    {
                        case 2/*XPathNamespaceScope.Local*/:
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationLocal(e);
                        break;
                        case 1/*XPathNamespaceScope.ExcludeXml*/:
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e);
                        while(a !== null && $.$$.System.String.op_Equality(a.Name.LocalName, "xml"))
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                        }
                        break;
                        case 0/*XPathNamespaceScope.All*/:
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e) ?? $.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration();
                        break;
                    }
                    if (a !== null)
                    {
                        this._source = a;
                        this._parent = e;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToId(/*string*/ id)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$spxl.System.SR.NotSupported_MoveToId);
            }
            /*bool */ MoveToNamespace(/*string*/ localName)
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if ($.$$.System.String.op_Equality(localName, "xmlns"))
                    {
                        return false;
                    }
                    if ($.$$.System.String.op_Inequality(localName, null) && localName.length === 0)
                    {
                        localName = "xmlns";
                    }
                    /*XAttribute?*/ let a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e);
                    while(a !== null)
                    {
                        if ($.$$.System.String.op_Equality(a.Name.LocalName, localName))
                        {
                            this._source = a;
                            this._parent = e;
                            return true;
                        }
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                    }
                    if ($.$$.System.String.op_Equality(localName, "xml"))
                    {
                        this._source = $.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration();
                        this._parent = e;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToNext()
            {
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    /*XContainer?*/ let container = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentNode);
                    if (container !== null)
                    {
                        /*XNode?*/ let next;
                        for(/*XNode*/ let node = currentNode; node !== null; node = next)
                        {
                            next = node.NextNode;
                            if (next === null)
                            {
                                break;
                            }
                            if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, next) && !($.$is(node, $.$spxl.System.Xml.Linq.XText) && $.$is(next, $.$spxl.System.Xml.Linq.XText)))
                            {
                                this._source = next;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToNext$1(/*string*/ localName, /*string*/ namespaceName)
            {
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    var $en3 = currentNode.ElementsAfterSelf().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$$.System.String.op_Equality(element.Name.LocalName, localName) && $.$$.System.String.op_Equality(element.Name.NamespaceName, namespaceName))
                            {
                                this._source = element;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToNext$2(/*XPathNodeType*/ type)
            {
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    /*XContainer?*/ let container = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentNode);
                    if (container !== null)
                    {
                        /*int*/ let mask = $.$spxl.System.Xml.XPath.XNodeNavigator.GetElementContentMask(type);
                        if ((24/*TextMask*/ & mask) !== 0 && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(container) === null && $.$is(container, $.$spxl.System.Xml.Linq.XDocument))
                        {
                            mask &= ~24/*TextMask*/;
                        }
                        /*XNode?*/ let next;
                        for(/*XNode*/ let node = currentNode; ; node = next)
                        {
                            next = node.NextNode;
                            if (next === null)
                            {
                                break;
                            }
                            if (((1 << next.NodeType) & mask) !== 0 && !($.$is(node, $.$spxl.System.Xml.Linq.XText) && $.$is(next, $.$spxl.System.Xml.Linq.XText)))
                            {
                                this._source = next;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToNextAttribute()
            {
                /*XAttribute?*/ let currentAttribute = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (currentAttribute !== null && this._parent === null)
                {
                    /*XElement?*/ let e = $.$cast($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentAttribute), $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        for(/*XAttribute?*/ let attribute = currentAttribute.NextAttribute; attribute !== null; attribute = attribute.NextAttribute)
                        {
                            if (!attribute.IsNamespaceDeclaration)
                            {
                                this._source = attribute;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToNextNamespace$1(/*XPathNamespaceScope*/ scope)
            {
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null && this._parent !== null && !$.$spxl.System.Xml.XPath.XNodeNavigator.IsXmlNamespaceDeclaration(a))
                {
                    switch(scope)
                    {
                        case 2/*XPathNamespaceScope.Local*/:
                        if ($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(a) !== this._parent)
                        {
                            return false;
                        }
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationLocal(a);
                        break;
                        case 1/*XPathNamespaceScope.ExcludeXml*/:
                        do
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                        }
                        while(a !== null && ($.$$.System.String.op_Equality(a.Name.LocalName, "xml") || $.$spxl.System.Xml.XPath.XNodeNavigator.HasNamespaceDeclarationInScope(a, this._parent)));
                        break;
                        case 0/*XPathNamespaceScope.All*/:
                        do
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                        }
                        while(a !== null && $.$spxl.System.Xml.XPath.XNodeNavigator.HasNamespaceDeclarationInScope(a, this._parent));
                        if (a === null && !$.$spxl.System.Xml.XPath.XNodeNavigator.HasNamespaceDeclarationInScope($.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration(), this._parent))
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration();
                        }
                        break;
                    }
                    if (a !== null)
                    {
                        this._source = a;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToParent()
            {
                if (this._parent !== null)
                {
                    this._source = this._parent;
                    this._parent = null;
                    return true;
                }
                /*XNode?*/ let parentNode = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(this._source);
                if (parentNode !== null)
                {
                    this._source = parentNode;
                    return true;
                }
                return false;
            }
            /*bool */ MoveToPrevious()
            {
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    /*XContainer?*/ let container = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentNode);
                    if (container !== null)
                    {
                        /*XNode?*/ let previous = null;
                        var $en4 = container.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var node = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (node === currentNode)
                                {
                                    if (previous !== null)
                                    {
                                        this._source = previous;
                                        return true;
                                    }
                                    return false;
                                }
                                if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, node))
                                {
                                    previous = node;
                                }
                            }
                        }
                    }
                }
                return false;
            }
            /*XmlReader */ ReadSubtree()
            {
                /*XContainer?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (c === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_BadNodeType, $.$box(this.NodeType, $.$spx.System.Xml.XPath.XPathNodeType)));
                }
                return c.CreateReader();
            }
            /*bool */ System$Xml$IXmlLineInfo$HasLineInfo()
            {
                /*IXmlLineInfo*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                if (li !== null)
                {
                    return li.System$Xml$IXmlLineInfo$HasLineInfo();
                }
                return false;
            }
            /*int */ get System$Xml$IXmlLineInfo$LineNumber()
            {
                /*IXmlLineInfo*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                if (li !== null)
                {
                    return li.System$Xml$IXmlLineInfo$LineNumber;
                }
                return 0;
            }
            /*int */ get System$Xml$IXmlLineInfo$LinePosition()
            {
                /*IXmlLineInfo*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                if (li !== null)
                {
                    return li.System$Xml$IXmlLineInfo$LinePosition;
                }
                return 0;
            }
            static /*string */ CollectText(/*XText*/ n)
            {
                /*string*/ let s = n.Value;
                if ($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n) !== null)
                {
                    var $en3 = n.NodesAfterSelf().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            /*XText?*/ let t = $.$as(node, $.$spxl.System.Xml.Linq.XText);
                            if (t === null)
                            {
                                break;
                            }
                            s += t.Value;
                        }
                    }
                }
                return s;
            }
            static /*NameTable */ CreateNameTable()
            {
                /*var*/ let nameTable = new $.$spx.System.Xml.NameTable().$ctor$2();
                nameTable.Add$1($.$$.System.String.Empty);
                nameTable.Add$1($.$spxl.System.Xml.XPath.XNodeNavigator.xmlnsPrefixNamespace);
                nameTable.Add$1($.$spxl.System.Xml.XPath.XNodeNavigator.xmlPrefixNamespace);
                return nameTable;
            }
            static /*bool */ IsContent(/*XContainer*/ c, /*XNode*/ n)
            {
                if ($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(c) !== null || $.$is(c, $.$spxl.System.Xml.Linq.XElement))
                {
                    return true;
                }
                return ((1 << n.NodeType) & 386/*DocumentContentMask*/) !== 0;
            }
            static /*bool */ IsSamePosition$1(/*XNodeNavigator*/ n1, /*XNodeNavigator*/ n2)
            {
                return n1._source === n2._source && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n1._source) === $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n2._source);
            }
            static /*bool */ IsXmlNamespaceDeclaration(/*XAttribute*/ a)
            {
                return $.$cast(a, $.$$.System.Object) === $.$cast($.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration(), $.$$.System.Object);
            }
            static /*int */ GetElementContentMask(/*XPathNodeType*/ type)
            {
                return $.$spxl.System.Xml.XPath.XNodeNavigator.ElementContentMasks.get_Item(type).$v;
            }
            static /*XAttribute? */ GetFirstNamespaceDeclarationGlobal(/*XElement*/ e)
            {
                /*XElement?*/ let ce = e;
                do
                {
                    /*XAttribute?*/ let a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationLocal(ce);
                    if (a !== null)
                    {
                        return a;
                    }
                    ce = ce.Parent;
                }
                while(ce !== null);
                return null;
            }
            static /*XAttribute? */ GetFirstNamespaceDeclarationLocal(/*XElement*/ e)
            {
                var $en2 = e.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var attribute = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (attribute.IsNamespaceDeclaration)
                        {
                            return attribute;
                        }
                    }
                }
                return null;
            }
            static /*XAttribute? */ GetNextNamespaceDeclarationGlobal(/*XAttribute*/ a)
            {
                /*XElement?*/ let e = $.$cast($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(a), $.$spxl.System.Xml.Linq.XElement);
                if (e === null)
                {
                    return null;
                }
                /*XAttribute?*/ let next = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationLocal(a);
                if (next !== null)
                {
                    return next;
                }
                e = e.Parent;
                if (e === null)
                {
                    return null;
                }
                return $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e);
            }
            static /*XAttribute? */ GetNextNamespaceDeclarationLocal(/*XAttribute*/ a)
            {
                /*XElement?*/ let e = a.Parent;
                if (e === null)
                {
                    return null;
                }
                /*XAttribute?*/ let ca = a;
                ca = ca.NextAttribute;
                while(ca !== null)
                {
                    if (ca.IsNamespaceDeclaration)
                    {
                        return ca;
                    }
                    ca = ca.NextAttribute;
                }
                return null;
            }
            static /*XAttribute */ GetXmlNamespaceDeclaration()
            {
                if ($.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration === null)
                {
                    $.$$.System.Threading.Interlocked.CompareExchange$14($.$spxl.System.Xml.Linq.XAttribute, $.$ref(() => $.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration, ($v) => $.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration = $v, $.$spxl.System.Xml.Linq.XAttribute), new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3($.$spxl.System.Xml.Linq.XNamespace.Xmlns.GetName$1("xml"), $.$spxl.System.Xml.XPath.XNodeNavigator.xmlPrefixNamespace), null);
                }
                return $.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration;
            }
            static /*bool */ HasNamespaceDeclarationInScope(/*XAttribute*/ a, /*XElement*/ e)
            {
                /*XName*/ let name = a.Name;
                /*XElement?*/ let ce = e;
                while(ce !== null && ce !== $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(a))
                {
                    if (ce.Attribute(name) !== null)
                    {
                        return true;
                    }
                    ce = ce.Parent;
                }
                return false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.xmlPrefixNamespace = $.$spxl.System.Xml.Linq.XNamespace.Xml.NamespaceName;
                }
                {
                    this.xmlnsPrefixNamespace = $.$spxl.System.Xml.Linq.XNamespace.Xmlns.NamespaceName;
                }
            }
            static $h = 3336144;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":59292310,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Int32).$h,"g":{"r":0,"d":0,"h":21478172624,"f":50331682},"n":"ElementContentMasks","d":3336144,"h":17183205328,"f":2097186},{"p":1310721,"g":{"r":0,"d":0,"h":60132878288,"f":50364417},"n":"BaseURI","d":3336144,"h":55837910992,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":68722812880,"f":50364417},"n":"HasAttributes","d":3336144,"h":64427845584,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":77312747472,"f":50364417},"n":"HasChildren","d":3336144,"h":73017780176,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":85902682064,"f":50364417},"n":"IsEmptyElement","d":3336144,"h":81607714768,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":94492616656,"f":50364417},"n":"LocalName","d":3336144,"h":90197649360,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":107377518544,"f":50364417},"n":"Name","d":3336144,"h":103082551248,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":115967453136,"f":50364417},"n":"NamespaceURI","d":3336144,"h":111672485840,"f":2129921},{"p":52083350,"g":{"r":0,"d":0,"h":128852355024,"f":50364417},"n":"NameTable","d":3336144,"h":124557387728,"f":2129921},{"p":59882134,"g":{"r":0,"d":0,"h":137442289616,"f":50364417},"n":"NodeType","d":3336144,"h":133147322320,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":146032224208,"f":50364417},"n":"Prefix","d":3336144,"h":141737256912,"f":2129921},{"p":131073,"g":{"r":0,"d":0,"h":158917126096,"f":50364417},"n":"UnderlyingObject","d":3336144,"h":154622158800,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":167507060688,"f":50364417},"n":"Value","d":3336144,"h":163212093392,"f":2129921},{"p":655361,"g":{"r":0,"d":0,"h":261996341200,"f":50331650},"n":"{13941398}.LineNumber","o":"System$Xml$IXmlLineInfo$LineNumber","d":3336144,"h":257701373904,"f":2097154},{"p":655361,"g":{"r":0,"d":0,"h":270586275792,"f":50331650},"n":"{13941398}.LinePosition","o":"System$Xml$IXmlLineInfo$LinePosition","d":3336144,"h":266291308496,"f":2097154}],"m":[{"r":1310721,"n":"GetLocalName","d":3336144,"h":98787583952,"f":16777218},{"r":1310721,"n":"GetNamespaceURI","d":3336144,"h":120262420432,"f":16777218},{"r":1310721,"n":"GetPrefix","d":3336144,"h":150327191504,"f":16777218},{"r":59292310,"n":"Clone","d":3336144,"h":171802027984,"f":16809985},{"r":262145,"p":[{"n":"navigator","p":59292310}],"n":"IsSamePosition","d":3336144,"h":176096995280,"f":16809985},{"r":262145,"p":[{"n":"navigator","p":59292310}],"n":"MoveTo","d":3336144,"h":180391962576,"f":16809985},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"MoveToAttribute","d":3336144,"h":184686929872,"f":16809985},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"MoveToChild","d":3336144,"h":188981897168,"f":16809985},{"r":262145,"p":[{"n":"type","p":59882134}],"n":"MoveToChild","o":"@$1","d":3336144,"h":193276864464,"f":16809985},{"r":262145,"n":"MoveToFirstAttribute","d":3336144,"h":197571831760,"f":16809985},{"r":262145,"n":"MoveToFirstChild","d":3336144,"h":201866799056,"f":16809985},{"r":262145,"p":[{"n":"scope","p":59226774}],"n":"MoveToFirstNamespace","o":"@$1","d":3336144,"h":206161766352,"f":16809985},{"r":262145,"p":[{"n":"id","p":1310721}],"n":"MoveToId","d":3336144,"h":210456733648,"f":16809985},{"r":262145,"p":[{"n":"localName","p":1310721}],"n":"MoveToNamespace","d":3336144,"h":214751700944,"f":16809985},{"r":262145,"n":"MoveToNext","d":3336144,"h":219046668240,"f":16809985},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"MoveToNext","o":"@$1","d":3336144,"h":223341635536,"f":16809985},{"r":262145,"p":[{"n":"type","p":59882134}],"n":"MoveToNext","o":"@$2","d":3336144,"h":227636602832,"f":16809985},{"r":262145,"n":"MoveToNextAttribute","d":3336144,"h":231931570128,"f":16809985},{"r":262145,"p":[{"n":"scope","p":59226774}],"n":"MoveToNextNamespace","o":"@$1","d":3336144,"h":236226537424,"f":16809985},{"r":262145,"n":"MoveToParent","d":3336144,"h":240521504720,"f":16809985},{"r":262145,"n":"MoveToPrevious","d":3336144,"h":244816472016,"f":16809985},{"r":53394070,"n":"ReadSubtree","d":3336144,"h":249111439312,"f":16809985},{"r":1310721,"p":[{"n":"n","p":3008464}],"n":"CollectText","d":3336144,"h":274881243088,"f":16777250},{"r":14269078,"n":"CreateNameTable","d":3336144,"h":279176210384,"f":16777250},{"r":262145,"p":[{"n":"c","p":1370064},{"n":"n","p":2287568}],"n":"IsContent","d":3336144,"h":283471177680,"f":16777250},{"r":262145,"p":[{"n":"n1","p":3336144},{"n":"n2","p":3336144}],"n":"IsSamePosition","o":"@$1","d":3336144,"h":287766144976,"f":16777250},{"r":262145,"p":[{"n":"a","p":1173456}],"n":"IsXmlNamespaceDeclaration","d":3336144,"h":292061112272,"f":16777250},{"r":655361,"p":[{"n":"type","p":59882134}],"n":"GetElementContentMask","d":3336144,"h":296356079568,"f":16777250},{"r":1173456,"p":[{"n":"e","p":1697744}],"n":"GetFirstNamespaceDeclarationGlobal","d":3336144,"h":300651046864,"f":16777250},{"r":1173456,"p":[{"n":"e","p":1697744}],"n":"GetFirstNamespaceDeclarationLocal","d":3336144,"h":304946014160,"f":16777250},{"r":1173456,"p":[{"n":"a","p":1173456}],"n":"GetNextNamespaceDeclarationGlobal","d":3336144,"h":309240981456,"f":16777250},{"r":1173456,"p":[{"n":"a","p":1173456}],"n":"GetNextNamespaceDeclarationLocal","d":3336144,"h":313535948752,"f":16777250},{"r":1173456,"n":"GetXmlNamespaceDeclaration","d":3336144,"h":317830916048,"f":16777250},{"r":262145,"p":[{"n":"a","p":1173456},{"n":"e","p":1697744}],"n":"HasNamespaceDeclarationInScope","d":3336144,"h":322125883344,"f":16777250}],"l":[{"t":1310721,"n":"xmlPrefixNamespace","d":3336144,"h":4298303440,"f":4194344},{"t":1310721,"n":"xmlnsPrefixNamespace","d":3336144,"h":8593270736,"f":4194344},{"t":655361,"n":"DocumentContentMask","d":3336144,"h":12888238032,"f":4194338},{"t":655361,"n":"TextMask","o":"@$1","d":3336144,"h":25773139920,"f":4194338},{"t":1173456,"n":"s_XmlNamespaceDeclaration","d":3336144,"h":30068107216,"f":4194338},{"t":2615248,"n":"_source","d":3336144,"h":34363074512,"f":4194306},{"t":1697744,"n":"_parent","d":3336144,"h":38658041808,"f":4194306},{"t":52083350,"n":"_nameTable","d":3336144,"h":42953009104,"f":4194306}],"c":[{"p":[{"n":"node","p":2287568},{"n":"nameTable","p":52083350}],"n":".ctor","o":"$ctor$3","d":3336144,"h":47247976400,"f":16777217},{"p":[{"n":"other","p":3336144}],"n":".ctor","o":"$ctor$4","d":3336144,"h":51542943696,"f":16777217}],"i":[57212929,58571414,14006934,13941398],"h":3336144}; }
            static get $b() { return $.$spx.System.Xml.XPath.XPathNavigator; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$spx.System.Xml.XPath.IXPathNavigable, $.$spx.System.Xml.IXmlNamespaceResolver, $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.XPath.XNodeNavigator`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.XObjectChange", ($self) => class XObjectChange extends $.$$.System.Enum
        {
            static Add = 0;
            static Remove = 1;
            static Name = 2;
            static Value = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Remove": 1n,
                    "Name": 2n,
                    "Value": 3n
                };
            }
            static $h = 2680784;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2680784,"n":"Add","d":2680784,"h":4297648080,"f":4194337},{"t":2680784,"n":"Remove","d":2680784,"h":8592615376,"f":4194337},{"t":2680784,"n":"Name","d":2680784,"h":12887582672,"f":4194337},{"t":2680784,"n":"Value","d":2680784,"h":17182549968,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2680784,"h":21477517264,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2680784}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.XObjectChange`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.LoadOptions", ($self) => class LoadOptions extends $.$$.System.Enum
        {
            static None = 0;
            static PreserveWhitespace = 1;
            static SetBaseUri = 2;
            static SetLineInfo = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "PreserveWhitespace": 1n,
                    "SetBaseUri": 2n,
                    "SetLineInfo": 4n
                };
            }
            static $h = 714704;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":714704,"n":"None","d":714704,"h":4295682000,"f":4194337},{"t":714704,"n":"PreserveWhitespace","d":714704,"h":8590649296,"f":4194337},{"t":714704,"n":"SetBaseUri","d":714704,"h":12885616592,"f":4194337},{"t":714704,"n":"SetLineInfo","d":714704,"h":17180583888,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":714704,"h":21475551184,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":714704,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.LoadOptions`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.SaveOptions", ($self) => class SaveOptions extends $.$$.System.Enum
        {
            static None = 0;
            static DisableFormatting = 1;
            static OmitDuplicateNamespaces = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "DisableFormatting": 1n,
                    "OmitDuplicateNamespaces": 2n
                };
            }
            static $h = 1042384;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1042384,"n":"None","d":1042384,"h":4296009680,"f":4194337},{"t":1042384,"n":"DisableFormatting","d":1042384,"h":8590976976,"f":4194337},{"t":1042384,"n":"OmitDuplicateNamespaces","d":1042384,"h":12885944272,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1042384,"h":17180911568,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1042384,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.SaveOptions`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.ReaderOptions", ($self) => class ReaderOptions extends $.$$.System.Enum
        {
            static None = 0;
            static OmitDuplicateNamespaces = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OmitDuplicateNamespaces": 1n
                };
            }
            static $h = 976848;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":976848,"n":"None","d":976848,"h":4295944144,"f":4194337},{"t":976848,"n":"OmitDuplicateNamespaces","d":976848,"h":8590911440,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":976848,"h":12885878736,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":976848,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.ReaderOptions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XDocument", ($self) => class XDocument extends $.$spxl.System.Xml.Linq.XContainer
        {
            /*XDeclaration?*/ _declaration = null;
            $ctor$5()
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            $ctor$6(/*params object?[]*/ content)
            {
                this.$ctor$5();
                {
                    this.AddContentSkipNotify(content);
                }
                return this;
            }
            $ctor$7(/*XDeclaration?*/ declaration, /*params object?[]*/ content)
            {
                this.$ctor$6(content);
                {
                    this._declaration = declaration;
                }
                return this;
            }
            $ctor$8(/*XDocument*/ other)
            {
                super.$ctor$4(other);
                {
                    if (other._declaration !== null)
                    {
                        this._declaration = new $.$spxl.System.Xml.Linq.XDeclaration().$ctor$3(other._declaration);
                    }
                }
                return this;
            }
            /*XDeclaration? */ get Declaration()
            {
                return this._declaration;
            }
            /*XDeclaration? */ set Declaration(value)
            {
                this._declaration = value;
            }
            /*XDocumentType? */ get DocumentType()
            {
                return this.GetFirstNode($.$spxl.System.Xml.Linq.XDocumentType);
            }
            /*XmlNodeType */ get NodeType()
            {
                return 9/*XmlNodeType.Document*/;
            }
            /*XElement? */ get Root()
            {
                return this.GetFirstNode($.$spxl.System.Xml.Linq.XElement);
            }
            static /*XDocument */ Load$5(/*string*/ uri)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Load$4(uri, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Load$4(/*string*/ uri, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$9(uri, rs);
                    return $.$spxl.System.Xml.Linq.XDocument.Load$6(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*XDocument */ Load$1(/*Stream*/ stream)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Load(stream, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Load(/*Stream*/ stream, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$2(stream, rs);
                    return $.$spxl.System.Xml.Linq.XDocument.Load$6(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*Task<XDocument> *//*async*/  LoadAsync(/*Stream*/ stream, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument), $.$spxl.System.Xml.Linq.XDocument, async () => 
                {
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$2(stream, rs);
                        return await $.$spxl.System.Xml.Linq.XDocument.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*XDocument */ Load$3(/*TextReader*/ textReader)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Load$2(textReader, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Load$2(/*TextReader*/ textReader, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$6(textReader, rs);
                    return $.$spxl.System.Xml.Linq.XDocument.Load$6(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*Task<XDocument> *//*async*/  LoadAsync$1(/*TextReader*/ textReader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument), $.$spxl.System.Xml.Linq.XDocument, async () => 
                {
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$6(textReader, rs);
                        return await $.$spxl.System.Xml.Linq.XDocument.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*XDocument */ Load$7(/*XmlReader*/ reader)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Load$6(reader, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Load$6(/*XmlReader*/ reader, /*LoadOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                if (reader.ReadState === 0/*ReadState.Initial*/)
                {
                    reader.Read();
                }
                /*XDocument*/ let d = $.$spxl.System.Xml.Linq.XDocument.InitLoad(reader, options);
                d.ReadContentFrom(reader, options);
                if (!reader.EOF)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                }
                if (d.Root === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingRoot);
                }
                return d;
            }
            static /*Task<XDocument> */ LoadAsync$2(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$3($.$spxl.System.Xml.Linq.XDocument, cancellationToken);
                }
                return $.$spxl.System.Xml.Linq.XDocument.LoadAsyncInternal(reader, options, cancellationToken);
            }
            static /*Task<XDocument> *//*async*/  LoadAsyncInternal(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument), $.$spxl.System.Xml.Linq.XDocument, async () => 
                {
                    if (reader.ReadState === 0/*ReadState.Initial*/)
                    {
                        await reader.ReadAsync().ConfigureAwait$2(false);
                    }
                    /*XDocument*/ let d = $.$spxl.System.Xml.Linq.XDocument.InitLoad(reader, options);
                    await d.ReadContentFromAsync$1(reader, options, cancellationToken).ConfigureAwait(false);
                    if (!reader.EOF)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                    }
                    if (d.Root === null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingRoot);
                    }
                    return d;
                });
            }
            static /*XDocument */ InitLoad(/*XmlReader*/ reader, /*LoadOptions*/ options)
            {
                /*XDocument*/ let d = new $.$spxl.System.Xml.Linq.XDocument().$ctor$5();
                if ((options & 2/*LoadOptions.SetBaseUri*/) !== 0)
                {
                    /*string?*/ let baseUri = reader.BaseURI;
                    if (!$.$$.System.String.IsNullOrEmpty(baseUri))
                    {
                        d.SetBaseUri(baseUri);
                    }
                }
                if ((options & 4/*LoadOptions.SetLineInfo*/) !== 0)
                {
                    /*IXmlLineInfo?*/ let li = $.$as(reader, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null && li.System$Xml$IXmlLineInfo$HasLineInfo())
                    {
                        d.SetLineInfo(li.System$Xml$IXmlLineInfo$LineNumber, li.System$Xml$IXmlLineInfo$LinePosition);
                    }
                }
                if (reader.NodeType === 17/*XmlNodeType.XmlDeclaration*/)
                {
                    d.Declaration = new $.$spxl.System.Xml.Linq.XDeclaration().$ctor$2(reader);
                }
                return d;
            }
            static /*XDocument */ Parse$1(/*string*/ text)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Parse(text, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Parse(/*string*/ text, /*LoadOptions*/ options)
            {
                let sr = null;
                try
                {
                    sr = new $.$$.System.IO.StringReader().$ctor$3(text);
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$6(sr, rs);
                        return $.$spxl.System.Xml.Linq.XDocument.Load$6(r, options);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                }
                finally
                {
                    sr?.System$IDisposable$Dispose();
                }
            }
            /*void */ Save$1(/*Stream*/ stream)
            {
                this.Save(stream, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save(/*Stream*/ stream, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                if (this._declaration !== null && !$.$$.System.String.IsNullOrEmpty(this._declaration.Encoding))
                {
                    try
                    {
                        ws.Encoding = $.$$.System.Text.Encoding.GetEncoding$3(this._declaration.Encoding);
                    }
                    catch($e)
                    {
                    }
                }
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create(stream, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*Task *//*async*/  SaveAsync(/*Stream*/ stream, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    if (this._declaration !== null && !$.$$.System.String.IsNullOrEmpty(this._declaration.Encoding))
                    {
                        try
                        {
                            ws.Encoding = $.$$.System.Text.Encoding.GetEncoding$3(this._declaration.Encoding);
                        }
                        catch($e)
                        {
                        }
                    }
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create(stream, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$$.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.WriteToAsync(w, cancellationToken).ConfigureAwait(false);
                        await w.FlushAsync().ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            /*void */ Save$3(/*TextWriter*/ textWriter)
            {
                this.Save$2(textWriter, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save$2(/*TextWriter*/ textWriter, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$2(textWriter, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*void */ Save$6(/*XmlWriter*/ writer)
            {
                this.WriteTo(writer);
            }
            /*Task *//*async*/  SaveAsync$1(/*TextWriter*/ textWriter, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create$2(textWriter, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$$.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.WriteToAsync(w, cancellationToken).ConfigureAwait(false);
                        await w.FlushAsync().ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            /*void */ Save$5(/*string*/ fileName)
            {
                this.Save$4(fileName, this.GetSaveOptionsFromAnnotations());
            }
            /*Task */ SaveAsync$2(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return this.WriteToAsync(writer, cancellationToken);
            }
            /*void */ Save$4(/*string*/ fileName, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                if (this._declaration !== null && !$.$$.System.String.IsNullOrEmpty(this._declaration.Encoding))
                {
                    try
                    {
                        ws.Encoding = $.$$.System.Text.Encoding.GetEncoding$3(this._declaration.Encoding);
                    }
                    catch($e)
                    {
                    }
                }
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$4(fileName, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (this._declaration !== null && $.$$.System.String.op_Equality(this._declaration.Standalone, "yes"))
                {
                    writer.WriteStartDocument$1(true);
                }
                else if (this._declaration !== null && $.$$.System.String.op_Equality(this._declaration.Standalone, "no"))
                {
                    writer.WriteStartDocument$1(false);
                }
                else 
                {
                    writer.WriteStartDocument();
                }
                this.WriteContentTo(writer);
                writer.WriteEndDocument();
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return this.WriteToAsyncInternal(writer, cancellationToken);
            }
            /*Task *//*async*/  WriteToAsyncInternal(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    /*Task*/ let tStart;
                    if (this._declaration !== null && $.$$.System.String.op_Equality(this._declaration.Standalone, "yes"))
                    {
                        tStart = writer.WriteStartDocumentAsync$1(true);
                    }
                    else if (this._declaration !== null && $.$$.System.String.op_Equality(this._declaration.Standalone, "no"))
                    {
                        tStart = writer.WriteStartDocumentAsync$1(false);
                    }
                    else 
                    {
                        tStart = writer.WriteStartDocumentAsync();
                    }
                    await tStart.ConfigureAwait(false);
                    await this.WriteContentToAsync(writer, cancellationToken).ConfigureAwait(false);
                    await writer.WriteEndDocumentAsync().ConfigureAwait(false);
                });
            }
            /*void */ AddAttribute(/*XAttribute*/ a)
            {
                throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_AddAttribute);
            }
            /*void */ AddAttributeSkipNotify(/*XAttribute*/ a)
            {
                throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_AddAttribute);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XDocument().$ctor$8(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XDocument?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XDocument);
                return other !== null && this.ContentsEqual(other);
            }
            /*int */ GetDeepHashCode()
            {
                return this.ContentsHashCode();
            }
            /*T? */ GetFirstNode(T)
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*T?*/ let e = $.$as(n, T);
                        if ($.$box(e, T) !== null)
                        {
                            return e;
                        }
                    }
                    while(n !== this.content);
                }
                return null;
            }
            /*void */ ValidateNode(/*XNode*/ node, /*XNode?*/ previous)
            {
                let $switch1 = node.NodeType;
                switch($switch1)
                {
                    case 3/*XmlNodeType.Text*/:
                    this.ValidateString(($.$cast(node, $.$spxl.System.Xml.Linq.XText)).Value);
                    break;
                    case 1/*XmlNodeType.Element*/:
                    this.ValidateDocument(previous, 10/*XmlNodeType.DocumentType*/, 0/*XmlNodeType.None*/);
                    break;
                    case 10/*XmlNodeType.DocumentType*/:
                    this.ValidateDocument(previous, 0/*XmlNodeType.None*/, 1/*XmlNodeType.Element*/);
                    break;
                    case 4/*XmlNodeType.CDATA*/:
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_AddNode, $.$box(4/*XmlNodeType.CDATA*/, $.$spx.System.Xml.XmlNodeType)));
                    case 9/*XmlNodeType.Document*/:
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_AddNode, $.$box(9/*XmlNodeType.Document*/, $.$spx.System.Xml.XmlNodeType)));
                }
            }
            /*void */ ValidateDocument(/*XNode?*/ previous, /*XmlNodeType*/ allowBefore, /*XmlNodeType*/ allowAfter)
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    if (previous === null)
                    {
                        allowBefore = allowAfter;
                    }
                    do
                    {
                        n = n.next;
                        /*XmlNodeType*/ let nt = n.NodeType;
                        if (nt === 1/*XmlNodeType.Element*/ || nt === 10/*XmlNodeType.DocumentType*/)
                        {
                            if (nt !== allowBefore)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_DocumentStructure);
                            }
                            allowBefore = 0/*XmlNodeType.None*/;
                        }
                        if (n === previous)
                        {
                            allowBefore = allowAfter;
                        }
                    }
                    while(n !== this.content);
                }
            }
            /*void */ ValidateString(/*string*/ s)
            {
                if ($.$$.System.MemoryExtensions.ContainsAnyExcept$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(s), $.$$.System.String.op_Implicit(" \t\r\n")))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_AddNonWhitespace);
                }
            }
            static $h = 1566672;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1370064,"p":[{"p":1501136,"g":{"r":0,"d":0,"h":30066337744,"f":50331649},"s":{"r":0,"d":0,"h":34361305040,"f":83886081},"n":"Declaration","d":1566672,"h":25771370448,"f":2097153},{"p":1632208,"g":{"r":0,"d":0,"h":42951239632,"f":50331649},"n":"DocumentType","d":1566672,"h":38656272336,"f":2097153},{"p":52869782,"g":{"r":0,"d":0,"h":51541174224,"f":50364417},"n":"NodeType","d":1566672,"h":47246206928,"f":2129921},{"p":1697744,"g":{"r":0,"d":0,"h":60131108816,"f":50331649},"n":"Root","d":1566672,"h":55836141520,"f":2097153}],"m":[{"r":1566672,"p":[{"n":"uri","p":1310721}],"n":"Load","o":"@$5","d":1566672,"h":64426076112,"f":16777249},{"r":1566672,"p":[{"n":"uri","p":1310721},{"n":"options","p":714704}],"n":"Load","o":"@$4","d":1566672,"h":68721043408,"f":16777249},{"r":1566672,"p":[{"n":"stream","p":62193665}],"n":"Load","o":"@$1","d":1566672,"h":73016010704,"f":16777249},{"r":1566672,"p":[{"n":"stream","p":62193665},{"n":"options","p":714704}],"n":"Load","d":1566672,"h":77310978000,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,"p":[{"n":"stream","p":62193665},{"n":"options","p":714704},{"n":"cancellationToken","p":125829121}],"n":"LoadAsync","d":1566672,"h":81605945296,"f":16781345},{"r":1566672,"p":[{"n":"textReader","p":62914561}],"n":"Load","o":"@$3","d":1566672,"h":85900912592,"f":16777249},{"r":1566672,"p":[{"n":"textReader","p":62914561},{"n":"options","p":714704}],"n":"Load","o":"@$2","d":1566672,"h":90195879888,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,"p":[{"n":"textReader","p":62914561},{"n":"options","p":714704},{"n":"cancellationToken","p":125829121}],"n":"LoadAsync","o":"@$1","d":1566672,"h":94490847184,"f":16781345},{"r":1566672,"p":[{"n":"reader","p":53394070}],"n":"Load","o":"@$7","d":1566672,"h":98785814480,"f":16777249},{"r":1566672,"p":[{"n":"reader","p":53394070},{"n":"options","p":714704}],"n":"Load","o":"@$6","d":1566672,"h":103080781776,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,"p":[{"n":"reader","p":53394070},{"n":"options","p":714704},{"n":"cancellationToken","p":125829121}],"n":"LoadAsync","o":"@$2","d":1566672,"h":107375749072,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,"p":[{"n":"reader","p":53394070},{"n":"options","p":714704},{"n":"cancellationToken","p":125829121}],"n":"LoadAsyncInternal","d":1566672,"h":111670716368,"f":16781346},{"r":1566672,"p":[{"n":"reader","p":53394070},{"n":"options","p":714704}],"n":"InitLoad","d":1566672,"h":115965683664,"f":16777250},{"r":1566672,"p":[{"n":"text","p":1310721}],"n":"Parse","o":"@$1","d":1566672,"h":120260650960,"f":16777249},{"r":1566672,"p":[{"n":"text","p":1310721},{"n":"options","p":714704}],"n":"Parse","d":1566672,"h":124555618256,"f":16777249},{"r":65537,"p":[{"n":"stream","p":62193665}],"n":"Save","o":"@$1","d":1566672,"h":128850585552,"f":16777217},{"r":65537,"p":[{"n":"stream","p":62193665},{"n":"options","p":1042384}],"n":"Save","d":1566672,"h":133145552848,"f":16777217},{"r":133169153,"p":[{"n":"stream","p":62193665},{"n":"options","p":1042384},{"n":"cancellationToken","p":125829121}],"n":"SaveAsync","d":1566672,"h":137440520144,"f":16781313},{"r":65537,"p":[{"n":"textWriter","p":63045633}],"n":"Save","o":"@$3","d":1566672,"h":141735487440,"f":16777217},{"r":65537,"p":[{"n":"textWriter","p":63045633},{"n":"options","p":1042384}],"n":"Save","o":"@$2","d":1566672,"h":146030454736,"f":16777217},{"r":65537,"p":[{"n":"writer","p":58440342}],"n":"Save","o":"@$6","d":1566672,"h":150325422032,"f":16777217},{"r":133169153,"p":[{"n":"textWriter","p":63045633},{"n":"options","p":1042384},{"n":"cancellationToken","p":125829121}],"n":"SaveAsync","o":"@$1","d":1566672,"h":154620389328,"f":16781313},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"Save","o":"@$5","d":1566672,"h":158915356624,"f":16777217},{"r":133169153,"p":[{"n":"writer","p":58440342},{"n":"cancellationToken","p":125829121}],"n":"SaveAsync","o":"@$2","d":1566672,"h":163210323920,"f":16777217},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"options","p":1042384}],"n":"Save","o":"@$4","d":1566672,"h":167505291216,"f":16777217},{"r":65537,"p":[{"n":"writer","p":58440342}],"n":"WriteTo","d":1566672,"h":171800258512,"f":16809985},{"r":133169153,"p":[{"n":"writer","p":58440342},{"n":"cancellationToken","p":125829121}],"n":"WriteToAsync","d":1566672,"h":176095225808,"f":16809985},{"r":133169153,"p":[{"n":"writer","p":58440342},{"n":"cancellationToken","p":125829121}],"n":"WriteToAsyncInternal","d":1566672,"h":180390193104,"f":16781314},{"r":65537,"p":[{"n":"a","p":1173456}],"n":"AddAttribute","d":1566672,"h":184685160400,"f":16809992},{"r":65537,"p":[{"n":"a","p":1173456}],"n":"AddAttributeSkipNotify","d":1566672,"h":188980127696,"f":16809992},{"r":2287568,"n":"CloneNode","d":1566672,"h":193275094992,"f":16809992},{"r":262145,"p":[{"n":"node","p":2287568}],"n":"DeepEquals","o":"@$1","d":1566672,"h":197570062288,"f":16809992},{"r":655361,"n":"GetDeepHashCode","d":1566672,"h":201865029584,"f":16809992},{"r":(T) => T.$h,"g":["T"],"n":"GetFirstNode","d":1566672,"h":206159996880,"f":16908290},{"r":65537,"p":[{"n":"node","p":2287568},{"n":"previous","p":2287568}],"n":"ValidateNode","d":1566672,"h":210454964176,"f":16809992},{"r":65537,"p":[{"n":"previous","p":2287568},{"n":"allowBefore","p":52869782},{"n":"allowAfter","p":52869782}],"n":"ValidateDocument","d":1566672,"h":214749931472,"f":16777218},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"ValidateString","d":1566672,"h":219044898768,"f":16809992}],"l":[{"t":1501136,"n":"_declaration","d":1566672,"h":4296533968,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$5","d":1566672,"h":8591501264,"f":16777217},{"p":[{"n":"content","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":".ctor","o":"$ctor$6","d":1566672,"h":12886468560,"f":16777217},{"p":[{"n":"declaration","p":1501136},{"n":"content","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":".ctor","o":"$ctor$7","d":1566672,"h":17181435856,"f":16777217},{"p":[{"n":"other","p":1566672}],"n":".ctor","o":"$ctor$8","d":1566672,"h":21476403152,"f":16777217}],"i":[13941398],"h":1566672}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XContainer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XDocument`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XElement", ($self) => class XElement extends $.$spxl.System.Xml.Linq.XContainer
        {
            static /*IEnumerable<XElement> */ get EmptySequence()
            {
                return $.$$.System.Array.Empty($.$spxl.System.Xml.Linq.XElement);
            }
            /*XName*/ name = null;
            /*XAttribute?*/ lastAttr = null;
            $ctor$12(/*XName*/ name)
            {
                super.$ctor$3();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                    this.name = name;
                }
                return this;
            }
            $ctor$10(/*XName*/ name, /*object?*/ content)
            {
                this.$ctor$12(name);
                {
                    this.AddContentSkipNotify(content);
                }
                return this;
            }
            $ctor$11(/*XName*/ name, /*params object?[]*/ content)
            {
                this.$ctor$10(name, $.$cast(content, $.$$.System.Object));
                {
                }
                return this;
            }
            $ctor$9(/*XElement*/ other)
            {
                super.$ctor$4(other);
                {
                    this.name = other.name;
                    /*XAttribute?*/ let a = other.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            this.AppendAttributeSkipNotify(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(a));
                        }
                        while(a !== other.lastAttr);
                    }
                }
                return this;
            }
            $ctor$13(/*XStreamingElement*/ other)
            {
                super.$ctor$3();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this.name = other.name;
                    this.AddContentSkipNotify(other.content);
                }
                return this;
            }
            $ctor$5()
            {
                this.$ctor$12($.$spxl.System.Xml.Linq.XName.op_Implicit($.$spxl.System.Xml.Linq.XName.op_Implicit($.$default())));
                {
                }
                return this;
            }
            $ctor$7(/*XmlReader*/ r)
            {
                this.$ctor$6(r, 0/*LoadOptions.None*/);
                {
                }
                return this;
            }
            $ctor$8(/*AsyncConstructionSentry*/ _)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            static $_AsyncConstructionSentry;
            static get AsyncConstructionSentry()
            {
                let $cls = $.$spxl.System.Xml.Linq.XElement;
                return $cls.$_AsyncConstructionSentry ??= $asm.$nstr("$spxl.System.Xml.Linq.XElement.AsyncConstructionSentry", ($self) => class AsyncConstructionSentry extends $.$$.System.ValueType
                {
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        return copy;
                    }
                    static $h = 1763280;
                    static $z = 0;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"c":[{"n":".ctor","o":"$ctor$2","d":1763280,"h":4296730576,"f":16777217}],"d":1697744,"h":1763280}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Xml.Linq.XElement.AsyncConstructionSentry`; }
                }, $cls, ($v) => $cls.$_AsyncConstructionSentry = $v);
            }
            $ctor$6(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                super.$ctor$3();
                {
                    this.ReadElementFrom(r, o);
                }
                return this;
            }
            static /*Task<XElement> *//*async*/  CreateAsync(/*XmlReader*/ r, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    /*XElement*/ let xe = new $.$spxl.System.Xml.Linq.XElement().$ctor$8($.$default($.$spxl.System.Xml.Linq.XElement.AsyncConstructionSentry));
                    await xe.ReadElementFromAsync(r, 0/*LoadOptions.None*/, cancellationToken).ConfigureAwait(false);
                    return xe;
                });
            }
            /*void */ Save$5(/*string*/ fileName)
            {
                this.Save$4(fileName, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save$4(/*string*/ fileName, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$4(fileName, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*XAttribute? */ get FirstAttribute()
            {
                return this.lastAttr?.next ?? null;
            }
            /*bool */ get HasAttributes()
            {
                return this.lastAttr !== null;
            }
            /*bool */ get HasElements()
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        if ($.$is(n, $.$spxl.System.Xml.Linq.XElement))
                        {
                            return true;
                        }
                        n = n.next;
                    }
                    while(n !== this.content);
                }
                return false;
            }
            /*bool */ get IsEmpty()
            {
                return this.content === null;
            }
            /*XAttribute? */ get LastAttribute()
            {
                return this.lastAttr;
            }
            /*XName */ get Name()
            {
                return this.name;
            }
            /*XName */ set Name(value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                this.name = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                }
            }
            /*XmlNodeType */ get NodeType()
            {
                return 1/*XmlNodeType.Element*/;
            }
            /*string */ get Value()
            {
                if (this.content === null)
                {
                    return $.$$.System.String.Empty;
                }
                /*string?*/ let s = $.$as(this.content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    return s;
                }
                /*StringBuilder*/ let sb = $.$spxl.System.Text.StringBuilderCache.Acquire(16);
                this.AppendText(sb);
                return $.$spxl.System.Text.StringBuilderCache.GetStringAndRelease(sb);
            }
            /*string */ set Value(value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.RemoveNodes();
                this.Add(value);
            }
            /*IEnumerable<XElement> */ AncestorsAndSelf()
            {
                return this.GetAncestors(null, true);
            }
            /*IEnumerable<XElement> */ AncestorsAndSelf$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetAncestors(name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*XAttribute? */ Attribute(/*XName*/ name)
            {
                /*XAttribute?*/ let a = this.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(a.name, name))
                        {
                            return a;
                        }
                    }
                    while(a !== this.lastAttr);
                }
                return null;
            }
            /*IEnumerable<XAttribute> */ Attributes()
            {
                return this.GetAttributes(null);
            }
            /*IEnumerable<XAttribute> */ Attributes$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetAttributes(name) : $.$spxl.System.Xml.Linq.XAttribute.EmptySequence;
            }
            /*IEnumerable<XNode> */ DescendantNodesAndSelf()
            {
                return this.GetDescendantNodes(true);
            }
            /*IEnumerable<XElement> */ DescendantsAndSelf()
            {
                return this.GetDescendants(null, true);
            }
            /*IEnumerable<XElement> */ DescendantsAndSelf$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetDescendants(name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*XNamespace */ GetDefaultNamespace()
            {
                /*string?*/ let namespaceName = this.GetNamespaceOfPrefixInScope("xmlns", null);
                return $.$$.System.String.op_Inequality(namespaceName, null) ? $.$spxl.System.Xml.Linq.XNamespace.Get$1(namespaceName) : $.$spxl.System.Xml.Linq.XNamespace.None;
            }
            /*XNamespace? */ GetNamespaceOfPrefix(/*string*/ prefix)
            {
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(prefix, "prefix");
                if ($.$$.System.String.op_Equality(prefix, "xmlns"))
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.Xmlns;
                }
                /*string?*/ let namespaceName = this.GetNamespaceOfPrefixInScope(prefix, null);
                if ($.$$.System.String.op_Inequality(namespaceName, null))
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.Get$1(namespaceName);
                }
                if ($.$$.System.String.op_Equality(prefix, "xml"))
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.Xml;
                }
                return null;
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(ns, "ns");
                /*string*/ let namespaceName = ns.NamespaceName;
                /*bool*/ let hasInScopeNamespace = false;
                /*XElement?*/ let e = this;
                do
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        /*bool*/ let hasLocalNamespace = false;
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration)
                            {
                                if ($.$$.System.String.op_Equality(a.Value, namespaceName))
                                {
                                    if (a.Name.NamespaceName.length !== 0 && (!hasInScopeNamespace || $.$$.System.String.op_Equality(this.GetNamespaceOfPrefixInScope(a.Name.LocalName, e), null)))
                                    {
                                        return a.Name.LocalName;
                                    }
                                }
                                hasLocalNamespace = true;
                            }
                        }
                        while(a !== e.lastAttr);
                        hasInScopeNamespace = $.$$.System.Boolean.op_BitwiseOr(hasInScopeNamespace, hasLocalNamespace);
                    }
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                while(e !== null);
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    if (!hasInScopeNamespace || $.$$.System.String.op_Equality(this.GetNamespaceOfPrefixInScope("xml", null), null))
                    {
                        return "xml";
                    }
                }
                else if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            static /*XElement */ Load$5(/*string*/ uri)
            {
                return $.$spxl.System.Xml.Linq.XElement.Load$4(uri, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Load$4(/*string*/ uri, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$9(uri, rs);
                    return $.$spxl.System.Xml.Linq.XElement.Load$6(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*XElement */ Load$1(/*Stream*/ stream)
            {
                return $.$spxl.System.Xml.Linq.XElement.Load(stream, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Load(/*Stream*/ stream, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$2(stream, rs);
                    return $.$spxl.System.Xml.Linq.XElement.Load$6(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*Task<XElement> *//*async*/  LoadAsync(/*Stream*/ stream, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$2(stream, rs);
                        return await $.$spxl.System.Xml.Linq.XElement.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*XElement */ Load$3(/*TextReader*/ textReader)
            {
                return $.$spxl.System.Xml.Linq.XElement.Load$2(textReader, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Load$2(/*TextReader*/ textReader, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$6(textReader, rs);
                    return $.$spxl.System.Xml.Linq.XElement.Load$6(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*Task<XElement> *//*async*/  LoadAsync$1(/*TextReader*/ textReader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$6(textReader, rs);
                        return await $.$spxl.System.Xml.Linq.XElement.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*XElement */ Load$7(/*XmlReader*/ reader)
            {
                return $.$spxl.System.Xml.Linq.XElement.Load$6(reader, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Load$6(/*XmlReader*/ reader, /*LoadOptions*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                if (reader.MoveToContent() !== 1/*XmlNodeType.Element*/)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$5($.$spxl.System.SR.InvalidOperation_ExpectedNodeType, $.$box(1/*XmlNodeType.Element*/, $.$spx.System.Xml.XmlNodeType), $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                }
                /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$6(reader, options);
                reader.MoveToContent();
                if (!reader.EOF)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                }
                return e;
            }
            static /*Task<XElement> */ LoadAsync$2(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$3($.$spxl.System.Xml.Linq.XElement, cancellationToken);
                }
                return $.$spxl.System.Xml.Linq.XElement.LoadAsyncInternal(reader, options, cancellationToken);
            }
            static /*Task<XElement> *//*async*/  LoadAsyncInternal(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    if (await reader.MoveToContentAsync().ConfigureAwait$2(false) !== 1/*XmlNodeType.Element*/)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$5($.$spxl.System.SR.InvalidOperation_ExpectedNodeType, $.$box(1/*XmlNodeType.Element*/, $.$spx.System.Xml.XmlNodeType), $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                    }
                    /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$8($.$default($.$spxl.System.Xml.Linq.XElement.AsyncConstructionSentry));
                    await e.ReadElementFromAsync(reader, options, cancellationToken).ConfigureAwait(false);
                    cancellationToken.ThrowIfCancellationRequested();
                    await reader.MoveToContentAsync().ConfigureAwait$2(false);
                    if (!reader.EOF)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                    }
                    return e;
                });
            }
            static /*XElement */ Parse$1(/*string*/ text)
            {
                return $.$spxl.System.Xml.Linq.XElement.Parse(text, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Parse(/*string*/ text, /*LoadOptions*/ options)
            {
                let sr = null;
                try
                {
                    sr = new $.$$.System.IO.StringReader().$ctor$3(text);
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$6(sr, rs);
                        return $.$spxl.System.Xml.Linq.XElement.Load$6(r, options);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                }
                finally
                {
                    sr?.System$IDisposable$Dispose();
                }
            }
            /*void */ RemoveAll()
            {
                this.RemoveAttributes();
                this.RemoveNodes();
            }
            /*void */ RemoveAttributes()
            {
                if (this.SkipNotify())
                {
                    this.RemoveAttributesSkipNotify();
                    return;
                }
                while(this.lastAttr !== null)
                {
                    /*XAttribute*/ let a = this.lastAttr.next;
                    this.NotifyChanging(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                    if (this.lastAttr === null || a !== this.lastAttr.next)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                    }
                    if (a !== this.lastAttr)
                    {
                        this.lastAttr.next = a.next;
                    }
                    else 
                    {
                        this.lastAttr = null;
                    }
                    a.parent = null;
                    a.next = null;
                    this.NotifyChanged(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                }
            }
            /*void */ ReplaceAll(/*object?*/ content)
            {
                content = $.$spxl.System.Xml.Linq.XContainer.GetContentSnapshot(content);
                this.RemoveAll();
                this.Add(content);
            }
            /*void */ ReplaceAll$1(/*params object?[]*/ content)
            {
                this.ReplaceAll($.$cast(content, $.$$.System.Object));
            }
            /*void */ ReplaceAttributes(/*object?*/ content)
            {
                content = $.$spxl.System.Xml.Linq.XContainer.GetContentSnapshot(content);
                this.RemoveAttributes();
                this.Add(content);
            }
            /*void */ ReplaceAttributes$1(/*params object?[]*/ content)
            {
                this.ReplaceAttributes($.$cast(content, $.$$.System.Object));
            }
            /*void */ Save$1(/*Stream*/ stream)
            {
                this.Save(stream, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save(/*Stream*/ stream, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create(stream, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*Task *//*async*/  SaveAsync(/*Stream*/ stream, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create(stream, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$$.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.SaveAsync$2(w, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            /*void */ Save$3(/*TextWriter*/ textWriter)
            {
                this.Save$2(textWriter, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save$2(/*TextWriter*/ textWriter, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$2(textWriter, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*Task *//*async*/  SaveAsync$1(/*TextWriter*/ textWriter, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create$2(textWriter, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$$.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.SaveAsync$2(w, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            /*void */ Save$6(/*XmlWriter*/ writer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                writer.WriteStartDocument();
                this.WriteTo(writer);
                writer.WriteEndDocument();
            }
            /*Task */ SaveAsync$2(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return this.SaveAsyncInternal(writer, cancellationToken);
            }
            /*Task *//*async*/  SaveAsyncInternal(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    await writer.WriteStartDocumentAsync().ConfigureAwait(false);
                    await this.WriteToAsync(writer, cancellationToken).ConfigureAwait(false);
                    cancellationToken.ThrowIfCancellationRequested();
                    await writer.WriteEndDocumentAsync().ConfigureAwait(false);
                });
            }
            /*void */ SetAttributeValue(/*XName*/ name, /*object?*/ value)
            {
                /*XAttribute?*/ let a = this.Attribute(name);
                if (value === null)
                {
                    if (a !== null)
                    {
                        this.RemoveAttribute(a);
                    }
                }
                else 
                {
                    if (a !== null)
                    {
                        a.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
                    }
                    else 
                    {
                        this.AppendAttribute(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(name, value));
                    }
                }
            }
            /*void */ SetElementValue(/*XName*/ name, /*object?*/ value)
            {
                /*XElement?*/ let e = this.Element(name);
                if (value === null)
                {
                    if (e !== null)
                    {
                        this.RemoveNode(e);
                    }
                }
                else 
                {
                    if (e !== null)
                    {
                        e.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
                    }
                    else 
                    {
                        this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$10(name, $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value)));
                    }
                }
            }
            /*void */ SetValue(/*object*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                new $.$spxl.System.Xml.Linq.ElementWriter().$ctor$3(writer).WriteElement(this);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return new $.$spxl.System.Xml.Linq.ElementWriter().$ctor$3(writer).WriteElementAsync(this, cancellationToken);
            }
            static /*string? */ op_Explicit$21(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return element.Value;
            }
            static /*bool */ op_Explicit(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$$.System.String.ToLowerInvariant.call(element.Value));
            }
            static /*bool? */ op_Explicit$8(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$$.System.String.ToLowerInvariant.call(element.Value));
            }
            static /*int */ op_Explicit$6(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToInt32(element.Value);
            }
            static /*int? */ op_Explicit$14(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt32(element.Value);
            }
            static /*uint */ op_Explicit$23(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToUInt32(element.Value);
            }
            static /*uint? */ op_Explicit$18(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt32(element.Value);
            }
            static /*long */ op_Explicit$7(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToInt64(element.Value);
            }
            static /*long? */ op_Explicit$15(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt64(element.Value);
            }
            static /*ulong */ op_Explicit$24(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToUInt64(element.Value);
            }
            static /*ulong? */ op_Explicit$19(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt64(element.Value);
            }
            static /*float */ op_Explicit$20(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToSingle(element.Value);
            }
            static /*float? */ op_Explicit$16(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToSingle(element.Value);
            }
            static /*double */ op_Explicit$4(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToDouble(element.Value);
            }
            static /*double? */ op_Explicit$12(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDouble(element.Value);
            }
            static /*decimal */ op_Explicit$3(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToDecimal(element.Value);
            }
            static /*decimal? */ op_Explicit$11(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDecimal(element.Value);
            }
            static /*DateTime */ op_Explicit$1(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$$.System.DateTime.Parse$2(element.Value, $.$$.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            static /*DateTime? */ op_Explicit$9(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$$.System.DateTime.Parse$2(element.Value, $.$$.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            static /*DateTimeOffset */ op_Explicit$2(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset$2(element.Value);
            }
            static /*DateTimeOffset? */ op_Explicit$10(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset$2(element.Value);
            }
            static /*TimeSpan */ op_Explicit$22(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(element.Value);
            }
            static /*TimeSpan? */ op_Explicit$17(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(element.Value);
            }
            static /*Guid */ op_Explicit$5(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToGuid(element.Value);
            }
            static /*Guid? */ op_Explicit$13(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToGuid(element.Value);
            }
            /*XmlSchema? */ System$Xml$Serialization$IXmlSerializable$GetSchema()
            {
                return null;
            }
            /*void */ System$Xml$Serialization$IXmlSerializable$ReadXml(/*XmlReader*/ reader)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                if (this.parent !== null || this.annotations !== null || this.content !== null || this.lastAttr !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_DeserializeInstance);
                }
                if (reader.MoveToContent() !== 1/*XmlNodeType.Element*/)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$5($.$spxl.System.SR.InvalidOperation_ExpectedNodeType, $.$box(1/*XmlNodeType.Element*/, $.$spx.System.Xml.XmlNodeType), $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                }
                this.ReadElementFrom(reader, 0/*LoadOptions.None*/);
            }
            /*void */ System$Xml$Serialization$IXmlSerializable$WriteXml(/*XmlWriter*/ writer)
            {
                this.WriteTo(writer);
            }
            /*void */ AddAttribute(/*XAttribute*/ a)
            {
                if (this.Attribute(a.Name) !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_DuplicateAttribute);
                }
                if (a.parent !== null)
                {
                    a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(a);
                }
                this.AppendAttribute(a);
            }
            /*void */ AddAttributeSkipNotify(/*XAttribute*/ a)
            {
                if (this.Attribute(a.Name) !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_DuplicateAttribute);
                }
                if (a.parent !== null)
                {
                    a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(a);
                }
                this.AppendAttributeSkipNotify(a);
            }
            /*void */ AppendAttribute(/*XAttribute*/ a)
            {
                /*bool*/ let notify = this.NotifyChanging(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                if (a.parent !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                this.AppendAttributeSkipNotify(a);
                if (notify)
                {
                    this.NotifyChanged(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                }
            }
            /*void */ AppendAttributeSkipNotify(/*XAttribute*/ a)
            {
                a.parent = this;
                if (this.lastAttr === null)
                {
                    a.next = a;
                }
                else 
                {
                    a.next = this.lastAttr.next;
                    this.lastAttr.next = a;
                }
                this.lastAttr = a;
            }
            /*bool */ AttributesEqual(/*XElement*/ e)
            {
                /*XAttribute?*/ let a1 = this.lastAttr;
                /*XAttribute?*/ let a2 = e.lastAttr;
                if (a1 !== null && a2 !== null)
                {
                    do
                    {
                        a1 = a1.next;
                        a2 = a2.next;
                        if ($.$spxl.System.Xml.Linq.XName.op_Inequality(a1.name, a2.name) || $.$$.System.String.op_Inequality(a1.value, a2.value))
                        {
                            return false;
                        }
                    }
                    while(a1 !== this.lastAttr);
                    return a2 === e.lastAttr;
                }
                return a1 === null && a2 === null;
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XElement().$ctor$9(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XElement?*/ let e = $.$as(node, $.$spxl.System.Xml.Linq.XElement);
                return e !== null && $.$spxl.System.Xml.Linq.XName.op_Equality(this.name, e.name) && this.ContentsEqual(e) && this.AttributesEqual(e);
            }
            /*IEnumerable<XAttribute> */ GetAttributes(/*XName?*/ name)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*XAttribute?*/ let a = this.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(a.name, name))
                            {
                                yield a;
                            }
                        }
                        while(a.parent === this && a !== this.lastAttr);
                    }
                }.bind(this));
            }
            /*string? */ GetNamespaceOfPrefixInScope(/*string*/ prefix, /*XElement?*/ outOfScope)
            {
                /*XElement?*/ let e = this;
                while(e !== outOfScope)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(e !== null, "e != null");
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration && $.$$.System.String.op_Equality(a.Name.LocalName, prefix))
                            {
                                return a.Value;
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return null;
            }
            /*int */ GetDeepHashCode()
            {
                /*int*/ let h = $.$spxl.System.Xml.Linq.XName.GetHashCode.call(this.name);
                h ^= this.ContentsHashCode();
                /*XAttribute?*/ let a = this.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        h ^= a.GetDeepHashCode();
                    }
                    while(a !== this.lastAttr);
                }
                return h;
            }
            /*void */ ReadElementFrom(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                this.ReadElementFromImpl(r, o);
                if (!r.IsEmptyElement)
                {
                    r.Read();
                    this.ReadContentFrom(r, o);
                }
                r.Read();
            }
            /*Task *//*async*/  ReadElementFromAsync(/*XmlReader*/ r, /*LoadOptions*/ o, /*CancellationToken*/ cancellationTokentoken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    this.ReadElementFromImpl(r, o);
                    if (!r.IsEmptyElement)
                    {
                        cancellationTokentoken.ThrowIfCancellationRequested();
                        await r.ReadAsync().ConfigureAwait$2(false);
                        await this.ReadContentFromAsync$1(r, o, cancellationTokentoken).ConfigureAwait(false);
                    }
                    cancellationTokentoken.ThrowIfCancellationRequested();
                    await r.ReadAsync().ConfigureAwait$2(false);
                });
            }
            /*void */ ReadElementFromImpl(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                if (r.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                this.name = $.$spxl.System.Xml.Linq.XNamespace.Get$1(r.NamespaceURI).GetName$1(r.LocalName);
                if ((o & 2/*LoadOptions.SetBaseUri*/) !== 0)
                {
                    /*string?*/ let baseUri = r.BaseURI;
                    if (!$.$$.System.String.IsNullOrEmpty(baseUri))
                    {
                        this.SetBaseUri(baseUri);
                    }
                }
                /*IXmlLineInfo?*/ let li = null;
                if ((o & 4/*LoadOptions.SetLineInfo*/) !== 0)
                {
                    li = $.$as(r, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null && li.System$Xml$IXmlLineInfo$HasLineInfo())
                    {
                        this.SetLineInfo(li.System$Xml$IXmlLineInfo$LineNumber, li.System$Xml$IXmlLineInfo$LinePosition);
                    }
                }
                if (r.MoveToFirstAttribute())
                {
                    do
                    {
                        /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3($.$spxl.System.Xml.Linq.XNamespace.Get$1(r.Prefix.length === 0 ? $.$$.System.String.Empty : r.NamespaceURI).GetName$1(r.LocalName), r.Value);
                        if (li !== null && li.System$Xml$IXmlLineInfo$HasLineInfo())
                        {
                            a.SetLineInfo(li.System$Xml$IXmlLineInfo$LineNumber, li.System$Xml$IXmlLineInfo$LinePosition);
                        }
                        this.AppendAttributeSkipNotify(a);
                    }
                    while(r.MoveToNextAttribute());
                    r.MoveToElement();
                }
            }
            /*void */ RemoveAttribute(/*XAttribute*/ a)
            {
                /*bool*/ let notify = this.NotifyChanging(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                if (a.parent !== this)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                /*XAttribute?*/ let p = this.lastAttr, n;
                while((n = p.next) !== a)
                {
                    p = n;
                }
                if (p === a)
                {
                    this.lastAttr = null;
                }
                else 
                {
                    if (this.lastAttr === a)
                    {
                        this.lastAttr = p;
                    }
                    p.next = a.next;
                }
                a.parent = null;
                a.next = null;
                if (notify)
                {
                    this.NotifyChanged(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                }
            }
            /*void */ RemoveAttributesSkipNotify()
            {
                if (this.lastAttr !== null)
                {
                    /*XAttribute*/ let a = this.lastAttr;
                    do
                    {
                        /*XAttribute*/ let next = a.next;
                        a.parent = null;
                        a.next = null;
                        a = next;
                    }
                    while(a !== this.lastAttr);
                    this.lastAttr = null;
                }
            }
            /*void */ SetEndElementLineInfo(/*int*/ lineNumber, /*int*/ linePosition)
            {
                this.AddAnnotation(new $.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation().$ctor$2(lineNumber, linePosition));
            }
            /*void */ ValidateNode(/*XNode*/ node, /*XNode?*/ previous)
            {
                if ($.$is(node, $.$spxl.System.Xml.Linq.XDocument))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_AddNode, $.$box(9/*XmlNodeType.Document*/, $.$spx.System.Xml.XmlNodeType)));
                }
                if ($.$is(node, $.$spxl.System.Xml.Linq.XDocumentType))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_AddNode, $.$box(10/*XmlNodeType.DocumentType*/, $.$spx.System.Xml.XmlNodeType)));
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.name = null;
            }
            static $h = 1697744;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1370064,"p":[{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"g":{"r":0,"d":0,"h":8591632336,"f":50331681},"n":"EmptySequence","d":1697744,"h":4296665040,"f":2097185},{"p":1173456,"g":{"r":0,"d":0,"h":81606076368,"f":50331649},"n":"FirstAttribute","d":1697744,"h":77311109072,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":90196010960,"f":50331649},"n":"HasAttributes","d":1697744,"h":85901043664,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":98785945552,"f":50331649},"n":"HasElements","d":1697744,"h":94490978256,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":107375880144,"f":50331649},"n":"IsEmpty","d":1697744,"h":103080912848,"f":2097153},{"p":1173456,"g":{"r":0,"d":0,"h":115965814736,"f":50331649},"n":"LastAttribute","d":1697744,"h":111670847440,"f":2097153},{"p":2156496,"g":{"r":0,"d":0,"h":124555749328,"f":50331649},"s":{"r":0,"d":0,"h":128850716624,"f":83886081},"n":"Name","d":1697744,"h":120260782032,"f":2097153},{"p":52869782,"g":{"r":0,"d":0,"h":137440651216,"f":50364417},"n":"NodeType","d":1697744,"h":133145683920,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":146030585808,"f":50331649},"s":{"r":0,"d":0,"h":150325553104,"f":83886081},"n":"Value","d":1697744,"h":141735618512,"f":2097153}],"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"r","p":53394070},{"n":"cancellationToken","p":125829121}],"n":"CreateAsync","d":1697744,"h":64426207184,"f":16781352},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"Save","o":"@$5","d":1697744,"h":68721174480,"f":16777217},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"options","p":1042384}],"n":"Save","o":"@$4","d":1697744,"h":73016141776,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"AncestorsAndSelf","d":1697744,"h":154620520400,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2156496}],"n":"AncestorsAndSelf","o":"@$1","d":1697744,"h":158915487696,"f":16777217},{"r":1173456,"p":[{"n":"name","p":2156496}],"n":"Attribute","d":1697744,"h":163210454992,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"n":"Attributes","d":1697744,"h":167505422288,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"name","p":2156496}],"n":"Attributes","o":"@$1","d":1697744,"h":171800389584,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"DescendantNodesAndSelf","d":1697744,"h":176095356880,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"DescendantsAndSelf","d":1697744,"h":180390324176,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2156496}],"n":"DescendantsAndSelf","o":"@$1","d":1697744,"h":184685291472,"f":16777217},{"r":2222032,"n":"GetDefaultNamespace","d":1697744,"h":188980258768,"f":16777217},{"r":2222032,"p":[{"n":"prefix","p":1310721}],"n":"GetNamespaceOfPrefix","d":1697744,"h":193275226064,"f":16777217},{"r":1310721,"p":[{"n":"ns","p":2222032}],"n":"GetPrefixOfNamespace","d":1697744,"h":197570193360,"f":16777217},{"r":1697744,"p":[{"n":"uri","p":1310721}],"n":"Load","o":"@$5","d":1697744,"h":201865160656,"f":16777249},{"r":1697744,"p":[{"n":"uri","p":1310721},{"n":"options","p":714704}],"n":"Load","o":"@$4","d":1697744,"h":206160127952,"f":16777249},{"r":1697744,"p":[{"n":"stream","p":62193665}],"n":"Load","o":"@$1","d":1697744,"h":210455095248,"f":16777249},{"r":1697744,"p":[{"n":"stream","p":62193665},{"n":"options","p":714704}],"n":"Load","d":1697744,"h":214750062544,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"stream","p":62193665},{"n":"options","p":714704},{"n":"cancellationToken","p":125829121}],"n":"LoadAsync","d":1697744,"h":219045029840,"f":16781345},{"r":1697744,"p":[{"n":"textReader","p":62914561}],"n":"Load","o":"@$3","d":1697744,"h":223339997136,"f":16777249},{"r":1697744,"p":[{"n":"textReader","p":62914561},{"n":"options","p":714704}],"n":"Load","o":"@$2","d":1697744,"h":227634964432,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"textReader","p":62914561},{"n":"options","p":714704},{"n":"cancellationToken","p":125829121}],"n":"LoadAsync","o":"@$1","d":1697744,"h":231929931728,"f":16781345},{"r":1697744,"p":[{"n":"reader","p":53394070}],"n":"Load","o":"@$7","d":1697744,"h":236224899024,"f":16777249},{"r":1697744,"p":[{"n":"reader","p":53394070},{"n":"options","p":714704}],"n":"Load","o":"@$6","d":1697744,"h":240519866320,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"reader","p":53394070},{"n":"options","p":714704},{"n":"cancellationToken","p":125829121}],"n":"LoadAsync","o":"@$2","d":1697744,"h":244814833616,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"reader","p":53394070},{"n":"options","p":714704},{"n":"cancellationToken","p":125829121}],"n":"LoadAsyncInternal","d":1697744,"h":249109800912,"f":16781346},{"r":1697744,"p":[{"n":"text","p":1310721}],"n":"Parse","o":"@$1","d":1697744,"h":253404768208,"f":16777249},{"r":1697744,"p":[{"n":"text","p":1310721},{"n":"options","p":714704}],"n":"Parse","d":1697744,"h":257699735504,"f":16777249},{"r":65537,"n":"RemoveAll","d":1697744,"h":261994702800,"f":16777217},{"r":65537,"n":"RemoveAttributes","d":1697744,"h":266289670096,"f":16777217},{"r":65537,"p":[{"n":"content","p":131073}],"n":"ReplaceAll","d":1697744,"h":270584637392,"f":16777217},{"r":65537,"p":[{"n":"content","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"ReplaceAll","o":"@$1","d":1697744,"h":274879604688,"f":16777217},{"r":65537,"p":[{"n":"content","p":131073}],"n":"ReplaceAttributes","d":1697744,"h":279174571984,"f":16777217},{"r":65537,"p":[{"n":"content","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"ReplaceAttributes","o":"@$1","d":1697744,"h":283469539280,"f":16777217},{"r":65537,"p":[{"n":"stream","p":62193665}],"n":"Save","o":"@$1","d":1697744,"h":287764506576,"f":16777217},{"r":65537,"p":[{"n":"stream","p":62193665},{"n":"options","p":1042384}],"n":"Save","d":1697744,"h":292059473872,"f":16777217},{"r":133169153,"p":[{"n":"stream","p":62193665},{"n":"options","p":1042384},{"n":"cancellationToken","p":125829121}],"n":"SaveAsync","d":1697744,"h":296354441168,"f":16781313},{"r":65537,"p":[{"n":"textWriter","p":63045633}],"n":"Save","o":"@$3","d":1697744,"h":300649408464,"f":16777217},{"r":65537,"p":[{"n":"textWriter","p":63045633},{"n":"options","p":1042384}],"n":"Save","o":"@$2","d":1697744,"h":304944375760,"f":16777217},{"r":133169153,"p":[{"n":"textWriter","p":63045633},{"n":"options","p":1042384},{"n":"cancellationToken","p":125829121}],"n":"SaveAsync","o":"@$1","d":1697744,"h":309239343056,"f":16781313},{"r":65537,"p":[{"n":"writer","p":58440342}],"n":"Save","o":"@$6","d":1697744,"h":313534310352,"f":16777217},{"r":133169153,"p":[{"n":"writer","p":58440342},{"n":"cancellationToken","p":125829121}],"n":"SaveAsync","o":"@$2","d":1697744,"h":317829277648,"f":16777217},{"r":133169153,"p":[{"n":"writer","p":58440342},{"n":"cancellationToken","p":125829121}],"n":"SaveAsyncInternal","d":1697744,"h":322124244944,"f":16781314},{"r":65537,"p":[{"n":"name","p":2156496},{"n":"value","p":131073}],"n":"SetAttributeValue","d":1697744,"h":326419212240,"f":16777217},{"r":65537,"p":[{"n":"name","p":2156496},{"n":"value","p":131073}],"n":"SetElementValue","d":1697744,"h":330714179536,"f":16777217},{"r":65537,"p":[{"n":"value","p":131073}],"n":"SetValue","d":1697744,"h":335009146832,"f":16777217},{"r":65537,"p":[{"n":"writer","p":58440342}],"n":"WriteTo","d":1697744,"h":339304114128,"f":16809985},{"r":133169153,"p":[{"n":"writer","p":58440342},{"n":"cancellationToken","p":125829121}],"n":"WriteToAsync","d":1697744,"h":343599081424,"f":16809985},{"r":65537,"p":[{"n":"a","p":1173456}],"n":"AddAttribute","d":1697744,"h":468153133008,"f":16809992},{"r":65537,"p":[{"n":"a","p":1173456}],"n":"AddAttributeSkipNotify","d":1697744,"h":472448100304,"f":16809992},{"r":65537,"p":[{"n":"a","p":1173456}],"n":"AppendAttribute","d":1697744,"h":476743067600,"f":16777224},{"r":65537,"p":[{"n":"a","p":1173456}],"n":"AppendAttributeSkipNotify","d":1697744,"h":481038034896,"f":16777224},{"r":262145,"p":[{"n":"e","p":1697744}],"n":"AttributesEqual","d":1697744,"h":485333002192,"f":16777218},{"r":2287568,"n":"CloneNode","d":1697744,"h":489627969488,"f":16809992},{"r":262145,"p":[{"n":"node","p":2287568}],"n":"DeepEquals","o":"@$1","d":1697744,"h":493922936784,"f":16809992},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"name","p":2156496}],"n":"GetAttributes","d":1697744,"h":498217904080,"f":16777218},{"r":1310721,"p":[{"n":"prefix","p":1310721},{"n":"outOfScope","p":1697744}],"n":"GetNamespaceOfPrefixInScope","d":1697744,"h":502512871376,"f":16777218},{"r":655361,"n":"GetDeepHashCode","d":1697744,"h":506807838672,"f":16809992},{"r":65537,"p":[{"n":"r","p":53394070},{"n":"o","p":714704}],"n":"ReadElementFrom","d":1697744,"h":511102805968,"f":16777218},{"r":133169153,"p":[{"n":"r","p":53394070},{"n":"o","p":714704},{"n":"cancellationTokentoken","p":125829121}],"n":"ReadElementFromAsync","d":1697744,"h":515397773264,"f":16781314},{"r":65537,"p":[{"n":"r","p":53394070},{"n":"o","p":714704}],"n":"ReadElementFromImpl","d":1697744,"h":519692740560,"f":16777218},{"r":65537,"p":[{"n":"a","p":1173456}],"n":"RemoveAttribute","d":1697744,"h":523987707856,"f":16777224},{"r":65537,"n":"RemoveAttributesSkipNotify","d":1697744,"h":528282675152,"f":16777218},{"r":65537,"p":[{"n":"lineNumber","p":655361},{"n":"linePosition","p":655361}],"n":"SetEndElementLineInfo","d":1697744,"h":532577642448,"f":16777224},{"r":65537,"p":[{"n":"node","p":2287568},{"n":"previous","p":2287568}],"n":"ValidateNode","d":1697744,"h":536872609744,"f":16809992}],"l":[{"t":2156496,"n":"name","d":1697744,"h":12886599632,"f":4194312},{"t":1173456,"n":"lastAttr","d":1697744,"h":17181566928,"f":4194312}],"c":[{"p":[{"n":"name","p":2156496}],"n":".ctor","o":"$ctor$12","d":1697744,"h":21476534224,"f":16777217},{"p":[{"n":"name","p":2156496},{"n":"content","p":131073}],"n":".ctor","o":"$ctor$10","d":1697744,"h":25771501520,"f":16777217},{"p":[{"n":"name","p":2156496},{"n":"content","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":".ctor","o":"$ctor$11","d":1697744,"h":30066468816,"f":16777217},{"p":[{"n":"other","p":1697744}],"n":".ctor","o":"$ctor$9","d":1697744,"h":34361436112,"f":16777217},{"p":[{"n":"other","p":2942928}],"n":".ctor","o":"$ctor$13","d":1697744,"h":38656403408,"f":16777217},{"n":".ctor","o":"$ctor$5","d":1697744,"h":42951370704,"f":16777224},{"p":[{"n":"r","p":53394070}],"n":".ctor","o":"$ctor$7","d":1697744,"h":47246338000,"f":16777224},{"p":[{"n":"_","p":1763280}],"n":".ctor","o":"$ctor$8","d":1697744,"h":51541305296,"f":16777218},{"p":[{"n":"r","p":53394070},{"n":"o","p":714704}],"n":".ctor","o":"$ctor$6","d":1697744,"h":60131239888,"f":16777224}],"i":[13941398,37272214],"j":[1763280],"h":1697744,"a":[{"t":44874390,"c":12929776278,"a":[{"t":1310721}],"n":[{"n":"IsAny","v":true,"t":262145}]},{"t":1545231,"c":4296512527,"a":[{"v":"MS.Internal.Xml.Linq.ComponentModel.XTypeDescriptionProvider\u00601[[System.Xml.Linq.XElement, System.Xml.Linq, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]],System.ComponentModel.TypeConverter","t":1310721}]}]}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XContainer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo, $.$spx.System.Xml.Serialization.IXmlSerializable ]; }
            static get $fullName() { return `System.Xml.Linq.XElement`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Schema.XmlSchemaInfoEqualityComparer", ($self) => class XmlSchemaInfoEqualityComparer extends $.$$.System.Object
        {
            /*bool */ Equals$2(/*XmlSchemaInfo?*/ si1, /*XmlSchemaInfo?*/ si2)
            {
                if (si1 === si2)
                {
                    return true;
                }
                if (si1 === null || si2 === null)
                {
                    return false;
                }
                return si1.ContentType === si2.ContentType && si1.IsDefault === si2.IsDefault && si1.IsNil === si2.IsNil && $.$cast(si1.MemberType, $.$$.System.Object) === $.$cast(si2.MemberType, $.$$.System.Object) && $.$cast(si1.SchemaAttribute, $.$$.System.Object) === $.$cast(si2.SchemaAttribute, $.$$.System.Object) && $.$cast(si1.SchemaElement, $.$$.System.Object) === $.$cast(si2.SchemaElement, $.$$.System.Object) && $.$cast(si1.SchemaType, $.$$.System.Object) === $.$cast(si2.SchemaType, $.$$.System.Object) && si1.Validity === si2.Validity;
            }
            /*int */ GetHashCode$1(/*XmlSchemaInfo?*/ si)
            {
                if (si === null)
                {
                    return 0;
                }
                /*int*/ let h = si.ContentType;
                if (si.IsDefault)
                {
                    h ^= 1;
                }
                if (si.IsNil)
                {
                    h ^= 1;
                }
                /*XmlSchemaSimpleType?*/ let memberType = si.MemberType;
                if (memberType !== null)
                {
                    h ^= $.$$.System.Object.GetHashCode.call(memberType);
                }
                /*XmlSchemaAttribute?*/ let schemaAttribute = si.SchemaAttribute;
                if (schemaAttribute !== null)
                {
                    h ^= $.$$.System.Object.GetHashCode.call(schemaAttribute);
                }
                /*XmlSchemaElement?*/ let schemaElement = si.SchemaElement;
                if (schemaElement !== null)
                {
                    h ^= $.$$.System.Object.GetHashCode.call(schemaElement);
                }
                /*XmlSchemaType?*/ let schemaType = si.SchemaType;
                if (schemaType !== null)
                {
                    h ^= $.$$.System.Object.GetHashCode.call(schemaType);
                }
                h ^= si.Validity;
                return h;
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Schema.XmlSchemaInfo>.Equals(System.Xml.Schema.XmlSchemaInfo?, System.Xml.Schema.XmlSchemaInfo?)
            System$Collections$Generic$IEqualityComparer$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Schema.XmlSchemaInfo>.GetHashCode(System.Xml.Schema.XmlSchemaInfo)
            System$Collections$Generic$IEqualityComparer$$$GetHashCode()
            {
                return this.GetHashCode$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 3139536;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"si1","p":30128790},{"n":"si2","p":30128790}],"n":"Equals","o":"@$2","d":3139536,"h":4298106832,"f":16777217},{"r":655361,"p":[{"n":"si","p":30128790}],"n":"GetHashCode","o":"@$1","d":3139536,"h":8593074128,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":3139536,"h":12888041424,"f":16777217}],"i":[$.$$.System.Collections.Generic.IEqualityComparer$$($.$spx.System.Xml.Schema.XmlSchemaInfo).$h],"h":3139536}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEqualityComparer$$($.$spx.System.Xml.Schema.XmlSchemaInfo) ]; }
            static get $fullName() { return `System.Xml.Schema.XmlSchemaInfoEqualityComparer`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.LineInfoEndElementAnnotation", ($self) => class LineInfoEndElementAnnotation extends $.$spxl.System.Xml.Linq.LineInfoAnnotation
        {
            $ctor$2(/*int*/ lineNumber, /*int*/ linePosition)
            {
                super.$ctor$1(lineNumber, linePosition);
                {
                }
                return this;
            }
            static $h = 649168;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":583632,"c":[{"p":[{"n":"lineNumber","p":655361},{"n":"linePosition","p":655361}],"n":".ctor","o":"$ctor$2","d":649168,"h":4295616464,"f":16777217}],"h":649168}; }
            static get $b() { return $.$spxl.System.Xml.Linq.LineInfoAnnotation; }
            static get $fullName() { return `System.Xml.Linq.LineInfoEndElementAnnotation`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XObjectChangeEventArgs", ($self) => class XObjectChangeEventArgs extends $.$$.System.EventArgs
        {
            /*XObjectChange*/ _objectChange = 0;
            /*XObjectChangeEventArgs*/ static Add = null;
            /*XObjectChangeEventArgs*/ static Remove = null;
            /*XObjectChangeEventArgs*/ static Name = null;
            /*XObjectChangeEventArgs*/ static Value = null;
            $ctor$2(/*XObjectChange*/ objectChange)
            {
                super.$ctor$1();
                {
                    this._objectChange = objectChange;
                }
                return this;
            }
            /*XObjectChange */ get ObjectChange()
            {
                return this._objectChange;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Add = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(0/*XObjectChange.Add*/);
                }
                {
                    this.Remove = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(1/*XObjectChange.Remove*/);
                }
                {
                    this.Name = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(2/*XObjectChange.Name*/);
                }
                {
                    this.Value = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(3/*XObjectChange.Value*/);
                }
            }
            static $h = 2811856;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":2680784,"g":{"r":0,"d":0,"h":34362550224,"f":50331649},"n":"ObjectChange","d":2811856,"h":30067582928,"f":2097153}],"l":[{"t":2680784,"n":"_objectChange","d":2811856,"h":4297779152,"f":4194306},{"t":2811856,"n":"Add","d":2811856,"h":8592746448,"f":4194337},{"t":2811856,"n":"Remove","d":2811856,"h":12887713744,"f":4194337},{"t":2811856,"n":"Name","d":2811856,"h":17182681040,"f":4194337},{"t":2811856,"n":"Value","d":2811856,"h":21477648336,"f":4194337}],"c":[{"p":[{"n":"objectChange","p":2680784}],"n":".ctor","o":"$ctor$2","d":2811856,"h":25772615632,"f":16777217}],"h":2811856}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.Xml.Linq.XObjectChangeEventArgs`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XCData", ($self) => class XCData extends $.$spxl.System.Xml.Linq.XText
        {
            $ctor$6(/*string*/ value)
            {
                super.$ctor$3(value);
                {
                }
                return this;
            }
            $ctor$8(/*XCData*/ other)
            {
                super.$ctor$5(other);
                {
                }
                return this;
            }
            $ctor$7(/*XmlReader*/ r)
            {
                super.$ctor$4(r);
                {
                }
                return this;
            }
            /*XmlNodeType */ get NodeType()
            {
                return 4/*XmlNodeType.CDATA*/;
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                writer.WriteCData(this.text);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return writer.WriteCDataAsync(this.text);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XCData().$ctor$8(this);
            }
            static $h = 1238992;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3008464,"p":[{"p":52869782,"g":{"r":0,"d":0,"h":21476075472,"f":50364417},"n":"NodeType","d":1238992,"h":17181108176,"f":2129921}],"m":[{"r":65537,"p":[{"n":"writer","p":58440342}],"n":"WriteTo","d":1238992,"h":25771042768,"f":16809985},{"r":133169153,"p":[{"n":"writer","p":58440342},{"n":"cancellationToken","p":125829121}],"n":"WriteToAsync","d":1238992,"h":30066010064,"f":16809985},{"r":2287568,"n":"CloneNode","d":1238992,"h":34360977360,"f":16809992}],"c":[{"p":[{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$6","d":1238992,"h":4296206288,"f":16777217},{"p":[{"n":"other","p":1238992}],"n":".ctor","o":"$ctor$8","d":1238992,"h":8591173584,"f":16777217},{"p":[{"n":"r","p":53394070}],"n":".ctor","o":"$ctor$7","d":1238992,"h":12886140880,"f":16777224}],"i":[13941398],"h":1238992}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XText; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XCData`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml"))