
//--TRIMMABLE-BOUNDARY-START(4)
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Private.Xml.Linq", 
    {
  "h": 4,
  "f": "System.Private.Xml.Linq",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Private.Xml.Linq",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Private.Xml.Linq",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2555908)
        $asm.$cls("$spxl.System.Xml.Linq.XObject", ($self) => class XObject extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(141736476676)
            /*XContainer?*/ parent = null;
            //--TRIMMABLE-BOUNDARY-END(141736476676)
            
            //--TRIMMABLE-BOUNDARY-START(42952228868)
            /*object?*/ annotations = null;
            //--TRIMMABLE-BOUNDARY-END(42952228868)
            
            //--TRIMMABLE-BOUNDARY-START(4297523204)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297523204);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297523204)
            
            //--TRIMMABLE-BOUNDARY-START(60132098052)
            /*string */ get BaseUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606934532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        break;
                    }
                    /*BaseUriAnnotation?*/ let a = o.Annotation$1($.$spxl.System.Xml.Linq.BaseUriAnnotation);
                    if (a !== null)
                    {
                        return a.baseUri;
                    }
                    o = o.parent;
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(60132098052)
            
            //--TRIMMABLE-BOUNDARY-START(73016999940)
            /*XDocument? */ get Document()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196869124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XObject*/ let n = this;
                while(n.parent !== null)
                {
                    n = n.parent;
                }
                /*XDocument?*/ let doc = $.$as(n, $.$spxl.System.Xml.Linq.XDocument);
                return doc;
            }
            //--TRIMMABLE-BOUNDARY-END(73016999940)
            
            //--TRIMMABLE-BOUNDARY-START(146031443972)
            /*XElement? */ get Parent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966672900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$as(this.parent, $.$spxl.System.Xml.Linq.XElement);
            }
            //--TRIMMABLE-BOUNDARY-END(146031443972)
            
            //--TRIMMABLE-BOUNDARY-START(25772359684)
            /*void */ AddAnnotation(/*object*/ annotation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772359684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(annotation, "annotation");
                if (this.annotations === null)
                {
                    this.annotations = $.$is(annotation, $.$typeArray($.$$.System.Object)) ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [annotation], [-1], null) : annotation;
                }
                else 
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                    if (a === null)
                    {
                        this.annotations = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [this.annotations, annotation], [-1], null);
                    }
                    else 
                    {
                        /*int*/ let i = 0;
                        while(i < a.length && $.$$.System.Array.$ReadT1.call(a, i) !== null)
                        {
                            i++;
                        }
                        if (i === a.length)
                        {
                            $.$$.System.Array.Resize($.$$.System.Object, $.$ref(() => a, ($v) => a = $v, $.$typeArray($.$$.System.Object)), ((i * 2) | 0));
                            this.annotations = a;
                        }
                        $.$$.System.Array.$WriteT1.call(a, annotation, i);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772359684)
            
            //--TRIMMABLE-BOUNDARY-START(30067326980)
            /*object? */ Annotation(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067326980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                    if (a === null)
                    {
                        if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(this.annotations, type))
                        {
                            return this.annotations;
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < a.length; i++)
                        {
                            /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(obj, type))
                            {
                                return obj;
                            }
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(30067326980)
            
            //--TRIMMABLE-BOUNDARY-START(38657261572)
            /*object? */ AnnotationForSealedType(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657261572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Inequality$1(type, null), "type != null");
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                    if (a === null)
                    {
                        if ($.$$.System.Type.op_Equality$1($.$$.System.Object.GetType.call(this.annotations), type))
                        {
                            return this.annotations;
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < a.length; i++)
                        {
                            /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if ($.$$.System.Type.op_Equality$1($.$$.System.Object.GetType.call(obj), type))
                            {
                                return obj;
                            }
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(38657261572)
            
            //--TRIMMABLE-BOUNDARY-START(34362294276)
            /*T? */ Annotation$1(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362294276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                    if (a === null)
                    {
                        return $.$as(this.annotations, T);
                    }
                    for(/*int*/ let i = 0; i < a.length; i++)
                    {
                        /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(a, i);
                        if (obj === null)
                        {
                            break;
                        }
                        /*T?*/ let result = $.$as(obj, T);
                        if ($.$box(result, T) !== null)
                        {
                            return result;
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(34362294276)
            
            //--TRIMMABLE-BOUNDARY-START(47247196164)
            /*IEnumerable<object> */ Annotations(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247196164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                return this.AnnotationsIterator(type);
            }
            //--TRIMMABLE-BOUNDARY-END(47247196164)
            
            //--TRIMMABLE-BOUNDARY-START(55837130756)
            /*IEnumerable<object> */ AnnotationsIterator(/*Type*/ type)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (this.annotations !== null)
                    {
                        /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                        if (a === null)
                        {
                            if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(this.annotations, type))
                            {
                                yield this.annotations;
                            }
                        }
                        else 
                        {
                            for(/*int*/ let i = 0; i < a.length; i++)
                            {
                                /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(a, i);
                                if (obj === null)
                                {
                                    break;
                                }
                                if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(obj, type))
                                {
                                    yield obj;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(55837130756)
            
            //--TRIMMABLE-BOUNDARY-START(51542163460)
            /*IEnumerable<T> */ Annotations$1(T)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (this.annotations !== null)
                    {
                        /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                        if (a === null)
                        {
                            /*T?*/ let result = $.$as(this.annotations, T);
                            if ($.$box(result, T) !== null)
                            {
                                yield result;
                            }
                        }
                        else 
                        {
                            for(/*int*/ let i = 0; i < a.length; i++)
                            {
                                /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(a, i);
                                if (obj === null)
                                {
                                    break;
                                }
                                /*T?*/ let result = $.$as(obj, T);
                                if ($.$box(result, T) !== null)
                                {
                                    yield result;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(51542163460)
            
            //--TRIMMABLE-BOUNDARY-START(167506280452)
            /*void */ RemoveAnnotations(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167506280452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                    if (a === null)
                    {
                        if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(this.annotations, type))
                        {
                            this.annotations = null;
                        }
                    }
                    else 
                    {
                        /*int*/ let i = 0, j = 0;
                        while(i < a.length)
                        {
                            /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if (!$.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(obj, type))
                            {
                                $.$$.System.Array.$WriteT1.call(a, obj, j++);
                            }
                            i++;
                        }
                        if (j === 0)
                        {
                            this.annotations = null;
                        }
                        else 
                        {
                            while(j < i)
                            {
                                $.$$.System.Array.$WriteT1.call(a, null, j++);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167506280452)
            
            //--TRIMMABLE-BOUNDARY-START(171801247748)
            /*void */ RemoveAnnotations$1(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801247748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$$.System.Object));
                    if (a === null)
                    {
                        if ($.$is(this.annotations, T))
                        {
                            this.annotations = null;
                        }
                    }
                    else 
                    {
                        /*int*/ let i = 0, j = 0;
                        while(i < a.length)
                        {
                            /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if (!($.$is(obj, T)))
                            {
                                $.$$.System.Array.$WriteT1.call(a, obj, j++);
                            }
                            i++;
                        }
                        if (j === 0)
                        {
                            this.annotations = null;
                        }
                        else 
                        {
                            while(j < i)
                            {
                                $.$$.System.Array.$WriteT1.call(a, null, j++);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171801247748)
            
            //--TRIMMABLE-BOUNDARY-START(64427065348)
            /*EventHandler<XObjectChangeEventArgs>*/ add_Changed(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887457796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    a = new $.$spxl.System.Xml.Linq.XObjectChangeAnnotation().$ctor$1();
                    this.AddAnnotation(a);
                }
                a.changed = $.$$.System.Delegate.Combine(a.changed, value);
            }
            /*EventHandler<XObjectChangeEventArgs>*/ remove_Changed(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621378564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    return;
                }
                a.changed = $.$$.System.Delegate.Remove(a.changed, value);
                if (a.changing === null && a.changed === null)
                {
                    this.RemoveAnnotations$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64427065348)
            
            //--TRIMMABLE-BOUNDARY-START(68722032644)
            /*EventHandler<XObjectChangeEventArgs>*/ add_Changing(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477392388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    a = new $.$spxl.System.Xml.Linq.XObjectChangeAnnotation().$ctor$1();
                    this.AddAnnotation(a);
                }
                a.changing = $.$$.System.Delegate.Combine(a.changing, value);
            }
            /*EventHandler<XObjectChangeEventArgs>*/ remove_Changing(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211313156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    return;
                }
                a.changing = $.$$.System.Delegate.Remove(a.changing, value);
                if (a.changing === null && a.changed === null)
                {
                    this.RemoveAnnotations$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68722032644)
            
            //--TRIMMABLE-BOUNDARY-START(206160986116)
            /*bool */ System$Xml$IXmlLineInfo$HasLineInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160986116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Annotation$1($.$spxl.System.Xml.Linq.LineInfoAnnotation) !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(206160986116)
            
            //--TRIMMABLE-BOUNDARY-START(210455953412)
            /*int */ get System$Xml$IXmlLineInfo$LineNumber()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193276084228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LineInfoAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.LineInfoAnnotation);
                if (a !== null)
                {
                    return a.lineNumber;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(210455953412)
            
            //--TRIMMABLE-BOUNDARY-START(214750920708)
            /*int */ get System$Xml$IXmlLineInfo$LinePosition()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201866018820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LineInfoAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.LineInfoAnnotation);
                if (a !== null)
                {
                    return a.linePosition;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(214750920708)
            
            //--TRIMMABLE-BOUNDARY-START(124556607492)
            /*bool */ get HasBaseUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786803716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Annotation$1($.$spxl.System.Xml.Linq.BaseUriAnnotation) !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(124556607492)
            
            //--TRIMMABLE-BOUNDARY-START(133146542084)
            /*bool */ NotifyChanged(/*object*/ sender, /*XObjectChangeEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146542084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let notify = false;
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        break;
                    }
                    /*XObjectChangeAnnotation?*/ let a = o.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                    if (a !== null)
                    {
                        notify = true;
                        a.changed?.Invoke(sender, e);
                    }
                    o = o.parent;
                }
                return notify;
            }
            //--TRIMMABLE-BOUNDARY-END(133146542084)
            
            //--TRIMMABLE-BOUNDARY-START(137441509380)
            /*bool */ NotifyChanging(/*object*/ sender, /*XObjectChangeEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441509380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let notify = false;
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        break;
                    }
                    /*XObjectChangeAnnotation?*/ let a = o.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                    if (a !== null)
                    {
                        notify = true;
                        a.changing?.Invoke(sender, e);
                    }
                    o = o.parent;
                }
                return notify;
            }
            //--TRIMMABLE-BOUNDARY-END(137441509380)
            
            //--TRIMMABLE-BOUNDARY-START(176096215044)
            /*void */ SetBaseUri(/*string*/ baseUri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096215044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddAnnotation(new $.$spxl.System.Xml.Linq.BaseUriAnnotation().$ctor$1(baseUri));
            }
            //--TRIMMABLE-BOUNDARY-END(176096215044)
            
            //--TRIMMABLE-BOUNDARY-START(180391182340)
            /*void */ SetLineInfo(/*int*/ lineNumber, /*int*/ linePosition)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391182340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddAnnotation(new $.$spxl.System.Xml.Linq.LineInfoAnnotation().$ctor$1(lineNumber, linePosition));
            }
            //--TRIMMABLE-BOUNDARY-END(180391182340)
            
            //--TRIMMABLE-BOUNDARY-START(184686149636)
            /*bool */ SkipNotify()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184686149636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        return true;
                    }
                    if (o.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation) !== null)
                    {
                        return false;
                    }
                    o = o.parent;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184686149636)
            
            //--TRIMMABLE-BOUNDARY-START(120261640196)
            /*SaveOptions */ GetSaveOptionsFromAnnotations()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261640196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        return 0/*SaveOptions.None*/;
                    }
                    /*object?*/ let saveOptions = o.AnnotationForSealedType($.$spxl.System.Xml.Linq.SaveOptions.$type);
                    if (saveOptions !== null)
                    {
                        return $.$cast(saveOptions, $.$spxl.System.Xml.Linq.SaveOptions);
                    }
                    o = o.parent;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120261640196)
            
            static $h = 2555908;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60132098052),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606934532,
        "f": 50331649
      },
      "n": "BaseUri",
      "d": 2555908,
      "h": 60132098052,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60132098052),
//--TRIMMABLE-BOUNDARY-START(73016999940),
    {
      "p": 1507332,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196869124,
        "f": 50331649
      },
      "n": "Document",
      "d": 2555908,
      "h": 73016999940,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016999940),
//--TRIMMABLE-BOUNDARY-START(128851574788),
    {
      "p": 52822019,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376738308,
        "f": 50331905
      },
      "n": "NodeType",
      "d": 2555908,
      "h": 128851574788,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(128851574788),
//--TRIMMABLE-BOUNDARY-START(146031443972),
    {
      "p": 1638404,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966672900,
        "f": 50331649
      },
      "n": "Parent",
      "d": 2555908,
      "h": 146031443972,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146031443972),
//--TRIMMABLE-BOUNDARY-START(210455953412),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193276084228,
        "f": 50331650
      },
      "n": "{13893635}.LineNumber",
      "o": "System$Xml$IXmlLineInfo$LineNumber",
      "d": 2555908,
      "h": 210455953412,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(210455953412),
//--TRIMMABLE-BOUNDARY-START(214750920708),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201866018820,
        "f": 50331650
      },
      "n": "{13893635}.LinePosition",
      "o": "System$Xml$IXmlLineInfo$LinePosition",
      "d": 2555908,
      "h": 214750920708,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(214750920708),
//--TRIMMABLE-BOUNDARY-START(124556607492),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786803716,
        "f": 50331656
      },
      "n": "HasBaseUri",
      "d": 2555908,
      "h": 124556607492,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(124556607492)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772359684),
    {
      "r": 65537,
      "p": [
        {
          "n": "annotation",
          "p": 131073
        }
      ],
      "n": "AddAnnotation",
      "d": 2555908,
      "h": 25772359684,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772359684),
//--TRIMMABLE-BOUNDARY-START(30067326980),
    {
      "r": 131073,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "Annotation",
      "d": 2555908,
      "h": 30067326980,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067326980),
//--TRIMMABLE-BOUNDARY-START(38657261572),
    {
      "r": 131073,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "AnnotationForSealedType",
      "d": 2555908,
      "h": 38657261572,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38657261572),
//--TRIMMABLE-BOUNDARY-START(34362294276),
    {
      "r": (T) => T.$h,
      "g": [
        "T"
      ],
      "n": "Annotation",
      "o": "@$1",
      "d": 2555908,
      "h": 34362294276,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(34362294276),
//--TRIMMABLE-BOUNDARY-START(47247196164),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "Annotations",
      "d": 2555908,
      "h": 47247196164,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47247196164),
//--TRIMMABLE-BOUNDARY-START(55837130756),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "AnnotationsIterator",
      "d": 2555908,
      "h": 55837130756,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55837130756),
//--TRIMMABLE-BOUNDARY-START(51542163460),
    {
      "r": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h,
      "g": [
        "T"
      ],
      "n": "Annotations",
      "o": "@$1",
      "d": 2555908,
      "h": 51542163460,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(51542163460),
//--TRIMMABLE-BOUNDARY-START(167506280452),
    {
      "r": 65537,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "RemoveAnnotations",
      "d": 2555908,
      "h": 167506280452,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167506280452),
//--TRIMMABLE-BOUNDARY-START(171801247748),
    {
      "r": 65537,
      "g": [
        "T"
      ],
      "n": "RemoveAnnotations",
      "o": "@$1",
      "d": 2555908,
      "h": 171801247748,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(171801247748),
//--TRIMMABLE-BOUNDARY-START(133146542084),
    {
      "r": 262145,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 2752516
        }
      ],
      "n": "NotifyChanged",
      "d": 2555908,
      "h": 133146542084,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(133146542084),
//--TRIMMABLE-BOUNDARY-START(137441509380),
    {
      "r": 262145,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 2752516
        }
      ],
      "n": "NotifyChanging",
      "d": 2555908,
      "h": 137441509380,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(137441509380),
//--TRIMMABLE-BOUNDARY-START(176096215044),
    {
      "r": 65537,
      "p": [
        {
          "n": "baseUri",
          "p": 1310721
        }
      ],
      "n": "SetBaseUri",
      "d": 2555908,
      "h": 176096215044,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(176096215044),
//--TRIMMABLE-BOUNDARY-START(180391182340),
    {
      "r": 65537,
      "p": [
        {
          "n": "lineNumber",
          "p": 655361
        },
        {
          "n": "linePosition",
          "p": 655361
        }
      ],
      "n": "SetLineInfo",
      "d": 2555908,
      "h": 180391182340,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(180391182340),
//--TRIMMABLE-BOUNDARY-START(184686149636),
    {
      "r": 262145,
      "n": "SkipNotify",
      "d": 2555908,
      "h": 184686149636,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(184686149636),
//--TRIMMABLE-BOUNDARY-START(120261640196),
    {
      "r": 983044,
      "n": "GetSaveOptionsFromAnnotations",
      "d": 2555908,
      "h": 120261640196,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(120261640196)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(141736476676),
    {
      "t": 1310724,
      "n": "parent",
      "d": 2555908,
      "h": 141736476676,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(141736476676),
//--TRIMMABLE-BOUNDARY-START(42952228868),
    {
      "t": 131073,
      "n": "annotations",
      "d": 2555908,
      "h": 42952228868,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(42952228868)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297523204),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2555908,
      "h": 4297523204,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297523204)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(64427065348),
    {
      "e": $.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h
          }
        ],
        "n": "add_Changed",
        "d": 2555908,
        "h": 12887457796,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h
          }
        ],
        "n": "remove_Changed",
        "d": 2555908,
        "h": 154621378564,
        "f": 285212673
      },
      "n": "Changed",
      "d": 2555908,
      "h": 64427065348,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(64427065348),
//--TRIMMABLE-BOUNDARY-START(68722032644),
    {
      "e": $.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h
          }
        ],
        "n": "add_Changing",
        "d": 2555908,
        "h": 21477392388,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h
          }
        ],
        "n": "remove_Changing",
        "d": 2555908,
        "h": 163211313156,
        "f": 285212673
      },
      "n": "Changing",
      "d": 2555908,
      "h": 68722032644,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(68722032644)
  ],
  "i": [13893635
  ],
  "h": 2555908
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XObject`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2555908)
        
        
        //--TRIMMABLE-BOUNDARY-START(2228228)
        $asm.$cls("$spxl.System.Xml.Linq.XNode", ($self) => class XNode extends $.$spxl.System.Xml.Linq.XObject
        {
            //--TRIMMABLE-BOUNDARY-START(171800920068)
            /*XNode?*/ next = null;
            //--TRIMMABLE-BOUNDARY-END(171800920068)
            
            //--TRIMMABLE-BOUNDARY-START(12887130116)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887130116);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887130116)
            
            //--TRIMMABLE-BOUNDARY-START(176095887364)
            /*XNode? */ get NextNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261312516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.parent === null || this === this.parent.content ? null : this.next;
            }
            //--TRIMMABLE-BOUNDARY-END(176095887364)
            
            //--TRIMMABLE-BOUNDARY-START(188980789252)
            /*XNode? */ get PreviousNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851247108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.parent === null)
                {
                    return null;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this.parent.content !== null, "parent.content != null");
                /*XNode*/ let n = ($.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode)).next;
                /*XNode?*/ let p = null;
                while(n !== this)
                {
                    p = n;
                    n = n.next;
                }
                return p;
            }
            //--TRIMMABLE-BOUNDARY-END(188980789252)
            
            //--TRIMMABLE-BOUNDARY-START(73016672260)
            /*XNodeDocumentOrderComparer*/ static DocumentOrderComparer$ = null;
            static /*XNodeDocumentOrderComparer */ get DocumentOrderComparer()
            {
                return $.$spxl.System.Xml.Linq.XNode.DocumentOrderComparer$ ??= new $.$spxl.System.Xml.Linq.XNodeDocumentOrderComparer().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(73016672260)
            
            //--TRIMMABLE-BOUNDARY-START(94491508740)
            /*XNodeEqualityComparer*/ static EqualityComparer$ = null;
            static /*XNodeEqualityComparer */ get EqualityComparer()
            {
                return $.$spxl.System.Xml.Linq.XNode.EqualityComparer$ ??= new $.$spxl.System.Xml.Linq.XNodeEqualityComparer().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(94491508740)
            
            //--TRIMMABLE-BOUNDARY-START(17182097412)
            /*void */ AddAfterSelf(/*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182097412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.parent === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$3(this.parent, this).Add(content);
            }
            //--TRIMMABLE-BOUNDARY-END(17182097412)
            
            //--TRIMMABLE-BOUNDARY-START(21477064708)
            /*void */ AddAfterSelf$1(/*params object?[]*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477064708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddAfterSelf($.$cast(content, $.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(21477064708)
            
            //--TRIMMABLE-BOUNDARY-START(25772032004)
            /*void */ AddBeforeSelf(/*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772032004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.parent === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                /*XNode?*/ let p = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                while(p.next !== this)
                {
                    p = p.next;
                }
                if (p === this.parent.content)
                {
                    p = null;
                }
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$3(this.parent, p).Add(content);
            }
            //--TRIMMABLE-BOUNDARY-END(25772032004)
            
            //--TRIMMABLE-BOUNDARY-START(30066999300)
            /*void */ AddBeforeSelf$1(/*params object?[]*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066999300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddBeforeSelf($.$cast(content, $.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(30066999300)
            
            //--TRIMMABLE-BOUNDARY-START(34361966596)
            /*IEnumerable<XElement> */ Ancestors()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361966596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAncestors(null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(34361966596)
            
            //--TRIMMABLE-BOUNDARY-START(38656933892)
            /*IEnumerable<XElement> */ Ancestors$1(/*XName?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656933892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetAncestors(name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            //--TRIMMABLE-BOUNDARY-END(38656933892)
            
            //--TRIMMABLE-BOUNDARY-START(51541835780)
            static /*int */ CompareDocumentOrder(/*XNode?*/ n1, /*XNode?*/ n2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541835780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (n1 === n2)
                {
                    return 0;
                }
                if (n1 === null)
                {
                    return -1;
                }
                if (n2 === null)
                {
                    return 1;
                }
                if (n1.parent !== n2.parent)
                {
                    /*int*/ let height = 0;
                    /*XNode*/ let p1 = n1;
                    while(p1.parent !== null)
                    {
                        p1 = p1.parent;
                        height++;
                    }
                    /*XNode*/ let p2 = n2;
                    while(p2.parent !== null)
                    {
                        p2 = p2.parent;
                        height--;
                    }
                    if (p1 !== p2)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingAncestor);
                    }
                    if (height < 0)
                    {
                        do
                        {
                            n2 = n2.parent;
                            height++;
                        }
                        while(height !== 0);
                        if (n1 === n2)
                        {
                            return -1;
                        }
                    }
                    else if (height > 0)
                    {
                        do
                        {
                            n1 = n1.parent;
                            height--;
                        }
                        while(height !== 0);
                        if (n1 === n2)
                        {
                            return 1;
                        }
                    }
                    while(n1.parent !== n2.parent)
                    {
                        n1 = n1.parent;
                        n2 = n2.parent;
                    }
                }
                else if (n1.parent === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingAncestor);
                }
                /*XNode*/ let n = $.$cast(n1.parent.content, $.$spxl.System.Xml.Linq.XNode);
                while(true)
                {
                    n = n.next;
                    if (n === n1)
                    {
                        return -1;
                    }
                    if (n === n2)
                    {
                        return 1;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541835780)
            
            //--TRIMMABLE-BOUNDARY-START(55836803076)
            /*XmlReader */ CreateReader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836803076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$spxl.System.Xml.Linq.XNodeReader().$ctor$3(this, null);
            }
            //--TRIMMABLE-BOUNDARY-END(55836803076)
            
            //--TRIMMABLE-BOUNDARY-START(60131770372)
            /*XmlReader */ CreateReader$1(/*ReaderOptions*/ readerOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131770372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$spxl.System.Xml.Linq.XNodeReader().$ctor$2(this, null, readerOptions);
            }
            //--TRIMMABLE-BOUNDARY-END(60131770372)
            
            //--TRIMMABLE-BOUNDARY-START(180390854660)
            /*IEnumerable<XNode> */ NodesAfterSelf()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*XNode*/ let n = this;
                    while(n.parent !== null && n !== n.parent.content)
                    {
                        n = n.next;
                        yield n;
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(180390854660)
            
            //--TRIMMABLE-BOUNDARY-START(184685821956)
            /*IEnumerable<XNode> */ NodesBeforeSelf()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (this.parent !== null)
                    {
                        /*XNode*/ let n = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                        do
                        {
                            n = n.next;
                            if (n === this)
                            {
                                break;
                            }
                            yield n;
                        }
                        while(this.parent !== null && this.parent === n.parent);
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(184685821956)
            
            //--TRIMMABLE-BOUNDARY-START(77311639556)
            /*IEnumerable<XElement> */ ElementsAfterSelf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311639556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetElementsAfterSelf(null);
            }
            //--TRIMMABLE-BOUNDARY-END(77311639556)
            
            //--TRIMMABLE-BOUNDARY-START(81606606852)
            /*IEnumerable<XElement> */ ElementsAfterSelf$1(/*XName?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606606852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetElementsAfterSelf(name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            //--TRIMMABLE-BOUNDARY-END(81606606852)
            
            //--TRIMMABLE-BOUNDARY-START(85901574148)
            /*IEnumerable<XElement> */ ElementsBeforeSelf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901574148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetElementsBeforeSelf(null);
            }
            //--TRIMMABLE-BOUNDARY-END(85901574148)
            
            //--TRIMMABLE-BOUNDARY-START(90196541444)
            /*IEnumerable<XElement> */ ElementsBeforeSelf$1(/*XName?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196541444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetElementsBeforeSelf(name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            //--TRIMMABLE-BOUNDARY-END(90196541444)
            
            //--TRIMMABLE-BOUNDARY-START(163210985476)
            /*bool */ IsAfter(/*XNode?*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210985476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XNode.CompareDocumentOrder(this, node) > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(163210985476)
            
            //--TRIMMABLE-BOUNDARY-START(167505952772)
            /*bool */ IsBefore(/*XNode?*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505952772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XNode.CompareDocumentOrder(this, node) < 0;
            }
            //--TRIMMABLE-BOUNDARY-END(167505952772)
            
            //--TRIMMABLE-BOUNDARY-START(193275756548)
            static /*XNode */ ReadFrom(/*XmlReader*/ reader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275756548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                if (reader.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                let $switch1 = reader.NodeType;
                switch($switch1)
                {
                    case 3/*XmlNodeType.Text*/:
                    case 14/*XmlNodeType.SignificantWhitespace*/:
                    case 13/*XmlNodeType.Whitespace*/:
                    return new $.$spxl.System.Xml.Linq.XText().$ctor$4(reader);
                    case 4/*XmlNodeType.CDATA*/:
                    return new $.$spxl.System.Xml.Linq.XCData().$ctor$7(reader);
                    case 8/*XmlNodeType.Comment*/:
                    return new $.$spxl.System.Xml.Linq.XComment().$ctor$4(reader);
                    case 10/*XmlNodeType.DocumentType*/:
                    return new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$4(reader);
                    case 1/*XmlNodeType.Element*/:
                    return new $.$spxl.System.Xml.Linq.XElement().$ctor$7(reader);
                    case 7/*XmlNodeType.ProcessingInstruction*/:
                    return new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$4(reader);
                    default:
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193275756548)
            
            //--TRIMMABLE-BOUNDARY-START(197570723844)
            static /*Task<XNode> */ ReadFromAsync(/*XmlReader*/ reader, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570723844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$3($.$spxl.System.Xml.Linq.XNode, cancellationToken);
                }
                return $.$spxl.System.Xml.Linq.XNode.ReadFromAsyncInternal(reader, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(197570723844)
            
            //--TRIMMABLE-BOUNDARY-START(201865691140)
            static /*Task<XNode> *//*async*/  ReadFromAsyncInternal(/*XmlReader*/ reader, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XNode), $.$spxl.System.Xml.Linq.XNode, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201865691140);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (reader.ReadState !== 1/*ReadState.Interactive*/)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                    }
                    /*XNode*/ let ret;
                    let $switch1 = reader.NodeType;
                    switch($switch1)
                    {
                        case 3/*XmlNodeType.Text*/:
                        case 14/*XmlNodeType.SignificantWhitespace*/:
                        case 13/*XmlNodeType.Whitespace*/:
                        ret = new $.$spxl.System.Xml.Linq.XText().$ctor$3(reader.Value);
                        break;
                        case 4/*XmlNodeType.CDATA*/:
                        ret = new $.$spxl.System.Xml.Linq.XCData().$ctor$6(reader.Value);
                        break;
                        case 8/*XmlNodeType.Comment*/:
                        ret = new $.$spxl.System.Xml.Linq.XComment().$ctor$3(reader.Value);
                        break;
                        case 10/*XmlNodeType.DocumentType*/:
                        /*var*/ let name = reader.Name;
                        /*var*/ let publicId = reader.GetAttribute$2("PUBLIC");
                        /*var*/ let systemId = reader.GetAttribute$2("SYSTEM");
                        /*var*/ let internalSubset = reader.Value;
                        ret = new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(name, publicId, systemId, internalSubset);
                        break;
                        case 1/*XmlNodeType.Element*/:
                        return await $.$spxl.System.Xml.Linq.XElement.CreateAsync(reader, cancellationToken).ConfigureAwait$2(false);
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        /*var*/ let target = reader.Name;
                        /*var*/ let data = reader.Value;
                        ret = new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(target, data);
                        break;
                        default:
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                    }
                    cancellationToken.ThrowIfCancellationRequested();
                    await reader.ReadAsync().ConfigureAwait$2(false);
                    return ret;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(201865691140)
            
            //--TRIMMABLE-BOUNDARY-START(206160658436)
            /*void */ Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160658436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.parent === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                this.parent.RemoveNode(this);
            }
            //--TRIMMABLE-BOUNDARY-END(206160658436)
            
            //--TRIMMABLE-BOUNDARY-START(210455625732)
            /*void */ ReplaceWith(/*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455625732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.parent === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                /*XContainer*/ let c = this.parent;
                /*XNode?*/ let p = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                while(p.next !== this)
                {
                    p = p.next;
                }
                if (p === this.parent.content)
                {
                    p = null;
                }
                this.parent.RemoveNode(this);
                if (p !== null && p.parent !== c)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$3(c, p).Add(content);
            }
            //--TRIMMABLE-BOUNDARY-END(210455625732)
            
            //--TRIMMABLE-BOUNDARY-START(214750593028)
            /*void */ ReplaceWith$1(/*params object?[]*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750593028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ReplaceWith($.$cast(content, $.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(214750593028)
            
            //--TRIMMABLE-BOUNDARY-START(219045560324)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045560324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetXmlString(this.GetSaveOptionsFromAnnotations());
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XNode.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(219045560324)
            
            //--TRIMMABLE-BOUNDARY-START(223340527620)
            /*string */ ToString$1(/*SaveOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340527620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetXmlString(options);
            }
            //--TRIMMABLE-BOUNDARY-END(223340527620)
            
            //--TRIMMABLE-BOUNDARY-START(64426737668)
            static /*bool */ DeepEquals(/*XNode?*/ n1, /*XNode?*/ n2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426737668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (n1 === n2)
                {
                    return true;
                }
                if (n1 === null || n2 === null)
                {
                    return false;
                }
                return n1.DeepEquals$1(n2);
            }
            //--TRIMMABLE-BOUNDARY-END(64426737668)
            
            //--TRIMMABLE-BOUNDARY-START(42951901188)
            /*void */ AppendText(/*StringBuilder*/ sb)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951901188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42951901188)
            
            //--TRIMMABLE-BOUNDARY-START(133146214404)
            /*IEnumerable<XElement> */ GetAncestors(/*XName?*/ name, /*bool*/ self)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*XElement?*/ let e = $.$as((self ? this : this.parent), $.$spxl.System.Xml.Linq.XElement);
                    while(e !== null)
                    {
                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                        {
                            yield e;
                        }
                        e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(133146214404)
            
            //--TRIMMABLE-BOUNDARY-START(141736148996)
            /*IEnumerable<XElement> */ GetElementsAfterSelf(/*XName?*/ name)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*XNode*/ let n = this;
                    while(n.parent !== null && n !== n.parent.content)
                    {
                        n = n.next;
                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                        {
                            yield e;
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(141736148996)
            
            //--TRIMMABLE-BOUNDARY-START(146031116292)
            /*IEnumerable<XElement> */ GetElementsBeforeSelf(/*XName?*/ name)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (this.parent !== null)
                    {
                        /*XNode*/ let n = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                        do
                        {
                            n = n.next;
                            if (n === this)
                            {
                                break;
                            }
                            /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                            if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                            {
                                yield e;
                            }
                        }
                        while(this.parent !== null && this.parent === n.parent);
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(146031116292)
            
            //--TRIMMABLE-BOUNDARY-START(150326083588)
            static /*XmlReaderSettings */ GetXmlReaderSettings(/*LoadOptions*/ o)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326083588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlReaderSettings*/ let rs = new $.$spx.System.Xml.XmlReaderSettings().$ctor$1();
                if ((o & 1/*LoadOptions.PreserveWhitespace*/) === 0)
                {
                    rs.IgnoreWhitespace = true;
                }
                rs.DtdProcessing = $.$cast(2, $.$spx.System.Xml.DtdProcessing);
                rs.MaxCharactersFromEntities = $.$cast(10000000n, $.$$.System.Int64);
                return rs;
            }
            //--TRIMMABLE-BOUNDARY-END(150326083588)
            
            //--TRIMMABLE-BOUNDARY-START(158916018180)
            static /*XmlWriterSettings */ GetXmlWriterSettings(/*SaveOptions*/ o)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158916018180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                if ((o & 1/*SaveOptions.DisableFormatting*/) === 0)
                {
                    ws.Indent = true;
                }
                if ((o & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0)
                {
                    ws.NamespaceHandling |= 1/*NamespaceHandling.OmitDuplicates*/;
                }
                return ws;
            }
            //--TRIMMABLE-BOUNDARY-END(158916018180)
            
            //--TRIMMABLE-BOUNDARY-START(154621050884)
            /*string */ GetXmlString(/*SaveOptions*/ o)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621050884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let sw = null;
                try
                {
                    sw = new $.$$.System.IO.StringWriter().$ctor$5($.$$.System.Globalization.CultureInfo.InvariantCulture);
                    /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                    ws.OmitXmlDeclaration = true;
                    if ((o & 1/*SaveOptions.DisableFormatting*/) === 0)
                    {
                        ws.Indent = true;
                    }
                    if ((o & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0)
                    {
                        ws.NamespaceHandling |= 1/*NamespaceHandling.OmitDuplicates*/;
                    }
                    if ($.$is(this, $.$spxl.System.Xml.Linq.XText))
                    {
                        ws.ConformanceLevel = 1/*ConformanceLevel.Fragment*/;
                    }
                    let w = null;
                    try
                    {
                        w = $.$spx.System.Xml.XmlWriter.Create$2(sw, ws);
                        /*XDocument?*/ let n = $.$as(this, $.$spxl.System.Xml.Linq.XDocument);
                        if (n !== null)
                        {
                            n.WriteContentTo(w);
                        }
                        else 
                        {
                            this.WriteTo(w);
                        }
                    }
                    finally
                    {
                        w?.System$IDisposable$Dispose();
                    }
                    return $.$$.System.IO.StringWriter.ToString.call(sw);
                }
                finally
                {
                    sw?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154621050884)
            
            static $h = 2228228;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2555908,
  "p": [
//--TRIMMABLE-BOUNDARY-START(176095887364),
    {
      "p": 2228228,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261312516,
        "f": 50331649
      },
      "n": "NextNode",
      "d": 2228228,
      "h": 176095887364,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176095887364),
//--TRIMMABLE-BOUNDARY-START(188980789252),
    {
      "p": 2228228,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128851247108,
        "f": 50331649
      },
      "n": "PreviousNode",
      "d": 2228228,
      "h": 188980789252,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188980789252),
//--TRIMMABLE-BOUNDARY-START(73016672260),
    {
      "p": 2359300,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081443332,
        "f": 50331681
      },
      "n": "DocumentOrderComparer",
      "d": 2228228,
      "h": 73016672260,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(73016672260),
//--TRIMMABLE-BOUNDARY-START(94491508740),
    {
      "p": 2424836,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671377924,
        "f": 50331681
      },
      "n": "EqualityComparer",
      "d": 2228228,
      "h": 94491508740,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(94491508740)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182097412),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "AddAfterSelf",
      "d": 2228228,
      "h": 17182097412,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182097412),
//--TRIMMABLE-BOUNDARY-START(21477064708),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "AddAfterSelf",
      "o": "@$1",
      "d": 2228228,
      "h": 21477064708,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477064708),
//--TRIMMABLE-BOUNDARY-START(25772032004),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "AddBeforeSelf",
      "d": 2228228,
      "h": 25772032004,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772032004),
//--TRIMMABLE-BOUNDARY-START(30066999300),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "AddBeforeSelf",
      "o": "@$1",
      "d": 2228228,
      "h": 30066999300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066999300),
//--TRIMMABLE-BOUNDARY-START(34361966596),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "n": "Ancestors",
      "d": 2228228,
      "h": 34361966596,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361966596),
//--TRIMMABLE-BOUNDARY-START(38656933892),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "Ancestors",
      "o": "@$1",
      "d": 2228228,
      "h": 38656933892,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656933892),
//--TRIMMABLE-BOUNDARY-START(51541835780),
    {
      "r": 655361,
      "p": [
        {
          "n": "n1",
          "p": 2228228
        },
        {
          "n": "n2",
          "p": 2228228
        }
      ],
      "n": "CompareDocumentOrder",
      "d": 2228228,
      "h": 51541835780,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51541835780),
//--TRIMMABLE-BOUNDARY-START(55836803076),
    {
      "r": 53346307,
      "n": "CreateReader",
      "d": 2228228,
      "h": 55836803076,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836803076),
//--TRIMMABLE-BOUNDARY-START(60131770372),
    {
      "r": 53346307,
      "p": [
        {
          "n": "readerOptions",
          "p": 917508
        }
      ],
      "n": "CreateReader",
      "o": "@$1",
      "d": 2228228,
      "h": 60131770372,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131770372),
//--TRIMMABLE-BOUNDARY-START(180390854660),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,
      "n": "NodesAfterSelf",
      "d": 2228228,
      "h": 180390854660,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180390854660),
//--TRIMMABLE-BOUNDARY-START(184685821956),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,
      "n": "NodesBeforeSelf",
      "d": 2228228,
      "h": 184685821956,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184685821956),
//--TRIMMABLE-BOUNDARY-START(77311639556),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "n": "ElementsAfterSelf",
      "d": 2228228,
      "h": 77311639556,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311639556),
//--TRIMMABLE-BOUNDARY-START(81606606852),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "ElementsAfterSelf",
      "o": "@$1",
      "d": 2228228,
      "h": 81606606852,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81606606852),
//--TRIMMABLE-BOUNDARY-START(85901574148),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "n": "ElementsBeforeSelf",
      "d": 2228228,
      "h": 85901574148,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85901574148),
//--TRIMMABLE-BOUNDARY-START(90196541444),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "ElementsBeforeSelf",
      "o": "@$1",
      "d": 2228228,
      "h": 90196541444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90196541444),
//--TRIMMABLE-BOUNDARY-START(163210985476),
    {
      "r": 262145,
      "p": [
        {
          "n": "node",
          "p": 2228228
        }
      ],
      "n": "IsAfter",
      "d": 2228228,
      "h": 163210985476,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163210985476),
//--TRIMMABLE-BOUNDARY-START(167505952772),
    {
      "r": 262145,
      "p": [
        {
          "n": "node",
          "p": 2228228
        }
      ],
      "n": "IsBefore",
      "d": 2228228,
      "h": 167505952772,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167505952772),
//--TRIMMABLE-BOUNDARY-START(193275756548),
    {
      "r": 2228228,
      "p": [
        {
          "n": "reader",
          "p": 53346307
        }
      ],
      "n": "ReadFrom",
      "d": 2228228,
      "h": 193275756548,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(193275756548),
//--TRIMMABLE-BOUNDARY-START(197570723844),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XNode).$h,
      "p": [
        {
          "n": "reader",
          "p": 53346307
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadFromAsync",
      "d": 2228228,
      "h": 197570723844,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(197570723844),
//--TRIMMABLE-BOUNDARY-START(201865691140),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XNode).$h,
      "p": [
        {
          "n": "reader",
          "p": 53346307
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadFromAsyncInternal",
      "d": 2228228,
      "h": 201865691140,
      "f": 16781346
    },
//--TRIMMABLE-BOUNDARY-END(201865691140),
//--TRIMMABLE-BOUNDARY-START(206160658436),
    {
      "r": 65537,
      "n": "Remove",
      "d": 2228228,
      "h": 206160658436,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(206160658436),
//--TRIMMABLE-BOUNDARY-START(210455625732),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "ReplaceWith",
      "d": 2228228,
      "h": 210455625732,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210455625732),
//--TRIMMABLE-BOUNDARY-START(214750593028),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "ReplaceWith",
      "o": "@$1",
      "d": 2228228,
      "h": 214750593028,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214750593028),
//--TRIMMABLE-BOUNDARY-START(219045560324),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2228228,
      "h": 219045560324,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(219045560324),
//--TRIMMABLE-BOUNDARY-START(223340527620),
    {
      "r": 1310721,
      "p": [
        {
          "n": "options",
          "p": 983044
        }
      ],
      "n": "ToString",
      "o": "@$1",
      "d": 2228228,
      "h": 223340527620,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223340527620),
//--TRIMMABLE-BOUNDARY-START(64426737668),
    {
      "r": 262145,
      "p": [
        {
          "n": "n1",
          "p": 2228228
        },
        {
          "n": "n2",
          "p": 2228228
        }
      ],
      "n": "DeepEquals",
      "d": 2228228,
      "h": 64426737668,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64426737668),
//--TRIMMABLE-BOUNDARY-START(227635494916),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        }
      ],
      "n": "WriteTo",
      "d": 2228228,
      "h": 227635494916,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(227635494916),
//--TRIMMABLE-BOUNDARY-START(231930462212),
    {
      "r": 177668097,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteToAsync",
      "d": 2228228,
      "h": 231930462212,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(231930462212),
//--TRIMMABLE-BOUNDARY-START(42951901188),
    {
      "r": 65537,
      "p": [
        {
          "n": "sb",
          "p": 167051265
        }
      ],
      "n": "AppendText",
      "d": 2228228,
      "h": 42951901188,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(42951901188),
//--TRIMMABLE-BOUNDARY-START(47246868484),
    {
      "r": 2228228,
      "n": "CloneNode",
      "d": 2228228,
      "h": 47246868484,
      "f": 16777480
    },
//--TRIMMABLE-BOUNDARY-END(47246868484),
//--TRIMMABLE-BOUNDARY-START(68721704964),
    {
      "r": 262145,
      "p": [
        {
          "n": "node",
          "p": 2228228
        }
      ],
      "n": "DeepEquals",
      "o": "@$1",
      "d": 2228228,
      "h": 68721704964,
      "f": 16777480
    },
//--TRIMMABLE-BOUNDARY-END(68721704964),
//--TRIMMABLE-BOUNDARY-START(133146214404),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "name",
          "p": 2097156
        },
        {
          "n": "self",
          "p": 262145
        }
      ],
      "n": "GetAncestors",
      "d": 2228228,
      "h": 133146214404,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(133146214404),
//--TRIMMABLE-BOUNDARY-START(141736148996),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "GetElementsAfterSelf",
      "d": 2228228,
      "h": 141736148996,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141736148996),
//--TRIMMABLE-BOUNDARY-START(146031116292),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "GetElementsBeforeSelf",
      "d": 2228228,
      "h": 146031116292,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(146031116292),
//--TRIMMABLE-BOUNDARY-START(137441181700),
    {
      "r": 655361,
      "n": "GetDeepHashCode",
      "d": 2228228,
      "h": 137441181700,
      "f": 16777480
    },
//--TRIMMABLE-BOUNDARY-END(137441181700),
//--TRIMMABLE-BOUNDARY-START(150326083588),
    {
      "r": 53477379,
      "p": [
        {
          "n": "o",
          "p": 655364
        }
      ],
      "n": "GetXmlReaderSettings",
      "d": 2228228,
      "h": 150326083588,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(150326083588),
//--TRIMMABLE-BOUNDARY-START(158916018180),
    {
      "r": 58458115,
      "p": [
        {
          "n": "o",
          "p": 983044
        }
      ],
      "n": "GetXmlWriterSettings",
      "d": 2228228,
      "h": 158916018180,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(158916018180),
//--TRIMMABLE-BOUNDARY-START(154621050884),
    {
      "r": 1310721,
      "p": [
        {
          "n": "o",
          "p": 983044
        }
      ],
      "n": "GetXmlString",
      "d": 2228228,
      "h": 154621050884,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(154621050884)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(171800920068),
    {
      "t": 2228228,
      "n": "next",
      "d": 2228228,
      "h": 171800920068,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(171800920068)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887130116),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2228228,
      "h": 12887130116,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12887130116)
  ],
  "i": [13893635
  ],
  "h": 2228228
}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XObject; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XNode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228228)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310724)
        $asm.$cls("$spxl.System.Xml.Linq.XContainer", ($self) => class XContainer extends $.$spxl.System.Xml.Linq.XNode
        {
            //--TRIMMABLE-BOUNDARY-START(85900656644)
            /*object?*/ content = null;
            //--TRIMMABLE-BOUNDARY-END(85900656644)
            
            //--TRIMMABLE-BOUNDARY-START(8591245316)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591245316);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591245316)
            
            //--TRIMMABLE-BOUNDARY-START(12886212612)
            $ctor$4(/*XContainer*/ other)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886212612);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    if ($.$is(other.content, $.$$.System.String))
                    {
                        this.content = other.content;
                    }
                    else 
                    {
                        /*XNode?*/ let n = $.$cast(other.content, $.$spxl.System.Xml.Linq.XNode);
                        if (n !== null)
                        {
                            do
                            {
                                n = n.next;
                                this.AppendNodeSkipNotify(n.CloneNode());
                            }
                            while(n !== other.content);
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886212612)
            
            //--TRIMMABLE-BOUNDARY-START(133145296900)
            /*XNode? */ get FirstNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735231492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LastNode?.next ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(133145296900)
            
            //--TRIMMABLE-BOUNDARY-START(180389937156)
            /*XNode? */ get LastNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325166084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.content === null)
                {
                    return null;
                }
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    return n;
                }
                /*string?*/ let s = $.$as(this.content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    if (s.length === 0)
                    {
                        return null;
                    }
                    /*XText*/ let t = new $.$spxl.System.Xml.Linq.XText().$ctor$3(s);
                    t.parent = this;
                    t.next = t;
                    $.$$.System.Threading.Interlocked.CompareExchange$6($.$ref(() => this.content, ($v) => this.content = $v, $.$$.System.Object), t, s);
                }
                return $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
            }
            //--TRIMMABLE-BOUNDARY-END(180389937156)
            
            //--TRIMMABLE-BOUNDARY-START(17181179908)
            /*void */ Add(/*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181179908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.SkipNotify())
                {
                    this.AddContentSkipNotify(content);
                    return;
                }
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.AddNode(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    this.AddString(s);
                    return;
                }
                /*XAttribute?*/ let a = $.$as(content, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    this.AddAttribute(a);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$13(x));
                    return;
                }
                /*object?[]?*/ let o = $.$as(content, $.$typeArray($.$$.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.Add(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$$.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$IEnumerable$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$IEnumerator$Current;
                        {
                            this.Add(obj);
                        }
                    }
                    return;
                }
                this.AddString($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            //--TRIMMABLE-BOUNDARY-END(17181179908)
            
            //--TRIMMABLE-BOUNDARY-START(21476147204)
            /*void */ Add$1(/*params object?[]*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476147204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Add($.$cast(content, $.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(21476147204)
            
            //--TRIMMABLE-BOUNDARY-START(42950983684)
            /*void */ AddFirst(/*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950983684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$3(this, null).Add(content);
            }
            //--TRIMMABLE-BOUNDARY-END(42950983684)
            
            //--TRIMMABLE-BOUNDARY-START(47245950980)
            /*void */ AddFirst$1(/*params object?[]*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245950980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddFirst($.$cast(content, $.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(47245950980)
            
            //--TRIMMABLE-BOUNDARY-START(103080525828)
            /*XmlWriter */ CreateWriter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080525828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlWriterSettings*/ let settings = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                settings.ConformanceLevel = $.$is(this, $.$spxl.System.Xml.Linq.XDocument) ? 2/*ConformanceLevel.Document*/ : 1/*ConformanceLevel.Fragment*/;
                return $.$spx.System.Xml.XmlWriter.Create$8(new $.$spxl.System.Xml.Linq.XNodeBuilder().$ctor$2(this), settings);
            }
            //--TRIMMABLE-BOUNDARY-END(103080525828)
            
            //--TRIMMABLE-BOUNDARY-START(107375493124)
            /*IEnumerable<XNode> */ DescendantNodes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375493124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDescendantNodes(false);
            }
            //--TRIMMABLE-BOUNDARY-END(107375493124)
            
            //--TRIMMABLE-BOUNDARY-START(111670460420)
            /*IEnumerable<XElement> */ Descendants()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670460420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDescendants(null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(111670460420)
            
            //--TRIMMABLE-BOUNDARY-START(115965427716)
            /*IEnumerable<XElement> */ Descendants$1(/*XName?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965427716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetDescendants(name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            //--TRIMMABLE-BOUNDARY-END(115965427716)
            
            //--TRIMMABLE-BOUNDARY-START(120260395012)
            /*XElement? */ Element(/*XName*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260395012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (e !== null && $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                        {
                            return e;
                        }
                    }
                    while(n !== this.content);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(120260395012)
            
            //--TRIMMABLE-BOUNDARY-START(124555362308)
            /*IEnumerable<XElement> */ Elements()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555362308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetElements(null);
            }
            //--TRIMMABLE-BOUNDARY-END(124555362308)
            
            //--TRIMMABLE-BOUNDARY-START(128850329604)
            /*IEnumerable<XElement> */ Elements$1(/*XName?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850329604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetElements(name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            //--TRIMMABLE-BOUNDARY-END(128850329604)
            
            //--TRIMMABLE-BOUNDARY-START(184684904452)
            /*IEnumerable<XNode> */ Nodes()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*XNode?*/ let n = this.LastNode;
                    if (n !== null)
                    {
                        do
                        {
                            n = n.next;
                            yield n;
                        }
                        while(n.parent === this && n !== this.content);
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(184684904452)
            
            //--TRIMMABLE-BOUNDARY-START(210454708228)
            /*void */ RemoveNodes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454708228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.SkipNotify())
                {
                    this.RemoveNodesSkipNotify();
                    return;
                }
                while(this.content !== null)
                {
                    /*string?*/ let s = $.$as(this.content, $.$$.System.String);
                    if ($.$$.System.String.op_Inequality(s, null))
                    {
                        if (s.length > 0)
                        {
                            this.ConvertTextToNode();
                        }
                        else 
                        {
                            if ($.$is(this, $.$spxl.System.Xml.Linq.XElement))
                            {
                                this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                                if (s !== this.content)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                                }
                                this.content = null;
                                this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                            }
                            else 
                            {
                                this.content = null;
                            }
                        }
                    }
                    /*XNode?*/ let last = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                    if (last !== null)
                    {
                        /*XNode*/ let n = last.next;
                        this.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                        if (last !== this.content || n !== last.next)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                        }
                        if (n !== last)
                        {
                            last.next = n.next;
                        }
                        else 
                        {
                            this.content = null;
                        }
                        n.parent = null;
                        n.next = null;
                        this.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(210454708228)
            
            //--TRIMMABLE-BOUNDARY-START(219044642820)
            /*void */ ReplaceNodes(/*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044642820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                content = $.$spxl.System.Xml.Linq.XContainer.GetContentSnapshot(content);
                this.RemoveNodes();
                this.Add(content);
            }
            //--TRIMMABLE-BOUNDARY-END(219044642820)
            
            //--TRIMMABLE-BOUNDARY-START(223339610116)
            /*void */ ReplaceNodes$1(/*params object?[]*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339610116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ReplaceNodes($.$cast(content, $.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(223339610116)
            
            //--TRIMMABLE-BOUNDARY-START(25771114500)
            /*void */ AddAttribute(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771114500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25771114500)
            
            //--TRIMMABLE-BOUNDARY-START(30066081796)
            /*void */ AddAttributeSkipNotify(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066081796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30066081796)
            
            //--TRIMMABLE-BOUNDARY-START(34361049092)
            /*void */ AddContentSkipNotify(/*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361049092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.AddNodeSkipNotify(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    this.AddStringSkipNotify(s);
                    return;
                }
                /*XAttribute?*/ let a = $.$as(content, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    this.AddAttributeSkipNotify(a);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XElement().$ctor$13(x));
                    return;
                }
                /*object?[]?*/ let o = $.$as(content, $.$typeArray($.$$.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.AddContentSkipNotify(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$$.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$IEnumerable$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$IEnumerator$Current;
                        {
                            this.AddContentSkipNotify(obj);
                        }
                    }
                    return;
                }
                this.AddStringSkipNotify($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            //--TRIMMABLE-BOUNDARY-END(34361049092)
            
            //--TRIMMABLE-BOUNDARY-START(51540918276)
            /*void */ AddNode(/*XNode*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540918276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateNode(n, this);
                if (n.parent !== null)
                {
                    n = n.CloneNode();
                }
                else 
                {
                    /*XNode*/ let p = this;
                    while(p.parent !== null)
                    {
                        p = p.parent;
                    }
                    if (n === p)
                    {
                        n = n.CloneNode();
                    }
                }
                this.ConvertTextToNode();
                this.AppendNode(n);
            }
            //--TRIMMABLE-BOUNDARY-END(51540918276)
            
            //--TRIMMABLE-BOUNDARY-START(55835885572)
            /*void */ AddNodeSkipNotify(/*XNode*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835885572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateNode(n, this);
                if (n.parent !== null)
                {
                    n = n.CloneNode();
                }
                else 
                {
                    /*XNode*/ let p = this;
                    while(p.parent !== null)
                    {
                        p = p.parent;
                    }
                    if (n === p)
                    {
                        n = n.CloneNode();
                    }
                }
                this.ConvertTextToNode();
                this.AppendNodeSkipNotify(n);
            }
            //--TRIMMABLE-BOUNDARY-END(55835885572)
            
            //--TRIMMABLE-BOUNDARY-START(60130852868)
            /*void */ AddString(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130852868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateString(s);
                if (this.content === null)
                {
                    if (s.length > 0)
                    {
                        this.AppendNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(s));
                    }
                    else 
                    {
                        if ($.$is(this, $.$spxl.System.Xml.Linq.XElement))
                        {
                            this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                            if (this.content !== null)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                            }
                            this.content = s;
                            this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                        }
                        else 
                        {
                            this.content = s;
                        }
                    }
                }
                else if (s.length > 0)
                {
                    this.ConvertTextToNode();
                    /*XText?*/ let tn = $.$as(this.content, $.$spxl.System.Xml.Linq.XText);
                    if (tn !== null && !($.$is(tn, $.$spxl.System.Xml.Linq.XCData)))
                    {
                        tn.Value += s;
                    }
                    else 
                    {
                        this.AppendNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(s));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130852868)
            
            //--TRIMMABLE-BOUNDARY-START(64425820164)
            /*void */ AddStringSkipNotify(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425820164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateString(s);
                if (this.content === null)
                {
                    this.content = s;
                }
                else if (s.length > 0)
                {
                    /*string?*/ let stringContent = $.$as(this.content, $.$$.System.String);
                    if ($.$$.System.String.op_Inequality(stringContent, null))
                    {
                        this.content = stringContent + s;
                    }
                    else 
                    {
                        /*XText?*/ let tn = $.$as(this.content, $.$spxl.System.Xml.Linq.XText);
                        if (tn !== null && !($.$is(tn, $.$spxl.System.Xml.Linq.XCData)))
                        {
                            tn.text += s;
                        }
                        else 
                        {
                            this.AppendNodeSkipNotify(new $.$spxl.System.Xml.Linq.XText().$ctor$3(s));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425820164)
            
            //--TRIMMABLE-BOUNDARY-START(68720787460)
            /*void */ AppendNode(/*XNode*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720787460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let notify = this.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                if (n.parent !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                this.AppendNodeSkipNotify(n);
                if (notify)
                {
                    this.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720787460)
            
            //--TRIMMABLE-BOUNDARY-START(73015754756)
            /*void */ AppendNodeSkipNotify(/*XNode*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015754756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                n.parent = this;
                if (this.content === null || $.$is(this.content, $.$$.System.String))
                {
                    n.next = n;
                }
                else 
                {
                    /*XNode*/ let x = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                    n.next = x.next;
                    x.next = n;
                }
                this.content = n;
            }
            //--TRIMMABLE-BOUNDARY-END(73015754756)
            
            //--TRIMMABLE-BOUNDARY-START(77310722052)
            /*void */ AppendText(/*StringBuilder*/ sb)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310722052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let s = $.$as(this.content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    sb.Append$19(s);
                }
                else 
                {
                    /*XNode?*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                    if (n !== null)
                    {
                        do
                        {
                            n = n.next;
                            n.AppendText(sb);
                        }
                        while(n !== this.content);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310722052)
            
            //--TRIMMABLE-BOUNDARY-START(176094969860)
            /*string? */ GetTextOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094969860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.content === null)
                {
                    return null;
                }
                /*string?*/ let s = $.$as(this.content, $.$$.System.String);
                if ($.$$.System.String.op_Equality(s, null))
                {
                    /*XNode*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                    do
                    {
                        n = n.next;
                        if (n.NodeType !== 3/*XmlNodeType.Text*/)
                        {
                            return null;
                        }
                        s += ($.$cast(n, $.$spxl.System.Xml.Linq.XText)).Value;
                    }
                    while(n !== this.content);
                }
                return s;
            }
            //--TRIMMABLE-BOUNDARY-END(176094969860)
            
            //--TRIMMABLE-BOUNDARY-START(81605689348)
            /*string */ CollectText(/*ref XNode?*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605689348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let s = "";
                while(n.$v !== null && n.$v.NodeType === 3/*XmlNodeType.Text*/)
                {
                    s += ($.$cast(n.$v, $.$spxl.System.Xml.Linq.XText)).Value;
                    n.$v = n.$v !== this.content ? n.$v.next : null;
                }
                return s;
            }
            //--TRIMMABLE-BOUNDARY-END(81605689348)
            
            //--TRIMMABLE-BOUNDARY-START(90195623940)
            /*bool */ ContentsEqual(/*XContainer*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195623940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.content === e.content)
                {
                    return true;
                }
                /*string?*/ let s = this.GetTextOnly();
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    return $.$$.System.String.op_Equality(s, e.GetTextOnly());
                }
                /*XNode?*/ let n1 = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                /*XNode?*/ let n2 = $.$as(e.content, $.$spxl.System.Xml.Linq.XNode);
                if (n1 !== null && n2 !== null)
                {
                    n1 = n1.next;
                    n2 = n2.next;
                    while(true)
                    {
                        if ($.$$.System.String.op_Inequality(this.CollectText($.$ref(() => n1, ($v) => n1 = $v, $.$spxl.System.Xml.Linq.XNode)), e.CollectText($.$ref(() => n2, ($v) => n2 = $v, $.$spxl.System.Xml.Linq.XNode))))
                        {
                            break;
                        }
                        if (n1 === null && n2 === null)
                        {
                            return true;
                        }
                        if (n1 === null || n2 === null || !n1.DeepEquals$1(n2))
                        {
                            break;
                        }
                        n1 = n1 !== this.content ? n1.next : null;
                        n2 = n2 !== e.content ? n2.next : null;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(90195623940)
            
            //--TRIMMABLE-BOUNDARY-START(94490591236)
            /*int */ ContentsHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490591236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let s = this.GetTextOnly();
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    return $.$$.System.String.GetHashCode.call(s);
                }
                /*int*/ let h = 0;
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*string*/ let text = this.CollectText($.$ref(() => n, ($v) => n = $v, $.$spxl.System.Xml.Linq.XNode));
                        if (text.length > 0)
                        {
                            h ^= $.$$.System.String.GetHashCode.call(text);
                        }
                        if (n === null)
                        {
                            break;
                        }
                        h ^= n.GetDeepHashCode();
                    }
                    while(n !== this.content);
                }
                return h;
            }
            //--TRIMMABLE-BOUNDARY-END(94490591236)
            
            //--TRIMMABLE-BOUNDARY-START(98785558532)
            /*void */ ConvertTextToNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785558532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let s = $.$as(this.content, $.$$.System.String);
                if (!$.$$.System.String.IsNullOrEmpty(s))
                {
                    /*XText*/ let t = new $.$spxl.System.Xml.Linq.XText().$ctor$3(s);
                    t.parent = this;
                    t.next = t;
                    this.content = t;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785558532)
            
            //--TRIMMABLE-BOUNDARY-START(158915100676)
            /*IEnumerable<XNode> */ GetDescendantNodes(/*bool*/ self)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (self)
                    {
                        yield this;
                    }
                    /*XNode*/ let n = this;
                    while(true)
                    {
                        /*XContainer?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XContainer);
                        /*XNode?*/ let first;
                        if (c !== null && (first = c.FirstNode) !== null)
                        {
                            n = first;
                        }
                        else 
                        {
                            while(n !== null && n !== this && n === n.parent.content)
                            {
                                n = n.parent;
                            }
                            if (n === null || n === this)
                            {
                                break;
                            }
                            n = n.next;
                        }
                        yield n;
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(158915100676)
            
            //--TRIMMABLE-BOUNDARY-START(163210067972)
            /*IEnumerable<XElement> */ GetDescendants(/*XName?*/ name, /*bool*/ self)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (self)
                    {
                        /*XElement*/ let e = $.$cast(this, $.$spxl.System.Xml.Linq.XElement);
                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                        {
                            yield e;
                        }
                    }
                    /*XNode*/ let n = this;
                    /*XContainer?*/ let c = this;
                    while(true)
                    {
                        if (c !== null && $.$is(c.content, $.$spxl.System.Xml.Linq.XNode))
                        {
                            n = ($.$cast(c.content, $.$spxl.System.Xml.Linq.XNode)).next;
                        }
                        else 
                        {
                            while(n !== this && n === n.parent.content)
                            {
                                n = n.parent;
                            }
                            if (n === this)
                            {
                                break;
                            }
                            n = n.next;
                        }
                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                        {
                            yield e;
                        }
                        c = e;
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(163210067972)
            
            //--TRIMMABLE-BOUNDARY-START(167505035268)
            /*IEnumerable<XElement> */ GetElements(/*XName?*/ name)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                    if (n !== null)
                    {
                        do
                        {
                            n = n.next;
                            /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                            if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                            {
                                yield e;
                            }
                        }
                        while(n.parent === this && n !== this.content);
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(167505035268)
            
            //--TRIMMABLE-BOUNDARY-START(171800002564)
            static /*string */ GetStringValue(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800002564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let s = (() =>
                {
                    {
                        let stringValue;
                        if ((stringValue = value, $.$is(stringValue, $.$$.System.String)))
                        {
                            return stringValue;
                        }
                    }
                    {
                        let intValue;
                        if ((intValue = value, $.$is(intValue, $.$$.System.Int32)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$13(intValue);
                        }
                    }
                    {
                        let doubleValue;
                        if ((doubleValue = value, $.$is(doubleValue, $.$$.System.Double)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$10(doubleValue);
                        }
                    }
                    {
                        let longValue;
                        if ((longValue = value, $.$is(longValue, $.$$.System.Int64)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$14(longValue);
                        }
                    }
                    {
                        let floatValue;
                        if ((floatValue = value, $.$is(floatValue, $.$$.System.Single)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$16(floatValue);
                        }
                    }
                    {
                        let decimalValue;
                        if ((decimalValue = value, $.$is(decimalValue, $.$$.System.Decimal)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$9(decimalValue);
                        }
                    }
                    {
                        let shortValue;
                        if ((shortValue = value, $.$is(shortValue, $.$$.System.Int16)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$12(shortValue);
                        }
                    }
                    {
                        let sbyteValue;
                        if ((sbyteValue = value, $.$is(sbyteValue, $.$$.System.SByte)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$15(sbyteValue);
                        }
                    }
                    {
                        let boolValue;
                        if ((boolValue = value, $.$is(boolValue, $.$$.System.Boolean)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$1(boolValue);
                        }
                    }
                    {
                        let dtValue;
                        if ((dtValue = value, $.$is(dtValue, $.$$.System.DateTime)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$5(dtValue, 3/*XmlDateTimeSerializationMode.RoundtripKind*/);
                        }
                    }
                    {
                        let dtoValue;
                        if ((dtoValue = value, $.$is(dtoValue, $.$$.System.DateTimeOffset)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$8(dtoValue);
                        }
                    }
                    {
                        let tsValue;
                        if ((tsValue = value, $.$is(tsValue, $.$$.System.TimeSpan)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$17(tsValue);
                        }
                    }
                    if (value === $.$spxl.System.Xml.Linq.XObject)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_XObjectValue);
                    }
                    return $.$$.System.Object.ToString.call(value);
                })();
                if ($.$$.System.String.op_Equality(s, null))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_ConvertToString);
                }
                return s;
            }
            //--TRIMMABLE-BOUNDARY-END(171800002564)
            
            //--TRIMMABLE-BOUNDARY-START(193274839044)
            /*void */ ReadContentFrom$1(/*XmlReader*/ r)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274839044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (r.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$2(this);
                while(cr.ReadContentFrom(this, r) && r.Read())
                {
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193274839044)
            
            //--TRIMMABLE-BOUNDARY-START(188979871748)
            /*void */ ReadContentFrom(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979871748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((o & (2/*LoadOptions.SetBaseUri*/ | 4/*LoadOptions.SetLineInfo*/)) === 0)
                {
                    this.ReadContentFrom$1(r);
                    return;
                }
                if (r.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$1(this, r, o);
                while(cr.ReadContentFromContainer(this, r) && r.Read())
                {
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979871748)
            
            //--TRIMMABLE-BOUNDARY-START(197569806340)
            /*Task *//*async*/  ReadContentFromAsync(/*XmlReader*/ r, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197569806340);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (r.ReadState !== 1/*ReadState.Interactive*/)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                    }
                    /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$2(this);
                    do
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                    while(await cr.ReadContentFromAsync(this, r).ConfigureAwait(false) && await r.ReadAsync().ConfigureAwait$2(false));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(197569806340)
            
            //--TRIMMABLE-BOUNDARY-START(201864773636)
            /*Task *//*async*/  ReadContentFromAsync$1(/*XmlReader*/ r, /*LoadOptions*/ o, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201864773636);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ((o & (2/*LoadOptions.SetBaseUri*/ | 4/*LoadOptions.SetLineInfo*/)) === 0)
                    {
                        await this.ReadContentFromAsync(r, cancellationToken).ConfigureAwait(false);
                        return;
                    }
                    if (r.ReadState !== 1/*ReadState.Interactive*/)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                    }
                    /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$1(this, r, o);
                    do
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                    while(await cr.ReadContentFromContainerAsync(this, r).ConfigureAwait(false) && await r.ReadAsync().ConfigureAwait$2(false));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(201864773636)
            
            //--TRIMMABLE-BOUNDARY-START(1376260)
            static $_ContentReader;
            static get ContentReader()
            {
                let $cls = $.$spxl.System.Xml.Linq.XContainer;
                return $cls.$_ContentReader ??= $asm.$ncls("$spxl.System.Xml.Linq.XContainer.ContentReader", ($self) => class ContentReader extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(17181245444)
                    /*NamespaceCache*/ _eCache;
                    //--TRIMMABLE-BOUNDARY-END(17181245444)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296343556)
                    /*NamespaceCache*/ _aCache;
                    //--TRIMMABLE-BOUNDARY-END(4296343556)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476212740)
                    /*IXmlLineInfo?*/ _lineInfo = null;
                    //--TRIMMABLE-BOUNDARY-END(21476212740)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886278148)
                    /*XContainer*/ _currentContainer = null;
                    //--TRIMMABLE-BOUNDARY-END(12886278148)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591310852)
                    /*string?*/ _baseUri = null;
                    //--TRIMMABLE-BOUNDARY-END(8591310852)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066147332)
                    $ctor$2(/*XContainer*/ rootContainer)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30066147332);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._currentContainer = rootContainer;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066147332)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771180036)
                    $ctor$1(/*XContainer*/ rootContainer, /*XmlReader*/ r, /*LoadOptions*/ o)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25771180036);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._currentContainer = rootContainer;
                            this._baseUri = (o & 2/*LoadOptions.SetBaseUri*/) !== 0 ? r.BaseURI : null;
                            this._lineInfo = (o & 4/*LoadOptions.SetLineInfo*/) !== 0 ? $.$as(r, $.$spx.System.Xml.IXmlLineInfo) : null;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771180036)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361114628)
                    /*bool */ ReadContentFrom(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34361114628);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $switch1 = r.NodeType;
                        switch($switch1)
                        {
                            case 1/*XmlNodeType.Element*/:
                            /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$12(this._eCache.Get(r.NamespaceURI).GetName$1(r.LocalName));
                            if (r.MoveToFirstAttribute())
                            {
                                do
                                {
                                    e.AppendAttributeSkipNotify(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(this._aCache.Get(r.Prefix.length === 0 ? $.$$.System.String.Empty : r.NamespaceURI).GetName$1(r.LocalName), r.Value));
                                }
                                while(r.MoveToNextAttribute());
                                r.MoveToElement();
                            }
                            this._currentContainer.AddNodeSkipNotify(e);
                            if (!r.IsEmptyElement)
                            {
                                this._currentContainer = e;
                            }
                            break;
                            case 15/*XmlNodeType.EndElement*/:
                            this._currentContainer.content ??= $.$$.System.String.Empty;
                            if (this._currentContainer === rootContainer)
                            {
                                return false;
                            }
                            this._currentContainer = this._currentContainer.parent;
                            break;
                            case 3/*XmlNodeType.Text*/:
                            case 14/*XmlNodeType.SignificantWhitespace*/:
                            case 13/*XmlNodeType.Whitespace*/:
                            this._currentContainer.AddStringSkipNotify(r.Value);
                            break;
                            case 4/*XmlNodeType.CDATA*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XCData().$ctor$6(r.Value));
                            break;
                            case 8/*XmlNodeType.Comment*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XComment().$ctor$3(r.Value));
                            break;
                            case 7/*XmlNodeType.ProcessingInstruction*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, r.Value));
                            break;
                            case 10/*XmlNodeType.DocumentType*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute$2("PUBLIC"), r.GetAttribute$2("SYSTEM"), r.Value));
                            break;
                            case 5/*XmlNodeType.EntityReference*/:
                            if (!r.CanResolveEntity)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                            }
                            r.ResolveEntity();
                            break;
                            case 16/*XmlNodeType.EndEntity*/:
                            break;
                            default:
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                        }
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361114628)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656081924)
                    /*ValueTask<bool> *//*async*/  ReadContentFromAsync(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean), $.$$.System.Boolean, async () => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(38656081924);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let $switch1 = r.NodeType;
                            switch($switch1)
                            {
                                case 1/*XmlNodeType.Element*/:
                                /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$12(this._eCache.Get(r.NamespaceURI).GetName$1(r.LocalName));
                                if (r.MoveToFirstAttribute())
                                {
                                    do
                                    {
                                        e.AppendAttributeSkipNotify(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(this._aCache.Get(r.Prefix.length === 0 ? $.$$.System.String.Empty : r.NamespaceURI).GetName$1(r.LocalName), await r.GetValueAsync().ConfigureAwait$2(false)));
                                    }
                                    while(r.MoveToNextAttribute());
                                    r.MoveToElement();
                                }
                                this._currentContainer.AddNodeSkipNotify(e);
                                if (!r.IsEmptyElement)
                                {
                                    this._currentContainer = e;
                                }
                                break;
                                case 15/*XmlNodeType.EndElement*/:
                                this._currentContainer.content ??= $.$$.System.String.Empty;
                                if (this._currentContainer === rootContainer)
                                {
                                    return false;
                                }
                                this._currentContainer = this._currentContainer.parent;
                                break;
                                case 3/*XmlNodeType.Text*/:
                                case 14/*XmlNodeType.SignificantWhitespace*/:
                                case 13/*XmlNodeType.Whitespace*/:
                                this._currentContainer.AddStringSkipNotify(await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 4/*XmlNodeType.CDATA*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XCData().$ctor$6(await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 8/*XmlNodeType.Comment*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XComment().$ctor$3(await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 7/*XmlNodeType.ProcessingInstruction*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 10/*XmlNodeType.DocumentType*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute$2("PUBLIC"), r.GetAttribute$2("SYSTEM"), await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 5/*XmlNodeType.EntityReference*/:
                                if (!r.CanResolveEntity)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                                }
                                r.ResolveEntity();
                                break;
                                case 16/*XmlNodeType.EndEntity*/:
                                break;
                                default:
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                            }
                            return true;
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656081924)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951049220)
                    /*bool */ ReadContentFromContainer(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42951049220);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*XNode?*/ let newNode = null;
                        /*string*/ let baseUri = r.BaseURI;
                        let $switch1 = r.NodeType;
                        switch($switch1)
                        {
                            case 1/*XmlNodeType.Element*/:
                            {
                                /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$12(this._eCache.Get(r.NamespaceURI).GetName$1(r.LocalName));
                                if ($.$$.System.String.op_Inequality(this._baseUri, null) && $.$$.System.String.op_Inequality(this._baseUri, baseUri))
                                {
                                    e.SetBaseUri(baseUri);
                                }
                                if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                {
                                    e.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                }
                                if (r.MoveToFirstAttribute())
                                {
                                    do
                                    {
                                        /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(this._aCache.Get(r.Prefix.length === 0 ? $.$$.System.String.Empty : r.NamespaceURI).GetName$1(r.LocalName), r.Value);
                                        if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                        {
                                            a.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                        }
                                        e.AppendAttributeSkipNotify(a);
                                    }
                                    while(r.MoveToNextAttribute());
                                    r.MoveToElement();
                                }
                                this._currentContainer.AddNodeSkipNotify(e);
                                if (!r.IsEmptyElement)
                                {
                                    this._currentContainer = e;
                                    if ($.$$.System.String.op_Inequality(this._baseUri, null))
                                    {
                                        this._baseUri = baseUri;
                                    }
                                }
                                break;
                            }
                            case 15/*XmlNodeType.EndElement*/:
                            {
                                this._currentContainer.content ??= $.$$.System.String.Empty;
                                /*XElement?*/ let e = $.$as(this._currentContainer, $.$spxl.System.Xml.Linq.XElement);
                                $.$$.System.Diagnostics.Debug.Assert$2(e !== null, "EndElement received but the current container is not an element.");
                                if (e !== null && this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                {
                                    e.SetEndElementLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                }
                                if (this._currentContainer === rootContainer)
                                {
                                    return false;
                                }
                                if ($.$$.System.String.op_Inequality(this._baseUri, null) && this._currentContainer.HasBaseUri)
                                {
                                    this._baseUri = this._currentContainer.parent.BaseUri;
                                }
                                this._currentContainer = this._currentContainer.parent;
                                break;
                            }
                            case 3/*XmlNodeType.Text*/:
                            case 14/*XmlNodeType.SignificantWhitespace*/:
                            case 13/*XmlNodeType.Whitespace*/:
                            if (($.$$.System.String.op_Inequality(this._baseUri, null) && $.$$.System.String.op_Inequality(this._baseUri, baseUri)) || (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo()))
                            {
                                newNode = new $.$spxl.System.Xml.Linq.XText().$ctor$3(r.Value);
                            }
                            else 
                            {
                                this._currentContainer.AddStringSkipNotify(r.Value);
                            }
                            break;
                            case 4/*XmlNodeType.CDATA*/:
                            newNode = new $.$spxl.System.Xml.Linq.XCData().$ctor$6(r.Value);
                            break;
                            case 8/*XmlNodeType.Comment*/:
                            newNode = new $.$spxl.System.Xml.Linq.XComment().$ctor$3(r.Value);
                            break;
                            case 7/*XmlNodeType.ProcessingInstruction*/:
                            newNode = new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, r.Value);
                            break;
                            case 10/*XmlNodeType.DocumentType*/:
                            newNode = new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute$2("PUBLIC"), r.GetAttribute$2("SYSTEM"), r.Value);
                            break;
                            case 5/*XmlNodeType.EntityReference*/:
                            if (!r.CanResolveEntity)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                            }
                            r.ResolveEntity();
                            break;
                            case 16/*XmlNodeType.EndEntity*/:
                            break;
                            default:
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                        }
                        if (newNode !== null)
                        {
                            if ($.$$.System.String.op_Inequality(this._baseUri, null) && $.$$.System.String.op_Inequality(this._baseUri, baseUri))
                            {
                                newNode.SetBaseUri(baseUri);
                            }
                            if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                            {
                                newNode.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                            }
                            this._currentContainer.AddNodeSkipNotify(newNode);
                        }
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42951049220)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246016516)
                    /*ValueTask<bool> *//*async*/  ReadContentFromContainerAsync(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean), $.$$.System.Boolean, async () => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(47246016516);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            /*XNode?*/ let newNode = null;
                            /*string*/ let baseUri = r.BaseURI;
                            let $switch1 = r.NodeType;
                            switch($switch1)
                            {
                                case 1/*XmlNodeType.Element*/:
                                {
                                    /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$12(this._eCache.Get(r.NamespaceURI).GetName$1(r.LocalName));
                                    if ($.$$.System.String.op_Inequality(this._baseUri, null) && $.$$.System.String.op_Inequality(this._baseUri, baseUri))
                                    {
                                        e.SetBaseUri(baseUri);
                                    }
                                    if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                    {
                                        e.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                    }
                                    if (r.MoveToFirstAttribute())
                                    {
                                        do
                                        {
                                            /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(this._aCache.Get(r.Prefix.length === 0 ? $.$$.System.String.Empty : r.NamespaceURI).GetName$1(r.LocalName), await r.GetValueAsync().ConfigureAwait$2(false));
                                            if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                            {
                                                a.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                            }
                                            e.AppendAttributeSkipNotify(a);
                                        }
                                        while(r.MoveToNextAttribute());
                                        r.MoveToElement();
                                    }
                                    this._currentContainer.AddNodeSkipNotify(e);
                                    if (!r.IsEmptyElement)
                                    {
                                        this._currentContainer = e;
                                        if ($.$$.System.String.op_Inequality(this._baseUri, null))
                                        {
                                            this._baseUri = baseUri;
                                        }
                                    }
                                    break;
                                }
                                case 15/*XmlNodeType.EndElement*/:
                                {
                                    this._currentContainer.content ??= $.$$.System.String.Empty;
                                    /*XElement?*/ let e = $.$as(this._currentContainer, $.$spxl.System.Xml.Linq.XElement);
                                    $.$$.System.Diagnostics.Debug.Assert$2(e !== null, "EndElement received but the current container is not an element.");
                                    if (e !== null && this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                    {
                                        e.SetEndElementLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                    }
                                    if (this._currentContainer === rootContainer)
                                    {
                                        return false;
                                    }
                                    if ($.$$.System.String.op_Inequality(this._baseUri, null) && this._currentContainer.HasBaseUri)
                                    {
                                        this._baseUri = this._currentContainer.parent.BaseUri;
                                    }
                                    this._currentContainer = this._currentContainer.parent;
                                    break;
                                }
                                case 3/*XmlNodeType.Text*/:
                                case 14/*XmlNodeType.SignificantWhitespace*/:
                                case 13/*XmlNodeType.Whitespace*/:
                                if (($.$$.System.String.op_Inequality(this._baseUri, null) && $.$$.System.String.op_Inequality(this._baseUri, baseUri)) || (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo()))
                                {
                                    newNode = new $.$spxl.System.Xml.Linq.XText().$ctor$3(await r.GetValueAsync().ConfigureAwait$2(false));
                                }
                                else 
                                {
                                    this._currentContainer.AddStringSkipNotify(await r.GetValueAsync().ConfigureAwait$2(false));
                                }
                                break;
                                case 4/*XmlNodeType.CDATA*/:
                                newNode = new $.$spxl.System.Xml.Linq.XCData().$ctor$6(await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 8/*XmlNodeType.Comment*/:
                                newNode = new $.$spxl.System.Xml.Linq.XComment().$ctor$3(await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 7/*XmlNodeType.ProcessingInstruction*/:
                                newNode = new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 10/*XmlNodeType.DocumentType*/:
                                newNode = new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute$2("PUBLIC"), r.GetAttribute$2("SYSTEM"), await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 5/*XmlNodeType.EntityReference*/:
                                if (!r.CanResolveEntity)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                                }
                                r.ResolveEntity();
                                break;
                                case 16/*XmlNodeType.EndEntity*/:
                                break;
                                default:
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                            }
                            if (newNode !== null)
                            {
                                if ($.$$.System.String.op_Inequality(this._baseUri, null) && $.$$.System.String.op_Inequality(this._baseUri, baseUri))
                                {
                                    newNode.SetBaseUri(baseUri);
                                }
                                if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                {
                                    newNode.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                }
                                this._currentContainer.AddNodeSkipNotify(newNode);
                            }
                            return true;
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(47246016516)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(17181245444)
                        this._eCache = $.$default($.$spxl.System.Xml.Linq.NamespaceCache);
                        //--TRIMMABLE-BOUNDARY-END(17181245444)
                        
                        //--TRIMMABLE-BOUNDARY-START(4296343556)
                        this._aCache = $.$default($.$spxl.System.Xml.Linq.NamespaceCache);
                        //--TRIMMABLE-BOUNDARY-END(4296343556)
                        
                    }
                    static $h = 1376260;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361114628),
    {
      "r": 262145,
      "p": [
        {
          "n": "rootContainer",
          "p": 1310724
        },
        {
          "n": "r",
          "p": 53346307
        }
      ],
      "n": "ReadContentFrom",
      "d": 1376260,
      "h": 34361114628,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361114628),
//--TRIMMABLE-BOUNDARY-START(38656081924),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "rootContainer",
          "p": 1310724
        },
        {
          "n": "r",
          "p": 53346307
        }
      ],
      "n": "ReadContentFromAsync",
      "d": 1376260,
      "h": 38656081924,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(38656081924),
//--TRIMMABLE-BOUNDARY-START(42951049220),
    {
      "r": 262145,
      "p": [
        {
          "n": "rootContainer",
          "p": 1310724
        },
        {
          "n": "r",
          "p": 53346307
        }
      ],
      "n": "ReadContentFromContainer",
      "d": 1376260,
      "h": 42951049220,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951049220),
//--TRIMMABLE-BOUNDARY-START(47246016516),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "rootContainer",
          "p": 1310724
        },
        {
          "n": "r",
          "p": 53346307
        }
      ],
      "n": "ReadContentFromContainerAsync",
      "d": 1376260,
      "h": 47246016516,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(47246016516)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181245444),
    {
      "t": 720900,
      "n": "_eCache",
      "d": 1376260,
      "h": 17181245444,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181245444),
//--TRIMMABLE-BOUNDARY-START(4296343556),
    {
      "t": 720900,
      "n": "_aCache",
      "d": 1376260,
      "h": 4296343556,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296343556),
//--TRIMMABLE-BOUNDARY-START(21476212740),
    {
      "t": 13893635,
      "n": "_lineInfo",
      "d": 1376260,
      "h": 21476212740,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476212740),
//--TRIMMABLE-BOUNDARY-START(12886278148),
    {
      "t": 1310724,
      "n": "_currentContainer",
      "d": 1376260,
      "h": 12886278148,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886278148),
//--TRIMMABLE-BOUNDARY-START(8591310852),
    {
      "t": 1310721,
      "n": "_baseUri",
      "d": 1376260,
      "h": 8591310852,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591310852)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066147332),
    {
      "p": [
        {
          "n": "rootContainer",
          "p": 1310724
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1376260,
      "h": 30066147332,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066147332),
//--TRIMMABLE-BOUNDARY-START(25771180036),
    {
      "p": [
        {
          "n": "rootContainer",
          "p": 1310724
        },
        {
          "n": "r",
          "p": 53346307
        },
        {
          "n": "o",
          "p": 655364
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376260,
      "h": 25771180036,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771180036)
  ],
  "d": 1310724,
  "h": 1376260
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Xml.Linq.XContainer.ContentReader`; }
                }, $cls, ($v) => $cls.$_ContentReader = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1376260)
            
            //--TRIMMABLE-BOUNDARY-START(206159740932)
            /*void */ RemoveNode(/*XNode*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159740932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let notify = this.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                if (n.parent !== this)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this.content !== null, "content != null");
                /*XNode*/ let p = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                while(p.next !== n)
                {
                    p = p.next;
                }
                if (p === n)
                {
                    this.content = null;
                }
                else 
                {
                    if (this.content === n)
                    {
                        this.content = p;
                    }
                    p.next = n.next;
                }
                n.parent = null;
                n.next = null;
                if (notify)
                {
                    this.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206159740932)
            
            //--TRIMMABLE-BOUNDARY-START(214749675524)
            /*void */ RemoveNodesSkipNotify()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749675524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        /*XNode*/ let next = n.next;
                        n.parent = null;
                        n.next = null;
                        n = next;
                    }
                    while(n !== this.content);
                }
                this.content = null;
            }
            //--TRIMMABLE-BOUNDARY-END(214749675524)
            
            //--TRIMMABLE-BOUNDARY-START(227634577412)
            /*void */ ValidateNode(/*XNode*/ node, /*XNode?*/ previous)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634577412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(227634577412)
            
            //--TRIMMABLE-BOUNDARY-START(231929544708)
            /*void */ ValidateString(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929544708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(231929544708)
            
            //--TRIMMABLE-BOUNDARY-START(236224512004)
            /*void */ WriteContentTo(/*XmlWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224512004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.content !== null)
                {
                    /*string?*/ let stringContent = $.$as(this.content, $.$$.System.String);
                    if ($.$$.System.String.op_Inequality(stringContent, null))
                    {
                        if ($.$is(this, $.$spxl.System.Xml.Linq.XDocument))
                        {
                            writer.WriteWhitespace(stringContent);
                        }
                        else 
                        {
                            writer.WriteString(stringContent);
                        }
                    }
                    else 
                    {
                        /*XNode*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                        do
                        {
                            n = n.next;
                            n.WriteTo(writer);
                        }
                        while(n !== this.content);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236224512004)
            
            //--TRIMMABLE-BOUNDARY-START(240519479300)
            /*Task *//*async*/  WriteContentToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(240519479300);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.content !== null)
                    {
                        /*string?*/ let stringContent = $.$as(this.content, $.$$.System.String);
                        if ($.$$.System.String.op_Inequality(stringContent, null))
                        {
                            cancellationToken.ThrowIfCancellationRequested();
                            /*Task*/ let tWrite;
                            if ($.$is(this, $.$spxl.System.Xml.Linq.XDocument))
                            {
                                tWrite = writer.WriteWhitespaceAsync(stringContent);
                            }
                            else 
                            {
                                tWrite = writer.WriteStringAsync(stringContent);
                            }
                            await tWrite.ConfigureAwait(false);
                        }
                        else 
                        {
                            /*XNode*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                            do
                            {
                                n = n.next;
                                await n.WriteToAsync(writer, cancellationToken).ConfigureAwait(false);
                            }
                            while(n !== this.content);
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(240519479300)
            
            //--TRIMMABLE-BOUNDARY-START(38656016388)
            static /*void */ AddContentToList(/*List<object?>*/ list, /*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656016388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable?*/ let e = $.$is(content, $.$$.System.String) ? null : $.$as(content, $.$$.System.Collections.IEnumerable);
                if (e === null)
                {
                    list.Add(content);
                }
                else 
                {
                    var $en3 = e.System$Collections$IEnumerable$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (obj !== null)
                            {
                                $.$spxl.System.Xml.Linq.XContainer.AddContentToList(list, obj);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656016388)
            
            //--TRIMMABLE-BOUNDARY-START(154620133380)
            static /*object? */ GetContentSnapshot(/*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620133380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(content, $.$$.System.String) || !($.$is(content, $.$$.System.Collections.IEnumerable)))
                {
                    return content;
                }
                /*List<object?>*/ let list = new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                $.$spxl.System.Xml.Linq.XContainer.AddContentToList(list, content);
                return list;
            }
            //--TRIMMABLE-BOUNDARY-END(154620133380)
            
            static $h = 1310724;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2228228,
  "p": [
//--TRIMMABLE-BOUNDARY-START(133145296900),
    {
      "p": 2228228,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735231492,
        "f": 50331649
      },
      "n": "FirstNode",
      "d": 1310724,
      "h": 133145296900,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145296900),
//--TRIMMABLE-BOUNDARY-START(180389937156),
    {
      "p": 2228228,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325166084,
        "f": 50331649
      },
      "n": "LastNode",
      "d": 1310724,
      "h": 180389937156,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180389937156)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181179908),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "Add",
      "d": 1310724,
      "h": 17181179908,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181179908),
//--TRIMMABLE-BOUNDARY-START(21476147204),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 1310724,
      "h": 21476147204,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476147204),
//--TRIMMABLE-BOUNDARY-START(42950983684),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "AddFirst",
      "d": 1310724,
      "h": 42950983684,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950983684),
//--TRIMMABLE-BOUNDARY-START(47245950980),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "AddFirst",
      "o": "@$1",
      "d": 1310724,
      "h": 47245950980,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245950980),
//--TRIMMABLE-BOUNDARY-START(103080525828),
    {
      "r": 58392579,
      "n": "CreateWriter",
      "d": 1310724,
      "h": 103080525828,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103080525828),
//--TRIMMABLE-BOUNDARY-START(107375493124),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,
      "n": "DescendantNodes",
      "d": 1310724,
      "h": 107375493124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107375493124),
//--TRIMMABLE-BOUNDARY-START(111670460420),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "n": "Descendants",
      "d": 1310724,
      "h": 111670460420,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670460420),
//--TRIMMABLE-BOUNDARY-START(115965427716),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "Descendants",
      "o": "@$1",
      "d": 1310724,
      "h": 115965427716,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115965427716),
//--TRIMMABLE-BOUNDARY-START(120260395012),
    {
      "r": 1638404,
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "Element",
      "d": 1310724,
      "h": 120260395012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120260395012),
//--TRIMMABLE-BOUNDARY-START(124555362308),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "n": "Elements",
      "d": 1310724,
      "h": 124555362308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124555362308),
//--TRIMMABLE-BOUNDARY-START(128850329604),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "Elements",
      "o": "@$1",
      "d": 1310724,
      "h": 128850329604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128850329604),
//--TRIMMABLE-BOUNDARY-START(184684904452),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,
      "n": "Nodes",
      "d": 1310724,
      "h": 184684904452,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684904452),
//--TRIMMABLE-BOUNDARY-START(210454708228),
    {
      "r": 65537,
      "n": "RemoveNodes",
      "d": 1310724,
      "h": 210454708228,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210454708228),
//--TRIMMABLE-BOUNDARY-START(219044642820),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "ReplaceNodes",
      "d": 1310724,
      "h": 219044642820,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(219044642820),
//--TRIMMABLE-BOUNDARY-START(223339610116),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "ReplaceNodes",
      "o": "@$1",
      "d": 1310724,
      "h": 223339610116,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223339610116),
//--TRIMMABLE-BOUNDARY-START(25771114500),
    {
      "r": 65537,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "AddAttribute",
      "d": 1310724,
      "h": 25771114500,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(25771114500),
//--TRIMMABLE-BOUNDARY-START(30066081796),
    {
      "r": 65537,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "AddAttributeSkipNotify",
      "d": 1310724,
      "h": 30066081796,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(30066081796),
//--TRIMMABLE-BOUNDARY-START(34361049092),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "AddContentSkipNotify",
      "d": 1310724,
      "h": 34361049092,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34361049092),
//--TRIMMABLE-BOUNDARY-START(51540918276),
    {
      "r": 65537,
      "p": [
        {
          "n": "n",
          "p": 2228228
        }
      ],
      "n": "AddNode",
      "d": 1310724,
      "h": 51540918276,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51540918276),
//--TRIMMABLE-BOUNDARY-START(55835885572),
    {
      "r": 65537,
      "p": [
        {
          "n": "n",
          "p": 2228228
        }
      ],
      "n": "AddNodeSkipNotify",
      "d": 1310724,
      "h": 55835885572,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(55835885572),
//--TRIMMABLE-BOUNDARY-START(60130852868),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "AddString",
      "d": 1310724,
      "h": 60130852868,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(60130852868),
//--TRIMMABLE-BOUNDARY-START(64425820164),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "AddStringSkipNotify",
      "d": 1310724,
      "h": 64425820164,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(64425820164),
//--TRIMMABLE-BOUNDARY-START(68720787460),
    {
      "r": 65537,
      "p": [
        {
          "n": "n",
          "p": 2228228
        }
      ],
      "n": "AppendNode",
      "d": 1310724,
      "h": 68720787460,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68720787460),
//--TRIMMABLE-BOUNDARY-START(73015754756),
    {
      "r": 65537,
      "p": [
        {
          "n": "n",
          "p": 2228228
        }
      ],
      "n": "AppendNodeSkipNotify",
      "d": 1310724,
      "h": 73015754756,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(73015754756),
//--TRIMMABLE-BOUNDARY-START(77310722052),
    {
      "r": 65537,
      "p": [
        {
          "n": "sb",
          "p": 167051265
        }
      ],
      "n": "AppendText",
      "d": 1310724,
      "h": 77310722052,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(77310722052),
//--TRIMMABLE-BOUNDARY-START(176094969860),
    {
      "r": 1310721,
      "n": "GetTextOnly",
      "d": 1310724,
      "h": 176094969860,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176094969860),
//--TRIMMABLE-BOUNDARY-START(81605689348),
    {
      "r": 1310721,
      "p": [
        {
          "n": "n",
          "p": 2228228,
          "f": 4
        }
      ],
      "n": "CollectText",
      "d": 1310724,
      "h": 81605689348,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81605689348),
//--TRIMMABLE-BOUNDARY-START(90195623940),
    {
      "r": 262145,
      "p": [
        {
          "n": "e",
          "p": 1310724
        }
      ],
      "n": "ContentsEqual",
      "d": 1310724,
      "h": 90195623940,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(90195623940),
//--TRIMMABLE-BOUNDARY-START(94490591236),
    {
      "r": 655361,
      "n": "ContentsHashCode",
      "d": 1310724,
      "h": 94490591236,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(94490591236),
//--TRIMMABLE-BOUNDARY-START(98785558532),
    {
      "r": 65537,
      "n": "ConvertTextToNode",
      "d": 1310724,
      "h": 98785558532,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(98785558532),
//--TRIMMABLE-BOUNDARY-START(158915100676),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,
      "p": [
        {
          "n": "self",
          "p": 262145
        }
      ],
      "n": "GetDescendantNodes",
      "d": 1310724,
      "h": 158915100676,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(158915100676),
//--TRIMMABLE-BOUNDARY-START(163210067972),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "name",
          "p": 2097156
        },
        {
          "n": "self",
          "p": 262145
        }
      ],
      "n": "GetDescendants",
      "d": 1310724,
      "h": 163210067972,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(163210067972),
//--TRIMMABLE-BOUNDARY-START(167505035268),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "GetElements",
      "d": 1310724,
      "h": 167505035268,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167505035268),
//--TRIMMABLE-BOUNDARY-START(171800002564),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "GetStringValue",
      "d": 1310724,
      "h": 171800002564,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(171800002564),
//--TRIMMABLE-BOUNDARY-START(193274839044),
    {
      "r": 65537,
      "p": [
        {
          "n": "r",
          "p": 53346307
        }
      ],
      "n": "ReadContentFrom",
      "o": "@$1",
      "d": 1310724,
      "h": 193274839044,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(193274839044),
//--TRIMMABLE-BOUNDARY-START(188979871748),
    {
      "r": 65537,
      "p": [
        {
          "n": "r",
          "p": 53346307
        },
        {
          "n": "o",
          "p": 655364
        }
      ],
      "n": "ReadContentFrom",
      "d": 1310724,
      "h": 188979871748,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(188979871748),
//--TRIMMABLE-BOUNDARY-START(197569806340),
    {
      "r": 177668097,
      "p": [
        {
          "n": "r",
          "p": 53346307
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadContentFromAsync",
      "d": 1310724,
      "h": 197569806340,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(197569806340),
//--TRIMMABLE-BOUNDARY-START(201864773636),
    {
      "r": 177668097,
      "p": [
        {
          "n": "r",
          "p": 53346307
        },
        {
          "n": "o",
          "p": 655364
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadContentFromAsync",
      "o": "@$1",
      "d": 1310724,
      "h": 201864773636,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(201864773636),
//--TRIMMABLE-BOUNDARY-START(206159740932),
    {
      "r": 65537,
      "p": [
        {
          "n": "n",
          "p": 2228228
        }
      ],
      "n": "RemoveNode",
      "d": 1310724,
      "h": 206159740932,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(206159740932),
//--TRIMMABLE-BOUNDARY-START(214749675524),
    {
      "r": 65537,
      "n": "RemoveNodesSkipNotify",
      "d": 1310724,
      "h": 214749675524,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(214749675524),
//--TRIMMABLE-BOUNDARY-START(227634577412),
    {
      "r": 65537,
      "p": [
        {
          "n": "node",
          "p": 2228228
        },
        {
          "n": "previous",
          "p": 2228228
        }
      ],
      "n": "ValidateNode",
      "d": 1310724,
      "h": 227634577412,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(227634577412),
//--TRIMMABLE-BOUNDARY-START(231929544708),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "ValidateString",
      "d": 1310724,
      "h": 231929544708,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(231929544708),
//--TRIMMABLE-BOUNDARY-START(236224512004),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        }
      ],
      "n": "WriteContentTo",
      "d": 1310724,
      "h": 236224512004,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(236224512004),
//--TRIMMABLE-BOUNDARY-START(240519479300),
    {
      "r": 177668097,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteContentToAsync",
      "d": 1310724,
      "h": 240519479300,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(240519479300),
//--TRIMMABLE-BOUNDARY-START(38656016388),
    {
      "r": 65537,
      "p": [
        {
          "n": "list",
          "p": $.$$.System.Collections.Generic.List$$($.$$.System.Object).$h
        },
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "AddContentToList",
      "d": 1310724,
      "h": 38656016388,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38656016388),
//--TRIMMABLE-BOUNDARY-START(154620133380),
    {
      "r": 131073,
      "p": [
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "GetContentSnapshot",
      "d": 1310724,
      "h": 154620133380,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(154620133380)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(85900656644),
    {
      "t": 131073,
      "n": "content",
      "d": 1310724,
      "h": 85900656644,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(85900656644)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591245316),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1310724,
      "h": 8591245316,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591245316),
//--TRIMMABLE-BOUNDARY-START(12886212612),
    {
      "p": [
        {
          "n": "other",
          "p": 1310724
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1310724,
      "h": 12886212612,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886212612)
  ],
  "i": [13893635
  ],
  "j": [1376260
  ],
  "h": 1310724
}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XContainer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310724)
        
        
        //--TRIMMABLE-BOUNDARY-START(262148)
        $asm.$cls("$spxl.System.Xml.Linq.BaseUriAnnotation", ($self) => class BaseUriAnnotation extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590196740)
            /*string*/ baseUri = null;
            //--TRIMMABLE-BOUNDARY-END(8590196740)
            
            //--TRIMMABLE-BOUNDARY-START(4295229444)
            $ctor$1(/*string*/ baseUri)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229444);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.baseUri = baseUri;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229444)
            
            static $h = 262148;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590196740),
    {
      "t": 1310721,
      "n": "baseUri",
      "d": 262148,
      "h": 8590196740,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590196740)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229444),
    {
      "p": [
        {
          "n": "baseUri",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262148,
      "h": 4295229444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229444)
  ],
  "h": 262148
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.BaseUriAnnotation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262148)
        
        
        //--TRIMMABLE-BOUNDARY-START(524292)
        $asm.$cls("$spxl.System.Xml.Linq.LineInfoAnnotation", ($self) => class LineInfoAnnotation extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590458884)
            /*int*/ lineNumber = 0;
            //--TRIMMABLE-BOUNDARY-END(8590458884)
            
            //--TRIMMABLE-BOUNDARY-START(12885426180)
            /*int*/ linePosition = 0;
            //--TRIMMABLE-BOUNDARY-END(12885426180)
            
            //--TRIMMABLE-BOUNDARY-START(4295491588)
            $ctor$1(/*int*/ lineNumber, /*int*/ linePosition)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295491588);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.lineNumber = lineNumber;
                    this.linePosition = linePosition;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491588)
            
            static $h = 524292;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590458884),
    {
      "t": 655361,
      "n": "lineNumber",
      "d": 524292,
      "h": 8590458884,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590458884),
//--TRIMMABLE-BOUNDARY-START(12885426180),
    {
      "t": 655361,
      "n": "linePosition",
      "d": 524292,
      "h": 12885426180,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885426180)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491588),
    {
      "p": [
        {
          "n": "lineNumber",
          "p": 655361
        },
        {
          "n": "linePosition",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524292,
      "h": 4295491588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491588)
  ],
  "h": 524292
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.LineInfoAnnotation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524292)
        
        
        //--TRIMMABLE-BOUNDARY-START(196612)
        $asm.$cls("$spxl.System.Text.StringBuilderCache", ($self) => class StringBuilderCache
        {
            //--TRIMMABLE-BOUNDARY-START(17180065796)
            /*int*/ static MaxBuilderSize = 360;
            //--TRIMMABLE-BOUNDARY-END(17180065796)
            
            //--TRIMMABLE-BOUNDARY-START(8590131204)
            /*int*/ static DefaultCapacity = 16;
            //--TRIMMABLE-BOUNDARY-END(8590131204)
            
            //--TRIMMABLE-BOUNDARY-START(25770000388)
            /*StringBuilder?*/ static t_cachedInstance = null;
            //--TRIMMABLE-BOUNDARY-END(25770000388)
            
            //--TRIMMABLE-BOUNDARY-START(4295163908)
            static /*StringBuilder */ Acquire(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295163908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (capacity <= 360/*MaxBuilderSize*/)
                {
                    /*StringBuilder?*/ let sb = $.$spxl.System.Text.StringBuilderCache.t_cachedInstance;
                    if (sb !== null)
                    {
                        if (capacity <= sb.Capacity)
                        {
                            $.$spxl.System.Text.StringBuilderCache.t_cachedInstance = null;
                            sb.Clear();
                            return sb;
                        }
                    }
                }
                return new $.$$.System.Text.StringBuilder().$ctor$4(capacity);
            }
            //--TRIMMABLE-BOUNDARY-END(4295163908)
            
            //--TRIMMABLE-BOUNDARY-START(21475033092)
            static /*void */ Release(/*StringBuilder*/ sb)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (sb.Capacity <= 360/*MaxBuilderSize*/)
                {
                    $.$spxl.System.Text.StringBuilderCache.t_cachedInstance = sb;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475033092)
            
            //--TRIMMABLE-BOUNDARY-START(12885098500)
            static /*string */ GetStringAndRelease(/*StringBuilder*/ sb)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let result = $.$$.System.Text.StringBuilder.ToString.call(sb);
                $.$spxl.System.Text.StringBuilderCache.Release(sb);
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098500)
            
            static $h = 196612;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295163908),
    {
      "r": 167051265,
      "p": [
        {
          "n": "capacity",
          "p": 655361,
          "f": 65,
          "v": 16
        }
      ],
      "n": "Acquire",
      "d": 196612,
      "h": 4295163908,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295163908),
//--TRIMMABLE-BOUNDARY-START(21475033092),
    {
      "r": 65537,
      "p": [
        {
          "n": "sb",
          "p": 167051265
        }
      ],
      "n": "Release",
      "d": 196612,
      "h": 21475033092,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475033092),
//--TRIMMABLE-BOUNDARY-START(12885098500),
    {
      "r": 1310721,
      "p": [
        {
          "n": "sb",
          "p": 167051265
        }
      ],
      "n": "GetStringAndRelease",
      "d": 196612,
      "h": 12885098500,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885098500)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180065796),
    {
      "t": 655361,
      "n": "MaxBuilderSize",
      "d": 196612,
      "h": 17180065796,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180065796),
//--TRIMMABLE-BOUNDARY-START(8590131204),
    {
      "t": 655361,
      "n": "DefaultCapacity",
      "d": 196612,
      "h": 8590131204,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590131204),
//--TRIMMABLE-BOUNDARY-START(25770000388),
    {
      "t": 167051265,
      "n": "t_cachedInstance",
      "d": 196612,
      "h": 25770000388,
      "f": 4194338,
      "a": [
        {
          "t": 185335809,
          "c": 4480303105
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770000388)
  ],
  "h": 196612
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.StringBuilderCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196612)
        
        
        //--TRIMMABLE-BOUNDARY-START(65540)
        $asm.$cls("$spxl.System.Collections.Generic.EnumerableHelpers", ($self) => class EnumerableHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(8590000132)
            static /*void */ Reset(T, /*ref T*/ enumerator)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000132);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$dsp(enumerator.$v, T, ($t) => $t.System$Collections$IEnumerator$Reset,);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000132)
            
            //--TRIMMABLE-BOUNDARY-START(4295032836)
            static /*IEnumerator<T> */ GetEmptyEnumerator(T)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032836);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ($.$$.System.Array.Empty(T)).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295032836)
            
            //--TRIMMABLE-BOUNDARY-START(12884967428)
            static /*T[] */ ToArray(T, /*IEnumerable<T>*/ source, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let ArrayMaxLength = 2147483591;
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Array.MaxLength === ArrayMaxLength, "Array.MaxLength == ArrayMaxLength");
                let ic;
                if ($.$is(source, $.$$.System.Collections.Generic.ICollection$$(T), { set $v(v){ ic = v; } }))
                {
                    /*int*/ let count = ic.System$Collections$Generic$ICollection$$$Count;
                    if (count !== 0)
                    {
                        /*T[]*/ let arr = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [count], null);
                        ic.System$Collections$Generic$ICollection$$$CopyTo(arr, 0, [T]);
                        length.$v = count;
                        return arr;
                    }
                }
                else 
                {
                    let en = null;
                    try
                    {
                        en = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                        if (en.System$Collections$IEnumerator$MoveNext())
                        {
                            /*int*/ let DefaultCapacity = 4;
                            /*T[]*/ let arr = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [DefaultCapacity], null);
                            $.$$.System.Array.$WriteT1.call(arr, en.System$Collections$Generic$IEnumerator$$$Current, 0);
                            /*int*/ let count = 1;
                            while(en.System$Collections$IEnumerator$MoveNext())
                            {
                                if (count === arr.length)
                                {
                                    /*int*/ let newLength = count << 1;
                                    if ((newLength >>> 0) > ArrayMaxLength)
                                    {
                                        newLength = ArrayMaxLength <= count ? ((count + 1) | 0) : ArrayMaxLength;
                                    }
                                    $.$$.System.Array.Resize(T, $.$ref(() => arr, ($v) => arr = $v, $.$typeArray(T)), newLength);
                                }
                                $.$$.System.Array.$WriteT1.call(arr, en.System$Collections$Generic$IEnumerator$$$Current, count++);
                            }
                            length.$v = count;
                            return arr;
                        }
                    }
                    finally
                    {
                        en?.System$IDisposable$Dispose();
                    }
                }
                length.$v = 0;
                return $.$$.System.Array.Empty(T);
            }
            //--TRIMMABLE-BOUNDARY-END(12884967428)
            
            static $h = 65540;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590000132),
    {
      "r": 65537,
      "p": [
        {
          "n": "enumerator",
          "p": (T) => T.$h,
          "f": 4
        }
      ],
      "g": [
        "T"
      ],
      "n": "Reset",
      "d": 65540,
      "h": 8590000132,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(8590000132),
//--TRIMMABLE-BOUNDARY-START(4295032836),
    {
      "r": (T) => $.$$.System.Collections.Generic.IEnumerator$$(T).$h,
      "g": [
        "T"
      ],
      "n": "GetEmptyEnumerator",
      "d": 65540,
      "h": 4295032836,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4295032836),
//--TRIMMABLE-BOUNDARY-START(12884967428),
    {
      "r": (T) => $.$typeArray(T).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        },
        {
          "n": "length",
          "p": 655361,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "ToArray",
      "d": 65540,
      "h": 12884967428,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(12884967428)
  ],
  "h": 65540
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.EnumerableHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65540)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441796)
        $asm.$cls("$spxl.System.Xml.Linq.XDeclaration", ($self) => class XDeclaration extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886343684)
            /*string?*/ _version = null;
            //--TRIMMABLE-BOUNDARY-END(12886343684)
            
            //--TRIMMABLE-BOUNDARY-START(4296409092)
            /*string?*/ _encoding = null;
            //--TRIMMABLE-BOUNDARY-END(4296409092)
            
            //--TRIMMABLE-BOUNDARY-START(8591376388)
            /*string?*/ _standalone = null;
            //--TRIMMABLE-BOUNDARY-END(8591376388)
            
            //--TRIMMABLE-BOUNDARY-START(17181310980)
            $ctor$1(/*string?*/ version, /*string?*/ encoding, /*string?*/ standalone)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181310980);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._version = version;
                    this._encoding = encoding;
                    this._standalone = standalone;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181310980)
            
            //--TRIMMABLE-BOUNDARY-START(25771245572)
            $ctor$3(/*XDeclaration*/ other)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771245572);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this._version = other._version;
                    this._encoding = other._encoding;
                    this._standalone = other._standalone;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771245572)
            
            //--TRIMMABLE-BOUNDARY-START(21476278276)
            $ctor$2(/*XmlReader*/ r)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476278276);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._version = r.GetAttribute$2("version");
                    this._encoding = r.GetAttribute$2("encoding");
                    this._standalone = r.GetAttribute$2("standalone");
                    r.Read();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476278276)
            
            //--TRIMMABLE-BOUNDARY-START(30066212868)
            /*string? */ get Encoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656147460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding;
            }
            /*string? */ set Encoding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425951236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._encoding = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30066212868)
            
            //--TRIMMABLE-BOUNDARY-START(85900787716)
            /*string? */ get Standalone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246082052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._standalone;
            }
            /*string? */ set Standalone(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015885828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._standalone = value;
            }
            //--TRIMMABLE-BOUNDARY-END(85900787716)
            
            //--TRIMMABLE-BOUNDARY-START(94490722308)
            /*string? */ get Version()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836016644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._version;
            }
            /*string? */ set Version(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605820420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._version = value;
            }
            //--TRIMMABLE-BOUNDARY-END(94490722308)
            
            //--TRIMMABLE-BOUNDARY-START(90195755012)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195755012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*StringBuilder*/ let sb = $.$spxl.System.Text.StringBuilderCache.Acquire(16);
                sb.Append$19("<?xml");
                if ($.$$.System.String.op_Inequality(this._version, null))
                {
                    sb.Append$19(" version=\"");
                    sb.Append$19(this._version);
                    sb.Append$3(/*\"*/ 34);
                }
                if ($.$$.System.String.op_Inequality(this._encoding, null))
                {
                    sb.Append$19(" encoding=\"");
                    sb.Append$19(this._encoding);
                    sb.Append$3(/*\"*/ 34);
                }
                if ($.$$.System.String.op_Inequality(this._standalone, null))
                {
                    sb.Append$19(" standalone=\"");
                    sb.Append$19(this._standalone);
                    sb.Append$3(/*\"*/ 34);
                }
                sb.Append$19("?>");
                return $.$spxl.System.Text.StringBuilderCache.GetStringAndRelease(sb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XDeclaration.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(90195755012)
            
            static $h = 1441796;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066212868),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656147460,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425951236,
        "f": 83886081
      },
      "n": "Encoding",
      "d": 1441796,
      "h": 30066212868,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066212868),
//--TRIMMABLE-BOUNDARY-START(85900787716),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246082052,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015885828,
        "f": 83886081
      },
      "n": "Standalone",
      "d": 1441796,
      "h": 85900787716,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900787716),
//--TRIMMABLE-BOUNDARY-START(94490722308),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836016644,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605820420,
        "f": 83886081
      },
      "n": "Version",
      "d": 1441796,
      "h": 94490722308,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490722308)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90195755012),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1441796,
      "h": 90195755012,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195755012)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886343684),
    {
      "t": 1310721,
      "n": "_version",
      "d": 1441796,
      "h": 12886343684,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886343684),
//--TRIMMABLE-BOUNDARY-START(4296409092),
    {
      "t": 1310721,
      "n": "_encoding",
      "d": 1441796,
      "h": 4296409092,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296409092),
//--TRIMMABLE-BOUNDARY-START(8591376388),
    {
      "t": 1310721,
      "n": "_standalone",
      "d": 1441796,
      "h": 8591376388,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591376388)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181310980),
    {
      "p": [
        {
          "n": "version",
          "p": 1310721
        },
        {
          "n": "encoding",
          "p": 1310721
        },
        {
          "n": "standalone",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1441796,
      "h": 17181310980,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181310980),
//--TRIMMABLE-BOUNDARY-START(25771245572),
    {
      "p": [
        {
          "n": "other",
          "p": 1441796
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1441796,
      "h": 25771245572,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771245572),
//--TRIMMABLE-BOUNDARY-START(21476278276),
    {
      "p": [
        {
          "n": "r",
          "p": 53346307
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1441796,
      "h": 21476278276,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21476278276)
  ],
  "h": 1441796
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XDeclaration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441796)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031620)
        $asm.$cls("$spxl.System.Xml.Linq.XHelper", ($self) => class XHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4296998916)
            static /*bool */ IsInstanceOfType(/*object?*/ o, /*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296998916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Inequality$1(type, null), "type != null");
                return o !== null && type.IsAssignableFrom($.$$.System.Object.GetType.call(o));
            }
            //--TRIMMABLE-BOUNDARY-END(4296998916)
            
            static $h = 2031620;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296998916),
    {
      "r": 262145,
      "p": [
        {
          "n": "o",
          "p": 131073
        },
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "IsInstanceOfType",
      "d": 2031620,
      "h": 4296998916,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296998916)
  ],
  "h": 2031620
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031620)
        
        
        //--TRIMMABLE-BOUNDARY-START(131076)
        $asm.$cls("$spxl.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(515396206596)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(515396206596)
            
            //--TRIMMABLE-BOUNDARY-START(506806272004)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(506806272004)
            
            //--TRIMMABLE-BOUNDARY-START(511101239300)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412316991492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$spxl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Private.Xml.Linq", $.$spxl.System.SR.$type.Assembly);
                    $.$spxl.System.SR.s_resourceManager = temp;
                }
                return $.$spxl.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(511101239300)
            
            //--TRIMMABLE-BOUNDARY-START(60129673220)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108234244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528281108484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$spxl.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(60129673220)
            
            //--TRIMMABLE-BOUNDARY-START(8590065668)
            static /*string */ get Argument_AddAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029019140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An attribute cannot be added to content.";
            }
            //--TRIMMABLE-BOUNDARY-END(8590065668)
            
            //--TRIMMABLE-BOUNDARY-START(12885032964)
            static /*string */ get Argument_AddNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154618953732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A node of type {0} cannot be added to content.";
            }
            //--TRIMMABLE-BOUNDARY-END(12885032964)
            
            //--TRIMMABLE-BOUNDARY-START(98784378884)
            static /*string */ FormatArgument_AddNode(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784378884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("A node of type {0} cannot be added to content.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(98784378884)
            
            //--TRIMMABLE-BOUNDARY-START(17180000260)
            static /*string */ get Argument_AddNonWhitespace()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163208888324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Non-whitespace characters cannot be added to content.";
            }
            //--TRIMMABLE-BOUNDARY-END(17180000260)
            
            //--TRIMMABLE-BOUNDARY-START(21474967556)
            static /*string */ get Argument_ConvertToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798822916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The argument cannot be converted to a string.";
            }
            //--TRIMMABLE-BOUNDARY-END(21474967556)
            
            //--TRIMMABLE-BOUNDARY-START(30064902148)
            static /*string */ get Argument_InvalidExpandedName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978692100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'{0}' is an invalid expanded name.";
            }
            //--TRIMMABLE-BOUNDARY-END(30064902148)
            
            //--TRIMMABLE-BOUNDARY-START(107374313476)
            static /*string */ FormatArgument_InvalidExpandedName(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374313476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("'{0}' is an invalid expanded name.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(107374313476)
            
            //--TRIMMABLE-BOUNDARY-START(34359869444)
            static /*string */ get Argument_InvalidPIName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568626692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'{0}' is an invalid name for a processing instruction.";
            }
            //--TRIMMABLE-BOUNDARY-END(34359869444)
            
            //--TRIMMABLE-BOUNDARY-START(111669280772)
            static /*string */ FormatArgument_InvalidPIName(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669280772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("'{0}' is an invalid name for a processing instruction.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(111669280772)
            
            //--TRIMMABLE-BOUNDARY-START(38654836740)
            static /*string */ get Argument_MustBeDerivedFrom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158561284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The argument must be derived from {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(38654836740)
            
            //--TRIMMABLE-BOUNDARY-START(115964248068)
            static /*string */ FormatArgument_MustBeDerivedFrom(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964248068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The argument must be derived from {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(115964248068)
            
            //--TRIMMABLE-BOUNDARY-START(42949804036)
            static /*string */ get Argument_NamespaceDeclarationPrefixed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748495876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The prefix '{0}' cannot be bound to the empty namespace name.";
            }
            //--TRIMMABLE-BOUNDARY-END(42949804036)
            
            //--TRIMMABLE-BOUNDARY-START(120259215364)
            static /*string */ FormatArgument_NamespaceDeclarationPrefixed(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259215364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The prefix '{0}' cannot be bound to the empty namespace name.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(120259215364)
            
            //--TRIMMABLE-BOUNDARY-START(47244771332)
            static /*string */ get Argument_NamespaceDeclarationXml()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338430468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The prefix 'xml' is bound to the namespace name 'http://www.w3.org/XML/1998/namespace'. Other prefixes must not be bound to this namespace name, and it must not be declared as the default namespace.";
            }
            //--TRIMMABLE-BOUNDARY-END(47244771332)
            
            //--TRIMMABLE-BOUNDARY-START(51539738628)
            static /*string */ get Argument_NamespaceDeclarationXmlns()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928365060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The prefix 'xmlns' is bound to the namespace name 'http://www.w3.org/2000/xmlns/'. It must not be declared. Other prefixes must not be bound to this namespace name, and it must not be declared as the default namespace.";
            }
            //--TRIMMABLE-BOUNDARY-END(51539738628)
            
            //--TRIMMABLE-BOUNDARY-START(55834705924)
            static /*string */ get Argument_XObjectValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518299652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An XObject cannot be used as a value.";
            }
            //--TRIMMABLE-BOUNDARY-END(55834705924)
            
            //--TRIMMABLE-BOUNDARY-START(433791827972)
            static /*string */ get InvalidOperation_DeserializeInstance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288103428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This instance cannot be deserialized.";
            }
            //--TRIMMABLE-BOUNDARY-END(433791827972)
            
            //--TRIMMABLE-BOUNDARY-START(438086795268)
            static /*string */ get InvalidOperation_DocumentStructure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878038020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This operation would create an incorrectly structured document.";
            }
            //--TRIMMABLE-BOUNDARY-END(438086795268)
            
            //--TRIMMABLE-BOUNDARY-START(442381762564)
            static /*string */ get InvalidOperation_DuplicateAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283467972612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Duplicate attribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(442381762564)
            
            //--TRIMMABLE-BOUNDARY-START(446676729860)
            static /*string */ get InvalidOperation_ExpectedEndOfFile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292057907204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The XmlReader state should be EndOfFile after this operation.";
            }
            //--TRIMMABLE-BOUNDARY-END(446676729860)
            
            //--TRIMMABLE-BOUNDARY-START(450971697156)
            static /*string */ get InvalidOperation_ExpectedInteractive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300647841796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The XmlReader state should be Interactive.";
            }
            //--TRIMMABLE-BOUNDARY-END(450971697156)
            
            //--TRIMMABLE-BOUNDARY-START(455266664452)
            static /*string */ get InvalidOperation_ExpectedNodeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309237776388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The XmlReader must be on a node of type {0} instead of a node of type {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(455266664452)
            
            //--TRIMMABLE-BOUNDARY-START(128849149956)
            static /*string */ FormatInvalidOperation_ExpectedNodeType(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849149956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The XmlReader must be on a node of type {0} instead of a node of type {1}.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(128849149956)
            
            //--TRIMMABLE-BOUNDARY-START(459561631748)
            static /*string */ get InvalidOperation_ExternalCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317827710980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This operation was corrupted by external code.";
            }
            //--TRIMMABLE-BOUNDARY-END(459561631748)
            
            //--TRIMMABLE-BOUNDARY-START(463856599044)
            static /*string */ get InvalidOperation_MissingAncestor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326417645572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A common ancestor is missing.";
            }
            //--TRIMMABLE-BOUNDARY-END(463856599044)
            
            //--TRIMMABLE-BOUNDARY-START(468151566340)
            static /*string */ get InvalidOperation_MissingParent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007580164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The parent is missing.";
            }
            //--TRIMMABLE-BOUNDARY-END(468151566340)
            
            //--TRIMMABLE-BOUNDARY-START(472446533636)
            static /*string */ get InvalidOperation_MissingRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597514756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The root element is missing.";
            }
            //--TRIMMABLE-BOUNDARY-END(472446533636)
            
            //--TRIMMABLE-BOUNDARY-START(481036468228)
            static /*string */ get InvalidOperation_UnexpectedNodeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777383940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The XmlReader should not be on a node of type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(481036468228)
            
            //--TRIMMABLE-BOUNDARY-START(137439084548)
            static /*string */ FormatInvalidOperation_UnexpectedNodeType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439084548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The XmlReader should not be on a node of type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(137439084548)
            
            //--TRIMMABLE-BOUNDARY-START(485331435524)
            static /*string */ get InvalidOperation_UnresolvedEntityReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367318532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The XmlReader cannot resolve entity references.";
            }
            //--TRIMMABLE-BOUNDARY-END(485331435524)
            
            //--TRIMMABLE-BOUNDARY-START(489626402820)
            static /*string */ get InvalidOperation_WriteAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957253124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An attribute cannot be written after content.";
            }
            //--TRIMMABLE-BOUNDARY-END(489626402820)
            
            //--TRIMMABLE-BOUNDARY-START(498216337412)
            static /*string */ get NotSupported_WriteBase64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137122308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This XmlWriter does not support base64 encoded data.";
            }
            //--TRIMMABLE-BOUNDARY-END(498216337412)
            
            //--TRIMMABLE-BOUNDARY-START(502511304708)
            static /*string */ get NotSupported_WriteEntityRef()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727056900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This XmlWriter does not support entity references.";
            }
            //--TRIMMABLE-BOUNDARY-END(502511304708)
            
            //--TRIMMABLE-BOUNDARY-START(25769934852)
            static /*string */ get Argument_CreateNavigator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388757508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This XPathNavigator cannot be created on a node of type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(25769934852)
            
            //--TRIMMABLE-BOUNDARY-START(103079346180)
            static /*string */ FormatArgument_CreateNavigator(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079346180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("This XPathNavigator cannot be created on a node of type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(103079346180)
            
            //--TRIMMABLE-BOUNDARY-START(429496860676)
            static /*string */ get InvalidOperation_BadNodeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698168836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This operation is not valid on a node of type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(429496860676)
            
            //--TRIMMABLE-BOUNDARY-START(124554182660)
            static /*string */ FormatInvalidOperation_BadNodeType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554182660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("This operation is not valid on a node of type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(124554182660)
            
            //--TRIMMABLE-BOUNDARY-START(476741500932)
            static /*string */ get InvalidOperation_UnexpectedEvaluation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187449348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The XPath expression evaluated to unexpected type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(476741500932)
            
            //--TRIMMABLE-BOUNDARY-START(133144117252)
            static /*string */ FormatInvalidOperation_UnexpectedEvaluation(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144117252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The XPath expression evaluated to unexpected type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(133144117252)
            
            //--TRIMMABLE-BOUNDARY-START(493921370116)
            static /*string */ get NotSupported_MoveToId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386547187716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This XPathNavigator does not support IDs.";
            }
            //--TRIMMABLE-BOUNDARY-END(493921370116)
            
            //--TRIMMABLE-BOUNDARY-START(519691173892)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(519691173892)
            
            //--TRIMMABLE-BOUNDARY-START(425201893380)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(425201893380);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(425201893380)
            
            //--TRIMMABLE-BOUNDARY-START(532576075780)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(532576075780);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$spxl.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(532576075780)
            
            //--TRIMMABLE-BOUNDARY-START(420906926084)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420906926084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$spxl.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(420906926084)
            
            //--TRIMMABLE-BOUNDARY-START(416611958788)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416611958788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$spxl.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(416611958788)
            
            //--TRIMMABLE-BOUNDARY-START(90194444292)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194444292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(90194444292)
            
            //--TRIMMABLE-BOUNDARY-START(85899476996)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899476996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(85899476996)
            
            //--TRIMMABLE-BOUNDARY-START(81604509700)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604509700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(81604509700)
            
            //--TRIMMABLE-BOUNDARY-START(94489411588)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489411588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$spxl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(94489411588)
            
            //--TRIMMABLE-BOUNDARY-START(73014575108)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014575108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(73014575108)
            
            //--TRIMMABLE-BOUNDARY-START(68719607812)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719607812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(68719607812)
            
            //--TRIMMABLE-BOUNDARY-START(64424640516)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424640516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(64424640516)
            
            //--TRIMMABLE-BOUNDARY-START(77309542404)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309542404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$spxl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(77309542404)
            
            //--TRIMMABLE-BOUNDARY-START(4295098372)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(519691173892)
                    this.s_usingResourceKeys = $.$spxl.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(519691173892)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295098372)
            
            static $h = 131076;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 131076
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131076)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769476)
        $asm.$cls("$spxl.System.Xml.Linq.XHashtable<>", (TValue) => $asm.$gt("$spxl.System.Xml.Linq.XHashtable<>", [TValue], ($self) => class XHashtable$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296736772)
            /*XHashtableState*/ _state = null;
            //--TRIMMABLE-BOUNDARY-END(4296736772)
            
            //--TRIMMABLE-BOUNDARY-START(1835012)
            static $_ExtractKeyDelegate;
            static get ExtractKeyDelegate()
            {
                let $cls = $.$spxl.System.Xml.Linq.XHashtable$$(TValue);
                return $cls.$_ExtractKeyDelegate ??= $asm.$ncls("$spxl.System.Xml.Linq.XHashtable$$.ExtractKeyDelegate", ($self) => class ExtractKeyDelegate extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*string?*/ Invoke(/**/ value)
                    {
                        return this.$nativeFunction.call(this.$target, value);
                    }
                    static $h = 1835012;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 98959361,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181704196),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": TValue?.$h??1507328
        }
      ],
      "n": "Invoke",
      "d": 1835012,
      "h": Number(BigInt(1835012)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181704196),
//--TRIMMABLE-BOUNDARY-START(8591769604),
    {
      "r": 89784321,
      "p": [
        {
          "n": "value",
          "p": TValue?.$h??1507328
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 1835012,
      "h": Number(BigInt(1835012)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591769604),
//--TRIMMABLE-BOUNDARY-START(12886736900),
    {
      "r": 1310721,
      "p": [
        {
          "n": "result",
          "p": 89784321
        }
      ],
      "n": "EndInvoke",
      "d": 1835012,
      "h": Number(BigInt(1835012)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886736900)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802308),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1835012,
      "h": Number(BigInt(1835012)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296802308)
  ],
  "i": [89980929,157483009
  ],
  "d": $.$spxl.System.Xml.Linq.XHashtable$$(TValue).$h,
  "h": 1835012
}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>.ExtractKeyDelegate`; }
                }, $cls, ($v) => $cls.$_ExtractKeyDelegate = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1835012)
            
            //--TRIMMABLE-BOUNDARY-START(17181638660)
            $ctor$1(/*ExtractKeyDelegate*/ extractKey, /*int*/ capacity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181638660);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._state = new ($.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState)().$ctor$1(extractKey, capacity);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181638660)
            
            //--TRIMMABLE-BOUNDARY-START(25771573252)
            /*bool */ TryGetValue(/*string*/ key, /*int*/ index, /*int*/ count, /*out TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771573252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._state.TryGetValue(key, index, count, value);
            }
            //--TRIMMABLE-BOUNDARY-END(25771573252)
            
            //--TRIMMABLE-BOUNDARY-START(21476605956)
            /*TValue */ Add(/*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476605956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TValue*/ let newValue;
                while(true)
                {
                    if (this._state.TryAdd(value, $.$ref(() => newValue, ($v) => newValue = $v, TValue)))
                    {
                        return newValue;
                    }
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this)
                        {
                            /*XHashtableState*/ let newState = this._state.Resize();
                            $.$$.System.Threading.Thread.MemoryBarrier();
                            this._state = newState;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476605956)
            
            //--TRIMMABLE-BOUNDARY-START(1900548)
            static $_XHashtableState;
            static get XHashtableState()
            {
                let $cls = $.$spxl.System.Xml.Linq.XHashtable$$(TValue);
                return $cls.$_XHashtableState ??= $asm.$ncls("$spxl.System.Xml.Linq.XHashtable$$.XHashtableState", ($self) => class XHashtableState extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296867844)
                    /*int[]*/ _buckets = null;
                    //--TRIMMABLE-BOUNDARY-END(4296867844)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591835140)
                    /*Entry[]*/ _entries = null;
                    //--TRIMMABLE-BOUNDARY-END(8591835140)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181769732)
                    /*int*/ _numEntries = 0;
                    //--TRIMMABLE-BOUNDARY-END(17181769732)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886802436)
                    /*ExtractKeyDelegate*/ _extractKey = null;
                    //--TRIMMABLE-BOUNDARY-END(12886802436)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361638916)
                    /*int*/ static EndOfList = 0;
                    //--TRIMMABLE-BOUNDARY-END(34361638916)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951573508)
                    /*int*/ static FullList = -1;
                    //--TRIMMABLE-BOUNDARY-END(42951573508)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771704324)
                    $ctor$1(/*ExtractKeyDelegate*/ extractKey, /*int*/ capacity)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25771704324);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Numerics.BitOperations.IsPow2(capacity), "capacity must be a power of 2");
                            $.$$.System.Diagnostics.Debug.Assert$2(extractKey !== null, "extractKey may not be null");
                            this._buckets = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [capacity], null);
                            this._entries = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.Entry), null, [capacity], null);
                            this._extractKey = extractKey;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771704324)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246540804)
                    /*XHashtableState */ Resize()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47246540804);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._numEntries < this._buckets.length)
                        {
                            return this;
                        }
                        /*int*/ let newSize = 0;
                        for(/*int*/ let bucketIdx = 0; bucketIdx < this._buckets.length; bucketIdx++)
                        {
                            /*int*/ let entryIdx = $.$$.System.Array.$ReadT1.call(this._buckets, bucketIdx);
                            if (entryIdx === 0/*EndOfList*/)
                            {
                                entryIdx = $.$$.System.Threading.Interlocked.CompareExchange$3($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$$.System.Int32, this._buckets, bucketIdx, false, true), -1/*FullList*/, 0/*EndOfList*/);
                            }
                            while(entryIdx > 0/*EndOfList*/)
                            {
                                if ($.$$.System.String.op_Inequality(this._extractKey.Invoke($.$$.System.Array.$ReadT1.call(this._entries, entryIdx).Value), null))
                                {
                                    newSize++;
                                }
                                if ($.$$.System.Array.$ReadT1.call(this._entries, entryIdx).Next === 0/*EndOfList*/)
                                {
                                    entryIdx = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => $.$$.System.Array.$ReadT1.call(this._entries, entryIdx).Next, ($v) => $.$$.System.Array.$ReadT1.call(this._entries, entryIdx).Next = $v, $.$$.System.Int32), -1/*FullList*/, 0/*EndOfList*/);
                                }
                                else 
                                {
                                    entryIdx = $.$$.System.Array.$ReadT1.call(this._entries, entryIdx).Next;
                                }
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(entryIdx === 0/*EndOfList*/, "Resize() should only be called by one thread");
                        }
                        if (newSize < $.trunc(this._buckets.length / 2))
                        {
                            newSize = this._buckets.length;
                        }
                        else 
                        {
                            newSize = ((this._buckets.length * 2) | 0);
                            if (newSize < 0)
                            {
                                throw new $.$$.System.OverflowException().$ctor$13();
                            }
                        }
                        /*XHashtableState*/ let newHashtable = new ($.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState)().$ctor$1(this._extractKey, newSize);
                        for(/*int*/ let bucketIdx = 0; bucketIdx < this._buckets.length; bucketIdx++)
                        {
                            /*int*/ let entryIdx = $.$$.System.Array.$ReadT1.call(this._buckets, bucketIdx);
                            while(entryIdx > 0/*EndOfList*/)
                            {
                                newHashtable.TryAdd($.$$.System.Array.$ReadT1.call(this._entries, entryIdx).Value, $.$discardRef());
                                entryIdx = $.$$.System.Array.$ReadT1.call(this._entries, entryIdx).Next;
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(entryIdx === -1/*FullList*/, "Linked list should have been closed when it was counted");
                        }
                        return newHashtable;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47246540804)
                    
                    //--TRIMMABLE-BOUNDARY-START(55836475396)
                    /*bool */ TryGetValue(/*string*/ key, /*int*/ index, /*int*/ count, /*out TValue*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55836475396);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*int*/ let hashCode = $.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.ComputeHashCode(key, index, count);
                        /*int*/ let entryIndex = 0;
                        if (this.FindEntry(hashCode, key, index, count, $.$ref(() => entryIndex, ($v) => entryIndex = $v, $.$$.System.Int32)))
                        {
                            value.$v = $.$$.System.Array.$ReadT1.call(this._entries, entryIndex).Value;
                            return true;
                        }
                        value.$v = $.$default(TValue);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(55836475396)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541508100)
                    /*bool */ TryAdd(/*TValue*/ value, /*out TValue*/ newValue)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51541508100);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*int*/ let newEntry, entryIndex;
                        /*string?*/ let key;
                        /*int*/ let hashCode;
                        newValue.$v = value;
                        key = this._extractKey.Invoke(value);
                        if ($.$$.System.String.op_Equality(key, null))
                        {
                            return true;
                        }
                        hashCode = $.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.ComputeHashCode(key, 0, key.length);
                        newEntry = $.$$.System.Threading.Interlocked.Increment($.$ref(() => this._numEntries, ($v) => this._numEntries = $v, $.$$.System.Int32));
                        if (newEntry < 0 || newEntry >= this._buckets.length)
                        {
                            return false;
                        }
                        $.$$.System.Array.$ReadT1.call(this._entries, newEntry).Value = value;
                        $.$$.System.Array.$ReadT1.call(this._entries, newEntry).HashCode = hashCode;
                        $.$$.System.Threading.Thread.MemoryBarrier();
                        entryIndex = 0;
                        while(!this.FindEntry(hashCode, key, 0, key.length, $.$ref(() => entryIndex, ($v) => entryIndex = $v, $.$$.System.Int32)))
                        {
                            if (entryIndex === 0)
                            {
                                entryIndex = $.$$.System.Threading.Interlocked.CompareExchange$3($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$$.System.Int32, this._buckets, hashCode & (((this._buckets.length - 1) | 0)), false, true), newEntry, 0/*EndOfList*/);
                            }
                            else 
                            {
                                entryIndex = $.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => $.$$.System.Array.$ReadT1.call(this._entries, entryIndex).Next, ($v) => $.$$.System.Array.$ReadT1.call(this._entries, entryIndex).Next = $v, $.$$.System.Int32), newEntry, 0/*EndOfList*/);
                            }
                            if (entryIndex <= 0/*EndOfList*/)
                            {
                                return entryIndex === 0/*EndOfList*/;
                            }
                        }
                        newValue.$v = $.$$.System.Array.$ReadT1.call(this._entries, entryIndex).Value;
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51541508100)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656606212)
                    /*bool */ FindEntry(/*int*/ hashCode, /*string*/ key, /*int*/ index, /*int*/ count, /*ref int*/ entryIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38656606212);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*int*/ let previousIndex = entryIndex.$v;
                        /*int*/ let currentIndex;
                        if (previousIndex === 0)
                        {
                            currentIndex = $.$$.System.Array.$ReadT1.call(this._buckets, hashCode & (((this._buckets.length - 1) | 0)));
                        }
                        else 
                        {
                            currentIndex = previousIndex;
                        }
                        while(currentIndex > 0/*EndOfList*/)
                        {
                            if ($.$$.System.Array.$ReadT1.call(this._entries, currentIndex).HashCode === hashCode)
                            {
                                /*string?*/ let keyCompare = this._extractKey.Invoke($.$$.System.Array.$ReadT1.call(this._entries, currentIndex).Value);
                                if ($.$$.System.String.op_Equality(keyCompare, null))
                                {
                                    if ($.$$.System.Array.$ReadT1.call(this._entries, currentIndex).Next > 0/*EndOfList*/)
                                    {
                                        $.$$.System.Array.$ReadT1.call(this._entries, currentIndex).Value = $.$default(TValue);
                                        currentIndex = $.$$.System.Array.$ReadT1.call(this._entries, currentIndex).Next;
                                        if (previousIndex === 0)
                                        {
                                            $.$$.System.Array.$WriteT1.call(this._buckets, currentIndex, hashCode & (((this._buckets.length - 1) | 0)));
                                        }
                                        else 
                                        {
                                            $.$$.System.Array.$ReadT1.call(this._entries, previousIndex).Next = currentIndex;
                                        }
                                        continue;
                                    }
                                }
                                else 
                                {
                                    if (count === keyCompare.length && $.$$.System.String.CompareOrdinal$1(key, index, keyCompare, 0, count) === 0)
                                    {
                                        entryIndex.$v = currentIndex;
                                        return true;
                                    }
                                }
                            }
                            previousIndex = currentIndex;
                            currentIndex = $.$$.System.Array.$ReadT1.call(this._entries, currentIndex).Next;
                        }
                        entryIndex.$v = previousIndex;
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656606212)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066671620)
                    static /*int */ ComputeHashCode(/*string*/ key, /*int*/ index, /*int*/ count)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30066671620);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Inequality(key, null), "key should have been checked previously for null");
                        return $.$$.System.String.GetHashCode$2($.$$.System.MemoryExtensions.AsSpan$1(key, index, count));
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066671620)
                    
                    //--TRIMMABLE-BOUNDARY-START(1966084)
                    static $_Entry;
                    static get Entry()
                    {
                        let $cls = $.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState;
                        return $cls.$_Entry ??= $asm.$nstr("$spxl.System.Xml.Linq.XHashtable$$.XHashtableState.Entry", ($self) => class Entry extends $.$$.System.ValueType
                        {
                            //--TRIMMABLE-BOUNDARY-START(17181835268)
                            /*TValue*/  get Value() { return this.$getField(0, 4); }
                            /*TValue*/  set Value(value) { this.$setField(0, 4, value); }
                            //--TRIMMABLE-BOUNDARY-END(17181835268)
                            
                            //--TRIMMABLE-BOUNDARY-START(8591900676)
                            /*int*/  get HashCode() { return this.$getField(4, 4); }
                            /*int*/  set HashCode(value) { this.$setField(4, 4, value); }
                            //--TRIMMABLE-BOUNDARY-END(8591900676)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886867972)
                            /*int*/  get Next() { return this.$getField(8, 4); }
                            /*int*/  set Next(value) { this.$setField(8, 4, value); }
                            //--TRIMMABLE-BOUNDARY-END(12886867972)
                            
                            //--TRIMMABLE-BOUNDARY-START(4296933380)
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(4296933380)
                            
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy.Value = this.Value;
                                copy.HashCode = this.HashCode;
                                copy.Next = this.Next;
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                //--TRIMMABLE-BOUNDARY-START(17181835268)
                                this.Value = $.$default(TValue);
                                //--TRIMMABLE-BOUNDARY-END(17181835268)
                                
                                //--TRIMMABLE-BOUNDARY-START(8591900676)
                                this.HashCode = 0;
                                //--TRIMMABLE-BOUNDARY-END(8591900676)
                                
                                //--TRIMMABLE-BOUNDARY-START(12886867972)
                                this.Next = 0;
                                //--TRIMMABLE-BOUNDARY-END(12886867972)
                                
                            }
                            static $h = 1966084;
                            static $z = 12;
                            static $f = 0b10000001011000000;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181835268),
    {
      "t": TValue?.$h??1507328,
      "n": "Value",
      "d": 1966084,
      "h": Number(BigInt(1966084)|0x400000000n),
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17181835268),
//--TRIMMABLE-BOUNDARY-START(8591900676),
    {
      "t": 655361,
      "n": "HashCode",
      "d": 1966084,
      "h": Number(BigInt(1966084)|0x200000000n),
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8591900676),
//--TRIMMABLE-BOUNDARY-START(12886867972),
    {
      "t": 655361,
      "n": "Next",
      "d": 1966084,
      "h": Number(BigInt(1966084)|0x300000000n),
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12886867972)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296933380),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1966084,
      "h": Number(BigInt(1966084)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296933380)
  ],
  "d": 1900548,
  "h": 1966084
}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>.XHashtableState.Entry`; }
                        }, $cls, ($v) => $cls.$_Entry = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1966084)
                    
                    static $h = 1900548;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246540804),
    {
      "r": 1900548,
      "n": "Resize",
      "d": 1900548,
      "h": Number(BigInt(1900548)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246540804),
//--TRIMMABLE-BOUNDARY-START(55836475396),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "value",
          "p": TValue?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": 1900548,
      "h": Number(BigInt(1900548)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836475396),
//--TRIMMABLE-BOUNDARY-START(51541508100),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": TValue?.$h??1507328
        },
        {
          "n": "newValue",
          "p": TValue?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryAdd",
      "d": 1900548,
      "h": Number(BigInt(1900548)|0xC00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541508100),
//--TRIMMABLE-BOUNDARY-START(38656606212),
    {
      "r": 262145,
      "p": [
        {
          "n": "hashCode",
          "p": 655361
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "entryIndex",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "FindEntry",
      "d": 1900548,
      "h": Number(BigInt(1900548)|0x900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38656606212),
//--TRIMMABLE-BOUNDARY-START(30066671620),
    {
      "r": 655361,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ComputeHashCode",
      "d": 1900548,
      "h": Number(BigInt(1900548)|0x700000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066671620)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296867844),
    {
      "t": $.$typeArray($.$$.System.Int32).$h,
      "n": "_buckets",
      "d": 1900548,
      "h": Number(BigInt(1900548)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296867844),
//--TRIMMABLE-BOUNDARY-START(8591835140),
    {
      "t": $.$typeArray($.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.Entry).$h,
      "n": "_entries",
      "d": 1900548,
      "h": Number(BigInt(1900548)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591835140),
//--TRIMMABLE-BOUNDARY-START(17181769732),
    {
      "t": 655361,
      "n": "_numEntries",
      "d": 1900548,
      "h": Number(BigInt(1900548)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181769732),
//--TRIMMABLE-BOUNDARY-START(12886802436),
    {
      "t": 1835012,
      "n": "_extractKey",
      "d": 1900548,
      "h": Number(BigInt(1900548)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886802436),
//--TRIMMABLE-BOUNDARY-START(34361638916),
    {
      "t": 655361,
      "n": "EndOfList",
      "d": 1900548,
      "h": Number(BigInt(1900548)|0x800000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34361638916),
//--TRIMMABLE-BOUNDARY-START(42951573508),
    {
      "t": 655361,
      "n": "FullList",
      "d": 1900548,
      "h": Number(BigInt(1900548)|0xA00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42951573508)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771704324),
    {
      "p": [
        {
          "n": "extractKey",
          "p": 1835012
        },
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1900548,
      "h": Number(BigInt(1900548)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771704324)
  ],
  "j": [1966084
  ],
  "d": $.$spxl.System.Xml.Linq.XHashtable$$(TValue).$h,
  "h": 1900548
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>.XHashtableState`; }
                }, $cls, ($v) => $cls.$_XHashtableState = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1900548)
            
            static $h = 1769476;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771573252),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "value",
          "p": TValue?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771573252),
//--TRIMMABLE-BOUNDARY-START(21476605956),
    {
      "r": TValue?.$h??1507328,
      "p": [
        {
          "n": "value",
          "p": TValue?.$h??1507328
        }
      ],
      "n": "Add",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476605956)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296736772),
    {
      "t": 1900548,
      "n": "_state",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296736772)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181638660),
    {
      "p": [
        {
          "n": "extractKey",
          "p": 1835012
        },
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181638660)
  ],
  "g": [TValue?.$h??1507328
  ],
  "j": [1835012,1900548
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1769476)
        
        
        //--TRIMMABLE-BOUNDARY-START(2686980)
        $asm.$cls("$spxl.System.Xml.Linq.XObjectChangeAnnotation", ($self) => class XObjectChangeAnnotation extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887588868)
            /*EventHandler<XObjectChangeEventArgs>?*/ changing = null;
            //--TRIMMABLE-BOUNDARY-END(12887588868)
            
            //--TRIMMABLE-BOUNDARY-START(8592621572)
            /*EventHandler<XObjectChangeEventArgs>?*/ changed = null;
            //--TRIMMABLE-BOUNDARY-END(8592621572)
            
            //--TRIMMABLE-BOUNDARY-START(4297654276)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297654276)
            
            static $h = 2686980;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887588868),
    {
      "t": $.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,
      "n": "changing",
      "d": 2686980,
      "h": 12887588868,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12887588868),
//--TRIMMABLE-BOUNDARY-START(8592621572),
    {
      "t": $.$$.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,
      "n": "changed",
      "d": 2686980,
      "h": 8592621572,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8592621572)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297654276),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2686980,
      "h": 4297654276,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297654276)
  ],
  "h": 2686980
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XObjectChangeAnnotation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2686980)
        
        
        //--TRIMMABLE-BOUNDARY-START(2883588)
        $asm.$cls("$spxl.System.Xml.Linq.XStreamingElement", ($self) => class XStreamingElement extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(42952556548)
            /*XName*/ name = null;
            //--TRIMMABLE-BOUNDARY-END(42952556548)
            
            //--TRIMMABLE-BOUNDARY-START(25772687364)
            /*object?*/ content = null;
            //--TRIMMABLE-BOUNDARY-END(25772687364)
            
            //--TRIMMABLE-BOUNDARY-START(12887785476)
            $ctor$3(/*XName*/ name)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887785476);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                    this.name = name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887785476)
            
            //--TRIMMABLE-BOUNDARY-START(4297850884)
            $ctor$1(/*XName*/ name, /*object?*/ content)
            {
                this.$ctor$3(name);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297850884);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.content = $.$is(content, $.$$.System.Collections.Generic.List$$($.$$.System.Object)) ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [content], [-1], null) : content;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297850884)
            
            //--TRIMMABLE-BOUNDARY-START(8592818180)
            $ctor$2(/*XName*/ name, /*params object?[]*/ content)
            {
                this.$ctor$3(name);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592818180);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.content = content;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592818180)
            
            //--TRIMMABLE-BOUNDARY-START(47247523844)
            /*XName */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362621956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.name;
            }
            /*XName */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902229508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.name = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47247523844)
            
            //--TRIMMABLE-BOUNDARY-START(17182752772)
            /*void */ Add(/*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182752772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (content !== null)
                {
                    /*List<object>?*/ let list = $.$as(this.content, $.$$.System.Collections.Generic.List$$($.$$.System.Object));
                    if (list === null)
                    {
                        list = new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                        if (this.content !== null)
                        {
                            list.Add(this.content);
                        }
                        this.content = list;
                    }
                    list.Add(content);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182752772)
            
            //--TRIMMABLE-BOUNDARY-START(21477720068)
            /*void */ Add$1(/*params object?[]*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477720068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Add($.$cast(content, $.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(21477720068)
            
            //--TRIMMABLE-BOUNDARY-START(55837458436)
            /*void */ Save$1(/*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837458436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Save(stream, 0/*SaveOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(55837458436)
            
            //--TRIMMABLE-BOUNDARY-START(51542491140)
            /*void */ Save(/*Stream*/ stream, /*SaveOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542491140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create(stream, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51542491140)
            
            //--TRIMMABLE-BOUNDARY-START(64427393028)
            /*void */ Save$3(/*TextWriter*/ textWriter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427393028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Save$2(textWriter, 0/*SaveOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(64427393028)
            
            //--TRIMMABLE-BOUNDARY-START(60132425732)
            /*void */ Save$2(/*TextWriter*/ textWriter, /*SaveOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132425732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$2(textWriter, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60132425732)
            
            //--TRIMMABLE-BOUNDARY-START(77312294916)
            /*void */ Save$6(/*XmlWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312294916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                writer.WriteStartDocument();
                this.WriteTo(writer);
                writer.WriteEndDocument();
            }
            //--TRIMMABLE-BOUNDARY-END(77312294916)
            
            //--TRIMMABLE-BOUNDARY-START(73017327620)
            /*void */ Save$5(/*string*/ fileName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017327620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Save$4(fileName, 0/*SaveOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(73017327620)
            
            //--TRIMMABLE-BOUNDARY-START(68722360324)
            /*void */ Save$4(/*string*/ fileName, /*SaveOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722360324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$4(fileName, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68722360324)
            
            //--TRIMMABLE-BOUNDARY-START(90197196804)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197196804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetXmlString(0/*SaveOptions.None*/);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XStreamingElement.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(90197196804)
            
            //--TRIMMABLE-BOUNDARY-START(94492164100)
            /*string */ ToString$1(/*SaveOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492164100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetXmlString(options);
            }
            //--TRIMMABLE-BOUNDARY-END(94492164100)
            
            //--TRIMMABLE-BOUNDARY-START(98787131396)
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787131396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                new $.$spxl.System.Xml.Linq.StreamingElementWriter().$ctor$3(writer).WriteStreamingElement(this);
            }
            //--TRIMMABLE-BOUNDARY-END(98787131396)
            
            //--TRIMMABLE-BOUNDARY-START(38657589252)
            /*string */ GetXmlString(/*SaveOptions*/ o)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657589252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let sw = null;
                try
                {
                    sw = new $.$$.System.IO.StringWriter().$ctor$5($.$$.System.Globalization.CultureInfo.InvariantCulture);
                    /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                    ws.OmitXmlDeclaration = true;
                    if ((o & 1/*SaveOptions.DisableFormatting*/) === 0)
                    {
                        ws.Indent = true;
                    }
                    if ((o & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0)
                    {
                        ws.NamespaceHandling |= 1/*NamespaceHandling.OmitDuplicates*/;
                    }
                    let w = null;
                    try
                    {
                        w = $.$spx.System.Xml.XmlWriter.Create$2(sw, ws);
                        this.WriteTo(w);
                    }
                    finally
                    {
                        w?.System$IDisposable$Dispose();
                    }
                    return $.$$.System.IO.StringWriter.ToString.call(sw);
                }
                finally
                {
                    sw?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38657589252)
            
            static $h = 2883588;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47247523844),
    {
      "p": 2097156,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362621956,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85902229508,
        "f": 83886081
      },
      "n": "Name",
      "d": 2883588,
      "h": 47247523844,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247523844)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182752772),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "Add",
      "d": 2883588,
      "h": 17182752772,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182752772),
//--TRIMMABLE-BOUNDARY-START(21477720068),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 2883588,
      "h": 21477720068,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477720068),
//--TRIMMABLE-BOUNDARY-START(55837458436),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        }
      ],
      "n": "Save",
      "o": "@$1",
      "d": 2883588,
      "h": 55837458436,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55837458436),
//--TRIMMABLE-BOUNDARY-START(51542491140),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "options",
          "p": 983044
        }
      ],
      "n": "Save",
      "d": 2883588,
      "h": 51542491140,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542491140),
//--TRIMMABLE-BOUNDARY-START(64427393028),
    {
      "r": 65537,
      "p": [
        {
          "n": "textWriter",
          "p": 95813633
        }
      ],
      "n": "Save",
      "o": "@$3",
      "d": 2883588,
      "h": 64427393028,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64427393028),
//--TRIMMABLE-BOUNDARY-START(60132425732),
    {
      "r": 65537,
      "p": [
        {
          "n": "textWriter",
          "p": 95813633
        },
        {
          "n": "options",
          "p": 983044
        }
      ],
      "n": "Save",
      "o": "@$2",
      "d": 2883588,
      "h": 60132425732,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60132425732),
//--TRIMMABLE-BOUNDARY-START(77312294916),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        }
      ],
      "n": "Save",
      "o": "@$6",
      "d": 2883588,
      "h": 77312294916,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77312294916),
//--TRIMMABLE-BOUNDARY-START(73017327620),
    {
      "r": 65537,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        }
      ],
      "n": "Save",
      "o": "@$5",
      "d": 2883588,
      "h": 73017327620,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73017327620),
//--TRIMMABLE-BOUNDARY-START(68722360324),
    {
      "r": 65537,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 983044
        }
      ],
      "n": "Save",
      "o": "@$4",
      "d": 2883588,
      "h": 68722360324,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68722360324),
//--TRIMMABLE-BOUNDARY-START(90197196804),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2883588,
      "h": 90197196804,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90197196804),
//--TRIMMABLE-BOUNDARY-START(94492164100),
    {
      "r": 1310721,
      "p": [
        {
          "n": "options",
          "p": 983044
        }
      ],
      "n": "ToString",
      "o": "@$1",
      "d": 2883588,
      "h": 94492164100,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94492164100),
//--TRIMMABLE-BOUNDARY-START(98787131396),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        }
      ],
      "n": "WriteTo",
      "d": 2883588,
      "h": 98787131396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98787131396),
//--TRIMMABLE-BOUNDARY-START(38657589252),
    {
      "r": 1310721,
      "p": [
        {
          "n": "o",
          "p": 983044
        }
      ],
      "n": "GetXmlString",
      "d": 2883588,
      "h": 38657589252,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38657589252)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42952556548),
    {
      "t": 2097156,
      "n": "name",
      "d": 2883588,
      "h": 42952556548,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(42952556548),
//--TRIMMABLE-BOUNDARY-START(25772687364),
    {
      "t": 131073,
      "n": "content",
      "d": 2883588,
      "h": 25772687364,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(25772687364)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887785476),
    {
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2883588,
      "h": 12887785476,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887785476),
//--TRIMMABLE-BOUNDARY-START(4297850884),
    {
      "p": [
        {
          "n": "name",
          "p": 2097156
        },
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2883588,
      "h": 4297850884,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297850884),
//--TRIMMABLE-BOUNDARY-START(8592818180),
    {
      "p": [
        {
          "n": "name",
          "p": 2097156
        },
        {
          "n": "content",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2883588,
      "h": 8592818180,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592818180)
  ],
  "h": 2883588
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XStreamingElement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2883588)
        
        
        //--TRIMMABLE-BOUNDARY-START(3342340)
        $asm.$cls("$spxl.System.Xml.XPath.XObjectExtensions", ($self) => class XObjectExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4298309636)
            static /*XContainer? */ GetParent(/*this XObject*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298309636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XContainer?*/ let ret = obj.Parent ?? obj.Document;
                if (ret === obj)
                {
                    return null;
                }
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(4298309636)
            
            static $h = 3342340;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298309636),
    {
      "r": 1310724,
      "p": [
        {
          "n": "obj",
          "p": 2555908
        }
      ],
      "n": "GetParent",
      "d": 3342340,
      "h": 4298309636,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298309636)
  ],
  "h": 3342340
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.XPath.XObjectExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3342340)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162692)
        $asm.$cls("$spxl.System.Xml.Linq.XNamespace", ($self) => class XNamespace extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(163210919940)
            /*string*/ static xmlPrefixNamespace = null;
            //--TRIMMABLE-BOUNDARY-END(163210919940)
            
            //--TRIMMABLE-BOUNDARY-START(158915952644)
            /*string*/ static xmlnsPrefixNamespace = null;
            //--TRIMMABLE-BOUNDARY-END(158915952644)
            
            //--TRIMMABLE-BOUNDARY-START(128851181572)
            /*XHashtable<WeakReference<XNamespace>>?*/ static s_namespaces = null;
            //--TRIMMABLE-BOUNDARY-END(128851181572)
            
            //--TRIMMABLE-BOUNDARY-START(133146148868)
            /*WeakReference<XNamespace>?*/ static s_refNone = null;
            //--TRIMMABLE-BOUNDARY-END(133146148868)
            
            //--TRIMMABLE-BOUNDARY-START(137441116164)
            /*WeakReference<XNamespace>?*/ static s_refXml = null;
            //--TRIMMABLE-BOUNDARY-END(137441116164)
            
            //--TRIMMABLE-BOUNDARY-START(141736083460)
            /*WeakReference<XNamespace>?*/ static s_refXmlns = null;
            //--TRIMMABLE-BOUNDARY-END(141736083460)
            
            //--TRIMMABLE-BOUNDARY-START(12887064580)
            /*string*/ _namespaceName = null;
            //--TRIMMABLE-BOUNDARY-END(12887064580)
            
            //--TRIMMABLE-BOUNDARY-START(4297129988)
            /*int*/ _hashCode = 0;
            //--TRIMMABLE-BOUNDARY-END(4297129988)
            
            //--TRIMMABLE-BOUNDARY-START(8592097284)
            /*XHashtable<XName>*/ _names = null;
            //--TRIMMABLE-BOUNDARY-END(8592097284)
            
            //--TRIMMABLE-BOUNDARY-START(98786410500)
            /*int*/ static NamesCapacity = 8;
            //--TRIMMABLE-BOUNDARY-END(98786410500)
            
            //--TRIMMABLE-BOUNDARY-START(107376345092)
            /*int*/ static NamespacesCapacity = 32;
            //--TRIMMABLE-BOUNDARY-END(107376345092)
            
            //--TRIMMABLE-BOUNDARY-START(21476999172)
            $ctor$1(/*string*/ namespaceName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476999172);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._namespaceName = namespaceName;
                    this._hashCode = $.$$.System.String.GetHashCode.call(namespaceName);
                    this._names = new ($.$spxl.System.Xml.Linq.XHashtable$$($.$spxl.System.Xml.Linq.XName))().$ctor$1(new $.$spxl.System.Xml.Linq.XHashtable$$($.$spxl.System.Xml.Linq.XName).ExtractKeyDelegate().$ctor($.$spxl.System.Xml.Linq.XNamespace, $.$spxl.System.Xml.Linq.XNamespace.ExtractLocalName), 8/*NamesCapacity*/);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476999172)
            
            //--TRIMMABLE-BOUNDARY-START(103081377796)
            /*string */ get NamespaceName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246802948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._namespaceName;
            }
            //--TRIMMABLE-BOUNDARY-END(103081377796)
            
            //--TRIMMABLE-BOUNDARY-START(94491443204)
            /*XName */ GetName$1(/*string*/ localName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491443204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(localName, "localName");
                return this.GetName(localName, 0, localName.length);
            }
            //--TRIMMABLE-BOUNDARY-END(94491443204)
            
            //--TRIMMABLE-BOUNDARY-START(146031050756)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031050756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._namespaceName;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XNamespace.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(146031050756)
            
            //--TRIMMABLE-BOUNDARY-START(111671312388)
            static /*XNamespace */ get None()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836737540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XNamespace.EnsureNamespace($.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_refNone, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_refNone = $v, $.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), $.$$.System.String.Empty);
            }
            //--TRIMMABLE-BOUNDARY-END(111671312388)
            
            //--TRIMMABLE-BOUNDARY-START(150326018052)
            static /*XNamespace */ get Xml()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426672132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XNamespace.EnsureNamespace($.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_refXml, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_refXml = $v, $.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), "http://www.w3.org/XML/1998/namespace"/*xmlPrefixNamespace*/);
            }
            //--TRIMMABLE-BOUNDARY-END(150326018052)
            
            //--TRIMMABLE-BOUNDARY-START(154620985348)
            static /*XNamespace */ get Xmlns()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016606724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XNamespace.EnsureNamespace($.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_refXmlns, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_refXmlns = $v, $.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), "http://www.w3.org/2000/xmlns/"/*xmlnsPrefixNamespace*/);
            }
            //--TRIMMABLE-BOUNDARY-END(154620985348)
            
            //--TRIMMABLE-BOUNDARY-START(81606541316)
            static /*XNamespace */ Get$1(/*string*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606541316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(namespaceName, "namespaceName");
                return $.$spxl.System.Xml.Linq.XNamespace.Get(namespaceName, 0, namespaceName.length);
            }
            //--TRIMMABLE-BOUNDARY-END(81606541316)
            
            //--TRIMMABLE-BOUNDARY-START(17182031876)
            static /*XNamespace? */ op_Implicit(/*string?*/ namespaceName)
            {
                return $.$$.System.String.op_Inequality(namespaceName, null) ? $.$spxl.System.Xml.Linq.XNamespace.Get$1(namespaceName) : null;
            }
            //--TRIMMABLE-BOUNDARY-END(17182031876)
            
            //--TRIMMABLE-BOUNDARY-START(115966279684)
            static /*XName */ op_Addition(/*XNamespace*/ ns, /*string*/ localName)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(ns, "ns");
                return ns.GetName$1(localName);
            }
            //--TRIMMABLE-BOUNDARY-END(115966279684)
            
            //--TRIMMABLE-BOUNDARY-START(30066933764)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066933764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this === obj;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$spxl.System.Xml.Linq.XNamespace.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(30066933764)
            
            //--TRIMMABLE-BOUNDARY-START(85901508612)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901508612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._hashCode;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$spxl.System.Xml.Linq.XNamespace.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(85901508612)
            
            //--TRIMMABLE-BOUNDARY-START(120261246980)
            static /*bool */ op_Equality(/*XNamespace?*/ left, /*XNamespace?*/ right)
            {
                return left === right;
            }
            //--TRIMMABLE-BOUNDARY-END(120261246980)
            
            //--TRIMMABLE-BOUNDARY-START(124556214276)
            static /*bool */ op_Inequality(/*XNamespace?*/ left, /*XNamespace?*/ right)
            {
                return left !== right;
            }
            //--TRIMMABLE-BOUNDARY-END(124556214276)
            
            //--TRIMMABLE-BOUNDARY-START(90196475908)
            /*XName */ GetName(/*string*/ localName, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196475908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(index >= 0 && index <= localName.length, "Caller should have checked that index was in bounds");
                $.$$.System.Diagnostics.Debug.Assert$2(count >= 0 && ((index + count) | 0) <= localName.length, "Caller should have checked that count was in bounds");
                /*XName?*/ let name;
                if (this._names.TryGetValue(localName, index, count, $.$ref(() => name, ($v) => name = $v, $.$spxl.System.Xml.Linq.XName)))
                {
                    return name;
                }
                return this._names.Add(new $.$spxl.System.Xml.Linq.XName().$ctor$1(this, $.$$.System.String.Substring.call(localName, index, count)));
            }
            //--TRIMMABLE-BOUNDARY-END(90196475908)
            
            //--TRIMMABLE-BOUNDARY-START(77311574020)
            static /*XNamespace */ Get(/*string*/ namespaceName, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311574020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(index >= 0 && index <= namespaceName.length, "Caller should have checked that index was in bounds");
                $.$$.System.Diagnostics.Debug.Assert$2(count >= 0 && ((index + count) | 0) <= namespaceName.length, "Caller should have checked that count was in bounds");
                if (count === 0)
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.None;
                }
                if ($.$spxl.System.Xml.Linq.XNamespace.s_namespaces === null)
                {
                    $.$$.System.Threading.Interlocked.CompareExchange$14($.$spxl.System.Xml.Linq.XHashtable$$($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), $.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_namespaces, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_namespaces = $v, $.$spxl.System.Xml.Linq.XHashtable$$($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))), new ($.$spxl.System.Xml.Linq.XHashtable$$($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)))().$ctor$1(new $.$spxl.System.Xml.Linq.XHashtable$$($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)).ExtractKeyDelegate().$ctor($.$spxl.System.Xml.Linq.XNamespace, $.$spxl.System.Xml.Linq.XNamespace.ExtractNamespace), 32/*NamespacesCapacity*/), null);
                }
                /*WeakReference<XNamespace>?*/ let refNamespace;
                /*XNamespace?*/ let ns;
                do
                {
                    if (!$.$spxl.System.Xml.Linq.XNamespace.s_namespaces.TryGetValue(namespaceName, index, count, $.$ref(() => refNamespace, ($v) => refNamespace = $v, $.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))))
                    {
                        if (count === "http://www.w3.org/XML/1998/namespace"/*xmlPrefixNamespace*/.length && $.$$.System.String.CompareOrdinal$1(namespaceName, index, "http://www.w3.org/XML/1998/namespace"/*xmlPrefixNamespace*/, 0, count) === 0)
                        {
                            return $.$spxl.System.Xml.Linq.XNamespace.Xml;
                        }
                        if (count === "http://www.w3.org/2000/xmlns/"/*xmlnsPrefixNamespace*/.length && $.$$.System.String.CompareOrdinal$1(namespaceName, index, "http://www.w3.org/2000/xmlns/"/*xmlnsPrefixNamespace*/, 0, count) === 0)
                        {
                            return $.$spxl.System.Xml.Linq.XNamespace.Xmlns;
                        }
                        refNamespace = $.$spxl.System.Xml.Linq.XNamespace.s_namespaces.Add(new ($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))().$ctor$3(new $.$spxl.System.Xml.Linq.XNamespace().$ctor$1($.$$.System.String.Substring.call(namespaceName, index, count))));
                    }
                    /*XNamespace?*/ let target;
                    ns = refNamespace !== null && refNamespace.TryGetTarget($.$ref(() => target, ($v) => target = $v, $.$spxl.System.Xml.Linq.XNamespace)) ? target : null;
                }
                while($.$spxl.System.Xml.Linq.XNamespace.op_Equality(ns, null));
                return ns;
            }
            //--TRIMMABLE-BOUNDARY-END(77311574020)
            
            //--TRIMMABLE-BOUNDARY-START(34361901060)
            static /*string */ ExtractLocalName(/*XName*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361901060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$spxl.System.Xml.Linq.XName.op_Inequality(n, null), "Null name should never exist here");
                return n.LocalName;
            }
            //--TRIMMABLE-BOUNDARY-END(34361901060)
            
            //--TRIMMABLE-BOUNDARY-START(38656868356)
            static /*string? */ ExtractNamespace(/*WeakReference<XNamespace>?*/ r)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656868356);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*XNamespace?*/ let target;
                    return !(r === null) && r.TryGetTarget($.$ref(() => target, ($v) => target = $v, $.$spxl.System.Xml.Linq.XNamespace)) ? target.NamespaceName : null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656868356)
            
            //--TRIMMABLE-BOUNDARY-START(25771966468)
            static /*XNamespace */ EnsureNamespace(/*ref WeakReference<XNamespace>?*/ refNmsp, /*string*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771966468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*WeakReference<XNamespace>?*/ let refOld;
                while(true)
                {
                    refOld = refNmsp.$v;
                    /*XNamespace?*/ let ns;
                    if (refOld !== null && refOld.TryGetTarget($.$ref(() => ns, ($v) => ns = $v, $.$spxl.System.Xml.Linq.XNamespace)))
                    {
                        return ns;
                    }
                    $.$$.System.Threading.Interlocked.CompareExchange$14($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace), refNmsp, new ($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))().$ctor$3(new $.$spxl.System.Xml.Linq.XNamespace().$ctor$1(namespaceName)), refOld);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771966468)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(163210919940)
                    this.xmlPrefixNamespace = "http://www.w3.org/XML/1998/namespace";
                    //--TRIMMABLE-BOUNDARY-END(163210919940)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158915952644)
                    this.xmlnsPrefixNamespace = "http://www.w3.org/2000/xmlns/";
                    //--TRIMMABLE-BOUNDARY-END(158915952644)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 2162692;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(103081377796),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246802948,
        "f": 50331649
      },
      "n": "NamespaceName",
      "d": 2162692,
      "h": 103081377796,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103081377796),
//--TRIMMABLE-BOUNDARY-START(111671312388),
    {
      "p": 2162692,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836737540,
        "f": 50331681
      },
      "n": "None",
      "d": 2162692,
      "h": 111671312388,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(111671312388),
//--TRIMMABLE-BOUNDARY-START(150326018052),
    {
      "p": 2162692,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426672132,
        "f": 50331681
      },
      "n": "Xml",
      "d": 2162692,
      "h": 150326018052,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(150326018052),
//--TRIMMABLE-BOUNDARY-START(154620985348),
    {
      "p": 2162692,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016606724,
        "f": 50331681
      },
      "n": "Xmlns",
      "d": 2162692,
      "h": 154620985348,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(154620985348)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(94491443204),
    {
      "r": 2097156,
      "p": [
        {
          "n": "localName",
          "p": 1310721
        }
      ],
      "n": "GetName",
      "o": "@$1",
      "d": 2162692,
      "h": 94491443204,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94491443204),
//--TRIMMABLE-BOUNDARY-START(146031050756),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2162692,
      "h": 146031050756,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146031050756),
//--TRIMMABLE-BOUNDARY-START(81606541316),
    {
      "r": 2162692,
      "p": [
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "Get",
      "o": "@$1",
      "d": 2162692,
      "h": 81606541316,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81606541316),
//--TRIMMABLE-BOUNDARY-START(30066933764),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2162692,
      "h": 30066933764,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066933764),
//--TRIMMABLE-BOUNDARY-START(85901508612),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2162692,
      "h": 85901508612,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901508612),
//--TRIMMABLE-BOUNDARY-START(90196475908),
    {
      "r": 2097156,
      "p": [
        {
          "n": "localName",
          "p": 1310721
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetName",
      "d": 2162692,
      "h": 90196475908,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(90196475908),
//--TRIMMABLE-BOUNDARY-START(77311574020),
    {
      "r": 2162692,
      "p": [
        {
          "n": "namespaceName",
          "p": 1310721
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Get",
      "d": 2162692,
      "h": 77311574020,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(77311574020),
//--TRIMMABLE-BOUNDARY-START(34361901060),
    {
      "r": 1310721,
      "p": [
        {
          "n": "n",
          "p": 2097156
        }
      ],
      "n": "ExtractLocalName",
      "d": 2162692,
      "h": 34361901060,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361901060),
//--TRIMMABLE-BOUNDARY-START(38656868356),
    {
      "r": 1310721,
      "p": [
        {
          "n": "r",
          "p": $.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h
        }
      ],
      "n": "ExtractNamespace",
      "d": 2162692,
      "h": 38656868356,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38656868356),
//--TRIMMABLE-BOUNDARY-START(25771966468),
    {
      "r": 2162692,
      "p": [
        {
          "n": "refNmsp",
          "p": $.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,
          "f": 4
        },
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "EnsureNamespace",
      "d": 2162692,
      "h": 25771966468,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25771966468)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(163210919940),
    {
      "t": 1310721,
      "n": "xmlPrefixNamespace",
      "d": 2162692,
      "h": 163210919940,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163210919940),
//--TRIMMABLE-BOUNDARY-START(158915952644),
    {
      "t": 1310721,
      "n": "xmlnsPrefixNamespace",
      "d": 2162692,
      "h": 158915952644,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158915952644),
//--TRIMMABLE-BOUNDARY-START(128851181572),
    {
      "t": $.$spxl.System.Xml.Linq.XHashtable$$($.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)).$h,
      "n": "s_namespaces",
      "d": 2162692,
      "h": 128851181572,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(128851181572),
//--TRIMMABLE-BOUNDARY-START(133146148868),
    {
      "t": $.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,
      "n": "s_refNone",
      "d": 2162692,
      "h": 133146148868,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(133146148868),
//--TRIMMABLE-BOUNDARY-START(137441116164),
    {
      "t": $.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,
      "n": "s_refXml",
      "d": 2162692,
      "h": 137441116164,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(137441116164),
//--TRIMMABLE-BOUNDARY-START(141736083460),
    {
      "t": $.$$.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,
      "n": "s_refXmlns",
      "d": 2162692,
      "h": 141736083460,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(141736083460),
//--TRIMMABLE-BOUNDARY-START(12887064580),
    {
      "t": 1310721,
      "n": "_namespaceName",
      "d": 2162692,
      "h": 12887064580,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887064580),
//--TRIMMABLE-BOUNDARY-START(4297129988),
    {
      "t": 655361,
      "n": "_hashCode",
      "d": 2162692,
      "h": 4297129988,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297129988),
//--TRIMMABLE-BOUNDARY-START(8592097284),
    {
      "t": $.$spxl.System.Xml.Linq.XHashtable$$($.$spxl.System.Xml.Linq.XName).$h,
      "n": "_names",
      "d": 2162692,
      "h": 8592097284,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592097284),
//--TRIMMABLE-BOUNDARY-START(98786410500),
    {
      "t": 655361,
      "n": "NamesCapacity",
      "d": 2162692,
      "h": 98786410500,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(98786410500),
//--TRIMMABLE-BOUNDARY-START(107376345092),
    {
      "t": 655361,
      "n": "NamespacesCapacity",
      "d": 2162692,
      "h": 107376345092,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(107376345092)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476999172),
    {
      "p": [
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162692,
      "h": 21476999172,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21476999172)
  ],
  "h": 2162692
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XNamespace`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162692)
        
        
        //--TRIMMABLE-BOUNDARY-START(393220)
        $asm.$cls("$spxl.System.Xml.Linq.Extensions", ($self) => class Extensions
        {
            //--TRIMMABLE-BOUNDARY-START(25770196996)
            static /*IEnumerable<XAttribute> */ Attributes$1(/*this IEnumerable<XElement?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770196996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetAttributes(source, null);
            }
            //--TRIMMABLE-BOUNDARY-END(25770196996)
            
            //--TRIMMABLE-BOUNDARY-START(21475229700)
            static /*IEnumerable<XAttribute> */ Attributes(/*this IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetAttributes(source, name) : $.$spxl.System.Xml.Linq.XAttribute.EmptySequence;
            }
            //--TRIMMABLE-BOUNDARY-END(21475229700)
            
            //--TRIMMABLE-BOUNDARY-START(8590327812)
            static /*IEnumerable<XElement> */ Ancestors$1(T, /*this IEnumerable<T?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetAncestors(T, source, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590327812)
            
            //--TRIMMABLE-BOUNDARY-START(4295360516)
            static /*IEnumerable<XElement> */ Ancestors(T, /*this IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetAncestors(T, source, name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360516)
            
            //--TRIMMABLE-BOUNDARY-START(17180262404)
            static /*IEnumerable<XElement> */ AncestorsAndSelf$1(/*this IEnumerable<XElement?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetAncestors($.$spxl.System.Xml.Linq.XElement, source, null, true);
            }
            //--TRIMMABLE-BOUNDARY-END(17180262404)
            
            //--TRIMMABLE-BOUNDARY-START(12885295108)
            static /*IEnumerable<XElement> */ AncestorsAndSelf(/*this IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetAncestors($.$spxl.System.Xml.Linq.XElement, source, name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            //--TRIMMABLE-BOUNDARY-END(12885295108)
            
            //--TRIMMABLE-BOUNDARY-START(94489673732)
            static /*IEnumerable<XNode> */ Nodes(T, /*this IEnumerable<T?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489673732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.NodesIterator(T, source);
            }
            //--TRIMMABLE-BOUNDARY-END(94489673732)
            
            //--TRIMMABLE-BOUNDARY-START(98784641028)
            static /*IEnumerable<XNode> */ NodesIterator(T, /*IEnumerable<T?>*/ source)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                /*XNode?*/ let n = root.LastNode;
                                if (n !== null)
                                {
                                    do
                                    {
                                        n = n.next;
                                        yield n;
                                    }
                                    while(n.parent === root && n !== root.content);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(98784641028)
            
            //--TRIMMABLE-BOUNDARY-START(30065164292)
            static /*IEnumerable<XNode> */ DescendantNodes(T, /*this IEnumerable<T?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendantNodes(T, source, false);
            }
            //--TRIMMABLE-BOUNDARY-END(30065164292)
            
            //--TRIMMABLE-BOUNDARY-START(42950066180)
            static /*IEnumerable<XElement> */ Descendants$1(T, /*this IEnumerable<T?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950066180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendants(T, source, null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(42950066180)
            
            //--TRIMMABLE-BOUNDARY-START(38655098884)
            static /*IEnumerable<XElement> */ Descendants(T, /*this IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655098884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetDescendants(T, source, name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            //--TRIMMABLE-BOUNDARY-END(38655098884)
            
            //--TRIMMABLE-BOUNDARY-START(34360131588)
            static /*IEnumerable<XNode> */ DescendantNodesAndSelf(/*this IEnumerable<XElement?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360131588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendantNodes($.$spxl.System.Xml.Linq.XElement, source, true);
            }
            //--TRIMMABLE-BOUNDARY-END(34360131588)
            
            //--TRIMMABLE-BOUNDARY-START(51540000772)
            static /*IEnumerable<XElement> */ DescendantsAndSelf$1(/*this IEnumerable<XElement?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540000772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendants($.$spxl.System.Xml.Linq.XElement, source, null, true);
            }
            //--TRIMMABLE-BOUNDARY-END(51540000772)
            
            //--TRIMMABLE-BOUNDARY-START(47245033476)
            static /*IEnumerable<XElement> */ DescendantsAndSelf(/*this IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245033476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetDescendants($.$spxl.System.Xml.Linq.XElement, source, name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            //--TRIMMABLE-BOUNDARY-END(47245033476)
            
            //--TRIMMABLE-BOUNDARY-START(64424902660)
            static /*IEnumerable<XElement> */ Elements$1(T, /*this IEnumerable<T?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424902660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetElements(T, source, null);
            }
            //--TRIMMABLE-BOUNDARY-END(64424902660)
            
            //--TRIMMABLE-BOUNDARY-START(60129935364)
            static /*IEnumerable<XElement> */ Elements(T, /*this IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129935364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetElements(T, source, name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            //--TRIMMABLE-BOUNDARY-END(60129935364)
            
            //--TRIMMABLE-BOUNDARY-START(90194706436)
            static /*IEnumerable<T> */ InDocumentOrder(T, /*this IEnumerable<T>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194706436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.DocumentOrderIterator(T, source);
            }
            //--TRIMMABLE-BOUNDARY-END(90194706436)
            
            //--TRIMMABLE-BOUNDARY-START(55834968068)
            static /*IEnumerable<T> */ DocumentOrderIterator(T, /*IEnumerable<T>*/ source)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*int*/ let count;
                    /*T[]*/ let items = $.$spxl.System.Collections.Generic.EnumerableHelpers.ToArray(T, source, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                    if (count > 0)
                    {
                        $.$$.System.Array.Sort$10($.$spxl.System.Xml.Linq.XNode, items, 0, count, $.$spxl.System.Xml.Linq.XNode.DocumentOrderComparer);
                        for(/*int*/ let i = 0; i !== count; ++i)
                        {
                            yield $.$$.System.Array.$ReadT1.call(items, i);
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(55834968068)
            
            //--TRIMMABLE-BOUNDARY-START(103079608324)
            static /*void */ Remove(/*this IEnumerable<XAttribute?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079608324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                /*int*/ let count;
                /*XAttribute?[]*/ let attributes = $.$spxl.System.Collections.Generic.EnumerableHelpers.ToArray($.$spxl.System.Xml.Linq.XAttribute, source, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                for(/*int*/ let i = 0; i < count; i++)
                {
                    $.$$.System.Array.$ReadT1.call(attributes, i)?.Remove();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079608324)
            
            //--TRIMMABLE-BOUNDARY-START(107374575620)
            static /*void */ Remove$1(T, /*this IEnumerable<T?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374575620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                /*int*/ let count;
                /*T?[]*/ let nodes = $.$spxl.System.Collections.Generic.EnumerableHelpers.ToArray(T, source, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                for(/*int*/ let i = 0; i < count; i++)
                {
                    $.$dsp($.$$.System.Array.$ReadT1.call(nodes, i), T, ($t) => $t.Remove,);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374575620)
            
            //--TRIMMABLE-BOUNDARY-START(73014837252)
            static /*IEnumerable<XAttribute> */ GetAttributes(/*IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var e = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (e !== null)
                            {
                                /*XAttribute?*/ let a = e.lastAttr;
                                if (a !== null)
                                {
                                    do
                                    {
                                        a = a.next;
                                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(a.name, name))
                                        {
                                            yield a;
                                        }
                                    }
                                    while(a.parent === e && a !== e.lastAttr);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(73014837252)
            
            //--TRIMMABLE-BOUNDARY-START(68719869956)
            static /*IEnumerable<XElement> */ GetAncestors(T, /*IEnumerable<T?>*/ source, /*XName?*/ name, /*bool*/ self)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (node !== null)
                            {
                                /*XElement?*/ let e = $.$as((self ? node : node.parent), $.$spxl.System.Xml.Linq.XElement);
                                while(e !== null)
                                {
                                    if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                                    {
                                        yield e;
                                    }
                                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(68719869956)
            
            //--TRIMMABLE-BOUNDARY-START(77309804548)
            static /*IEnumerable<XNode> */ GetDescendantNodes(T, /*IEnumerable<T?>*/ source, /*bool*/ self)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                if (self)
                                {
                                    yield root;
                                }
                                /*XNode?*/ let n = root;
                                while(true)
                                {
                                    /*XContainer?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XContainer);
                                    /*XNode?*/ let first;
                                    if (c !== null && (first = c.FirstNode) !== null)
                                    {
                                        n = first;
                                    }
                                    else 
                                    {
                                        while(n !== null && n !== root && n === n.parent.content)
                                        {
                                            n = n.parent;
                                        }
                                        if (n === null || n === root)
                                        {
                                            break;
                                        }
                                        n = n.next;
                                    }
                                    yield n;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(77309804548)
            
            //--TRIMMABLE-BOUNDARY-START(81604771844)
            static /*IEnumerable<XElement> */ GetDescendants(T, /*IEnumerable<T?>*/ source, /*XName?*/ name, /*bool*/ self)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                if (self)
                                {
                                    /*XElement*/ let e = $.$cast(root, $.$spxl.System.Xml.Linq.XElement);
                                    if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                                    {
                                        yield e;
                                    }
                                }
                                /*XNode?*/ let n = root;
                                /*XContainer?*/ let c = root;
                                while(true)
                                {
                                    if (c !== null && $.$is(c.content, $.$spxl.System.Xml.Linq.XNode))
                                    {
                                        n = ($.$cast(c.content, $.$spxl.System.Xml.Linq.XNode)).next;
                                    }
                                    else 
                                    {
                                        while(n !== null && n !== root && n === n.parent.content)
                                        {
                                            n = n.parent;
                                        }
                                        if (n === null || n === root)
                                        {
                                            break;
                                        }
                                        n = n.next;
                                    }
                                    /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                                    if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                                    {
                                        yield e;
                                    }
                                    c = e;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(81604771844)
            
            //--TRIMMABLE-BOUNDARY-START(85899739140)
            static /*IEnumerable<XElement> */ GetElements(T, /*IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                /*XNode?*/ let n = $.$as(root.content, $.$spxl.System.Xml.Linq.XNode);
                                if (n !== null)
                                {
                                    do
                                    {
                                        n = n.next;
                                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                                        if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                                        {
                                            yield e;
                                        }
                                    }
                                    while(n.parent === root && n !== root.content);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(85899739140)
            
            static $h = 393220;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770196996),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h
        }
      ],
      "n": "Attributes",
      "o": "@$1",
      "d": 393220,
      "h": 25770196996,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770196996),
//--TRIMMABLE-BOUNDARY-START(21475229700),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h
        },
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "Attributes",
      "d": 393220,
      "h": 21475229700,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475229700),
//--TRIMMABLE-BOUNDARY-START(8590327812),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Ancestors",
      "o": "@$1",
      "d": 393220,
      "h": 8590327812,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590327812),
//--TRIMMABLE-BOUNDARY-START(4295360516),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        },
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "g": [
        "T"
      ],
      "n": "Ancestors",
      "d": 393220,
      "h": 4295360516,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295360516),
//--TRIMMABLE-BOUNDARY-START(17180262404),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h
        }
      ],
      "n": "AncestorsAndSelf",
      "o": "@$1",
      "d": 393220,
      "h": 17180262404,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180262404),
//--TRIMMABLE-BOUNDARY-START(12885295108),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h
        },
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "AncestorsAndSelf",
      "d": 393220,
      "h": 12885295108,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885295108),
//--TRIMMABLE-BOUNDARY-START(94489673732),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Nodes",
      "d": 393220,
      "h": 94489673732,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(94489673732),
//--TRIMMABLE-BOUNDARY-START(98784641028),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "NodesIterator",
      "d": 393220,
      "h": 98784641028,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(98784641028),
//--TRIMMABLE-BOUNDARY-START(30065164292),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "DescendantNodes",
      "d": 393220,
      "h": 30065164292,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(30065164292),
//--TRIMMABLE-BOUNDARY-START(42950066180),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Descendants",
      "o": "@$1",
      "d": 393220,
      "h": 42950066180,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(42950066180),
//--TRIMMABLE-BOUNDARY-START(38655098884),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        },
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "g": [
        "T"
      ],
      "n": "Descendants",
      "d": 393220,
      "h": 38655098884,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(38655098884),
//--TRIMMABLE-BOUNDARY-START(34360131588),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h
        }
      ],
      "n": "DescendantNodesAndSelf",
      "d": 393220,
      "h": 34360131588,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360131588),
//--TRIMMABLE-BOUNDARY-START(51540000772),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h
        }
      ],
      "n": "DescendantsAndSelf",
      "o": "@$1",
      "d": 393220,
      "h": 51540000772,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540000772),
//--TRIMMABLE-BOUNDARY-START(47245033476),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h
        },
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "DescendantsAndSelf",
      "d": 393220,
      "h": 47245033476,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245033476),
//--TRIMMABLE-BOUNDARY-START(64424902660),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Elements",
      "o": "@$1",
      "d": 393220,
      "h": 64424902660,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(64424902660),
//--TRIMMABLE-BOUNDARY-START(60129935364),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        },
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "g": [
        "T"
      ],
      "n": "Elements",
      "d": 393220,
      "h": 60129935364,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(60129935364),
//--TRIMMABLE-BOUNDARY-START(90194706436),
    {
      "r": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "InDocumentOrder",
      "d": 393220,
      "h": 90194706436,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(90194706436),
//--TRIMMABLE-BOUNDARY-START(55834968068),
    {
      "r": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "DocumentOrderIterator",
      "d": 393220,
      "h": 55834968068,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(55834968068),
//--TRIMMABLE-BOUNDARY-START(103079608324),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h
        }
      ],
      "n": "Remove",
      "d": 393220,
      "h": 103079608324,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(103079608324),
//--TRIMMABLE-BOUNDARY-START(107374575620),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Remove",
      "o": "@$1",
      "d": 393220,
      "h": 107374575620,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(107374575620),
//--TRIMMABLE-BOUNDARY-START(73014837252),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h
        },
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "GetAttributes",
      "d": 393220,
      "h": 73014837252,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73014837252),
//--TRIMMABLE-BOUNDARY-START(68719869956),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        },
        {
          "n": "name",
          "p": 2097156
        },
        {
          "n": "self",
          "p": 262145
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetAncestors",
      "d": 393220,
      "h": 68719869956,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(68719869956),
//--TRIMMABLE-BOUNDARY-START(77309804548),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        },
        {
          "n": "self",
          "p": 262145
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetDescendantNodes",
      "d": 393220,
      "h": 77309804548,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(77309804548),
//--TRIMMABLE-BOUNDARY-START(81604771844),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        },
        {
          "n": "name",
          "p": 2097156
        },
        {
          "n": "self",
          "p": 262145
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetDescendants",
      "d": 393220,
      "h": 81604771844,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(81604771844),
//--TRIMMABLE-BOUNDARY-START(85899739140),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        },
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetElements",
      "d": 393220,
      "h": 85899739140,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(85899739140)
  ],
  "h": 393220
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Linq.Extensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393220)
        
        
        //--TRIMMABLE-BOUNDARY-START(3145732)
        $asm.$cls("$spxl.System.Xml.Schema.XNodeValidator", ($self) => class XNodeValidator extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(60132687876)
            /*XmlSchemaSet*/ schemas = null;
            //--TRIMMABLE-BOUNDARY-END(60132687876)
            
            //--TRIMMABLE-BOUNDARY-START(94492426244)
            /*ValidationEventHandler?*/ validationEventHandler = null;
            //--TRIMMABLE-BOUNDARY-END(94492426244)
            
            //--TRIMMABLE-BOUNDARY-START(64427655172)
            /*XObject?*/ source = null;
            //--TRIMMABLE-BOUNDARY-END(64427655172)
            
            //--TRIMMABLE-BOUNDARY-START(8593080324)
            /*bool*/ addSchemaInfo = false;
            //--TRIMMABLE-BOUNDARY-END(8593080324)
            
            //--TRIMMABLE-BOUNDARY-START(30067916804)
            /*XmlNamespaceManager?*/ namespaceManager = null;
            //--TRIMMABLE-BOUNDARY-END(30067916804)
            
            //--TRIMMABLE-BOUNDARY-START(98787393540)
            /*XmlSchemaValidator?*/ validator = null;
            //--TRIMMABLE-BOUNDARY-END(98787393540)
            
            //--TRIMMABLE-BOUNDARY-START(55837720580)
            /*HashSet<XmlSchemaInfo>?*/ schemaInfos = null;
            //--TRIMMABLE-BOUNDARY-END(55837720580)
            
            //--TRIMMABLE-BOUNDARY-START(12888047620)
            /*ArrayList?*/ defaultAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(12888047620)
            
            //--TRIMMABLE-BOUNDARY-START(107377328132)
            /*XName*/ xsiTypeName = null;
            //--TRIMMABLE-BOUNDARY-END(107377328132)
            
            //--TRIMMABLE-BOUNDARY-START(103082360836)
            /*XName*/ xsiNilName = null;
            //--TRIMMABLE-BOUNDARY-END(103082360836)
            
            //--TRIMMABLE-BOUNDARY-START(4298113028)
            $ctor$1(/*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298113028);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.schemas = schemas;
                    this.validationEventHandler = validationEventHandler;
                    /*XNamespace*/ let xsi = $.$spxl.System.Xml.Linq.XNamespace.Get$1("http://www.w3.org/2001/XMLSchema-instance");
                    this.xsiTypeName = xsi.GetName$1("type");
                    this.xsiNilName = xsi.GetName$1("nil");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298113028)
            
            //--TRIMMABLE-BOUNDARY-START(68722622468)
            /*void */ Validate(/*XObject*/ source, /*XmlSchemaObject?*/ partialValidationType, /*bool*/ addSchemaInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722622468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.source = source;
                this.addSchemaInfo = addSchemaInfo;
                /*XmlSchemaValidationFlags*/ let validationFlags = 16/*XmlSchemaValidationFlags.AllowXmlAttributes*/;
                /*XmlNodeType*/ let nt = source.NodeType;
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    switch($switchJumpState1 ?? nt)
                    {
                        case 9/*XmlNodeType.Document*/:
                        source = ($.$cast(source, $.$spxl.System.Xml.Linq.XDocument)).Root;
                        if (source === null)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingRoot);
                        }
                        validationFlags |= 8/*XmlSchemaValidationFlags.ProcessIdentityConstraints*/;
                        break;
                        case 1/*XmlNodeType.Element*/:
                        break;
                        case 2/*XmlNodeType.Attribute*/:
                        if (($.$cast(source, $.$spxl.System.Xml.Linq.XAttribute)).IsNamespaceDeclaration)
                        {
                            $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                            continue $switchJumpStart1;
                        }
                        if (source.Parent === null)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingParent);
                        }
                        break;
                        default:
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_BadNodeType, $.$box(nt, $.$spx.System.Xml.XmlNodeType)));
                    }
                    break;
                }
                this.namespaceManager = new $.$spx.System.Xml.XmlNamespaceManager().$ctor$2(this.schemas.NameTable);
                this.PushAncestorsAndSelf(source.Parent);
                this.validator = new $.$spx.System.Xml.Schema.XmlSchemaValidator().$ctor$1(this.schemas.NameTable, this.schemas, this.namespaceManager, validationFlags);
                this.validator.add_ValidationEventHandler(new $.$spx.System.Xml.Schema.ValidationEventHandler().$ctor(this, this.ValidationCallback));
                this.validator.XmlResolver = null;
                if (partialValidationType !== null)
                {
                    this.validator.Initialize$1(partialValidationType);
                }
                else 
                {
                    this.validator.Initialize();
                }
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(source);
                if (nt === 2/*XmlNodeType.Attribute*/)
                {
                    this.ValidateAttribute($.$cast(source, $.$spxl.System.Xml.Linq.XAttribute));
                }
                else 
                {
                    this.ValidateElement($.$cast(source, $.$spxl.System.Xml.Linq.XElement));
                }
                this.validator.EndValidation();
                this.RestoreLineInfo(original);
            }
            //--TRIMMABLE-BOUNDARY-END(68722622468)
            
            //--TRIMMABLE-BOUNDARY-START(17183014916)
            /*XmlSchemaInfo */ GetDefaultAttributeSchemaInfo(/*XmlSchemaAttribute*/ sa)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183014916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlSchemaInfo*/ let si = new $.$spx.System.Xml.Schema.XmlSchemaInfo().$ctor$1();
                si.IsDefault = true;
                si.IsNil = false;
                si.SchemaAttribute = sa;
                $.$$.System.Diagnostics.Debug.Assert$2(sa.AttributeSchemaType !== null, "sa.AttributeSchemaType != null");
                /*XmlSchemaSimpleType*/ let st = sa.AttributeSchemaType;
                si.SchemaType = st;
                $.$$.System.Diagnostics.Debug.Assert$2(st.Datatype !== null, "st.Datatype != null");
                if (st.Datatype.Variety === 2/*XmlSchemaDatatypeVariety.Union*/)
                {
                    /*string?*/ let value = this.GetDefaultValue(sa);
                    $.$$.System.Diagnostics.Debug.Assert$2(st.Content !== null, "st.Content != null");
                    let $i1 = 0;
                    let $arr1 = ($.$cast(st.Content, $.$spx.System.Xml.Schema.XmlSchemaSimpleTypeUnion)).BaseMemberTypes;
                    while ($i1 < $arr1.length)
                    {
                        let mt = $arr1[$i1++];
                        /*object?*/ let typedValue = null;
                        try
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(mt.Datatype !== null, "mt.Datatype != null");
                            $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Inequality(value, null), "value != null");
                            typedValue = mt.Datatype.ParseValue$1(value, this.schemas.NameTable, this.namespaceManager);
                        }
                        catch($e)
                        {
                        }
                        if (typedValue !== null)
                        {
                            si.MemberType = mt;
                            break;
                        }
                    }
                }
                si.Validity = 1/*XmlSchemaValidity.Valid*/;
                return si;
            }
            //--TRIMMABLE-BOUNDARY-END(17183014916)
            
            //--TRIMMABLE-BOUNDARY-START(21477982212)
            /*string? */ GetDefaultValue(/*XmlSchemaAttribute*/ sa)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477982212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlSchemaAttribute?*/ let saCopy = sa;
                /*XmlQualifiedName*/ let name = saCopy.RefName;
                if (!name.IsEmpty)
                {
                    saCopy = $.$as(this.schemas.GlobalAttributes.get_Item$1(name), $.$spx.System.Xml.Schema.XmlSchemaAttribute);
                    if (saCopy === null)
                    {
                        return null;
                    }
                }
                /*string?*/ let s = saCopy.FixedValue;
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    return s;
                }
                return saCopy.DefaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(21477982212)
            
            //--TRIMMABLE-BOUNDARY-START(25772949508)
            /*string? */ GetDefaultValue$1(/*XmlSchemaElement*/ se)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772949508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlSchemaElement?*/ let seCopy = se;
                /*XmlQualifiedName*/ let name = seCopy.RefName;
                if (!name.IsEmpty)
                {
                    seCopy = $.$as(this.schemas.GlobalElements.get_Item$1(name), $.$spx.System.Xml.Schema.XmlSchemaElement);
                    if (seCopy === null)
                    {
                        return null;
                    }
                }
                /*string?*/ let s = seCopy.FixedValue;
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    return s;
                }
                return seCopy.DefaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(25772949508)
            
            //--TRIMMABLE-BOUNDARY-START(42952818692)
            /*void */ ReplaceSchemaInfo(/*XObject*/ o, /*XmlSchemaInfo*/ schemaInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952818692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.schemaInfos ??= new ($.$$.System.Collections.Generic.HashSet$$($.$spx.System.Xml.Schema.XmlSchemaInfo))().$ctor$4(new $.$spxl.System.Xml.Schema.XmlSchemaInfoEqualityComparer().$ctor$1());
                /*XmlSchemaInfo?*/ let si = o.Annotation$1($.$spx.System.Xml.Schema.XmlSchemaInfo);
                if (si !== null)
                {
                    this.schemaInfos.Add(si);
                    o.RemoveAnnotations$1($.$spx.System.Xml.Schema.XmlSchemaInfo);
                }
                if (!this.schemaInfos.TryGetValue(schemaInfo, $.$ref(() => si, ($v) => si = $v, $.$spx.System.Xml.Schema.XmlSchemaInfo)))
                {
                    si = schemaInfo;
                    this.schemaInfos.Add(si);
                }
                o.AddAnnotation(si);
            }
            //--TRIMMABLE-BOUNDARY-END(42952818692)
            
            //--TRIMMABLE-BOUNDARY-START(34362884100)
            /*void */ PushAncestorsAndSelf(/*XElement?*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362884100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                while(e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration)
                            {
                                /*string*/ let localName = a.Name.LocalName;
                                if ($.$$.System.String.op_Equality(localName, "xmlns"))
                                {
                                    localName = $.$$.System.String.Empty;
                                }
                                if (!this.namespaceManager.HasNamespace(localName))
                                {
                                    this.namespaceManager.AddNamespace(localName, a.Value);
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34362884100)
            
            //--TRIMMABLE-BOUNDARY-START(38657851396)
            /*void */ PushElement(/*XElement*/ e, /*ref string?*/ xsiType, /*ref string?*/ xsiNil)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657851396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.namespaceManager.PushScope();
                /*XAttribute?*/ let a = e.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if (a.IsNamespaceDeclaration)
                        {
                            /*string*/ let localName = a.Name.LocalName;
                            if ($.$$.System.String.op_Equality(localName, "xmlns"))
                            {
                                localName = $.$$.System.String.Empty;
                            }
                            this.namespaceManager.AddNamespace(localName, a.Value);
                        }
                        else 
                        {
                            /*XName*/ let name = a.Name;
                            if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, this.xsiTypeName))
                            {
                                xsiType.$v = a.Value;
                            }
                            else if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, this.xsiNilName))
                            {
                                xsiNil.$v = a.Value;
                            }
                        }
                    }
                    while(a !== e.lastAttr);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38657851396)
            
            //--TRIMMABLE-BOUNDARY-START(51542753284)
            /*IXmlLineInfo */ SaveLineInfo(/*XObject?*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542753284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IXmlLineInfo*/ let previousLineInfo = this.validator.LineInfoProvider;
                this.validator.LineInfoProvider = $.$as(source, $.$spx.System.Xml.IXmlLineInfo);
                return previousLineInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(51542753284)
            
            //--TRIMMABLE-BOUNDARY-START(47247785988)
            /*void */ RestoreLineInfo(/*IXmlLineInfo*/ originalLineInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247785988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.validator.LineInfoProvider = originalLineInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(47247785988)
            
            //--TRIMMABLE-BOUNDARY-START(73017589764)
            /*void */ ValidateAttribute(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017589764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(a);
                /*XmlSchemaInfo?*/ let si = this.addSchemaInfo ? new $.$spx.System.Xml.Schema.XmlSchemaInfo().$ctor$1() : null;
                this.source = a;
                this.validator.ValidateAttribute(a.Name.LocalName, a.Name.NamespaceName, a.Value, si);
                if (this.addSchemaInfo)
                {
                    this.ReplaceSchemaInfo(a, si);
                }
                this.RestoreLineInfo(original);
            }
            //--TRIMMABLE-BOUNDARY-END(73017589764)
            
            //--TRIMMABLE-BOUNDARY-START(77312557060)
            /*void */ ValidateAttributes(/*XElement*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312557060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XAttribute?*/ let a = e.lastAttr;
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(a);
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if (!a.IsNamespaceDeclaration)
                        {
                            this.ValidateAttribute(a);
                        }
                    }
                    while(a !== e.lastAttr);
                    this.source = e;
                }
                if (this.addSchemaInfo)
                {
                    if (this.defaultAttributes === null)
                    {
                        this.defaultAttributes = new $.$$.System.Collections.ArrayList().$ctor$1();
                    }
                    else 
                    {
                        this.defaultAttributes.Clear();
                    }
                    this.validator.GetUnspecifiedDefaultAttributes$1(this.defaultAttributes);
                    var $en3 = this.defaultAttributes.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var sa = $en3.System$Collections$IEnumerator$Current;
                        {
                            a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3($.$spxl.System.Xml.Linq.XNamespace.Get$1(sa.QualifiedName.Namespace).GetName$1(sa.QualifiedName.Name), this.GetDefaultValue(sa));
                            this.ReplaceSchemaInfo(a, this.GetDefaultAttributeSchemaInfo(sa));
                            e.Add(a);
                        }
                    }
                }
                this.RestoreLineInfo(original);
            }
            //--TRIMMABLE-BOUNDARY-END(77312557060)
            
            //--TRIMMABLE-BOUNDARY-START(81607524356)
            /*void */ ValidateElement(/*XElement*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81607524356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlSchemaInfo?*/ let si = this.addSchemaInfo ? new $.$spx.System.Xml.Schema.XmlSchemaInfo().$ctor$1() : null;
                /*string?*/ let xsiType = null;
                /*string?*/ let xsiNil = null;
                this.PushElement(e, $.$ref(() => xsiType, ($v) => xsiType = $v, $.$$.System.String), $.$ref(() => xsiNil, ($v) => xsiNil = $v, $.$$.System.String));
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(e);
                this.source = e;
                this.validator.ValidateElement(e.Name.LocalName, e.Name.NamespaceName, si, xsiType, xsiNil, null, null);
                this.ValidateAttributes(e);
                this.validator.ValidateEndOfAttributes(si);
                this.ValidateNodes(e);
                this.validator.ValidateEndElement$1(si);
                if (this.addSchemaInfo)
                {
                    if (si.Validity === 1/*XmlSchemaValidity.Valid*/ && si.IsDefault)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(si.SchemaElement !== null, "si.SchemaElement != null");
                        e.Value = this.GetDefaultValue$1(si.SchemaElement);
                    }
                    this.ReplaceSchemaInfo(e, si);
                }
                this.RestoreLineInfo(original);
                this.namespaceManager.PopScope();
            }
            //--TRIMMABLE-BOUNDARY-END(81607524356)
            
            //--TRIMMABLE-BOUNDARY-START(85902491652)
            /*void */ ValidateNodes(/*XElement*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902491652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let n = $.$as(e.content, $.$spxl.System.Xml.Linq.XNode);
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(n);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*XElement?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (c !== null)
                        {
                            this.ValidateElement(c);
                        }
                        else 
                        {
                            /*XText?*/ let t = $.$as(n, $.$spxl.System.Xml.Linq.XText);
                            if (t !== null)
                            {
                                /*string*/ let s = t.Value;
                                if (s.length > 0)
                                {
                                    this.validator.LineInfoProvider = $.$as(t, $.$spx.System.Xml.IXmlLineInfo);
                                    this.validator.ValidateText$1(s);
                                }
                            }
                        }
                    }
                    while(n !== e.content);
                    this.source = e;
                }
                else 
                {
                    /*string?*/ let s = $.$as(e.content, $.$$.System.String);
                    if ($.$$.System.String.op_Inequality(s, null) && s.length > 0)
                    {
                        this.validator.ValidateText$1(s);
                    }
                }
                this.RestoreLineInfo(original);
            }
            //--TRIMMABLE-BOUNDARY-END(85902491652)
            
            //--TRIMMABLE-BOUNDARY-START(90197458948)
            /*void */ ValidationCallback(/*object?*/ sender, /*ValidationEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197458948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.validationEventHandler !== null)
                {
                    this.validationEventHandler.Invoke(this.source, e);
                }
                else if (e.Severity === 0/*XmlSeverityType.Error*/)
                {
                    throw e.Exception;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90197458948)
            
            static $h = 3145732;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(68722622468),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 2555908
        },
        {
          "n": "partialValidationType",
          "p": 30867459
        },
        {
          "n": "addSchemaInfo",
          "p": 262145
        }
      ],
      "n": "Validate",
      "d": 3145732,
      "h": 68722622468,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68722622468),
//--TRIMMABLE-BOUNDARY-START(17183014916),
    {
      "r": 30081027,
      "p": [
        {
          "n": "sa",
          "p": 27721731
        }
      ],
      "n": "GetDefaultAttributeSchemaInfo",
      "d": 3145732,
      "h": 17183014916,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17183014916),
//--TRIMMABLE-BOUNDARY-START(21477982212),
    {
      "r": 1310721,
      "p": [
        {
          "n": "sa",
          "p": 27721731
        }
      ],
      "n": "GetDefaultValue",
      "d": 3145732,
      "h": 21477982212,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21477982212),
//--TRIMMABLE-BOUNDARY-START(25772949508),
    {
      "r": 1310721,
      "p": [
        {
          "n": "se",
          "p": 29032451
        }
      ],
      "n": "GetDefaultValue",
      "o": "@$1",
      "d": 3145732,
      "h": 25772949508,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25772949508),
//--TRIMMABLE-BOUNDARY-START(42952818692),
    {
      "r": 65537,
      "p": [
        {
          "n": "o",
          "p": 2555908
        },
        {
          "n": "schemaInfo",
          "p": 30081027
        }
      ],
      "n": "ReplaceSchemaInfo",
      "d": 3145732,
      "h": 42952818692,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42952818692),
//--TRIMMABLE-BOUNDARY-START(34362884100),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 1638404
        }
      ],
      "n": "PushAncestorsAndSelf",
      "d": 3145732,
      "h": 34362884100,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34362884100),
//--TRIMMABLE-BOUNDARY-START(38657851396),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 1638404
        },
        {
          "n": "xsiType",
          "p": 1310721,
          "f": 4
        },
        {
          "n": "xsiNil",
          "p": 1310721,
          "f": 4
        }
      ],
      "n": "PushElement",
      "d": 3145732,
      "h": 38657851396,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38657851396),
//--TRIMMABLE-BOUNDARY-START(51542753284),
    {
      "r": 13893635,
      "p": [
        {
          "n": "source",
          "p": 2555908
        }
      ],
      "n": "SaveLineInfo",
      "d": 3145732,
      "h": 51542753284,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51542753284),
//--TRIMMABLE-BOUNDARY-START(47247785988),
    {
      "r": 65537,
      "p": [
        {
          "n": "originalLineInfo",
          "p": 13893635
        }
      ],
      "n": "RestoreLineInfo",
      "d": 3145732,
      "h": 47247785988,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47247785988),
//--TRIMMABLE-BOUNDARY-START(73017589764),
    {
      "r": 65537,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "ValidateAttribute",
      "d": 3145732,
      "h": 73017589764,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73017589764),
//--TRIMMABLE-BOUNDARY-START(77312557060),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 1638404
        }
      ],
      "n": "ValidateAttributes",
      "d": 3145732,
      "h": 77312557060,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77312557060),
//--TRIMMABLE-BOUNDARY-START(81607524356),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 1638404
        }
      ],
      "n": "ValidateElement",
      "d": 3145732,
      "h": 81607524356,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81607524356),
//--TRIMMABLE-BOUNDARY-START(85902491652),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 1638404
        }
      ],
      "n": "ValidateNodes",
      "d": 3145732,
      "h": 85902491652,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85902491652),
//--TRIMMABLE-BOUNDARY-START(90197458948),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 25427971
        }
      ],
      "n": "ValidationCallback",
      "d": 3145732,
      "h": 90197458948,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90197458948)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60132687876),
    {
      "t": 31916035,
      "n": "schemas",
      "d": 3145732,
      "h": 60132687876,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60132687876),
//--TRIMMABLE-BOUNDARY-START(94492426244),
    {
      "t": 25493507,
      "n": "validationEventHandler",
      "d": 3145732,
      "h": 94492426244,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(94492426244),
//--TRIMMABLE-BOUNDARY-START(64427655172),
    {
      "t": 2555908,
      "n": "source",
      "d": 3145732,
      "h": 64427655172,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64427655172),
//--TRIMMABLE-BOUNDARY-START(8593080324),
    {
      "t": 262145,
      "n": "addSchemaInfo",
      "d": 3145732,
      "h": 8593080324,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593080324),
//--TRIMMABLE-BOUNDARY-START(30067916804),
    {
      "t": 51838979,
      "n": "namespaceManager",
      "d": 3145732,
      "h": 30067916804,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30067916804),
//--TRIMMABLE-BOUNDARY-START(98787393540),
    {
      "t": 33030147,
      "n": "validator",
      "d": 3145732,
      "h": 98787393540,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98787393540),
//--TRIMMABLE-BOUNDARY-START(55837720580),
    {
      "t": $.$$.System.Collections.Generic.HashSet$$($.$spx.System.Xml.Schema.XmlSchemaInfo).$h,
      "n": "schemaInfos",
      "d": 3145732,
      "h": 55837720580,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55837720580),
//--TRIMMABLE-BOUNDARY-START(12888047620),
    {
      "t": 54460417,
      "n": "defaultAttributes",
      "d": 3145732,
      "h": 12888047620,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12888047620),
//--TRIMMABLE-BOUNDARY-START(107377328132),
    {
      "t": 2097156,
      "n": "xsiTypeName",
      "d": 3145732,
      "h": 107377328132,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(107377328132),
//--TRIMMABLE-BOUNDARY-START(103082360836),
    {
      "t": 2097156,
      "n": "xsiNilName",
      "d": 3145732,
      "h": 103082360836,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(103082360836)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298113028),
    {
      "p": [
        {
          "n": "schemas",
          "p": 31916035
        },
        {
          "n": "validationEventHandler",
          "p": 25493507
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3145732,
      "h": 4298113028,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298113028)
  ],
  "h": 3145732
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Schema.XNodeValidator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3145732)
        
        
        //--TRIMMABLE-BOUNDARY-START(3014660)
        $asm.$cls("$spxl.System.Xml.Schema.Extensions", ($self) => class Extensions
        {
            //--TRIMMABLE-BOUNDARY-START(8592949252)
            static /*IXmlSchemaInfo? */ GetSchemaInfo$1(/*this XElement*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592949252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.Annotation$1($.$spx.System.Xml.Schema.IXmlSchemaInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(8592949252)
            
            //--TRIMMABLE-BOUNDARY-START(4297981956)
            static /*IXmlSchemaInfo? */ GetSchemaInfo(/*this XAttribute*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297981956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.Annotation$1($.$spx.System.Xml.Schema.IXmlSchemaInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(4297981956)
            
            //--TRIMMABLE-BOUNDARY-START(25772818436)
            static /*void */ Validate$3(/*this XDocument*/ source, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772818436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$spxl.System.Xml.Schema.Extensions.Validate$2(source, schemas, validationEventHandler, false);
            }
            //--TRIMMABLE-BOUNDARY-END(25772818436)
            
            //--TRIMMABLE-BOUNDARY-START(21477851140)
            static /*void */ Validate$2(/*this XDocument*/ source, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler, /*bool*/ addSchemaInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477851140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(schemas, "schemas");
                new $.$spxl.System.Xml.Schema.XNodeValidator().$ctor$1(schemas, validationEventHandler).Validate(source, null, addSchemaInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(21477851140)
            
            //--TRIMMABLE-BOUNDARY-START(34362753028)
            static /*void */ Validate$5(/*this XElement*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362753028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$spxl.System.Xml.Schema.Extensions.Validate$4(source, partialValidationType, schemas, validationEventHandler, false);
            }
            //--TRIMMABLE-BOUNDARY-END(34362753028)
            
            //--TRIMMABLE-BOUNDARY-START(30067785732)
            static /*void */ Validate$4(/*this XElement*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler, /*bool*/ addSchemaInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067785732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(partialValidationType, "partialValidationType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(schemas, "schemas");
                new $.$spxl.System.Xml.Schema.XNodeValidator().$ctor$1(schemas, validationEventHandler).Validate(source, partialValidationType, addSchemaInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(30067785732)
            
            //--TRIMMABLE-BOUNDARY-START(17182883844)
            static /*void */ Validate$1(/*this XAttribute*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182883844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$spxl.System.Xml.Schema.Extensions.Validate(source, partialValidationType, schemas, validationEventHandler, false);
            }
            //--TRIMMABLE-BOUNDARY-END(17182883844)
            
            //--TRIMMABLE-BOUNDARY-START(12887916548)
            static /*void */ Validate(/*this XAttribute*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler, /*bool*/ addSchemaInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887916548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(partialValidationType, "partialValidationType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(schemas, "schemas");
                new $.$spxl.System.Xml.Schema.XNodeValidator().$ctor$1(schemas, validationEventHandler).Validate(source, partialValidationType, addSchemaInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(12887916548)
            
            static $h = 3014660;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592949252),
    {
      "r": 21757955,
      "p": [
        {
          "n": "source",
          "p": 1638404
        }
      ],
      "n": "GetSchemaInfo",
      "o": "@$1",
      "d": 3014660,
      "h": 8592949252,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592949252),
//--TRIMMABLE-BOUNDARY-START(4297981956),
    {
      "r": 21757955,
      "p": [
        {
          "n": "source",
          "p": 1114116
        }
      ],
      "n": "GetSchemaInfo",
      "d": 3014660,
      "h": 4297981956,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297981956),
//--TRIMMABLE-BOUNDARY-START(25772818436),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 1507332
        },
        {
          "n": "schemas",
          "p": 31916035
        },
        {
          "n": "validationEventHandler",
          "p": 25493507
        }
      ],
      "n": "Validate",
      "o": "@$3",
      "d": 3014660,
      "h": 25772818436,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772818436),
//--TRIMMABLE-BOUNDARY-START(21477851140),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 1507332
        },
        {
          "n": "schemas",
          "p": 31916035
        },
        {
          "n": "validationEventHandler",
          "p": 25493507
        },
        {
          "n": "addSchemaInfo",
          "p": 262145
        }
      ],
      "n": "Validate",
      "o": "@$2",
      "d": 3014660,
      "h": 21477851140,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477851140),
//--TRIMMABLE-BOUNDARY-START(34362753028),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 1638404
        },
        {
          "n": "partialValidationType",
          "p": 30867459
        },
        {
          "n": "schemas",
          "p": 31916035
        },
        {
          "n": "validationEventHandler",
          "p": 25493507
        }
      ],
      "n": "Validate",
      "o": "@$5",
      "d": 3014660,
      "h": 34362753028,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34362753028),
//--TRIMMABLE-BOUNDARY-START(30067785732),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 1638404
        },
        {
          "n": "partialValidationType",
          "p": 30867459
        },
        {
          "n": "schemas",
          "p": 31916035
        },
        {
          "n": "validationEventHandler",
          "p": 25493507
        },
        {
          "n": "addSchemaInfo",
          "p": 262145
        }
      ],
      "n": "Validate",
      "o": "@$4",
      "d": 3014660,
      "h": 30067785732,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067785732),
//--TRIMMABLE-BOUNDARY-START(17182883844),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 1114116
        },
        {
          "n": "partialValidationType",
          "p": 30867459
        },
        {
          "n": "schemas",
          "p": 31916035
        },
        {
          "n": "validationEventHandler",
          "p": 25493507
        }
      ],
      "n": "Validate",
      "o": "@$1",
      "d": 3014660,
      "h": 17182883844,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182883844),
//--TRIMMABLE-BOUNDARY-START(12887916548),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 1114116
        },
        {
          "n": "partialValidationType",
          "p": 30867459
        },
        {
          "n": "schemas",
          "p": 31916035
        },
        {
          "n": "validationEventHandler",
          "p": 25493507
        },
        {
          "n": "addSchemaInfo",
          "p": 262145
        }
      ],
      "n": "Validate",
      "d": 3014660,
      "h": 12887916548,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887916548)
  ],
  "h": 3014660
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.Schema.Extensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3014660)
        
        
        //--TRIMMABLE-BOUNDARY-START(3407876)
        $asm.$cls("$spxl.System.Xml.XPath.XPathEvaluator", ($self) => class XPathEvaluator
        {
            //--TRIMMABLE-BOUNDARY-START(4298375172)
            static /*object */ Evaluate(T, /*XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298375172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XPathNavigator*/ let navigator = $.$spxl.System.Xml.XPath.Extensions.CreateNavigator$1(node);
                /*object*/ let result = navigator.Evaluate(expression, resolver);
                /*XPathNodeIterator?*/ let iterator = $.$as(result, $.$spx.System.Xml.XPath.XPathNodeIterator);
                if (iterator !== null)
                {
                    return $.$spxl.System.Xml.XPath.XPathEvaluator.EvaluateIterator(T, iterator);
                }
                if (!($.$is(result, T)))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedEvaluation, $.$$.System.Object.GetType.call(result)));
                }
                return $.$box($.$cast(result, T), T);
            }
            //--TRIMMABLE-BOUNDARY-END(4298375172)
            
            //--TRIMMABLE-BOUNDARY-START(8593342468)
            static /*IEnumerable<T> */ EvaluateIterator(T, /*XPathNodeIterator*/ result)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = result.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var navigator = $en3.System$Collections$IEnumerator$Current;
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(navigator.UnderlyingObject !== null, "navigator.UnderlyingObject != null");
                            /*object*/ let r = navigator.UnderlyingObject;
                            if (!($.$is(r, T)))
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_UnexpectedEvaluation, $.$$.System.Object.GetType.call(r)));
                            }
                            yield $.$cast(r, T);
                            /*XText?*/ let t = $.$as(r, $.$spxl.System.Xml.Linq.XText);
                            if (t !== null && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(t) !== null)
                            {
                                do
                                {
                                    t = $.$as(t.NextNode, $.$spxl.System.Xml.Linq.XText);
                                    if (t === null)
                                    {
                                        break;
                                    }
                                    yield $.$cast($.$cast(t, $.$$.System.Object), T);
                                }
                                while(t !== $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(t).LastNode);
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(8593342468)
            
            static $h = 3407876;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298375172),
    {
      "r": 131073,
      "p": [
        {
          "n": "node",
          "p": 2228228
        },
        {
          "n": "expression",
          "p": 1310721
        },
        {
          "n": "resolver",
          "p": 13959171
        }
      ],
      "g": [
        "T"
      ],
      "n": "Evaluate",
      "d": 3407876,
      "h": 4298375172,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4298375172),
//--TRIMMABLE-BOUNDARY-START(8593342468),
    {
      "r": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h,
      "p": [
        {
          "n": "result",
          "p": 59703299
        }
      ],
      "g": [
        "T"
      ],
      "n": "EvaluateIterator",
      "d": 3407876,
      "h": 8593342468,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(8593342468)
  ],
  "h": 3407876
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.XPath.XPathEvaluator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3407876)
        
        
        //--TRIMMABLE-BOUNDARY-START(3211268)
        $asm.$cls("$spxl.System.Xml.XPath.Extensions", ($self) => class Extensions
        {
            //--TRIMMABLE-BOUNDARY-START(12888113156)
            static /*XPathNavigator */ CreateNavigator$1(/*this XNode*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888113156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.XPath.Extensions.CreateNavigator(node, null);
            }
            //--TRIMMABLE-BOUNDARY-END(12888113156)
            
            //--TRIMMABLE-BOUNDARY-START(8593145860)
            static /*XPathNavigator */ CreateNavigator(/*this XNode*/ node, /*XmlNameTable?*/ nameTable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593145860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(node, "node");
                if ($.$is(node, $.$spxl.System.Xml.Linq.XDocumentType))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_CreateNavigator, $.$box(10/*XmlNodeType.DocumentType*/, $.$spx.System.Xml.XmlNodeType)));
                }
                /*XText?*/ let text = $.$as(node, $.$spxl.System.Xml.Linq.XText);
                if (text !== null)
                {
                    if ($.$is($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(text), $.$spxl.System.Xml.Linq.XDocument))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_CreateNavigator, $.$box(13/*XmlNodeType.Whitespace*/, $.$spx.System.Xml.XmlNodeType)));
                    }
                    node = $.$spxl.System.Xml.XPath.Extensions.CalibrateText(text);
                }
                return new $.$spxl.System.Xml.XPath.XNodeNavigator().$ctor$3(node, nameTable);
            }
            //--TRIMMABLE-BOUNDARY-END(8593145860)
            
            //--TRIMMABLE-BOUNDARY-START(21478047748)
            static /*object */ XPathEvaluate$1(/*this XNode*/ node, /*string*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478047748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.XPath.Extensions.XPathEvaluate(node, expression, null);
            }
            //--TRIMMABLE-BOUNDARY-END(21478047748)
            
            //--TRIMMABLE-BOUNDARY-START(17183080452)
            static /*object */ XPathEvaluate(/*this XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183080452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(node, "node");
                return $.$spxl.System.Xml.XPath.XPathEvaluator.Evaluate($.$$.System.Object, node, expression, resolver);
            }
            //--TRIMMABLE-BOUNDARY-END(17183080452)
            
            //--TRIMMABLE-BOUNDARY-START(30067982340)
            static /*XElement? */ XPathSelectElement$1(/*this XNode*/ node, /*string*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067982340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.XPath.Extensions.XPathSelectElement(node, expression, null);
            }
            //--TRIMMABLE-BOUNDARY-END(30067982340)
            
            //--TRIMMABLE-BOUNDARY-START(25773015044)
            static /*XElement? */ XPathSelectElement(/*this XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773015044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.System.Linq.Enumerable.FirstOrDefault$3($.$spxl.System.Xml.Linq.XElement, $.$spxl.System.Xml.XPath.Extensions.XPathSelectElements(node, expression, resolver));
            }
            //--TRIMMABLE-BOUNDARY-END(25773015044)
            
            //--TRIMMABLE-BOUNDARY-START(38657916932)
            static /*IEnumerable<XElement> */ XPathSelectElements$1(/*this XNode*/ node, /*string*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657916932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.XPath.Extensions.XPathSelectElements(node, expression, null);
            }
            //--TRIMMABLE-BOUNDARY-END(38657916932)
            
            //--TRIMMABLE-BOUNDARY-START(34362949636)
            static /*IEnumerable<XElement> */ XPathSelectElements(/*this XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362949636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(node, "node");
                return $.$cast($.$spxl.System.Xml.XPath.XPathEvaluator.Evaluate($.$spxl.System.Xml.Linq.XElement, node, expression, resolver), $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement));
            }
            //--TRIMMABLE-BOUNDARY-END(34362949636)
            
            //--TRIMMABLE-BOUNDARY-START(4298178564)
            static /*XText */ CalibrateText(/*XText*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298178564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XContainer?*/ let parentNode = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n);
                if (parentNode === null)
                {
                    return n;
                }
                var $en2 = parentNode.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var node = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*XText?*/ let t = $.$as(node, $.$spxl.System.Xml.Linq.XText);
                        /*bool*/ let isTextNode = t !== null;
                        if (isTextNode && node === n)
                        {
                            return t;
                        }
                    }
                }
                $.$$.System.Diagnostics.Debug.Fail$1("Parent node doesn't contain itself.");
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(4298178564)
            
            static $h = 3211268;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888113156),
    {
      "r": 59244547,
      "p": [
        {
          "n": "node",
          "p": 2228228
        }
      ],
      "n": "CreateNavigator",
      "o": "@$1",
      "d": 3211268,
      "h": 12888113156,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12888113156),
//--TRIMMABLE-BOUNDARY-START(8593145860),
    {
      "r": 59244547,
      "p": [
        {
          "n": "node",
          "p": 2228228
        },
        {
          "n": "nameTable",
          "p": 52035587
        }
      ],
      "n": "CreateNavigator",
      "d": 3211268,
      "h": 8593145860,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593145860),
//--TRIMMABLE-BOUNDARY-START(21478047748),
    {
      "r": 131073,
      "p": [
        {
          "n": "node",
          "p": 2228228
        },
        {
          "n": "expression",
          "p": 1310721
        }
      ],
      "n": "XPathEvaluate",
      "o": "@$1",
      "d": 3211268,
      "h": 21478047748,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21478047748),
//--TRIMMABLE-BOUNDARY-START(17183080452),
    {
      "r": 131073,
      "p": [
        {
          "n": "node",
          "p": 2228228
        },
        {
          "n": "expression",
          "p": 1310721
        },
        {
          "n": "resolver",
          "p": 13959171
        }
      ],
      "n": "XPathEvaluate",
      "d": 3211268,
      "h": 17183080452,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17183080452),
//--TRIMMABLE-BOUNDARY-START(30067982340),
    {
      "r": 1638404,
      "p": [
        {
          "n": "node",
          "p": 2228228
        },
        {
          "n": "expression",
          "p": 1310721
        }
      ],
      "n": "XPathSelectElement",
      "o": "@$1",
      "d": 3211268,
      "h": 30067982340,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067982340),
//--TRIMMABLE-BOUNDARY-START(25773015044),
    {
      "r": 1638404,
      "p": [
        {
          "n": "node",
          "p": 2228228
        },
        {
          "n": "expression",
          "p": 1310721
        },
        {
          "n": "resolver",
          "p": 13959171
        }
      ],
      "n": "XPathSelectElement",
      "d": 3211268,
      "h": 25773015044,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25773015044),
//--TRIMMABLE-BOUNDARY-START(38657916932),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "node",
          "p": 2228228
        },
        {
          "n": "expression",
          "p": 1310721
        }
      ],
      "n": "XPathSelectElements",
      "o": "@$1",
      "d": 3211268,
      "h": 38657916932,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38657916932),
//--TRIMMABLE-BOUNDARY-START(34362949636),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "node",
          "p": 2228228
        },
        {
          "n": "expression",
          "p": 1310721
        },
        {
          "n": "resolver",
          "p": 13959171
        }
      ],
      "n": "XPathSelectElements",
      "d": 3211268,
      "h": 34362949636,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34362949636),
//--TRIMMABLE-BOUNDARY-START(4298178564),
    {
      "r": 2949124,
      "p": [
        {
          "n": "n",
          "p": 2949124
        }
      ],
      "n": "CalibrateText",
      "d": 3211268,
      "h": 4298178564,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4298178564)
  ],
  "h": 3211268
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Xml.XPath.Extensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3211268)
        
        
        //--TRIMMABLE-BOUNDARY-START(2097156)
        $asm.$cls("$spxl.System.Xml.Linq.XName", ($self) => class XName extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886999044)
            /*XNamespace*/ _ns = null;
            //--TRIMMABLE-BOUNDARY-END(12886999044)
            
            //--TRIMMABLE-BOUNDARY-START(8592031748)
            /*string*/ _localName = null;
            //--TRIMMABLE-BOUNDARY-END(8592031748)
            
            //--TRIMMABLE-BOUNDARY-START(4297064452)
            /*int*/ _hashCode = 0;
            //--TRIMMABLE-BOUNDARY-END(4297064452)
            
            //--TRIMMABLE-BOUNDARY-START(21476933636)
            $ctor$1(/*XNamespace*/ ns, /*string*/ localName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476933636);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._ns = ns;
                    this._localName = $.$spx.System.Xml.XmlConvert.VerifyNCName$1(localName);
                    this._hashCode = $.$spxl.System.Xml.Linq.XNamespace.GetHashCode.call(ns) ^ $.$$.System.String.GetHashCode.call(localName);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476933636)
            
            //--TRIMMABLE-BOUNDARY-START(68721573892)
            /*string */ get LocalName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361835524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._localName;
            }
            //--TRIMMABLE-BOUNDARY-END(68721573892)
            
            //--TRIMMABLE-BOUNDARY-START(73016541188)
            /*XNamespace */ get Namespace()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951770116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ns;
            }
            //--TRIMMABLE-BOUNDARY-END(73016541188)
            
            //--TRIMMABLE-BOUNDARY-START(77311508484)
            /*string */ get NamespaceName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541704708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ns.NamespaceName;
            }
            //--TRIMMABLE-BOUNDARY-END(77311508484)
            
            //--TRIMMABLE-BOUNDARY-START(98786344964)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786344964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._ns.NamespaceName.length === 0)
                {
                    return this._localName;
                }
                return "{" + this._ns.NamespaceName + "}" + this._localName;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XName.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(98786344964)
            
            //--TRIMMABLE-BOUNDARY-START(60131639300)
            static /*XName */ Get$1(/*string*/ expandedName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131639300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(expandedName, "expandedName");
                if ($.$$.System.String.get_Chars.call(expandedName, 0) === /*{*/ 123)
                {
                    /*int*/ let i = $.$$.System.String.LastIndexOf$2.call(expandedName, /*}*/ 125);
                    if (i <= 1 || i === ((expandedName.length - 1) | 0))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_InvalidExpandedName, expandedName));
                    }
                    return $.$spxl.System.Xml.Linq.XNamespace.Get(expandedName, 1, ((i - 1) | 0)).GetName(expandedName, ((i + 1) | 0), ((((expandedName.length - i) | 0) - 1) | 0));
                }
                else 
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.None.GetName$1(expandedName);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131639300)
            
            //--TRIMMABLE-BOUNDARY-START(55836672004)
            static /*XName */ Get(/*string*/ localName, /*string*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836672004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XNamespace.Get$1(namespaceName).GetName$1(localName);
            }
            //--TRIMMABLE-BOUNDARY-END(55836672004)
            
            //--TRIMMABLE-BOUNDARY-START(17181966340)
            static /*XName? */ op_Implicit(/*string?*/ expandedName)
            {
                return $.$$.System.String.op_Inequality(expandedName, null) ? $.$spxl.System.Xml.Linq.XName.Get$1(expandedName) : null;
            }
            //--TRIMMABLE-BOUNDARY-END(17181966340)
            
            //--TRIMMABLE-BOUNDARY-START(25771900932)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771900932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this === obj;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$spxl.System.Xml.Linq.XName.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25771900932)
            
            //--TRIMMABLE-BOUNDARY-START(64426606596)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426606596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._hashCode;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$spxl.System.Xml.Linq.XName.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(64426606596)
            
            //--TRIMMABLE-BOUNDARY-START(81606475780)
            static /*bool */ op_Equality(/*XName?*/ left, /*XName?*/ right)
            {
                return left === right;
            }
            //--TRIMMABLE-BOUNDARY-END(81606475780)
            
            //--TRIMMABLE-BOUNDARY-START(85901443076)
            static /*bool */ op_Inequality(/*XName?*/ left, /*XName?*/ right)
            {
                return left !== right;
            }
            //--TRIMMABLE-BOUNDARY-END(85901443076)
            
            //--TRIMMABLE-BOUNDARY-START(90196410372)
            /*bool */ System$IEquatable$$$Equals(/*XName?*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196410372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this === other;
            }
            //--TRIMMABLE-BOUNDARY-END(90196410372)
            
            //--TRIMMABLE-BOUNDARY-START(94491377668)
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491377668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(94491377668)
            
            static $h = 2097156;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68721573892),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361835524,
        "f": 50331649
      },
      "n": "LocalName",
      "d": 2097156,
      "h": 68721573892,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721573892),
//--TRIMMABLE-BOUNDARY-START(73016541188),
    {
      "p": 2162692,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951770116,
        "f": 50331649
      },
      "n": "Namespace",
      "d": 2097156,
      "h": 73016541188,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016541188),
//--TRIMMABLE-BOUNDARY-START(77311508484),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541704708,
        "f": 50331649
      },
      "n": "NamespaceName",
      "d": 2097156,
      "h": 77311508484,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311508484)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98786344964),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2097156,
      "h": 98786344964,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98786344964),
//--TRIMMABLE-BOUNDARY-START(60131639300),
    {
      "r": 2097156,
      "p": [
        {
          "n": "expandedName",
          "p": 1310721
        }
      ],
      "n": "Get",
      "o": "@$1",
      "d": 2097156,
      "h": 60131639300,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60131639300),
//--TRIMMABLE-BOUNDARY-START(55836672004),
    {
      "r": 2097156,
      "p": [
        {
          "n": "localName",
          "p": 1310721
        },
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "Get",
      "d": 2097156,
      "h": 55836672004,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55836672004),
//--TRIMMABLE-BOUNDARY-START(25771900932),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2097156,
      "h": 25771900932,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771900932),
//--TRIMMABLE-BOUNDARY-START(64426606596),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2097156,
      "h": 64426606596,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64426606596)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886999044),
    {
      "t": 2162692,
      "n": "_ns",
      "d": 2097156,
      "h": 12886999044,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886999044),
//--TRIMMABLE-BOUNDARY-START(8592031748),
    {
      "t": 1310721,
      "n": "_localName",
      "d": 2097156,
      "h": 8592031748,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592031748),
//--TRIMMABLE-BOUNDARY-START(4297064452),
    {
      "t": 655361,
      "n": "_hashCode",
      "d": 2097156,
      "h": 4297064452,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297064452)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476933636),
    {
      "p": [
        {
          "n": "ns",
          "p": 2162692
        },
        {
          "n": "localName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2097156,
      "h": 21476933636,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21476933636)
  ],
  "i": [$.$$.System.IEquatable$$($.$spxl.System.Xml.Linq.XName).$h,157483009
  ],
  "h": 2097156
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$spxl.System.Xml.Linq.XName), $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Xml.Linq.XName`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097156)
        
        
        //--TRIMMABLE-BOUNDARY-START(2424836)
        $asm.$cls("$spxl.System.Xml.Linq.XNodeEqualityComparer", ($self) => class XNodeEqualityComparer extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592359428)
            /*bool */ Equals$2(/*XNode?*/ x, /*XNode?*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592359428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XNode.DeepEquals(x, y);
            }
            //--TRIMMABLE-BOUNDARY-END(8592359428)
            
            //--TRIMMABLE-BOUNDARY-START(12887326724)
            /*int */ GetHashCode$1(/*XNode*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887326724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return obj !== null ? obj.GetDeepHashCode() : 0;
            }
            //--TRIMMABLE-BOUNDARY-END(12887326724)
            
            //--TRIMMABLE-BOUNDARY-START(17182294020)
            /*bool */ System$Collections$IEqualityComparer$Equals(/*object?*/ x, /*object?*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182294020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let n1 = $.$as(x, $.$spxl.System.Xml.Linq.XNode);
                if (n1 === null && x !== null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "x");
                }
                /*XNode?*/ let n2 = $.$as(y, $.$spxl.System.Xml.Linq.XNode);
                if (n2 === null && y !== null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "y");
                }
                return this.Equals$2(n1, n2);
            }
            //--TRIMMABLE-BOUNDARY-END(17182294020)
            
            //--TRIMMABLE-BOUNDARY-START(21477261316)
            /*int */ System$Collections$IEqualityComparer$GetHashCode(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477261316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let n = $.$as(obj, $.$spxl.System.Xml.Linq.XNode);
                if (n === null && obj !== null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "obj");
                }
                return this.GetHashCode$1(n);
            }
            //--TRIMMABLE-BOUNDARY-END(21477261316)
            
            //--TRIMMABLE-BOUNDARY-START(4354736129)
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Linq.XNode>.Equals(System.Xml.Linq.XNode?, System.Xml.Linq.XNode?)
            System$Collections$Generic$IEqualityComparer$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354736129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354736129)
            
            //--TRIMMABLE-BOUNDARY-START(8649703425)
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Linq.XNode>.GetHashCode(System.Xml.Linq.XNode)
            System$Collections$Generic$IEqualityComparer$$$GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649703425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetHashCode$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649703425)
            
            //--TRIMMABLE-BOUNDARY-START(4297392132)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297392132)
            
            static $h = 2424836;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592359428),
    {
      "r": 262145,
      "p": [
        {
          "n": "x",
          "p": 2228228
        },
        {
          "n": "y",
          "p": 2228228
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 2424836,
      "h": 8592359428,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592359428),
//--TRIMMABLE-BOUNDARY-START(12887326724),
    {
      "r": 655361,
      "p": [
        {
          "n": "obj",
          "p": 2228228
        }
      ],
      "n": "GetHashCode",
      "o": "@$1",
      "d": 2424836,
      "h": 12887326724,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887326724)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297392132),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2424836,
      "h": 4297392132,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297392132)
  ],
  "i": [62849025,$.$$.System.Collections.Generic.IEqualityComparer$$($.$spxl.System.Xml.Linq.XNode).$h
  ],
  "h": 2424836
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEqualityComparer, $.$$.System.Collections.Generic.IEqualityComparer$$($.$spxl.System.Xml.Linq.XNode) ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeEqualityComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424836)
        
        
        //--TRIMMABLE-BOUNDARY-START(2359300)
        $asm.$cls("$spxl.System.Xml.Linq.XNodeDocumentOrderComparer", ($self) => class XNodeDocumentOrderComparer extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592293892)
            /*int */ Compare(/*XNode?*/ x, /*XNode?*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592293892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XNode.CompareDocumentOrder(x, y);
            }
            //--TRIMMABLE-BOUNDARY-END(8592293892)
            
            //--TRIMMABLE-BOUNDARY-START(12887261188)
            /*int */ System$Collections$IComparer$Compare(/*object?*/ x, /*object?*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887261188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let n1 = $.$as(x, $.$spxl.System.Xml.Linq.XNode);
                if (n1 === null && x !== null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "x");
                }
                /*XNode?*/ let n2 = $.$as(y, $.$spxl.System.Xml.Linq.XNode);
                if (n2 === null && y !== null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "y");
                }
                return this.Compare(n1, n2);
            }
            //--TRIMMABLE-BOUNDARY-END(12887261188)
            
            //--TRIMMABLE-BOUNDARY-START(4354408449)
            //Generated interface implemetation for System.Collections.Generic.IComparer<System.Xml.Linq.XNode?>.Compare(System.Xml.Linq.XNode?, System.Xml.Linq.XNode?)
            System$Collections$Generic$IComparer$$$Compare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354408449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Compare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354408449)
            
            //--TRIMMABLE-BOUNDARY-START(4297326596)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297326596)
            
            static $h = 2359300;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592293892),
    {
      "r": 655361,
      "p": [
        {
          "n": "x",
          "p": 2228228
        },
        {
          "n": "y",
          "p": 2228228
        }
      ],
      "n": "Compare",
      "d": 2359300,
      "h": 8592293892,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592293892)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297326596),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2359300,
      "h": 4297326596,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297326596)
  ],
  "i": [62455809,$.$$.System.Collections.Generic.IComparer$$($.$spxl.System.Xml.Linq.XNode).$h
  ],
  "h": 2359300
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IComparer, $.$$.System.Collections.Generic.IComparer$$($.$spxl.System.Xml.Linq.XNode) ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeDocumentOrderComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359300)
        
        
        //--TRIMMABLE-BOUNDARY-START(458756)
        $asm.$str("$spxl.System.Xml.Linq.Inserter", ($self) => class Inserter extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295426052)
            /*XContainer*/  get _parent() { return this.$getField(0, 4); }
            /*XContainer*/  set _parent(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4295426052)
            
            //--TRIMMABLE-BOUNDARY-START(8590393348)
            /*XNode?*/  get _previous() { return this.$getField(4, 4); }
            /*XNode?*/  set _previous(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8590393348)
            
            //--TRIMMABLE-BOUNDARY-START(12885360644)
            /*string?*/  get _text() { return this.$getField(8, 4); }
            /*string?*/  set _text(value) { this.$setField(8, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12885360644)
            
            //--TRIMMABLE-BOUNDARY-START(21475295236)
            $ctor$3(/*XContainer*/ parent, /*XNode?*/ anchor)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475295236);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._parent = parent;
                    this._previous = anchor;
                    this._text = null;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475295236)
            
            //--TRIMMABLE-BOUNDARY-START(25770262532)
            /*void */ Add(/*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddContent(content);
                if ($.$$.System.String.op_Inequality(this._text, null))
                {
                    if (this._parent.content === null)
                    {
                        if (this._parent.SkipNotify())
                        {
                            this._parent.content = this._text;
                        }
                        else 
                        {
                            if (this._text.length > 0)
                            {
                                this.InsertNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(this._text));
                            }
                            else 
                            {
                                if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XElement))
                                {
                                    this._parent.NotifyChanging(this._parent, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                                    if (this._parent.content !== null)
                                    {
                                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                                    }
                                    this._parent.content = this._text;
                                    this._parent.NotifyChanged(this._parent, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                                }
                                else 
                                {
                                    this._parent.content = this._text;
                                }
                            }
                        }
                    }
                    else if (this._text.length > 0)
                    {
                        /*XText?*/ let prevXText = $.$as(this._previous, $.$spxl.System.Xml.Linq.XText);
                        if (prevXText !== null && !($.$is(this._previous, $.$spxl.System.Xml.Linq.XCData)))
                        {
                            prevXText.Value += this._text;
                        }
                        else 
                        {
                            this._parent.ConvertTextToNode();
                            this.InsertNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(this._text));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770262532)
            
            //--TRIMMABLE-BOUNDARY-START(30065229828)
            /*void */ AddContent(/*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.AddNode(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    this.AddString(s);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$13(x));
                    return;
                }
                /*object?[]?*/ let o = $.$as(content, $.$typeArray($.$$.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.AddContent(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$$.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$IEnumerable$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$IEnumerator$Current;
                        {
                            this.AddContent(obj);
                        }
                    }
                    return;
                }
                if ($.$is(content, $.$spxl.System.Xml.Linq.XAttribute))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_AddAttribute);
                }
                this.AddString($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            //--TRIMMABLE-BOUNDARY-END(30065229828)
            
            //--TRIMMABLE-BOUNDARY-START(34360197124)
            /*void */ AddNode(/*XNode*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._parent.ValidateNode(n, this._previous);
                if (n.parent !== null)
                {
                    n = n.CloneNode();
                }
                else 
                {
                    /*XNode*/ let p = this._parent;
                    while(p.parent !== null)
                    {
                        p = p.parent;
                    }
                    if (n === p)
                    {
                        n = n.CloneNode();
                    }
                }
                this._parent.ConvertTextToNode();
                if ($.$$.System.String.op_Inequality(this._text, null))
                {
                    if (this._text.length > 0)
                    {
                        /*XText?*/ let prevXText = $.$as(this._previous, $.$spxl.System.Xml.Linq.XText);
                        if (prevXText !== null && !($.$is(this._previous, $.$spxl.System.Xml.Linq.XCData)))
                        {
                            prevXText.Value += this._text;
                        }
                        else 
                        {
                            this.InsertNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(this._text));
                        }
                    }
                    this._text = null;
                }
                this.InsertNode(n);
            }
            //--TRIMMABLE-BOUNDARY-END(34360197124)
            
            //--TRIMMABLE-BOUNDARY-START(38655164420)
            /*void */ AddString(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._parent.ValidateString(s);
                this._text += s;
            }
            //--TRIMMABLE-BOUNDARY-END(38655164420)
            
            //--TRIMMABLE-BOUNDARY-START(42950131716)
            /*void */ InsertNode(/*XNode*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let notify = this._parent.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                if (n.parent !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                n.parent = this._parent;
                if (this._parent.content === null || $.$is(this._parent.content, $.$$.System.String))
                {
                    n.next = n;
                    this._parent.content = n;
                }
                else if (this._previous === null)
                {
                    /*XNode*/ let last = $.$cast(this._parent.content, $.$spxl.System.Xml.Linq.XNode);
                    n.next = last.next;
                    last.next = n;
                }
                else 
                {
                    n.next = this._previous.next;
                    this._previous.next = n;
                    if (this._parent.content === this._previous)
                    {
                        this._parent.content = n;
                    }
                }
                this._previous = n;
                if (notify)
                {
                    this._parent.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950131716)
            
            //--TRIMMABLE-BOUNDARY-START(17180327940)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180327940)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._parent = this._parent;
                copy._previous = this._previous;
                copy._text = this._text;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295426052)
                this._parent = null;
                //--TRIMMABLE-BOUNDARY-END(4295426052)
                
                //--TRIMMABLE-BOUNDARY-START(8590393348)
                this._previous = null;
                //--TRIMMABLE-BOUNDARY-END(8590393348)
                
                //--TRIMMABLE-BOUNDARY-START(12885360644)
                this._text = null;
                //--TRIMMABLE-BOUNDARY-END(12885360644)
                
            }
            static $h = 458756;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770262532),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "Add",
      "d": 458756,
      "h": 25770262532,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770262532),
//--TRIMMABLE-BOUNDARY-START(30065229828),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "AddContent",
      "d": 458756,
      "h": 30065229828,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065229828),
//--TRIMMABLE-BOUNDARY-START(34360197124),
    {
      "r": 65537,
      "p": [
        {
          "n": "n",
          "p": 2228228
        }
      ],
      "n": "AddNode",
      "d": 458756,
      "h": 34360197124,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360197124),
//--TRIMMABLE-BOUNDARY-START(38655164420),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "AddString",
      "d": 458756,
      "h": 38655164420,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655164420),
//--TRIMMABLE-BOUNDARY-START(42950131716),
    {
      "r": 65537,
      "p": [
        {
          "n": "n",
          "p": 2228228
        }
      ],
      "n": "InsertNode",
      "d": 458756,
      "h": 42950131716,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950131716)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295426052),
    {
      "t": 1310724,
      "n": "_parent",
      "d": 458756,
      "h": 4295426052,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426052),
//--TRIMMABLE-BOUNDARY-START(8590393348),
    {
      "t": 2228228,
      "n": "_previous",
      "d": 458756,
      "h": 8590393348,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590393348),
//--TRIMMABLE-BOUNDARY-START(12885360644),
    {
      "t": 1310721,
      "n": "_text",
      "d": 458756,
      "h": 12885360644,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885360644)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475295236),
    {
      "p": [
        {
          "n": "parent",
          "p": 1310724
        },
        {
          "n": "anchor",
          "p": 2228228
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458756,
      "h": 21475295236,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475295236),
//--TRIMMABLE-BOUNDARY-START(17180327940),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458756,
      "h": 17180327940,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180327940)
  ],
  "h": 458756
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.Inserter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458756)
        
        
        //--TRIMMABLE-BOUNDARY-START(720900)
        $asm.$str("$spxl.System.Xml.Linq.NamespaceCache", ($self) => class NamespaceCache extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590655492)
            /*XNamespace*/  get _ns() { return this.$getField(0, 4); }
            /*XNamespace*/  set _ns(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8590655492)
            
            //--TRIMMABLE-BOUNDARY-START(4295688196)
            /*string*/  get _namespaceName() { return this.$getField(4, 4); }
            /*string*/  set _namespaceName(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4295688196)
            
            //--TRIMMABLE-BOUNDARY-START(17180590084)
            /*XNamespace */ Get(/*string*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (namespaceName === this._namespaceName)
                {
                    return this._ns;
                }
                this._namespaceName = namespaceName;
                this._ns = $.$spxl.System.Xml.Linq.XNamespace.Get$1(namespaceName);
                return this._ns;
            }
            //--TRIMMABLE-BOUNDARY-END(17180590084)
            
            //--TRIMMABLE-BOUNDARY-START(12885622788)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622788)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._ns = this._ns;
                copy._namespaceName = this._namespaceName;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590655492)
                this._ns = null;
                //--TRIMMABLE-BOUNDARY-END(8590655492)
                
                //--TRIMMABLE-BOUNDARY-START(4295688196)
                this._namespaceName = null;
                //--TRIMMABLE-BOUNDARY-END(4295688196)
                
            }
            static $h = 720900;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180590084),
    {
      "r": 2162692,
      "p": [
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "Get",
      "d": 720900,
      "h": 17180590084,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180590084)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590655492),
    {
      "t": 2162692,
      "n": "_ns",
      "d": 720900,
      "h": 8590655492,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655492),
//--TRIMMABLE-BOUNDARY-START(4295688196),
    {
      "t": 1310721,
      "n": "_namespaceName",
      "d": 720900,
      "h": 4295688196,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688196)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885622788),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720900,
      "h": 12885622788,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885622788)
  ],
  "h": 720900
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.NamespaceCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720900)
        
        
        //--TRIMMABLE-BOUNDARY-START(327684)
        $asm.$str("$spxl.System.Xml.Linq.ElementWriter", ($self) => class ElementWriter extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590262276)
            /*XmlWriter*/  get _writer() { return this.$getField(0, 4); }
            /*XmlWriter*/  set _writer(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8590262276)
            
            //--TRIMMABLE-BOUNDARY-START(4295294980)
            /*NamespaceResolver*/  get _resolver() { return this.$getField(4, 12); }
            /*NamespaceResolver*/  set _resolver(value) { this.$setField(4, 12, value); }
            //--TRIMMABLE-BOUNDARY-END(4295294980)
            
            //--TRIMMABLE-BOUNDARY-START(17180196868)
            $ctor$3(/*XmlWriter*/ writer)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180196868);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._writer = writer;
                    this._resolver = new $.$spxl.System.Xml.Linq.NamespaceResolver();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196868)
            
            //--TRIMMABLE-BOUNDARY-START(34360066052)
            /*void */ WriteElement(/*XElement*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PushAncestors(e);
                /*XElement*/ let root = e;
                /*XNode*/ let n = e;
                while(true)
                {
                    /*XElement?*/ let current = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                    if (current !== null)
                    {
                        this.WriteStartElement(current);
                        if (current.content === null)
                        {
                            this.WriteEndElement();
                        }
                        else 
                        {
                            /*string?*/ let s = $.$as(current.content, $.$$.System.String);
                            if ($.$$.System.String.op_Inequality(s, null))
                            {
                                this._writer.WriteString(s);
                                this.WriteFullEndElement();
                            }
                            else 
                            {
                                n = ($.$cast(current.content, $.$spxl.System.Xml.Linq.XNode)).next;
                                continue;
                            }
                        }
                    }
                    else 
                    {
                        n.WriteTo(this._writer);
                    }
                    while(n !== root && n === n.parent.content)
                    {
                        n = n.parent;
                        this.WriteFullEndElement();
                    }
                    if (n === root)
                    {
                        break;
                    }
                    n = n.next;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360066052)
            
            //--TRIMMABLE-BOUNDARY-START(38655033348)
            /*Task *//*async*/  WriteElementAsync(/*XElement*/ e, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655033348);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.PushAncestors(e);
                    /*XElement*/ let root = e;
                    /*XNode*/ let n = e;
                    while(true)
                    {
                        /*XElement?*/ let current = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (current !== null)
                        {
                            await this.WriteStartElementAsync(current, cancellationToken).ConfigureAwait(false);
                            if (current.content === null)
                            {
                                await this.WriteEndElementAsync(cancellationToken).ConfigureAwait(false);
                            }
                            else 
                            {
                                /*string?*/ let s = $.$as(current.content, $.$$.System.String);
                                if ($.$$.System.String.op_Inequality(s, null))
                                {
                                    cancellationToken.ThrowIfCancellationRequested();
                                    await this._writer.WriteStringAsync(s).ConfigureAwait(false);
                                    await this.WriteFullEndElementAsync(cancellationToken).ConfigureAwait(false);
                                }
                                else 
                                {
                                    n = ($.$cast(current.content, $.$spxl.System.Xml.Linq.XNode)).next;
                                    continue;
                                }
                            }
                        }
                        else 
                        {
                            await n.WriteToAsync(this._writer, cancellationToken).ConfigureAwait(false);
                        }
                        while(n !== root && n === n.parent.content)
                        {
                            n = n.parent;
                            await this.WriteFullEndElementAsync(cancellationToken).ConfigureAwait(false);
                        }
                        if (n === root)
                        {
                            break;
                        }
                        n = n.next;
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38655033348)
            
            //--TRIMMABLE-BOUNDARY-START(21475164164)
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns, /*bool*/ allowDefaultNamespace)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let namespaceName = ns.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$$.System.String.Empty;
                }
                /*string?*/ let prefix = this._resolver.GetPrefixOfNamespace(ns, allowDefaultNamespace);
                if ($.$$.System.String.op_Inequality(prefix, null))
                {
                    return prefix;
                }
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    return "xml";
                }
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(21475164164)
            
            //--TRIMMABLE-BOUNDARY-START(25770131460)
            /*void */ PushAncestors(/*XElement?*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770131460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                while(true)
                {
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    if (e === null)
                    {
                        break;
                    }
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration)
                            {
                                this._resolver.AddFirst(a.Name.NamespaceName.length === 0 ? $.$$.System.String.Empty : a.Name.LocalName, $.$spxl.System.Xml.Linq.XNamespace.Get$1(a.Value));
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770131460)
            
            //--TRIMMABLE-BOUNDARY-START(30065098756)
            /*void */ PushElement(/*XElement*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065098756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._resolver.PushScope();
                /*XAttribute?*/ let a = e.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if (a.IsNamespaceDeclaration)
                        {
                            this._resolver.Add(a.Name.NamespaceName.length === 0 ? $.$$.System.String.Empty : a.Name.LocalName, $.$spxl.System.Xml.Linq.XNamespace.Get$1(a.Value));
                        }
                    }
                    while(a !== e.lastAttr);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065098756)
            
            //--TRIMMABLE-BOUNDARY-START(42950000644)
            /*void */ WriteEndElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950000644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._writer.WriteEndElement();
                this._resolver.PopScope();
            }
            //--TRIMMABLE-BOUNDARY-END(42950000644)
            
            //--TRIMMABLE-BOUNDARY-START(47244967940)
            /*Task *//*async*/  WriteEndElementAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244967940);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    cancellationToken.ThrowIfCancellationRequested();
                    await this._writer.WriteEndElementAsync().ConfigureAwait(false);
                    this._resolver.PopScope();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47244967940)
            
            //--TRIMMABLE-BOUNDARY-START(51539935236)
            /*void */ WriteFullEndElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539935236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._writer.WriteFullEndElement();
                this._resolver.PopScope();
            }
            //--TRIMMABLE-BOUNDARY-END(51539935236)
            
            //--TRIMMABLE-BOUNDARY-START(55834902532)
            /*Task *//*async*/  WriteFullEndElementAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834902532);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    cancellationToken.ThrowIfCancellationRequested();
                    await this._writer.WriteFullEndElementAsync().ConfigureAwait(false);
                    this._resolver.PopScope();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55834902532)
            
            //--TRIMMABLE-BOUNDARY-START(60129869828)
            /*void */ WriteStartElement(/*XElement*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129869828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PushElement(e);
                /*XNamespace*/ let ns = e.Name.Namespace;
                this._writer.WriteStartElement(this.GetPrefixOfNamespace(ns, true), e.Name.LocalName, ns.NamespaceName);
                /*XAttribute?*/ let a = e.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        ns = a.Name.Namespace;
                        /*string*/ let localName = a.Name.LocalName;
                        /*string*/ let namespaceName = ns.NamespaceName;
                        this._writer.WriteAttributeString(this.GetPrefixOfNamespace(ns, false), localName, namespaceName.length === 0 && $.$$.System.String.op_Equality(localName, "xmlns") ? "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/ : namespaceName, a.Value);
                    }
                    while(a !== e.lastAttr);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129869828)
            
            //--TRIMMABLE-BOUNDARY-START(64424837124)
            /*Task *//*async*/  WriteStartElementAsync(/*XElement*/ e, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424837124);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.PushElement(e);
                    /*XNamespace*/ let ns = e.Name.Namespace;
                    await this._writer.WriteStartElementAsync(this.GetPrefixOfNamespace(ns, true), e.Name.LocalName, ns.NamespaceName).ConfigureAwait(false);
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            ns = a.Name.Namespace;
                            /*string*/ let localName = a.Name.LocalName;
                            /*string*/ let namespaceName = ns.NamespaceName;
                            cancellationToken.ThrowIfCancellationRequested();
                            await this._writer.WriteAttributeStringAsync(this.GetPrefixOfNamespace(ns, false), localName, namespaceName.length === 0 && $.$$.System.String.op_Equality(localName, "xmlns") ? "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/ : namespaceName, a.Value).ConfigureAwait(false);
                        }
                        while(a !== e.lastAttr);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64424837124)
            
            //--TRIMMABLE-BOUNDARY-START(12885229572)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885229572)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._writer = this._writer;
                copy._resolver = this._resolver.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590262276)
                this._writer = null;
                //--TRIMMABLE-BOUNDARY-END(8590262276)
                
                //--TRIMMABLE-BOUNDARY-START(4295294980)
                this._resolver = $.$default($.$spxl.System.Xml.Linq.NamespaceResolver);
                //--TRIMMABLE-BOUNDARY-END(4295294980)
                
            }
            static $h = 327684;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360066052),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 1638404
        }
      ],
      "n": "WriteElement",
      "d": 327684,
      "h": 34360066052,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360066052),
//--TRIMMABLE-BOUNDARY-START(38655033348),
    {
      "r": 177668097,
      "p": [
        {
          "n": "e",
          "p": 1638404
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteElementAsync",
      "d": 327684,
      "h": 38655033348,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(38655033348),
//--TRIMMABLE-BOUNDARY-START(21475164164),
    {
      "r": 1310721,
      "p": [
        {
          "n": "ns",
          "p": 2162692
        },
        {
          "n": "allowDefaultNamespace",
          "p": 262145
        }
      ],
      "n": "GetPrefixOfNamespace",
      "d": 327684,
      "h": 21475164164,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475164164),
//--TRIMMABLE-BOUNDARY-START(25770131460),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 1638404
        }
      ],
      "n": "PushAncestors",
      "d": 327684,
      "h": 25770131460,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770131460),
//--TRIMMABLE-BOUNDARY-START(30065098756),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 1638404
        }
      ],
      "n": "PushElement",
      "d": 327684,
      "h": 30065098756,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065098756),
//--TRIMMABLE-BOUNDARY-START(42950000644),
    {
      "r": 65537,
      "n": "WriteEndElement",
      "d": 327684,
      "h": 42950000644,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950000644),
//--TRIMMABLE-BOUNDARY-START(47244967940),
    {
      "r": 177668097,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteEndElementAsync",
      "d": 327684,
      "h": 47244967940,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(47244967940),
//--TRIMMABLE-BOUNDARY-START(51539935236),
    {
      "r": 65537,
      "n": "WriteFullEndElement",
      "d": 327684,
      "h": 51539935236,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51539935236),
//--TRIMMABLE-BOUNDARY-START(55834902532),
    {
      "r": 177668097,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteFullEndElementAsync",
      "d": 327684,
      "h": 55834902532,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(55834902532),
//--TRIMMABLE-BOUNDARY-START(60129869828),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 1638404
        }
      ],
      "n": "WriteStartElement",
      "d": 327684,
      "h": 60129869828,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60129869828),
//--TRIMMABLE-BOUNDARY-START(64424837124),
    {
      "r": 177668097,
      "p": [
        {
          "n": "e",
          "p": 1638404
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteStartElementAsync",
      "d": 327684,
      "h": 64424837124,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(64424837124)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590262276),
    {
      "t": 58392579,
      "n": "_writer",
      "d": 327684,
      "h": 8590262276,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590262276),
//--TRIMMABLE-BOUNDARY-START(4295294980),
    {
      "t": 786436,
      "n": "_resolver",
      "d": 327684,
      "h": 4295294980,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295294980)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180196868),
    {
      "p": [
        {
          "n": "writer",
          "p": 58392579
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327684,
      "h": 17180196868,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180196868),
//--TRIMMABLE-BOUNDARY-START(12885229572),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327684,
      "h": 12885229572,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885229572)
  ],
  "h": 327684
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.ElementWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327684)
        
        
        //--TRIMMABLE-BOUNDARY-START(786436)
        $asm.$str("$spxl.System.Xml.Linq.NamespaceResolver", ($self) => class NamespaceResolver extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(851972)
            static $_NamespaceDeclaration;
            static get NamespaceDeclaration()
            {
                let $cls = $.$spxl.System.Xml.Linq.NamespaceResolver;
                return $cls.$_NamespaceDeclaration ??= $asm.$ncls("$spxl.System.Xml.Linq.NamespaceResolver.NamespaceDeclaration", ($self) => class NamespaceDeclaration extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12885753860)
                    /*string*/ prefix = null;
                    //--TRIMMABLE-BOUNDARY-END(12885753860)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590786564)
                    /*XNamespace*/ ns = null;
                    //--TRIMMABLE-BOUNDARY-END(8590786564)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475688452)
                    /*int*/ scope = 0;
                    //--TRIMMABLE-BOUNDARY-END(21475688452)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180721156)
                    /*NamespaceDeclaration*/ prev = null;
                    //--TRIMMABLE-BOUNDARY-END(17180721156)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295819268)
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295819268)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(12885753860)
                        this.prefix = null;
                        //--TRIMMABLE-BOUNDARY-END(12885753860)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590786564)
                        this.ns = null;
                        //--TRIMMABLE-BOUNDARY-END(8590786564)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180721156)
                        this.prev = null;
                        //--TRIMMABLE-BOUNDARY-END(17180721156)
                        
                    }
                    static $h = 851972;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885753860),
    {
      "t": 1310721,
      "n": "prefix",
      "d": 851972,
      "h": 12885753860,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12885753860),
//--TRIMMABLE-BOUNDARY-START(8590786564),
    {
      "t": 2162692,
      "n": "ns",
      "d": 851972,
      "h": 8590786564,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8590786564),
//--TRIMMABLE-BOUNDARY-START(21475688452),
    {
      "t": 655361,
      "n": "scope",
      "d": 851972,
      "h": 21475688452,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(21475688452),
//--TRIMMABLE-BOUNDARY-START(17180721156),
    {
      "t": 851972,
      "n": "prev",
      "d": 851972,
      "h": 17180721156,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17180721156)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819268),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 851972,
      "h": 4295819268,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819268)
  ],
  "d": 786436,
  "h": 851972
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Xml.Linq.NamespaceResolver.NamespaceDeclaration`; }
                }, $cls, ($v) => $cls.$_NamespaceDeclaration = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(851972)
            
            //--TRIMMABLE-BOUNDARY-START(12885688324)
            /*int*/  get _scope() { return this.$getField(0, 4); }
            /*int*/  set _scope(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12885688324)
            
            //--TRIMMABLE-BOUNDARY-START(4295753732)
            /*NamespaceDeclaration?*/  get _declaration() { return this.$getField(4, 4); }
            /*NamespaceDeclaration?*/  set _declaration(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4295753732)
            
            //--TRIMMABLE-BOUNDARY-START(8590721028)
            /*NamespaceDeclaration?*/  get _rover() { return this.$getField(8, 4); }
            /*NamespaceDeclaration?*/  set _rover(value) { this.$setField(8, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8590721028)
            
            //--TRIMMABLE-BOUNDARY-START(42950459396)
            /*void */ PushScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950459396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._scope++;
            }
            //--TRIMMABLE-BOUNDARY-END(42950459396)
            
            //--TRIMMABLE-BOUNDARY-START(38655492100)
            /*void */ PopScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655492100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*NamespaceDeclaration?*/ let d = this._declaration;
                if (d !== null)
                {
                    do
                    {
                        d = d.prev;
                        if (d.scope !== this._scope)
                        {
                            break;
                        }
                        if (d === this._declaration)
                        {
                            this._declaration = null;
                        }
                        else 
                        {
                            this._declaration.prev = d.prev;
                        }
                        this._rover = null;
                    }
                    while(d !== this._declaration && this._declaration !== null);
                }
                this._scope--;
            }
            //--TRIMMABLE-BOUNDARY-END(38655492100)
            
            //--TRIMMABLE-BOUNDARY-START(25770590212)
            /*void */ Add(/*string*/ prefix, /*XNamespace*/ ns)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*NamespaceDeclaration*/ let d = new $.$spxl.System.Xml.Linq.NamespaceResolver.NamespaceDeclaration().$ctor$1();
                d.prefix = prefix;
                d.ns = ns;
                d.scope = this._scope;
                if (this._declaration === null)
                {
                    this._declaration = d;
                }
                else 
                {
                    d.prev = this._declaration.prev;
                }
                this._declaration.prev = d;
                this._rover = null;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590212)
            
            //--TRIMMABLE-BOUNDARY-START(30065557508)
            /*void */ AddFirst(/*string*/ prefix, /*XNamespace*/ ns)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065557508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*NamespaceDeclaration*/ let d = new $.$spxl.System.Xml.Linq.NamespaceResolver.NamespaceDeclaration().$ctor$1();
                d.prefix = prefix;
                d.ns = ns;
                d.scope = this._scope;
                if (this._declaration === null)
                {
                    d.prev = d;
                }
                else 
                {
                    d.prev = this._declaration.prev;
                    this._declaration.prev = d;
                }
                this._declaration = d;
                this._rover = null;
            }
            //--TRIMMABLE-BOUNDARY-END(30065557508)
            
            //--TRIMMABLE-BOUNDARY-START(34360524804)
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns, /*bool*/ allowDefaultNamespace)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._rover !== null && $.$spxl.System.Xml.Linq.XNamespace.op_Equality(this._rover.ns, ns) && (allowDefaultNamespace || this._rover.prefix.length > 0))
                {
                    return this._rover.prefix;
                }
                /*NamespaceDeclaration?*/ let d = this._declaration;
                if (d !== null)
                {
                    do
                    {
                        d = d.prev;
                        if ($.$spxl.System.Xml.Linq.XNamespace.op_Equality(d.ns, ns))
                        {
                            /*NamespaceDeclaration*/ let x = this._declaration.prev;
                            while(x !== d && $.$$.System.String.op_Inequality(x.prefix, d.prefix))
                            {
                                x = x.prev;
                            }
                            if (x === d)
                            {
                                if (allowDefaultNamespace)
                                {
                                    this._rover = d;
                                    return d.prefix;
                                }
                                else if (d.prefix.length > 0)
                                {
                                    return d.prefix;
                                }
                            }
                        }
                    }
                    while(d !== this._declaration);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(34360524804)
            
            //--TRIMMABLE-BOUNDARY-START(21475622916)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475622916)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._scope = this._scope;
                copy._declaration = this._declaration;
                copy._rover = this._rover;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885688324)
                this._scope = 0;
                //--TRIMMABLE-BOUNDARY-END(12885688324)
                
                //--TRIMMABLE-BOUNDARY-START(4295753732)
                this._declaration = null;
                //--TRIMMABLE-BOUNDARY-END(4295753732)
                
                //--TRIMMABLE-BOUNDARY-START(8590721028)
                this._rover = null;
                //--TRIMMABLE-BOUNDARY-END(8590721028)
                
            }
            static $h = 786436;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950459396),
    {
      "r": 65537,
      "n": "PushScope",
      "d": 786436,
      "h": 42950459396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950459396),
//--TRIMMABLE-BOUNDARY-START(38655492100),
    {
      "r": 65537,
      "n": "PopScope",
      "d": 786436,
      "h": 38655492100,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655492100),
//--TRIMMABLE-BOUNDARY-START(25770590212),
    {
      "r": 65537,
      "p": [
        {
          "n": "prefix",
          "p": 1310721
        },
        {
          "n": "ns",
          "p": 2162692
        }
      ],
      "n": "Add",
      "d": 786436,
      "h": 25770590212,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590212),
//--TRIMMABLE-BOUNDARY-START(30065557508),
    {
      "r": 65537,
      "p": [
        {
          "n": "prefix",
          "p": 1310721
        },
        {
          "n": "ns",
          "p": 2162692
        }
      ],
      "n": "AddFirst",
      "d": 786436,
      "h": 30065557508,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065557508),
//--TRIMMABLE-BOUNDARY-START(34360524804),
    {
      "r": 1310721,
      "p": [
        {
          "n": "ns",
          "p": 2162692
        },
        {
          "n": "allowDefaultNamespace",
          "p": 262145
        }
      ],
      "n": "GetPrefixOfNamespace",
      "d": 786436,
      "h": 34360524804,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360524804)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885688324),
    {
      "t": 655361,
      "n": "_scope",
      "d": 786436,
      "h": 12885688324,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688324),
//--TRIMMABLE-BOUNDARY-START(4295753732),
    {
      "t": 851972,
      "n": "_declaration",
      "d": 786436,
      "h": 4295753732,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753732),
//--TRIMMABLE-BOUNDARY-START(8590721028),
    {
      "t": 851972,
      "n": "_rover",
      "d": 786436,
      "h": 8590721028,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721028)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475622916),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786436,
      "h": 21475622916,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475622916)
  ],
  "j": [851972
  ],
  "h": 786436
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.NamespaceResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786436)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048580)
        $asm.$str("$spxl.System.Xml.Linq.StreamingElementWriter", ($self) => class StreamingElementWriter extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17180917764)
            /*XmlWriter*/  get _writer() { return this.$getField(0, 4); }
            /*XmlWriter*/  set _writer(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(17180917764)
            
            //--TRIMMABLE-BOUNDARY-START(8590983172)
            /*XStreamingElement?*/  get _element() { return this.$getField(4, 4); }
            /*XStreamingElement?*/  set _element(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8590983172)
            
            //--TRIMMABLE-BOUNDARY-START(4296015876)
            /*List<XAttribute>*/  get _attributes() { return this.$getField(8, 4); }
            /*List<XAttribute>*/  set _attributes(value) { this.$setField(8, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4296015876)
            
            //--TRIMMABLE-BOUNDARY-START(12885950468)
            /*NamespaceResolver*/  get _resolver() { return this.$getField(12, 12); }
            /*NamespaceResolver*/  set _resolver(value) { this.$setField(12, 12, value); }
            //--TRIMMABLE-BOUNDARY-END(12885950468)
            
            //--TRIMMABLE-BOUNDARY-START(25770852356)
            $ctor$3(/*XmlWriter*/ w)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770852356);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._writer = w;
                    this._element = null;
                    this._attributes = new ($.$$.System.Collections.Generic.List$$($.$spxl.System.Xml.Linq.XAttribute))().$ctor$1();
                    this._resolver = new $.$spxl.System.Xml.Linq.NamespaceResolver();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770852356)
            
            //--TRIMMABLE-BOUNDARY-START(30065819652)
            /*void */ FlushElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065819652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._element !== null)
                {
                    this.PushElement();
                    /*XNamespace*/ let ns = this._element.Name.Namespace;
                    this._writer.WriteStartElement(this.GetPrefixOfNamespace(ns, true), this._element.Name.LocalName, ns.NamespaceName);
                    var $en3 = this._attributes.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var a = $en3.Current;
                        {
                            ns = a.Name.Namespace;
                            /*string*/ let localName = a.Name.LocalName;
                            /*string*/ let namespaceName = ns.NamespaceName;
                            this._writer.WriteAttributeString(this.GetPrefixOfNamespace(ns, false), localName, namespaceName.length === 0 && $.$$.System.String.op_Equality(localName, "xmlns") ? "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/ : namespaceName, a.Value);
                        }
                    }
                    this._element = null;
                    this._attributes.Clear();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065819652)
            
            //--TRIMMABLE-BOUNDARY-START(34360786948)
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns, /*bool*/ allowDefaultNamespace)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360786948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let namespaceName = ns.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$$.System.String.Empty;
                }
                /*string?*/ let prefix = this._resolver.GetPrefixOfNamespace(ns, allowDefaultNamespace);
                if ($.$$.System.String.op_Inequality(prefix, null))
                {
                    return prefix;
                }
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    return "xml";
                }
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(34360786948)
            
            //--TRIMMABLE-BOUNDARY-START(38655754244)
            /*void */ PushElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655754244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._resolver.PushScope();
                var $en2 = this._attributes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var a = $en2.Current;
                    {
                        if (a.IsNamespaceDeclaration)
                        {
                            this._resolver.Add(a.Name.NamespaceName.length === 0 ? $.$$.System.String.Empty : a.Name.LocalName, $.$spxl.System.Xml.Linq.XNamespace.Get$1(a.Value));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655754244)
            
            //--TRIMMABLE-BOUNDARY-START(42950721540)
            /*void */ Write(/*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950721540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.WriteNode(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    this.WriteString(s);
                    return;
                }
                /*XAttribute?*/ let a = $.$as(content, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    this.WriteAttribute(a);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.WriteStreamingElement(x);
                    return;
                }
                /*object[]?*/ let o = $.$as(content, $.$typeArray($.$$.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.Write(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$$.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$IEnumerable$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$IEnumerator$Current;
                        {
                            this.Write(obj);
                        }
                    }
                    return;
                }
                this.WriteString($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            //--TRIMMABLE-BOUNDARY-END(42950721540)
            
            //--TRIMMABLE-BOUNDARY-START(47245688836)
            /*void */ WriteAttribute(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245688836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._element === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_WriteAttribute);
                }
                this._attributes.Add(a);
            }
            //--TRIMMABLE-BOUNDARY-END(47245688836)
            
            //--TRIMMABLE-BOUNDARY-START(51540656132)
            /*void */ WriteNode(/*XNode*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540656132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.FlushElement();
                n.WriteTo(this._writer);
            }
            //--TRIMMABLE-BOUNDARY-END(51540656132)
            
            //--TRIMMABLE-BOUNDARY-START(55835623428)
            /*void */ WriteStreamingElement(/*XStreamingElement*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835623428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.FlushElement();
                this._element = e;
                this.Write(e.content);
                this.FlushElement();
                this._writer.WriteEndElement();
                this._resolver.PopScope();
            }
            //--TRIMMABLE-BOUNDARY-END(55835623428)
            
            //--TRIMMABLE-BOUNDARY-START(60130590724)
            /*void */ WriteString(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130590724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.FlushElement();
                this._writer.WriteString(s);
            }
            //--TRIMMABLE-BOUNDARY-END(60130590724)
            
            //--TRIMMABLE-BOUNDARY-START(21475885060)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475885060)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._writer = this._writer;
                copy._element = this._element;
                copy._attributes = this._attributes;
                copy._resolver = this._resolver.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180917764)
                this._writer = null;
                //--TRIMMABLE-BOUNDARY-END(17180917764)
                
                //--TRIMMABLE-BOUNDARY-START(8590983172)
                this._element = null;
                //--TRIMMABLE-BOUNDARY-END(8590983172)
                
                //--TRIMMABLE-BOUNDARY-START(4296015876)
                this._attributes = null;
                //--TRIMMABLE-BOUNDARY-END(4296015876)
                
                //--TRIMMABLE-BOUNDARY-START(12885950468)
                this._resolver = $.$default($.$spxl.System.Xml.Linq.NamespaceResolver);
                //--TRIMMABLE-BOUNDARY-END(12885950468)
                
            }
            static $h = 1048580;
            static $z = 24;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065819652),
    {
      "r": 65537,
      "n": "FlushElement",
      "d": 1048580,
      "h": 30065819652,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065819652),
//--TRIMMABLE-BOUNDARY-START(34360786948),
    {
      "r": 1310721,
      "p": [
        {
          "n": "ns",
          "p": 2162692
        },
        {
          "n": "allowDefaultNamespace",
          "p": 262145
        }
      ],
      "n": "GetPrefixOfNamespace",
      "d": 1048580,
      "h": 34360786948,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360786948),
//--TRIMMABLE-BOUNDARY-START(38655754244),
    {
      "r": 65537,
      "n": "PushElement",
      "d": 1048580,
      "h": 38655754244,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655754244),
//--TRIMMABLE-BOUNDARY-START(42950721540),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "Write",
      "d": 1048580,
      "h": 42950721540,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950721540),
//--TRIMMABLE-BOUNDARY-START(47245688836),
    {
      "r": 65537,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "WriteAttribute",
      "d": 1048580,
      "h": 47245688836,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47245688836),
//--TRIMMABLE-BOUNDARY-START(51540656132),
    {
      "r": 65537,
      "p": [
        {
          "n": "n",
          "p": 2228228
        }
      ],
      "n": "WriteNode",
      "d": 1048580,
      "h": 51540656132,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540656132),
//--TRIMMABLE-BOUNDARY-START(55835623428),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 2883588
        }
      ],
      "n": "WriteStreamingElement",
      "d": 1048580,
      "h": 55835623428,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(55835623428),
//--TRIMMABLE-BOUNDARY-START(60130590724),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "WriteString",
      "d": 1048580,
      "h": 60130590724,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60130590724)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180917764),
    {
      "t": 58392579,
      "n": "_writer",
      "d": 1048580,
      "h": 17180917764,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180917764),
//--TRIMMABLE-BOUNDARY-START(8590983172),
    {
      "t": 2883588,
      "n": "_element",
      "d": 1048580,
      "h": 8590983172,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590983172),
//--TRIMMABLE-BOUNDARY-START(4296015876),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$spxl.System.Xml.Linq.XAttribute).$h,
      "n": "_attributes",
      "d": 1048580,
      "h": 4296015876,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296015876),
//--TRIMMABLE-BOUNDARY-START(12885950468),
    {
      "t": 786436,
      "n": "_resolver",
      "d": 1048580,
      "h": 12885950468,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885950468)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770852356),
    {
      "p": [
        {
          "n": "w",
          "p": 58392579
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1048580,
      "h": 25770852356,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770852356),
//--TRIMMABLE-BOUNDARY-START(21475885060),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048580,
      "h": 21475885060,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475885060)
  ],
  "h": 1048580
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.StreamingElementWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048580)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114116)
        $asm.$cls("$spxl.System.Xml.Linq.XAttribute", ($self) => class XAttribute extends $.$spxl.System.Xml.Linq.XObject
        {
            //--TRIMMABLE-BOUNDARY-START(120260198404)
            static /*IEnumerable<XAttribute> */ get EmptySequence()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850132996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Array.Empty($.$spxl.System.Xml.Linq.XAttribute);
            }
            //--TRIMMABLE-BOUNDARY-END(120260198404)
            
            //--TRIMMABLE-BOUNDARY-START(206159544324)
            /*XAttribute?*/ next = null;
            //--TRIMMABLE-BOUNDARY-END(206159544324)
            
            //--TRIMMABLE-BOUNDARY-START(197569609732)
            /*XName*/ name = null;
            //--TRIMMABLE-BOUNDARY-END(197569609732)
            
            //--TRIMMABLE-BOUNDARY-START(249109217284)
            /*string*/ value = null;
            //--TRIMMABLE-BOUNDARY-END(249109217284)
            
            //--TRIMMABLE-BOUNDARY-START(115965231108)
            $ctor$3(/*XName*/ name, /*object*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115965231108);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                    /*string*/ let s = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
                    $.$spxl.System.Xml.Linq.XAttribute.ValidateAttribute(name, s);
                    this.name = name;
                    this.value = s;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(115965231108)
            
            //--TRIMMABLE-BOUNDARY-START(111670263812)
            $ctor$2(/*XAttribute*/ other)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670263812);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this.name = other.name;
                    this.value = other.value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(111670263812)
            
            //--TRIMMABLE-BOUNDARY-START(193274642436)
            /*bool */ get IsNamespaceDeclaration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440067588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let namespaceName = this.name.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$$.System.String.op_Equality(this.name.LocalName, "xmlns");
                }
                return namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/;
            }
            //--TRIMMABLE-BOUNDARY-END(193274642436)
            
            //--TRIMMABLE-BOUNDARY-START(201864577028)
            /*XName */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030002180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.name;
            }
            //--TRIMMABLE-BOUNDARY-END(201864577028)
            
            //--TRIMMABLE-BOUNDARY-START(210454511620)
            /*XAttribute? */ get NextAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619936772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.parent !== null && ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr !== this ? this.next : null;
            }
            //--TRIMMABLE-BOUNDARY-END(210454511620)
            
            //--TRIMMABLE-BOUNDARY-START(214749478916)
            /*XmlNodeType */ get NodeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209871364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 2/*XmlNodeType.Attribute*/;
            }
            //--TRIMMABLE-BOUNDARY-END(214749478916)
            
            //--TRIMMABLE-BOUNDARY-START(219044446212)
            /*XAttribute? */ get PreviousAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799805956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.parent === null)
                {
                    return null;
                }
                /*XAttribute*/ let a = ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr;
                while(a.next !== this)
                {
                    a = a.next;
                }
                return a !== ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr ? a : null;
            }
            //--TRIMMABLE-BOUNDARY-END(219044446212)
            
            //--TRIMMABLE-BOUNDARY-START(253404184580)
            /*string */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389740548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.value;
            }
            /*string */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929348100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                $.$spxl.System.Xml.Linq.XAttribute.ValidateAttribute(this.name, value);
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.value = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253404184580)
            
            //--TRIMMABLE-BOUNDARY-START(223339413508)
            /*void */ Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339413508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.parent === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).RemoveAttribute(this);
            }
            //--TRIMMABLE-BOUNDARY-END(223339413508)
            
            //--TRIMMABLE-BOUNDARY-START(236224315396)
            /*void */ SetValue(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224315396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
            }
            //--TRIMMABLE-BOUNDARY-END(236224315396)
            
            //--TRIMMABLE-BOUNDARY-START(240519282692)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519282692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let sw = null;
                try
                {
                    sw = new $.$$.System.IO.StringWriter().$ctor$5($.$$.System.Globalization.CultureInfo.InvariantCulture);
                    /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                    ws.ConformanceLevel = 1/*ConformanceLevel.Fragment*/;
                    let w = null;
                    try
                    {
                        w = $.$spx.System.Xml.XmlWriter.Create$2(sw, ws);
                        w.WriteAttributeString(this.GetPrefixOfNamespace(this.name.Namespace), this.name.LocalName, this.name.NamespaceName, this.value);
                    }
                    finally
                    {
                        w?.System$IDisposable$Dispose();
                    }
                    return $.$$.System.String.Trim.call($.$$.System.IO.StringWriter.ToString.call(sw));
                }
                finally
                {
                    sw?.System$IDisposable$Dispose();
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XAttribute.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(240519282692)
            
            //--TRIMMABLE-BOUNDARY-START(94490394628)
            static /*string? */ op_Explicit$21(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return attribute.value;
            }
            //--TRIMMABLE-BOUNDARY-END(94490394628)
            
            //--TRIMMABLE-BOUNDARY-START(4296081412)
            static /*bool */ op_Explicit(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$$.System.String.ToLowerInvariant.call(attribute.value));
            }
            //--TRIMMABLE-BOUNDARY-END(4296081412)
            
            //--TRIMMABLE-BOUNDARY-START(38655819780)
            static /*bool? */ op_Explicit$8(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$$.System.String.ToLowerInvariant.call(attribute.value));
            }
            //--TRIMMABLE-BOUNDARY-END(38655819780)
            
            //--TRIMMABLE-BOUNDARY-START(30065885188)
            static /*int */ op_Explicit$6(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToInt32(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(30065885188)
            
            //--TRIMMABLE-BOUNDARY-START(64425623556)
            static /*int? */ op_Explicit$14(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt32(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(64425623556)
            
            //--TRIMMABLE-BOUNDARY-START(103080329220)
            static /*uint */ op_Explicit$23(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToUInt32(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(103080329220)
            
            //--TRIMMABLE-BOUNDARY-START(81605492740)
            static /*uint? */ op_Explicit$18(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt32(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(81605492740)
            
            //--TRIMMABLE-BOUNDARY-START(34360852484)
            static /*long */ op_Explicit$7(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToInt64(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360852484)
            
            //--TRIMMABLE-BOUNDARY-START(68720590852)
            static /*long? */ op_Explicit$15(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt64(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(68720590852)
            
            //--TRIMMABLE-BOUNDARY-START(107375296516)
            static /*ulong */ op_Explicit$24(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToUInt64(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(107375296516)
            
            //--TRIMMABLE-BOUNDARY-START(85900460036)
            static /*ulong? */ op_Explicit$19(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt64(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(85900460036)
            
            //--TRIMMABLE-BOUNDARY-START(90195427332)
            static /*float */ op_Explicit$20(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToSingle(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(90195427332)
            
            //--TRIMMABLE-BOUNDARY-START(73015558148)
            static /*float? */ op_Explicit$16(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToSingle(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(73015558148)
            
            //--TRIMMABLE-BOUNDARY-START(21475950596)
            static /*double */ op_Explicit$4(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToDouble(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475950596)
            
            //--TRIMMABLE-BOUNDARY-START(55835688964)
            static /*double? */ op_Explicit$12(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDouble(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(55835688964)
            
            //--TRIMMABLE-BOUNDARY-START(17180983300)
            static /*decimal */ op_Explicit$3(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToDecimal(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(17180983300)
            
            //--TRIMMABLE-BOUNDARY-START(51540721668)
            static /*decimal? */ op_Explicit$11(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDecimal(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(51540721668)
            
            //--TRIMMABLE-BOUNDARY-START(8591048708)
            static /*DateTime */ op_Explicit$1(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$$.System.DateTime.Parse$2(attribute.value, $.$$.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            //--TRIMMABLE-BOUNDARY-END(8591048708)
            
            //--TRIMMABLE-BOUNDARY-START(42950787076)
            static /*DateTime? */ op_Explicit$9(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$$.System.DateTime.Parse$2(attribute.value, $.$$.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            //--TRIMMABLE-BOUNDARY-END(42950787076)
            
            //--TRIMMABLE-BOUNDARY-START(12886016004)
            static /*DateTimeOffset */ op_Explicit$2(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset$2(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(12886016004)
            
            //--TRIMMABLE-BOUNDARY-START(47245754372)
            static /*DateTimeOffset? */ op_Explicit$10(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset$2(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(47245754372)
            
            //--TRIMMABLE-BOUNDARY-START(98785361924)
            static /*TimeSpan */ op_Explicit$22(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(98785361924)
            
            //--TRIMMABLE-BOUNDARY-START(77310525444)
            static /*TimeSpan? */ op_Explicit$17(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(77310525444)
            
            //--TRIMMABLE-BOUNDARY-START(25770917892)
            static /*Guid */ op_Explicit$5(/*XAttribute*/ attribute)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToGuid(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(25770917892)
            
            //--TRIMMABLE-BOUNDARY-START(60130656260)
            static /*Guid? */ op_Explicit$13(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToGuid(attribute.value);
            }
            //--TRIMMABLE-BOUNDARY-END(60130656260)
            
            //--TRIMMABLE-BOUNDARY-START(184684707844)
            /*int */ GetDeepHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684707844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XName.GetHashCode.call(this.name) ^ $.$$.System.String.GetHashCode.call(this.value);
            }
            //--TRIMMABLE-BOUNDARY-END(184684707844)
            
            //--TRIMMABLE-BOUNDARY-START(188979675140)
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979675140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let namespaceName = ns.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$$.System.String.Empty;
                }
                if (this.parent !== null)
                {
                    return ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).GetPrefixOfNamespace(ns);
                }
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    return "xml";
                }
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(188979675140)
            
            //--TRIMMABLE-BOUNDARY-START(244814249988)
            static /*void */ ValidateAttribute(/*XName*/ name, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814249988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let namespaceName = name.NamespaceName;
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    if (value.length === 0)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_NamespaceDeclarationPrefixed, name.LocalName));
                    }
                    else if ($.$$.System.String.op_Equality(value, "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/))
                    {
                        if ($.$$.System.String.op_Inequality(name.LocalName, "xml"))
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_NamespaceDeclarationXml);
                        }
                    }
                    else if ($.$$.System.String.op_Equality(value, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_NamespaceDeclarationXmlns);
                    }
                    else 
                    {
                        /*string*/ let localName = name.LocalName;
                        if ($.$$.System.String.op_Equality(localName, "xml"))
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_NamespaceDeclarationXml);
                        }
                        else if ($.$$.System.String.op_Equality(localName, "xmlns"))
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_NamespaceDeclarationXmlns);
                        }
                    }
                }
                else if (namespaceName.length === 0 && $.$$.System.String.op_Equality(name.LocalName, "xmlns"))
                {
                    if ($.$$.System.String.op_Equality(value, "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_NamespaceDeclarationXml);
                    }
                    else if ($.$$.System.String.op_Equality(value, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_NamespaceDeclarationXmlns);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244814249988)
            
            static $h = 1114116;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2555908,
  "p": [
//--TRIMMABLE-BOUNDARY-START(120260198404),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850132996,
        "f": 50331681
      },
      "n": "EmptySequence",
      "d": 1114116,
      "h": 120260198404,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(120260198404),
//--TRIMMABLE-BOUNDARY-START(193274642436),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440067588,
        "f": 50331649
      },
      "n": "IsNamespaceDeclaration",
      "d": 1114116,
      "h": 193274642436,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274642436),
//--TRIMMABLE-BOUNDARY-START(201864577028),
    {
      "p": 2097156,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030002180,
        "f": 50331649
      },
      "n": "Name",
      "d": 1114116,
      "h": 201864577028,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864577028),
//--TRIMMABLE-BOUNDARY-START(210454511620),
    {
      "p": 1114116,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619936772,
        "f": 50331649
      },
      "n": "NextAttribute",
      "d": 1114116,
      "h": 210454511620,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210454511620),
//--TRIMMABLE-BOUNDARY-START(214749478916),
    {
      "p": 52822019,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209871364,
        "f": 50364417
      },
      "n": "NodeType",
      "d": 1114116,
      "h": 214749478916,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(214749478916),
//--TRIMMABLE-BOUNDARY-START(219044446212),
    {
      "p": 1114116,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799805956,
        "f": 50331649
      },
      "n": "PreviousAttribute",
      "d": 1114116,
      "h": 219044446212,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219044446212),
//--TRIMMABLE-BOUNDARY-START(253404184580),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389740548,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231929348100,
        "f": 83886081
      },
      "n": "Value",
      "d": 1114116,
      "h": 253404184580,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253404184580)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(223339413508),
    {
      "r": 65537,
      "n": "Remove",
      "d": 1114116,
      "h": 223339413508,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223339413508),
//--TRIMMABLE-BOUNDARY-START(236224315396),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetValue",
      "d": 1114116,
      "h": 236224315396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(236224315396),
//--TRIMMABLE-BOUNDARY-START(240519282692),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1114116,
      "h": 240519282692,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(240519282692),
//--TRIMMABLE-BOUNDARY-START(184684707844),
    {
      "r": 655361,
      "n": "GetDeepHashCode",
      "d": 1114116,
      "h": 184684707844,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(184684707844),
//--TRIMMABLE-BOUNDARY-START(188979675140),
    {
      "r": 1310721,
      "p": [
        {
          "n": "ns",
          "p": 2162692
        }
      ],
      "n": "GetPrefixOfNamespace",
      "d": 1114116,
      "h": 188979675140,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(188979675140),
//--TRIMMABLE-BOUNDARY-START(244814249988),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 2097156
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "ValidateAttribute",
      "d": 1114116,
      "h": 244814249988,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(244814249988)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(206159544324),
    {
      "t": 1114116,
      "n": "next",
      "d": 1114116,
      "h": 206159544324,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(206159544324),
//--TRIMMABLE-BOUNDARY-START(197569609732),
    {
      "t": 2097156,
      "n": "name",
      "d": 1114116,
      "h": 197569609732,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(197569609732),
//--TRIMMABLE-BOUNDARY-START(249109217284),
    {
      "t": 1310721,
      "n": "value",
      "d": 1114116,
      "h": 249109217284,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(249109217284)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(115965231108),
    {
      "p": [
        {
          "n": "name",
          "p": 2097156
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1114116,
      "h": 115965231108,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115965231108),
//--TRIMMABLE-BOUNDARY-START(111670263812),
    {
      "p": [
        {
          "n": "other",
          "p": 1114116
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114116,
      "h": 111670263812,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670263812)
  ],
  "i": [13893635
  ],
  "h": 1114116,
  "a": [
    {
      "t": 1638418,
      "c": 8591573010,
      "a": [
        {
          "v": "MS.Internal.Xml.Linq.ComponentModel.XTypeDescriptionProvider\u00601[[System.Xml.Linq.XAttribute, System.Xml.Linq, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]],System.ComponentModel.TypeConverter",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XObject; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114116)
        
        
        //--TRIMMABLE-BOUNDARY-START(2293764)
        $asm.$cls("$spxl.System.Xml.Linq.XNodeBuilder", ($self) => class XNodeBuilder extends $.$spx.System.Xml.XmlWriter
        {
            //--TRIMMABLE-BOUNDARY-START(12887195652)
            /*List<object>?*/ _content = null;
            //--TRIMMABLE-BOUNDARY-END(12887195652)
            
            //--TRIMMABLE-BOUNDARY-START(17182162948)
            /*XContainer?*/ _parent = null;
            //--TRIMMABLE-BOUNDARY-END(17182162948)
            
            //--TRIMMABLE-BOUNDARY-START(4297261060)
            /*XName?*/ _attrName = null;
            //--TRIMMABLE-BOUNDARY-END(4297261060)
            
            //--TRIMMABLE-BOUNDARY-START(8592228356)
            /*string?*/ _attrValue = null;
            //--TRIMMABLE-BOUNDARY-END(8592228356)
            
            //--TRIMMABLE-BOUNDARY-START(21477130244)
            /*XContainer*/ _root = null;
            //--TRIMMABLE-BOUNDARY-END(21477130244)
            
            //--TRIMMABLE-BOUNDARY-START(25772097540)
            $ctor$2(/*XContainer*/ container)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772097540);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._root = container;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772097540)
            
            //--TRIMMABLE-BOUNDARY-START(77311705092)
            /*XmlWriterSettings */ get Settings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131835908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlWriterSettings*/ let settings = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                settings.ConformanceLevel = 0/*ConformanceLevel.Auto*/;
                return settings;
            }
            //--TRIMMABLE-BOUNDARY-END(77311705092)
            
            //--TRIMMABLE-BOUNDARY-START(158916083716)
            /*WriteState */ get WriteState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721770500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(158916083716)
            
            //--TRIMMABLE-BOUNDARY-START(47246934020)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246934020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (disposing)
                {
                    this.Close();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246934020)
            
            //--TRIMMABLE-BOUNDARY-START(42951966724)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951966724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._root.Add(this._content);
            }
            //--TRIMMABLE-BOUNDARY-END(42951966724)
            
            //--TRIMMABLE-BOUNDARY-START(51541901316)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541901316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51541901316)
            
            //--TRIMMABLE-BOUNDARY-START(73016737796)
            /*string */ LookupPrefix(/*string*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016737796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(73016737796)
            
            //--TRIMMABLE-BOUNDARY-START(81606672388)
            /*void */ WriteBase64(/*byte[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606672388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$12($.$spxl.System.SR.NotSupported_WriteBase64);
            }
            //--TRIMMABLE-BOUNDARY-END(81606672388)
            
            //--TRIMMABLE-BOUNDARY-START(85901639684)
            /*void */ WriteCData(/*string?*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901639684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddNode(new $.$spxl.System.Xml.Linq.XCData().$ctor$6(text));
            }
            //--TRIMMABLE-BOUNDARY-END(85901639684)
            
            //--TRIMMABLE-BOUNDARY-START(90196606980)
            /*void */ WriteCharEntity(/*char*/ ch)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196606980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddString($.$$.System.Char.ToString$1(ch));
            }
            //--TRIMMABLE-BOUNDARY-END(90196606980)
            
            //--TRIMMABLE-BOUNDARY-START(94491574276)
            /*void */ WriteChars(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491574276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddString($.$$.System.String.Create$1(buffer, index, count));
            }
            //--TRIMMABLE-BOUNDARY-END(94491574276)
            
            //--TRIMMABLE-BOUNDARY-START(98786541572)
            /*void */ WriteComment(/*string?*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786541572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddNode(new $.$spxl.System.Xml.Linq.XComment().$ctor$3(text));
            }
            //--TRIMMABLE-BOUNDARY-END(98786541572)
            
            //--TRIMMABLE-BOUNDARY-START(103081508868)
            /*void */ WriteDocType(/*string*/ name, /*string?*/ pubid, /*string?*/ sysid, /*string?*/ subset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081508868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddNode(new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(name, pubid, sysid, subset));
            }
            //--TRIMMABLE-BOUNDARY-END(103081508868)
            
            //--TRIMMABLE-BOUNDARY-START(107376476164)
            /*void */ WriteEndAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376476164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(this._attrName, this._attrValue);
                this._attrName = null;
                this._attrValue = null;
                if (this._parent !== null)
                {
                    this._parent.Add(a);
                }
                else 
                {
                    this.Add(a);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107376476164)
            
            //--TRIMMABLE-BOUNDARY-START(111671443460)
            /*void */ WriteEndDocument()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671443460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(111671443460)
            
            //--TRIMMABLE-BOUNDARY-START(115966410756)
            /*void */ WriteEndElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966410756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._parent = ($.$cast(this._parent, $.$spxl.System.Xml.Linq.XElement)).parent;
            }
            //--TRIMMABLE-BOUNDARY-END(115966410756)
            
            //--TRIMMABLE-BOUNDARY-START(120261378052)
            /*void */ WriteEntityRef(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261378052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(name)
                {
                    case "amp":
                    this.AddString("&");
                    break;
                    case "apos":
                    this.AddString("'");
                    break;
                    case "gt":
                    this.AddString(">");
                    break;
                    case "lt":
                    this.AddString("<");
                    break;
                    case "quot":
                    this.AddString("\"");
                    break;
                    default:
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$spxl.System.SR.NotSupported_WriteEntityRef);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120261378052)
            
            //--TRIMMABLE-BOUNDARY-START(124556345348)
            /*void */ WriteFullEndElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556345348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement*/ let e = $.$cast(this._parent, $.$spxl.System.Xml.Linq.XElement);
                if (e.IsEmpty)
                {
                    e.Add($.$$.System.String.Empty);
                }
                this._parent = e.parent;
            }
            //--TRIMMABLE-BOUNDARY-END(124556345348)
            
            //--TRIMMABLE-BOUNDARY-START(128851312644)
            /*void */ WriteProcessingInstruction(/*string*/ name, /*string?*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851312644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(name, "xml"))
                {
                    return;
                }
                this.AddNode(new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(name, text));
            }
            //--TRIMMABLE-BOUNDARY-END(128851312644)
            
            //--TRIMMABLE-BOUNDARY-START(133146279940)
            /*void */ WriteRaw(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146279940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddString($.$$.System.String.Create$1(buffer, index, count));
            }
            //--TRIMMABLE-BOUNDARY-END(133146279940)
            
            //--TRIMMABLE-BOUNDARY-START(137441247236)
            /*void */ WriteRaw$1(/*string*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441247236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddString(data);
            }
            //--TRIMMABLE-BOUNDARY-END(137441247236)
            
            //--TRIMMABLE-BOUNDARY-START(141736214532)
            /*void */ WriteStartAttribute(/*string?*/ prefix, /*string*/ localName, /*string?*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736214532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(prefix, "prefix");
                this._attrName = $.$spxl.System.Xml.Linq.XNamespace.Get$1(prefix.length === 0 ? $.$$.System.String.Empty : namespaceName).GetName$1(localName);
                this._attrValue = $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(141736214532)
            
            //--TRIMMABLE-BOUNDARY-START(146031181828)
            /*void */ WriteStartDocument()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031181828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(146031181828)
            
            //--TRIMMABLE-BOUNDARY-START(150326149124)
            /*void */ WriteStartDocument$1(/*bool*/ standalone)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326149124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(150326149124)
            
            //--TRIMMABLE-BOUNDARY-START(154621116420)
            /*void */ WriteStartElement(/*string?*/ prefix, /*string*/ localName, /*string?*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621116420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$12($.$spxl.System.Xml.Linq.XNamespace.Get$1(namespaceName).GetName$1(localName)));
            }
            //--TRIMMABLE-BOUNDARY-END(154621116420)
            
            //--TRIMMABLE-BOUNDARY-START(163211051012)
            /*void */ WriteString(/*string?*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211051012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddString(text);
            }
            //--TRIMMABLE-BOUNDARY-END(163211051012)
            
            //--TRIMMABLE-BOUNDARY-START(167506018308)
            /*void */ WriteSurrogateCharEntity(/*char*/ lowCh, /*char*/ highCh)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167506018308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddString($.$$.System.String.Create$2($.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [highCh, lowCh], null, null))));
            }
            //--TRIMMABLE-BOUNDARY-END(167506018308)
            
            //--TRIMMABLE-BOUNDARY-START(171800985604)
            /*void */ WriteValue$2(/*DateTimeOffset*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800985604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteString($.$spx.System.Xml.XmlConvert.ToString$8(value));
            }
            //--TRIMMABLE-BOUNDARY-END(171800985604)
            
            //--TRIMMABLE-BOUNDARY-START(176095952900)
            /*void */ WriteWhitespace(/*string?*/ ws)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095952900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddString(ws);
            }
            //--TRIMMABLE-BOUNDARY-END(176095952900)
            
            //--TRIMMABLE-BOUNDARY-START(30067064836)
            /*void */ Add(/*object*/ o)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067064836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._content ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                this._content.Add(o);
            }
            //--TRIMMABLE-BOUNDARY-END(30067064836)
            
            //--TRIMMABLE-BOUNDARY-START(34362032132)
            /*void */ AddNode(/*XNode*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362032132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._parent !== null)
                {
                    this._parent.Add(n);
                }
                else 
                {
                    this.Add(n);
                }
                /*XContainer?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XContainer);
                if (c !== null)
                {
                    this._parent = c;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34362032132)
            
            //--TRIMMABLE-BOUNDARY-START(38656999428)
            /*void */ AddString(/*string?*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656999428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                if ($.$$.System.String.op_Inequality(this._attrValue, null))
                {
                    this._attrValue += s;
                }
                else if (this._parent !== null)
                {
                    this._parent.Add(s);
                }
                else 
                {
                    this.Add(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656999428)
            
            static $h = 2293764;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 58392579,
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311705092),
    {
      "p": 58458115,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131835908,
        "f": 50364417
      },
      "n": "Settings",
      "d": 2293764,
      "h": 77311705092,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77311705092),
//--TRIMMABLE-BOUNDARY-START(158916083716),
    {
      "p": 48562179,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721770500,
        "f": 50364417
      },
      "n": "WriteState",
      "d": 2293764,
      "h": 158916083716,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158916083716)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246934020),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 2293764,
      "h": 47246934020,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47246934020),
//--TRIMMABLE-BOUNDARY-START(42951966724),
    {
      "r": 65537,
      "n": "Close",
      "d": 2293764,
      "h": 42951966724,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951966724),
//--TRIMMABLE-BOUNDARY-START(51541901316),
    {
      "r": 65537,
      "n": "Flush",
      "d": 2293764,
      "h": 51541901316,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541901316),
//--TRIMMABLE-BOUNDARY-START(73016737796),
    {
      "r": 1310721,
      "p": [
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "LookupPrefix",
      "d": 2293764,
      "h": 73016737796,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73016737796),
//--TRIMMABLE-BOUNDARY-START(81606672388),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "WriteBase64",
      "d": 2293764,
      "h": 81606672388,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81606672388),
//--TRIMMABLE-BOUNDARY-START(85901639684),
    {
      "r": 65537,
      "p": [
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "WriteCData",
      "d": 2293764,
      "h": 85901639684,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901639684),
//--TRIMMABLE-BOUNDARY-START(90196606980),
    {
      "r": 65537,
      "p": [
        {
          "n": "ch",
          "p": 458753
        }
      ],
      "n": "WriteCharEntity",
      "d": 2293764,
      "h": 90196606980,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90196606980),
//--TRIMMABLE-BOUNDARY-START(94491574276),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "WriteChars",
      "d": 2293764,
      "h": 94491574276,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94491574276),
//--TRIMMABLE-BOUNDARY-START(98786541572),
    {
      "r": 65537,
      "p": [
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "WriteComment",
      "d": 2293764,
      "h": 98786541572,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98786541572),
//--TRIMMABLE-BOUNDARY-START(103081508868),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "pubid",
          "p": 1310721
        },
        {
          "n": "sysid",
          "p": 1310721
        },
        {
          "n": "subset",
          "p": 1310721
        }
      ],
      "n": "WriteDocType",
      "d": 2293764,
      "h": 103081508868,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103081508868),
//--TRIMMABLE-BOUNDARY-START(107376476164),
    {
      "r": 65537,
      "n": "WriteEndAttribute",
      "d": 2293764,
      "h": 107376476164,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107376476164),
//--TRIMMABLE-BOUNDARY-START(111671443460),
    {
      "r": 65537,
      "n": "WriteEndDocument",
      "d": 2293764,
      "h": 111671443460,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111671443460),
//--TRIMMABLE-BOUNDARY-START(115966410756),
    {
      "r": 65537,
      "n": "WriteEndElement",
      "d": 2293764,
      "h": 115966410756,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115966410756),
//--TRIMMABLE-BOUNDARY-START(120261378052),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "WriteEntityRef",
      "d": 2293764,
      "h": 120261378052,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120261378052),
//--TRIMMABLE-BOUNDARY-START(124556345348),
    {
      "r": 65537,
      "n": "WriteFullEndElement",
      "d": 2293764,
      "h": 124556345348,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124556345348),
//--TRIMMABLE-BOUNDARY-START(128851312644),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "WriteProcessingInstruction",
      "d": 2293764,
      "h": 128851312644,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128851312644),
//--TRIMMABLE-BOUNDARY-START(133146279940),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "WriteRaw",
      "d": 2293764,
      "h": 133146279940,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133146279940),
//--TRIMMABLE-BOUNDARY-START(137441247236),
    {
      "r": 65537,
      "p": [
        {
          "n": "data",
          "p": 1310721
        }
      ],
      "n": "WriteRaw",
      "o": "@$1",
      "d": 2293764,
      "h": 137441247236,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(137441247236),
//--TRIMMABLE-BOUNDARY-START(141736214532),
    {
      "r": 65537,
      "p": [
        {
          "n": "prefix",
          "p": 1310721
        },
        {
          "n": "localName",
          "p": 1310721
        },
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "WriteStartAttribute",
      "d": 2293764,
      "h": 141736214532,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(141736214532),
//--TRIMMABLE-BOUNDARY-START(146031181828),
    {
      "r": 65537,
      "n": "WriteStartDocument",
      "d": 2293764,
      "h": 146031181828,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146031181828),
//--TRIMMABLE-BOUNDARY-START(150326149124),
    {
      "r": 65537,
      "p": [
        {
          "n": "standalone",
          "p": 262145
        }
      ],
      "n": "WriteStartDocument",
      "o": "@$1",
      "d": 2293764,
      "h": 150326149124,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150326149124),
//--TRIMMABLE-BOUNDARY-START(154621116420),
    {
      "r": 65537,
      "p": [
        {
          "n": "prefix",
          "p": 1310721
        },
        {
          "n": "localName",
          "p": 1310721
        },
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "WriteStartElement",
      "d": 2293764,
      "h": 154621116420,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154621116420),
//--TRIMMABLE-BOUNDARY-START(163211051012),
    {
      "r": 65537,
      "p": [
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "WriteString",
      "d": 2293764,
      "h": 163211051012,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163211051012),
//--TRIMMABLE-BOUNDARY-START(167506018308),
    {
      "r": 65537,
      "p": [
        {
          "n": "lowCh",
          "p": 458753
        },
        {
          "n": "highCh",
          "p": 458753
        }
      ],
      "n": "WriteSurrogateCharEntity",
      "d": 2293764,
      "h": 167506018308,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(167506018308),
//--TRIMMABLE-BOUNDARY-START(171800985604),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 65470465
        }
      ],
      "n": "WriteValue",
      "o": "@$2",
      "d": 2293764,
      "h": 171800985604,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171800985604),
//--TRIMMABLE-BOUNDARY-START(176095952900),
    {
      "r": 65537,
      "p": [
        {
          "n": "ws",
          "p": 1310721
        }
      ],
      "n": "WriteWhitespace",
      "d": 2293764,
      "h": 176095952900,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176095952900),
//--TRIMMABLE-BOUNDARY-START(30067064836),
    {
      "r": 65537,
      "p": [
        {
          "n": "o",
          "p": 131073
        }
      ],
      "n": "Add",
      "d": 2293764,
      "h": 30067064836,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30067064836),
//--TRIMMABLE-BOUNDARY-START(34362032132),
    {
      "r": 65537,
      "p": [
        {
          "n": "n",
          "p": 2228228
        }
      ],
      "n": "AddNode",
      "d": 2293764,
      "h": 34362032132,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34362032132),
//--TRIMMABLE-BOUNDARY-START(38656999428),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "AddString",
      "d": 2293764,
      "h": 38656999428,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38656999428)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887195652),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.Object).$h,
      "n": "_content",
      "d": 2293764,
      "h": 12887195652,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887195652),
//--TRIMMABLE-BOUNDARY-START(17182162948),
    {
      "t": 1310724,
      "n": "_parent",
      "d": 2293764,
      "h": 17182162948,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182162948),
//--TRIMMABLE-BOUNDARY-START(4297261060),
    {
      "t": 2097156,
      "n": "_attrName",
      "d": 2293764,
      "h": 4297261060,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297261060),
//--TRIMMABLE-BOUNDARY-START(8592228356),
    {
      "t": 1310721,
      "n": "_attrValue",
      "d": 2293764,
      "h": 8592228356,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592228356),
//--TRIMMABLE-BOUNDARY-START(21477130244),
    {
      "t": 1310724,
      "n": "_root",
      "d": 2293764,
      "h": 21477130244,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477130244)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772097540),
    {
      "p": [
        {
          "n": "container",
          "p": 1310724
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2293764,
      "h": 25772097540,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772097540)
  ],
  "i": [90308609,89718785
  ],
  "h": 2293764
}; }
            static get $b() { return $.$spx.System.Xml.XmlWriter; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293764)
        
        
        //--TRIMMABLE-BOUNDARY-START(2490372)
        $asm.$cls("$spxl.System.Xml.Linq.XNodeReader", ($self) => class XNodeReader extends $.$spx.System.Xml.XmlReader
        {
            //--TRIMMABLE-BOUNDARY-START(21477326852)
            /*object*/ _source = null;
            //--TRIMMABLE-BOUNDARY-END(21477326852)
            
            //--TRIMMABLE-BOUNDARY-START(12887392260)
            /*object?*/ _parent = null;
            //--TRIMMABLE-BOUNDARY-END(12887392260)
            
            //--TRIMMABLE-BOUNDARY-START(25772294148)
            /*ReadState*/ _state = 0;
            //--TRIMMABLE-BOUNDARY-END(25772294148)
            
            //--TRIMMABLE-BOUNDARY-START(17182359556)
            /*XNode*/ _root = null;
            //--TRIMMABLE-BOUNDARY-END(17182359556)
            
            //--TRIMMABLE-BOUNDARY-START(4297457668)
            /*XmlNameTable*/ _nameTable = null;
            //--TRIMMABLE-BOUNDARY-END(4297457668)
            
            //--TRIMMABLE-BOUNDARY-START(8592424964)
            /*bool*/ _omitDuplicateNamespaces = false;
            //--TRIMMABLE-BOUNDARY-END(8592424964)
            
            //--TRIMMABLE-BOUNDARY-START(30067261444)
            $ctor$2(/*XNode*/ node, /*XmlNameTable?*/ nameTable, /*ReaderOptions*/ options)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067261444);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._source = node;
                    this._root = node;
                    this._nameTable = nameTable ?? $.$spxl.System.Xml.Linq.XNodeReader.CreateNameTable();
                    this._omitDuplicateNamespaces = (options & 1/*ReaderOptions.OmitDuplicateNamespaces*/) !== 0 ? true : false;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30067261444)
            
            //--TRIMMABLE-BOUNDARY-START(34362228740)
            $ctor$3(/*XNode*/ node, /*XmlNameTable?*/ nameTable)
            {
                this.$ctor$2(node, nameTable, (node.GetSaveOptionsFromAnnotations() & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0 ? 1/*ReaderOptions.OmitDuplicateNamespaces*/ : 0/*ReaderOptions.None*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362228740);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34362228740)
            
            //--TRIMMABLE-BOUNDARY-START(38657196036)
            /*int */ get AttributeCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016934404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return 0;
                }
                /*int*/ let count = 0;
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (!this._omitDuplicateNamespaces || !this.IsDuplicateNamespaceAttribute(a))
                            {
                                count++;
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return count;
            }
            //--TRIMMABLE-BOUNDARY-END(38657196036)
            
            //--TRIMMABLE-BOUNDARY-START(42952163332)
            /*string */ get BaseURI()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606868996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return o.BaseUri;
                }
                o = $.$as(this._parent, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return o.BaseUri;
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(42952163332)
            
            //--TRIMMABLE-BOUNDARY-START(55837065220)
            /*int */ get Depth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196803588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return 0;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return $.$spxl.System.Xml.Linq.XNodeReader.GetDepth(o);
                }
                o = $.$as(this._parent, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return (($.$spxl.System.Xml.Linq.XNodeReader.GetDepth(o) + 1) | 0);
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(55837065220)
            
            //--TRIMMABLE-BOUNDARY-START(253405560836)
            static /*int */ GetDepth(/*XObject*/ o)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405560836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let depth = 0;
                while(o.parent !== null)
                {
                    depth++;
                    o = o.parent;
                }
                if ($.$is(o, $.$spxl.System.Xml.Linq.XDocument))
                {
                    depth--;
                }
                return depth;
            }
            //--TRIMMABLE-BOUNDARY-END(253405560836)
            
            //--TRIMMABLE-BOUNDARY-START(64426999812)
            /*bool */ get EOF()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786738180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._state === 3/*ReadState.EndOfFile*/;
            }
            //--TRIMMABLE-BOUNDARY-END(64426999812)
            
            //--TRIMMABLE-BOUNDARY-START(287765299204)
            /*bool */ get HasAttributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376672772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null && e.lastAttr !== null)
                {
                    if (this._omitDuplicateNamespaces)
                    {
                        return this.GetFirstNonDuplicateNamespaceAttribute(e.lastAttr.next) !== null;
                    }
                    else 
                    {
                        return true;
                    }
                }
                else 
                {
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(287765299204)
            
            //--TRIMMABLE-BOUNDARY-START(292060266500)
            /*bool */ get HasValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966607364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    let $switch1 = o.NodeType;
                    switch($switch1)
                    {
                        case 2/*XmlNodeType.Attribute*/:
                        case 3/*XmlNodeType.Text*/:
                        case 4/*XmlNodeType.CDATA*/:
                        case 8/*XmlNodeType.Comment*/:
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        case 10/*XmlNodeType.DocumentType*/:
                        return true;
                        default:
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(292060266500)
            
            //--TRIMMABLE-BOUNDARY-START(304945168388)
            /*bool */ get IsEmptyElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556541956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                return e !== null && e.IsEmpty;
            }
            //--TRIMMABLE-BOUNDARY-END(304945168388)
            
            //--TRIMMABLE-BOUNDARY-START(317830070276)
            /*string */ get LocalName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326345732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._nameTable.Add$1(this.GetLocalName());
            }
            //--TRIMMABLE-BOUNDARY-END(317830070276)
            
            //--TRIMMABLE-BOUNDARY-START(270585430020)
            /*string */ GetLocalName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270585430020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return $.$$.System.String.Empty;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.LocalName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return a.Name.LocalName;
                }
                /*XProcessingInstruction?*/ let p = $.$as(this._source, $.$spxl.System.Xml.Linq.XProcessingInstruction);
                if (p !== null)
                {
                    return p.Target;
                }
                /*XDocumentType?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XDocumentType);
                if (n !== null)
                {
                    return n.Name;
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(270585430020)
            
            //--TRIMMABLE-BOUNDARY-START(352189808644)
            /*string */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158916280324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let prefix = this.GetPrefix();
                if (prefix.length === 0)
                {
                    return this._nameTable.Add$1(this.GetLocalName());
                }
                return this._nameTable.Add$1($.$$.System.String.Concat$12(prefix, ":", this.GetLocalName()));
            }
            //--TRIMMABLE-BOUNDARY-END(352189808644)
            
            //--TRIMMABLE-BOUNDARY-START(356484775940)
            /*string */ get NamespaceURI()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167506214916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._nameTable.Add$1(this.GetNamespaceURI());
            }
            //--TRIMMABLE-BOUNDARY-END(356484775940)
            
            //--TRIMMABLE-BOUNDARY-START(279175364612)
            /*string */ GetNamespaceURI()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279175364612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return $.$$.System.String.Empty;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.NamespaceName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    /*string*/ let namespaceName = a.Name.NamespaceName;
                    if (namespaceName.length === 0 && $.$$.System.String.op_Equality(a.Name.LocalName, "xmlns"))
                    {
                        return "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/;
                    }
                    return namespaceName;
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(279175364612)
            
            //--TRIMMABLE-BOUNDARY-START(360779743236)
            /*XmlNameTable */ get NameTable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096149508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._nameTable;
            }
            //--TRIMMABLE-BOUNDARY-END(360779743236)
            
            //--TRIMMABLE-BOUNDARY-START(365074710532)
            /*XmlNodeType */ get NodeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184686084100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return 0/*XmlNodeType.None*/;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    if (this.IsEndElement)
                    {
                        return 15/*XmlNodeType.EndElement*/;
                    }
                    /*XmlNodeType*/ let nt = o.NodeType;
                    if (nt !== 3/*XmlNodeType.Text*/)
                    {
                        return nt;
                    }
                    if (o.parent !== null && o.parent.parent === null && $.$is(o.parent, $.$spxl.System.Xml.Linq.XDocument))
                    {
                        return 13/*XmlNodeType.Whitespace*/;
                    }
                    return 3/*XmlNodeType.Text*/;
                }
                if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XDocument))
                {
                    return 13/*XmlNodeType.Whitespace*/;
                }
                return 3/*XmlNodeType.Text*/;
            }
            //--TRIMMABLE-BOUNDARY-END(365074710532)
            
            //--TRIMMABLE-BOUNDARY-START(369369677828)
            /*string */ get Prefix()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193276018692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._nameTable.Add$1(this.GetPrefix());
            }
            //--TRIMMABLE-BOUNDARY-END(369369677828)
            
            //--TRIMMABLE-BOUNDARY-START(283470331908)
            /*string */ GetPrefix()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283470331908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return $.$$.System.String.Empty;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    /*string?*/ let prefix = e.GetPrefixOfNamespace(e.Name.Namespace);
                    if ($.$$.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                    return $.$$.System.String.Empty;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    /*string?*/ let prefix = a.GetPrefixOfNamespace(a.Name.Namespace);
                    if ($.$$.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(283470331908)
            
            //--TRIMMABLE-BOUNDARY-START(412319350788)
            /*ReadState */ get ReadState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865953284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._state;
            }
            //--TRIMMABLE-BOUNDARY-END(412319350788)
            
            //--TRIMMABLE-BOUNDARY-START(446679089156)
            /*XmlReaderSettings */ get Settings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455887876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlReaderSettings*/ let settings = new $.$spx.System.Xml.XmlReaderSettings().$ctor$1();
                settings.CheckCharacters = false;
                return settings;
            }
            //--TRIMMABLE-BOUNDARY-END(446679089156)
            
            //--TRIMMABLE-BOUNDARY-START(485333794820)
            /*string */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045822468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return $.$$.System.String.Empty;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    let $switch1 = o.NodeType;
                    switch($switch1)
                    {
                        case 2/*XmlNodeType.Attribute*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XAttribute)).Value;
                        case 3/*XmlNodeType.Text*/:
                        case 4/*XmlNodeType.CDATA*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XText)).Value;
                        case 8/*XmlNodeType.Comment*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XComment)).Value;
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XProcessingInstruction)).Data;
                        case 10/*XmlNodeType.DocumentType*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XDocumentType)).InternalSubset ?? $.$$.System.String.Empty;
                        default:
                        return $.$$.System.String.Empty;
                    }
                }
                return $.$cast(this._source, $.$$.System.String);
            }
            //--TRIMMABLE-BOUNDARY-END(485333794820)
            
            //--TRIMMABLE-BOUNDARY-START(489628762116)
            /*string */ get XmlLang()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635757060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return $.$$.System.String.Empty;
                }
                /*XElement?*/ let e = this.GetElementInScope();
                if (e !== null)
                {
                    /*XName*/ let name = $.$spxl.System.Xml.Linq.XNamespace.Xml.GetName$1("lang");
                    do
                    {
                        /*XAttribute?*/ let a = e.Attribute(name);
                        if (a !== null)
                        {
                            return a.Value;
                        }
                        e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    }
                    while(e !== null);
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(489628762116)
            
            //--TRIMMABLE-BOUNDARY-START(493923729412)
            /*XmlSpace */ get XmlSpace()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225691652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return 0/*XmlSpace.None*/;
                }
                /*XElement?*/ let e = this.GetElementInScope();
                if (e !== null)
                {
                    /*XName*/ let name = $.$spxl.System.Xml.Linq.XNamespace.Xml.GetName$1("space");
                    do
                    {
                        /*XAttribute?*/ let a = e.Attribute(name);
                        if (a !== null)
                        {
                            let $switch1 = $.$$.System.MemoryExtensions.Trim$3($.$$.System.MemoryExtensions.AsSpan$4(a.Value), $.$$.System.String.op_Implicit(" \t\n\r"));
                            switch($switch1)
                            {
                                case "preserve":
                                return 2/*XmlSpace.Preserve*/;
                                case $.$default():
                                return 1/*XmlSpace.Default*/;
                                default:
                                break;
                            }
                        }
                        e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    }
                    while(e !== null);
                }
                return 0/*XmlSpace.None*/;
            }
            //--TRIMMABLE-BOUNDARY-END(493923729412)
            
            //--TRIMMABLE-BOUNDARY-START(60132032516)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132032516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (disposing && this.ReadState !== 4/*ReadState.Closed*/)
                {
                    this.Close();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60132032516)
            
            //--TRIMMABLE-BOUNDARY-START(47247130628)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247130628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._source = null;
                this._parent = null;
                this._root = null;
                this._state = 4/*ReadState.Closed*/;
            }
            //--TRIMMABLE-BOUNDARY-END(47247130628)
            
            //--TRIMMABLE-BOUNDARY-START(249110593540)
            /*string? */ GetAttribute$2(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249110593540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return null;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*string?*/ let localName, namespaceName;
                    $.$spxl.System.Xml.Linq.XNodeReader.GetNameInAttributeScope(name, e, $.$ref(() => localName, ($v) => localName = $v, $.$$.System.String), $.$ref(() => namespaceName, ($v) => namespaceName = $v, $.$$.System.String));
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$$.System.String.op_Equality(a.Name.LocalName, localName) && $.$$.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return null;
                                }
                                else 
                                {
                                    return a.Value;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                    return null;
                }
                /*XDocumentType?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XDocumentType);
                if (n !== null)
                {
                    switch(name)
                    {
                        case "PUBLIC":
                        return n.PublicId;
                        case "SYSTEM":
                        return n.SystemId;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(249110593540)
            
            //--TRIMMABLE-BOUNDARY-START(244815626244)
            /*string? */ GetAttribute$1(/*string*/ localName, /*string?*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815626244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return null;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    if ($.$$.System.String.op_Equality(localName, "xmlns"))
                    {
                        if ($.$$.System.String.op_Inequality(namespaceName, null) && namespaceName.length === 0)
                        {
                            return null;
                        }
                        if ($.$$.System.String.op_Equality(namespaceName, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                        {
                            namespaceName = $.$$.System.String.Empty;
                        }
                    }
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$$.System.String.op_Equality(a.Name.LocalName, localName) && $.$$.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return null;
                                }
                                else 
                                {
                                    return a.Value;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(244815626244)
            
            //--TRIMMABLE-BOUNDARY-START(240520658948)
            /*string */ GetAttribute(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240520658948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (!this._omitDuplicateNamespaces || !this.IsDuplicateNamespaceAttribute(a))
                            {
                                if (index-- === 0)
                                {
                                    return a.Value;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("index");
            }
            //--TRIMMABLE-BOUNDARY-END(240520658948)
            
            //--TRIMMABLE-BOUNDARY-START(322125037572)
            /*string? */ LookupNamespace(/*string*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322125037572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return null;
                }
                if ($.$$.System.String.op_Equality(prefix, null))
                {
                    return null;
                }
                /*XElement?*/ let e = this.GetElementInScope();
                if (e !== null)
                {
                    /*XNamespace?*/ let ns = prefix.length === 0 ? e.GetDefaultNamespace() : e.GetNamespaceOfPrefix(prefix);
                    if ($.$spxl.System.Xml.Linq.XNamespace.op_Inequality(ns, null))
                    {
                        return this._nameTable.Add$1(ns.NamespaceName);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(322125037572)
            
            //--TRIMMABLE-BOUNDARY-START(335009939460)
            /*bool */ MoveToAttribute$2(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335009939460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*string?*/ let localName, namespaceName;
                    $.$spxl.System.Xml.Linq.XNodeReader.GetNameInAttributeScope(name, e, $.$ref(() => localName, ($v) => localName = $v, $.$$.System.String), $.$ref(() => namespaceName, ($v) => namespaceName = $v, $.$$.System.String));
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$$.System.String.op_Equality(a.Name.LocalName, localName) && $.$$.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return false;
                                }
                                else 
                                {
                                    this._source = a;
                                    this._parent = null;
                                    return true;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(335009939460)
            
            //--TRIMMABLE-BOUNDARY-START(330714972164)
            /*bool */ MoveToAttribute$1(/*string*/ localName, /*string?*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714972164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    if ($.$$.System.String.op_Equality(localName, "xmlns"))
                    {
                        if ($.$$.System.String.op_Inequality(namespaceName, null) && namespaceName.length === 0)
                        {
                            return false;
                        }
                        if ($.$$.System.String.op_Equality(namespaceName, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                        {
                            namespaceName = $.$$.System.String.Empty;
                        }
                    }
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$$.System.String.op_Equality(a.Name.LocalName, localName) && $.$$.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return false;
                                }
                                else 
                                {
                                    this._source = a;
                                    this._parent = null;
                                    return true;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(330714972164)
            
            //--TRIMMABLE-BOUNDARY-START(326420004868)
            /*void */ MoveToAttribute(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326420004868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return;
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (!this._omitDuplicateNamespaces || !this.IsDuplicateNamespaceAttribute(a))
                            {
                                if (index-- === 0)
                                {
                                    this._source = a;
                                    this._parent = null;
                                    return;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("index");
            }
            //--TRIMMABLE-BOUNDARY-END(326420004868)
            
            //--TRIMMABLE-BOUNDARY-START(339304906756)
            /*bool */ MoveToElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339304906756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute) ?? $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (a.parent !== null)
                    {
                        this._source = a.parent;
                        this._parent = null;
                        return true;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(339304906756)
            
            //--TRIMMABLE-BOUNDARY-START(343599874052)
            /*bool */ MoveToFirstAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343599874052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    if (e.lastAttr !== null)
                    {
                        if (this._omitDuplicateNamespaces)
                        {
                            /*object?*/ let na = this.GetFirstNonDuplicateNamespaceAttribute(e.lastAttr.next);
                            if (na === null)
                            {
                                return false;
                            }
                            this._source = na;
                        }
                        else 
                        {
                            this._source = e.lastAttr.next;
                        }
                        return true;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(343599874052)
            
            //--TRIMMABLE-BOUNDARY-START(347894841348)
            /*bool */ MoveToNextAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347894841348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (this.IsEndElement)
                    {
                        return false;
                    }
                    if (e.lastAttr !== null)
                    {
                        if (this._omitDuplicateNamespaces)
                        {
                            /*object?*/ let na = this.GetFirstNonDuplicateNamespaceAttribute(e.lastAttr.next);
                            if (na === null)
                            {
                                return false;
                            }
                            this._source = na;
                        }
                        else 
                        {
                            this._source = e.lastAttr.next;
                        }
                        return true;
                    }
                    return false;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute) ?? $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (a.parent !== null && ($.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr !== a)
                    {
                        if (this._omitDuplicateNamespaces)
                        {
                            /*object?*/ let na = this.GetFirstNonDuplicateNamespaceAttribute(a.next);
                            if (na === null)
                            {
                                return false;
                            }
                            this._source = na;
                        }
                        else 
                        {
                            this._source = a.next;
                        }
                        this._parent = null;
                        return true;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(347894841348)
            
            //--TRIMMABLE-BOUNDARY-START(373664645124)
            /*bool */ Read()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373664645124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(this._state)
                {
                    case 0/*ReadState.Initial*/:
                    this._state = 1/*ReadState.Interactive*/;
                    /*XDocument?*/ let d = $.$as(this._source, $.$spxl.System.Xml.Linq.XDocument);
                    if (d !== null)
                    {
                        return this.ReadIntoDocument(d);
                    }
                    return true;
                    case 1/*ReadState.Interactive*/:
                    return this.Read$1(false);
                    default:
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(373664645124)
            
            //--TRIMMABLE-BOUNDARY-START(382254579716)
            /*bool */ ReadAttributeValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382254579716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return this.ReadIntoAttribute(a);
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(382254579716)
            
            //--TRIMMABLE-BOUNDARY-START(416614318084)
            /*bool */ ReadToDescendant(/*string*/ localName, /*string*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416614318084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return false;
                }
                this.MoveToElement();
                /*XElement?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (c !== null && !c.IsEmpty)
                {
                    if (this.IsEndElement)
                    {
                        return false;
                    }
                    var $en3 = c.Descendants().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var e = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$$.System.String.op_Equality(e.Name.LocalName, localName) && $.$$.System.String.op_Equality(e.Name.NamespaceName, namespaceName))
                            {
                                this._source = e;
                                return true;
                            }
                        }
                    }
                    this.IsEndElement = true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(416614318084)
            
            //--TRIMMABLE-BOUNDARY-START(425204252676)
            /*bool */ ReadToFollowing(/*string*/ localName, /*string*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425204252676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                while(this.Read())
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        if (this.IsEndElement)
                        {
                            continue;
                        }
                        if ($.$$.System.String.op_Equality(e.Name.LocalName, localName) && $.$$.System.String.op_Equality(e.Name.NamespaceName, namespaceName))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(425204252676)
            
            //--TRIMMABLE-BOUNDARY-START(429499219972)
            /*bool */ ReadToNextSibling(/*string*/ localName, /*string*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429499219972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return false;
                }
                this.MoveToElement();
                if (this._source !== this._root)
                {
                    /*XNode?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                    if (n !== null)
                    {
                        var $en4 = n.ElementsAfterSelf().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var e = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if ($.$$.System.String.op_Equality(e.Name.LocalName, localName) && $.$$.System.String.op_Equality(e.Name.NamespaceName, namespaceName))
                                {
                                    this._source = e;
                                    this.IsEndElement = false;
                                    return true;
                                }
                            }
                        }
                        if ($.$is(n.parent, $.$spxl.System.Xml.Linq.XElement))
                        {
                            this._source = n.parent;
                            this.IsEndElement = true;
                            return false;
                        }
                    }
                    else 
                    {
                        if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XElement))
                        {
                            this._source = this._parent;
                            this._parent = null;
                            this.IsEndElement = true;
                            return false;
                        }
                    }
                }
                return this.ReadToEnd();
            }
            //--TRIMMABLE-BOUNDARY-END(429499219972)
            
            //--TRIMMABLE-BOUNDARY-START(433794187268)
            /*void */ ResolveEntity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433794187268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(433794187268)
            
            //--TRIMMABLE-BOUNDARY-START(450974056452)
            /*void */ Skip()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450974056452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsInteractive)
                {
                    return;
                }
                this.Read$1(true);
            }
            //--TRIMMABLE-BOUNDARY-END(450974056452)
            
            //--TRIMMABLE-BOUNDARY-START(472448892932)
            /*bool */ System$Xml$IXmlLineInfo$HasLineInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472448892932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEndElement)
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        return e.Annotation$1($.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation) !== null;
                    }
                }
                else 
                {
                    /*IXmlLineInfo?*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null)
                    {
                        return li.System$Xml$IXmlLineInfo$HasLineInfo();
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(472448892932)
            
            //--TRIMMABLE-BOUNDARY-START(476743860228)
            /*int */ get System$Xml$IXmlLineInfo$LineNumber()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459563991044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEndElement)
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        /*LineInfoEndElementAnnotation?*/ let a = e.Annotation$1($.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation);
                        if (a !== null)
                        {
                            return a.lineNumber;
                        }
                    }
                }
                else 
                {
                    /*IXmlLineInfo?*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null)
                    {
                        return li.System$Xml$IXmlLineInfo$LineNumber;
                    }
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(476743860228)
            
            //--TRIMMABLE-BOUNDARY-START(481038827524)
            /*int */ get System$Xml$IXmlLineInfo$LinePosition()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468153925636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEndElement)
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        /*LineInfoEndElementAnnotation?*/ let a = e.Annotation$1($.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation);
                        if (a !== null)
                        {
                            return a.linePosition;
                        }
                    }
                }
                else 
                {
                    /*IXmlLineInfo?*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null)
                    {
                        return li.System$Xml$IXmlLineInfo$LinePosition;
                    }
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(481038827524)
            
            //--TRIMMABLE-BOUNDARY-START(309240135684)
            /*bool */ get IsEndElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146476548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._parent === this._source;
            }
            /*bool */ set IsEndElement(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442384121860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._parent = value ? this._source : null;
            }
            //--TRIMMABLE-BOUNDARY-END(309240135684)
            
            //--TRIMMABLE-BOUNDARY-START(313535102980)
            /*bool */ get IsInteractive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736411140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._state === 1/*ReadState.Interactive*/;
            }
            //--TRIMMABLE-BOUNDARY-END(313535102980)
            
            //--TRIMMABLE-BOUNDARY-START(51542097924)
            static /*NameTable */ CreateNameTable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542097924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let nameTable = new $.$spx.System.Xml.NameTable().$ctor$2();
                nameTable.Add$1($.$$.System.String.Empty);
                nameTable.Add$1("http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/);
                nameTable.Add$1("http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/);
                return nameTable;
            }
            //--TRIMMABLE-BOUNDARY-END(51542097924)
            
            //--TRIMMABLE-BOUNDARY-START(257700528132)
            /*XElement? */ GetElementInAttributeScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257700528132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (this.IsEndElement)
                    {
                        return null;
                    }
                    return e;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                a = $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(257700528132)
            
            //--TRIMMABLE-BOUNDARY-START(261995495428)
            /*XElement? */ GetElementInScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261995495428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e;
                }
                /*XNode?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    return $.$as(n.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                e = $.$as(this._parent, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e;
                }
                a = $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(261995495428)
            
            //--TRIMMABLE-BOUNDARY-START(274880397316)
            static /*void */ GetNameInAttributeScope(/*string?*/ qualifiedName, /*XElement*/ e, /*out string?*/ localName, /*out string?*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274880397316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.String.IsNullOrEmpty(qualifiedName))
                {
                    /*int*/ let i = $.$$.System.String.IndexOf$3.call(qualifiedName, /*:*/ 58);
                    if (i !== 0 && i !== ((qualifiedName.length - 1) | 0))
                    {
                        if (i === -1)
                        {
                            localName.$v = qualifiedName;
                            namespaceName.$v = $.$$.System.String.Empty;
                            return;
                        }
                        /*XNamespace?*/ let ns = e.GetNamespaceOfPrefix($.$$.System.String.Substring.call(qualifiedName, 0, i));
                        if ($.$spxl.System.Xml.Linq.XNamespace.op_Inequality(ns, null))
                        {
                            localName.$v = $.$$.System.String.Substring$1.call(qualifiedName, ((i + 1) | 0));
                            namespaceName.$v = ns.NamespaceName;
                            return;
                        }
                    }
                }
                localName.$v = null;
                namespaceName.$v = null;
            }
            //--TRIMMABLE-BOUNDARY-END(274880397316)
            
            //--TRIMMABLE-BOUNDARY-START(377959612420)
            /*bool */ Read$1(/*bool*/ skipContent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377959612420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (e.IsEmpty || this.IsEndElement || skipContent)
                    {
                        return this.ReadOverNode(e);
                    }
                    return this.ReadIntoElement(e);
                }
                /*XNode?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    return this.ReadOverNode(n);
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return this.ReadOverAttribute(a, skipContent);
                }
                return this.ReadOverText(skipContent);
            }
            //--TRIMMABLE-BOUNDARY-END(377959612420)
            
            //--TRIMMABLE-BOUNDARY-START(390844514308)
            /*bool */ ReadIntoDocument(/*XDocument*/ d)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390844514308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let n = $.$as(d.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this._source = n.next;
                    return true;
                }
                /*string?*/ let s = $.$as(d.content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    if (s.length > 0)
                    {
                        this._source = s;
                        this._parent = d;
                        return true;
                    }
                }
                return this.ReadToEnd();
            }
            //--TRIMMABLE-BOUNDARY-END(390844514308)
            
            //--TRIMMABLE-BOUNDARY-START(395139481604)
            /*bool */ ReadIntoElement(/*XElement*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395139481604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let n = $.$as(e.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this._source = n.next;
                    return true;
                }
                /*string?*/ let s = $.$as(e.content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    if (s.length > 0)
                    {
                        this._source = s;
                        this._parent = e;
                    }
                    else 
                    {
                        this._source = e;
                        this.IsEndElement = true;
                    }
                    return true;
                }
                return this.ReadToEnd();
            }
            //--TRIMMABLE-BOUNDARY-END(395139481604)
            
            //--TRIMMABLE-BOUNDARY-START(386549547012)
            /*bool */ ReadIntoAttribute(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386549547012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._source = a.value;
                this._parent = a;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(386549547012)
            
            //--TRIMMABLE-BOUNDARY-START(399434448900)
            /*bool */ ReadOverAttribute(/*XAttribute*/ a, /*bool*/ skipContent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399434448900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (e.IsEmpty || skipContent)
                    {
                        return this.ReadOverNode(e);
                    }
                    return this.ReadIntoElement(e);
                }
                return this.ReadToEnd();
            }
            //--TRIMMABLE-BOUNDARY-END(399434448900)
            
            //--TRIMMABLE-BOUNDARY-START(403729416196)
            /*bool */ ReadOverNode(/*XNode*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403729416196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (n === this._root)
                {
                    return this.ReadToEnd();
                }
                /*XNode?*/ let next = n.next;
                if (null === next || next === n || n === n.parent.content)
                {
                    if (n.parent === null || (n.parent.parent === null && $.$is(n.parent, $.$spxl.System.Xml.Linq.XDocument)))
                    {
                        return this.ReadToEnd();
                    }
                    this._source = n.parent;
                    this.IsEndElement = true;
                }
                else 
                {
                    this._source = next;
                    this.IsEndElement = false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(403729416196)
            
            //--TRIMMABLE-BOUNDARY-START(408024383492)
            /*bool */ ReadOverText(/*bool*/ skipContent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408024383492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XElement))
                {
                    this._source = this._parent;
                    this._parent = null;
                    this.IsEndElement = true;
                    return true;
                }
                /*XAttribute?*/ let parent = $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (parent !== null)
                {
                    this._parent = null;
                    return this.ReadOverAttribute(parent, skipContent);
                }
                return this.ReadToEnd();
            }
            //--TRIMMABLE-BOUNDARY-END(408024383492)
            
            //--TRIMMABLE-BOUNDARY-START(420909285380)
            /*bool */ ReadToEnd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420909285380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._state = 3/*ReadState.EndOfFile*/;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(420909285380)
            
            //--TRIMMABLE-BOUNDARY-START(296355233796)
            /*bool */ IsDuplicateNamespaceAttribute(/*XAttribute*/ candidateAttribute)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296355233796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!candidateAttribute.IsNamespaceDeclaration)
                {
                    return false;
                }
                else 
                {
                    return this.IsDuplicateNamespaceAttributeInner(candidateAttribute);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(296355233796)
            
            //--TRIMMABLE-BOUNDARY-START(300650201092)
            /*bool */ IsDuplicateNamespaceAttributeInner(/*XAttribute*/ candidateAttribute)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300650201092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(candidateAttribute.Name.LocalName, "xml"))
                {
                    return true;
                }
                /*XElement?*/ let element = $.$as(candidateAttribute.parent, $.$spxl.System.Xml.Linq.XElement);
                if (element === this._root || element === null)
                {
                    return false;
                }
                element = $.$as(element.parent, $.$spxl.System.Xml.Linq.XElement);
                while(element !== null)
                {
                    /*XAttribute?*/ let a = element.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            if ($.$spxl.System.Xml.Linq.XName.op_Equality(a.name, candidateAttribute.name))
                            {
                                if ($.$$.System.String.op_Equality(a.Value, candidateAttribute.Value))
                                {
                                    return true;
                                }
                                else 
                                {
                                    return false;
                                }
                            }
                            a = a.next;
                        }
                        while(a !== element.lastAttr);
                    }
                    if (element === this._root)
                    {
                        return false;
                    }
                    element = $.$as(element.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(300650201092)
            
            //--TRIMMABLE-BOUNDARY-START(266290462724)
            /*XAttribute? */ GetFirstNonDuplicateNamespaceAttribute(/*XAttribute*/ candidate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266290462724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._omitDuplicateNamespaces, "This method should only be called if we're omitting duplicate namespace attribute. For perf reason it's better to test this flag in the caller method.");
                if (!this.IsDuplicateNamespaceAttribute(candidate))
                {
                    return candidate;
                }
                /*XElement?*/ let e = $.$as(candidate.parent, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null && candidate !== e.lastAttr)
                {
                    do
                    {
                        candidate = candidate.next;
                        if (!this.IsDuplicateNamespaceAttribute(candidate))
                        {
                            return candidate;
                        }
                    }
                    while(candidate !== e.lastAttr);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(266290462724)
            
            static $h = 2490372;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 53346307,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38657196036),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016934404,
        "f": 50364417
      },
      "n": "AttributeCount",
      "d": 2490372,
      "h": 38657196036,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38657196036),
//--TRIMMABLE-BOUNDARY-START(42952163332),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606868996,
        "f": 50364417
      },
      "n": "BaseURI",
      "d": 2490372,
      "h": 42952163332,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42952163332),
//--TRIMMABLE-BOUNDARY-START(55837065220),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196803588,
        "f": 50364417
      },
      "n": "Depth",
      "d": 2490372,
      "h": 55837065220,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55837065220),
//--TRIMMABLE-BOUNDARY-START(64426999812),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786738180,
        "f": 50364417
      },
      "n": "EOF",
      "d": 2490372,
      "h": 64426999812,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64426999812),
//--TRIMMABLE-BOUNDARY-START(287765299204),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376672772,
        "f": 50364417
      },
      "n": "HasAttributes",
      "d": 2490372,
      "h": 287765299204,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(287765299204),
//--TRIMMABLE-BOUNDARY-START(292060266500),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966607364,
        "f": 50364417
      },
      "n": "HasValue",
      "d": 2490372,
      "h": 292060266500,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(292060266500),
//--TRIMMABLE-BOUNDARY-START(304945168388),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124556541956,
        "f": 50364417
      },
      "n": "IsEmptyElement",
      "d": 2490372,
      "h": 304945168388,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(304945168388),
//--TRIMMABLE-BOUNDARY-START(317830070276),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150326345732,
        "f": 50364417
      },
      "n": "LocalName",
      "d": 2490372,
      "h": 317830070276,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(317830070276),
//--TRIMMABLE-BOUNDARY-START(352189808644),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158916280324,
        "f": 50364417
      },
      "n": "Name",
      "d": 2490372,
      "h": 352189808644,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(352189808644),
//--TRIMMABLE-BOUNDARY-START(356484775940),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167506214916,
        "f": 50364417
      },
      "n": "NamespaceURI",
      "d": 2490372,
      "h": 356484775940,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(356484775940),
//--TRIMMABLE-BOUNDARY-START(360779743236),
    {
      "p": 52035587,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176096149508,
        "f": 50364417
      },
      "n": "NameTable",
      "d": 2490372,
      "h": 360779743236,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(360779743236),
//--TRIMMABLE-BOUNDARY-START(365074710532),
    {
      "p": 52822019,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184686084100,
        "f": 50364417
      },
      "n": "NodeType",
      "d": 2490372,
      "h": 365074710532,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(365074710532),
//--TRIMMABLE-BOUNDARY-START(369369677828),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193276018692,
        "f": 50364417
      },
      "n": "Prefix",
      "d": 2490372,
      "h": 369369677828,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(369369677828),
//--TRIMMABLE-BOUNDARY-START(412319350788),
    {
      "p": 14876675,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201865953284,
        "f": 50364417
      },
      "n": "ReadState",
      "d": 2490372,
      "h": 412319350788,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(412319350788),
//--TRIMMABLE-BOUNDARY-START(446679089156),
    {
      "p": 53477379,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210455887876,
        "f": 50364417
      },
      "n": "Settings",
      "d": 2490372,
      "h": 446679089156,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(446679089156),
//--TRIMMABLE-BOUNDARY-START(485333794820),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219045822468,
        "f": 50364417
      },
      "n": "Value",
      "d": 2490372,
      "h": 485333794820,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(485333794820),
//--TRIMMABLE-BOUNDARY-START(489628762116),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227635757060,
        "f": 50364417
      },
      "n": "XmlLang",
      "d": 2490372,
      "h": 489628762116,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(489628762116),
//--TRIMMABLE-BOUNDARY-START(493923729412),
    {
      "p": 54001667,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236225691652,
        "f": 50364417
      },
      "n": "XmlSpace",
      "d": 2490372,
      "h": 493923729412,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(493923729412),
//--TRIMMABLE-BOUNDARY-START(476743860228),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 459563991044,
        "f": 50331650
      },
      "n": "{13893635}.LineNumber",
      "o": "System$Xml$IXmlLineInfo$LineNumber",
      "d": 2490372,
      "h": 476743860228,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(476743860228),
//--TRIMMABLE-BOUNDARY-START(481038827524),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 468153925636,
        "f": 50331650
      },
      "n": "{13893635}.LinePosition",
      "o": "System$Xml$IXmlLineInfo$LinePosition",
      "d": 2490372,
      "h": 481038827524,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(481038827524),
//--TRIMMABLE-BOUNDARY-START(309240135684),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133146476548,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 442384121860,
        "f": 83886082
      },
      "n": "IsEndElement",
      "d": 2490372,
      "h": 309240135684,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(309240135684),
//--TRIMMABLE-BOUNDARY-START(313535102980),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141736411140,
        "f": 50331650
      },
      "n": "IsInteractive",
      "d": 2490372,
      "h": 313535102980,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(313535102980)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(253405560836),
    {
      "r": 655361,
      "p": [
        {
          "n": "o",
          "p": 2555908
        }
      ],
      "n": "GetDepth",
      "d": 2490372,
      "h": 253405560836,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(253405560836),
//--TRIMMABLE-BOUNDARY-START(270585430020),
    {
      "r": 1310721,
      "n": "GetLocalName",
      "d": 2490372,
      "h": 270585430020,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(270585430020),
//--TRIMMABLE-BOUNDARY-START(279175364612),
    {
      "r": 1310721,
      "n": "GetNamespaceURI",
      "d": 2490372,
      "h": 279175364612,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(279175364612),
//--TRIMMABLE-BOUNDARY-START(283470331908),
    {
      "r": 1310721,
      "n": "GetPrefix",
      "d": 2490372,
      "h": 283470331908,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(283470331908),
//--TRIMMABLE-BOUNDARY-START(60132032516),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 2490372,
      "h": 60132032516,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(60132032516),
//--TRIMMABLE-BOUNDARY-START(47247130628),
    {
      "r": 65537,
      "n": "Close",
      "d": 2490372,
      "h": 47247130628,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47247130628),
//--TRIMMABLE-BOUNDARY-START(249110593540),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetAttribute",
      "o": "@$2",
      "d": 2490372,
      "h": 249110593540,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(249110593540),
//--TRIMMABLE-BOUNDARY-START(244815626244),
    {
      "r": 1310721,
      "p": [
        {
          "n": "localName",
          "p": 1310721
        },
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "GetAttribute",
      "o": "@$1",
      "d": 2490372,
      "h": 244815626244,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(244815626244),
//--TRIMMABLE-BOUNDARY-START(240520658948),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "GetAttribute",
      "d": 2490372,
      "h": 240520658948,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(240520658948),
//--TRIMMABLE-BOUNDARY-START(322125037572),
    {
      "r": 1310721,
      "p": [
        {
          "n": "prefix",
          "p": 1310721
        }
      ],
      "n": "LookupNamespace",
      "d": 2490372,
      "h": 322125037572,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(322125037572),
//--TRIMMABLE-BOUNDARY-START(335009939460),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "MoveToAttribute",
      "o": "@$2",
      "d": 2490372,
      "h": 335009939460,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(335009939460),
//--TRIMMABLE-BOUNDARY-START(330714972164),
    {
      "r": 262145,
      "p": [
        {
          "n": "localName",
          "p": 1310721
        },
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "MoveToAttribute",
      "o": "@$1",
      "d": 2490372,
      "h": 330714972164,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(330714972164),
//--TRIMMABLE-BOUNDARY-START(326420004868),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "MoveToAttribute",
      "d": 2490372,
      "h": 326420004868,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(326420004868),
//--TRIMMABLE-BOUNDARY-START(339304906756),
    {
      "r": 262145,
      "n": "MoveToElement",
      "d": 2490372,
      "h": 339304906756,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(339304906756),
//--TRIMMABLE-BOUNDARY-START(343599874052),
    {
      "r": 262145,
      "n": "MoveToFirstAttribute",
      "d": 2490372,
      "h": 343599874052,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(343599874052),
//--TRIMMABLE-BOUNDARY-START(347894841348),
    {
      "r": 262145,
      "n": "MoveToNextAttribute",
      "d": 2490372,
      "h": 347894841348,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(347894841348),
//--TRIMMABLE-BOUNDARY-START(373664645124),
    {
      "r": 262145,
      "n": "Read",
      "d": 2490372,
      "h": 373664645124,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(373664645124),
//--TRIMMABLE-BOUNDARY-START(382254579716),
    {
      "r": 262145,
      "n": "ReadAttributeValue",
      "d": 2490372,
      "h": 382254579716,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(382254579716),
//--TRIMMABLE-BOUNDARY-START(416614318084),
    {
      "r": 262145,
      "p": [
        {
          "n": "localName",
          "p": 1310721
        },
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "ReadToDescendant",
      "d": 2490372,
      "h": 416614318084,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(416614318084),
//--TRIMMABLE-BOUNDARY-START(425204252676),
    {
      "r": 262145,
      "p": [
        {
          "n": "localName",
          "p": 1310721
        },
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "ReadToFollowing",
      "d": 2490372,
      "h": 425204252676,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(425204252676),
//--TRIMMABLE-BOUNDARY-START(429499219972),
    {
      "r": 262145,
      "p": [
        {
          "n": "localName",
          "p": 1310721
        },
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "ReadToNextSibling",
      "d": 2490372,
      "h": 429499219972,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(429499219972),
//--TRIMMABLE-BOUNDARY-START(433794187268),
    {
      "r": 65537,
      "n": "ResolveEntity",
      "d": 2490372,
      "h": 433794187268,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(433794187268),
//--TRIMMABLE-BOUNDARY-START(450974056452),
    {
      "r": 65537,
      "n": "Skip",
      "d": 2490372,
      "h": 450974056452,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(450974056452),
//--TRIMMABLE-BOUNDARY-START(51542097924),
    {
      "r": 14221315,
      "n": "CreateNameTable",
      "d": 2490372,
      "h": 51542097924,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51542097924),
//--TRIMMABLE-BOUNDARY-START(257700528132),
    {
      "r": 1638404,
      "n": "GetElementInAttributeScope",
      "d": 2490372,
      "h": 257700528132,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(257700528132),
//--TRIMMABLE-BOUNDARY-START(261995495428),
    {
      "r": 1638404,
      "n": "GetElementInScope",
      "d": 2490372,
      "h": 261995495428,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(261995495428),
//--TRIMMABLE-BOUNDARY-START(274880397316),
    {
      "r": 65537,
      "p": [
        {
          "n": "qualifiedName",
          "p": 1310721
        },
        {
          "n": "e",
          "p": 1638404
        },
        {
          "n": "localName",
          "p": 1310721,
          "f": 2
        },
        {
          "n": "namespaceName",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "GetNameInAttributeScope",
      "d": 2490372,
      "h": 274880397316,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(274880397316),
//--TRIMMABLE-BOUNDARY-START(377959612420),
    {
      "r": 262145,
      "p": [
        {
          "n": "skipContent",
          "p": 262145
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 2490372,
      "h": 377959612420,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(377959612420),
//--TRIMMABLE-BOUNDARY-START(390844514308),
    {
      "r": 262145,
      "p": [
        {
          "n": "d",
          "p": 1507332
        }
      ],
      "n": "ReadIntoDocument",
      "d": 2490372,
      "h": 390844514308,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(390844514308),
//--TRIMMABLE-BOUNDARY-START(395139481604),
    {
      "r": 262145,
      "p": [
        {
          "n": "e",
          "p": 1638404
        }
      ],
      "n": "ReadIntoElement",
      "d": 2490372,
      "h": 395139481604,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(395139481604),
//--TRIMMABLE-BOUNDARY-START(386549547012),
    {
      "r": 262145,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "ReadIntoAttribute",
      "d": 2490372,
      "h": 386549547012,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(386549547012),
//--TRIMMABLE-BOUNDARY-START(399434448900),
    {
      "r": 262145,
      "p": [
        {
          "n": "a",
          "p": 1114116
        },
        {
          "n": "skipContent",
          "p": 262145
        }
      ],
      "n": "ReadOverAttribute",
      "d": 2490372,
      "h": 399434448900,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(399434448900),
//--TRIMMABLE-BOUNDARY-START(403729416196),
    {
      "r": 262145,
      "p": [
        {
          "n": "n",
          "p": 2228228
        }
      ],
      "n": "ReadOverNode",
      "d": 2490372,
      "h": 403729416196,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(403729416196),
//--TRIMMABLE-BOUNDARY-START(408024383492),
    {
      "r": 262145,
      "p": [
        {
          "n": "skipContent",
          "p": 262145
        }
      ],
      "n": "ReadOverText",
      "d": 2490372,
      "h": 408024383492,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(408024383492),
//--TRIMMABLE-BOUNDARY-START(420909285380),
    {
      "r": 262145,
      "n": "ReadToEnd",
      "d": 2490372,
      "h": 420909285380,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(420909285380),
//--TRIMMABLE-BOUNDARY-START(296355233796),
    {
      "r": 262145,
      "p": [
        {
          "n": "candidateAttribute",
          "p": 1114116
        }
      ],
      "n": "IsDuplicateNamespaceAttribute",
      "d": 2490372,
      "h": 296355233796,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(296355233796),
//--TRIMMABLE-BOUNDARY-START(300650201092),
    {
      "r": 262145,
      "p": [
        {
          "n": "candidateAttribute",
          "p": 1114116
        }
      ],
      "n": "IsDuplicateNamespaceAttributeInner",
      "d": 2490372,
      "h": 300650201092,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(300650201092),
//--TRIMMABLE-BOUNDARY-START(266290462724),
    {
      "r": 1114116,
      "p": [
        {
          "n": "candidate",
          "p": 1114116
        }
      ],
      "n": "GetFirstNonDuplicateNamespaceAttribute",
      "d": 2490372,
      "h": 266290462724,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(266290462724)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21477326852),
    {
      "t": 131073,
      "n": "_source",
      "d": 2490372,
      "h": 21477326852,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477326852),
//--TRIMMABLE-BOUNDARY-START(12887392260),
    {
      "t": 131073,
      "n": "_parent",
      "d": 2490372,
      "h": 12887392260,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887392260),
//--TRIMMABLE-BOUNDARY-START(25772294148),
    {
      "t": 14876675,
      "n": "_state",
      "d": 2490372,
      "h": 25772294148,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25772294148),
//--TRIMMABLE-BOUNDARY-START(17182359556),
    {
      "t": 2228228,
      "n": "_root",
      "d": 2490372,
      "h": 17182359556,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182359556),
//--TRIMMABLE-BOUNDARY-START(4297457668),
    {
      "t": 52035587,
      "n": "_nameTable",
      "d": 2490372,
      "h": 4297457668,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297457668),
//--TRIMMABLE-BOUNDARY-START(8592424964),
    {
      "t": 262145,
      "n": "_omitDuplicateNamespaces",
      "d": 2490372,
      "h": 8592424964,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592424964)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30067261444),
    {
      "p": [
        {
          "n": "node",
          "p": 2228228
        },
        {
          "n": "nameTable",
          "p": 52035587
        },
        {
          "n": "options",
          "p": 917508
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2490372,
      "h": 30067261444,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30067261444),
//--TRIMMABLE-BOUNDARY-START(34362228740),
    {
      "p": [
        {
          "n": "node",
          "p": 2228228
        },
        {
          "n": "nameTable",
          "p": 52035587
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2490372,
      "h": 34362228740,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34362228740)
  ],
  "i": [90308609,13893635
  ],
  "h": 2490372
}; }
            static get $b() { return $.$spx.System.Xml.XmlReader; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490372)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572868)
        $asm.$cls("$spxl.System.Xml.Linq.XDocumentType", ($self) => class XDocumentType extends $.$spxl.System.Xml.Linq.XNode
        {
            //--TRIMMABLE-BOUNDARY-START(8591507460)
            /*string*/ _name = null;
            //--TRIMMABLE-BOUNDARY-END(8591507460)
            
            //--TRIMMABLE-BOUNDARY-START(12886474756)
            /*string?*/ _publicId = null;
            //--TRIMMABLE-BOUNDARY-END(12886474756)
            
            //--TRIMMABLE-BOUNDARY-START(17181442052)
            /*string?*/ _systemId = null;
            //--TRIMMABLE-BOUNDARY-END(17181442052)
            
            //--TRIMMABLE-BOUNDARY-START(4296540164)
            /*string?*/ _internalSubset = null;
            //--TRIMMABLE-BOUNDARY-END(4296540164)
            
            //--TRIMMABLE-BOUNDARY-START(21476409348)
            $ctor$3(/*string*/ name, /*string?*/ publicId, /*string?*/ systemId, /*string?*/ internalSubset)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476409348);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._name = $.$spx.System.Xml.XmlConvert.VerifyName(name);
                    this._publicId = publicId;
                    this._systemId = systemId;
                    this._internalSubset = internalSubset;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476409348)
            
            //--TRIMMABLE-BOUNDARY-START(30066343940)
            $ctor$5(/*XDocumentType*/ other)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066343940);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this._name = other._name;
                    this._publicId = other._publicId;
                    this._systemId = other._systemId;
                    this._internalSubset = other._internalSubset;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066343940)
            
            //--TRIMMABLE-BOUNDARY-START(25771376644)
            $ctor$4(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771376644);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._name = r.Name;
                    this._publicId = r.GetAttribute$2("PUBLIC");
                    this._systemId = r.GetAttribute$2("SYSTEM");
                    this._internalSubset = r.Value;
                    r.Read();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771376644)
            
            //--TRIMMABLE-BOUNDARY-START(90195886084)
            /*string? */ get InternalSubset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246213124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._internalSubset;
            }
            /*string? */ set InternalSubset(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670722564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this._internalSubset = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195886084)
            
            //--TRIMMABLE-BOUNDARY-START(94490853380)
            /*string */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836147716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._name;
            }
            /*string */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260657156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value = $.$spx.System.Xml.XmlConvert.VerifyName(value);
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                this._name = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490853380)
            
            //--TRIMMABLE-BOUNDARY-START(98785820676)
            /*XmlNodeType */ get NodeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426082308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 10/*XmlNodeType.DocumentType*/;
            }
            //--TRIMMABLE-BOUNDARY-END(98785820676)
            
            //--TRIMMABLE-BOUNDARY-START(103080787972)
            /*string? */ get PublicId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016016900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._publicId;
            }
            /*string? */ set PublicId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850591748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this._publicId = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080787972)
            
            //--TRIMMABLE-BOUNDARY-START(141735493636)
            /*string? */ get SystemId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605951492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._systemId;
            }
            /*string? */ set SystemId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440526340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this._systemId = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141735493636)
            
            //--TRIMMABLE-BOUNDARY-START(146030460932)
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030460932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                writer.WriteDocType(this._name, this._publicId, this._systemId, this._internalSubset);
            }
            //--TRIMMABLE-BOUNDARY-END(146030460932)
            
            //--TRIMMABLE-BOUNDARY-START(150325428228)
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325428228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return writer.WriteDocTypeAsync(this._name, this._publicId, this._systemId, this._internalSubset);
            }
            //--TRIMMABLE-BOUNDARY-END(150325428228)
            
            //--TRIMMABLE-BOUNDARY-START(34361311236)
            /*XNode */ CloneNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361311236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$5(this);
            }
            //--TRIMMABLE-BOUNDARY-END(34361311236)
            
            //--TRIMMABLE-BOUNDARY-START(38656278532)
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656278532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XDocumentType?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XDocumentType);
                return other !== null && $.$$.System.String.op_Equality(this._name, other._name) && $.$$.System.String.op_Equality(this._publicId, other._publicId) && $.$$.System.String.op_Equality(this._systemId, other.SystemId) && $.$$.System.String.op_Equality(this._internalSubset, other._internalSubset);
            }
            //--TRIMMABLE-BOUNDARY-END(38656278532)
            
            //--TRIMMABLE-BOUNDARY-START(85900918788)
            /*int */ GetDeepHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900918788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.GetHashCode.call(this._name) ^ ($.$$.System.String.op_Inequality(this._publicId, null) ? $.$$.System.String.GetHashCode.call(this._publicId) : 0) ^ ($.$$.System.String.op_Inequality(this._systemId, null) ? $.$$.System.String.GetHashCode.call(this._systemId) : 0) ^ ($.$$.System.String.op_Inequality(this._internalSubset, null) ? $.$$.System.String.GetHashCode.call(this._internalSubset) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(85900918788)
            
            static $h = 1572868;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2228228,
  "p": [
//--TRIMMABLE-BOUNDARY-START(90195886084),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246213124,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670722564,
        "f": 83886081
      },
      "n": "InternalSubset",
      "d": 1572868,
      "h": 90195886084,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195886084),
//--TRIMMABLE-BOUNDARY-START(94490853380),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836147716,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260657156,
        "f": 83886081
      },
      "n": "Name",
      "d": 1572868,
      "h": 94490853380,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490853380),
//--TRIMMABLE-BOUNDARY-START(98785820676),
    {
      "p": 52822019,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426082308,
        "f": 50364417
      },
      "n": "NodeType",
      "d": 1572868,
      "h": 98785820676,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(98785820676),
//--TRIMMABLE-BOUNDARY-START(103080787972),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016016900,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850591748,
        "f": 83886081
      },
      "n": "PublicId",
      "d": 1572868,
      "h": 103080787972,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080787972),
//--TRIMMABLE-BOUNDARY-START(141735493636),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605951492,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137440526340,
        "f": 83886081
      },
      "n": "SystemId",
      "d": 1572868,
      "h": 141735493636,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141735493636)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(146030460932),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        }
      ],
      "n": "WriteTo",
      "d": 1572868,
      "h": 146030460932,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146030460932),
//--TRIMMABLE-BOUNDARY-START(150325428228),
    {
      "r": 177668097,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteToAsync",
      "d": 1572868,
      "h": 150325428228,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150325428228),
//--TRIMMABLE-BOUNDARY-START(34361311236),
    {
      "r": 2228228,
      "n": "CloneNode",
      "d": 1572868,
      "h": 34361311236,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(34361311236),
//--TRIMMABLE-BOUNDARY-START(38656278532),
    {
      "r": 262145,
      "p": [
        {
          "n": "node",
          "p": 2228228
        }
      ],
      "n": "DeepEquals",
      "o": "@$1",
      "d": 1572868,
      "h": 38656278532,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(38656278532),
//--TRIMMABLE-BOUNDARY-START(85900918788),
    {
      "r": 655361,
      "n": "GetDeepHashCode",
      "d": 1572868,
      "h": 85900918788,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(85900918788)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591507460),
    {
      "t": 1310721,
      "n": "_name",
      "d": 1572868,
      "h": 8591507460,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591507460),
//--TRIMMABLE-BOUNDARY-START(12886474756),
    {
      "t": 1310721,
      "n": "_publicId",
      "d": 1572868,
      "h": 12886474756,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886474756),
//--TRIMMABLE-BOUNDARY-START(17181442052),
    {
      "t": 1310721,
      "n": "_systemId",
      "d": 1572868,
      "h": 17181442052,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181442052),
//--TRIMMABLE-BOUNDARY-START(4296540164),
    {
      "t": 1310721,
      "n": "_internalSubset",
      "d": 1572868,
      "h": 4296540164,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296540164)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476409348),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "publicId",
          "p": 1310721
        },
        {
          "n": "systemId",
          "p": 1310721
        },
        {
          "n": "internalSubset",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1572868,
      "h": 21476409348,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476409348),
//--TRIMMABLE-BOUNDARY-START(30066343940),
    {
      "p": [
        {
          "n": "other",
          "p": 1572868
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1572868,
      "h": 30066343940,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066343940),
//--TRIMMABLE-BOUNDARY-START(25771376644),
    {
      "p": [
        {
          "n": "r",
          "p": 53346307
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1572868,
      "h": 25771376644,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25771376644)
  ],
  "i": [13893635
  ],
  "h": 1572868
}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XDocumentType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572868)
        
        
        //--TRIMMABLE-BOUNDARY-START(2818052)
        $asm.$cls("$spxl.System.Xml.Linq.XProcessingInstruction", ($self) => class XProcessingInstruction extends $.$spxl.System.Xml.Linq.XNode
        {
            //--TRIMMABLE-BOUNDARY-START(85902163972)
            /*string*/ target = null;
            //--TRIMMABLE-BOUNDARY-END(85902163972)
            
            //--TRIMMABLE-BOUNDARY-START(21477654532)
            /*string*/ data = null;
            //--TRIMMABLE-BOUNDARY-END(21477654532)
            
            //--TRIMMABLE-BOUNDARY-START(4297785348)
            $ctor$3(/*string*/ target, /*string*/ data)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297785348);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(data, "data");
                    $.$spxl.System.Xml.Linq.XProcessingInstruction.ValidateName(target);
                    this.target = target;
                    this.data = data;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297785348)
            
            //--TRIMMABLE-BOUNDARY-START(12887719940)
            $ctor$5(/*XProcessingInstruction*/ other)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887719940);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this.target = other.target;
                    this.data = other.data;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887719940)
            
            //--TRIMMABLE-BOUNDARY-START(8592752644)
            $ctor$4(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592752644);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.target = r.Name;
                    this.data = r.Value;
                    r.Read();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592752644)
            
            //--TRIMMABLE-BOUNDARY-START(25772621828)
            /*string */ get Data()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657523716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.data;
            }
            /*string */ set Data(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017262084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.data = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772621828)
            
            //--TRIMMABLE-BOUNDARY-START(64427327492)
            /*XmlNodeType */ get NodeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247458308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 7/*XmlNodeType.ProcessingInstruction*/;
            }
            //--TRIMMABLE-BOUNDARY-END(64427327492)
            
            //--TRIMMABLE-BOUNDARY-START(90197131268)
            /*string */ get Target()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837392900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.target;
            }
            /*string */ set Target(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81607196676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$spxl.System.Xml.Linq.XProcessingInstruction.ValidateName(value);
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                this.target = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90197131268)
            
            //--TRIMMABLE-BOUNDARY-START(98787065860)
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787065860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                writer.WriteProcessingInstruction(this.target, this.data);
            }
            //--TRIMMABLE-BOUNDARY-END(98787065860)
            
            //--TRIMMABLE-BOUNDARY-START(103082033156)
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082033156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return writer.WriteProcessingInstructionAsync(this.target, this.data);
            }
            //--TRIMMABLE-BOUNDARY-END(103082033156)
            
            //--TRIMMABLE-BOUNDARY-START(17182687236)
            /*XNode */ CloneNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182687236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$5(this);
            }
            //--TRIMMABLE-BOUNDARY-END(17182687236)
            
            //--TRIMMABLE-BOUNDARY-START(30067589124)
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067589124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XProcessingInstruction?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XProcessingInstruction);
                return other !== null && $.$$.System.String.op_Equality(this.target, other.target) && $.$$.System.String.op_Equality(this.data, other.data);
            }
            //--TRIMMABLE-BOUNDARY-END(30067589124)
            
            //--TRIMMABLE-BOUNDARY-START(60132360196)
            /*int */ GetDeepHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132360196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.GetHashCode.call(this.target) ^ $.$$.System.String.GetHashCode.call(this.data);
            }
            //--TRIMMABLE-BOUNDARY-END(60132360196)
            
            //--TRIMMABLE-BOUNDARY-START(94492098564)
            static /*void */ ValidateName(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492098564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$spx.System.Xml.XmlConvert.VerifyNCName$1(name);
                if ($.$$.System.String.Equals$2(name, "xml", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_InvalidPIName, name));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94492098564)
            
            static $h = 2818052;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2228228,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772621828),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657523716,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017262084,
        "f": 83886081
      },
      "n": "Data",
      "d": 2818052,
      "h": 25772621828,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772621828),
//--TRIMMABLE-BOUNDARY-START(64427327492),
    {
      "p": 52822019,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247458308,
        "f": 50364417
      },
      "n": "NodeType",
      "d": 2818052,
      "h": 64427327492,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64427327492),
//--TRIMMABLE-BOUNDARY-START(90197131268),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837392900,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81607196676,
        "f": 83886081
      },
      "n": "Target",
      "d": 2818052,
      "h": 90197131268,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90197131268)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98787065860),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        }
      ],
      "n": "WriteTo",
      "d": 2818052,
      "h": 98787065860,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98787065860),
//--TRIMMABLE-BOUNDARY-START(103082033156),
    {
      "r": 177668097,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteToAsync",
      "d": 2818052,
      "h": 103082033156,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103082033156),
//--TRIMMABLE-BOUNDARY-START(17182687236),
    {
      "r": 2228228,
      "n": "CloneNode",
      "d": 2818052,
      "h": 17182687236,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(17182687236),
//--TRIMMABLE-BOUNDARY-START(30067589124),
    {
      "r": 262145,
      "p": [
        {
          "n": "node",
          "p": 2228228
        }
      ],
      "n": "DeepEquals",
      "o": "@$1",
      "d": 2818052,
      "h": 30067589124,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(30067589124),
//--TRIMMABLE-BOUNDARY-START(60132360196),
    {
      "r": 655361,
      "n": "GetDeepHashCode",
      "d": 2818052,
      "h": 60132360196,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(60132360196),
//--TRIMMABLE-BOUNDARY-START(94492098564),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "ValidateName",
      "d": 2818052,
      "h": 94492098564,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94492098564)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(85902163972),
    {
      "t": 1310721,
      "n": "target",
      "d": 2818052,
      "h": 85902163972,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(85902163972),
//--TRIMMABLE-BOUNDARY-START(21477654532),
    {
      "t": 1310721,
      "n": "data",
      "d": 2818052,
      "h": 21477654532,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21477654532)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297785348),
    {
      "p": [
        {
          "n": "target",
          "p": 1310721
        },
        {
          "n": "data",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2818052,
      "h": 4297785348,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297785348),
//--TRIMMABLE-BOUNDARY-START(12887719940),
    {
      "p": [
        {
          "n": "other",
          "p": 2818052
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2818052,
      "h": 12887719940,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887719940),
//--TRIMMABLE-BOUNDARY-START(8592752644),
    {
      "p": [
        {
          "n": "r",
          "p": 53346307
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2818052,
      "h": 8592752644,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592752644)
  ],
  "i": [13893635
  ],
  "h": 2818052
}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XProcessingInstruction`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2818052)
        
        
        //--TRIMMABLE-BOUNDARY-START(2949124)
        $asm.$cls("$spxl.System.Xml.Linq.XText", ($self) => class XText extends $.$spxl.System.Xml.Linq.XNode
        {
            //--TRIMMABLE-BOUNDARY-START(64427458564)
            /*string*/ text = null;
            //--TRIMMABLE-BOUNDARY-END(64427458564)
            
            //--TRIMMABLE-BOUNDARY-START(4297916420)
            $ctor$3(/*string*/ value)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297916420);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                    this.text = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297916420)
            
            //--TRIMMABLE-BOUNDARY-START(12887851012)
            $ctor$5(/*XText*/ other)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887851012);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this.text = other.text;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887851012)
            
            //--TRIMMABLE-BOUNDARY-START(8592883716)
            $ctor$4(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592883716);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.text = r.Value;
                    r.Read();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592883716)
            
            //--TRIMMABLE-BOUNDARY-START(51542556676)
            /*XmlNodeType */ get NodeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362687492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 3/*XmlNodeType.Text*/;
            }
            //--TRIMMABLE-BOUNDARY-END(51542556676)
            
            //--TRIMMABLE-BOUNDARY-START(68722425860)
            /*string */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952622084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.text;
            }
            /*string */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132491268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.text = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68722425860)
            
            //--TRIMMABLE-BOUNDARY-START(73017393156)
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017393156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if ($.$is(this.parent, $.$spxl.System.Xml.Linq.XDocument))
                {
                    writer.WriteWhitespace(this.text);
                }
                else 
                {
                    writer.WriteString(this.text);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73017393156)
            
            //--TRIMMABLE-BOUNDARY-START(77312360452)
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312360452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return $.$is(this.parent, $.$spxl.System.Xml.Linq.XDocument) ? writer.WriteWhitespaceAsync(this.text) : writer.WriteStringAsync(this.text);
            }
            //--TRIMMABLE-BOUNDARY-END(77312360452)
            
            //--TRIMMABLE-BOUNDARY-START(17182818308)
            /*void */ AppendText(/*StringBuilder*/ sb)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182818308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                sb.Append$19(this.text);
            }
            //--TRIMMABLE-BOUNDARY-END(17182818308)
            
            //--TRIMMABLE-BOUNDARY-START(21477785604)
            /*XNode */ CloneNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477785604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$spxl.System.Xml.Linq.XText().$ctor$5(this);
            }
            //--TRIMMABLE-BOUNDARY-END(21477785604)
            
            //--TRIMMABLE-BOUNDARY-START(25772752900)
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772752900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return node !== null && this.NodeType === node.NodeType && $.$$.System.String.op_Equality(this.text, ($.$cast(node, $.$spxl.System.Xml.Linq.XText)).text);
            }
            //--TRIMMABLE-BOUNDARY-END(25772752900)
            
            //--TRIMMABLE-BOUNDARY-START(47247589380)
            /*int */ GetDeepHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247589380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.GetHashCode.call(this.text);
            }
            //--TRIMMABLE-BOUNDARY-END(47247589380)
            
            static $h = 2949124;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2228228,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542556676),
    {
      "p": 52822019,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362687492,
        "f": 50364417
      },
      "n": "NodeType",
      "d": 2949124,
      "h": 51542556676,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51542556676),
//--TRIMMABLE-BOUNDARY-START(68722425860),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952622084,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132491268,
        "f": 83886081
      },
      "n": "Value",
      "d": 2949124,
      "h": 68722425860,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68722425860)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73017393156),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        }
      ],
      "n": "WriteTo",
      "d": 2949124,
      "h": 73017393156,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73017393156),
//--TRIMMABLE-BOUNDARY-START(77312360452),
    {
      "r": 177668097,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteToAsync",
      "d": 2949124,
      "h": 77312360452,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77312360452),
//--TRIMMABLE-BOUNDARY-START(17182818308),
    {
      "r": 65537,
      "p": [
        {
          "n": "sb",
          "p": 167051265
        }
      ],
      "n": "AppendText",
      "d": 2949124,
      "h": 17182818308,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(17182818308),
//--TRIMMABLE-BOUNDARY-START(21477785604),
    {
      "r": 2228228,
      "n": "CloneNode",
      "d": 2949124,
      "h": 21477785604,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(21477785604),
//--TRIMMABLE-BOUNDARY-START(25772752900),
    {
      "r": 262145,
      "p": [
        {
          "n": "node",
          "p": 2228228
        }
      ],
      "n": "DeepEquals",
      "o": "@$1",
      "d": 2949124,
      "h": 25772752900,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(25772752900),
//--TRIMMABLE-BOUNDARY-START(47247589380),
    {
      "r": 655361,
      "n": "GetDeepHashCode",
      "d": 2949124,
      "h": 47247589380,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(47247589380)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64427458564),
    {
      "t": 1310721,
      "n": "text",
      "d": 2949124,
      "h": 64427458564,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(64427458564)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297916420),
    {
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2949124,
      "h": 4297916420,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297916420),
//--TRIMMABLE-BOUNDARY-START(12887851012),
    {
      "p": [
        {
          "n": "other",
          "p": 2949124
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2949124,
      "h": 12887851012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887851012),
//--TRIMMABLE-BOUNDARY-START(8592883716),
    {
      "p": [
        {
          "n": "r",
          "p": 53346307
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2949124,
      "h": 8592883716,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592883716)
  ],
  "i": [13893635
  ],
  "h": 2949124
}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XText`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2949124)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245188)
        $asm.$cls("$spxl.System.Xml.Linq.XComment", ($self) => class XComment extends $.$spxl.System.Xml.Linq.XNode
        {
            //--TRIMMABLE-BOUNDARY-START(60130787332)
            /*string*/ value = null;
            //--TRIMMABLE-BOUNDARY-END(60130787332)
            
            //--TRIMMABLE-BOUNDARY-START(4296212484)
            $ctor$3(/*string*/ value)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296212484);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                    this.value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296212484)
            
            //--TRIMMABLE-BOUNDARY-START(12886147076)
            $ctor$5(/*XComment*/ other)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886147076);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this.value = other.value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886147076)
            
            //--TRIMMABLE-BOUNDARY-START(8591179780)
            $ctor$4(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591179780);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.value = r.Value;
                    r.Read();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591179780)
            
            //--TRIMMABLE-BOUNDARY-START(47245885444)
            /*XmlNodeType */ get NodeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066016260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 8/*XmlNodeType.Comment*/;
            }
            //--TRIMMABLE-BOUNDARY-END(47245885444)
            
            //--TRIMMABLE-BOUNDARY-START(64425754628)
            /*string */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655950852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.value;
            }
            /*string */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835820036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.value = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425754628)
            
            //--TRIMMABLE-BOUNDARY-START(68720721924)
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720721924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                writer.WriteComment(this.value);
            }
            //--TRIMMABLE-BOUNDARY-END(68720721924)
            
            //--TRIMMABLE-BOUNDARY-START(73015689220)
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015689220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return writer.WriteCommentAsync(this.value);
            }
            //--TRIMMABLE-BOUNDARY-END(73015689220)
            
            //--TRIMMABLE-BOUNDARY-START(17181114372)
            /*XNode */ CloneNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181114372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$spxl.System.Xml.Linq.XComment().$ctor$5(this);
            }
            //--TRIMMABLE-BOUNDARY-END(17181114372)
            
            //--TRIMMABLE-BOUNDARY-START(21476081668)
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476081668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XComment?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XComment);
                return other !== null && $.$$.System.String.op_Equality(this.value, other.value);
            }
            //--TRIMMABLE-BOUNDARY-END(21476081668)
            
            //--TRIMMABLE-BOUNDARY-START(42950918148)
            /*int */ GetDeepHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950918148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.GetHashCode.call(this.value);
            }
            //--TRIMMABLE-BOUNDARY-END(42950918148)
            
            static $h = 1245188;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2228228,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245885444),
    {
      "p": 52822019,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066016260,
        "f": 50364417
      },
      "n": "NodeType",
      "d": 1245188,
      "h": 47245885444,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47245885444),
//--TRIMMABLE-BOUNDARY-START(64425754628),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655950852,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835820036,
        "f": 83886081
      },
      "n": "Value",
      "d": 1245188,
      "h": 64425754628,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425754628)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720721924),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        }
      ],
      "n": "WriteTo",
      "d": 1245188,
      "h": 68720721924,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720721924),
//--TRIMMABLE-BOUNDARY-START(73015689220),
    {
      "r": 177668097,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteToAsync",
      "d": 1245188,
      "h": 73015689220,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015689220),
//--TRIMMABLE-BOUNDARY-START(17181114372),
    {
      "r": 2228228,
      "n": "CloneNode",
      "d": 1245188,
      "h": 17181114372,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(17181114372),
//--TRIMMABLE-BOUNDARY-START(21476081668),
    {
      "r": 262145,
      "p": [
        {
          "n": "node",
          "p": 2228228
        }
      ],
      "n": "DeepEquals",
      "o": "@$1",
      "d": 1245188,
      "h": 21476081668,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(21476081668),
//--TRIMMABLE-BOUNDARY-START(42950918148),
    {
      "r": 655361,
      "n": "GetDeepHashCode",
      "d": 1245188,
      "h": 42950918148,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(42950918148)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60130787332),
    {
      "t": 1310721,
      "n": "value",
      "d": 1245188,
      "h": 60130787332,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(60130787332)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212484),
    {
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1245188,
      "h": 4296212484,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212484),
//--TRIMMABLE-BOUNDARY-START(12886147076),
    {
      "p": [
        {
          "n": "other",
          "p": 1245188
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1245188,
      "h": 12886147076,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886147076),
//--TRIMMABLE-BOUNDARY-START(8591179780),
    {
      "p": [
        {
          "n": "r",
          "p": 53346307
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1245188,
      "h": 8591179780,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591179780)
  ],
  "i": [13893635
  ],
  "h": 1245188
}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XComment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245188)
        
        
        //--TRIMMABLE-BOUNDARY-START(2621444)
        $asm.$str("$spxl.System.Xml.Linq.XObjectChange", ($self) => class XObjectChange extends $.$$.System.Enum
        {
            static Add = 0;
            static Remove = 1;
            static Name = 2;
            static Value = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2621444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Remove": 1n,
                    "Name": 2n,
                    "Value": 3n
                };
            }
            static $h = 2621444;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592556036),
    {
      "t": 2621444,
      "n": "Add",
      "d": 2621444,
      "h": 8592556036,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592556036),
//--TRIMMABLE-BOUNDARY-START(17182490628),
    {
      "t": 2621444,
      "n": "Remove",
      "d": 2621444,
      "h": 17182490628,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182490628),
//--TRIMMABLE-BOUNDARY-START(12887523332),
    {
      "t": 2621444,
      "n": "Name",
      "d": 2621444,
      "h": 12887523332,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887523332),
//--TRIMMABLE-BOUNDARY-START(21477457924),
    {
      "t": 2621444,
      "n": "Value",
      "d": 2621444,
      "h": 21477457924,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477457924)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297588740),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2621444,
      "h": 4297588740,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297588740)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 2621444
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.XObjectChange`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2621444)
        
        
        //--TRIMMABLE-BOUNDARY-START(655364)
        $asm.$str("$spxl.System.Xml.Linq.LoadOptions", ($self) => class LoadOptions extends $.$$.System.Enum
        {
            static None = 0;
            static PreserveWhitespace = 1;
            static SetBaseUri = 2;
            static SetLineInfo = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "PreserveWhitespace": 1n,
                    "SetBaseUri": 2n,
                    "SetLineInfo": 4n
                };
            }
            static $h = 655364;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590589956),
    {
      "t": 655364,
      "n": "None",
      "d": 655364,
      "h": 8590589956,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590589956),
//--TRIMMABLE-BOUNDARY-START(12885557252),
    {
      "t": 655364,
      "n": "PreserveWhitespace",
      "d": 655364,
      "h": 12885557252,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885557252),
//--TRIMMABLE-BOUNDARY-START(17180524548),
    {
      "t": 655364,
      "n": "SetBaseUri",
      "d": 655364,
      "h": 17180524548,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180524548),
//--TRIMMABLE-BOUNDARY-START(21475491844),
    {
      "t": 655364,
      "n": "SetLineInfo",
      "d": 655364,
      "h": 21475491844,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475491844)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622660),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655364,
      "h": 4295622660,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622660)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 655364,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.LoadOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655364)
        
        
        //--TRIMMABLE-BOUNDARY-START(983044)
        $asm.$str("$spxl.System.Xml.Linq.SaveOptions", ($self) => class SaveOptions extends $.$$.System.Enum
        {
            static None = 0;
            static DisableFormatting = 1;
            static OmitDuplicateNamespaces = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(983044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "DisableFormatting": 1n,
                    "OmitDuplicateNamespaces": 2n
                };
            }
            static $h = 983044;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885884932),
    {
      "t": 983044,
      "n": "None",
      "d": 983044,
      "h": 12885884932,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885884932),
//--TRIMMABLE-BOUNDARY-START(8590917636),
    {
      "t": 983044,
      "n": "DisableFormatting",
      "d": 983044,
      "h": 8590917636,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590917636),
//--TRIMMABLE-BOUNDARY-START(17180852228),
    {
      "t": 983044,
      "n": "OmitDuplicateNamespaces",
      "d": 983044,
      "h": 17180852228,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180852228)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950340),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 983044,
      "h": 4295950340,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950340)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 983044,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.SaveOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983044)
        
        
        //--TRIMMABLE-BOUNDARY-START(917508)
        $asm.$str("$spxl.System.Xml.Linq.ReaderOptions", ($self) => class ReaderOptions extends $.$$.System.Enum
        {
            static None = 0;
            static OmitDuplicateNamespaces = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(917508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "OmitDuplicateNamespaces": 1n
                };
            }
            static $h = 917508;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852100),
    {
      "t": 917508,
      "n": "None",
      "d": 917508,
      "h": 8590852100,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590852100),
//--TRIMMABLE-BOUNDARY-START(12885819396),
    {
      "t": 917508,
      "n": "OmitDuplicateNamespaces",
      "d": 917508,
      "h": 12885819396,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885819396)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884804),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917508,
      "h": 4295884804,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295884804)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 917508,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.ReaderOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917508)
        
        
        //--TRIMMABLE-BOUNDARY-START(3276804)
        $asm.$cls("$spxl.System.Xml.XPath.XNodeNavigator", ($self) => class XNodeNavigator extends $.$spx.System.Xml.XPath.XPathNavigator
        {
            //--TRIMMABLE-BOUNDARY-START(390845300740)
            /*string*/ static xmlPrefixNamespace = null;
            //--TRIMMABLE-BOUNDARY-END(390845300740)
            
            //--TRIMMABLE-BOUNDARY-START(386550333444)
            /*string*/ static xmlnsPrefixNamespace = null;
            //--TRIMMABLE-BOUNDARY-END(386550333444)
            
            //--TRIMMABLE-BOUNDARY-START(47247917060)
            /*int*/ static DocumentContentMask = 386;
            //--TRIMMABLE-BOUNDARY-END(47247917060)
            
            //--TRIMMABLE-BOUNDARY-START(51542884356)
            static /*ReadOnlySpan<int> */ get ElementContentMasks()
            {
                return this.$cacheElementContentMasks ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Int32))().$ctor$4([ 0, (1 << 1/*XmlNodeType.Element*/), 0, 0, (1 << 4/*XmlNodeType.CDATA*/) | (1 << 3/*XmlNodeType.Text*/), 0, 0, (1 << 7/*XmlNodeType.ProcessingInstruction*/), (1 << 8/*XmlNodeType.Comment*/), (1 << 1/*XmlNodeType.Element*/) | (1 << 4/*XmlNodeType.CDATA*/) | (1 << 3/*XmlNodeType.Text*/) | (1 << 7/*XmlNodeType.ProcessingInstruction*/) | (1 << 8/*XmlNodeType.Comment*/) ]);
            }
            //--TRIMMABLE-BOUNDARY-END(51542884356)
            
            //--TRIMMABLE-BOUNDARY-START(373665431556)
            /*int*/ static TextMask$1 = 24;
            //--TRIMMABLE-BOUNDARY-END(373665431556)
            
            //--TRIMMABLE-BOUNDARY-START(339305693188)
            /*XAttribute?*/ static s_XmlNamespaceDeclaration = null;
            //--TRIMMABLE-BOUNDARY-END(339305693188)
            
            //--TRIMMABLE-BOUNDARY-START(12888178692)
            /*XObject*/ _source = null;
            //--TRIMMABLE-BOUNDARY-END(12888178692)
            
            //--TRIMMABLE-BOUNDARY-START(8593211396)
            /*XElement?*/ _parent = null;
            //--TRIMMABLE-BOUNDARY-END(8593211396)
            
            //--TRIMMABLE-BOUNDARY-START(4298244100)
            /*XmlNameTable*/ _nameTable = null;
            //--TRIMMABLE-BOUNDARY-END(4298244100)
            
            //--TRIMMABLE-BOUNDARY-START(21478113284)
            $ctor$3(/*XNode*/ node, /*XmlNameTable?*/ nameTable)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478113284);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._source = node;
                    this._nameTable = nameTable ?? $.$spxl.System.Xml.XPath.XNodeNavigator.CreateNameTable();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21478113284)
            
            //--TRIMMABLE-BOUNDARY-START(25773080580)
            $ctor$4(/*XNodeNavigator*/ other)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25773080580);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._source = other._source;
                    this._parent = other._parent;
                    this._nameTable = other._nameTable;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25773080580)
            
            //--TRIMMABLE-BOUNDARY-START(30068047876)
            /*string */ get BaseURI()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132818948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._source !== null)
                {
                    return this._source.BaseUri;
                }
                if (this._parent !== null)
                {
                    return this._parent.BaseUri;
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(30068047876)
            
            //--TRIMMABLE-BOUNDARY-START(206161707012)
            /*bool */ get HasAttributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312688132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let element = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (element !== null)
                {
                    var $en3 = element.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var attribute = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!attribute.IsNamespaceDeclaration)
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(206161707012)
            
            //--TRIMMABLE-BOUNDARY-START(210456674308)
            /*bool */ get HasChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902622724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XContainer?*/ let container = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (container !== null)
                {
                    var $en3 = container.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, node))
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(210456674308)
            
            //--TRIMMABLE-BOUNDARY-START(223341576196)
            /*bool */ get IsEmptyElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492557316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                return e !== null && e.IsEmpty;
            }
            //--TRIMMABLE-BOUNDARY-END(223341576196)
            
            //--TRIMMABLE-BOUNDARY-START(240521445380)
            /*string */ get LocalName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082491908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._nameTable.Add$1(this.GetLocalName());
            }
            //--TRIMMABLE-BOUNDARY-END(240521445380)
            
            //--TRIMMABLE-BOUNDARY-START(180391903236)
            /*string */ GetLocalName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391903236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.LocalName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (this._parent !== null && a.Name.NamespaceName.length === 0)
                    {
                        return $.$$.System.String.Empty;
                    }
                    return a.Name.LocalName;
                }
                /*XProcessingInstruction?*/ let p = $.$as(this._source, $.$spxl.System.Xml.Linq.XProcessingInstruction);
                if (p !== null)
                {
                    return p.Target;
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(180391903236)
            
            //--TRIMMABLE-BOUNDARY-START(313535889412)
            /*string */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111672426500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let prefix = this.GetPrefix();
                if (prefix.length === 0)
                {
                    return this._nameTable.Add$1(this.GetLocalName());
                }
                return this._nameTable.Add$1($.$$.System.String.Concat$12(prefix, ":", this.GetLocalName()));
            }
            //--TRIMMABLE-BOUNDARY-END(313535889412)
            
            //--TRIMMABLE-BOUNDARY-START(317830856708)
            /*string */ get NamespaceURI()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120262361092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._nameTable.Add$1(this.GetNamespaceURI());
            }
            //--TRIMMABLE-BOUNDARY-END(317830856708)
            
            //--TRIMMABLE-BOUNDARY-START(184686870532)
            /*string */ GetNamespaceURI()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184686870532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.NamespaceName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (this._parent !== null)
                    {
                        return $.$$.System.String.Empty;
                    }
                    return a.Name.NamespaceName;
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(184686870532)
            
            //--TRIMMABLE-BOUNDARY-START(322125824004)
            /*XmlNameTable */ get NameTable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128852295684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._nameTable;
            }
            //--TRIMMABLE-BOUNDARY-END(322125824004)
            
            //--TRIMMABLE-BOUNDARY-START(326420791300)
            /*XPathNodeType */ get NodeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137442230276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._source !== null)
                {
                    let $switch1 = this._source.NodeType;
                    switch($switch1)
                    {
                        case 1/*XmlNodeType.Element*/:
                        return 1/*XPathNodeType.Element*/;
                        case 2/*XmlNodeType.Attribute*/:
                        /*XAttribute*/ let attribute = $.$cast(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                        return attribute.IsNamespaceDeclaration ? 3/*XPathNodeType.Namespace*/ : 2/*XPathNodeType.Attribute*/;
                        case 9/*XmlNodeType.Document*/:
                        return 0/*XPathNodeType.Root*/;
                        case 8/*XmlNodeType.Comment*/:
                        return 8/*XPathNodeType.Comment*/;
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        return 7/*XPathNodeType.ProcessingInstruction*/;
                        default:
                        return 4/*XPathNodeType.Text*/;
                    }
                }
                return 4/*XPathNodeType.Text*/;
            }
            //--TRIMMABLE-BOUNDARY-END(326420791300)
            
            //--TRIMMABLE-BOUNDARY-START(330715758596)
            /*string */ get Prefix()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146032164868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._nameTable.Add$1(this.GetPrefix());
            }
            //--TRIMMABLE-BOUNDARY-END(330715758596)
            
            //--TRIMMABLE-BOUNDARY-START(197571772420)
            /*string */ GetPrefix()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197571772420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    /*string?*/ let prefix = e.GetPrefixOfNamespace(e.Name.Namespace);
                    if ($.$$.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                    return $.$$.System.String.Empty;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (this._parent !== null)
                    {
                        return $.$$.System.String.Empty;
                    }
                    /*string?*/ let prefix = a.GetPrefixOfNamespace(a.Name.Namespace);
                    if ($.$$.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(197571772420)
            
            //--TRIMMABLE-BOUNDARY-START(377960398852)
            /*object */ get UnderlyingObject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154622099460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._source;
            }
            //--TRIMMABLE-BOUNDARY-END(377960398852)
            
            //--TRIMMABLE-BOUNDARY-START(382255366148)
            /*string */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163212034052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._source !== null)
                {
                    let $switch1 = this._source.NodeType;
                    switch($switch1)
                    {
                        case 1/*XmlNodeType.Element*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XElement)).Value;
                        case 2/*XmlNodeType.Attribute*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XAttribute)).Value;
                        case 9/*XmlNodeType.Document*/:
                        /*XElement?*/ let root = ($.$cast(this._source, $.$spxl.System.Xml.Linq.XDocument)).Root;
                        return root !== null ? root.Value : $.$$.System.String.Empty;
                        case 3/*XmlNodeType.Text*/:
                        case 4/*XmlNodeType.CDATA*/:
                        return $.$spxl.System.Xml.XPath.XNodeNavigator.CollectText($.$cast(this._source, $.$spxl.System.Xml.Linq.XText));
                        case 8/*XmlNodeType.Comment*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XComment)).Value;
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XProcessingInstruction)).Data;
                        default:
                        return $.$$.System.String.Empty;
                    }
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(382255366148)
            
            //--TRIMMABLE-BOUNDARY-START(34363015172)
            /*XPathNavigator */ Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363015172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$spxl.System.Xml.XPath.XNodeNavigator().$ctor$4(this);
            }
            //--TRIMMABLE-BOUNDARY-END(34363015172)
            
            //--TRIMMABLE-BOUNDARY-START(227636543492)
            /*bool */ IsSamePosition(/*XPathNavigator*/ navigator)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227636543492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNodeNavigator?*/ let other = $.$as(navigator, $.$spxl.System.Xml.XPath.XNodeNavigator);
                if (other === null)
                {
                    return false;
                }
                return $.$spxl.System.Xml.XPath.XNodeNavigator.IsSamePosition$1(this, other);
            }
            //--TRIMMABLE-BOUNDARY-END(227636543492)
            
            //--TRIMMABLE-BOUNDARY-START(244816412676)
            /*bool */ MoveTo(/*XPathNavigator*/ navigator)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244816412676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNodeNavigator?*/ let other = $.$as(navigator, $.$spxl.System.Xml.XPath.XNodeNavigator);
                if (other !== null)
                {
                    this._source = other._source;
                    this._parent = other._parent;
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(244816412676)
            
            //--TRIMMABLE-BOUNDARY-START(249111379972)
            /*bool */ MoveToAttribute(/*string*/ localName, /*string*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249111379972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    var $en3 = e.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var attribute = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$$.System.String.op_Equality(attribute.Name.LocalName, localName) && $.$$.System.String.op_Equality(attribute.Name.NamespaceName, namespaceName) && !attribute.IsNamespaceDeclaration)
                            {
                                this._source = attribute;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(249111379972)
            
            //--TRIMMABLE-BOUNDARY-START(253406347268)
            /*bool */ MoveToChild(/*string*/ localName, /*string*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253406347268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XContainer?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (c !== null)
                {
                    var $en3 = c.Elements().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$$.System.String.op_Equality(element.Name.LocalName, localName) && $.$$.System.String.op_Equality(element.Name.NamespaceName, namespaceName))
                            {
                                this._source = element;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(253406347268)
            
            //--TRIMMABLE-BOUNDARY-START(257701314564)
            /*bool */ MoveToChild$1(/*XPathNodeType*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257701314564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XContainer?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (c !== null)
                {
                    /*int*/ let mask = $.$spxl.System.Xml.XPath.XNodeNavigator.GetElementContentMask(type);
                    if ((24/*TextMask*/ & mask) !== 0 && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(c) === null && $.$is(c, $.$spxl.System.Xml.Linq.XDocument))
                    {
                        mask &= ~24/*TextMask*/;
                    }
                    var $en3 = c.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (((1 << node.NodeType) & mask) !== 0)
                            {
                                this._source = node;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(257701314564)
            
            //--TRIMMABLE-BOUNDARY-START(261996281860)
            /*bool */ MoveToFirstAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261996281860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    var $en3 = e.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var attribute = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!attribute.IsNamespaceDeclaration)
                            {
                                this._source = attribute;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(261996281860)
            
            //--TRIMMABLE-BOUNDARY-START(266291249156)
            /*bool */ MoveToFirstChild()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266291249156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XContainer?*/ let container = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (container !== null)
                {
                    var $en3 = container.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, node))
                            {
                                this._source = node;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(266291249156)
            
            //--TRIMMABLE-BOUNDARY-START(270586216452)
            /*bool */ MoveToFirstNamespace$1(/*XPathNamespaceScope*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270586216452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    /*XAttribute?*/ let a = null;
                    switch(scope)
                    {
                        case 2/*XPathNamespaceScope.Local*/:
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationLocal(e);
                        break;
                        case 1/*XPathNamespaceScope.ExcludeXml*/:
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e);
                        while(a !== null && $.$$.System.String.op_Equality(a.Name.LocalName, "xml"))
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                        }
                        break;
                        case 0/*XPathNamespaceScope.All*/:
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e) ?? $.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration();
                        break;
                    }
                    if (a !== null)
                    {
                        this._source = a;
                        this._parent = e;
                        return true;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(270586216452)
            
            //--TRIMMABLE-BOUNDARY-START(274881183748)
            /*bool */ MoveToId(/*string*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274881183748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$12($.$spxl.System.SR.NotSupported_MoveToId);
            }
            //--TRIMMABLE-BOUNDARY-END(274881183748)
            
            //--TRIMMABLE-BOUNDARY-START(279176151044)
            /*bool */ MoveToNamespace(/*string*/ localName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279176151044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if ($.$$.System.String.op_Equality(localName, "xmlns"))
                    {
                        return false;
                    }
                    if ($.$$.System.String.op_Inequality(localName, null) && localName.length === 0)
                    {
                        localName = "xmlns";
                    }
                    /*XAttribute?*/ let a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e);
                    while(a !== null)
                    {
                        if ($.$$.System.String.op_Equality(a.Name.LocalName, localName))
                        {
                            this._source = a;
                            this._parent = e;
                            return true;
                        }
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                    }
                    if ($.$$.System.String.op_Equality(localName, "xml"))
                    {
                        this._source = $.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration();
                        this._parent = e;
                        return true;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(279176151044)
            
            //--TRIMMABLE-BOUNDARY-START(283471118340)
            /*bool */ MoveToNext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283471118340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    /*XContainer?*/ let container = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentNode);
                    if (container !== null)
                    {
                        /*XNode?*/ let next;
                        for(/*XNode*/ let node = currentNode; node !== null; node = next)
                        {
                            next = node.NextNode;
                            if (next === null)
                            {
                                break;
                            }
                            if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, next) && !($.$is(node, $.$spxl.System.Xml.Linq.XText) && $.$is(next, $.$spxl.System.Xml.Linq.XText)))
                            {
                                this._source = next;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(283471118340)
            
            //--TRIMMABLE-BOUNDARY-START(287766085636)
            /*bool */ MoveToNext$1(/*string*/ localName, /*string*/ namespaceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287766085636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    var $en3 = currentNode.ElementsAfterSelf().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$$.System.String.op_Equality(element.Name.LocalName, localName) && $.$$.System.String.op_Equality(element.Name.NamespaceName, namespaceName))
                            {
                                this._source = element;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(287766085636)
            
            //--TRIMMABLE-BOUNDARY-START(292061052932)
            /*bool */ MoveToNext$2(/*XPathNodeType*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292061052932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    /*XContainer?*/ let container = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentNode);
                    if (container !== null)
                    {
                        /*int*/ let mask = $.$spxl.System.Xml.XPath.XNodeNavigator.GetElementContentMask(type);
                        if ((24/*TextMask*/ & mask) !== 0 && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(container) === null && $.$is(container, $.$spxl.System.Xml.Linq.XDocument))
                        {
                            mask &= ~24/*TextMask*/;
                        }
                        /*XNode?*/ let next;
                        for(/*XNode*/ let node = currentNode; ; node = next)
                        {
                            next = node.NextNode;
                            if (next === null)
                            {
                                break;
                            }
                            if (((1 << next.NodeType) & mask) !== 0 && !($.$is(node, $.$spxl.System.Xml.Linq.XText) && $.$is(next, $.$spxl.System.Xml.Linq.XText)))
                            {
                                this._source = next;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(292061052932)
            
            //--TRIMMABLE-BOUNDARY-START(296356020228)
            /*bool */ MoveToNextAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296356020228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XAttribute?*/ let currentAttribute = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (currentAttribute !== null && this._parent === null)
                {
                    /*XElement?*/ let e = $.$cast($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentAttribute), $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        for(/*XAttribute?*/ let attribute = currentAttribute.NextAttribute; attribute !== null; attribute = attribute.NextAttribute)
                        {
                            if (!attribute.IsNamespaceDeclaration)
                            {
                                this._source = attribute;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(296356020228)
            
            //--TRIMMABLE-BOUNDARY-START(300650987524)
            /*bool */ MoveToNextNamespace$1(/*XPathNamespaceScope*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300650987524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null && this._parent !== null && !$.$spxl.System.Xml.XPath.XNodeNavigator.IsXmlNamespaceDeclaration(a))
                {
                    switch(scope)
                    {
                        case 2/*XPathNamespaceScope.Local*/:
                        if ($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(a) !== this._parent)
                        {
                            return false;
                        }
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationLocal(a);
                        break;
                        case 1/*XPathNamespaceScope.ExcludeXml*/:
                        do
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                        }
                        while(a !== null && ($.$$.System.String.op_Equality(a.Name.LocalName, "xml") || $.$spxl.System.Xml.XPath.XNodeNavigator.HasNamespaceDeclarationInScope(a, this._parent)));
                        break;
                        case 0/*XPathNamespaceScope.All*/:
                        do
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                        }
                        while(a !== null && $.$spxl.System.Xml.XPath.XNodeNavigator.HasNamespaceDeclarationInScope(a, this._parent));
                        if (a === null && !$.$spxl.System.Xml.XPath.XNodeNavigator.HasNamespaceDeclarationInScope($.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration(), this._parent))
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration();
                        }
                        break;
                    }
                    if (a !== null)
                    {
                        this._source = a;
                        return true;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(300650987524)
            
            //--TRIMMABLE-BOUNDARY-START(304945954820)
            /*bool */ MoveToParent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304945954820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._parent !== null)
                {
                    this._source = this._parent;
                    this._parent = null;
                    return true;
                }
                /*XNode?*/ let parentNode = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(this._source);
                if (parentNode !== null)
                {
                    this._source = parentNode;
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(304945954820)
            
            //--TRIMMABLE-BOUNDARY-START(309240922116)
            /*bool */ MoveToPrevious()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309240922116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    /*XContainer?*/ let container = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentNode);
                    if (container !== null)
                    {
                        /*XNode?*/ let previous = null;
                        var $en4 = container.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var node = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (node === currentNode)
                                {
                                    if (previous !== null)
                                    {
                                        this._source = previous;
                                        return true;
                                    }
                                    return false;
                                }
                                if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, node))
                                {
                                    previous = node;
                                }
                            }
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(309240922116)
            
            //--TRIMMABLE-BOUNDARY-START(335010725892)
            /*XmlReader */ ReadSubtree()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335010725892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XContainer?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (c === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$6($.$spxl.System.SR.InvalidOperation_BadNodeType, $.$box(this.NodeType, $.$spx.System.Xml.XPath.XPathNodeType)));
                }
                return c.CreateReader();
            }
            //--TRIMMABLE-BOUNDARY-END(335010725892)
            
            //--TRIMMABLE-BOUNDARY-START(360780529668)
            /*bool */ System$Xml$IXmlLineInfo$HasLineInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360780529668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IXmlLineInfo*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                if (li !== null)
                {
                    return li.System$Xml$IXmlLineInfo$HasLineInfo();
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(360780529668)
            
            //--TRIMMABLE-BOUNDARY-START(365075496964)
            /*int */ get System$Xml$IXmlLineInfo$LineNumber()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347895627780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IXmlLineInfo*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                if (li !== null)
                {
                    return li.System$Xml$IXmlLineInfo$LineNumber;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(365075496964)
            
            //--TRIMMABLE-BOUNDARY-START(369370464260)
            /*int */ get System$Xml$IXmlLineInfo$LinePosition()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356485562372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IXmlLineInfo*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                if (li !== null)
                {
                    return li.System$Xml$IXmlLineInfo$LinePosition;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(369370464260)
            
            //--TRIMMABLE-BOUNDARY-START(38657982468)
            static /*string */ CollectText(/*XText*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657982468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let s = n.Value;
                if ($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n) !== null)
                {
                    var $en3 = n.NodesAfterSelf().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            /*XText?*/ let t = $.$as(node, $.$spxl.System.Xml.Linq.XText);
                            if (t === null)
                            {
                                break;
                            }
                            s += t.Value;
                        }
                    }
                }
                return s;
            }
            //--TRIMMABLE-BOUNDARY-END(38657982468)
            
            //--TRIMMABLE-BOUNDARY-START(42952949764)
            static /*NameTable */ CreateNameTable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952949764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let nameTable = new $.$spx.System.Xml.NameTable().$ctor$2();
                nameTable.Add$1($.$$.System.String.Empty);
                nameTable.Add$1($.$spxl.System.Xml.XPath.XNodeNavigator.xmlnsPrefixNamespace);
                nameTable.Add$1($.$spxl.System.Xml.XPath.XNodeNavigator.xmlPrefixNamespace);
                return nameTable;
            }
            //--TRIMMABLE-BOUNDARY-END(42952949764)
            
            //--TRIMMABLE-BOUNDARY-START(219046608900)
            static /*bool */ IsContent(/*XContainer*/ c, /*XNode*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219046608900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(c) !== null || $.$is(c, $.$spxl.System.Xml.Linq.XElement))
                {
                    return true;
                }
                return ((1 << n.NodeType) & 386/*DocumentContentMask*/) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(219046608900)
            
            //--TRIMMABLE-BOUNDARY-START(231931510788)
            static /*bool */ IsSamePosition$1(/*XNodeNavigator*/ n1, /*XNodeNavigator*/ n2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231931510788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return n1._source === n2._source && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n1._source) === $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n2._source);
            }
            //--TRIMMABLE-BOUNDARY-END(231931510788)
            
            //--TRIMMABLE-BOUNDARY-START(236226478084)
            static /*bool */ IsXmlNamespaceDeclaration(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236226478084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast(a, $.$$.System.Object) === $.$cast($.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration(), $.$$.System.Object);
            }
            //--TRIMMABLE-BOUNDARY-END(236226478084)
            
            //--TRIMMABLE-BOUNDARY-START(167507001348)
            static /*int */ GetElementContentMask(/*XPathNodeType*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167507001348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.XPath.XNodeNavigator.ElementContentMasks.get_Item(type).$v;
            }
            //--TRIMMABLE-BOUNDARY-END(167507001348)
            
            //--TRIMMABLE-BOUNDARY-START(171801968644)
            static /*XAttribute? */ GetFirstNamespaceDeclarationGlobal(/*XElement*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801968644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let ce = e;
                do
                {
                    /*XAttribute?*/ let a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationLocal(ce);
                    if (a !== null)
                    {
                        return a;
                    }
                    ce = ce.Parent;
                }
                while(ce !== null);
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(171801968644)
            
            //--TRIMMABLE-BOUNDARY-START(176096935940)
            static /*XAttribute? */ GetFirstNamespaceDeclarationLocal(/*XElement*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096935940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = e.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var attribute = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (attribute.IsNamespaceDeclaration)
                        {
                            return attribute;
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(176096935940)
            
            //--TRIMMABLE-BOUNDARY-START(188981837828)
            static /*XAttribute? */ GetNextNamespaceDeclarationGlobal(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188981837828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = $.$cast($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(a), $.$spxl.System.Xml.Linq.XElement);
                if (e === null)
                {
                    return null;
                }
                /*XAttribute?*/ let next = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationLocal(a);
                if (next !== null)
                {
                    return next;
                }
                e = e.Parent;
                if (e === null)
                {
                    return null;
                }
                return $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e);
            }
            //--TRIMMABLE-BOUNDARY-END(188981837828)
            
            //--TRIMMABLE-BOUNDARY-START(193276805124)
            static /*XAttribute? */ GetNextNamespaceDeclarationLocal(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193276805124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = a.Parent;
                if (e === null)
                {
                    return null;
                }
                /*XAttribute?*/ let ca = a;
                ca = ca.NextAttribute;
                while(ca !== null)
                {
                    if (ca.IsNamespaceDeclaration)
                    {
                        return ca;
                    }
                    ca = ca.NextAttribute;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(193276805124)
            
            //--TRIMMABLE-BOUNDARY-START(201866739716)
            static /*XAttribute */ GetXmlNamespaceDeclaration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201866739716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration === null)
                {
                    $.$$.System.Threading.Interlocked.CompareExchange$14($.$spxl.System.Xml.Linq.XAttribute, $.$ref(() => $.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration, ($v) => $.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration = $v, $.$spxl.System.Xml.Linq.XAttribute), new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3($.$spxl.System.Xml.Linq.XNamespace.Xmlns.GetName$1("xml"), $.$spxl.System.Xml.XPath.XNodeNavigator.xmlPrefixNamespace), null);
                }
                return $.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration;
            }
            //--TRIMMABLE-BOUNDARY-END(201866739716)
            
            //--TRIMMABLE-BOUNDARY-START(214751641604)
            static /*bool */ HasNamespaceDeclarationInScope(/*XAttribute*/ a, /*XElement*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214751641604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XName*/ let name = a.Name;
                /*XElement?*/ let ce = e;
                while(ce !== null && ce !== $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(a))
                {
                    if (ce.Attribute(name) !== null)
                    {
                        return true;
                    }
                    ce = ce.Parent;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(214751641604)
            
            //--TRIMMABLE-BOUNDARY-START(17183145988)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(390845300740)
                    this.xmlPrefixNamespace = $.$spxl.System.Xml.Linq.XNamespace.Xml.NamespaceName;
                    //--TRIMMABLE-BOUNDARY-END(390845300740)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386550333444)
                    this.xmlnsPrefixNamespace = $.$spxl.System.Xml.Linq.XNamespace.Xmlns.NamespaceName;
                    //--TRIMMABLE-BOUNDARY-END(386550333444)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17183145988)
            
            static $h = 3276804;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 59244547,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542884356),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68722753540,
        "f": 50331682
      },
      "n": "ElementContentMasks",
      "d": 3276804,
      "h": 51542884356,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(51542884356),
//--TRIMMABLE-BOUNDARY-START(30068047876),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132818948,
        "f": 50364417
      },
      "n": "BaseURI",
      "d": 3276804,
      "h": 30068047876,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30068047876),
//--TRIMMABLE-BOUNDARY-START(206161707012),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77312688132,
        "f": 50364417
      },
      "n": "HasAttributes",
      "d": 3276804,
      "h": 206161707012,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(206161707012),
//--TRIMMABLE-BOUNDARY-START(210456674308),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85902622724,
        "f": 50364417
      },
      "n": "HasChildren",
      "d": 3276804,
      "h": 210456674308,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(210456674308),
//--TRIMMABLE-BOUNDARY-START(223341576196),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94492557316,
        "f": 50364417
      },
      "n": "IsEmptyElement",
      "d": 3276804,
      "h": 223341576196,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(223341576196),
//--TRIMMABLE-BOUNDARY-START(240521445380),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103082491908,
        "f": 50364417
      },
      "n": "LocalName",
      "d": 3276804,
      "h": 240521445380,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(240521445380),
//--TRIMMABLE-BOUNDARY-START(313535889412),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111672426500,
        "f": 50364417
      },
      "n": "Name",
      "d": 3276804,
      "h": 313535889412,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(313535889412),
//--TRIMMABLE-BOUNDARY-START(317830856708),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120262361092,
        "f": 50364417
      },
      "n": "NamespaceURI",
      "d": 3276804,
      "h": 317830856708,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(317830856708),
//--TRIMMABLE-BOUNDARY-START(322125824004),
    {
      "p": 52035587,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128852295684,
        "f": 50364417
      },
      "n": "NameTable",
      "d": 3276804,
      "h": 322125824004,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(322125824004),
//--TRIMMABLE-BOUNDARY-START(326420791300),
    {
      "p": 59834371,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137442230276,
        "f": 50364417
      },
      "n": "NodeType",
      "d": 3276804,
      "h": 326420791300,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(326420791300),
//--TRIMMABLE-BOUNDARY-START(330715758596),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146032164868,
        "f": 50364417
      },
      "n": "Prefix",
      "d": 3276804,
      "h": 330715758596,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(330715758596),
//--TRIMMABLE-BOUNDARY-START(377960398852),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154622099460,
        "f": 50364417
      },
      "n": "UnderlyingObject",
      "d": 3276804,
      "h": 377960398852,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(377960398852),
//--TRIMMABLE-BOUNDARY-START(382255366148),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163212034052,
        "f": 50364417
      },
      "n": "Value",
      "d": 3276804,
      "h": 382255366148,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(382255366148),
//--TRIMMABLE-BOUNDARY-START(365075496964),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 347895627780,
        "f": 50331650
      },
      "n": "{13893635}.LineNumber",
      "o": "System$Xml$IXmlLineInfo$LineNumber",
      "d": 3276804,
      "h": 365075496964,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(365075496964),
//--TRIMMABLE-BOUNDARY-START(369370464260),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 356485562372,
        "f": 50331650
      },
      "n": "{13893635}.LinePosition",
      "o": "System$Xml$IXmlLineInfo$LinePosition",
      "d": 3276804,
      "h": 369370464260,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(369370464260)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(180391903236),
    {
      "r": 1310721,
      "n": "GetLocalName",
      "d": 3276804,
      "h": 180391903236,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180391903236),
//--TRIMMABLE-BOUNDARY-START(184686870532),
    {
      "r": 1310721,
      "n": "GetNamespaceURI",
      "d": 3276804,
      "h": 184686870532,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(184686870532),
//--TRIMMABLE-BOUNDARY-START(197571772420),
    {
      "r": 1310721,
      "n": "GetPrefix",
      "d": 3276804,
      "h": 197571772420,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(197571772420),
//--TRIMMABLE-BOUNDARY-START(34363015172),
    {
      "r": 59244547,
      "n": "Clone",
      "d": 3276804,
      "h": 34363015172,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34363015172),
//--TRIMMABLE-BOUNDARY-START(227636543492),
    {
      "r": 262145,
      "p": [
        {
          "n": "navigator",
          "p": 59244547
        }
      ],
      "n": "IsSamePosition",
      "d": 3276804,
      "h": 227636543492,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(227636543492),
//--TRIMMABLE-BOUNDARY-START(244816412676),
    {
      "r": 262145,
      "p": [
        {
          "n": "navigator",
          "p": 59244547
        }
      ],
      "n": "MoveTo",
      "d": 3276804,
      "h": 244816412676,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(244816412676),
//--TRIMMABLE-BOUNDARY-START(249111379972),
    {
      "r": 262145,
      "p": [
        {
          "n": "localName",
          "p": 1310721
        },
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "MoveToAttribute",
      "d": 3276804,
      "h": 249111379972,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(249111379972),
//--TRIMMABLE-BOUNDARY-START(253406347268),
    {
      "r": 262145,
      "p": [
        {
          "n": "localName",
          "p": 1310721
        },
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "MoveToChild",
      "d": 3276804,
      "h": 253406347268,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(253406347268),
//--TRIMMABLE-BOUNDARY-START(257701314564),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 59834371
        }
      ],
      "n": "MoveToChild",
      "o": "@$1",
      "d": 3276804,
      "h": 257701314564,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(257701314564),
//--TRIMMABLE-BOUNDARY-START(261996281860),
    {
      "r": 262145,
      "n": "MoveToFirstAttribute",
      "d": 3276804,
      "h": 261996281860,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(261996281860),
//--TRIMMABLE-BOUNDARY-START(266291249156),
    {
      "r": 262145,
      "n": "MoveToFirstChild",
      "d": 3276804,
      "h": 266291249156,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(266291249156),
//--TRIMMABLE-BOUNDARY-START(270586216452),
    {
      "r": 262145,
      "p": [
        {
          "n": "scope",
          "p": 59179011
        }
      ],
      "n": "MoveToFirstNamespace",
      "o": "@$1",
      "d": 3276804,
      "h": 270586216452,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(270586216452),
//--TRIMMABLE-BOUNDARY-START(274881183748),
    {
      "r": 262145,
      "p": [
        {
          "n": "id",
          "p": 1310721
        }
      ],
      "n": "MoveToId",
      "d": 3276804,
      "h": 274881183748,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(274881183748),
//--TRIMMABLE-BOUNDARY-START(279176151044),
    {
      "r": 262145,
      "p": [
        {
          "n": "localName",
          "p": 1310721
        }
      ],
      "n": "MoveToNamespace",
      "d": 3276804,
      "h": 279176151044,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(279176151044),
//--TRIMMABLE-BOUNDARY-START(283471118340),
    {
      "r": 262145,
      "n": "MoveToNext",
      "d": 3276804,
      "h": 283471118340,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(283471118340),
//--TRIMMABLE-BOUNDARY-START(287766085636),
    {
      "r": 262145,
      "p": [
        {
          "n": "localName",
          "p": 1310721
        },
        {
          "n": "namespaceName",
          "p": 1310721
        }
      ],
      "n": "MoveToNext",
      "o": "@$1",
      "d": 3276804,
      "h": 287766085636,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(287766085636),
//--TRIMMABLE-BOUNDARY-START(292061052932),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 59834371
        }
      ],
      "n": "MoveToNext",
      "o": "@$2",
      "d": 3276804,
      "h": 292061052932,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(292061052932),
//--TRIMMABLE-BOUNDARY-START(296356020228),
    {
      "r": 262145,
      "n": "MoveToNextAttribute",
      "d": 3276804,
      "h": 296356020228,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(296356020228),
//--TRIMMABLE-BOUNDARY-START(300650987524),
    {
      "r": 262145,
      "p": [
        {
          "n": "scope",
          "p": 59179011
        }
      ],
      "n": "MoveToNextNamespace",
      "o": "@$1",
      "d": 3276804,
      "h": 300650987524,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(300650987524),
//--TRIMMABLE-BOUNDARY-START(304945954820),
    {
      "r": 262145,
      "n": "MoveToParent",
      "d": 3276804,
      "h": 304945954820,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(304945954820),
//--TRIMMABLE-BOUNDARY-START(309240922116),
    {
      "r": 262145,
      "n": "MoveToPrevious",
      "d": 3276804,
      "h": 309240922116,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(309240922116),
//--TRIMMABLE-BOUNDARY-START(335010725892),
    {
      "r": 53346307,
      "n": "ReadSubtree",
      "d": 3276804,
      "h": 335010725892,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(335010725892),
//--TRIMMABLE-BOUNDARY-START(38657982468),
    {
      "r": 1310721,
      "p": [
        {
          "n": "n",
          "p": 2949124
        }
      ],
      "n": "CollectText",
      "d": 3276804,
      "h": 38657982468,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38657982468),
//--TRIMMABLE-BOUNDARY-START(42952949764),
    {
      "r": 14221315,
      "n": "CreateNameTable",
      "d": 3276804,
      "h": 42952949764,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42952949764),
//--TRIMMABLE-BOUNDARY-START(219046608900),
    {
      "r": 262145,
      "p": [
        {
          "n": "c",
          "p": 1310724
        },
        {
          "n": "n",
          "p": 2228228
        }
      ],
      "n": "IsContent",
      "d": 3276804,
      "h": 219046608900,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(219046608900),
//--TRIMMABLE-BOUNDARY-START(231931510788),
    {
      "r": 262145,
      "p": [
        {
          "n": "n1",
          "p": 3276804
        },
        {
          "n": "n2",
          "p": 3276804
        }
      ],
      "n": "IsSamePosition",
      "o": "@$1",
      "d": 3276804,
      "h": 231931510788,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(231931510788),
//--TRIMMABLE-BOUNDARY-START(236226478084),
    {
      "r": 262145,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "IsXmlNamespaceDeclaration",
      "d": 3276804,
      "h": 236226478084,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(236226478084),
//--TRIMMABLE-BOUNDARY-START(167507001348),
    {
      "r": 655361,
      "p": [
        {
          "n": "type",
          "p": 59834371
        }
      ],
      "n": "GetElementContentMask",
      "d": 3276804,
      "h": 167507001348,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(167507001348),
//--TRIMMABLE-BOUNDARY-START(171801968644),
    {
      "r": 1114116,
      "p": [
        {
          "n": "e",
          "p": 1638404
        }
      ],
      "n": "GetFirstNamespaceDeclarationGlobal",
      "d": 3276804,
      "h": 171801968644,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(171801968644),
//--TRIMMABLE-BOUNDARY-START(176096935940),
    {
      "r": 1114116,
      "p": [
        {
          "n": "e",
          "p": 1638404
        }
      ],
      "n": "GetFirstNamespaceDeclarationLocal",
      "d": 3276804,
      "h": 176096935940,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(176096935940),
//--TRIMMABLE-BOUNDARY-START(188981837828),
    {
      "r": 1114116,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "GetNextNamespaceDeclarationGlobal",
      "d": 3276804,
      "h": 188981837828,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(188981837828),
//--TRIMMABLE-BOUNDARY-START(193276805124),
    {
      "r": 1114116,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "GetNextNamespaceDeclarationLocal",
      "d": 3276804,
      "h": 193276805124,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(193276805124),
//--TRIMMABLE-BOUNDARY-START(201866739716),
    {
      "r": 1114116,
      "n": "GetXmlNamespaceDeclaration",
      "d": 3276804,
      "h": 201866739716,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(201866739716),
//--TRIMMABLE-BOUNDARY-START(214751641604),
    {
      "r": 262145,
      "p": [
        {
          "n": "a",
          "p": 1114116
        },
        {
          "n": "e",
          "p": 1638404
        }
      ],
      "n": "HasNamespaceDeclarationInScope",
      "d": 3276804,
      "h": 214751641604,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(214751641604)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(390845300740),
    {
      "t": 1310721,
      "n": "xmlPrefixNamespace",
      "d": 3276804,
      "h": 390845300740,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390845300740),
//--TRIMMABLE-BOUNDARY-START(386550333444),
    {
      "t": 1310721,
      "n": "xmlnsPrefixNamespace",
      "d": 3276804,
      "h": 386550333444,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386550333444),
//--TRIMMABLE-BOUNDARY-START(47247917060),
    {
      "t": 655361,
      "n": "DocumentContentMask",
      "d": 3276804,
      "h": 47247917060,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47247917060),
//--TRIMMABLE-BOUNDARY-START(373665431556),
    {
      "t": 655361,
      "n": "TextMask",
      "o": "@$1",
      "d": 3276804,
      "h": 373665431556,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(373665431556),
//--TRIMMABLE-BOUNDARY-START(339305693188),
    {
      "t": 1114116,
      "n": "s_XmlNamespaceDeclaration",
      "d": 3276804,
      "h": 339305693188,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(339305693188),
//--TRIMMABLE-BOUNDARY-START(12888178692),
    {
      "t": 2555908,
      "n": "_source",
      "d": 3276804,
      "h": 12888178692,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12888178692),
//--TRIMMABLE-BOUNDARY-START(8593211396),
    {
      "t": 1638404,
      "n": "_parent",
      "d": 3276804,
      "h": 8593211396,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593211396),
//--TRIMMABLE-BOUNDARY-START(4298244100),
    {
      "t": 52035587,
      "n": "_nameTable",
      "d": 3276804,
      "h": 4298244100,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298244100)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21478113284),
    {
      "p": [
        {
          "n": "node",
          "p": 2228228
        },
        {
          "n": "nameTable",
          "p": 52035587
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3276804,
      "h": 21478113284,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478113284),
//--TRIMMABLE-BOUNDARY-START(25773080580),
    {
      "p": [
        {
          "n": "other",
          "p": 3276804
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3276804,
      "h": 25773080580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25773080580)
  ],
  "i": [89980929,58523651,13959171,13893635
  ],
  "h": 3276804
}; }
            static get $b() { return $.$spx.System.Xml.XPath.XPathNavigator; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$spx.System.Xml.XPath.IXPathNavigable, $.$spx.System.Xml.IXmlNamespaceResolver, $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.XPath.XNodeNavigator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3276804)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507332)
        $asm.$cls("$spxl.System.Xml.Linq.XDocument", ($self) => class XDocument extends $.$spxl.System.Xml.Linq.XContainer
        {
            //--TRIMMABLE-BOUNDARY-START(4296474628)
            /*XDeclaration?*/ _declaration = null;
            //--TRIMMABLE-BOUNDARY-END(4296474628)
            
            //--TRIMMABLE-BOUNDARY-START(8591441924)
            $ctor$5()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591441924);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591441924)
            
            //--TRIMMABLE-BOUNDARY-START(12886409220)
            $ctor$6(/*params object?[]*/ content)
            {
                this.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886409220);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.AddContentSkipNotify(content);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886409220)
            
            //--TRIMMABLE-BOUNDARY-START(17181376516)
            $ctor$7(/*XDeclaration?*/ declaration, /*params object?[]*/ content)
            {
                this.$ctor$6(content);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181376516);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._declaration = declaration;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181376516)
            
            //--TRIMMABLE-BOUNDARY-START(21476343812)
            $ctor$8(/*XDocument*/ other)
            {
                super.$ctor$4(other);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476343812);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (other._declaration !== null)
                    {
                        this._declaration = new $.$spxl.System.Xml.Linq.XDeclaration().$ctor$3(other._declaration);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476343812)
            
            //--TRIMMABLE-BOUNDARY-START(38656212996)
            /*XDeclaration? */ get Declaration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836082180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._declaration;
            }
            /*XDeclaration? */ set Declaration(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749872132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._declaration = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38656212996)
            
            //--TRIMMABLE-BOUNDARY-START(47246147588)
            /*XDocumentType? */ get DocumentType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426016772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFirstNode($.$spxl.System.Xml.Linq.XDocumentType);
            }
            //--TRIMMABLE-BOUNDARY-END(47246147588)
            
            //--TRIMMABLE-BOUNDARY-START(150325362692)
            /*XmlNodeType */ get NodeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015951364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 9/*XmlNodeType.Document*/;
            }
            //--TRIMMABLE-BOUNDARY-END(150325362692)
            
            //--TRIMMABLE-BOUNDARY-START(163210264580)
            /*XElement? */ get Root()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605885956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFirstNode($.$spxl.System.Xml.Linq.XElement);
            }
            //--TRIMMABLE-BOUNDARY-END(163210264580)
            
            //--TRIMMABLE-BOUNDARY-START(120260591620)
            static /*XDocument */ Load$5(/*string*/ uri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260591620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XDocument.Load$4(uri, 0/*LoadOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(120260591620)
            
            //--TRIMMABLE-BOUNDARY-START(115965624324)
            static /*XDocument */ Load$4(/*string*/ uri, /*LoadOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965624324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$9(uri, rs);
                    return $.$spxl.System.Xml.Linq.XDocument.Load$6(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115965624324)
            
            //--TRIMMABLE-BOUNDARY-START(103080722436)
            static /*XDocument */ Load$1(/*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080722436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XDocument.Load(stream, 0/*LoadOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(103080722436)
            
            //--TRIMMABLE-BOUNDARY-START(98785755140)
            static /*XDocument */ Load(/*Stream*/ stream, /*LoadOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785755140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$2(stream, rs);
                    return $.$spxl.System.Xml.Linq.XDocument.Load$6(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785755140)
            
            //--TRIMMABLE-BOUNDARY-START(133145493508)
            static /*Task<XDocument> *//*async*/  LoadAsync(/*Stream*/ stream, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument), $.$spxl.System.Xml.Linq.XDocument, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133145493508);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$2(stream, rs);
                        return await $.$spxl.System.Xml.Linq.XDocument.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(133145493508)
            
            //--TRIMMABLE-BOUNDARY-START(111670657028)
            static /*XDocument */ Load$3(/*TextReader*/ textReader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670657028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XDocument.Load$2(textReader, 0/*LoadOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(111670657028)
            
            //--TRIMMABLE-BOUNDARY-START(107375689732)
            static /*XDocument */ Load$2(/*TextReader*/ textReader, /*LoadOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375689732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$6(textReader, rs);
                    return $.$spxl.System.Xml.Linq.XDocument.Load$6(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107375689732)
            
            //--TRIMMABLE-BOUNDARY-START(137440460804)
            static /*Task<XDocument> *//*async*/  LoadAsync$1(/*TextReader*/ textReader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument), $.$spxl.System.Xml.Linq.XDocument, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137440460804);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$6(textReader, rs);
                        return await $.$spxl.System.Xml.Linq.XDocument.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(137440460804)
            
            //--TRIMMABLE-BOUNDARY-START(128850526212)
            static /*XDocument */ Load$7(/*XmlReader*/ reader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850526212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XDocument.Load$6(reader, 0/*LoadOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(128850526212)
            
            //--TRIMMABLE-BOUNDARY-START(124555558916)
            static /*XDocument */ Load$6(/*XmlReader*/ reader, /*LoadOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555558916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                if (reader.ReadState === 0/*ReadState.Initial*/)
                {
                    reader.Read();
                }
                /*XDocument*/ let d = $.$spxl.System.Xml.Linq.XDocument.InitLoad(reader, options);
                d.ReadContentFrom(reader, options);
                if (!reader.EOF)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                }
                if (d.Root === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingRoot);
                }
                return d;
            }
            //--TRIMMABLE-BOUNDARY-END(124555558916)
            
            //--TRIMMABLE-BOUNDARY-START(141735428100)
            static /*Task<XDocument> */ LoadAsync$2(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735428100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$3($.$spxl.System.Xml.Linq.XDocument, cancellationToken);
                }
                return $.$spxl.System.Xml.Linq.XDocument.LoadAsyncInternal(reader, options, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(141735428100)
            
            //--TRIMMABLE-BOUNDARY-START(146030395396)
            static /*Task<XDocument> *//*async*/  LoadAsyncInternal(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument), $.$spxl.System.Xml.Linq.XDocument, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146030395396);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (reader.ReadState === 0/*ReadState.Initial*/)
                    {
                        await reader.ReadAsync().ConfigureAwait$2(false);
                    }
                    /*XDocument*/ let d = $.$spxl.System.Xml.Linq.XDocument.InitLoad(reader, options);
                    await d.ReadContentFromAsync$1(reader, options, cancellationToken).ConfigureAwait(false);
                    if (!reader.EOF)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                    }
                    if (d.Root === null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_MissingRoot);
                    }
                    return d;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(146030395396)
            
            //--TRIMMABLE-BOUNDARY-START(94490787844)
            static /*XDocument */ InitLoad(/*XmlReader*/ reader, /*LoadOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490787844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XDocument*/ let d = new $.$spxl.System.Xml.Linq.XDocument().$ctor$5();
                if ((options & 2/*LoadOptions.SetBaseUri*/) !== 0)
                {
                    /*string?*/ let baseUri = reader.BaseURI;
                    if (!$.$$.System.String.IsNullOrEmpty(baseUri))
                    {
                        d.SetBaseUri(baseUri);
                    }
                }
                if ((options & 4/*LoadOptions.SetLineInfo*/) !== 0)
                {
                    /*IXmlLineInfo?*/ let li = $.$as(reader, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null && li.System$Xml$IXmlLineInfo$HasLineInfo())
                    {
                        d.SetLineInfo(li.System$Xml$IXmlLineInfo$LineNumber, li.System$Xml$IXmlLineInfo$LinePosition);
                    }
                }
                if (reader.NodeType === 17/*XmlNodeType.XmlDeclaration*/)
                {
                    d.Declaration = new $.$spxl.System.Xml.Linq.XDeclaration().$ctor$2(reader);
                }
                return d;
            }
            //--TRIMMABLE-BOUNDARY-END(94490787844)
            
            //--TRIMMABLE-BOUNDARY-START(158915297284)
            static /*XDocument */ Parse$1(/*string*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915297284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XDocument.Parse(text, 0/*LoadOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(158915297284)
            
            //--TRIMMABLE-BOUNDARY-START(154620329988)
            static /*XDocument */ Parse(/*string*/ text, /*LoadOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620329988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let sr = null;
                try
                {
                    sr = new $.$$.System.IO.StringReader().$ctor$3(text);
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$6(sr, rs);
                        return $.$spxl.System.Xml.Linq.XDocument.Load$6(r, options);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                }
                finally
                {
                    sr?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154620329988)
            
            //--TRIMMABLE-BOUNDARY-START(171800199172)
            /*void */ Save$1(/*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800199172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Save(stream, this.GetSaveOptionsFromAnnotations());
            }
            //--TRIMMABLE-BOUNDARY-END(171800199172)
            
            //--TRIMMABLE-BOUNDARY-START(167505231876)
            /*void */ Save(/*Stream*/ stream, /*SaveOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505231876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                if (this._declaration !== null && !$.$$.System.String.IsNullOrEmpty(this._declaration.Encoding))
                {
                    try
                    {
                        ws.Encoding = $.$$.System.Text.Encoding.GetEncoding$3(this._declaration.Encoding);
                    }
                    catch($e)
                    {
                    }
                }
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create(stream, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167505231876)
            
            //--TRIMMABLE-BOUNDARY-START(197570002948)
            /*Task *//*async*/  SaveAsync(/*Stream*/ stream, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197570002948);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    if (this._declaration !== null && !$.$$.System.String.IsNullOrEmpty(this._declaration.Encoding))
                    {
                        try
                        {
                            ws.Encoding = $.$$.System.Text.Encoding.GetEncoding$3(this._declaration.Encoding);
                        }
                        catch($e)
                        {
                        }
                    }
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create(stream, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$$.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.WriteToAsync(w, cancellationToken).ConfigureAwait(false);
                        await w.FlushAsync().ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(197570002948)
            
            //--TRIMMABLE-BOUNDARY-START(180390133764)
            /*void */ Save$3(/*TextWriter*/ textWriter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390133764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Save$2(textWriter, this.GetSaveOptionsFromAnnotations());
            }
            //--TRIMMABLE-BOUNDARY-END(180390133764)
            
            //--TRIMMABLE-BOUNDARY-START(176095166468)
            /*void */ Save$2(/*TextWriter*/ textWriter, /*SaveOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095166468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$2(textWriter, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176095166468)
            
            //--TRIMMABLE-BOUNDARY-START(193275035652)
            /*void */ Save$6(/*XmlWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275035652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteTo(writer);
            }
            //--TRIMMABLE-BOUNDARY-END(193275035652)
            
            //--TRIMMABLE-BOUNDARY-START(201864970244)
            /*Task *//*async*/  SaveAsync$1(/*TextWriter*/ textWriter, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201864970244);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create$2(textWriter, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$$.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.WriteToAsync(w, cancellationToken).ConfigureAwait(false);
                        await w.FlushAsync().ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(201864970244)
            
            //--TRIMMABLE-BOUNDARY-START(188980068356)
            /*void */ Save$5(/*string*/ fileName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980068356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Save$4(fileName, this.GetSaveOptionsFromAnnotations());
            }
            //--TRIMMABLE-BOUNDARY-END(188980068356)
            
            //--TRIMMABLE-BOUNDARY-START(206159937540)
            /*Task */ SaveAsync$2(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159937540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WriteToAsync(writer, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(206159937540)
            
            //--TRIMMABLE-BOUNDARY-START(184685101060)
            /*void */ Save$4(/*string*/ fileName, /*SaveOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685101060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                if (this._declaration !== null && !$.$$.System.String.IsNullOrEmpty(this._declaration.Encoding))
                {
                    try
                    {
                        ws.Encoding = $.$$.System.Text.Encoding.GetEncoding$3(this._declaration.Encoding);
                    }
                    catch($e)
                    {
                    }
                }
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$4(fileName, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184685101060)
            
            //--TRIMMABLE-BOUNDARY-START(231929741316)
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929741316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (this._declaration !== null && $.$$.System.String.op_Equality(this._declaration.Standalone, "yes"))
                {
                    writer.WriteStartDocument$1(true);
                }
                else if (this._declaration !== null && $.$$.System.String.op_Equality(this._declaration.Standalone, "no"))
                {
                    writer.WriteStartDocument$1(false);
                }
                else 
                {
                    writer.WriteStartDocument();
                }
                this.WriteContentTo(writer);
                writer.WriteEndDocument();
            }
            //--TRIMMABLE-BOUNDARY-END(231929741316)
            
            //--TRIMMABLE-BOUNDARY-START(236224708612)
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224708612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return this.WriteToAsyncInternal(writer, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(236224708612)
            
            //--TRIMMABLE-BOUNDARY-START(240519675908)
            /*Task *//*async*/  WriteToAsyncInternal(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(240519675908);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*Task*/ let tStart;
                    if (this._declaration !== null && $.$$.System.String.op_Equality(this._declaration.Standalone, "yes"))
                    {
                        tStart = writer.WriteStartDocumentAsync$1(true);
                    }
                    else if (this._declaration !== null && $.$$.System.String.op_Equality(this._declaration.Standalone, "no"))
                    {
                        tStart = writer.WriteStartDocumentAsync$1(false);
                    }
                    else 
                    {
                        tStart = writer.WriteStartDocumentAsync();
                    }
                    await tStart.ConfigureAwait(false);
                    await this.WriteContentToAsync(writer, cancellationToken).ConfigureAwait(false);
                    await writer.WriteEndDocumentAsync().ConfigureAwait(false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(240519675908)
            
            //--TRIMMABLE-BOUNDARY-START(25771311108)
            /*void */ AddAttribute(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_AddAttribute);
            }
            //--TRIMMABLE-BOUNDARY-END(25771311108)
            
            //--TRIMMABLE-BOUNDARY-START(30066278404)
            /*void */ AddAttributeSkipNotify(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066278404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_AddAttribute);
            }
            //--TRIMMABLE-BOUNDARY-END(30066278404)
            
            //--TRIMMABLE-BOUNDARY-START(34361245700)
            /*XNode */ CloneNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361245700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$spxl.System.Xml.Linq.XDocument().$ctor$8(this);
            }
            //--TRIMMABLE-BOUNDARY-END(34361245700)
            
            //--TRIMMABLE-BOUNDARY-START(42951180292)
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951180292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XDocument?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XDocument);
                return other !== null && this.ContentsEqual(other);
            }
            //--TRIMMABLE-BOUNDARY-END(42951180292)
            
            //--TRIMMABLE-BOUNDARY-START(85900853252)
            /*int */ GetDeepHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900853252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ContentsHashCode();
            }
            //--TRIMMABLE-BOUNDARY-END(85900853252)
            
            //--TRIMMABLE-BOUNDARY-START(90195820548)
            /*T? */ GetFirstNode(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195820548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*T?*/ let e = $.$as(n, T);
                        if ($.$box(e, T) !== null)
                        {
                            return e;
                        }
                    }
                    while(n !== this.content);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(90195820548)
            
            //--TRIMMABLE-BOUNDARY-START(223339806724)
            /*void */ ValidateNode(/*XNode*/ node, /*XNode?*/ previous)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339806724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = node.NodeType;
                switch($switch1)
                {
                    case 3/*XmlNodeType.Text*/:
                    this.ValidateString(($.$cast(node, $.$spxl.System.Xml.Linq.XText)).Value);
                    break;
                    case 1/*XmlNodeType.Element*/:
                    this.ValidateDocument(previous, 10/*XmlNodeType.DocumentType*/, 0/*XmlNodeType.None*/);
                    break;
                    case 10/*XmlNodeType.DocumentType*/:
                    this.ValidateDocument(previous, 0/*XmlNodeType.None*/, 1/*XmlNodeType.Element*/);
                    break;
                    case 4/*XmlNodeType.CDATA*/:
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_AddNode, $.$box(4/*XmlNodeType.CDATA*/, $.$spx.System.Xml.XmlNodeType)));
                    case 9/*XmlNodeType.Document*/:
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_AddNode, $.$box(9/*XmlNodeType.Document*/, $.$spx.System.Xml.XmlNodeType)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223339806724)
            
            //--TRIMMABLE-BOUNDARY-START(219044839428)
            /*void */ ValidateDocument(/*XNode?*/ previous, /*XmlNodeType*/ allowBefore, /*XmlNodeType*/ allowAfter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044839428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    if (previous === null)
                    {
                        allowBefore = allowAfter;
                    }
                    do
                    {
                        n = n.next;
                        /*XmlNodeType*/ let nt = n.NodeType;
                        if (nt === 1/*XmlNodeType.Element*/ || nt === 10/*XmlNodeType.DocumentType*/)
                        {
                            if (nt !== allowBefore)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_DocumentStructure);
                            }
                            allowBefore = 0/*XmlNodeType.None*/;
                        }
                        if (n === previous)
                        {
                            allowBefore = allowAfter;
                        }
                    }
                    while(n !== this.content);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219044839428)
            
            //--TRIMMABLE-BOUNDARY-START(227634774020)
            /*void */ ValidateString(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634774020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.MemoryExtensions.ContainsAnyExcept$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(s), $.$$.System.String.op_Implicit(" \t\r\n")))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Argument_AddNonWhitespace);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227634774020)
            
            static $h = 1507332;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1310724,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656212996),
    {
      "p": 1441796,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836082180,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214749872132,
        "f": 83886081
      },
      "n": "Declaration",
      "d": 1507332,
      "h": 38656212996,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656212996),
//--TRIMMABLE-BOUNDARY-START(47246147588),
    {
      "p": 1572868,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426016772,
        "f": 50331649
      },
      "n": "DocumentType",
      "d": 1507332,
      "h": 47246147588,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246147588),
//--TRIMMABLE-BOUNDARY-START(150325362692),
    {
      "p": 52822019,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015951364,
        "f": 50364417
      },
      "n": "NodeType",
      "d": 1507332,
      "h": 150325362692,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150325362692),
//--TRIMMABLE-BOUNDARY-START(163210264580),
    {
      "p": 1638404,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605885956,
        "f": 50331649
      },
      "n": "Root",
      "d": 1507332,
      "h": 163210264580,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163210264580)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(120260591620),
    {
      "r": 1507332,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        }
      ],
      "n": "Load",
      "o": "@$5",
      "d": 1507332,
      "h": 120260591620,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120260591620),
//--TRIMMABLE-BOUNDARY-START(115965624324),
    {
      "r": 1507332,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 655364
        }
      ],
      "n": "Load",
      "o": "@$4",
      "d": 1507332,
      "h": 115965624324,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115965624324),
//--TRIMMABLE-BOUNDARY-START(103080722436),
    {
      "r": 1507332,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        }
      ],
      "n": "Load",
      "o": "@$1",
      "d": 1507332,
      "h": 103080722436,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(103080722436),
//--TRIMMABLE-BOUNDARY-START(98785755140),
    {
      "r": 1507332,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "options",
          "p": 655364
        }
      ],
      "n": "Load",
      "d": 1507332,
      "h": 98785755140,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98785755140),
//--TRIMMABLE-BOUNDARY-START(133145493508),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "options",
          "p": 655364
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "LoadAsync",
      "d": 1507332,
      "h": 133145493508,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(133145493508),
//--TRIMMABLE-BOUNDARY-START(111670657028),
    {
      "r": 1507332,
      "p": [
        {
          "n": "textReader",
          "p": 95682561
        }
      ],
      "n": "Load",
      "o": "@$3",
      "d": 1507332,
      "h": 111670657028,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111670657028),
//--TRIMMABLE-BOUNDARY-START(107375689732),
    {
      "r": 1507332,
      "p": [
        {
          "n": "textReader",
          "p": 95682561
        },
        {
          "n": "options",
          "p": 655364
        }
      ],
      "n": "Load",
      "o": "@$2",
      "d": 1507332,
      "h": 107375689732,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(107375689732),
//--TRIMMABLE-BOUNDARY-START(137440460804),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,
      "p": [
        {
          "n": "textReader",
          "p": 95682561
        },
        {
          "n": "options",
          "p": 655364
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "LoadAsync",
      "o": "@$1",
      "d": 1507332,
      "h": 137440460804,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(137440460804),
//--TRIMMABLE-BOUNDARY-START(128850526212),
    {
      "r": 1507332,
      "p": [
        {
          "n": "reader",
          "p": 53346307
        }
      ],
      "n": "Load",
      "o": "@$7",
      "d": 1507332,
      "h": 128850526212,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(128850526212),
//--TRIMMABLE-BOUNDARY-START(124555558916),
    {
      "r": 1507332,
      "p": [
        {
          "n": "reader",
          "p": 53346307
        },
        {
          "n": "options",
          "p": 655364
        }
      ],
      "n": "Load",
      "o": "@$6",
      "d": 1507332,
      "h": 124555558916,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124555558916),
//--TRIMMABLE-BOUNDARY-START(141735428100),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,
      "p": [
        {
          "n": "reader",
          "p": 53346307
        },
        {
          "n": "options",
          "p": 655364
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "LoadAsync",
      "o": "@$2",
      "d": 1507332,
      "h": 141735428100,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(141735428100),
//--TRIMMABLE-BOUNDARY-START(146030395396),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,
      "p": [
        {
          "n": "reader",
          "p": 53346307
        },
        {
          "n": "options",
          "p": 655364
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "LoadAsyncInternal",
      "d": 1507332,
      "h": 146030395396,
      "f": 16781346
    },
//--TRIMMABLE-BOUNDARY-END(146030395396),
//--TRIMMABLE-BOUNDARY-START(94490787844),
    {
      "r": 1507332,
      "p": [
        {
          "n": "reader",
          "p": 53346307
        },
        {
          "n": "options",
          "p": 655364
        }
      ],
      "n": "InitLoad",
      "d": 1507332,
      "h": 94490787844,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94490787844),
//--TRIMMABLE-BOUNDARY-START(158915297284),
    {
      "r": 1507332,
      "p": [
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "Parse",
      "o": "@$1",
      "d": 1507332,
      "h": 158915297284,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(158915297284),
//--TRIMMABLE-BOUNDARY-START(154620329988),
    {
      "r": 1507332,
      "p": [
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 655364
        }
      ],
      "n": "Parse",
      "d": 1507332,
      "h": 154620329988,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(154620329988),
//--TRIMMABLE-BOUNDARY-START(171800199172),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        }
      ],
      "n": "Save",
      "o": "@$1",
      "d": 1507332,
      "h": 171800199172,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171800199172),
//--TRIMMABLE-BOUNDARY-START(167505231876),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "options",
          "p": 983044
        }
      ],
      "n": "Save",
      "d": 1507332,
      "h": 167505231876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167505231876),
//--TRIMMABLE-BOUNDARY-START(197570002948),
    {
      "r": 177668097,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "options",
          "p": 983044
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "SaveAsync",
      "d": 1507332,
      "h": 197570002948,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(197570002948),
//--TRIMMABLE-BOUNDARY-START(180390133764),
    {
      "r": 65537,
      "p": [
        {
          "n": "textWriter",
          "p": 95813633
        }
      ],
      "n": "Save",
      "o": "@$3",
      "d": 1507332,
      "h": 180390133764,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180390133764),
//--TRIMMABLE-BOUNDARY-START(176095166468),
    {
      "r": 65537,
      "p": [
        {
          "n": "textWriter",
          "p": 95813633
        },
        {
          "n": "options",
          "p": 983044
        }
      ],
      "n": "Save",
      "o": "@$2",
      "d": 1507332,
      "h": 176095166468,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176095166468),
//--TRIMMABLE-BOUNDARY-START(193275035652),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        }
      ],
      "n": "Save",
      "o": "@$6",
      "d": 1507332,
      "h": 193275035652,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193275035652),
//--TRIMMABLE-BOUNDARY-START(201864970244),
    {
      "r": 177668097,
      "p": [
        {
          "n": "textWriter",
          "p": 95813633
        },
        {
          "n": "options",
          "p": 983044
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "SaveAsync",
      "o": "@$1",
      "d": 1507332,
      "h": 201864970244,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(201864970244),
//--TRIMMABLE-BOUNDARY-START(188980068356),
    {
      "r": 65537,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        }
      ],
      "n": "Save",
      "o": "@$5",
      "d": 1507332,
      "h": 188980068356,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188980068356),
//--TRIMMABLE-BOUNDARY-START(206159937540),
    {
      "r": 177668097,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "SaveAsync",
      "o": "@$2",
      "d": 1507332,
      "h": 206159937540,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(206159937540),
//--TRIMMABLE-BOUNDARY-START(184685101060),
    {
      "r": 65537,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 983044
        }
      ],
      "n": "Save",
      "o": "@$4",
      "d": 1507332,
      "h": 184685101060,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184685101060),
//--TRIMMABLE-BOUNDARY-START(231929741316),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        }
      ],
      "n": "WriteTo",
      "d": 1507332,
      "h": 231929741316,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(231929741316),
//--TRIMMABLE-BOUNDARY-START(236224708612),
    {
      "r": 177668097,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteToAsync",
      "d": 1507332,
      "h": 236224708612,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(236224708612),
//--TRIMMABLE-BOUNDARY-START(240519675908),
    {
      "r": 177668097,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteToAsyncInternal",
      "d": 1507332,
      "h": 240519675908,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(240519675908),
//--TRIMMABLE-BOUNDARY-START(25771311108),
    {
      "r": 65537,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "AddAttribute",
      "d": 1507332,
      "h": 25771311108,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(25771311108),
//--TRIMMABLE-BOUNDARY-START(30066278404),
    {
      "r": 65537,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "AddAttributeSkipNotify",
      "d": 1507332,
      "h": 30066278404,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(30066278404),
//--TRIMMABLE-BOUNDARY-START(34361245700),
    {
      "r": 2228228,
      "n": "CloneNode",
      "d": 1507332,
      "h": 34361245700,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(34361245700),
//--TRIMMABLE-BOUNDARY-START(42951180292),
    {
      "r": 262145,
      "p": [
        {
          "n": "node",
          "p": 2228228
        }
      ],
      "n": "DeepEquals",
      "o": "@$1",
      "d": 1507332,
      "h": 42951180292,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(42951180292),
//--TRIMMABLE-BOUNDARY-START(85900853252),
    {
      "r": 655361,
      "n": "GetDeepHashCode",
      "d": 1507332,
      "h": 85900853252,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(85900853252),
//--TRIMMABLE-BOUNDARY-START(90195820548),
    {
      "r": (T) => T.$h,
      "g": [
        "T"
      ],
      "n": "GetFirstNode",
      "d": 1507332,
      "h": 90195820548,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(90195820548),
//--TRIMMABLE-BOUNDARY-START(223339806724),
    {
      "r": 65537,
      "p": [
        {
          "n": "node",
          "p": 2228228
        },
        {
          "n": "previous",
          "p": 2228228
        }
      ],
      "n": "ValidateNode",
      "d": 1507332,
      "h": 223339806724,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(223339806724),
//--TRIMMABLE-BOUNDARY-START(219044839428),
    {
      "r": 65537,
      "p": [
        {
          "n": "previous",
          "p": 2228228
        },
        {
          "n": "allowBefore",
          "p": 52822019
        },
        {
          "n": "allowAfter",
          "p": 52822019
        }
      ],
      "n": "ValidateDocument",
      "d": 1507332,
      "h": 219044839428,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(219044839428),
//--TRIMMABLE-BOUNDARY-START(227634774020),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "ValidateString",
      "d": 1507332,
      "h": 227634774020,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(227634774020)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296474628),
    {
      "t": 1441796,
      "n": "_declaration",
      "d": 1507332,
      "h": 4296474628,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474628)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591441924),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1507332,
      "h": 8591441924,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591441924),
//--TRIMMABLE-BOUNDARY-START(12886409220),
    {
      "p": [
        {
          "n": "content",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1507332,
      "h": 12886409220,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886409220),
//--TRIMMABLE-BOUNDARY-START(17181376516),
    {
      "p": [
        {
          "n": "declaration",
          "p": 1441796
        },
        {
          "n": "content",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1507332,
      "h": 17181376516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181376516),
//--TRIMMABLE-BOUNDARY-START(21476343812),
    {
      "p": [
        {
          "n": "other",
          "p": 1507332
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1507332,
      "h": 21476343812,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476343812)
  ],
  "i": [13893635
  ],
  "h": 1507332
}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XContainer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XDocument`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507332)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638404)
        $asm.$cls("$spxl.System.Xml.Linq.XElement", ($self) => class XElement extends $.$spxl.System.Xml.Linq.XContainer
        {
            //--TRIMMABLE-BOUNDARY-START(223339937796)
            static /*IEnumerable<XElement> */ get EmptySequence()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224839684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Array.Empty($.$spxl.System.Xml.Linq.XElement);
            }
            //--TRIMMABLE-BOUNDARY-END(223339937796)
            
            //--TRIMMABLE-BOUNDARY-START(408023531524)
            /*XName*/ name = null;
            //--TRIMMABLE-BOUNDARY-END(408023531524)
            
            //--TRIMMABLE-BOUNDARY-START(347893989380)
            /*XAttribute?*/ lastAttr = null;
            //--TRIMMABLE-BOUNDARY-END(347893989380)
            
            //--TRIMMABLE-BOUNDARY-START(146030526468)
            $ctor$12(/*XName*/ name)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146030526468);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                    this.name = name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(146030526468)
            
            //--TRIMMABLE-BOUNDARY-START(137440591876)
            $ctor$10(/*XName*/ name, /*object?*/ content)
            {
                this.$ctor$12(name);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137440591876);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.AddContentSkipNotify(content);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(137440591876)
            
            //--TRIMMABLE-BOUNDARY-START(141735559172)
            $ctor$11(/*XName*/ name, /*params object?[]*/ content)
            {
                this.$ctor$10(name, $.$cast(content, $.$$.System.Object));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141735559172);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(141735559172)
            
            //--TRIMMABLE-BOUNDARY-START(133145624580)
            $ctor$9(/*XElement*/ other)
            {
                super.$ctor$4(other);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133145624580);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.name = other.name;
                    /*XAttribute?*/ let a = other.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            this.AppendAttributeSkipNotify(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(a));
                        }
                        while(a !== other.lastAttr);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(133145624580)
            
            //--TRIMMABLE-BOUNDARY-START(150325493764)
            $ctor$13(/*XStreamingElement*/ other)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150325493764);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                    this.name = other.name;
                    this.AddContentSkipNotify(other.content);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(150325493764)
            
            //--TRIMMABLE-BOUNDARY-START(115965755396)
            $ctor$5()
            {
                this.$ctor$12($.$spxl.System.Xml.Linq.XName.op_Implicit($.$spxl.System.Xml.Linq.XName.op_Implicit($.$default())));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115965755396);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(115965755396)
            
            //--TRIMMABLE-BOUNDARY-START(124555689988)
            $ctor$7(/*XmlReader*/ r)
            {
                this.$ctor$6(r, 0/*LoadOptions.None*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124555689988);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(124555689988)
            
            //--TRIMMABLE-BOUNDARY-START(128850657284)
            $ctor$8(/*AsyncConstructionSentry*/ _)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128850657284);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(128850657284)
            
            //--TRIMMABLE-BOUNDARY-START(1703940)
            static $_AsyncConstructionSentry;
            static get AsyncConstructionSentry()
            {
                let $cls = $.$spxl.System.Xml.Linq.XElement;
                return $cls.$_AsyncConstructionSentry ??= $asm.$nstr("$spxl.System.Xml.Linq.XElement.AsyncConstructionSentry", ($self) => class AsyncConstructionSentry extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4296671236)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296671236)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        return copy;
                    }
                    static $h = 1703940;
                    static $z = 0;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671236),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1703940,
      "h": 4296671236,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296671236)
  ],
  "d": 1638404,
  "h": 1703940
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Xml.Linq.XElement.AsyncConstructionSentry`; }
                }, $cls, ($v) => $cls.$_AsyncConstructionSentry = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1703940)
            
            //--TRIMMABLE-BOUNDARY-START(120260722692)
            $ctor$6(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120260722692);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ReadElementFrom(r, o);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(120260722692)
            
            //--TRIMMABLE-BOUNDARY-START(201865101316)
            static /*Task<XElement> *//*async*/  CreateAsync(/*XmlReader*/ r, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201865101316);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*XElement*/ let xe = new $.$spxl.System.Xml.Linq.XElement().$ctor$8($.$default($.$spxl.System.Xml.Linq.XElement.AsyncConstructionSentry));
                    await xe.ReadElementFromAsync(r, 0/*LoadOptions.None*/, cancellationToken).ConfigureAwait(false);
                    return xe;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(201865101316)
            
            //--TRIMMABLE-BOUNDARY-START(498217844740)
            /*void */ Save$5(/*string*/ fileName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498217844740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Save$4(fileName, this.GetSaveOptionsFromAnnotations());
            }
            //--TRIMMABLE-BOUNDARY-END(498217844740)
            
            //--TRIMMABLE-BOUNDARY-START(493922877444)
            /*void */ Save$4(/*string*/ fileName, /*SaveOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493922877444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$4(fileName, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(493922877444)
            
            //--TRIMMABLE-BOUNDARY-START(227634905092)
            /*XAttribute? */ get FirstAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814774276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.lastAttr?.next ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(227634905092)
            
            //--TRIMMABLE-BOUNDARY-START(335009087492)
            /*bool */ get HasAttributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404708868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.lastAttr !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(335009087492)
            
            //--TRIMMABLE-BOUNDARY-START(339304054788)
            /*bool */ get HasElements()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994643460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        if ($.$is(n, $.$spxl.System.Xml.Linq.XElement))
                        {
                            return true;
                        }
                        n = n.next;
                    }
                    while(n !== this.content);
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(339304054788)
            
            //--TRIMMABLE-BOUNDARY-START(343599022084)
            /*bool */ get IsEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584578052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.content === null;
            }
            //--TRIMMABLE-BOUNDARY-END(343599022084)
            
            //--TRIMMABLE-BOUNDARY-START(352188956676)
            /*XAttribute? */ get LastAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174512644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.lastAttr;
            }
            //--TRIMMABLE-BOUNDARY-END(352188956676)
            
            //--TRIMMABLE-BOUNDARY-START(412318498820)
            /*XName */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764447236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.name;
            }
            /*XName */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528282615812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                this.name = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(412318498820)
            
            //--TRIMMABLE-BOUNDARY-START(416613466116)
            /*XmlNodeType */ get NodeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354381828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 1/*XmlNodeType.Element*/;
            }
            //--TRIMMABLE-BOUNDARY-END(416613466116)
            
            //--TRIMMABLE-BOUNDARY-START(575527256068)
            /*string */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304944316420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.content === null)
                {
                    return $.$$.System.String.Empty;
                }
                /*string?*/ let s = $.$as(this.content, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(s, null))
                {
                    return s;
                }
                /*StringBuilder*/ let sb = $.$spxl.System.Text.StringBuilderCache.Acquire(16);
                this.AppendText(sb);
                return $.$spxl.System.Text.StringBuilderCache.GetStringAndRelease(sb);
            }
            /*string */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536872550404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.RemoveNodes();
                this.Add(value);
            }
            //--TRIMMABLE-BOUNDARY-END(575527256068)
            
            //--TRIMMABLE-BOUNDARY-START(163210395652)
            /*IEnumerable<XElement> */ AncestorsAndSelf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210395652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAncestors(null, true);
            }
            //--TRIMMABLE-BOUNDARY-END(163210395652)
            
            //--TRIMMABLE-BOUNDARY-START(167505362948)
            /*IEnumerable<XElement> */ AncestorsAndSelf$1(/*XName?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505362948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetAncestors(name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            //--TRIMMABLE-BOUNDARY-END(167505362948)
            
            //--TRIMMABLE-BOUNDARY-START(180390264836)
            /*XAttribute? */ Attribute(/*XName*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390264836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XAttribute?*/ let a = this.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(a.name, name))
                        {
                            return a;
                        }
                    }
                    while(a !== this.lastAttr);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(180390264836)
            
            //--TRIMMABLE-BOUNDARY-START(184685232132)
            /*IEnumerable<XAttribute> */ Attributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685232132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAttributes(null);
            }
            //--TRIMMABLE-BOUNDARY-END(184685232132)
            
            //--TRIMMABLE-BOUNDARY-START(188980199428)
            /*IEnumerable<XAttribute> */ Attributes$1(/*XName?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980199428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetAttributes(name) : $.$spxl.System.Xml.Linq.XAttribute.EmptySequence;
            }
            //--TRIMMABLE-BOUNDARY-END(188980199428)
            
            //--TRIMMABLE-BOUNDARY-START(210455035908)
            /*IEnumerable<XNode> */ DescendantNodesAndSelf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455035908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDescendantNodes(true);
            }
            //--TRIMMABLE-BOUNDARY-END(210455035908)
            
            //--TRIMMABLE-BOUNDARY-START(214750003204)
            /*IEnumerable<XElement> */ DescendantsAndSelf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750003204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDescendants(null, true);
            }
            //--TRIMMABLE-BOUNDARY-END(214750003204)
            
            //--TRIMMABLE-BOUNDARY-START(219044970500)
            /*IEnumerable<XElement> */ DescendantsAndSelf$1(/*XName?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044970500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetDescendants(name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            //--TRIMMABLE-BOUNDARY-END(219044970500)
            
            //--TRIMMABLE-BOUNDARY-START(317829218308)
            /*XNamespace */ GetDefaultNamespace()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317829218308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let namespaceName = this.GetNamespaceOfPrefixInScope("xmlns", null);
                return $.$$.System.String.op_Inequality(namespaceName, null) ? $.$spxl.System.Xml.Linq.XNamespace.Get$1(namespaceName) : $.$spxl.System.Xml.Linq.XNamespace.None;
            }
            //--TRIMMABLE-BOUNDARY-END(317829218308)
            
            //--TRIMMABLE-BOUNDARY-START(322124185604)
            /*XNamespace? */ GetNamespaceOfPrefix(/*string*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322124185604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(prefix, "prefix");
                if ($.$$.System.String.op_Equality(prefix, "xmlns"))
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.Xmlns;
                }
                /*string?*/ let namespaceName = this.GetNamespaceOfPrefixInScope(prefix, null);
                if ($.$$.System.String.op_Inequality(namespaceName, null))
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.Get$1(namespaceName);
                }
                if ($.$$.System.String.op_Equality(prefix, "xml"))
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.Xml;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(322124185604)
            
            //--TRIMMABLE-BOUNDARY-START(330714120196)
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714120196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(ns, "ns");
                /*string*/ let namespaceName = ns.NamespaceName;
                /*bool*/ let hasInScopeNamespace = false;
                /*XElement?*/ let e = this;
                do
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        /*bool*/ let hasLocalNamespace = false;
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration)
                            {
                                if ($.$$.System.String.op_Equality(a.Value, namespaceName))
                                {
                                    if (a.Name.NamespaceName.length !== 0 && (!hasInScopeNamespace || $.$$.System.String.op_Equality(this.GetNamespaceOfPrefixInScope(a.Name.LocalName, e), null)))
                                    {
                                        return a.Name.LocalName;
                                    }
                                }
                                hasLocalNamespace = true;
                            }
                        }
                        while(a !== e.lastAttr);
                        hasInScopeNamespace = $.$$.System.Boolean.op_BitwiseOr(hasInScopeNamespace, hasLocalNamespace);
                    }
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                while(e !== null);
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    if (!hasInScopeNamespace || $.$$.System.String.op_Equality(this.GetNamespaceOfPrefixInScope("xml", null), null))
                    {
                        return "xml";
                    }
                }
                else if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(330714120196)
            
            //--TRIMMABLE-BOUNDARY-START(377958760452)
            static /*XElement */ Load$5(/*string*/ uri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377958760452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XElement.Load$4(uri, 0/*LoadOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(377958760452)
            
            //--TRIMMABLE-BOUNDARY-START(373663793156)
            static /*XElement */ Load$4(/*string*/ uri, /*LoadOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373663793156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$9(uri, rs);
                    return $.$spxl.System.Xml.Linq.XElement.Load$6(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(373663793156)
            
            //--TRIMMABLE-BOUNDARY-START(360778891268)
            static /*XElement */ Load$1(/*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778891268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XElement.Load(stream, 0/*LoadOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(360778891268)
            
            //--TRIMMABLE-BOUNDARY-START(356483923972)
            static /*XElement */ Load(/*Stream*/ stream, /*LoadOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483923972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$2(stream, rs);
                    return $.$spxl.System.Xml.Linq.XElement.Load$6(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(356483923972)
            
            //--TRIMMABLE-BOUNDARY-START(390843662340)
            static /*Task<XElement> *//*async*/  LoadAsync(/*Stream*/ stream, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(390843662340);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$2(stream, rs);
                        return await $.$spxl.System.Xml.Linq.XElement.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(390843662340)
            
            //--TRIMMABLE-BOUNDARY-START(369368825860)
            static /*XElement */ Load$3(/*TextReader*/ textReader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369368825860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XElement.Load$2(textReader, 0/*LoadOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(369368825860)
            
            //--TRIMMABLE-BOUNDARY-START(365073858564)
            static /*XElement */ Load$2(/*TextReader*/ textReader, /*LoadOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365073858564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$6(textReader, rs);
                    return $.$spxl.System.Xml.Linq.XElement.Load$6(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(365073858564)
            
            //--TRIMMABLE-BOUNDARY-START(395138629636)
            static /*Task<XElement> *//*async*/  LoadAsync$1(/*TextReader*/ textReader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(395138629636);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$6(textReader, rs);
                        return await $.$spxl.System.Xml.Linq.XElement.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(395138629636)
            
            //--TRIMMABLE-BOUNDARY-START(386548695044)
            static /*XElement */ Load$7(/*XmlReader*/ reader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548695044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XElement.Load$6(reader, 0/*LoadOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(386548695044)
            
            //--TRIMMABLE-BOUNDARY-START(382253727748)
            static /*XElement */ Load$6(/*XmlReader*/ reader, /*LoadOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382253727748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                if (reader.MoveToContent() !== 1/*XmlNodeType.Element*/)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$5($.$spxl.System.SR.InvalidOperation_ExpectedNodeType, $.$box(1/*XmlNodeType.Element*/, $.$spx.System.Xml.XmlNodeType), $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                }
                /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$6(reader, options);
                reader.MoveToContent();
                if (!reader.EOF)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                }
                return e;
            }
            //--TRIMMABLE-BOUNDARY-END(382253727748)
            
            //--TRIMMABLE-BOUNDARY-START(399433596932)
            static /*Task<XElement> */ LoadAsync$2(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399433596932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$3($.$spxl.System.Xml.Linq.XElement, cancellationToken);
                }
                return $.$spxl.System.Xml.Linq.XElement.LoadAsyncInternal(reader, options, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(399433596932)
            
            //--TRIMMABLE-BOUNDARY-START(403728564228)
            static /*Task<XElement> *//*async*/  LoadAsyncInternal(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(403728564228);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (await reader.MoveToContentAsync().ConfigureAwait$2(false) !== 1/*XmlNodeType.Element*/)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$5($.$spxl.System.SR.InvalidOperation_ExpectedNodeType, $.$box(1/*XmlNodeType.Element*/, $.$spx.System.Xml.XmlNodeType), $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                    }
                    /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$8($.$default($.$spxl.System.Xml.Linq.XElement.AsyncConstructionSentry));
                    await e.ReadElementFromAsync(reader, options, cancellationToken).ConfigureAwait(false);
                    cancellationToken.ThrowIfCancellationRequested();
                    await reader.MoveToContentAsync().ConfigureAwait$2(false);
                    if (!reader.EOF)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                    }
                    return e;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(403728564228)
            
            //--TRIMMABLE-BOUNDARY-START(425203400708)
            static /*XElement */ Parse$1(/*string*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425203400708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$spxl.System.Xml.Linq.XElement.Parse(text, 0/*LoadOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(425203400708)
            
            //--TRIMMABLE-BOUNDARY-START(420908433412)
            static /*XElement */ Parse(/*string*/ text, /*LoadOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420908433412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let sr = null;
                try
                {
                    sr = new $.$$.System.IO.StringReader().$ctor$3(text);
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$6(sr, rs);
                        return $.$spxl.System.Xml.Linq.XElement.Load$6(r, options);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                }
                finally
                {
                    sr?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(420908433412)
            
            //--TRIMMABLE-BOUNDARY-START(442383269892)
            /*void */ RemoveAll()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442383269892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.RemoveAttributes();
                this.RemoveNodes();
            }
            //--TRIMMABLE-BOUNDARY-END(442383269892)
            
            //--TRIMMABLE-BOUNDARY-START(450973204484)
            /*void */ RemoveAttributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450973204484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.SkipNotify())
                {
                    this.RemoveAttributesSkipNotify();
                    return;
                }
                while(this.lastAttr !== null)
                {
                    /*XAttribute*/ let a = this.lastAttr.next;
                    this.NotifyChanging(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                    if (this.lastAttr === null || a !== this.lastAttr.next)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                    }
                    if (a !== this.lastAttr)
                    {
                        this.lastAttr.next = a.next;
                    }
                    else 
                    {
                        this.lastAttr = null;
                    }
                    a.parent = null;
                    a.next = null;
                    this.NotifyChanged(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(450973204484)
            
            //--TRIMMABLE-BOUNDARY-START(459563139076)
            /*void */ ReplaceAll(/*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459563139076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                content = $.$spxl.System.Xml.Linq.XContainer.GetContentSnapshot(content);
                this.RemoveAll();
                this.Add(content);
            }
            //--TRIMMABLE-BOUNDARY-END(459563139076)
            
            //--TRIMMABLE-BOUNDARY-START(463858106372)
            /*void */ ReplaceAll$1(/*params object?[]*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463858106372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ReplaceAll($.$cast(content, $.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(463858106372)
            
            //--TRIMMABLE-BOUNDARY-START(468153073668)
            /*void */ ReplaceAttributes(/*object?*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468153073668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                content = $.$spxl.System.Xml.Linq.XContainer.GetContentSnapshot(content);
                this.RemoveAttributes();
                this.Add(content);
            }
            //--TRIMMABLE-BOUNDARY-END(468153073668)
            
            //--TRIMMABLE-BOUNDARY-START(472448040964)
            /*void */ ReplaceAttributes$1(/*params object?[]*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472448040964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ReplaceAttributes($.$cast(content, $.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(472448040964)
            
            //--TRIMMABLE-BOUNDARY-START(481037975556)
            /*void */ Save$1(/*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481037975556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Save(stream, this.GetSaveOptionsFromAnnotations());
            }
            //--TRIMMABLE-BOUNDARY-END(481037975556)
            
            //--TRIMMABLE-BOUNDARY-START(476743008260)
            /*void */ Save(/*Stream*/ stream, /*SaveOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476743008260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create(stream, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(476743008260)
            
            //--TRIMMABLE-BOUNDARY-START(506807779332)
            /*Task *//*async*/  SaveAsync(/*Stream*/ stream, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(506807779332);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create(stream, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$$.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.SaveAsync$2(w, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(506807779332)
            
            //--TRIMMABLE-BOUNDARY-START(489627910148)
            /*void */ Save$3(/*TextWriter*/ textWriter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489627910148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Save$2(textWriter, this.GetSaveOptionsFromAnnotations());
            }
            //--TRIMMABLE-BOUNDARY-END(489627910148)
            
            //--TRIMMABLE-BOUNDARY-START(485332942852)
            /*void */ Save$2(/*TextWriter*/ textWriter, /*SaveOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485332942852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$2(textWriter, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(485332942852)
            
            //--TRIMMABLE-BOUNDARY-START(511102746628)
            /*Task *//*async*/  SaveAsync$1(/*TextWriter*/ textWriter, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(511102746628);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create$2(textWriter, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$$.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.SaveAsync$2(w, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(511102746628)
            
            //--TRIMMABLE-BOUNDARY-START(502512812036)
            /*void */ Save$6(/*XmlWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502512812036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                writer.WriteStartDocument();
                this.WriteTo(writer);
                writer.WriteEndDocument();
            }
            //--TRIMMABLE-BOUNDARY-END(502512812036)
            
            //--TRIMMABLE-BOUNDARY-START(515397713924)
            /*Task */ SaveAsync$2(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515397713924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return this.SaveAsyncInternal(writer, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(515397713924)
            
            //--TRIMMABLE-BOUNDARY-START(519692681220)
            /*Task *//*async*/  SaveAsyncInternal(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(519692681220);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    await writer.WriteStartDocumentAsync().ConfigureAwait(false);
                    await this.WriteToAsync(writer, cancellationToken).ConfigureAwait(false);
                    cancellationToken.ThrowIfCancellationRequested();
                    await writer.WriteEndDocumentAsync().ConfigureAwait(false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(519692681220)
            
            //--TRIMMABLE-BOUNDARY-START(541167517700)
            /*void */ SetAttributeValue(/*XName*/ name, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541167517700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XAttribute?*/ let a = this.Attribute(name);
                if (value === null)
                {
                    if (a !== null)
                    {
                        this.RemoveAttribute(a);
                    }
                }
                else 
                {
                    if (a !== null)
                    {
                        a.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
                    }
                    else 
                    {
                        this.AppendAttribute(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(name, value));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(541167517700)
            
            //--TRIMMABLE-BOUNDARY-START(545462484996)
            /*void */ SetElementValue(/*XName*/ name, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545462484996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = this.Element(name);
                if (value === null)
                {
                    if (e !== null)
                    {
                        this.RemoveNode(e);
                    }
                }
                else 
                {
                    if (e !== null)
                    {
                        e.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
                    }
                    else 
                    {
                        this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$10(name, $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value)));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(545462484996)
            
            //--TRIMMABLE-BOUNDARY-START(554052419588)
            /*void */ SetValue(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554052419588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
            }
            //--TRIMMABLE-BOUNDARY-END(554052419588)
            
            //--TRIMMABLE-BOUNDARY-START(579822223364)
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(579822223364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                new $.$spxl.System.Xml.Linq.ElementWriter().$ctor$3(writer).WriteElement(this);
            }
            //--TRIMMABLE-BOUNDARY-END(579822223364)
            
            //--TRIMMABLE-BOUNDARY-START(584117190660)
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584117190660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return new $.$spxl.System.Xml.Linq.ElementWriter().$ctor$3(writer).WriteElementAsync(this, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(584117190660)
            
            //--TRIMMABLE-BOUNDARY-START(94490918916)
            static /*string? */ op_Explicit$21(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return element.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(94490918916)
            
            //--TRIMMABLE-BOUNDARY-START(4296605700)
            static /*bool */ op_Explicit(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$$.System.String.ToLowerInvariant.call(element.Value));
            }
            //--TRIMMABLE-BOUNDARY-END(4296605700)
            
            //--TRIMMABLE-BOUNDARY-START(38656344068)
            static /*bool? */ op_Explicit$8(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$$.System.String.ToLowerInvariant.call(element.Value));
            }
            //--TRIMMABLE-BOUNDARY-END(38656344068)
            
            //--TRIMMABLE-BOUNDARY-START(30066409476)
            static /*int */ op_Explicit$6(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToInt32(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(30066409476)
            
            //--TRIMMABLE-BOUNDARY-START(64426147844)
            static /*int? */ op_Explicit$14(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt32(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(64426147844)
            
            //--TRIMMABLE-BOUNDARY-START(103080853508)
            static /*uint */ op_Explicit$23(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToUInt32(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(103080853508)
            
            //--TRIMMABLE-BOUNDARY-START(81606017028)
            static /*uint? */ op_Explicit$18(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt32(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(81606017028)
            
            //--TRIMMABLE-BOUNDARY-START(34361376772)
            static /*long */ op_Explicit$7(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToInt64(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(34361376772)
            
            //--TRIMMABLE-BOUNDARY-START(68721115140)
            static /*long? */ op_Explicit$15(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt64(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(68721115140)
            
            //--TRIMMABLE-BOUNDARY-START(107375820804)
            static /*ulong */ op_Explicit$24(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToUInt64(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(107375820804)
            
            //--TRIMMABLE-BOUNDARY-START(85900984324)
            static /*ulong? */ op_Explicit$19(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt64(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(85900984324)
            
            //--TRIMMABLE-BOUNDARY-START(90195951620)
            static /*float */ op_Explicit$20(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToSingle(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(90195951620)
            
            //--TRIMMABLE-BOUNDARY-START(73016082436)
            static /*float? */ op_Explicit$16(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToSingle(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(73016082436)
            
            //--TRIMMABLE-BOUNDARY-START(21476474884)
            static /*double */ op_Explicit$4(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToDouble(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(21476474884)
            
            //--TRIMMABLE-BOUNDARY-START(55836213252)
            static /*double? */ op_Explicit$12(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDouble(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(55836213252)
            
            //--TRIMMABLE-BOUNDARY-START(17181507588)
            static /*decimal */ op_Explicit$3(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToDecimal(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(17181507588)
            
            //--TRIMMABLE-BOUNDARY-START(51541245956)
            static /*decimal? */ op_Explicit$11(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDecimal(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(51541245956)
            
            //--TRIMMABLE-BOUNDARY-START(8591572996)
            static /*DateTime */ op_Explicit$1(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$$.System.DateTime.Parse$2(element.Value, $.$$.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            //--TRIMMABLE-BOUNDARY-END(8591572996)
            
            //--TRIMMABLE-BOUNDARY-START(42951311364)
            static /*DateTime? */ op_Explicit$9(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$$.System.DateTime.Parse$2(element.Value, $.$$.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            //--TRIMMABLE-BOUNDARY-END(42951311364)
            
            //--TRIMMABLE-BOUNDARY-START(12886540292)
            static /*DateTimeOffset */ op_Explicit$2(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset$2(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(12886540292)
            
            //--TRIMMABLE-BOUNDARY-START(47246278660)
            static /*DateTimeOffset? */ op_Explicit$10(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset$2(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(47246278660)
            
            //--TRIMMABLE-BOUNDARY-START(98785886212)
            static /*TimeSpan */ op_Explicit$22(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(98785886212)
            
            //--TRIMMABLE-BOUNDARY-START(77311049732)
            static /*TimeSpan? */ op_Explicit$17(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(77311049732)
            
            //--TRIMMABLE-BOUNDARY-START(25771442180)
            static /*Guid */ op_Explicit$5(/*XElement*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToGuid(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(25771442180)
            
            //--TRIMMABLE-BOUNDARY-START(60131180548)
            static /*Guid? */ op_Explicit$13(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToGuid(element.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(60131180548)
            
            //--TRIMMABLE-BOUNDARY-START(558347386884)
            /*XmlSchema? */ System$Xml$Serialization$IXmlSerializable$GetSchema()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(558347386884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(558347386884)
            
            //--TRIMMABLE-BOUNDARY-START(562642354180)
            /*void */ System$Xml$Serialization$IXmlSerializable$ReadXml(/*XmlReader*/ reader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(562642354180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(reader, "reader");
                if (this.parent !== null || this.annotations !== null || this.content !== null || this.lastAttr !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_DeserializeInstance);
                }
                if (reader.MoveToContent() !== 1/*XmlNodeType.Element*/)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.Format$5($.$spxl.System.SR.InvalidOperation_ExpectedNodeType, $.$box(1/*XmlNodeType.Element*/, $.$spx.System.Xml.XmlNodeType), $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                }
                this.ReadElementFrom(reader, 0/*LoadOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(562642354180)
            
            //--TRIMMABLE-BOUNDARY-START(566937321476)
            /*void */ System$Xml$Serialization$IXmlSerializable$WriteXml(/*XmlWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(566937321476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteTo(writer);
            }
            //--TRIMMABLE-BOUNDARY-END(566937321476)
            
            //--TRIMMABLE-BOUNDARY-START(154620461060)
            /*void */ AddAttribute(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620461060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Attribute(a.Name) !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_DuplicateAttribute);
                }
                if (a.parent !== null)
                {
                    a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(a);
                }
                this.AppendAttribute(a);
            }
            //--TRIMMABLE-BOUNDARY-END(154620461060)
            
            //--TRIMMABLE-BOUNDARY-START(158915428356)
            /*void */ AddAttributeSkipNotify(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915428356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Attribute(a.Name) !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_DuplicateAttribute);
                }
                if (a.parent !== null)
                {
                    a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(a);
                }
                this.AppendAttributeSkipNotify(a);
            }
            //--TRIMMABLE-BOUNDARY-END(158915428356)
            
            //--TRIMMABLE-BOUNDARY-START(171800330244)
            /*void */ AppendAttribute(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800330244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let notify = this.NotifyChanging(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                if (a.parent !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                this.AppendAttributeSkipNotify(a);
                if (notify)
                {
                    this.NotifyChanged(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171800330244)
            
            //--TRIMMABLE-BOUNDARY-START(176095297540)
            /*void */ AppendAttributeSkipNotify(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095297540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                a.parent = this;
                if (this.lastAttr === null)
                {
                    a.next = a;
                }
                else 
                {
                    a.next = this.lastAttr.next;
                    this.lastAttr.next = a;
                }
                this.lastAttr = a;
            }
            //--TRIMMABLE-BOUNDARY-END(176095297540)
            
            //--TRIMMABLE-BOUNDARY-START(193275166724)
            /*bool */ AttributesEqual(/*XElement*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275166724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XAttribute?*/ let a1 = this.lastAttr;
                /*XAttribute?*/ let a2 = e.lastAttr;
                if (a1 !== null && a2 !== null)
                {
                    do
                    {
                        a1 = a1.next;
                        a2 = a2.next;
                        if ($.$spxl.System.Xml.Linq.XName.op_Inequality(a1.name, a2.name) || $.$$.System.String.op_Inequality(a1.value, a2.value))
                        {
                            return false;
                        }
                    }
                    while(a1 !== this.lastAttr);
                    return a2 === e.lastAttr;
                }
                return a1 === null && a2 === null;
            }
            //--TRIMMABLE-BOUNDARY-END(193275166724)
            
            //--TRIMMABLE-BOUNDARY-START(197570134020)
            /*XNode */ CloneNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570134020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$spxl.System.Xml.Linq.XElement().$ctor$9(this);
            }
            //--TRIMMABLE-BOUNDARY-END(197570134020)
            
            //--TRIMMABLE-BOUNDARY-START(206160068612)
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160068612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = $.$as(node, $.$spxl.System.Xml.Linq.XElement);
                return e !== null && $.$spxl.System.Xml.Linq.XName.op_Equality(this.name, e.name) && this.ContentsEqual(e) && this.AttributesEqual(e);
            }
            //--TRIMMABLE-BOUNDARY-END(206160068612)
            
            //--TRIMMABLE-BOUNDARY-START(309239283716)
            /*IEnumerable<XAttribute> */ GetAttributes(/*XName?*/ name)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*XAttribute?*/ let a = this.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(a.name, name))
                            {
                                yield a;
                            }
                        }
                        while(a.parent === this && a !== this.lastAttr);
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(309239283716)
            
            //--TRIMMABLE-BOUNDARY-START(326419152900)
            /*string? */ GetNamespaceOfPrefixInScope(/*string*/ prefix, /*XElement?*/ outOfScope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326419152900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*XElement?*/ let e = this;
                while(e !== outOfScope)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(e !== null, "e != null");
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration && $.$$.System.String.op_Equality(a.Name.LocalName, prefix))
                            {
                                return a.Value;
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(326419152900)
            
            //--TRIMMABLE-BOUNDARY-START(313534251012)
            /*int */ GetDeepHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313534251012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let h = $.$spxl.System.Xml.Linq.XName.GetHashCode.call(this.name);
                h ^= this.ContentsHashCode();
                /*XAttribute?*/ let a = this.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        h ^= a.GetDeepHashCode();
                    }
                    while(a !== this.lastAttr);
                }
                return h;
            }
            //--TRIMMABLE-BOUNDARY-END(313534251012)
            
            //--TRIMMABLE-BOUNDARY-START(429498368004)
            /*void */ ReadElementFrom(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429498368004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ReadElementFromImpl(r, o);
                if (!r.IsEmptyElement)
                {
                    r.Read();
                    this.ReadContentFrom(r, o);
                }
                r.Read();
            }
            //--TRIMMABLE-BOUNDARY-END(429498368004)
            
            //--TRIMMABLE-BOUNDARY-START(433793335300)
            /*Task *//*async*/  ReadElementFromAsync(/*XmlReader*/ r, /*LoadOptions*/ o, /*CancellationToken*/ cancellationTokentoken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(433793335300);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ReadElementFromImpl(r, o);
                    if (!r.IsEmptyElement)
                    {
                        cancellationTokentoken.ThrowIfCancellationRequested();
                        await r.ReadAsync().ConfigureAwait$2(false);
                        await this.ReadContentFromAsync$1(r, o, cancellationTokentoken).ConfigureAwait(false);
                    }
                    cancellationTokentoken.ThrowIfCancellationRequested();
                    await r.ReadAsync().ConfigureAwait$2(false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(433793335300)
            
            //--TRIMMABLE-BOUNDARY-START(438088302596)
            /*void */ ReadElementFromImpl(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438088302596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (r.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                this.name = $.$spxl.System.Xml.Linq.XNamespace.Get$1(r.NamespaceURI).GetName$1(r.LocalName);
                if ((o & 2/*LoadOptions.SetBaseUri*/) !== 0)
                {
                    /*string?*/ let baseUri = r.BaseURI;
                    if (!$.$$.System.String.IsNullOrEmpty(baseUri))
                    {
                        this.SetBaseUri(baseUri);
                    }
                }
                /*IXmlLineInfo?*/ let li = null;
                if ((o & 4/*LoadOptions.SetLineInfo*/) !== 0)
                {
                    li = $.$as(r, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null && li.System$Xml$IXmlLineInfo$HasLineInfo())
                    {
                        this.SetLineInfo(li.System$Xml$IXmlLineInfo$LineNumber, li.System$Xml$IXmlLineInfo$LinePosition);
                    }
                }
                if (r.MoveToFirstAttribute())
                {
                    do
                    {
                        /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3($.$spxl.System.Xml.Linq.XNamespace.Get$1(r.Prefix.length === 0 ? $.$$.System.String.Empty : r.NamespaceURI).GetName$1(r.LocalName), r.Value);
                        if (li !== null && li.System$Xml$IXmlLineInfo$HasLineInfo())
                        {
                            a.SetLineInfo(li.System$Xml$IXmlLineInfo$LineNumber, li.System$Xml$IXmlLineInfo$LinePosition);
                        }
                        this.AppendAttributeSkipNotify(a);
                    }
                    while(r.MoveToNextAttribute());
                    r.MoveToElement();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(438088302596)
            
            //--TRIMMABLE-BOUNDARY-START(446678237188)
            /*void */ RemoveAttribute(/*XAttribute*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446678237188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let notify = this.NotifyChanging(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                if (a.parent !== this)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                /*XAttribute?*/ let p = this.lastAttr, n;
                while((n = p.next) !== a)
                {
                    p = n;
                }
                if (p === a)
                {
                    this.lastAttr = null;
                }
                else 
                {
                    if (this.lastAttr === a)
                    {
                        this.lastAttr = p;
                    }
                    p.next = a.next;
                }
                a.parent = null;
                a.next = null;
                if (notify)
                {
                    this.NotifyChanged(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(446678237188)
            
            //--TRIMMABLE-BOUNDARY-START(455268171780)
            /*void */ RemoveAttributesSkipNotify()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455268171780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.lastAttr !== null)
                {
                    /*XAttribute*/ let a = this.lastAttr;
                    do
                    {
                        /*XAttribute*/ let next = a.next;
                        a.parent = null;
                        a.next = null;
                        a = next;
                    }
                    while(a !== this.lastAttr);
                    this.lastAttr = null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(455268171780)
            
            //--TRIMMABLE-BOUNDARY-START(549757452292)
            /*void */ SetEndElementLineInfo(/*int*/ lineNumber, /*int*/ linePosition)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(549757452292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddAnnotation(new $.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation().$ctor$2(lineNumber, linePosition));
            }
            //--TRIMMABLE-BOUNDARY-END(549757452292)
            
            //--TRIMMABLE-BOUNDARY-START(571232288772)
            /*void */ ValidateNode(/*XNode*/ node, /*XNode?*/ previous)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(571232288772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(node, $.$spxl.System.Xml.Linq.XDocument))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_AddNode, $.$box(9/*XmlNodeType.Document*/, $.$spx.System.Xml.XmlNodeType)));
                }
                if ($.$is(node, $.$spxl.System.Xml.Linq.XDocumentType))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$spxl.System.SR.Format$6($.$spxl.System.SR.Argument_AddNode, $.$box(10/*XmlNodeType.DocumentType*/, $.$spx.System.Xml.XmlNodeType)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(571232288772)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(408023531524)
                this.name = null;
                //--TRIMMABLE-BOUNDARY-END(408023531524)
                
            }
            static $h = 1638404;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1310724,
  "p": [
//--TRIMMABLE-BOUNDARY-START(223339937796),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236224839684,
        "f": 50331681
      },
      "n": "EmptySequence",
      "d": 1638404,
      "h": 223339937796,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(223339937796),
//--TRIMMABLE-BOUNDARY-START(227634905092),
    {
      "p": 1114116,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244814774276,
        "f": 50331649
      },
      "n": "FirstAttribute",
      "d": 1638404,
      "h": 227634905092,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227634905092),
//--TRIMMABLE-BOUNDARY-START(335009087492),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253404708868,
        "f": 50331649
      },
      "n": "HasAttributes",
      "d": 1638404,
      "h": 335009087492,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(335009087492),
//--TRIMMABLE-BOUNDARY-START(339304054788),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261994643460,
        "f": 50331649
      },
      "n": "HasElements",
      "d": 1638404,
      "h": 339304054788,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(339304054788),
//--TRIMMABLE-BOUNDARY-START(343599022084),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270584578052,
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": 1638404,
      "h": 343599022084,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(343599022084),
//--TRIMMABLE-BOUNDARY-START(352188956676),
    {
      "p": 1114116,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279174512644,
        "f": 50331649
      },
      "n": "LastAttribute",
      "d": 1638404,
      "h": 352188956676,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(352188956676),
//--TRIMMABLE-BOUNDARY-START(412318498820),
    {
      "p": 2097156,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287764447236,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 528282615812,
        "f": 83886081
      },
      "n": "Name",
      "d": 1638404,
      "h": 412318498820,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(412318498820),
//--TRIMMABLE-BOUNDARY-START(416613466116),
    {
      "p": 52822019,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296354381828,
        "f": 50364417
      },
      "n": "NodeType",
      "d": 1638404,
      "h": 416613466116,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(416613466116),
//--TRIMMABLE-BOUNDARY-START(575527256068),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304944316420,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 536872550404,
        "f": 83886081
      },
      "n": "Value",
      "d": 1638404,
      "h": 575527256068,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(575527256068)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(201865101316),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "r",
          "p": 53346307
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "CreateAsync",
      "d": 1638404,
      "h": 201865101316,
      "f": 16781352
    },
//--TRIMMABLE-BOUNDARY-END(201865101316),
//--TRIMMABLE-BOUNDARY-START(498217844740),
    {
      "r": 65537,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        }
      ],
      "n": "Save",
      "o": "@$5",
      "d": 1638404,
      "h": 498217844740,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(498217844740),
//--TRIMMABLE-BOUNDARY-START(493922877444),
    {
      "r": 65537,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 983044
        }
      ],
      "n": "Save",
      "o": "@$4",
      "d": 1638404,
      "h": 493922877444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(493922877444),
//--TRIMMABLE-BOUNDARY-START(163210395652),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "n": "AncestorsAndSelf",
      "d": 1638404,
      "h": 163210395652,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163210395652),
//--TRIMMABLE-BOUNDARY-START(167505362948),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "AncestorsAndSelf",
      "o": "@$1",
      "d": 1638404,
      "h": 167505362948,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167505362948),
//--TRIMMABLE-BOUNDARY-START(180390264836),
    {
      "r": 1114116,
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "Attribute",
      "d": 1638404,
      "h": 180390264836,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180390264836),
//--TRIMMABLE-BOUNDARY-START(184685232132),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,
      "n": "Attributes",
      "d": 1638404,
      "h": 184685232132,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184685232132),
//--TRIMMABLE-BOUNDARY-START(188980199428),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "Attributes",
      "o": "@$1",
      "d": 1638404,
      "h": 188980199428,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188980199428),
//--TRIMMABLE-BOUNDARY-START(210455035908),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,
      "n": "DescendantNodesAndSelf",
      "d": 1638404,
      "h": 210455035908,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210455035908),
//--TRIMMABLE-BOUNDARY-START(214750003204),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "n": "DescendantsAndSelf",
      "d": 1638404,
      "h": 214750003204,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214750003204),
//--TRIMMABLE-BOUNDARY-START(219044970500),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "DescendantsAndSelf",
      "o": "@$1",
      "d": 1638404,
      "h": 219044970500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(219044970500),
//--TRIMMABLE-BOUNDARY-START(317829218308),
    {
      "r": 2162692,
      "n": "GetDefaultNamespace",
      "d": 1638404,
      "h": 317829218308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(317829218308),
//--TRIMMABLE-BOUNDARY-START(322124185604),
    {
      "r": 2162692,
      "p": [
        {
          "n": "prefix",
          "p": 1310721
        }
      ],
      "n": "GetNamespaceOfPrefix",
      "d": 1638404,
      "h": 322124185604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(322124185604),
//--TRIMMABLE-BOUNDARY-START(330714120196),
    {
      "r": 1310721,
      "p": [
        {
          "n": "ns",
          "p": 2162692
        }
      ],
      "n": "GetPrefixOfNamespace",
      "d": 1638404,
      "h": 330714120196,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(330714120196),
//--TRIMMABLE-BOUNDARY-START(377958760452),
    {
      "r": 1638404,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        }
      ],
      "n": "Load",
      "o": "@$5",
      "d": 1638404,
      "h": 377958760452,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(377958760452),
//--TRIMMABLE-BOUNDARY-START(373663793156),
    {
      "r": 1638404,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 655364
        }
      ],
      "n": "Load",
      "o": "@$4",
      "d": 1638404,
      "h": 373663793156,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(373663793156),
//--TRIMMABLE-BOUNDARY-START(360778891268),
    {
      "r": 1638404,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        }
      ],
      "n": "Load",
      "o": "@$1",
      "d": 1638404,
      "h": 360778891268,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(360778891268),
//--TRIMMABLE-BOUNDARY-START(356483923972),
    {
      "r": 1638404,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "options",
          "p": 655364
        }
      ],
      "n": "Load",
      "d": 1638404,
      "h": 356483923972,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(356483923972),
//--TRIMMABLE-BOUNDARY-START(390843662340),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "options",
          "p": 655364
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "LoadAsync",
      "d": 1638404,
      "h": 390843662340,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(390843662340),
//--TRIMMABLE-BOUNDARY-START(369368825860),
    {
      "r": 1638404,
      "p": [
        {
          "n": "textReader",
          "p": 95682561
        }
      ],
      "n": "Load",
      "o": "@$3",
      "d": 1638404,
      "h": 369368825860,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(369368825860),
//--TRIMMABLE-BOUNDARY-START(365073858564),
    {
      "r": 1638404,
      "p": [
        {
          "n": "textReader",
          "p": 95682561
        },
        {
          "n": "options",
          "p": 655364
        }
      ],
      "n": "Load",
      "o": "@$2",
      "d": 1638404,
      "h": 365073858564,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(365073858564),
//--TRIMMABLE-BOUNDARY-START(395138629636),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "textReader",
          "p": 95682561
        },
        {
          "n": "options",
          "p": 655364
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "LoadAsync",
      "o": "@$1",
      "d": 1638404,
      "h": 395138629636,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(395138629636),
//--TRIMMABLE-BOUNDARY-START(386548695044),
    {
      "r": 1638404,
      "p": [
        {
          "n": "reader",
          "p": 53346307
        }
      ],
      "n": "Load",
      "o": "@$7",
      "d": 1638404,
      "h": 386548695044,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(386548695044),
//--TRIMMABLE-BOUNDARY-START(382253727748),
    {
      "r": 1638404,
      "p": [
        {
          "n": "reader",
          "p": 53346307
        },
        {
          "n": "options",
          "p": 655364
        }
      ],
      "n": "Load",
      "o": "@$6",
      "d": 1638404,
      "h": 382253727748,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(382253727748),
//--TRIMMABLE-BOUNDARY-START(399433596932),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "reader",
          "p": 53346307
        },
        {
          "n": "options",
          "p": 655364
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "LoadAsync",
      "o": "@$2",
      "d": 1638404,
      "h": 399433596932,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(399433596932),
//--TRIMMABLE-BOUNDARY-START(403728564228),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,
      "p": [
        {
          "n": "reader",
          "p": 53346307
        },
        {
          "n": "options",
          "p": 655364
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "LoadAsyncInternal",
      "d": 1638404,
      "h": 403728564228,
      "f": 16781346
    },
//--TRIMMABLE-BOUNDARY-END(403728564228),
//--TRIMMABLE-BOUNDARY-START(425203400708),
    {
      "r": 1638404,
      "p": [
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "Parse",
      "o": "@$1",
      "d": 1638404,
      "h": 425203400708,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(425203400708),
//--TRIMMABLE-BOUNDARY-START(420908433412),
    {
      "r": 1638404,
      "p": [
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 655364
        }
      ],
      "n": "Parse",
      "d": 1638404,
      "h": 420908433412,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(420908433412),
//--TRIMMABLE-BOUNDARY-START(442383269892),
    {
      "r": 65537,
      "n": "RemoveAll",
      "d": 1638404,
      "h": 442383269892,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(442383269892),
//--TRIMMABLE-BOUNDARY-START(450973204484),
    {
      "r": 65537,
      "n": "RemoveAttributes",
      "d": 1638404,
      "h": 450973204484,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(450973204484),
//--TRIMMABLE-BOUNDARY-START(459563139076),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "ReplaceAll",
      "d": 1638404,
      "h": 459563139076,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(459563139076),
//--TRIMMABLE-BOUNDARY-START(463858106372),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "ReplaceAll",
      "o": "@$1",
      "d": 1638404,
      "h": 463858106372,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(463858106372),
//--TRIMMABLE-BOUNDARY-START(468153073668),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": "ReplaceAttributes",
      "d": 1638404,
      "h": 468153073668,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(468153073668),
//--TRIMMABLE-BOUNDARY-START(472448040964),
    {
      "r": 65537,
      "p": [
        {
          "n": "content",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "ReplaceAttributes",
      "o": "@$1",
      "d": 1638404,
      "h": 472448040964,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(472448040964),
//--TRIMMABLE-BOUNDARY-START(481037975556),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        }
      ],
      "n": "Save",
      "o": "@$1",
      "d": 1638404,
      "h": 481037975556,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(481037975556),
//--TRIMMABLE-BOUNDARY-START(476743008260),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "options",
          "p": 983044
        }
      ],
      "n": "Save",
      "d": 1638404,
      "h": 476743008260,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(476743008260),
//--TRIMMABLE-BOUNDARY-START(506807779332),
    {
      "r": 177668097,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "options",
          "p": 983044
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "SaveAsync",
      "d": 1638404,
      "h": 506807779332,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(506807779332),
//--TRIMMABLE-BOUNDARY-START(489627910148),
    {
      "r": 65537,
      "p": [
        {
          "n": "textWriter",
          "p": 95813633
        }
      ],
      "n": "Save",
      "o": "@$3",
      "d": 1638404,
      "h": 489627910148,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(489627910148),
//--TRIMMABLE-BOUNDARY-START(485332942852),
    {
      "r": 65537,
      "p": [
        {
          "n": "textWriter",
          "p": 95813633
        },
        {
          "n": "options",
          "p": 983044
        }
      ],
      "n": "Save",
      "o": "@$2",
      "d": 1638404,
      "h": 485332942852,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(485332942852),
//--TRIMMABLE-BOUNDARY-START(511102746628),
    {
      "r": 177668097,
      "p": [
        {
          "n": "textWriter",
          "p": 95813633
        },
        {
          "n": "options",
          "p": 983044
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "SaveAsync",
      "o": "@$1",
      "d": 1638404,
      "h": 511102746628,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(511102746628),
//--TRIMMABLE-BOUNDARY-START(502512812036),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        }
      ],
      "n": "Save",
      "o": "@$6",
      "d": 1638404,
      "h": 502512812036,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(502512812036),
//--TRIMMABLE-BOUNDARY-START(515397713924),
    {
      "r": 177668097,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "SaveAsync",
      "o": "@$2",
      "d": 1638404,
      "h": 515397713924,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(515397713924),
//--TRIMMABLE-BOUNDARY-START(519692681220),
    {
      "r": 177668097,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "SaveAsyncInternal",
      "d": 1638404,
      "h": 519692681220,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(519692681220),
//--TRIMMABLE-BOUNDARY-START(541167517700),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 2097156
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetAttributeValue",
      "d": 1638404,
      "h": 541167517700,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(541167517700),
//--TRIMMABLE-BOUNDARY-START(545462484996),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 2097156
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetElementValue",
      "d": 1638404,
      "h": 545462484996,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(545462484996),
//--TRIMMABLE-BOUNDARY-START(554052419588),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetValue",
      "d": 1638404,
      "h": 554052419588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(554052419588),
//--TRIMMABLE-BOUNDARY-START(579822223364),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        }
      ],
      "n": "WriteTo",
      "d": 1638404,
      "h": 579822223364,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(579822223364),
//--TRIMMABLE-BOUNDARY-START(584117190660),
    {
      "r": 177668097,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteToAsync",
      "d": 1638404,
      "h": 584117190660,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(584117190660),
//--TRIMMABLE-BOUNDARY-START(154620461060),
    {
      "r": 65537,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "AddAttribute",
      "d": 1638404,
      "h": 154620461060,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(154620461060),
//--TRIMMABLE-BOUNDARY-START(158915428356),
    {
      "r": 65537,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "AddAttributeSkipNotify",
      "d": 1638404,
      "h": 158915428356,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(158915428356),
//--TRIMMABLE-BOUNDARY-START(171800330244),
    {
      "r": 65537,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "AppendAttribute",
      "d": 1638404,
      "h": 171800330244,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(171800330244),
//--TRIMMABLE-BOUNDARY-START(176095297540),
    {
      "r": 65537,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "AppendAttributeSkipNotify",
      "d": 1638404,
      "h": 176095297540,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(176095297540),
//--TRIMMABLE-BOUNDARY-START(193275166724),
    {
      "r": 262145,
      "p": [
        {
          "n": "e",
          "p": 1638404
        }
      ],
      "n": "AttributesEqual",
      "d": 1638404,
      "h": 193275166724,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(193275166724),
//--TRIMMABLE-BOUNDARY-START(197570134020),
    {
      "r": 2228228,
      "n": "CloneNode",
      "d": 1638404,
      "h": 197570134020,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(197570134020),
//--TRIMMABLE-BOUNDARY-START(206160068612),
    {
      "r": 262145,
      "p": [
        {
          "n": "node",
          "p": 2228228
        }
      ],
      "n": "DeepEquals",
      "o": "@$1",
      "d": 1638404,
      "h": 206160068612,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(206160068612),
//--TRIMMABLE-BOUNDARY-START(309239283716),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": "GetAttributes",
      "d": 1638404,
      "h": 309239283716,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(309239283716),
//--TRIMMABLE-BOUNDARY-START(326419152900),
    {
      "r": 1310721,
      "p": [
        {
          "n": "prefix",
          "p": 1310721
        },
        {
          "n": "outOfScope",
          "p": 1638404
        }
      ],
      "n": "GetNamespaceOfPrefixInScope",
      "d": 1638404,
      "h": 326419152900,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(326419152900),
//--TRIMMABLE-BOUNDARY-START(313534251012),
    {
      "r": 655361,
      "n": "GetDeepHashCode",
      "d": 1638404,
      "h": 313534251012,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(313534251012),
//--TRIMMABLE-BOUNDARY-START(429498368004),
    {
      "r": 65537,
      "p": [
        {
          "n": "r",
          "p": 53346307
        },
        {
          "n": "o",
          "p": 655364
        }
      ],
      "n": "ReadElementFrom",
      "d": 1638404,
      "h": 429498368004,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(429498368004),
//--TRIMMABLE-BOUNDARY-START(433793335300),
    {
      "r": 177668097,
      "p": [
        {
          "n": "r",
          "p": 53346307
        },
        {
          "n": "o",
          "p": 655364
        },
        {
          "n": "cancellationTokentoken",
          "p": 170065921
        }
      ],
      "n": "ReadElementFromAsync",
      "d": 1638404,
      "h": 433793335300,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(433793335300),
//--TRIMMABLE-BOUNDARY-START(438088302596),
    {
      "r": 65537,
      "p": [
        {
          "n": "r",
          "p": 53346307
        },
        {
          "n": "o",
          "p": 655364
        }
      ],
      "n": "ReadElementFromImpl",
      "d": 1638404,
      "h": 438088302596,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(438088302596),
//--TRIMMABLE-BOUNDARY-START(446678237188),
    {
      "r": 65537,
      "p": [
        {
          "n": "a",
          "p": 1114116
        }
      ],
      "n": "RemoveAttribute",
      "d": 1638404,
      "h": 446678237188,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(446678237188),
//--TRIMMABLE-BOUNDARY-START(455268171780),
    {
      "r": 65537,
      "n": "RemoveAttributesSkipNotify",
      "d": 1638404,
      "h": 455268171780,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(455268171780),
//--TRIMMABLE-BOUNDARY-START(549757452292),
    {
      "r": 65537,
      "p": [
        {
          "n": "lineNumber",
          "p": 655361
        },
        {
          "n": "linePosition",
          "p": 655361
        }
      ],
      "n": "SetEndElementLineInfo",
      "d": 1638404,
      "h": 549757452292,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(549757452292),
//--TRIMMABLE-BOUNDARY-START(571232288772),
    {
      "r": 65537,
      "p": [
        {
          "n": "node",
          "p": 2228228
        },
        {
          "n": "previous",
          "p": 2228228
        }
      ],
      "n": "ValidateNode",
      "d": 1638404,
      "h": 571232288772,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(571232288772)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(408023531524),
    {
      "t": 2097156,
      "n": "name",
      "d": 1638404,
      "h": 408023531524,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(408023531524),
//--TRIMMABLE-BOUNDARY-START(347893989380),
    {
      "t": 1114116,
      "n": "lastAttr",
      "d": 1638404,
      "h": 347893989380,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(347893989380)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(146030526468),
    {
      "p": [
        {
          "n": "name",
          "p": 2097156
        }
      ],
      "n": ".ctor",
      "o": "$ctor$12",
      "d": 1638404,
      "h": 146030526468,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146030526468),
//--TRIMMABLE-BOUNDARY-START(137440591876),
    {
      "p": [
        {
          "n": "name",
          "p": 2097156
        },
        {
          "n": "content",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 1638404,
      "h": 137440591876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137440591876),
//--TRIMMABLE-BOUNDARY-START(141735559172),
    {
      "p": [
        {
          "n": "name",
          "p": 2097156
        },
        {
          "n": "content",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 1638404,
      "h": 141735559172,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141735559172),
//--TRIMMABLE-BOUNDARY-START(133145624580),
    {
      "p": [
        {
          "n": "other",
          "p": 1638404
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 1638404,
      "h": 133145624580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133145624580),
//--TRIMMABLE-BOUNDARY-START(150325493764),
    {
      "p": [
        {
          "n": "other",
          "p": 2883588
        }
      ],
      "n": ".ctor",
      "o": "$ctor$13",
      "d": 1638404,
      "h": 150325493764,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150325493764),
//--TRIMMABLE-BOUNDARY-START(115965755396),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1638404,
      "h": 115965755396,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(115965755396),
//--TRIMMABLE-BOUNDARY-START(124555689988),
    {
      "p": [
        {
          "n": "r",
          "p": 53346307
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1638404,
      "h": 124555689988,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(124555689988),
//--TRIMMABLE-BOUNDARY-START(128850657284),
    {
      "p": [
        {
          "n": "_",
          "p": 1703940
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1638404,
      "h": 128850657284,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128850657284),
//--TRIMMABLE-BOUNDARY-START(120260722692),
    {
      "p": [
        {
          "n": "r",
          "p": 53346307
        },
        {
          "n": "o",
          "p": 655364
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1638404,
      "h": 120260722692,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(120260722692)
  ],
  "i": [13893635,37224451
  ],
  "j": [1703940
  ],
  "h": 1638404,
  "a": [
    {
      "t": 44826627,
      "c": 12929728515,
      "a": [
        {
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "IsAny",
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 1638418,
      "c": 8591573010,
      "a": [
        {
          "v": "MS.Internal.Xml.Linq.ComponentModel.XTypeDescriptionProvider\u00601[[System.Xml.Linq.XElement, System.Xml.Linq, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]],System.ComponentModel.TypeConverter",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XContainer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo, $.$spx.System.Xml.Serialization.IXmlSerializable ]; }
            static get $fullName() { return `System.Xml.Linq.XElement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638404)
        
        
        //--TRIMMABLE-BOUNDARY-START(3080196)
        $asm.$cls("$spxl.System.Xml.Schema.XmlSchemaInfoEqualityComparer", ($self) => class XmlSchemaInfoEqualityComparer extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593014788)
            /*bool */ Equals$2(/*XmlSchemaInfo?*/ si1, /*XmlSchemaInfo?*/ si2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593014788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (si1 === si2)
                {
                    return true;
                }
                if (si1 === null || si2 === null)
                {
                    return false;
                }
                return si1.ContentType === si2.ContentType && si1.IsDefault === si2.IsDefault && si1.IsNil === si2.IsNil && $.$cast(si1.MemberType, $.$$.System.Object) === $.$cast(si2.MemberType, $.$$.System.Object) && $.$cast(si1.SchemaAttribute, $.$$.System.Object) === $.$cast(si2.SchemaAttribute, $.$$.System.Object) && $.$cast(si1.SchemaElement, $.$$.System.Object) === $.$cast(si2.SchemaElement, $.$$.System.Object) && $.$cast(si1.SchemaType, $.$$.System.Object) === $.$cast(si2.SchemaType, $.$$.System.Object) && si1.Validity === si2.Validity;
            }
            //--TRIMMABLE-BOUNDARY-END(8593014788)
            
            //--TRIMMABLE-BOUNDARY-START(12887982084)
            /*int */ GetHashCode$1(/*XmlSchemaInfo?*/ si)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887982084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (si === null)
                {
                    return 0;
                }
                /*int*/ let h = si.ContentType;
                if (si.IsDefault)
                {
                    h ^= 1;
                }
                if (si.IsNil)
                {
                    h ^= 1;
                }
                /*XmlSchemaSimpleType?*/ let memberType = si.MemberType;
                if (memberType !== null)
                {
                    h ^= $.$$.System.Object.GetHashCode.call(memberType);
                }
                /*XmlSchemaAttribute?*/ let schemaAttribute = si.SchemaAttribute;
                if (schemaAttribute !== null)
                {
                    h ^= $.$$.System.Object.GetHashCode.call(schemaAttribute);
                }
                /*XmlSchemaElement?*/ let schemaElement = si.SchemaElement;
                if (schemaElement !== null)
                {
                    h ^= $.$$.System.Object.GetHashCode.call(schemaElement);
                }
                /*XmlSchemaType?*/ let schemaType = si.SchemaType;
                if (schemaType !== null)
                {
                    h ^= $.$$.System.Object.GetHashCode.call(schemaType);
                }
                h ^= si.Validity;
                return h;
            }
            //--TRIMMABLE-BOUNDARY-END(12887982084)
            
            //--TRIMMABLE-BOUNDARY-START(4354736129)
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Schema.XmlSchemaInfo>.Equals(System.Xml.Schema.XmlSchemaInfo?, System.Xml.Schema.XmlSchemaInfo?)
            System$Collections$Generic$IEqualityComparer$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354736129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354736129)
            
            //--TRIMMABLE-BOUNDARY-START(8649703425)
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Schema.XmlSchemaInfo>.GetHashCode(System.Xml.Schema.XmlSchemaInfo)
            System$Collections$Generic$IEqualityComparer$$$GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649703425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetHashCode$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649703425)
            
            //--TRIMMABLE-BOUNDARY-START(4298047492)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298047492)
            
            static $h = 3080196;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593014788),
    {
      "r": 262145,
      "p": [
        {
          "n": "si1",
          "p": 30081027
        },
        {
          "n": "si2",
          "p": 30081027
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 3080196,
      "h": 8593014788,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593014788),
//--TRIMMABLE-BOUNDARY-START(12887982084),
    {
      "r": 655361,
      "p": [
        {
          "n": "si",
          "p": 30081027
        }
      ],
      "n": "GetHashCode",
      "o": "@$1",
      "d": 3080196,
      "h": 12887982084,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887982084)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298047492),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3080196,
      "h": 4298047492,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298047492)
  ],
  "i": [$.$$.System.Collections.Generic.IEqualityComparer$$($.$spx.System.Xml.Schema.XmlSchemaInfo).$h
  ],
  "h": 3080196
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEqualityComparer$$($.$spx.System.Xml.Schema.XmlSchemaInfo) ]; }
            static get $fullName() { return `System.Xml.Schema.XmlSchemaInfoEqualityComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3080196)
        
        
        //--TRIMMABLE-BOUNDARY-START(589828)
        $asm.$cls("$spxl.System.Xml.Linq.LineInfoEndElementAnnotation", ($self) => class LineInfoEndElementAnnotation extends $.$spxl.System.Xml.Linq.LineInfoAnnotation
        {
            //--TRIMMABLE-BOUNDARY-START(4295557124)
            $ctor$2(/*int*/ lineNumber, /*int*/ linePosition)
            {
                super.$ctor$1(lineNumber, linePosition);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295557124);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557124)
            
            static $h = 589828;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 524292,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557124),
    {
      "p": [
        {
          "n": "lineNumber",
          "p": 655361
        },
        {
          "n": "linePosition",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589828,
      "h": 4295557124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557124)
  ],
  "h": 589828
}; }
            static get $b() { return $.$spxl.System.Xml.Linq.LineInfoAnnotation; }
            static get $fullName() { return `System.Xml.Linq.LineInfoEndElementAnnotation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589828)
        
        
        //--TRIMMABLE-BOUNDARY-START(2752516)
        $asm.$cls("$spxl.System.Xml.Linq.XObjectChangeEventArgs", ($self) => class XObjectChangeEventArgs extends $.$$.System.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(4297719812)
            /*XObjectChange*/ _objectChange = 0;
            //--TRIMMABLE-BOUNDARY-END(4297719812)
            
            //--TRIMMABLE-BOUNDARY-START(17182621700)
            /*XObjectChangeEventArgs*/ static Add = null;
            //--TRIMMABLE-BOUNDARY-END(17182621700)
            
            //--TRIMMABLE-BOUNDARY-START(38657458180)
            /*XObjectChangeEventArgs*/ static Remove = null;
            //--TRIMMABLE-BOUNDARY-END(38657458180)
            
            //--TRIMMABLE-BOUNDARY-START(30067523588)
            /*XObjectChangeEventArgs*/ static Name = null;
            //--TRIMMABLE-BOUNDARY-END(30067523588)
            
            //--TRIMMABLE-BOUNDARY-START(42952425476)
            /*XObjectChangeEventArgs*/ static Value = null;
            //--TRIMMABLE-BOUNDARY-END(42952425476)
            
            //--TRIMMABLE-BOUNDARY-START(12887654404)
            $ctor$2(/*XObjectChange*/ objectChange)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887654404);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._objectChange = objectChange;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887654404)
            
            //--TRIMMABLE-BOUNDARY-START(34362490884)
            /*XObjectChange */ get ObjectChange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772556292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._objectChange;
            }
            //--TRIMMABLE-BOUNDARY-END(34362490884)
            
            //--TRIMMABLE-BOUNDARY-START(8592687108)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17182621700)
                    this.Add = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(0/*XObjectChange.Add*/);
                    //--TRIMMABLE-BOUNDARY-END(17182621700)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38657458180)
                    this.Remove = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(1/*XObjectChange.Remove*/);
                    //--TRIMMABLE-BOUNDARY-END(38657458180)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30067523588)
                    this.Name = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(2/*XObjectChange.Name*/);
                    //--TRIMMABLE-BOUNDARY-END(30067523588)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42952425476)
                    this.Value = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(3/*XObjectChange.Value*/);
                    //--TRIMMABLE-BOUNDARY-END(42952425476)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592687108)
            
            static $h = 2752516;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79757313,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362490884),
    {
      "p": 2621444,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772556292,
        "f": 50331649
      },
      "n": "ObjectChange",
      "d": 2752516,
      "h": 34362490884,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362490884)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297719812),
    {
      "t": 2621444,
      "n": "_objectChange",
      "d": 2752516,
      "h": 4297719812,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297719812),
//--TRIMMABLE-BOUNDARY-START(17182621700),
    {
      "t": 2752516,
      "n": "Add",
      "d": 2752516,
      "h": 17182621700,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182621700),
//--TRIMMABLE-BOUNDARY-START(38657458180),
    {
      "t": 2752516,
      "n": "Remove",
      "d": 2752516,
      "h": 38657458180,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38657458180),
//--TRIMMABLE-BOUNDARY-START(30067523588),
    {
      "t": 2752516,
      "n": "Name",
      "d": 2752516,
      "h": 30067523588,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067523588),
//--TRIMMABLE-BOUNDARY-START(42952425476),
    {
      "t": 2752516,
      "n": "Value",
      "d": 2752516,
      "h": 42952425476,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42952425476)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887654404),
    {
      "p": [
        {
          "n": "objectChange",
          "p": 2621444
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2752516,
      "h": 12887654404,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887654404)
  ],
  "h": 2752516
}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.Xml.Linq.XObjectChangeEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752516)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179652)
        $asm.$cls("$spxl.System.Xml.Linq.XCData", ($self) => class XCData extends $.$spxl.System.Xml.Linq.XText
        {
            //--TRIMMABLE-BOUNDARY-START(4296146948)
            $ctor$6(/*string*/ value)
            {
                super.$ctor$3(value);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296146948);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296146948)
            
            //--TRIMMABLE-BOUNDARY-START(12886081540)
            $ctor$8(/*XCData*/ other)
            {
                super.$ctor$5(other);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886081540);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081540)
            
            //--TRIMMABLE-BOUNDARY-START(8591114244)
            $ctor$7(/*XmlReader*/ r)
            {
                super.$ctor$4(r);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591114244);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114244)
            
            //--TRIMMABLE-BOUNDARY-START(30065950724)
            /*XmlNodeType */ get NodeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770983428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 4/*XmlNodeType.CDATA*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065950724)
            
            //--TRIMMABLE-BOUNDARY-START(34360918020)
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360918020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                writer.WriteCData(this.text);
            }
            //--TRIMMABLE-BOUNDARY-END(34360918020)
            
            //--TRIMMABLE-BOUNDARY-START(38655885316)
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655885316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return writer.WriteCDataAsync(this.text);
            }
            //--TRIMMABLE-BOUNDARY-END(38655885316)
            
            //--TRIMMABLE-BOUNDARY-START(17181048836)
            /*XNode */ CloneNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181048836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$spxl.System.Xml.Linq.XCData().$ctor$8(this);
            }
            //--TRIMMABLE-BOUNDARY-END(17181048836)
            
            static $h = 1179652;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2949124,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065950724),
    {
      "p": 52822019,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770983428,
        "f": 50364417
      },
      "n": "NodeType",
      "d": 1179652,
      "h": 30065950724,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065950724)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360918020),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        }
      ],
      "n": "WriteTo",
      "d": 1179652,
      "h": 34360918020,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360918020),
//--TRIMMABLE-BOUNDARY-START(38655885316),
    {
      "r": 177668097,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteToAsync",
      "d": 1179652,
      "h": 38655885316,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655885316),
//--TRIMMABLE-BOUNDARY-START(17181048836),
    {
      "r": 2228228,
      "n": "CloneNode",
      "d": 1179652,
      "h": 17181048836,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(17181048836)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296146948),
    {
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1179652,
      "h": 4296146948,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296146948),
//--TRIMMABLE-BOUNDARY-START(12886081540),
    {
      "p": [
        {
          "n": "other",
          "p": 1179652
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1179652,
      "h": 12886081540,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886081540),
//--TRIMMABLE-BOUNDARY-START(8591114244),
    {
      "p": [
        {
          "n": "r",
          "p": 53346307
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1179652,
      "h": 8591114244,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591114244)
  ],
  "i": [13893635
  ],
  "h": 1179652
}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XText; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XCData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179652)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml"))
//--TRIMMABLE-BOUNDARY-END(4)
