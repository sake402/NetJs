
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $srei, $srel, $srp, $sri, $srl, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $scm, $so, $srn, $ssc, $sris, $stc, $scp, $scsl, $sfa, $sic, $sim, $sl, $snp, $sspw, $srij, $scs, $sicb, $sci, $sdd, $sdts, $srm, $snnr, $sds, $sre, $sns, $sscr, $sle, $str, $snn, $snsc, $snq, $snh, $spx) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Private.Xml.Linq", 
    {"h":36401,"f":"System.Private.Xml.Linq","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Private.Xml.Linq","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Private.Xml.Linq","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$spxl.System.Xml.Linq.XObject", ($self) => class XObject extends $.$spc.System.Object
        {
            /*XContainer?*/ parent = null;
            /*object?*/ annotations = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string */ get BaseUri()
            {
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        break;
                    }
                    /*BaseUriAnnotation?*/ let a = o.Annotation$1($.$spxl.System.Xml.Linq.BaseUriAnnotation);
                    if (a !== null)
                    {
                        return a.baseUri;
                    }
                    o = o.parent;
                }
                return $.$spc.System.String.Empty;
            }
            /*XDocument? */ get Document()
            {
                /*XObject*/ let n = this;
                while(n.parent !== null)
                {
                    n = n.parent;
                }
                /*XDocument?*/ let doc = $.$as(n, $.$spxl.System.Xml.Linq.XDocument);
                return doc;
            }
            /*XElement? */ get Parent()
            {
                return $.$as(this.parent, $.$spxl.System.Xml.Linq.XElement);
            }
            /*void */ AddAnnotation(/*object*/ annotation)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(annotation, "annotation");
                if (this.annotations === null)
                {
                    this.annotations = $.$is(annotation, $.$typeArray($.$spc.System.Object)) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [annotation], [-1], null) : annotation;
                }
                else 
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                    if (a === null)
                    {
                        this.annotations = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [this.annotations, annotation], [-1], null);
                    }
                    else 
                    {
                        /*int*/ let i = 0;
                        while(i < a.length && $.$spc.System.Array.$ReadT1.call(a, i) !== null)
                        {
                            i++;
                        }
                        if (i === a.length)
                        {
                            $.$spc.System.Array.Resize($.$spc.System.Object, $.$ref(() => a, ($v) => a = $v, $.$typeArray($.$spc.System.Object)), ((i * 2) | 0));
                            this.annotations = a;
                        }
                        $.$spc.System.Array.$WriteT1.call(a, annotation, i);
                    }
                }
            }
            /*object? */ Annotation(/*Type*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                    if (a === null)
                    {
                        if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(this.annotations, type))
                        {
                            return this.annotations;
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < a.length; i++)
                        {
                            /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(obj, type))
                            {
                                return obj;
                            }
                        }
                    }
                }
                return null;
            }
            /*object? */ AnnotationForSealedType(/*Type*/ type)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Inequality$1(type, null), "type != null");
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                    if (a === null)
                    {
                        if ($.$spc.System.Type.op_Equality$1($.$spc.System.Object.GetType.call(this.annotations), type))
                        {
                            return this.annotations;
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < a.length; i++)
                        {
                            /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if ($.$spc.System.Type.op_Equality$1($.$spc.System.Object.GetType.call(obj), type))
                            {
                                return obj;
                            }
                        }
                    }
                }
                return null;
            }
            /*T? */ Annotation$1(T, )
            {
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                    if (a === null)
                    {
                        return $.$as(this.annotations, T);
                    }
                    for(/*int*/ let i = 0; i < a.length; i++)
                    {
                        /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(a, i);
                        if (obj === null)
                        {
                            break;
                        }
                        /*T?*/ let result = $.$as(obj, T);
                        if ($.$box(result, T) !== null)
                        {
                            return result;
                        }
                    }
                }
                return null;
            }
            /*IEnumerable<object> */ Annotations(/*Type*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                return this.AnnotationsIterator(type);
            }
            /*IEnumerable<object> */ AnnotationsIterator(/*Type*/ type)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    if (this.annotations !== null)
                    {
                        /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                        if (a === null)
                        {
                            if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(this.annotations, type))
                            {
                                yield this.annotations;
                            }
                        }
                        else 
                        {
                            for(/*int*/ let i = 0; i < a.length; i++)
                            {
                                /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(a, i);
                                if (obj === null)
                                {
                                    break;
                                }
                                if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(obj, type))
                                {
                                    yield obj;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*IEnumerable<T> */ Annotations$1(T, )
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    if (this.annotations !== null)
                    {
                        /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                        if (a === null)
                        {
                            /*T?*/ let result = $.$as(this.annotations, T);
                            if ($.$box(result, T) !== null)
                            {
                                yield result;
                            }
                        }
                        else 
                        {
                            for(/*int*/ let i = 0; i < a.length; i++)
                            {
                                /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(a, i);
                                if (obj === null)
                                {
                                    break;
                                }
                                /*T?*/ let result = $.$as(obj, T);
                                if ($.$box(result, T) !== null)
                                {
                                    yield result;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*void */ RemoveAnnotations(/*Type*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                    if (a === null)
                    {
                        if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(this.annotations, type))
                        {
                            this.annotations = null;
                        }
                    }
                    else 
                    {
                        /*int*/ let i = 0, j = 0;
                        while(i < a.length)
                        {
                            /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if (!$.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(obj, type))
                            {
                                $.$spc.System.Array.$WriteT1.call(a, obj, j++);
                            }
                            i++;
                        }
                        if (j === 0)
                        {
                            this.annotations = null;
                        }
                        else 
                        {
                            while(j < i)
                            {
                                $.$spc.System.Array.$WriteT1.call(a, null, j++);
                            }
                        }
                    }
                }
            }
            /*void */ RemoveAnnotations$1(T, )
            {
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                    if (a === null)
                    {
                        if ($.$is(this.annotations, T))
                        {
                            this.annotations = null;
                        }
                    }
                    else 
                    {
                        /*int*/ let i = 0, j = 0;
                        while(i < a.length)
                        {
                            /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if (!($.$is(obj, T)))
                            {
                                $.$spc.System.Array.$WriteT1.call(a, obj, j++);
                            }
                            i++;
                        }
                        if (j === 0)
                        {
                            this.annotations = null;
                        }
                        else 
                        {
                            while(j < i)
                            {
                                $.$spc.System.Array.$WriteT1.call(a, null, j++);
                            }
                        }
                    }
                }
            }
            /*EventHandler<XObjectChangeEventArgs>*/ add_Changed(value)
            {
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    a = new $.$spxl.System.Xml.Linq.XObjectChangeAnnotation().$ctor$1();
                    this.AddAnnotation(a);
                }
                a.changed = $.$spc.System.Delegate.Combine(a.changed, value);
            }
            /*EventHandler<XObjectChangeEventArgs>*/ remove_Changed(value)
            {
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    return;
                }
                a.changed = $.$spc.System.Delegate.Remove(a.changed, value);
                if (a.changing === null && a.changed === null)
                {
                    this.RemoveAnnotations$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                }
            }
            /*EventHandler<XObjectChangeEventArgs>*/ add_Changing(value)
            {
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    a = new $.$spxl.System.Xml.Linq.XObjectChangeAnnotation().$ctor$1();
                    this.AddAnnotation(a);
                }
                a.changing = $.$spc.System.Delegate.Combine(a.changing, value);
            }
            /*EventHandler<XObjectChangeEventArgs>*/ remove_Changing(value)
            {
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    return;
                }
                a.changing = $.$spc.System.Delegate.Remove(a.changing, value);
                if (a.changing === null && a.changed === null)
                {
                    this.RemoveAnnotations$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                }
            }
            /*bool */ System$Xml$IXmlLineInfo$HasLineInfo()
            {
                return this.Annotation$1($.$spxl.System.Xml.Linq.LineInfoAnnotation) !== null;
            }
            /*int */ get System$Xml$IXmlLineInfo$LineNumber()
            {
                /*LineInfoAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.LineInfoAnnotation);
                if (a !== null)
                {
                    return a.lineNumber;
                }
                return 0;
            }
            /*int */ get System$Xml$IXmlLineInfo$LinePosition()
            {
                /*LineInfoAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.LineInfoAnnotation);
                if (a !== null)
                {
                    return a.linePosition;
                }
                return 0;
            }
            /*bool */ get HasBaseUri()
            {
                return this.Annotation$1($.$spxl.System.Xml.Linq.BaseUriAnnotation) !== null;
            }
            /*bool */ NotifyChanged(/*object*/ sender, /*XObjectChangeEventArgs*/ e)
            {
                /*bool*/ let notify = false;
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        break;
                    }
                    /*XObjectChangeAnnotation?*/ let a = o.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                    if (a !== null)
                    {
                        notify = true;
                        a.changed?.Invoke(sender, e);
                    }
                    o = o.parent;
                }
                return notify;
            }
            /*bool */ NotifyChanging(/*object*/ sender, /*XObjectChangeEventArgs*/ e)
            {
                /*bool*/ let notify = false;
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        break;
                    }
                    /*XObjectChangeAnnotation?*/ let a = o.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                    if (a !== null)
                    {
                        notify = true;
                        a.changing?.Invoke(sender, e);
                    }
                    o = o.parent;
                }
                return notify;
            }
            /*void */ SetBaseUri(/*string*/ baseUri)
            {
                this.AddAnnotation(new $.$spxl.System.Xml.Linq.BaseUriAnnotation().$ctor$1(baseUri));
            }
            /*void */ SetLineInfo(/*int*/ lineNumber, /*int*/ linePosition)
            {
                this.AddAnnotation(new $.$spxl.System.Xml.Linq.LineInfoAnnotation().$ctor$1(lineNumber, linePosition));
            }
            /*bool */ SkipNotify()
            {
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        return true;
                    }
                    if (o.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation) !== null)
                    {
                        return false;
                    }
                    o = o.parent;
                }
            }
            /*SaveOptions */ GetSaveOptionsFromAnnotations()
            {
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        return 0/*SaveOptions.None*/;
                    }
                    /*object?*/ let saveOptions = o.AnnotationForSealedType($.$spxl.System.Xml.Linq.SaveOptions.$type);
                    if (saveOptions !== null)
                    {
                        return $.$cast(saveOptions, $.$spxl.System.Xml.Linq.SaveOptions);
                    }
                    o = o.parent;
                }
            }
            static $h = 2592305;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21477428785,"f":1},"n":"BaseUri","d":2592305,"h":17182461489,"f":1},{"p":1543729,"g":{"r":0,"d":0,"h":30067363377,"f":1},"n":"Document","d":2592305,"h":25772396081,"f":1},{"p":52874332,"g":{"r":0,"d":0,"h":38657297969,"f":257},"n":"NodeType","d":2592305,"h":34362330673,"f":257},{"p":1674801,"g":{"r":0,"d":0,"h":47247232561,"f":1},"n":"Parent","d":2592305,"h":42952265265,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":124556643889,"f":2},"n":"{13945948}.LineNumber","o":"System$Xml$IXmlLineInfo$LineNumber","d":2592305,"h":120261676593,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":133146578481,"f":2},"n":"{13945948}.LinePosition","o":"System$Xml$IXmlLineInfo$LinePosition","d":2592305,"h":128851611185,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":141736513073,"f":8},"n":"HasBaseUri","d":2592305,"h":137441545777,"f":8}],"m":[{"r":65537,"p":[{"n":"annotation","p":131073}],"n":"AddAnnotation","d":2592305,"h":51542199857,"f":1},{"r":131073,"p":[{"n":"type","p":142606337}],"n":"Annotation","d":2592305,"h":55837167153,"f":1},{"r":131073,"p":[{"n":"type","p":142606337}],"n":"AnnotationForSealedType","d":2592305,"h":60132134449,"f":2},{"r":(T) => T.$h,"g":["T"],"n":"Annotation","o":"@$1","d":2592305,"h":64427101745,"f":131073},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Object).$h,"p":[{"n":"type","p":142606337}],"n":"Annotations","d":2592305,"h":68722069041,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Object).$h,"p":[{"n":"type","p":142606337}],"n":"AnnotationsIterator","d":2592305,"h":73017036337,"f":2},{"r":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h,"g":["T"],"n":"Annotations","o":"@$1","d":2592305,"h":77312003633,"f":131073},{"r":65537,"p":[{"n":"type","p":142606337}],"n":"RemoveAnnotations","d":2592305,"h":81606970929,"f":1},{"r":65537,"g":["T"],"n":"RemoveAnnotations","o":"@$1","d":2592305,"h":85901938225,"f":131073},{"r":262145,"p":[{"n":"sender","p":131073},{"n":"e","p":2788913}],"n":"NotifyChanged","d":2592305,"h":146031480369,"f":8},{"r":262145,"p":[{"n":"sender","p":131073},{"n":"e","p":2788913}],"n":"NotifyChanging","d":2592305,"h":150326447665,"f":8},{"r":65537,"p":[{"n":"baseUri","p":1310721}],"n":"SetBaseUri","d":2592305,"h":154621414961,"f":8},{"r":65537,"p":[{"n":"lineNumber","p":655361},{"n":"linePosition","p":655361}],"n":"SetLineInfo","d":2592305,"h":158916382257,"f":8},{"r":262145,"n":"SkipNotify","d":2592305,"h":163211349553,"f":8},{"r":1019441,"n":"GetSaveOptionsFromAnnotations","d":2592305,"h":167506316849,"f":8}],"l":[{"t":1347121,"n":"parent","d":2592305,"h":4297559601,"f":8},{"t":131073,"n":"annotations","d":2592305,"h":8592526897,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":2592305,"h":12887494193,"f":8}],"e":[{"e":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h}],"n":"add_Changed","d":2592305,"h":94491872817,"f":1},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h}],"n":"remove_Changed","d":2592305,"h":98786840113,"f":1},"n":"Changed","d":2592305,"h":90196905521,"f":1},{"e":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h}],"n":"add_Changing","d":2592305,"h":107376774705,"f":1},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h}],"n":"remove_Changing","d":2592305,"h":111671742001,"f":1},"n":"Changing","d":2592305,"h":103081807409,"f":1}],"i":[13945948],"h":2592305}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XObject`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNode", ($self) => class XNode extends $.$spxl.System.Xml.Linq.XObject
        {
            /*XNode?*/ next = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*XNode? */ get NextNode()
            {
                return this.parent === null || this === this.parent.content ? null : this.next;
            }
            /*XNode? */ get PreviousNode()
            {
                if (this.parent === null)
                {
                    return null;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this.parent.content !== null, "parent.content != null");
                /*XNode*/ let n = ($.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode)).next;
                /*XNode?*/ let p = null;
                while(n !== this)
                {
                    p = n;
                    n = n.next;
                }
                return p;
            }
            /*XNodeDocumentOrderComparer*/ static DocumentOrderComparer$ = null;
            static /*XNodeDocumentOrderComparer */ get DocumentOrderComparer()
            {
                return $.$spxl.System.Xml.Linq.XNode.DocumentOrderComparer$ ??= new $.$spxl.System.Xml.Linq.XNodeDocumentOrderComparer().$ctor$1();
            }
            /*XNodeEqualityComparer*/ static EqualityComparer$ = null;
            static /*XNodeEqualityComparer */ get EqualityComparer()
            {
                return $.$spxl.System.Xml.Linq.XNode.EqualityComparer$ ??= new $.$spxl.System.Xml.Linq.XNodeEqualityComparer().$ctor$1();
            }
            /*void */ AddAfterSelf(/*object?*/ content)
            {
                if (this.parent === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$2(this.parent, this).Add(content);
            }
            /*void */ AddAfterSelf$1(/*params object?[]*/ content)
            {
                this.AddAfterSelf($.$cast(content, $.$spc.System.Object));
            }
            /*void */ AddBeforeSelf(/*object?*/ content)
            {
                if (this.parent === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                /*XNode?*/ let p = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                while(p.next !== this)
                {
                    p = p.next;
                }
                if (p === this.parent.content)
                {
                    p = null;
                }
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$2(this.parent, p).Add(content);
            }
            /*void */ AddBeforeSelf$1(/*params object?[]*/ content)
            {
                this.AddBeforeSelf($.$cast(content, $.$spc.System.Object));
            }
            /*IEnumerable<XElement> */ Ancestors()
            {
                return this.GetAncestors(null, false);
            }
            /*IEnumerable<XElement> */ Ancestors$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetAncestors(name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*int */ CompareDocumentOrder(/*XNode?*/ n1, /*XNode?*/ n2)
            {
                if (n1 === n2)
                {
                    return 0;
                }
                if (n1 === null)
                {
                    return -1;
                }
                if (n2 === null)
                {
                    return 1;
                }
                if (n1.parent !== n2.parent)
                {
                    /*int*/ let height = 0;
                    /*XNode*/ let p1 = n1;
                    while(p1.parent !== null)
                    {
                        p1 = p1.parent;
                        height++;
                    }
                    /*XNode*/ let p2 = n2;
                    while(p2.parent !== null)
                    {
                        p2 = p2.parent;
                        height--;
                    }
                    if (p1 !== p2)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingAncestor);
                    }
                    if (height < 0)
                    {
                        do
                        {
                            n2 = n2.parent;
                            height++;
                        }
                        while(height !== 0);
                        if (n1 === n2)
                        {
                            return -1;
                        }
                    }
                    else if (height > 0)
                    {
                        do
                        {
                            n1 = n1.parent;
                            height--;
                        }
                        while(height !== 0);
                        if (n1 === n2)
                        {
                            return 1;
                        }
                    }
                    while(n1.parent !== n2.parent)
                    {
                        n1 = n1.parent;
                        n2 = n2.parent;
                    }
                }
                else if (n1.parent === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingAncestor);
                }
                /*XNode*/ let n = $.$cast(n1.parent.content, $.$spxl.System.Xml.Linq.XNode);
                while(true)
                {
                    n = n.next;
                    if (n === n1)
                    {
                        return -1;
                    }
                    if (n === n2)
                    {
                        return 1;
                    }
                }
            }
            /*XmlReader */ CreateReader()
            {
                return new $.$spxl.System.Xml.Linq.XNodeReader().$ctor$3(this, null);
            }
            /*XmlReader */ CreateReader$1(/*ReaderOptions*/ readerOptions)
            {
                return new $.$spxl.System.Xml.Linq.XNodeReader().$ctor$2(this, null, readerOptions);
            }
            /*IEnumerable<XNode> */ NodesAfterSelf()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*XNode*/ let n = this;
                    while(n.parent !== null && n !== n.parent.content)
                    {
                        n = n.next;
                        yield n;
                    }
                }.bind(this));
            }
            /*IEnumerable<XNode> */ NodesBeforeSelf()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    if (this.parent !== null)
                    {
                        /*XNode*/ let n = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                        do
                        {
                            n = n.next;
                            if (n === this)
                            {
                                break;
                            }
                            yield n;
                        }
                        while(this.parent !== null && this.parent === n.parent);
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ ElementsAfterSelf()
            {
                return this.GetElementsAfterSelf(null);
            }
            /*IEnumerable<XElement> */ ElementsAfterSelf$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetElementsAfterSelf(name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*IEnumerable<XElement> */ ElementsBeforeSelf()
            {
                return this.GetElementsBeforeSelf(null);
            }
            /*IEnumerable<XElement> */ ElementsBeforeSelf$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetElementsBeforeSelf(name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*bool */ IsAfter(/*XNode?*/ node)
            {
                return $.$spxl.System.Xml.Linq.XNode.CompareDocumentOrder(this, node) > 0;
            }
            /*bool */ IsBefore(/*XNode?*/ node)
            {
                return $.$spxl.System.Xml.Linq.XNode.CompareDocumentOrder(this, node) < 0;
            }
            static /*XNode */ ReadFrom(/*XmlReader*/ reader)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                if (reader.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                let $switch1 = reader.NodeType;
                switch($switch1)
                {
                    case 3/*XmlNodeType.Text*/:
                    case 14/*XmlNodeType.SignificantWhitespace*/:
                    case 13/*XmlNodeType.Whitespace*/:
                    return new $.$spxl.System.Xml.Linq.XText().$ctor$5(reader);
                    case 4/*XmlNodeType.CDATA*/:
                    return new $.$spxl.System.Xml.Linq.XCData().$ctor$8(reader);
                    case 8/*XmlNodeType.Comment*/:
                    return new $.$spxl.System.Xml.Linq.XComment().$ctor$5(reader);
                    case 10/*XmlNodeType.DocumentType*/:
                    return new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$5(reader);
                    case 1/*XmlNodeType.Element*/:
                    return new $.$spxl.System.Xml.Linq.XElement().$ctor$11(reader);
                    case 7/*XmlNodeType.ProcessingInstruction*/:
                    return new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$5(reader);
                    default:
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                }
            }
            static /*Task<XNode> */ ReadFromAsync(/*XmlReader*/ reader, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spxl.System.Xml.Linq.XNode, cancellationToken);
                }
                return $.$spxl.System.Xml.Linq.XNode.ReadFromAsyncInternal(reader, cancellationToken);
            }
            static /*Task<XNode> *//*async*/  ReadFromAsyncInternal(/*XmlReader*/ reader, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XNode), $.$spxl.System.Xml.Linq.XNode, async () => 
                {
                    if (reader.ReadState !== 1/*ReadState.Interactive*/)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                    }
                    /*XNode*/ let ret;
                    let $switch1 = reader.NodeType;
                    switch($switch1)
                    {
                        case 3/*XmlNodeType.Text*/:
                        case 14/*XmlNodeType.SignificantWhitespace*/:
                        case 13/*XmlNodeType.Whitespace*/:
                        ret = new $.$spxl.System.Xml.Linq.XText().$ctor$3(reader.Value);
                        break;
                        case 4/*XmlNodeType.CDATA*/:
                        ret = new $.$spxl.System.Xml.Linq.XCData().$ctor$6(reader.Value);
                        break;
                        case 8/*XmlNodeType.Comment*/:
                        ret = new $.$spxl.System.Xml.Linq.XComment().$ctor$3(reader.Value);
                        break;
                        case 10/*XmlNodeType.DocumentType*/:
                        /*var*/ let name = reader.Name;
                        /*var*/ let publicId = reader.GetAttribute("PUBLIC");
                        /*var*/ let systemId = reader.GetAttribute("SYSTEM");
                        /*var*/ let internalSubset = reader.Value;
                        ret = new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(name, publicId, systemId, internalSubset);
                        break;
                        case 1/*XmlNodeType.Element*/:
                        return await $.$spxl.System.Xml.Linq.XElement.CreateAsync(reader, cancellationToken).ConfigureAwait$2(false);
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        /*var*/ let target = reader.Name;
                        /*var*/ let data = reader.Value;
                        ret = new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(target, data);
                        break;
                        default:
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                    }
                    cancellationToken.ThrowIfCancellationRequested();
                    await reader.ReadAsync().ConfigureAwait$2(false);
                    return ret;
                });
            }
            /*void */ Remove()
            {
                if (this.parent === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                this.parent.RemoveNode(this);
            }
            /*void */ ReplaceWith(/*object?*/ content)
            {
                if (this.parent === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                /*XContainer*/ let c = this.parent;
                /*XNode?*/ let p = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                while(p.next !== this)
                {
                    p = p.next;
                }
                if (p === this.parent.content)
                {
                    p = null;
                }
                this.parent.RemoveNode(this);
                if (p !== null && p.parent !== c)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$2(c, p).Add(content);
            }
            /*void */ ReplaceWith$1(/*params object?[]*/ content)
            {
                this.ReplaceWith($.$cast(content, $.$spc.System.Object));
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.GetXmlString(this.GetSaveOptionsFromAnnotations());
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XNode.ToString.apply(this, arguments); }
            /*string */ ToString$1(/*SaveOptions*/ options)
            {
                return this.GetXmlString(options);
            }
            static /*bool */ DeepEquals(/*XNode?*/ n1, /*XNode?*/ n2)
            {
                if (n1 === n2)
                {
                    return true;
                }
                if (n1 === null || n2 === null)
                {
                    return false;
                }
                return n1.DeepEquals$1(n2);
            }
            /*void */ AppendText(/*StringBuilder*/ sb)
            {
            }
            /*IEnumerable<XElement> */ GetAncestors(/*XName?*/ name, /*bool*/ self)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*XElement?*/ let e = $.$as((self ? this : this.parent), $.$spxl.System.Xml.Linq.XElement);
                    while(e !== null)
                    {
                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                        {
                            yield e;
                        }
                        e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ GetElementsAfterSelf(/*XName?*/ name)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*XNode*/ let n = this;
                    while(n.parent !== null && n !== n.parent.content)
                    {
                        n = n.next;
                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                        {
                            yield e;
                        }
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ GetElementsBeforeSelf(/*XName?*/ name)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    if (this.parent !== null)
                    {
                        /*XNode*/ let n = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                        do
                        {
                            n = n.next;
                            if (n === this)
                            {
                                break;
                            }
                            /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                            if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                            {
                                yield e;
                            }
                        }
                        while(this.parent !== null && this.parent === n.parent);
                    }
                }.bind(this));
            }
            static /*XmlReaderSettings */ GetXmlReaderSettings(/*LoadOptions*/ o)
            {
                /*XmlReaderSettings*/ let rs = new $.$spx.System.Xml.XmlReaderSettings().$ctor$1();
                if ((o & 1/*LoadOptions.PreserveWhitespace*/) === 0)
                {
                    rs.IgnoreWhitespace = true;
                }
                rs.DtdProcessing = $.$cast(2, $.$spx.System.Xml.DtdProcessing);
                rs.MaxCharactersFromEntities = $.$cast(10000000n, $.$spc.System.Int64);
                return rs;
            }
            static /*XmlWriterSettings */ GetXmlWriterSettings(/*SaveOptions*/ o)
            {
                /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                if ((o & 1/*SaveOptions.DisableFormatting*/) === 0)
                {
                    ws.Indent = true;
                }
                if ((o & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0)
                {
                    ws.NamespaceHandling |= 1/*NamespaceHandling.OmitDuplicates*/;
                }
                return ws;
            }
            /*string */ GetXmlString(/*SaveOptions*/ o)
            {
                let sw = null;
                try
                {
                    sw = new $.$spc.System.IO.StringWriter().$ctor$5($.$spc.System.Globalization.CultureInfo.InvariantCulture);
                    /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                    ws.OmitXmlDeclaration = true;
                    if ((o & 1/*SaveOptions.DisableFormatting*/) === 0)
                    {
                        ws.Indent = true;
                    }
                    if ((o & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0)
                    {
                        ws.NamespaceHandling |= 1/*NamespaceHandling.OmitDuplicates*/;
                    }
                    if ($.$is(this, $.$spxl.System.Xml.Linq.XText))
                    {
                        ws.ConformanceLevel = 1/*ConformanceLevel.Fragment*/;
                    }
                    let w = null;
                    try
                    {
                        w = $.$spx.System.Xml.XmlWriter.Create$5(sw, ws);
                        /*XDocument?*/ let n = $.$as(this, $.$spxl.System.Xml.Linq.XDocument);
                        if (n !== null)
                        {
                            n.WriteContentTo(w);
                        }
                        else 
                        {
                            this.WriteTo(w);
                        }
                    }
                    finally
                    {
                        w?.System$IDisposable$Dispose();
                    }
                    return $.$spc.System.IO.StringWriter.ToString.call(sw);
                }
                finally
                {
                    sw?.System$IDisposable$Dispose();
                }
            }
            static $h = 2264625;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2592305,"p":[{"p":2264625,"g":{"r":0,"d":0,"h":17182133809,"f":1},"n":"NextNode","d":2264625,"h":12887166513,"f":1},{"p":2264625,"g":{"r":0,"d":0,"h":25772068401,"f":1},"n":"PreviousNode","d":2264625,"h":21477101105,"f":1},{"p":2395697,"g":{"r":0,"d":0,"h":38656970289,"f":33},"n":"DocumentOrderComparer","d":2264625,"h":34362002993,"f":33},{"p":2461233,"g":{"r":0,"d":0,"h":51541872177,"f":33},"n":"EqualityComparer","d":2264625,"h":47246904881,"f":33}],"m":[{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddAfterSelf","d":2264625,"h":55836839473,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"AddAfterSelf","o":"@$1","d":2264625,"h":60131806769,"f":1},{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddBeforeSelf","d":2264625,"h":64426774065,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"AddBeforeSelf","o":"@$1","d":2264625,"h":68721741361,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"Ancestors","d":2264625,"h":73016708657,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2133553}],"n":"Ancestors","o":"@$1","d":2264625,"h":77311675953,"f":1},{"r":655361,"p":[{"n":"n1","p":2264625},{"n":"n2","p":2264625}],"n":"CompareDocumentOrder","d":2264625,"h":81606643249,"f":33},{"r":53398620,"n":"CreateReader","d":2264625,"h":85901610545,"f":1},{"r":53398620,"p":[{"n":"readerOptions","p":953905}],"n":"CreateReader","o":"@$1","d":2264625,"h":90196577841,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"NodesAfterSelf","d":2264625,"h":94491545137,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"NodesBeforeSelf","d":2264625,"h":98786512433,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"ElementsAfterSelf","d":2264625,"h":103081479729,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2133553}],"n":"ElementsAfterSelf","o":"@$1","d":2264625,"h":107376447025,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"ElementsBeforeSelf","d":2264625,"h":111671414321,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2133553}],"n":"ElementsBeforeSelf","o":"@$1","d":2264625,"h":115966381617,"f":1},{"r":262145,"p":[{"n":"node","p":2264625}],"n":"IsAfter","d":2264625,"h":120261348913,"f":1},{"r":262145,"p":[{"n":"node","p":2264625}],"n":"IsBefore","d":2264625,"h":124556316209,"f":1},{"r":2264625,"p":[{"n":"reader","p":53398620}],"n":"ReadFrom","d":2264625,"h":128851283505,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"reader","p":53398620},{"n":"cancellationToken","p":125960193}],"n":"ReadFromAsync","d":2264625,"h":133146250801,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"reader","p":53398620},{"n":"cancellationToken","p":125960193}],"n":"ReadFromAsyncInternal","d":2264625,"h":137441218097,"f":4130},{"r":65537,"n":"Remove","d":2264625,"h":141736185393,"f":1},{"r":65537,"p":[{"n":"content","p":131073}],"n":"ReplaceWith","d":2264625,"h":146031152689,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"ReplaceWith","o":"@$1","d":2264625,"h":150326119985,"f":1},{"r":1310721,"n":"ToString","d":2264625,"h":154621087281,"f":32769},{"r":1310721,"p":[{"n":"options","p":1019441}],"n":"ToString","o":"@$1","d":2264625,"h":158916054577,"f":1},{"r":262145,"p":[{"n":"n1","p":2264625},{"n":"n2","p":2264625}],"n":"DeepEquals","d":2264625,"h":163211021873,"f":33},{"r":65537,"p":[{"n":"writer","p":58444892}],"n":"WriteTo","d":2264625,"h":167505989169,"f":257},{"r":133300225,"p":[{"n":"writer","p":58444892},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":2264625,"h":171800956465,"f":257},{"r":65537,"p":[{"n":"sb","p":122945537}],"n":"AppendText","d":2264625,"h":176095923761,"f":136},{"r":2264625,"n":"CloneNode","d":2264625,"h":180390891057,"f":264},{"r":262145,"p":[{"n":"node","p":2264625}],"n":"DeepEquals","o":"@$1","d":2264625,"h":184685858353,"f":264},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2133553},{"n":"self","p":262145}],"n":"GetAncestors","d":2264625,"h":188980825649,"f":8},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2133553}],"n":"GetElementsAfterSelf","d":2264625,"h":193275792945,"f":2},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2133553}],"n":"GetElementsBeforeSelf","d":2264625,"h":197570760241,"f":2},{"r":655361,"n":"GetDeepHashCode","d":2264625,"h":201865727537,"f":264},{"r":53529692,"p":[{"n":"o","p":691761}],"n":"GetXmlReaderSettings","d":2264625,"h":206160694833,"f":40},{"r":58510428,"p":[{"n":"o","p":1019441}],"n":"GetXmlWriterSettings","d":2264625,"h":210455662129,"f":40},{"r":1310721,"p":[{"n":"o","p":1019441}],"n":"GetXmlString","d":2264625,"h":214750629425,"f":2}],"l":[{"t":2264625,"n":"next","d":2264625,"h":4297231921,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":2264625,"h":8592199217,"f":8}],"i":[13945948],"h":2264625}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XObject; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XNode`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XContainer", ($self) => class XContainer extends $.$spxl.System.Xml.Linq.XNode
        {
            /*object?*/ content = null;
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*XContainer*/ other)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    if ($.$is(other.content, $.$spc.System.String))
                    {
                        this.content = other.content;
                    }
                    else 
                    {
                        /*XNode?*/ let n = $.$cast(other.content, $.$spxl.System.Xml.Linq.XNode);
                        if (n !== null)
                        {
                            do
                            {
                                n = n.next;
                                this.AppendNodeSkipNotify(n.CloneNode());
                            }
                            while(n !== other.content);
                        }
                    }
                }
                return this;
            }
            /*XNode? */ get FirstNode()
            {
                return this.LastNode?.next;
            }
            /*XNode? */ get LastNode()
            {
                if (this.content === null)
                {
                    return null;
                }
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    return n;
                }
                /*string?*/ let s = $.$as(this.content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    if (s.length === 0)
                    {
                        return null;
                    }
                    /*XText*/ let t = new $.$spxl.System.Xml.Linq.XText().$ctor$3(s);
                    t.parent = this;
                    t.next = t;
                    $.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => this.content, ($v) => this.content = $v, $.$spc.System.Object), t, s);
                }
                return $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
            }
            /*void */ Add(/*object?*/ content)
            {
                if (this.SkipNotify())
                {
                    this.AddContentSkipNotify(content);
                    return;
                }
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.AddNode(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    this.AddString(s);
                    return;
                }
                /*XAttribute?*/ let a = $.$as(content, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    this.AddAttribute(a);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$9(x));
                    return;
                }
                /*object?[]?*/ let o = $.$as(content, $.$typeArray($.$spc.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.Add(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$spc.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.Add(obj);
                        }
                    }
                    return;
                }
                this.AddString($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            /*void */ Add$1(/*params object?[]*/ content)
            {
                this.Add($.$cast(content, $.$spc.System.Object));
            }
            /*void */ AddFirst(/*object?*/ content)
            {
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$2(this, null).Add(content);
            }
            /*void */ AddFirst$1(/*params object?[]*/ content)
            {
                this.AddFirst($.$cast(content, $.$spc.System.Object));
            }
            /*XmlWriter */ CreateWriter()
            {
                /*XmlWriterSettings*/ let settings = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                settings.ConformanceLevel = $.$is(this, $.$spxl.System.Xml.Linq.XDocument) ? 2/*ConformanceLevel.Document*/ : 1/*ConformanceLevel.Fragment*/;
                return $.$spx.System.Xml.XmlWriter.Create$9(new $.$spxl.System.Xml.Linq.XNodeBuilder().$ctor$2(this), settings);
            }
            /*IEnumerable<XNode> */ DescendantNodes()
            {
                return this.GetDescendantNodes(false);
            }
            /*IEnumerable<XElement> */ Descendants()
            {
                return this.GetDescendants(null, false);
            }
            /*IEnumerable<XElement> */ Descendants$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetDescendants(name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*XElement? */ Element(/*XName*/ name)
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (e !== null && $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                        {
                            return e;
                        }
                    }
                    while(n !== this.content);
                }
                return null;
            }
            /*IEnumerable<XElement> */ Elements()
            {
                return this.GetElements(null);
            }
            /*IEnumerable<XElement> */ Elements$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetElements(name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*IEnumerable<XNode> */ Nodes()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*XNode?*/ let n = this.LastNode;
                    if (n !== null)
                    {
                        do
                        {
                            n = n.next;
                            yield n;
                        }
                        while(n.parent === this && n !== this.content);
                    }
                }.bind(this));
            }
            /*void */ RemoveNodes()
            {
                if (this.SkipNotify())
                {
                    this.RemoveNodesSkipNotify();
                    return;
                }
                while(this.content !== null)
                {
                    /*string?*/ let s = $.$as(this.content, $.$spc.System.String);
                    if ($.$spc.System.String.op_Inequality(s, null))
                    {
                        if (s.length > 0)
                        {
                            this.ConvertTextToNode();
                        }
                        else 
                        {
                            if ($.$is(this, $.$spxl.System.Xml.Linq.XElement))
                            {
                                this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                                if (s !== this.content)
                                {
                                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                                }
                                this.content = null;
                                this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                            }
                            else 
                            {
                                this.content = null;
                            }
                        }
                    }
                    /*XNode?*/ let last = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                    if (last !== null)
                    {
                        /*XNode*/ let n = last.next;
                        this.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                        if (last !== this.content || n !== last.next)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                        }
                        if (n !== last)
                        {
                            last.next = n.next;
                        }
                        else 
                        {
                            this.content = null;
                        }
                        n.parent = null;
                        n.next = null;
                        this.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                    }
                }
            }
            /*void */ ReplaceNodes(/*object?*/ content)
            {
                content = $.$spxl.System.Xml.Linq.XContainer.GetContentSnapshot(content);
                this.RemoveNodes();
                this.Add(content);
            }
            /*void */ ReplaceNodes$1(/*params object?[]*/ content)
            {
                this.ReplaceNodes($.$cast(content, $.$spc.System.Object));
            }
            /*void */ AddAttribute(/*XAttribute*/ a)
            {
            }
            /*void */ AddAttributeSkipNotify(/*XAttribute*/ a)
            {
            }
            /*void */ AddContentSkipNotify(/*object?*/ content)
            {
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.AddNodeSkipNotify(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    this.AddStringSkipNotify(s);
                    return;
                }
                /*XAttribute?*/ let a = $.$as(content, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    this.AddAttributeSkipNotify(a);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XElement().$ctor$9(x));
                    return;
                }
                /*object?[]?*/ let o = $.$as(content, $.$typeArray($.$spc.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.AddContentSkipNotify(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$spc.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.AddContentSkipNotify(obj);
                        }
                    }
                    return;
                }
                this.AddStringSkipNotify($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            /*void */ AddNode(/*XNode*/ n)
            {
                this.ValidateNode(n, this);
                if (n.parent !== null)
                {
                    n = n.CloneNode();
                }
                else 
                {
                    /*XNode*/ let p = this;
                    while(p.parent !== null)
                    {
                        p = p.parent;
                    }
                    if (n === p)
                    {
                        n = n.CloneNode();
                    }
                }
                this.ConvertTextToNode();
                this.AppendNode(n);
            }
            /*void */ AddNodeSkipNotify(/*XNode*/ n)
            {
                this.ValidateNode(n, this);
                if (n.parent !== null)
                {
                    n = n.CloneNode();
                }
                else 
                {
                    /*XNode*/ let p = this;
                    while(p.parent !== null)
                    {
                        p = p.parent;
                    }
                    if (n === p)
                    {
                        n = n.CloneNode();
                    }
                }
                this.ConvertTextToNode();
                this.AppendNodeSkipNotify(n);
            }
            /*void */ AddString(/*string*/ s)
            {
                this.ValidateString(s);
                if (this.content === null)
                {
                    if (s.length > 0)
                    {
                        this.AppendNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(s));
                    }
                    else 
                    {
                        if ($.$is(this, $.$spxl.System.Xml.Linq.XElement))
                        {
                            this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                            if (this.content !== null)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                            }
                            this.content = s;
                            this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                        }
                        else 
                        {
                            this.content = s;
                        }
                    }
                }
                else if (s.length > 0)
                {
                    this.ConvertTextToNode();
                    /*XText?*/ let tn = $.$as(this.content, $.$spxl.System.Xml.Linq.XText);
                    if (tn !== null && !($.$is(tn, $.$spxl.System.Xml.Linq.XCData)))
                    {
                        tn.Value += s;
                    }
                    else 
                    {
                        this.AppendNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(s));
                    }
                }
            }
            /*void */ AddStringSkipNotify(/*string*/ s)
            {
                this.ValidateString(s);
                if (this.content === null)
                {
                    this.content = s;
                }
                else if (s.length > 0)
                {
                    /*string?*/ let stringContent = $.$as(this.content, $.$spc.System.String);
                    if ($.$spc.System.String.op_Inequality(stringContent, null))
                    {
                        this.content = stringContent + s;
                    }
                    else 
                    {
                        /*XText?*/ let tn = $.$as(this.content, $.$spxl.System.Xml.Linq.XText);
                        if (tn !== null && !($.$is(tn, $.$spxl.System.Xml.Linq.XCData)))
                        {
                            tn.text += s;
                        }
                        else 
                        {
                            this.AppendNodeSkipNotify(new $.$spxl.System.Xml.Linq.XText().$ctor$3(s));
                        }
                    }
                }
            }
            /*void */ AppendNode(/*XNode*/ n)
            {
                /*bool*/ let notify = this.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                if (n.parent !== null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                this.AppendNodeSkipNotify(n);
                if (notify)
                {
                    this.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                }
            }
            /*void */ AppendNodeSkipNotify(/*XNode*/ n)
            {
                n.parent = this;
                if (this.content === null || $.$is(this.content, $.$spc.System.String))
                {
                    n.next = n;
                }
                else 
                {
                    /*XNode*/ let x = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                    n.next = x.next;
                    x.next = n;
                }
                this.content = n;
            }
            /*void */ AppendText(/*StringBuilder*/ sb)
            {
                /*string?*/ let s = $.$as(this.content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    sb.Append$2(s);
                }
                else 
                {
                    /*XNode?*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                    if (n !== null)
                    {
                        do
                        {
                            n = n.next;
                            n.AppendText(sb);
                        }
                        while(n !== this.content);
                    }
                }
            }
            /*string? */ GetTextOnly()
            {
                if (this.content === null)
                {
                    return null;
                }
                /*string?*/ let s = $.$as(this.content, $.$spc.System.String);
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    /*XNode*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                    do
                    {
                        n = n.next;
                        if (n.NodeType !== 3/*XmlNodeType.Text*/)
                        {
                            return null;
                        }
                        s += ($.$cast(n, $.$spxl.System.Xml.Linq.XText)).Value;
                    }
                    while(n !== this.content);
                }
                return s;
            }
            /*string */ CollectText(/*ref XNode?*/ n)
            {
                /*string*/ let s = "";
                while(n.$v !== null && n.$v.NodeType === 3/*XmlNodeType.Text*/)
                {
                    s += ($.$cast(n.$v, $.$spxl.System.Xml.Linq.XText)).Value;
                    n.$v = n.$v !== this.content ? n.$v.next : null;
                }
                return s;
            }
            /*bool */ ContentsEqual(/*XContainer*/ e)
            {
                if (this.content === e.content)
                {
                    return true;
                }
                /*string?*/ let s = this.GetTextOnly();
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    return $.$spc.System.String.op_Equality(s, e.GetTextOnly());
                }
                /*XNode?*/ let n1 = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                /*XNode?*/ let n2 = $.$as(e.content, $.$spxl.System.Xml.Linq.XNode);
                if (n1 !== null && n2 !== null)
                {
                    n1 = n1.next;
                    n2 = n2.next;
                    while(true)
                    {
                        if ($.$spc.System.String.op_Inequality(this.CollectText($.$ref(() => n1, ($v) => n1 = $v, $.$spxl.System.Xml.Linq.XNode)), e.CollectText($.$ref(() => n2, ($v) => n2 = $v, $.$spxl.System.Xml.Linq.XNode))))
                        {
                            break;
                        }
                        if (n1 === null && n2 === null)
                        {
                            return true;
                        }
                        if (n1 === null || n2 === null || !n1.DeepEquals$1(n2))
                        {
                            break;
                        }
                        n1 = n1 !== this.content ? n1.next : null;
                        n2 = n2 !== e.content ? n2.next : null;
                    }
                }
                return false;
            }
            /*int */ ContentsHashCode()
            {
                /*string?*/ let s = this.GetTextOnly();
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    return $.$spc.System.String.GetHashCode.call(s);
                }
                /*int*/ let h = 0;
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*string*/ let text = this.CollectText($.$ref(() => n, ($v) => n = $v, $.$spxl.System.Xml.Linq.XNode));
                        if (text.length > 0)
                        {
                            h ^= $.$spc.System.String.GetHashCode.call(text);
                        }
                        if (n === null)
                        {
                            break;
                        }
                        h ^= n.GetDeepHashCode();
                    }
                    while(n !== this.content);
                }
                return h;
            }
            /*void */ ConvertTextToNode()
            {
                /*string?*/ let s = $.$as(this.content, $.$spc.System.String);
                if (!$.$spc.System.String.IsNullOrEmpty(s))
                {
                    /*XText*/ let t = new $.$spxl.System.Xml.Linq.XText().$ctor$3(s);
                    t.parent = this;
                    t.next = t;
                    this.content = t;
                }
            }
            /*IEnumerable<XNode> */ GetDescendantNodes(/*bool*/ self)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    if (self)
                    {
                        yield this;
                    }
                    /*XNode*/ let n = this;
                    while(true)
                    {
                        /*XContainer?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XContainer);
                        /*XNode?*/ let first;
                        if (c !== null && (first = c.FirstNode) !== null)
                        {
                            n = first;
                        }
                        else 
                        {
                            while(n !== null && n !== this && n === n.parent.content)
                            {
                                n = n.parent;
                            }
                            if (n === null || n === this)
                            {
                                break;
                            }
                            n = n.next;
                        }
                        yield n;
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ GetDescendants(/*XName?*/ name, /*bool*/ self)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    if (self)
                    {
                        /*XElement*/ let e = $.$cast(this, $.$spxl.System.Xml.Linq.XElement);
                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                        {
                            yield e;
                        }
                    }
                    /*XNode*/ let n = this;
                    /*XContainer?*/ let c = this;
                    while(true)
                    {
                        if (c !== null && $.$is(c.content, $.$spxl.System.Xml.Linq.XNode))
                        {
                            n = ($.$cast(c.content, $.$spxl.System.Xml.Linq.XNode)).next;
                        }
                        else 
                        {
                            while(n !== this && n === n.parent.content)
                            {
                                n = n.parent;
                            }
                            if (n === this)
                            {
                                break;
                            }
                            n = n.next;
                        }
                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                        {
                            yield e;
                        }
                        c = e;
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ GetElements(/*XName?*/ name)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                    if (n !== null)
                    {
                        do
                        {
                            n = n.next;
                            /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                            if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                            {
                                yield e;
                            }
                        }
                        while(n.parent === this && n !== this.content);
                    }
                }.bind(this));
            }
            static /*string */ GetStringValue(/*object*/ value)
            {
                /*string?*/ let s = (() =>
                {
                    {
                        let stringValue;
                        if ((stringValue = value, $.$is(stringValue, $.$spc.System.String)))
                        {
                            return stringValue;
                        }
                    }
                    {
                        let intValue;
                        if ((intValue = value, $.$is(intValue, $.$spc.System.Int32)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$6(intValue);
                        }
                    }
                    {
                        let doubleValue;
                        if ((doubleValue = value, $.$is(doubleValue, $.$spc.System.Double)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$13(doubleValue);
                        }
                    }
                    {
                        let longValue;
                        if ((longValue = value, $.$is(longValue, $.$spc.System.Int64)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$7(longValue);
                        }
                    }
                    {
                        let floatValue;
                        if ((floatValue = value, $.$is(floatValue, $.$spc.System.Single)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$12(floatValue);
                        }
                    }
                    {
                        let decimalValue;
                        if ((decimalValue = value, $.$is(decimalValue, $.$spc.System.Decimal)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$3(decimalValue);
                        }
                    }
                    {
                        let shortValue;
                        if ((shortValue = value, $.$is(shortValue, $.$spc.System.Int16)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$5(shortValue);
                        }
                    }
                    {
                        let sbyteValue;
                        if ((sbyteValue = value, $.$is(sbyteValue, $.$spc.System.SByte)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$4(sbyteValue);
                        }
                    }
                    {
                        let boolValue;
                        if ((boolValue = value, $.$is(boolValue, $.$spc.System.Boolean)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$1(boolValue);
                        }
                    }
                    {
                        let dtValue;
                        if ((dtValue = value, $.$is(dtValue, $.$spc.System.DateTime)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$17(dtValue, 3/*XmlDateTimeSerializationMode.RoundtripKind*/);
                        }
                    }
                    {
                        let dtoValue;
                        if ((dtoValue = value, $.$is(dtoValue, $.$spc.System.DateTimeOffset)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$18(dtoValue);
                        }
                    }
                    {
                        let tsValue;
                        if ((tsValue = value, $.$is(tsValue, $.$spc.System.TimeSpan)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$14(tsValue);
                        }
                    }
                    if (value === $.$spxl.System.Xml.Linq.XObject)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_XObjectValue);
                    }
                    return $.$spc.System.Object.ToString.call(value);
                })();
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_ConvertToString);
                }
                return s;
            }
            /*void */ ReadContentFrom(/*XmlReader*/ r)
            {
                if (r.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$1(this);
                while(cr.ReadContentFrom(this, r) && r.Read())
                {
                }
            }
            /*void */ ReadContentFrom$1(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                if ((o & (2/*LoadOptions.SetBaseUri*/ | 4/*LoadOptions.SetLineInfo*/)) === 0)
                {
                    this.ReadContentFrom(r);
                    return;
                }
                if (r.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$2(this, r, o);
                while(cr.ReadContentFromContainer(this, r) && r.Read())
                {
                }
            }
            /*Task *//*async*/  ReadContentFromAsync(/*XmlReader*/ r, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (r.ReadState !== 1/*ReadState.Interactive*/)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                    }
                    /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$1(this);
                    do
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                    while(await cr.ReadContentFromAsync(this, r).ConfigureAwait(false) && await r.ReadAsync().ConfigureAwait$2(false));
                });
            }
            /*Task *//*async*/  ReadContentFromAsync$1(/*XmlReader*/ r, /*LoadOptions*/ o, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if ((o & (2/*LoadOptions.SetBaseUri*/ | 4/*LoadOptions.SetLineInfo*/)) === 0)
                    {
                        await this.ReadContentFromAsync(r, cancellationToken).ConfigureAwait(false);
                        return;
                    }
                    if (r.ReadState !== 1/*ReadState.Interactive*/)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                    }
                    /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$2(this, r, o);
                    do
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                    while(await cr.ReadContentFromContainerAsync(this, r).ConfigureAwait(false) && await r.ReadAsync().ConfigureAwait$2(false));
                });
            }
            static $_ContentReader;
            static get ContentReader()
            {
                let $cls = $.$spxl.System.Xml.Linq.XContainer;
                return $cls.$_ContentReader ??= $asm.$ncls("$spxl.System.Xml.Linq.XContainer.ContentReader", ($self) => class ContentReader extends $.$spc.System.Object
                {
                    /*NamespaceCache*/ _eCache;
                    /*NamespaceCache*/ _aCache;
                    /*IXmlLineInfo?*/ _lineInfo = null;
                    /*XContainer*/ _currentContainer = null;
                    /*string?*/ _baseUri = null;
                    $ctor$1(/*XContainer*/ rootContainer)
                    {
                        super.$ctor();
                        {
                            this._currentContainer = rootContainer;
                        }
                        return this;
                    }
                    $ctor$2(/*XContainer*/ rootContainer, /*XmlReader*/ r, /*LoadOptions*/ o)
                    {
                        super.$ctor();
                        {
                            this._currentContainer = rootContainer;
                            this._baseUri = (o & 2/*LoadOptions.SetBaseUri*/) !== 0 ? r.BaseURI : null;
                            this._lineInfo = (o & 4/*LoadOptions.SetLineInfo*/) !== 0 ? $.$as(r, $.$spx.System.Xml.IXmlLineInfo) : null;
                        }
                        return this;
                    }
                    /*bool */ ReadContentFrom(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        let $switch1 = r.NodeType;
                        switch($switch1)
                        {
                            case 1/*XmlNodeType.Element*/:
                            /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$5(this._eCache.Get(r.NamespaceURI).GetName(r.LocalName));
                            if (r.MoveToFirstAttribute())
                            {
                                do
                                {
                                    e.AppendAttributeSkipNotify(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(this._aCache.Get(r.Prefix.length === 0 ? $.$spc.System.String.Empty : r.NamespaceURI).GetName(r.LocalName), r.Value));
                                }
                                while(r.MoveToNextAttribute());
                                r.MoveToElement();
                            }
                            this._currentContainer.AddNodeSkipNotify(e);
                            if (!r.IsEmptyElement)
                            {
                                this._currentContainer = e;
                            }
                            break;
                            case 15/*XmlNodeType.EndElement*/:
                            this._currentContainer.content ??= $.$spc.System.String.Empty;
                            if (this._currentContainer === rootContainer)
                            {
                                return false;
                            }
                            this._currentContainer = this._currentContainer.parent;
                            break;
                            case 3/*XmlNodeType.Text*/:
                            case 14/*XmlNodeType.SignificantWhitespace*/:
                            case 13/*XmlNodeType.Whitespace*/:
                            this._currentContainer.AddStringSkipNotify(r.Value);
                            break;
                            case 4/*XmlNodeType.CDATA*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XCData().$ctor$6(r.Value));
                            break;
                            case 8/*XmlNodeType.Comment*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XComment().$ctor$3(r.Value));
                            break;
                            case 7/*XmlNodeType.ProcessingInstruction*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, r.Value));
                            break;
                            case 10/*XmlNodeType.DocumentType*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute("PUBLIC"), r.GetAttribute("SYSTEM"), r.Value));
                            break;
                            case 5/*XmlNodeType.EntityReference*/:
                            if (!r.CanResolveEntity)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                            }
                            r.ResolveEntity();
                            break;
                            case 16/*XmlNodeType.EndEntity*/:
                            break;
                            default:
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                        }
                        return true;
                    }
                    /*ValueTask<bool> *//*async*/  ReadContentFromAsync(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                        {
                            let $switch1 = r.NodeType;
                            switch($switch1)
                            {
                                case 1/*XmlNodeType.Element*/:
                                /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$5(this._eCache.Get(r.NamespaceURI).GetName(r.LocalName));
                                if (r.MoveToFirstAttribute())
                                {
                                    do
                                    {
                                        e.AppendAttributeSkipNotify(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(this._aCache.Get(r.Prefix.length === 0 ? $.$spc.System.String.Empty : r.NamespaceURI).GetName(r.LocalName), await r.GetValueAsync().ConfigureAwait$2(false)));
                                    }
                                    while(r.MoveToNextAttribute());
                                    r.MoveToElement();
                                }
                                this._currentContainer.AddNodeSkipNotify(e);
                                if (!r.IsEmptyElement)
                                {
                                    this._currentContainer = e;
                                }
                                break;
                                case 15/*XmlNodeType.EndElement*/:
                                this._currentContainer.content ??= $.$spc.System.String.Empty;
                                if (this._currentContainer === rootContainer)
                                {
                                    return false;
                                }
                                this._currentContainer = this._currentContainer.parent;
                                break;
                                case 3/*XmlNodeType.Text*/:
                                case 14/*XmlNodeType.SignificantWhitespace*/:
                                case 13/*XmlNodeType.Whitespace*/:
                                this._currentContainer.AddStringSkipNotify(await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 4/*XmlNodeType.CDATA*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XCData().$ctor$6(await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 8/*XmlNodeType.Comment*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XComment().$ctor$3(await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 7/*XmlNodeType.ProcessingInstruction*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 10/*XmlNodeType.DocumentType*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute("PUBLIC"), r.GetAttribute("SYSTEM"), await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 5/*XmlNodeType.EntityReference*/:
                                if (!r.CanResolveEntity)
                                {
                                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                                }
                                r.ResolveEntity();
                                break;
                                case 16/*XmlNodeType.EndEntity*/:
                                break;
                                default:
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                            }
                            return true;
                        });
                    }
                    /*bool */ ReadContentFromContainer(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        /*XNode?*/ let newNode = null;
                        /*string*/ let baseUri = r.BaseURI;
                        let $switch1 = r.NodeType;
                        switch($switch1)
                        {
                            case 1/*XmlNodeType.Element*/:
                            {
                                /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$5(this._eCache.Get(r.NamespaceURI).GetName(r.LocalName));
                                if ($.$spc.System.String.op_Inequality(this._baseUri, null) && $.$spc.System.String.op_Inequality(this._baseUri, baseUri))
                                {
                                    e.SetBaseUri(baseUri);
                                }
                                if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                {
                                    e.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                }
                                if (r.MoveToFirstAttribute())
                                {
                                    do
                                    {
                                        /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(this._aCache.Get(r.Prefix.length === 0 ? $.$spc.System.String.Empty : r.NamespaceURI).GetName(r.LocalName), r.Value);
                                        if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                        {
                                            a.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                        }
                                        e.AppendAttributeSkipNotify(a);
                                    }
                                    while(r.MoveToNextAttribute());
                                    r.MoveToElement();
                                }
                                this._currentContainer.AddNodeSkipNotify(e);
                                if (!r.IsEmptyElement)
                                {
                                    this._currentContainer = e;
                                    if ($.$spc.System.String.op_Inequality(this._baseUri, null))
                                    {
                                        this._baseUri = baseUri;
                                    }
                                }
                                break;
                            }
                            case 15/*XmlNodeType.EndElement*/:
                            {
                                this._currentContainer.content ??= $.$spc.System.String.Empty;
                                /*XElement?*/ let e = $.$as(this._currentContainer, $.$spxl.System.Xml.Linq.XElement);
                                $.$spc.System.Diagnostics.Debug.Assert$1(e !== null, "EndElement received but the current container is not an element.");
                                if (e !== null && this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                {
                                    e.SetEndElementLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                }
                                if (this._currentContainer === rootContainer)
                                {
                                    return false;
                                }
                                if ($.$spc.System.String.op_Inequality(this._baseUri, null) && this._currentContainer.HasBaseUri)
                                {
                                    this._baseUri = this._currentContainer.parent.BaseUri;
                                }
                                this._currentContainer = this._currentContainer.parent;
                                break;
                            }
                            case 3/*XmlNodeType.Text*/:
                            case 14/*XmlNodeType.SignificantWhitespace*/:
                            case 13/*XmlNodeType.Whitespace*/:
                            if (($.$spc.System.String.op_Inequality(this._baseUri, null) && $.$spc.System.String.op_Inequality(this._baseUri, baseUri)) || (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo()))
                            {
                                newNode = new $.$spxl.System.Xml.Linq.XText().$ctor$3(r.Value);
                            }
                            else 
                            {
                                this._currentContainer.AddStringSkipNotify(r.Value);
                            }
                            break;
                            case 4/*XmlNodeType.CDATA*/:
                            newNode = new $.$spxl.System.Xml.Linq.XCData().$ctor$6(r.Value);
                            break;
                            case 8/*XmlNodeType.Comment*/:
                            newNode = new $.$spxl.System.Xml.Linq.XComment().$ctor$3(r.Value);
                            break;
                            case 7/*XmlNodeType.ProcessingInstruction*/:
                            newNode = new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, r.Value);
                            break;
                            case 10/*XmlNodeType.DocumentType*/:
                            newNode = new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute("PUBLIC"), r.GetAttribute("SYSTEM"), r.Value);
                            break;
                            case 5/*XmlNodeType.EntityReference*/:
                            if (!r.CanResolveEntity)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                            }
                            r.ResolveEntity();
                            break;
                            case 16/*XmlNodeType.EndEntity*/:
                            break;
                            default:
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                        }
                        if (newNode !== null)
                        {
                            if ($.$spc.System.String.op_Inequality(this._baseUri, null) && $.$spc.System.String.op_Inequality(this._baseUri, baseUri))
                            {
                                newNode.SetBaseUri(baseUri);
                            }
                            if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                            {
                                newNode.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                            }
                            this._currentContainer.AddNodeSkipNotify(newNode);
                        }
                        return true;
                    }
                    /*ValueTask<bool> *//*async*/  ReadContentFromContainerAsync(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                        {
                            /*XNode?*/ let newNode = null;
                            /*string*/ let baseUri = r.BaseURI;
                            let $switch1 = r.NodeType;
                            switch($switch1)
                            {
                                case 1/*XmlNodeType.Element*/:
                                {
                                    /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$5(this._eCache.Get(r.NamespaceURI).GetName(r.LocalName));
                                    if ($.$spc.System.String.op_Inequality(this._baseUri, null) && $.$spc.System.String.op_Inequality(this._baseUri, baseUri))
                                    {
                                        e.SetBaseUri(baseUri);
                                    }
                                    if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                    {
                                        e.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                    }
                                    if (r.MoveToFirstAttribute())
                                    {
                                        do
                                        {
                                            /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(this._aCache.Get(r.Prefix.length === 0 ? $.$spc.System.String.Empty : r.NamespaceURI).GetName(r.LocalName), await r.GetValueAsync().ConfigureAwait$2(false));
                                            if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                            {
                                                a.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                            }
                                            e.AppendAttributeSkipNotify(a);
                                        }
                                        while(r.MoveToNextAttribute());
                                        r.MoveToElement();
                                    }
                                    this._currentContainer.AddNodeSkipNotify(e);
                                    if (!r.IsEmptyElement)
                                    {
                                        this._currentContainer = e;
                                        if ($.$spc.System.String.op_Inequality(this._baseUri, null))
                                        {
                                            this._baseUri = baseUri;
                                        }
                                    }
                                    break;
                                }
                                case 15/*XmlNodeType.EndElement*/:
                                {
                                    this._currentContainer.content ??= $.$spc.System.String.Empty;
                                    /*XElement?*/ let e = $.$as(this._currentContainer, $.$spxl.System.Xml.Linq.XElement);
                                    $.$spc.System.Diagnostics.Debug.Assert$1(e !== null, "EndElement received but the current container is not an element.");
                                    if (e !== null && this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                    {
                                        e.SetEndElementLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                    }
                                    if (this._currentContainer === rootContainer)
                                    {
                                        return false;
                                    }
                                    if ($.$spc.System.String.op_Inequality(this._baseUri, null) && this._currentContainer.HasBaseUri)
                                    {
                                        this._baseUri = this._currentContainer.parent.BaseUri;
                                    }
                                    this._currentContainer = this._currentContainer.parent;
                                    break;
                                }
                                case 3/*XmlNodeType.Text*/:
                                case 14/*XmlNodeType.SignificantWhitespace*/:
                                case 13/*XmlNodeType.Whitespace*/:
                                if (($.$spc.System.String.op_Inequality(this._baseUri, null) && $.$spc.System.String.op_Inequality(this._baseUri, baseUri)) || (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo()))
                                {
                                    newNode = new $.$spxl.System.Xml.Linq.XText().$ctor$3(await r.GetValueAsync().ConfigureAwait$2(false));
                                }
                                else 
                                {
                                    this._currentContainer.AddStringSkipNotify(await r.GetValueAsync().ConfigureAwait$2(false));
                                }
                                break;
                                case 4/*XmlNodeType.CDATA*/:
                                newNode = new $.$spxl.System.Xml.Linq.XCData().$ctor$6(await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 8/*XmlNodeType.Comment*/:
                                newNode = new $.$spxl.System.Xml.Linq.XComment().$ctor$3(await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 7/*XmlNodeType.ProcessingInstruction*/:
                                newNode = new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 10/*XmlNodeType.DocumentType*/:
                                newNode = new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute("PUBLIC"), r.GetAttribute("SYSTEM"), await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 5/*XmlNodeType.EntityReference*/:
                                if (!r.CanResolveEntity)
                                {
                                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                                }
                                r.ResolveEntity();
                                break;
                                case 16/*XmlNodeType.EndEntity*/:
                                break;
                                default:
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                            }
                            if (newNode !== null)
                            {
                                if ($.$spc.System.String.op_Inequality(this._baseUri, null) && $.$spc.System.String.op_Inequality(this._baseUri, baseUri))
                                {
                                    newNode.SetBaseUri(baseUri);
                                }
                                if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                {
                                    newNode.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                }
                                this._currentContainer.AddNodeSkipNotify(newNode);
                            }
                            return true;
                        });
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._eCache = $.$default($.$spxl.System.Xml.Linq.NamespaceCache);
                        this._aCache = $.$default($.$spxl.System.Xml.Linq.NamespaceCache);
                    }
                    static $h = 1412657;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"rootContainer","p":1347121},{"n":"r","p":53398620}],"n":"ReadContentFrom","d":1412657,"h":34361151025,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"rootContainer","p":1347121},{"n":"r","p":53398620}],"n":"ReadContentFromAsync","d":1412657,"h":38656118321,"f":4097},{"r":262145,"p":[{"n":"rootContainer","p":1347121},{"n":"r","p":53398620}],"n":"ReadContentFromContainer","d":1412657,"h":42951085617,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"rootContainer","p":1347121},{"n":"r","p":53398620}],"n":"ReadContentFromContainerAsync","d":1412657,"h":47246052913,"f":4097}],"l":[{"t":757297,"n":"_eCache","d":1412657,"h":4296379953,"f":2},{"t":757297,"n":"_aCache","d":1412657,"h":8591347249,"f":2},{"t":13945948,"n":"_lineInfo","d":1412657,"h":12886314545,"f":2},{"t":1347121,"n":"_currentContainer","d":1412657,"h":17181281841,"f":2},{"t":1310721,"n":"_baseUri","d":1412657,"h":21476249137,"f":2}],"c":[{"p":[{"n":"rootContainer","p":1347121}],"n":".ctor","o":"$ctor$1","d":1412657,"h":25771216433,"f":1},{"p":[{"n":"rootContainer","p":1347121},{"n":"r","p":53398620},{"n":"o","p":691761}],"n":".ctor","o":"$ctor$2","d":1412657,"h":30066183729,"f":1}],"d":1347121,"h":1412657}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Xml.Linq.XContainer.ContentReader`; }
                }, $cls, ($v) => $cls.$_ContentReader = $v);
            }
            /*void */ RemoveNode(/*XNode*/ n)
            {
                /*bool*/ let notify = this.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                if (n.parent !== this)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this.content !== null, "content != null");
                /*XNode*/ let p = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                while(p.next !== n)
                {
                    p = p.next;
                }
                if (p === n)
                {
                    this.content = null;
                }
                else 
                {
                    if (this.content === n)
                    {
                        this.content = p;
                    }
                    p.next = n.next;
                }
                n.parent = null;
                n.next = null;
                if (notify)
                {
                    this.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                }
            }
            /*void */ RemoveNodesSkipNotify()
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        /*XNode*/ let next = n.next;
                        n.parent = null;
                        n.next = null;
                        n = next;
                    }
                    while(n !== this.content);
                }
                this.content = null;
            }
            /*void */ ValidateNode(/*XNode*/ node, /*XNode?*/ previous)
            {
            }
            /*void */ ValidateString(/*string*/ s)
            {
            }
            /*void */ WriteContentTo(/*XmlWriter*/ writer)
            {
                if (this.content !== null)
                {
                    /*string?*/ let stringContent = $.$as(this.content, $.$spc.System.String);
                    if ($.$spc.System.String.op_Inequality(stringContent, null))
                    {
                        if ($.$is(this, $.$spxl.System.Xml.Linq.XDocument))
                        {
                            writer.WriteWhitespace(stringContent);
                        }
                        else 
                        {
                            writer.WriteString(stringContent);
                        }
                    }
                    else 
                    {
                        /*XNode*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                        do
                        {
                            n = n.next;
                            n.WriteTo(writer);
                        }
                        while(n !== this.content);
                    }
                }
            }
            /*Task *//*async*/  WriteContentToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (this.content !== null)
                    {
                        /*string?*/ let stringContent = $.$as(this.content, $.$spc.System.String);
                        if ($.$spc.System.String.op_Inequality(stringContent, null))
                        {
                            cancellationToken.ThrowIfCancellationRequested();
                            /*Task*/ let tWrite;
                            if ($.$is(this, $.$spxl.System.Xml.Linq.XDocument))
                            {
                                tWrite = writer.WriteWhitespaceAsync(stringContent);
                            }
                            else 
                            {
                                tWrite = writer.WriteStringAsync(stringContent);
                            }
                            await tWrite.ConfigureAwait(false);
                        }
                        else 
                        {
                            /*XNode*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                            do
                            {
                                n = n.next;
                                await n.WriteToAsync(writer, cancellationToken).ConfigureAwait(false);
                            }
                            while(n !== this.content);
                        }
                    }
                });
            }
            static /*void */ AddContentToList(/*List<object?>*/ list, /*object?*/ content)
            {
                /*IEnumerable?*/ let e = $.$is(content, $.$spc.System.String) ? null : $.$as(content, $.$spc.System.Collections.IEnumerable);
                if (e === null)
                {
                    list.Add(content);
                }
                else 
                {
                    var $en3 = e.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (obj !== null)
                            {
                                $.$spxl.System.Xml.Linq.XContainer.AddContentToList(list, obj);
                            }
                        }
                    }
                }
            }
            static /*object? */ GetContentSnapshot(/*object?*/ content)
            {
                if ($.$is(content, $.$spc.System.String) || !($.$is(content, $.$spc.System.Collections.IEnumerable)))
                {
                    return content;
                }
                /*List<object?>*/ let list = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Object))().$ctor$1();
                $.$spxl.System.Xml.Linq.XContainer.AddContentToList(list, content);
                return list;
            }
            static $h = 1347121;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2264625,"p":[{"p":2264625,"g":{"r":0,"d":0,"h":21476183601,"f":1},"n":"FirstNode","d":1347121,"h":17181216305,"f":1},{"p":2264625,"g":{"r":0,"d":0,"h":30066118193,"f":1},"n":"LastNode","d":1347121,"h":25771150897,"f":1}],"m":[{"r":65537,"p":[{"n":"content","p":131073}],"n":"Add","d":1347121,"h":34361085489,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"Add","o":"@$1","d":1347121,"h":38656052785,"f":1},{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddFirst","d":1347121,"h":42951020081,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"AddFirst","o":"@$1","d":1347121,"h":47245987377,"f":1},{"r":58444892,"n":"CreateWriter","d":1347121,"h":51540954673,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"DescendantNodes","d":1347121,"h":55835921969,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"Descendants","d":1347121,"h":60130889265,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2133553}],"n":"Descendants","o":"@$1","d":1347121,"h":64425856561,"f":1},{"r":1674801,"p":[{"n":"name","p":2133553}],"n":"Element","d":1347121,"h":68720823857,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"Elements","d":1347121,"h":73015791153,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2133553}],"n":"Elements","o":"@$1","d":1347121,"h":77310758449,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"Nodes","d":1347121,"h":81605725745,"f":1},{"r":65537,"n":"RemoveNodes","d":1347121,"h":85900693041,"f":1},{"r":65537,"p":[{"n":"content","p":131073}],"n":"ReplaceNodes","d":1347121,"h":90195660337,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"ReplaceNodes","o":"@$1","d":1347121,"h":94490627633,"f":1},{"r":65537,"p":[{"n":"a","p":1150513}],"n":"AddAttribute","d":1347121,"h":98785594929,"f":136},{"r":65537,"p":[{"n":"a","p":1150513}],"n":"AddAttributeSkipNotify","d":1347121,"h":103080562225,"f":136},{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddContentSkipNotify","d":1347121,"h":107375529521,"f":8},{"r":65537,"p":[{"n":"n","p":2264625}],"n":"AddNode","d":1347121,"h":111670496817,"f":8},{"r":65537,"p":[{"n":"n","p":2264625}],"n":"AddNodeSkipNotify","d":1347121,"h":115965464113,"f":8},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AddString","d":1347121,"h":120260431409,"f":8},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AddStringSkipNotify","d":1347121,"h":124555398705,"f":8},{"r":65537,"p":[{"n":"n","p":2264625}],"n":"AppendNode","d":1347121,"h":128850366001,"f":8},{"r":65537,"p":[{"n":"n","p":2264625}],"n":"AppendNodeSkipNotify","d":1347121,"h":133145333297,"f":8},{"r":65537,"p":[{"n":"sb","p":122945537}],"n":"AppendText","d":1347121,"h":137440300593,"f":32776},{"r":1310721,"n":"GetTextOnly","d":1347121,"h":141735267889,"f":2},{"r":1310721,"p":[{"n":"n","p":2264625,"f":4}],"n":"CollectText","d":1347121,"h":146030235185,"f":2},{"r":262145,"p":[{"n":"e","p":1347121}],"n":"ContentsEqual","d":1347121,"h":150325202481,"f":8},{"r":655361,"n":"ContentsHashCode","d":1347121,"h":154620169777,"f":8},{"r":65537,"n":"ConvertTextToNode","d":1347121,"h":158915137073,"f":8},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"self","p":262145}],"n":"GetDescendantNodes","d":1347121,"h":163210104369,"f":8},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2133553},{"n":"self","p":262145}],"n":"GetDescendants","d":1347121,"h":167505071665,"f":8},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2133553}],"n":"GetElements","d":1347121,"h":171800038961,"f":2},{"r":1310721,"p":[{"n":"value","p":131073}],"n":"GetStringValue","d":1347121,"h":176095006257,"f":40},{"r":65537,"p":[{"n":"r","p":53398620}],"n":"ReadContentFrom","d":1347121,"h":180389973553,"f":8},{"r":65537,"p":[{"n":"r","p":53398620},{"n":"o","p":691761}],"n":"ReadContentFrom","o":"@$1","d":1347121,"h":184684940849,"f":8},{"r":133300225,"p":[{"n":"r","p":53398620},{"n":"cancellationToken","p":125960193}],"n":"ReadContentFromAsync","d":1347121,"h":188979908145,"f":4104},{"r":133300225,"p":[{"n":"r","p":53398620},{"n":"o","p":691761},{"n":"cancellationToken","p":125960193}],"n":"ReadContentFromAsync","o":"@$1","d":1347121,"h":193274875441,"f":4104},{"r":65537,"p":[{"n":"n","p":2264625}],"n":"RemoveNode","d":1347121,"h":201864810033,"f":8},{"r":65537,"n":"RemoveNodesSkipNotify","d":1347121,"h":206159777329,"f":2},{"r":65537,"p":[{"n":"node","p":2264625},{"n":"previous","p":2264625}],"n":"ValidateNode","d":1347121,"h":210454744625,"f":136},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"ValidateString","d":1347121,"h":214749711921,"f":136},{"r":65537,"p":[{"n":"writer","p":58444892}],"n":"WriteContentTo","d":1347121,"h":219044679217,"f":8},{"r":133300225,"p":[{"n":"writer","p":58444892},{"n":"cancellationToken","p":125960193}],"n":"WriteContentToAsync","d":1347121,"h":223339646513,"f":4104},{"r":65537,"p":[{"n":"list","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Object).$h},{"n":"content","p":131073}],"n":"AddContentToList","d":1347121,"h":227634613809,"f":34},{"r":131073,"p":[{"n":"content","p":131073}],"n":"GetContentSnapshot","d":1347121,"h":231929581105,"f":40}],"l":[{"t":131073,"n":"content","d":1347121,"h":4296314417,"f":8}],"c":[{"n":".ctor","o":"$ctor$3","d":1347121,"h":8591281713,"f":8},{"p":[{"n":"other","p":1347121}],"n":".ctor","o":"$ctor$4","d":1347121,"h":12886249009,"f":8}],"i":[13945948],"j":[1412657],"h":1347121}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XContainer`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.BaseUriAnnotation", ($self) => class BaseUriAnnotation extends $.$spc.System.Object
        {
            /*string*/ baseUri = null;
            $ctor$1(/*string*/ baseUri)
            {
                super.$ctor();
                {
                    this.baseUri = baseUri;
                }
                return this;
            }
            static $h = 298545;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"baseUri","d":298545,"h":4295265841,"f":8}],"c":[{"p":[{"n":"baseUri","p":1310721}],"n":".ctor","o":"$ctor$1","d":298545,"h":8590233137,"f":1}],"h":298545}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.BaseUriAnnotation`; }
        });
        
        $asm.$cls("$spxl.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$spxl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Private.Xml.Linq", $.$spxl.System.SR.$type.Assembly);
                    $.$spxl.System.SR.s_resourceManager = temp;
                }
                return $.$spxl.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$spxl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$spxl.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_AddAttribute()
            {
                return "An attribute cannot be added to content.";
            }
            static /*string */ get Argument_AddNode()
            {
                return "A node of type {0} cannot be added to content.";
            }
            static /*string */ FormatArgument_AddNode(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("A node of type {0} cannot be added to content.", arg1);
            }
            static /*string */ get Argument_AddNonWhitespace()
            {
                return "Non-whitespace characters cannot be added to content.";
            }
            static /*string */ get Argument_ConvertToString()
            {
                return "The argument cannot be converted to a string.";
            }
            static /*string */ get Argument_InvalidExpandedName()
            {
                return "'{0}' is an invalid expanded name.";
            }
            static /*string */ FormatArgument_InvalidExpandedName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("'{0}' is an invalid expanded name.", arg1);
            }
            static /*string */ get Argument_InvalidPIName()
            {
                return "'{0}' is an invalid name for a processing instruction.";
            }
            static /*string */ FormatArgument_InvalidPIName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("'{0}' is an invalid name for a processing instruction.", arg1);
            }
            static /*string */ get Argument_MustBeDerivedFrom()
            {
                return "The argument must be derived from {0}.";
            }
            static /*string */ FormatArgument_MustBeDerivedFrom(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The argument must be derived from {0}.", arg1);
            }
            static /*string */ get Argument_NamespaceDeclarationPrefixed()
            {
                return "The prefix '{0}' cannot be bound to the empty namespace name.";
            }
            static /*string */ FormatArgument_NamespaceDeclarationPrefixed(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The prefix '{0}' cannot be bound to the empty namespace name.", arg1);
            }
            static /*string */ get Argument_NamespaceDeclarationXml()
            {
                return "The prefix 'xml' is bound to the namespace name 'http://www.w3.org/XML/1998/namespace'. Other prefixes must not be bound to this namespace name, and it must not be declared as the default namespace.";
            }
            static /*string */ get Argument_NamespaceDeclarationXmlns()
            {
                return "The prefix 'xmlns' is bound to the namespace name 'http://www.w3.org/2000/xmlns/'. It must not be declared. Other prefixes must not be bound to this namespace name, and it must not be declared as the default namespace.";
            }
            static /*string */ get Argument_XObjectValue()
            {
                return "An XObject cannot be used as a value.";
            }
            static /*string */ get InvalidOperation_DeserializeInstance()
            {
                return "This instance cannot be deserialized.";
            }
            static /*string */ get InvalidOperation_DocumentStructure()
            {
                return "This operation would create an incorrectly structured document.";
            }
            static /*string */ get InvalidOperation_DuplicateAttribute()
            {
                return "Duplicate attribute.";
            }
            static /*string */ get InvalidOperation_ExpectedEndOfFile()
            {
                return "The XmlReader state should be EndOfFile after this operation.";
            }
            static /*string */ get InvalidOperation_ExpectedInteractive()
            {
                return "The XmlReader state should be Interactive.";
            }
            static /*string */ get InvalidOperation_ExpectedNodeType()
            {
                return "The XmlReader must be on a node of type {0} instead of a node of type {1}.";
            }
            static /*string */ FormatInvalidOperation_ExpectedNodeType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The XmlReader must be on a node of type {0} instead of a node of type {1}.", arg1, arg2);
            }
            static /*string */ get InvalidOperation_ExternalCode()
            {
                return "This operation was corrupted by external code.";
            }
            static /*string */ get InvalidOperation_MissingAncestor()
            {
                return "A common ancestor is missing.";
            }
            static /*string */ get InvalidOperation_MissingParent()
            {
                return "The parent is missing.";
            }
            static /*string */ get InvalidOperation_MissingRoot()
            {
                return "The root element is missing.";
            }
            static /*string */ get InvalidOperation_UnexpectedNodeType()
            {
                return "The XmlReader should not be on a node of type {0}.";
            }
            static /*string */ FormatInvalidOperation_UnexpectedNodeType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The XmlReader should not be on a node of type {0}.", arg1);
            }
            static /*string */ get InvalidOperation_UnresolvedEntityReference()
            {
                return "The XmlReader cannot resolve entity references.";
            }
            static /*string */ get InvalidOperation_WriteAttribute()
            {
                return "An attribute cannot be written after content.";
            }
            static /*string */ get NotSupported_WriteBase64()
            {
                return "This XmlWriter does not support base64 encoded data.";
            }
            static /*string */ get NotSupported_WriteEntityRef()
            {
                return "This XmlWriter does not support entity references.";
            }
            static /*string */ get Argument_CreateNavigator()
            {
                return "This XPathNavigator cannot be created on a node of type {0}.";
            }
            static /*string */ FormatArgument_CreateNavigator(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("This XPathNavigator cannot be created on a node of type {0}.", arg1);
            }
            static /*string */ get InvalidOperation_BadNodeType()
            {
                return "This operation is not valid on a node of type {0}.";
            }
            static /*string */ FormatInvalidOperation_BadNodeType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("This operation is not valid on a node of type {0}.", arg1);
            }
            static /*string */ get InvalidOperation_UnexpectedEvaluation()
            {
                return "The XPath expression evaluated to unexpected type {0}.";
            }
            static /*string */ FormatInvalidOperation_UnexpectedEvaluation(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The XPath expression evaluated to unexpected type {0}.", arg1);
            }
            static /*string */ get NotSupported_MoveToId()
            {
                return "This XPathNavigator does not support IDs.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$spxl.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$spxl.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$spxl.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$spxl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$spxl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$spxl.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 167473;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":167473}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$spxl.System.Text.StringBuilderCache", ($self) => class StringBuilderCache
        {
            /*int*/ static MaxBuilderSize = 360;
            /*int*/ static DefaultCapacity = 16;
            /*StringBuilder?*/ static t_cachedInstance = null;
            static /*StringBuilder */ Acquire(/*int*/ capacity)
            {
                if (capacity <= 360/*MaxBuilderSize*/)
                {
                    /*StringBuilder?*/ let sb = $.$spxl.System.Text.StringBuilderCache.t_cachedInstance;
                    if (sb !== null)
                    {
                        if (capacity <= sb.Capacity)
                        {
                            $.$spxl.System.Text.StringBuilderCache.t_cachedInstance = null;
                            sb.Clear();
                            return sb;
                        }
                    }
                }
                return new $.$spc.System.Text.StringBuilder().$ctor$2(capacity);
            }
            static /*void */ Release(/*StringBuilder*/ sb)
            {
                if (sb.Capacity <= 360/*MaxBuilderSize*/)
                {
                    $.$spxl.System.Text.StringBuilderCache.t_cachedInstance = sb;
                }
            }
            static /*string */ GetStringAndRelease(/*StringBuilder*/ sb)
            {
                /*string*/ let result = $.$spc.System.Text.StringBuilder.ToString.call(sb);
                $.$spxl.System.Text.StringBuilderCache.Release(sb);
                return result;
            }
            static $h = 233009;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":122945537,"p":[{"n":"capacity","p":655361,"f":65,"v":16}],"n":"Acquire","d":233009,"h":17180102193,"f":33},{"r":65537,"p":[{"n":"sb","p":122945537}],"n":"Release","d":233009,"h":21475069489,"f":33},{"r":1310721,"p":[{"n":"sb","p":122945537}],"n":"GetStringAndRelease","d":233009,"h":25770036785,"f":33}],"l":[{"t":655361,"n":"MaxBuilderSize","d":233009,"h":4295200305,"f":40},{"t":655361,"n":"DefaultCapacity","d":233009,"h":8590167601,"f":34},{"t":122945537,"n":"t_cachedInstance","d":233009,"h":12885134897,"f":34,"a":[{"t":140181505,"c":4435148801}]}],"h":233009}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Text.StringBuilderCache`; }
        });
        
        $asm.$cls("$spxl.System.Collections.Generic.EnumerableHelpers", ($self) => class EnumerableHelpers
        {
            static /*void */ Reset(T, /*ref T*/ enumerator)
            {
                return $.$dsp(enumerator.$v, T, ($t) => $t.System$Collections$IEnumerator$Reset,);
            }
            static /*IEnumerator<T> */ GetEmptyEnumerator(T, )
            {
                return ($.$spc.System.Array.Empty(T)).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            static /*T[] */ ToArray(T, /*IEnumerable<T>*/ source, /*out int*/ length)
            {
                /*int*/ let ArrayMaxLength = 2147483591;
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Array.MaxLength === ArrayMaxLength, "Array.MaxLength == ArrayMaxLength");
                let ic;
                if ($.$is(source, $.$spc.System.Collections.Generic.ICollection$$(T), { set $v(v){ ic = v; } }))
                {
                    /*int*/ let count = ic.System$Collections$Generic$ICollection$$$Count;
                    if (count !== 0)
                    {
                        /*T[]*/ let arr = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [count], null);
                        ic.System$Collections$Generic$ICollection$$$CopyTo(arr, 0, [T]);
                        length.$v = count;
                        return arr;
                    }
                }
                else 
                {
                    let en = null;
                    try
                    {
                        en = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                        if (en.System$Collections$IEnumerator$MoveNext())
                        {
                            /*int*/ let DefaultCapacity = 4;
                            /*T[]*/ let arr = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [DefaultCapacity], null);
                            $.$spc.System.Array.$WriteT1.call(arr, en.System$Collections$Generic$IEnumerator$$$Current, 0);
                            /*int*/ let count = 1;
                            while(en.System$Collections$IEnumerator$MoveNext())
                            {
                                if (count === arr.length)
                                {
                                    /*int*/ let newLength = count << 1;
                                    if ((newLength >>> 0) > ArrayMaxLength)
                                    {
                                        newLength = ArrayMaxLength <= count ? ((count + 1) | 0) : ArrayMaxLength;
                                    }
                                    $.$spc.System.Array.Resize(T, $.$ref(() => arr, ($v) => arr = $v, $.$typeArray(T)), newLength);
                                }
                                $.$spc.System.Array.$WriteT1.call(arr, en.System$Collections$Generic$IEnumerator$$$Current, count++);
                            }
                            length.$v = count;
                            return arr;
                        }
                    }
                    finally
                    {
                        en?.System$IDisposable$Dispose();
                    }
                }
                length.$v = 0;
                return $.$spc.System.Array.Empty(T);
            }
            static $h = 101937;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"enumerator","p":(T) => T.$h,"f":4}],"g":["T"],"n":"Reset","d":101937,"h":4295069233,"f":131112},{"r":(T) => $.$spc.System.Collections.Generic.IEnumerator$$(T).$h,"g":["T"],"n":"GetEmptyEnumerator","d":101937,"h":8590036529,"f":131112},{"r":0,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"length","p":655361,"f":2}],"g":["T"],"n":"ToArray","d":101937,"h":12885003825,"f":131112}],"h":101937}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Collections.Generic.EnumerableHelpers`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.LineInfoAnnotation", ($self) => class LineInfoAnnotation extends $.$spc.System.Object
        {
            /*int*/ lineNumber = 0;
            /*int*/ linePosition = 0;
            $ctor$1(/*int*/ lineNumber, /*int*/ linePosition)
            {
                super.$ctor();
                {
                    this.lineNumber = lineNumber;
                    this.linePosition = linePosition;
                }
                return this;
            }
            static $h = 560689;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"lineNumber","d":560689,"h":4295527985,"f":8},{"t":655361,"n":"linePosition","d":560689,"h":8590495281,"f":8}],"c":[{"p":[{"n":"lineNumber","p":655361},{"n":"linePosition","p":655361}],"n":".ctor","o":"$ctor$1","d":560689,"h":12885462577,"f":1}],"h":560689}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.LineInfoAnnotation`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.Extensions", ($self) => class Extensions
        {
            static /*IEnumerable<XAttribute> */ Attributes(/*this IEnumerable<XElement?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetAttributes(source, null);
            }
            static /*IEnumerable<XAttribute> */ Attributes$1(/*this IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetAttributes(source, name) : $.$spxl.System.Xml.Linq.XAttribute.EmptySequence;
            }
            static /*IEnumerable<XElement> */ Ancestors(T, /*this IEnumerable<T?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetAncestors(T, source, null, false);
            }
            static /*IEnumerable<XElement> */ Ancestors$1(T, /*this IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetAncestors(T, source, name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<XElement> */ AncestorsAndSelf(/*this IEnumerable<XElement?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetAncestors($.$spxl.System.Xml.Linq.XElement, source, null, true);
            }
            static /*IEnumerable<XElement> */ AncestorsAndSelf$1(/*this IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetAncestors($.$spxl.System.Xml.Linq.XElement, source, name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<XNode> */ Nodes(T, /*this IEnumerable<T?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.NodesIterator(T, source);
            }
            static /*IEnumerable<XNode> */ NodesIterator(T, /*IEnumerable<T?>*/ source)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                /*XNode?*/ let n = root.LastNode;
                                if (n !== null)
                                {
                                    do
                                    {
                                        n = n.next;
                                        yield n;
                                    }
                                    while(n.parent === root && n !== root.content);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XNode> */ DescendantNodes(T, /*this IEnumerable<T?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendantNodes(T, source, false);
            }
            static /*IEnumerable<XElement> */ Descendants(T, /*this IEnumerable<T?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendants(T, source, null, false);
            }
            static /*IEnumerable<XElement> */ Descendants$1(T, /*this IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetDescendants(T, source, name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<XNode> */ DescendantNodesAndSelf(/*this IEnumerable<XElement?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendantNodes($.$spxl.System.Xml.Linq.XElement, source, true);
            }
            static /*IEnumerable<XElement> */ DescendantsAndSelf(/*this IEnumerable<XElement?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendants($.$spxl.System.Xml.Linq.XElement, source, null, true);
            }
            static /*IEnumerable<XElement> */ DescendantsAndSelf$1(/*this IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetDescendants($.$spxl.System.Xml.Linq.XElement, source, name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<XElement> */ Elements(T, /*this IEnumerable<T?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetElements(T, source, null);
            }
            static /*IEnumerable<XElement> */ Elements$1(T, /*this IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetElements(T, source, name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<T> */ InDocumentOrder(T, /*this IEnumerable<T>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.DocumentOrderIterator(T, source);
            }
            static /*IEnumerable<T> */ DocumentOrderIterator(T, /*IEnumerable<T>*/ source)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*int*/ let count;
                    /*T[]*/ let items = $.$spxl.System.Collections.Generic.EnumerableHelpers.ToArray(T, source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32));
                    if (count > 0)
                    {
                        $.$spc.System.Array.Sort$14($.$spxl.System.Xml.Linq.XNode, items, 0, count, $.$spxl.System.Xml.Linq.XNode.DocumentOrderComparer);
                        for(/*int*/ let i = 0; i !== count; ++i)
                        {
                            yield $.$spc.System.Array.$ReadT1.call(items, i);
                        }
                    }
                }.bind(this));
            }
            static /*void */ Remove(/*this IEnumerable<XAttribute?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                /*int*/ let count;
                /*XAttribute?[]*/ let attributes = $.$spxl.System.Collections.Generic.EnumerableHelpers.ToArray($.$spxl.System.Xml.Linq.XAttribute, source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32));
                for(/*int*/ let i = 0; i < count; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(attributes, i)?.Remove();
                }
            }
            static /*void */ Remove$1(T, /*this IEnumerable<T?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                /*int*/ let count;
                /*T?[]*/ let nodes = $.$spxl.System.Collections.Generic.EnumerableHelpers.ToArray(T, source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32));
                for(/*int*/ let i = 0; i < count; i++)
                {
                    $.$dsp($.$spc.System.Array.$ReadT1.call(nodes, i), T, ($t) => $t.Remove,);
                }
            }
            static /*IEnumerable<XAttribute> */ GetAttributes(/*IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var e = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (e !== null)
                            {
                                /*XAttribute?*/ let a = e.lastAttr;
                                if (a !== null)
                                {
                                    do
                                    {
                                        a = a.next;
                                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(a.name, name))
                                        {
                                            yield a;
                                        }
                                    }
                                    while(a.parent === e && a !== e.lastAttr);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XElement> */ GetAncestors(T, /*IEnumerable<T?>*/ source, /*XName?*/ name, /*bool*/ self)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (node !== null)
                            {
                                /*XElement?*/ let e = $.$as((self ? node : node.parent), $.$spxl.System.Xml.Linq.XElement);
                                while(e !== null)
                                {
                                    if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                                    {
                                        yield e;
                                    }
                                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XNode> */ GetDescendantNodes(T, /*IEnumerable<T?>*/ source, /*bool*/ self)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                if (self)
                                {
                                    yield root;
                                }
                                /*XNode?*/ let n = root;
                                while(true)
                                {
                                    /*XContainer?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XContainer);
                                    /*XNode?*/ let first;
                                    if (c !== null && (first = c.FirstNode) !== null)
                                    {
                                        n = first;
                                    }
                                    else 
                                    {
                                        while(n !== null && n !== root && n === n.parent.content)
                                        {
                                            n = n.parent;
                                        }
                                        if (n === null || n === root)
                                        {
                                            break;
                                        }
                                        n = n.next;
                                    }
                                    yield n;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XElement> */ GetDescendants(T, /*IEnumerable<T?>*/ source, /*XName?*/ name, /*bool*/ self)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                if (self)
                                {
                                    /*XElement*/ let e = $.$cast(root, $.$spxl.System.Xml.Linq.XElement);
                                    if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                                    {
                                        yield e;
                                    }
                                }
                                /*XNode?*/ let n = root;
                                /*XContainer?*/ let c = root;
                                while(true)
                                {
                                    if (c !== null && $.$is(c.content, $.$spxl.System.Xml.Linq.XNode))
                                    {
                                        n = ($.$cast(c.content, $.$spxl.System.Xml.Linq.XNode)).next;
                                    }
                                    else 
                                    {
                                        while(n !== null && n !== root && n === n.parent.content)
                                        {
                                            n = n.parent;
                                        }
                                        if (n === null || n === root)
                                        {
                                            break;
                                        }
                                        n = n.next;
                                    }
                                    /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                                    if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                                    {
                                        yield e;
                                    }
                                    c = e;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XElement> */ GetElements(T, /*IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                /*XNode?*/ let n = $.$as(root.content, $.$spxl.System.Xml.Linq.XNode);
                                if (n !== null)
                                {
                                    do
                                    {
                                        n = n.next;
                                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                                        if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                                        {
                                            yield e;
                                        }
                                    }
                                    while(n.parent === root && n !== root.content);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static $h = 429617;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h}],"n":"Attributes","d":429617,"h":4295396913,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h},{"n":"name","p":2133553}],"n":"Attributes","o":"@$1","d":429617,"h":8590364209,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Ancestors","d":429617,"h":12885331505,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2133553}],"g":["T"],"n":"Ancestors","o":"@$1","d":429617,"h":17180298801,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h}],"n":"AncestorsAndSelf","d":429617,"h":21475266097,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h},{"n":"name","p":2133553}],"n":"AncestorsAndSelf","o":"@$1","d":429617,"h":25770233393,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Nodes","d":429617,"h":30065200689,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"NodesIterator","d":429617,"h":34360167985,"f":131106},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"DescendantNodes","d":429617,"h":38655135281,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Descendants","d":429617,"h":42950102577,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2133553}],"g":["T"],"n":"Descendants","o":"@$1","d":429617,"h":47245069873,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h}],"n":"DescendantNodesAndSelf","d":429617,"h":51540037169,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h}],"n":"DescendantsAndSelf","d":429617,"h":55835004465,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h},{"n":"name","p":2133553}],"n":"DescendantsAndSelf","o":"@$1","d":429617,"h":60129971761,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Elements","d":429617,"h":64424939057,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2133553}],"g":["T"],"n":"Elements","o":"@$1","d":429617,"h":68719906353,"f":131105},{"r":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"InDocumentOrder","d":429617,"h":73014873649,"f":131105},{"r":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"DocumentOrderIterator","d":429617,"h":77309840945,"f":131106},{"r":65537,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h}],"n":"Remove","d":429617,"h":81604808241,"f":33},{"r":65537,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Remove","o":"@$1","d":429617,"h":85899775537,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h},{"n":"name","p":2133553}],"n":"GetAttributes","d":429617,"h":90194742833,"f":34},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2133553},{"n":"self","p":262145}],"g":["T"],"n":"GetAncestors","d":429617,"h":94489710129,"f":131106},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"self","p":262145}],"g":["T"],"n":"GetDescendantNodes","d":429617,"h":98784677425,"f":131106},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2133553},{"n":"self","p":262145}],"g":["T"],"n":"GetDescendants","d":429617,"h":103079644721,"f":131106},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2133553}],"g":["T"],"n":"GetElements","d":429617,"h":107374612017,"f":131106}],"h":429617}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.Extensions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XDeclaration", ($self) => class XDeclaration extends $.$spc.System.Object
        {
            /*string?*/ _version = null;
            /*string?*/ _encoding = null;
            /*string?*/ _standalone = null;
            $ctor$1(/*string?*/ version, /*string?*/ encoding, /*string?*/ standalone)
            {
                super.$ctor();
                {
                    this._version = version;
                    this._encoding = encoding;
                    this._standalone = standalone;
                }
                return this;
            }
            $ctor$2(/*XDeclaration*/ other)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this._version = other._version;
                    this._encoding = other._encoding;
                    this._standalone = other._standalone;
                }
                return this;
            }
            $ctor$3(/*XmlReader*/ r)
            {
                super.$ctor();
                {
                    this._version = r.GetAttribute("version");
                    this._encoding = r.GetAttribute("encoding");
                    this._standalone = r.GetAttribute("standalone");
                    r.Read();
                }
                return this;
            }
            /*string? */ get Encoding()
            {
                return this._encoding;
            }
            /*string? */ set Encoding(value)
            {
                this._encoding = value;
            }
            /*string? */ get Standalone()
            {
                return this._standalone;
            }
            /*string? */ set Standalone(value)
            {
                this._standalone = value;
            }
            /*string? */ get Version()
            {
                return this._version;
            }
            /*string? */ set Version(value)
            {
                this._version = value;
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*StringBuilder*/ let sb = $.$spxl.System.Text.StringBuilderCache.Acquire(16);
                sb.Append$2("<?xml");
                if ($.$spc.System.String.op_Inequality(this._version, null))
                {
                    sb.Append$2(" version=\"");
                    sb.Append$2(this._version);
                    sb.Append$7(/*\"*/ 34);
                }
                if ($.$spc.System.String.op_Inequality(this._encoding, null))
                {
                    sb.Append$2(" encoding=\"");
                    sb.Append$2(this._encoding);
                    sb.Append$7(/*\"*/ 34);
                }
                if ($.$spc.System.String.op_Inequality(this._standalone, null))
                {
                    sb.Append$2(" standalone=\"");
                    sb.Append$2(this._standalone);
                    sb.Append$7(/*\"*/ 34);
                }
                sb.Append$2("?>");
                return $.$spxl.System.Text.StringBuilderCache.GetStringAndRelease(sb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XDeclaration.ToString.apply(this, arguments); }
            static $h = 1478193;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":34361216561,"f":1},"s":{"r":0,"d":0,"h":38656183857,"f":1},"n":"Encoding","d":1478193,"h":30066249265,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":47246118449,"f":1},"s":{"r":0,"d":0,"h":51541085745,"f":1},"n":"Standalone","d":1478193,"h":42951151153,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":60131020337,"f":1},"s":{"r":0,"d":0,"h":64425987633,"f":1},"n":"Version","d":1478193,"h":55836053041,"f":1}],"m":[{"r":1310721,"n":"ToString","d":1478193,"h":68720954929,"f":32769}],"l":[{"t":1310721,"n":"_version","d":1478193,"h":4296445489,"f":2},{"t":1310721,"n":"_encoding","d":1478193,"h":8591412785,"f":2},{"t":1310721,"n":"_standalone","d":1478193,"h":12886380081,"f":2}],"c":[{"p":[{"n":"version","p":1310721},{"n":"encoding","p":1310721},{"n":"standalone","p":1310721}],"n":".ctor","o":"$ctor$1","d":1478193,"h":17181347377,"f":1},{"p":[{"n":"other","p":1478193}],"n":".ctor","o":"$ctor$2","d":1478193,"h":21476314673,"f":1},{"p":[{"n":"r","p":53398620}],"n":".ctor","o":"$ctor$3","d":1478193,"h":25771281969,"f":8}],"h":1478193}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XDeclaration`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XHelper", ($self) => class XHelper
        {
            static /*bool */ IsInstanceOfType(/*object?*/ o, /*Type*/ type)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Inequality$1(type, null), "type != null");
                return o !== null && type.IsAssignableFrom($.$spc.System.Object.GetType.call(o));
            }
            static $h = 2068017;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"o","p":131073},{"n":"type","p":142606337}],"n":"IsInstanceOfType","d":2068017,"h":4297035313,"f":40}],"h":2068017}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XHelper`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XHashtable<>", (TValue) => $asm.$gt("$spxl.System.Xml.Linq.XHashtable<>", [TValue], ($self) => class XHashtable$$ extends $.$spc.System.Object
        {
            /*XHashtableState*/ _state = null;
            static $_ExtractKeyDelegate;
            static get ExtractKeyDelegate()
            {
                let $cls = $.$spxl.System.Xml.Linq.XHashtable$$(TValue);
                return $cls.$_ExtractKeyDelegate ??= $asm.$ncls("$spxl.System.Xml.Linq.XHashtable$$.ExtractKeyDelegate", ($self) => class ExtractKeyDelegate extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn)
                    {
                        this._target = target;
                        this.$nativeFunction = fn;
                        return this;
                    }
                    /*string?*/ Invoke(/**/ $value)
                    {
                        return this.$nativeFunction.apply(this._target, arguments);
                    }
                    static $h = 1871409;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":1310721,"p":[{"n":"value","p":TValue?.$h??1507328}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":129},{"r":56950785,"p":[{"n":"value","p":TValue?.$h??1507328},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":129},{"r":1310721,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[57147393,113377281],"d":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>.ExtractKeyDelegate`; }
                }, $cls, ($v) => $cls.$_ExtractKeyDelegate = $v);
            }
            $ctor$1(/*ExtractKeyDelegate*/ extractKey, /*int*/ capacity)
            {
                super.$ctor();
                {
                    this._state = new ($.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState)().$ctor$1(extractKey, capacity);
                }
                return this;
            }
            /*bool */ TryGetValue(/*string*/ key, /*int*/ index, /*int*/ count, /*out TValue*/ value)
            {
                return this._state.TryGetValue(key, index, count, value);
            }
            /*TValue */ Add(/*TValue*/ value)
            {
                /*TValue*/ let newValue;
                while(true)
                {
                    if (this._state.TryAdd(value, $.$ref(() => newValue, ($v) => newValue = $v, TValue)))
                    {
                        return newValue;
                    }
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            /*XHashtableState*/ let newState = this._state.Resize();
                            $.$spc.System.Threading.Thread.MemoryBarrier();
                            this._state = newState;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                }
            }
            static $_XHashtableState;
            static get XHashtableState()
            {
                let $cls = $.$spxl.System.Xml.Linq.XHashtable$$(TValue);
                return $cls.$_XHashtableState ??= $asm.$ncls("$spxl.System.Xml.Linq.XHashtable$$.XHashtableState", ($self) => class XHashtableState extends $.$spc.System.Object
                {
                    /*int[]*/ _buckets = null;
                    /*Entry[]*/ _entries = null;
                    /*int*/ _numEntries = 0;
                    /*ExtractKeyDelegate*/ _extractKey = null;
                    /*int*/ static EndOfList = 0;
                    /*int*/ static FullList = -1;
                    $ctor$1(/*ExtractKeyDelegate*/ extractKey, /*int*/ capacity)
                    {
                        super.$ctor();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Numerics.BitOperations.IsPow2(capacity), "capacity must be a power of 2");
                            $.$spc.System.Diagnostics.Debug.Assert$1(extractKey !== null, "extractKey may not be null");
                            this._buckets = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [capacity], null);
                            this._entries = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.Entry), null, [capacity], null);
                            this._extractKey = extractKey;
                        }
                        return this;
                    }
                    /*XHashtableState */ Resize()
                    {
                        if (this._numEntries < this._buckets.length)
                        {
                            return this;
                        }
                        /*int*/ let newSize = 0;
                        for(/*int*/ let bucketIdx = 0; bucketIdx < this._buckets.length; bucketIdx++)
                        {
                            /*int*/ let entryIdx = $.$spc.System.Array.$ReadT1.call(this._buckets, bucketIdx);
                            if (entryIdx === 0/*EndOfList*/)
                            {
                                entryIdx = $.$spc.System.Threading.Interlocked.CompareExchange($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$spc.System.Int32, this._buckets, bucketIdx, false, true), -1/*FullList*/, 0/*EndOfList*/);
                            }
                            while(entryIdx > 0/*EndOfList*/)
                            {
                                if ($.$spc.System.String.op_Inequality(this._extractKey.Invoke($.$spc.System.Array.$ReadT1.call(this._entries, entryIdx).Value), null))
                                {
                                    newSize++;
                                }
                                if ($.$spc.System.Array.$ReadT1.call(this._entries, entryIdx).Next === 0/*EndOfList*/)
                                {
                                    entryIdx = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => $.$spc.System.Array.$ReadT1.call(this._entries, entryIdx).Next, ($v) => $.$spc.System.Array.$ReadT1.call(this._entries, entryIdx).Next = $v, $.$spc.System.Int32), -1/*FullList*/, 0/*EndOfList*/);
                                }
                                else 
                                {
                                    entryIdx = $.$spc.System.Array.$ReadT1.call(this._entries, entryIdx).Next;
                                }
                            }
                            $.$spc.System.Diagnostics.Debug.Assert$1(entryIdx === 0/*EndOfList*/, "Resize() should only be called by one thread");
                        }
                        if (newSize < $.trunc(this._buckets.length / 2))
                        {
                            newSize = this._buckets.length;
                        }
                        else 
                        {
                            newSize = ((this._buckets.length * 2) | 0);
                            if (newSize < 0)
                            {
                                throw new $.$spc.System.OverflowException().$ctor$13();
                            }
                        }
                        /*XHashtableState*/ let newHashtable = new ($.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState)().$ctor$1(this._extractKey, newSize);
                        for(/*int*/ let bucketIdx = 0; bucketIdx < this._buckets.length; bucketIdx++)
                        {
                            /*int*/ let entryIdx = $.$spc.System.Array.$ReadT1.call(this._buckets, bucketIdx);
                            while(entryIdx > 0/*EndOfList*/)
                            {
                                newHashtable.TryAdd($.$spc.System.Array.$ReadT1.call(this._entries, entryIdx).Value, $.$discardRef());
                                entryIdx = $.$spc.System.Array.$ReadT1.call(this._entries, entryIdx).Next;
                            }
                            $.$spc.System.Diagnostics.Debug.Assert$1(entryIdx === -1/*FullList*/, "Linked list should have been closed when it was counted");
                        }
                        return newHashtable;
                    }
                    /*bool */ TryGetValue(/*string*/ key, /*int*/ index, /*int*/ count, /*out TValue*/ value)
                    {
                        /*int*/ let hashCode = $.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.ComputeHashCode(key, index, count);
                        /*int*/ let entryIndex = 0;
                        if (this.FindEntry(hashCode, key, index, count, $.$ref(() => entryIndex, ($v) => entryIndex = $v, $.$spc.System.Int32)))
                        {
                            value.$v = $.$spc.System.Array.$ReadT1.call(this._entries, entryIndex).Value;
                            return true;
                        }
                        value.$v = $.$default(TValue);
                        return false;
                    }
                    /*bool */ TryAdd(/*TValue*/ value, /*out TValue*/ newValue)
                    {
                        /*int*/ let newEntry, entryIndex;
                        /*string?*/ let key;
                        /*int*/ let hashCode;
                        newValue.$v = value;
                        key = this._extractKey.Invoke(value);
                        if ($.$spc.System.String.op_Equality(key, null))
                        {
                            return true;
                        }
                        hashCode = $.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.ComputeHashCode(key, 0, key.length);
                        newEntry = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._numEntries, ($v) => this._numEntries = $v, $.$spc.System.Int32));
                        if (newEntry < 0 || newEntry >= this._buckets.length)
                        {
                            return false;
                        }
                        $.$spc.System.Array.$ReadT1.call(this._entries, newEntry).Value = value;
                        $.$spc.System.Array.$ReadT1.call(this._entries, newEntry).HashCode = hashCode;
                        $.$spc.System.Threading.Thread.MemoryBarrier();
                        entryIndex = 0;
                        while(!this.FindEntry(hashCode, key, 0, key.length, $.$ref(() => entryIndex, ($v) => entryIndex = $v, $.$spc.System.Int32)))
                        {
                            if (entryIndex === 0)
                            {
                                entryIndex = $.$spc.System.Threading.Interlocked.CompareExchange($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$spc.System.Int32, this._buckets, hashCode & (((this._buckets.length - 1) | 0)), false, true), newEntry, 0/*EndOfList*/);
                            }
                            else 
                            {
                                entryIndex = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => $.$spc.System.Array.$ReadT1.call(this._entries, entryIndex).Next, ($v) => $.$spc.System.Array.$ReadT1.call(this._entries, entryIndex).Next = $v, $.$spc.System.Int32), newEntry, 0/*EndOfList*/);
                            }
                            if (entryIndex <= 0/*EndOfList*/)
                            {
                                return entryIndex === 0/*EndOfList*/;
                            }
                        }
                        newValue.$v = $.$spc.System.Array.$ReadT1.call(this._entries, entryIndex).Value;
                        return true;
                    }
                    /*bool */ FindEntry(/*int*/ hashCode, /*string*/ key, /*int*/ index, /*int*/ count, /*ref int*/ entryIndex)
                    {
                        /*int*/ let previousIndex = entryIndex.$v;
                        /*int*/ let currentIndex;
                        if (previousIndex === 0)
                        {
                            currentIndex = $.$spc.System.Array.$ReadT1.call(this._buckets, hashCode & (((this._buckets.length - 1) | 0)));
                        }
                        else 
                        {
                            currentIndex = previousIndex;
                        }
                        while(currentIndex > 0/*EndOfList*/)
                        {
                            if ($.$spc.System.Array.$ReadT1.call(this._entries, currentIndex).HashCode === hashCode)
                            {
                                /*string?*/ let keyCompare = this._extractKey.Invoke($.$spc.System.Array.$ReadT1.call(this._entries, currentIndex).Value);
                                if ($.$spc.System.String.op_Equality(keyCompare, null))
                                {
                                    if ($.$spc.System.Array.$ReadT1.call(this._entries, currentIndex).Next > 0/*EndOfList*/)
                                    {
                                        $.$spc.System.Array.$ReadT1.call(this._entries, currentIndex).Value = $.$default(TValue);
                                        currentIndex = $.$spc.System.Array.$ReadT1.call(this._entries, currentIndex).Next;
                                        if (previousIndex === 0)
                                        {
                                            $.$spc.System.Array.$WriteT1.call(this._buckets, currentIndex, hashCode & (((this._buckets.length - 1) | 0)));
                                        }
                                        else 
                                        {
                                            $.$spc.System.Array.$ReadT1.call(this._entries, previousIndex).Next = currentIndex;
                                        }
                                        continue;
                                    }
                                }
                                else 
                                {
                                    if (count === keyCompare.length && $.$spc.System.String.CompareOrdinal$2(key, index, keyCompare, 0, count) === 0)
                                    {
                                        entryIndex.$v = currentIndex;
                                        return true;
                                    }
                                }
                            }
                            previousIndex = currentIndex;
                            currentIndex = $.$spc.System.Array.$ReadT1.call(this._entries, currentIndex).Next;
                        }
                        entryIndex.$v = previousIndex;
                        return false;
                    }
                    static /*int */ ComputeHashCode(/*string*/ key, /*int*/ index, /*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(key, null), "key should have been checked previously for null");
                        return $.$spc.System.String.GetHashCode$2($.$spc.System.MemoryExtensions.AsSpan$7(key, index, count));
                    }
                    static $_Entry;
                    static get Entry()
                    {
                        let $cls = $.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState;
                        return $cls.$_Entry ??= $asm.$nstr("$spxl.System.Xml.Linq.XHashtable$$.XHashtableState.Entry", ($self) => class Entry extends $.$spc.System.ValueType
                        {
                            /*TValue*/  get Value() { return this.$getField(0, 4); }
                            /*TValue*/  set Value(value) { this.$setField(0, 4, value); }
                            /*int*/  get HashCode() { return this.$getField(4, 4); }
                            /*int*/  set HashCode(value) { this.$setField(4, 4, value); }
                            /*int*/  get Next() { return this.$getField(8, 4); }
                            /*int*/  set Next(value) { this.$setField(8, 4, value); }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy.Value = this.Value;
                                copy.HashCode = this.HashCode;
                                copy.Next = this.Next;
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this.Value = $.$default(TValue);
                                this.HashCode = 0;
                                this.Next = 0;
                            }
                            static $h = 2002481;
                            static $z = 12;
                            static $f = 0b10000001011000000;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":TValue?.$h??1507328,"n":"Value","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"t":655361,"n":"HashCode","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"t":655361,"n":"Next","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"d":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.$h,"h":this.$h}; }
                            static get $b() { return $.$spc.System.ValueType; }
                            static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>.XHashtableState.Entry`; }
                        }, $cls, ($v) => $cls.$_Entry = $v);
                    }
                    static $h = 1936945;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":this.$h,"n":"Resize","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":1},{"r":262145,"p":[{"n":"key","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361},{"n":"value","p":TValue?.$h??1507328,"f":2}],"n":"TryGetValue","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},{"r":262145,"p":[{"n":"value","p":TValue?.$h??1507328},{"n":"newValue","p":TValue?.$h??1507328,"f":2}],"n":"TryAdd","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},{"r":262145,"p":[{"n":"hashCode","p":655361},{"n":"key","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361},{"n":"entryIndex","p":655361,"f":4}],"n":"FindEntry","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2},{"r":655361,"p":[{"n":"key","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"ComputeHashCode","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":34}],"l":[{"t":0,"n":"_buckets","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":0,"n":"_entries","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":655361,"n":"_numEntries","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).ExtractKeyDelegate.$h,"n":"_extractKey","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":655361,"n":"EndOfList","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":34},{"t":655361,"n":"FullList","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":34}],"c":[{"p":[{"n":"extractKey","p":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).ExtractKeyDelegate.$h},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1}],"j":[$.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.Entry.$h],"d":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>.XHashtableState`; }
                }, $cls, ($v) => $cls.$_XHashtableState = $v);
            }
            static $h = 1805873;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"key","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361},{"n":"value","p":TValue?.$h??1507328,"f":2}],"n":"TryGetValue","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},{"r":TValue?.$h??1507328,"p":[{"n":"value","p":TValue?.$h??1507328}],"n":"Add","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"l":[{"t":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.$h,"n":"_state","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2}],"c":[{"p":[{"n":"extractKey","p":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).ExtractKeyDelegate.$h},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"g":[TValue?.$h??1507328],"j":[$.$spxl.System.Xml.Linq.XHashtable$$(TValue).ExtractKeyDelegate.$h,$.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.$h],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$spxl.System.Xml.Linq.XNamespace", ($self) => class XNamespace extends $.$spc.System.Object
        {
            /*string*/ static xmlPrefixNamespace = null;
            /*string*/ static xmlnsPrefixNamespace = null;
            /*XHashtable<WeakReference<XNamespace>>?*/ static s_namespaces = null;
            /*WeakReference<XNamespace>?*/ static s_refNone = null;
            /*WeakReference<XNamespace>?*/ static s_refXml = null;
            /*WeakReference<XNamespace>?*/ static s_refXmlns = null;
            /*string*/ _namespaceName = null;
            /*int*/ _hashCode = 0;
            /*XHashtable<XName>*/ _names = null;
            /*int*/ static NamesCapacity = 8;
            /*int*/ static NamespacesCapacity = 32;
            $ctor$1(/*string*/ namespaceName)
            {
                super.$ctor();
                {
                    this._namespaceName = namespaceName;
                    this._hashCode = $.$spc.System.String.GetHashCode.call(namespaceName);
                    this._names = new ($.$spxl.System.Xml.Linq.XHashtable$$($.$spxl.System.Xml.Linq.XName))().$ctor$1(new $.$spxl.System.Xml.Linq.XHashtable$$($.$spxl.System.Xml.Linq.XName).ExtractKeyDelegate().$ctor(null, $.$spxl.System.Xml.Linq.XNamespace.ExtractLocalName), 8/*NamesCapacity*/);
                }
                return this;
            }
            /*string */ get NamespaceName()
            {
                return this._namespaceName;
            }
            /*XName */ GetName(/*string*/ localName)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(localName, "localName");
                return this.GetName$1(localName, 0, localName.length);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this._namespaceName;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XNamespace.ToString.apply(this, arguments); }
            static /*XNamespace */ get None()
            {
                return $.$spxl.System.Xml.Linq.XNamespace.EnsureNamespace($.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_refNone, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_refNone = $v, $.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), $.$spc.System.String.Empty);
            }
            static /*XNamespace */ get Xml()
            {
                return $.$spxl.System.Xml.Linq.XNamespace.EnsureNamespace($.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_refXml, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_refXml = $v, $.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), "http://www.w3.org/XML/1998/namespace"/*xmlPrefixNamespace*/);
            }
            static /*XNamespace */ get Xmlns()
            {
                return $.$spxl.System.Xml.Linq.XNamespace.EnsureNamespace($.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_refXmlns, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_refXmlns = $v, $.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), "http://www.w3.org/2000/xmlns/"/*xmlnsPrefixNamespace*/);
            }
            static /*XNamespace */ Get(/*string*/ namespaceName)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(namespaceName, "namespaceName");
                return $.$spxl.System.Xml.Linq.XNamespace.Get$1(namespaceName, 0, namespaceName.length);
            }
            static /*XNamespace? */ op_Implicit(/*string?*/ namespaceName)
            {
                return $.$spc.System.String.op_Inequality(namespaceName, null) ? $.$spxl.System.Xml.Linq.XNamespace.Get(namespaceName) : null;
            }
            static /*XName */ op_Addition(/*XNamespace*/ ns, /*string*/ localName)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(ns, "ns");
                return ns.GetName(localName);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return this === obj;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$spxl.System.Xml.Linq.XNamespace.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._hashCode;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$spxl.System.Xml.Linq.XNamespace.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*XNamespace?*/ left, /*XNamespace?*/ right)
            {
                return left === right;
            }
            static /*bool */ op_Inequality(/*XNamespace?*/ left, /*XNamespace?*/ right)
            {
                return left !== right;
            }
            /*XName */ GetName$1(/*string*/ localName, /*int*/ index, /*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index >= 0 && index <= localName.length, "Caller should have checked that index was in bounds");
                $.$spc.System.Diagnostics.Debug.Assert$1(count >= 0 && ((index + count) | 0) <= localName.length, "Caller should have checked that count was in bounds");
                /*XName?*/ let name;
                if (this._names.TryGetValue(localName, index, count, $.$ref(() => name, ($v) => name = $v, $.$spxl.System.Xml.Linq.XName)))
                {
                    return name;
                }
                return this._names.Add(new $.$spxl.System.Xml.Linq.XName().$ctor$1(this, $.$spc.System.String.Substring$1.call(localName, index, count)));
            }
            static /*XNamespace */ Get$1(/*string*/ namespaceName, /*int*/ index, /*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index >= 0 && index <= namespaceName.length, "Caller should have checked that index was in bounds");
                $.$spc.System.Diagnostics.Debug.Assert$1(count >= 0 && ((index + count) | 0) <= namespaceName.length, "Caller should have checked that count was in bounds");
                if (count === 0)
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.None;
                }
                if ($.$spxl.System.Xml.Linq.XNamespace.s_namespaces === null)
                {
                    $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spxl.System.Xml.Linq.XHashtable$$($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), $.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_namespaces, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_namespaces = $v, $.$spxl.System.Xml.Linq.XHashtable$$($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))), new ($.$spxl.System.Xml.Linq.XHashtable$$($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)))().$ctor$1(new $.$spxl.System.Xml.Linq.XHashtable$$($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)).ExtractKeyDelegate().$ctor(null, $.$spxl.System.Xml.Linq.XNamespace.ExtractNamespace), 32/*NamespacesCapacity*/), null);
                }
                /*WeakReference<XNamespace>?*/ let refNamespace;
                /*XNamespace?*/ let ns;
                do
                {
                    if (!$.$spxl.System.Xml.Linq.XNamespace.s_namespaces.TryGetValue(namespaceName, index, count, $.$ref(() => refNamespace, ($v) => refNamespace = $v, $.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))))
                    {
                        if (count === "http://www.w3.org/XML/1998/namespace"/*xmlPrefixNamespace*/.length && $.$spc.System.String.CompareOrdinal$2(namespaceName, index, "http://www.w3.org/XML/1998/namespace"/*xmlPrefixNamespace*/, 0, count) === 0)
                        {
                            return $.$spxl.System.Xml.Linq.XNamespace.Xml;
                        }
                        if (count === "http://www.w3.org/2000/xmlns/"/*xmlnsPrefixNamespace*/.length && $.$spc.System.String.CompareOrdinal$2(namespaceName, index, "http://www.w3.org/2000/xmlns/"/*xmlnsPrefixNamespace*/, 0, count) === 0)
                        {
                            return $.$spxl.System.Xml.Linq.XNamespace.Xmlns;
                        }
                        refNamespace = $.$spxl.System.Xml.Linq.XNamespace.s_namespaces.Add(new ($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))().$ctor$1(new $.$spxl.System.Xml.Linq.XNamespace().$ctor$1($.$spc.System.String.Substring$1.call(namespaceName, index, count))));
                    }
                    /*XNamespace?*/ let target;
                    ns = refNamespace !== null && refNamespace.TryGetTarget($.$ref(() => target, ($v) => target = $v, $.$spxl.System.Xml.Linq.XNamespace)) ? target : null;
                }
                while($.$spxl.System.Xml.Linq.XNamespace.op_Equality(ns, null));
                return ns;
            }
            static /*string */ ExtractLocalName(/*XName*/ n)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spxl.System.Xml.Linq.XName.op_Inequality(n, null), "Null name should never exist here");
                return n.LocalName;
            }
            static /*string? */ ExtractNamespace(/*WeakReference<XNamespace>?*/ r)
            {
                /*XNamespace?*/ let target;
                return !(r === null) && r.TryGetTarget($.$ref(() => target, ($v) => target = $v, $.$spxl.System.Xml.Linq.XNamespace)) ? target.NamespaceName : null;
            }
            static /*XNamespace */ EnsureNamespace(/*ref WeakReference<XNamespace>?*/ refNmsp, /*string*/ namespaceName)
            {
                /*WeakReference<XNamespace>?*/ let refOld;
                while(true)
                {
                    refOld = refNmsp.$v;
                    /*XNamespace?*/ let ns;
                    if (refOld !== null && refOld.TryGetTarget($.$ref(() => ns, ($v) => ns = $v, $.$spxl.System.Xml.Linq.XNamespace)))
                    {
                        return ns;
                    }
                    $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace), refNmsp, new ($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))().$ctor$1(new $.$spxl.System.Xml.Linq.XNamespace().$ctor$1(namespaceName)), refOld);
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.xmlPrefixNamespace = "http://www.w3.org/XML/1998/namespace";
                }
                {
                    this.xmlnsPrefixNamespace = "http://www.w3.org/2000/xmlns/";
                }
            }
            static $h = 2199089;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":60131741233,"f":1},"n":"NamespaceName","d":2199089,"h":55836773937,"f":1},{"p":2199089,"g":{"r":0,"d":0,"h":77311610417,"f":33},"n":"None","d":2199089,"h":73016643121,"f":33},{"p":2199089,"g":{"r":0,"d":0,"h":85901545009,"f":33},"n":"Xml","d":2199089,"h":81606577713,"f":33},{"p":2199089,"g":{"r":0,"d":0,"h":94491479601,"f":33},"n":"Xmlns","d":2199089,"h":90196512305,"f":33}],"m":[{"r":2133553,"p":[{"n":"localName","p":1310721}],"n":"GetName","d":2199089,"h":64426708529,"f":1},{"r":1310721,"n":"ToString","d":2199089,"h":68721675825,"f":32769},{"r":2199089,"p":[{"n":"namespaceName","p":1310721}],"n":"Get","d":2199089,"h":98786446897,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2199089,"h":111671348785,"f":32769},{"r":655361,"n":"GetHashCode","d":2199089,"h":115966316081,"f":32769},{"r":2133553,"p":[{"n":"localName","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetName","o":"@$1","d":2199089,"h":128851217969,"f":8},{"r":2199089,"p":[{"n":"namespaceName","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"Get","o":"@$1","d":2199089,"h":133146185265,"f":40},{"r":1310721,"p":[{"n":"n","p":2133553}],"n":"ExtractLocalName","d":2199089,"h":137441152561,"f":34},{"r":1310721,"p":[{"n":"r","p":$.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h}],"n":"ExtractNamespace","d":2199089,"h":141736119857,"f":34},{"r":2199089,"p":[{"n":"refNmsp","p":$.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,"f":4},{"n":"namespaceName","p":1310721}],"n":"EnsureNamespace","d":2199089,"h":146031087153,"f":34}],"l":[{"t":1310721,"n":"xmlPrefixNamespace","d":2199089,"h":4297166385,"f":40},{"t":1310721,"n":"xmlnsPrefixNamespace","d":2199089,"h":8592133681,"f":40},{"t":$.$spxl.System.Xml.Linq.XHashtable$$($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)).$h,"n":"s_namespaces","d":2199089,"h":12887100977,"f":34},{"t":$.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,"n":"s_refNone","d":2199089,"h":17182068273,"f":34},{"t":$.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,"n":"s_refXml","d":2199089,"h":21477035569,"f":34},{"t":$.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,"n":"s_refXmlns","d":2199089,"h":25772002865,"f":34},{"t":1310721,"n":"_namespaceName","d":2199089,"h":30066970161,"f":2},{"t":655361,"n":"_hashCode","d":2199089,"h":34361937457,"f":2},{"t":$.$spxl.System.Xml.Linq.XHashtable$$($.$spxl.System.Xml.Linq.XName).$h,"n":"_names","d":2199089,"h":38656904753,"f":2},{"t":655361,"n":"NamesCapacity","d":2199089,"h":42951872049,"f":34},{"t":655361,"n":"NamespacesCapacity","d":2199089,"h":47246839345,"f":34}],"c":[{"p":[{"n":"namespaceName","p":1310721}],"n":".ctor","o":"$ctor$1","d":2199089,"h":51541806641,"f":8}],"h":2199089}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XNamespace`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XObjectChangeAnnotation", ($self) => class XObjectChangeAnnotation extends $.$spc.System.Object
        {
            /*EventHandler<XObjectChangeEventArgs>?*/ changing = null;
            /*EventHandler<XObjectChangeEventArgs>?*/ changed = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2723377;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,"n":"changing","d":2723377,"h":4297690673,"f":8},{"t":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,"n":"changed","d":2723377,"h":8592657969,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":2723377,"h":12887625265,"f":1}],"h":2723377}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XObjectChangeAnnotation`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XStreamingElement", ($self) => class XStreamingElement extends $.$spc.System.Object
        {
            /*XName*/ name = null;
            /*object?*/ content = null;
            $ctor$1(/*XName*/ name)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                    this.name = name;
                }
                return this;
            }
            $ctor$2(/*XName*/ name, /*object?*/ content)
            {
                this.$ctor$1(name);
                {
                    this.content = $.$is(content, $.$spc.System.Collections.Generic.List$$($.$spc.System.Object)) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [content], [-1], null) : content;
                }
                return this;
            }
            $ctor$3(/*XName*/ name, /*params object?[]*/ content)
            {
                this.$ctor$1(name);
                {
                    this.content = content;
                }
                return this;
            }
            /*XName */ get Name()
            {
                return this.name;
            }
            /*XName */ set Name(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                this.name = value;
            }
            /*void */ Add(/*object?*/ content)
            {
                if (content !== null)
                {
                    /*List<object>?*/ let list = $.$as(this.content, $.$spc.System.Collections.Generic.List$$($.$spc.System.Object));
                    if (list === null)
                    {
                        list = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Object))().$ctor$1();
                        if (this.content !== null)
                        {
                            list.Add(this.content);
                        }
                        this.content = list;
                    }
                    list.Add(content);
                }
            }
            /*void */ Add$1(/*params object?[]*/ content)
            {
                this.Add($.$cast(content, $.$spc.System.Object));
            }
            /*void */ Save(/*Stream*/ stream)
            {
                this.Save$1(stream, 0/*SaveOptions.None*/);
            }
            /*void */ Save$1(/*Stream*/ stream, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$3(stream, ws);
                    this.Save$4(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*void */ Save$2(/*TextWriter*/ textWriter)
            {
                this.Save$3(textWriter, 0/*SaveOptions.None*/);
            }
            /*void */ Save$3(/*TextWriter*/ textWriter, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$5(textWriter, ws);
                    this.Save$4(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*void */ Save$4(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                writer.WriteStartDocument();
                this.WriteTo(writer);
                writer.WriteEndDocument();
            }
            /*void */ Save$5(/*string*/ fileName)
            {
                this.Save$6(fileName, 0/*SaveOptions.None*/);
            }
            /*void */ Save$6(/*string*/ fileName, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$1(fileName, ws);
                    this.Save$4(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.GetXmlString(0/*SaveOptions.None*/);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XStreamingElement.ToString.apply(this, arguments); }
            /*string */ ToString$1(/*SaveOptions*/ options)
            {
                return this.GetXmlString(options);
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                new $.$spxl.System.Xml.Linq.StreamingElementWriter().$ctor$2(writer).WriteStreamingElement(this);
            }
            /*string */ GetXmlString(/*SaveOptions*/ o)
            {
                let sw = null;
                try
                {
                    sw = new $.$spc.System.IO.StringWriter().$ctor$5($.$spc.System.Globalization.CultureInfo.InvariantCulture);
                    /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                    ws.OmitXmlDeclaration = true;
                    if ((o & 1/*SaveOptions.DisableFormatting*/) === 0)
                    {
                        ws.Indent = true;
                    }
                    if ((o & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0)
                    {
                        ws.NamespaceHandling |= 1/*NamespaceHandling.OmitDuplicates*/;
                    }
                    let w = null;
                    try
                    {
                        w = $.$spx.System.Xml.XmlWriter.Create$5(sw, ws);
                        this.WriteTo(w);
                    }
                    finally
                    {
                        w?.System$IDisposable$Dispose();
                    }
                    return $.$spc.System.IO.StringWriter.ToString.call(sw);
                }
                finally
                {
                    sw?.System$IDisposable$Dispose();
                }
            }
            static $h = 2919985;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2133553,"g":{"r":0,"d":0,"h":30067691057,"f":1},"s":{"r":0,"d":0,"h":34362658353,"f":1},"n":"Name","d":2919985,"h":25772723761,"f":1}],"m":[{"r":65537,"p":[{"n":"content","p":131073}],"n":"Add","d":2919985,"h":38657625649,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"Add","o":"@$1","d":2919985,"h":42952592945,"f":1},{"r":65537,"p":[{"n":"stream","p":62128129}],"n":"Save","d":2919985,"h":47247560241,"f":1},{"r":65537,"p":[{"n":"stream","p":62128129},{"n":"options","p":1019441}],"n":"Save","o":"@$1","d":2919985,"h":51542527537,"f":1},{"r":65537,"p":[{"n":"textWriter","p":62980097}],"n":"Save","o":"@$2","d":2919985,"h":55837494833,"f":1},{"r":65537,"p":[{"n":"textWriter","p":62980097},{"n":"options","p":1019441}],"n":"Save","o":"@$3","d":2919985,"h":60132462129,"f":1},{"r":65537,"p":[{"n":"writer","p":58444892}],"n":"Save","o":"@$4","d":2919985,"h":64427429425,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"Save","o":"@$5","d":2919985,"h":68722396721,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"options","p":1019441}],"n":"Save","o":"@$6","d":2919985,"h":73017364017,"f":1},{"r":1310721,"n":"ToString","d":2919985,"h":77312331313,"f":32769},{"r":1310721,"p":[{"n":"options","p":1019441}],"n":"ToString","o":"@$1","d":2919985,"h":81607298609,"f":1},{"r":65537,"p":[{"n":"writer","p":58444892}],"n":"WriteTo","d":2919985,"h":85902265905,"f":1},{"r":1310721,"p":[{"n":"o","p":1019441}],"n":"GetXmlString","d":2919985,"h":90197233201,"f":2}],"l":[{"t":2133553,"n":"name","d":2919985,"h":4297887281,"f":8},{"t":131073,"n":"content","d":2919985,"h":8592854577,"f":8}],"c":[{"p":[{"n":"name","p":2133553}],"n":".ctor","o":"$ctor$1","d":2919985,"h":12887821873,"f":1},{"p":[{"n":"name","p":2133553},{"n":"content","p":131073}],"n":".ctor","o":"$ctor$2","d":2919985,"h":17182789169,"f":1},{"p":[{"n":"name","p":2133553},{"n":"content","p":0,"f":16}],"n":".ctor","o":"$ctor$3","d":2919985,"h":21477756465,"f":1}],"h":2919985}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XStreamingElement`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Schema.XNodeValidator", ($self) => class XNodeValidator extends $.$spc.System.Object
        {
            /*XmlSchemaSet*/ schemas = null;
            /*ValidationEventHandler?*/ validationEventHandler = null;
            /*XObject?*/ source = null;
            /*bool*/ addSchemaInfo = false;
            /*XmlNamespaceManager?*/ namespaceManager = null;
            /*XmlSchemaValidator?*/ validator = null;
            /*HashSet<XmlSchemaInfo>?*/ schemaInfos = null;
            /*ArrayList?*/ defaultAttributes = null;
            /*XName*/ xsiTypeName = null;
            /*XName*/ xsiNilName = null;
            $ctor$1(/*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                super.$ctor();
                {
                    this.schemas = schemas;
                    this.validationEventHandler = validationEventHandler;
                    /*XNamespace*/ let xsi = $.$spxl.System.Xml.Linq.XNamespace.Get("http://www.w3.org/2001/XMLSchema-instance");
                    this.xsiTypeName = xsi.GetName("type");
                    this.xsiNilName = xsi.GetName("nil");
                }
                return this;
            }
            /*void */ Validate(/*XObject*/ source, /*XmlSchemaObject?*/ partialValidationType, /*bool*/ addSchemaInfo)
            {
                this.source = source;
                this.addSchemaInfo = addSchemaInfo;
                /*XmlSchemaValidationFlags*/ let validationFlags = 16/*XmlSchemaValidationFlags.AllowXmlAttributes*/;
                /*XmlNodeType*/ let nt = source.NodeType;
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    switch($switchJumpState1 ?? nt)
                    {
                        case 9/*XmlNodeType.Document*/:
                        source = ($.$cast(source, $.$spxl.System.Xml.Linq.XDocument)).Root;
                        if (source === null)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingRoot);
                        }
                        validationFlags |= 8/*XmlSchemaValidationFlags.ProcessIdentityConstraints*/;
                        break;
                        case 1/*XmlNodeType.Element*/:
                        break;
                        case 2/*XmlNodeType.Attribute*/:
                        if (($.$cast(source, $.$spxl.System.Xml.Linq.XAttribute)).IsNamespaceDeclaration)
                        {
                            $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                            continue $switchJumpStart1;
                        }
                        if (source.Parent === null)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingParent);
                        }
                        break;
                        default:
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_BadNodeType, $.$box(nt, $.$spx.System.Xml.XmlNodeType)));
                    }
                    break;
                }
                this.namespaceManager = new $.$spx.System.Xml.XmlNamespaceManager().$ctor$2(this.schemas.NameTable);
                this.PushAncestorsAndSelf(source.Parent);
                this.validator = new $.$spx.System.Xml.Schema.XmlSchemaValidator().$ctor$1(this.schemas.NameTable, this.schemas, this.namespaceManager, validationFlags);
                this.validator.add_ValidationEventHandler(new $.$spx.System.Xml.Schema.ValidationEventHandler().$ctor(this, this.ValidationCallback));
                this.validator.XmlResolver = null;
                if (partialValidationType !== null)
                {
                    this.validator.Initialize$1(partialValidationType);
                }
                else 
                {
                    this.validator.Initialize();
                }
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(source);
                if (nt === 2/*XmlNodeType.Attribute*/)
                {
                    this.ValidateAttribute($.$cast(source, $.$spxl.System.Xml.Linq.XAttribute));
                }
                else 
                {
                    this.ValidateElement($.$cast(source, $.$spxl.System.Xml.Linq.XElement));
                }
                this.validator.EndValidation();
                this.RestoreLineInfo(original);
            }
            /*XmlSchemaInfo */ GetDefaultAttributeSchemaInfo(/*XmlSchemaAttribute*/ sa)
            {
                /*XmlSchemaInfo*/ let si = new $.$spx.System.Xml.Schema.XmlSchemaInfo().$ctor$1();
                si.IsDefault = true;
                si.IsNil = false;
                si.SchemaAttribute = sa;
                $.$spc.System.Diagnostics.Debug.Assert$1(sa.AttributeSchemaType !== null, "sa.AttributeSchemaType != null");
                /*XmlSchemaSimpleType*/ let st = sa.AttributeSchemaType;
                si.SchemaType = st;
                $.$spc.System.Diagnostics.Debug.Assert$1(st.Datatype !== null, "st.Datatype != null");
                if (st.Datatype.Variety === 2/*XmlSchemaDatatypeVariety.Union*/)
                {
                    /*string?*/ let value = this.GetDefaultValue(sa);
                    $.$spc.System.Diagnostics.Debug.Assert$1(st.Content !== null, "st.Content != null");
                    let $i1 = 0;
                    let $arr1 = ($.$cast(st.Content, $.$spx.System.Xml.Schema.XmlSchemaSimpleTypeUnion)).BaseMemberTypes;
                    while ($i1 < $arr1.length)
                    {
                        let mt = $arr1[$i1++];
                        /*object?*/ let typedValue = null;
                        try
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(mt.Datatype !== null, "mt.Datatype != null");
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(value, null), "value != null");
                            typedValue = mt.Datatype.ParseValue(value, this.schemas.NameTable, this.namespaceManager);
                        }
                        catch($e)
                        {
                        }
                        if (typedValue !== null)
                        {
                            si.MemberType = mt;
                            break;
                        }
                    }
                }
                si.Validity = 1/*XmlSchemaValidity.Valid*/;
                return si;
            }
            /*string? */ GetDefaultValue(/*XmlSchemaAttribute*/ sa)
            {
                /*XmlSchemaAttribute?*/ let saCopy = sa;
                /*XmlQualifiedName*/ let name = saCopy.RefName;
                if (!name.IsEmpty)
                {
                    saCopy = $.$as(this.schemas.GlobalAttributes.get_Item(name), $.$spx.System.Xml.Schema.XmlSchemaAttribute);
                    if (saCopy === null)
                    {
                        return null;
                    }
                }
                /*string?*/ let s = saCopy.FixedValue;
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    return s;
                }
                return saCopy.DefaultValue;
            }
            /*string? */ GetDefaultValue$1(/*XmlSchemaElement*/ se)
            {
                /*XmlSchemaElement?*/ let seCopy = se;
                /*XmlQualifiedName*/ let name = seCopy.RefName;
                if (!name.IsEmpty)
                {
                    seCopy = $.$as(this.schemas.GlobalElements.get_Item(name), $.$spx.System.Xml.Schema.XmlSchemaElement);
                    if (seCopy === null)
                    {
                        return null;
                    }
                }
                /*string?*/ let s = seCopy.FixedValue;
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    return s;
                }
                return seCopy.DefaultValue;
            }
            /*void */ ReplaceSchemaInfo(/*XObject*/ o, /*XmlSchemaInfo*/ schemaInfo)
            {
                this.schemaInfos ??= new ($.$spc.System.Collections.Generic.HashSet$$($.$spx.System.Xml.Schema.XmlSchemaInfo))().$ctor$2(new $.$spxl.System.Xml.Schema.XmlSchemaInfoEqualityComparer().$ctor$1());
                /*XmlSchemaInfo?*/ let si = o.Annotation$1($.$spx.System.Xml.Schema.XmlSchemaInfo);
                if (si !== null)
                {
                    this.schemaInfos.Add(si);
                    o.RemoveAnnotations$1($.$spx.System.Xml.Schema.XmlSchemaInfo);
                }
                if (!this.schemaInfos.TryGetValue(schemaInfo, $.$ref(() => si, ($v) => si = $v, $.$spx.System.Xml.Schema.XmlSchemaInfo)))
                {
                    si = schemaInfo;
                    this.schemaInfos.Add(si);
                }
                o.AddAnnotation(si);
            }
            /*void */ PushAncestorsAndSelf(/*XElement?*/ e)
            {
                while(e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration)
                            {
                                /*string*/ let localName = a.Name.LocalName;
                                if ($.$spc.System.String.op_Equality(localName, "xmlns"))
                                {
                                    localName = $.$spc.System.String.Empty;
                                }
                                if (!this.namespaceManager.HasNamespace(localName))
                                {
                                    this.namespaceManager.AddNamespace(localName, a.Value);
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                }
            }
            /*void */ PushElement(/*XElement*/ e, /*ref string?*/ xsiType, /*ref string?*/ xsiNil)
            {
                this.namespaceManager.PushScope();
                /*XAttribute?*/ let a = e.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if (a.IsNamespaceDeclaration)
                        {
                            /*string*/ let localName = a.Name.LocalName;
                            if ($.$spc.System.String.op_Equality(localName, "xmlns"))
                            {
                                localName = $.$spc.System.String.Empty;
                            }
                            this.namespaceManager.AddNamespace(localName, a.Value);
                        }
                        else 
                        {
                            /*XName*/ let name = a.Name;
                            if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, this.xsiTypeName))
                            {
                                xsiType.$v = a.Value;
                            }
                            else if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, this.xsiNilName))
                            {
                                xsiNil.$v = a.Value;
                            }
                        }
                    }
                    while(a !== e.lastAttr);
                }
            }
            /*IXmlLineInfo */ SaveLineInfo(/*XObject?*/ source)
            {
                /*IXmlLineInfo*/ let previousLineInfo = this.validator.LineInfoProvider;
                this.validator.LineInfoProvider = $.$as(source, $.$spx.System.Xml.IXmlLineInfo);
                return previousLineInfo;
            }
            /*void */ RestoreLineInfo(/*IXmlLineInfo*/ originalLineInfo)
            {
                this.validator.LineInfoProvider = originalLineInfo;
            }
            /*void */ ValidateAttribute(/*XAttribute*/ a)
            {
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(a);
                /*XmlSchemaInfo?*/ let si = this.addSchemaInfo ? new $.$spx.System.Xml.Schema.XmlSchemaInfo().$ctor$1() : null;
                this.source = a;
                this.validator.ValidateAttribute(a.Name.LocalName, a.Name.NamespaceName, a.Value, si);
                if (this.addSchemaInfo)
                {
                    this.ReplaceSchemaInfo(a, si);
                }
                this.RestoreLineInfo(original);
            }
            /*void */ ValidateAttributes(/*XElement*/ e)
            {
                /*XAttribute?*/ let a = e.lastAttr;
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(a);
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if (!a.IsNamespaceDeclaration)
                        {
                            this.ValidateAttribute(a);
                        }
                    }
                    while(a !== e.lastAttr);
                    this.source = e;
                }
                if (this.addSchemaInfo)
                {
                    if (this.defaultAttributes === null)
                    {
                        this.defaultAttributes = new $.$spc.System.Collections.ArrayList().$ctor$1();
                    }
                    else 
                    {
                        this.defaultAttributes.Clear();
                    }
                    this.validator.GetUnspecifiedDefaultAttributes(this.defaultAttributes);
                    var $en3 = this.defaultAttributes.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var sa = $en3.Current;
                        {
                            a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2($.$spxl.System.Xml.Linq.XNamespace.Get(sa.QualifiedName.Namespace).GetName(sa.QualifiedName.Name), this.GetDefaultValue(sa));
                            this.ReplaceSchemaInfo(a, this.GetDefaultAttributeSchemaInfo(sa));
                            e.Add(a);
                        }
                    }
                }
                this.RestoreLineInfo(original);
            }
            /*void */ ValidateElement(/*XElement*/ e)
            {
                /*XmlSchemaInfo?*/ let si = this.addSchemaInfo ? new $.$spx.System.Xml.Schema.XmlSchemaInfo().$ctor$1() : null;
                /*string?*/ let xsiType = null;
                /*string?*/ let xsiNil = null;
                this.PushElement(e, $.$ref(() => xsiType, ($v) => xsiType = $v, $.$spc.System.String), $.$ref(() => xsiNil, ($v) => xsiNil = $v, $.$spc.System.String));
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(e);
                this.source = e;
                this.validator.ValidateElement$1(e.Name.LocalName, e.Name.NamespaceName, si, xsiType, xsiNil, null, null);
                this.ValidateAttributes(e);
                this.validator.ValidateEndOfAttributes(si);
                this.ValidateNodes(e);
                this.validator.ValidateEndElement(si);
                if (this.addSchemaInfo)
                {
                    if (si.Validity === 1/*XmlSchemaValidity.Valid*/ && si.IsDefault)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(si.SchemaElement !== null, "si.SchemaElement != null");
                        e.Value = this.GetDefaultValue$1(si.SchemaElement);
                    }
                    this.ReplaceSchemaInfo(e, si);
                }
                this.RestoreLineInfo(original);
                this.namespaceManager.PopScope();
            }
            /*void */ ValidateNodes(/*XElement*/ e)
            {
                /*XNode?*/ let n = $.$as(e.content, $.$spxl.System.Xml.Linq.XNode);
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(n);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*XElement?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (c !== null)
                        {
                            this.ValidateElement(c);
                        }
                        else 
                        {
                            /*XText?*/ let t = $.$as(n, $.$spxl.System.Xml.Linq.XText);
                            if (t !== null)
                            {
                                /*string*/ let s = t.Value;
                                if (s.length > 0)
                                {
                                    this.validator.LineInfoProvider = $.$as(t, $.$spx.System.Xml.IXmlLineInfo);
                                    this.validator.ValidateText(s);
                                }
                            }
                        }
                    }
                    while(n !== e.content);
                    this.source = e;
                }
                else 
                {
                    /*string?*/ let s = $.$as(e.content, $.$spc.System.String);
                    if ($.$spc.System.String.op_Inequality(s, null) && s.length > 0)
                    {
                        this.validator.ValidateText(s);
                    }
                }
                this.RestoreLineInfo(original);
            }
            /*void */ ValidationCallback(/*object?*/ sender, /*ValidationEventArgs*/ e)
            {
                if (this.validationEventHandler !== null)
                {
                    this.validationEventHandler.Invoke(this.source, e);
                }
                else if (e.Severity === 0/*XmlSeverityType.Error*/)
                {
                    throw e.Exception;
                }
            }
            static $h = 3182129;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"source","p":2592305},{"n":"partialValidationType","p":30919772},{"n":"addSchemaInfo","p":262145}],"n":"Validate","d":3182129,"h":51542789681,"f":1},{"r":30133340,"p":[{"n":"sa","p":27774044}],"n":"GetDefaultAttributeSchemaInfo","d":3182129,"h":55837756977,"f":2},{"r":1310721,"p":[{"n":"sa","p":27774044}],"n":"GetDefaultValue","d":3182129,"h":60132724273,"f":2},{"r":1310721,"p":[{"n":"se","p":29084764}],"n":"GetDefaultValue","o":"@$1","d":3182129,"h":64427691569,"f":2},{"r":65537,"p":[{"n":"o","p":2592305},{"n":"schemaInfo","p":30133340}],"n":"ReplaceSchemaInfo","d":3182129,"h":68722658865,"f":2},{"r":65537,"p":[{"n":"e","p":1674801}],"n":"PushAncestorsAndSelf","d":3182129,"h":73017626161,"f":2},{"r":65537,"p":[{"n":"e","p":1674801},{"n":"xsiType","p":1310721,"f":4},{"n":"xsiNil","p":1310721,"f":4}],"n":"PushElement","d":3182129,"h":77312593457,"f":2},{"r":13945948,"p":[{"n":"source","p":2592305}],"n":"SaveLineInfo","d":3182129,"h":81607560753,"f":2},{"r":65537,"p":[{"n":"originalLineInfo","p":13945948}],"n":"RestoreLineInfo","d":3182129,"h":85902528049,"f":2},{"r":65537,"p":[{"n":"a","p":1150513}],"n":"ValidateAttribute","d":3182129,"h":90197495345,"f":2},{"r":65537,"p":[{"n":"e","p":1674801}],"n":"ValidateAttributes","d":3182129,"h":94492462641,"f":2},{"r":65537,"p":[{"n":"e","p":1674801}],"n":"ValidateElement","d":3182129,"h":98787429937,"f":2},{"r":65537,"p":[{"n":"e","p":1674801}],"n":"ValidateNodes","d":3182129,"h":103082397233,"f":2},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":25480284}],"n":"ValidationCallback","d":3182129,"h":107377364529,"f":2}],"l":[{"t":31968348,"n":"schemas","d":3182129,"h":4298149425,"f":2},{"t":25545820,"n":"validationEventHandler","d":3182129,"h":8593116721,"f":2},{"t":2592305,"n":"source","d":3182129,"h":12888084017,"f":2},{"t":262145,"n":"addSchemaInfo","d":3182129,"h":17183051313,"f":2},{"t":51891292,"n":"namespaceManager","d":3182129,"h":21478018609,"f":2},{"t":33082460,"n":"validator","d":3182129,"h":25772985905,"f":2},{"t":$.$spc.System.Collections.Generic.HashSet$$($.$spx.System.Xml.Schema.XmlSchemaInfo).$h,"n":"schemaInfos","d":3182129,"h":30067953201,"f":2},{"t":23592961,"n":"defaultAttributes","d":3182129,"h":34362920497,"f":2},{"t":2133553,"n":"xsiTypeName","d":3182129,"h":38657887793,"f":2},{"t":2133553,"n":"xsiNilName","d":3182129,"h":42952855089,"f":2}],"c":[{"p":[{"n":"schemas","p":31968348},{"n":"validationEventHandler","p":25545820}],"n":".ctor","o":"$ctor$1","d":3182129,"h":47247822385,"f":1}],"h":3182129}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Schema.XNodeValidator`; }
        });
        
        $asm.$cls("$spxl.System.Xml.XPath.XPathEvaluator", ($self) => class XPathEvaluator
        {
            static /*object */ Evaluate(T, /*XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                /*XPathNavigator*/ let navigator = $.$spxl.System.Xml.XPath.Extensions.CreateNavigator(node);
                /*object*/ let result = navigator.Evaluate$1(expression, resolver);
                /*XPathNodeIterator?*/ let iterator = $.$as(result, $.$spx.System.Xml.XPath.XPathNodeIterator);
                if (iterator !== null)
                {
                    return $.$spxl.System.Xml.XPath.XPathEvaluator.EvaluateIterator(T, iterator);
                }
                if (!($.$is(result, T)))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedEvaluation, $.$spc.System.Object.GetType.call(result)));
                }
                return $.$box($.$cast(result, T), T);
            }
            static /*IEnumerable<T> */ EvaluateIterator(T, /*XPathNodeIterator*/ result)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = result.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var navigator = $en3.Current;
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(navigator.UnderlyingObject !== null, "navigator.UnderlyingObject != null");
                            /*object*/ let r = navigator.UnderlyingObject;
                            if (!($.$is(r, T)))
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedEvaluation, $.$spc.System.Object.GetType.call(r)));
                            }
                            yield $.$cast(r, T);
                            /*XText?*/ let t = $.$as(r, $.$spxl.System.Xml.Linq.XText);
                            if (t !== null && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(t) !== null)
                            {
                                do
                                {
                                    t = $.$as(t.NextNode, $.$spxl.System.Xml.Linq.XText);
                                    if (t === null)
                                    {
                                        break;
                                    }
                                    yield $.$cast($.$cast(t, $.$spc.System.Object), T);
                                }
                                while(t !== $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(t).LastNode);
                            }
                        }
                    }
                }.bind(this));
            }
            static $h = 3444273;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131073,"p":[{"n":"node","p":2264625},{"n":"expression","p":1310721},{"n":"resolver","p":14011484}],"g":["T"],"n":"Evaluate","d":3444273,"h":4298411569,"f":131105},{"r":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h,"p":[{"n":"result","p":59755612}],"g":["T"],"n":"EvaluateIterator","d":3444273,"h":8593378865,"f":131106}],"h":3444273}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.XPath.XPathEvaluator`; }
        });
        
        $asm.$cls("$spxl.System.Xml.XPath.Extensions", ($self) => class Extensions
        {
            static /*XPathNavigator */ CreateNavigator(/*this XNode*/ node)
            {
                return $.$spxl.System.Xml.XPath.Extensions.CreateNavigator$1(node, null);
            }
            static /*XPathNavigator */ CreateNavigator$1(/*this XNode*/ node, /*XmlNameTable?*/ nameTable)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(node, "node");
                if ($.$is(node, $.$spxl.System.Xml.Linq.XDocumentType))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_CreateNavigator, $.$box(10/*XmlNodeType.DocumentType*/, $.$spx.System.Xml.XmlNodeType)));
                }
                /*XText?*/ let text = $.$as(node, $.$spxl.System.Xml.Linq.XText);
                if (text !== null)
                {
                    if ($.$is($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(text), $.$spxl.System.Xml.Linq.XDocument))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_CreateNavigator, $.$box(13/*XmlNodeType.Whitespace*/, $.$spx.System.Xml.XmlNodeType)));
                    }
                    node = $.$spxl.System.Xml.XPath.Extensions.CalibrateText(text);
                }
                return new $.$spxl.System.Xml.XPath.XNodeNavigator().$ctor$3(node, nameTable);
            }
            static /*object */ XPathEvaluate(/*this XNode*/ node, /*string*/ expression)
            {
                return $.$spxl.System.Xml.XPath.Extensions.XPathEvaluate$1(node, expression, null);
            }
            static /*object */ XPathEvaluate$1(/*this XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(node, "node");
                return $.$spxl.System.Xml.XPath.XPathEvaluator.Evaluate($.$spc.System.Object, node, expression, resolver);
            }
            static /*XElement? */ XPathSelectElement(/*this XNode*/ node, /*string*/ expression)
            {
                return $.$spxl.System.Xml.XPath.Extensions.XPathSelectElement$1(node, expression, null);
            }
            static /*XElement? */ XPathSelectElement$1(/*this XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                return $.$sl.System.Linq.Enumerable.FirstOrDefault($.$spxl.System.Xml.Linq.XElement, $.$spxl.System.Xml.XPath.Extensions.XPathSelectElements$1(node, expression, resolver));
            }
            static /*IEnumerable<XElement> */ XPathSelectElements(/*this XNode*/ node, /*string*/ expression)
            {
                return $.$spxl.System.Xml.XPath.Extensions.XPathSelectElements$1(node, expression, null);
            }
            static /*IEnumerable<XElement> */ XPathSelectElements$1(/*this XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(node, "node");
                return $.$cast($.$spxl.System.Xml.XPath.XPathEvaluator.Evaluate($.$spxl.System.Xml.Linq.XElement, node, expression, resolver), $.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement));
            }
            static /*XText */ CalibrateText(/*XText*/ n)
            {
                /*XContainer?*/ let parentNode = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n);
                if (parentNode === null)
                {
                    return n;
                }
                var $en2 = parentNode.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var node = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*XText?*/ let t = $.$as(node, $.$spxl.System.Xml.Linq.XText);
                        /*bool*/ let isTextNode = t !== null;
                        if (isTextNode && node === n)
                        {
                            return t;
                        }
                    }
                }
                $.$spc.System.Diagnostics.Debug.Fail("Parent node doesn't contain itself.");
                return null;
            }
            static $h = 3247665;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":59296860,"p":[{"n":"node","p":2264625}],"n":"CreateNavigator","d":3247665,"h":4298214961,"f":33},{"r":59296860,"p":[{"n":"node","p":2264625},{"n":"nameTable","p":52087900}],"n":"CreateNavigator","o":"@$1","d":3247665,"h":8593182257,"f":33},{"r":131073,"p":[{"n":"node","p":2264625},{"n":"expression","p":1310721}],"n":"XPathEvaluate","d":3247665,"h":12888149553,"f":33},{"r":131073,"p":[{"n":"node","p":2264625},{"n":"expression","p":1310721},{"n":"resolver","p":14011484}],"n":"XPathEvaluate","o":"@$1","d":3247665,"h":17183116849,"f":33},{"r":1674801,"p":[{"n":"node","p":2264625},{"n":"expression","p":1310721}],"n":"XPathSelectElement","d":3247665,"h":21478084145,"f":33},{"r":1674801,"p":[{"n":"node","p":2264625},{"n":"expression","p":1310721},{"n":"resolver","p":14011484}],"n":"XPathSelectElement","o":"@$1","d":3247665,"h":25773051441,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"node","p":2264625},{"n":"expression","p":1310721}],"n":"XPathSelectElements","d":3247665,"h":30068018737,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"node","p":2264625},{"n":"expression","p":1310721},{"n":"resolver","p":14011484}],"n":"XPathSelectElements","o":"@$1","d":3247665,"h":34362986033,"f":33},{"r":2985521,"p":[{"n":"n","p":2985521}],"n":"CalibrateText","d":3247665,"h":38657953329,"f":34}],"h":3247665}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.XPath.Extensions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.XPath.XObjectExtensions", ($self) => class XObjectExtensions
        {
            static /*XContainer? */ GetParent(/*this XObject*/ obj)
            {
                /*XContainer?*/ let ret = obj.Parent ?? obj.Document;
                if (ret === obj)
                {
                    return null;
                }
                return ret;
            }
            static $h = 3378737;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1347121,"p":[{"n":"obj","p":2592305}],"n":"GetParent","d":3378737,"h":4298346033,"f":33}],"h":3378737}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.XPath.XObjectExtensions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Schema.Extensions", ($self) => class Extensions
        {
            static /*IXmlSchemaInfo? */ GetSchemaInfo(/*this XElement*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.Annotation$1($.$spx.System.Xml.Schema.IXmlSchemaInfo);
            }
            static /*IXmlSchemaInfo? */ GetSchemaInfo$1(/*this XAttribute*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.Annotation$1($.$spx.System.Xml.Schema.IXmlSchemaInfo);
            }
            static /*void */ Validate(/*this XDocument*/ source, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                $.$spxl.System.Xml.Schema.Extensions.Validate$1(source, schemas, validationEventHandler, false);
            }
            static /*void */ Validate$1(/*this XDocument*/ source, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler, /*bool*/ addSchemaInfo)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(schemas, "schemas");
                new $.$spxl.System.Xml.Schema.XNodeValidator().$ctor$1(schemas, validationEventHandler).Validate(source, null, addSchemaInfo);
            }
            static /*void */ Validate$2(/*this XElement*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                $.$spxl.System.Xml.Schema.Extensions.Validate$3(source, partialValidationType, schemas, validationEventHandler, false);
            }
            static /*void */ Validate$3(/*this XElement*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler, /*bool*/ addSchemaInfo)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(partialValidationType, "partialValidationType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(schemas, "schemas");
                new $.$spxl.System.Xml.Schema.XNodeValidator().$ctor$1(schemas, validationEventHandler).Validate(source, partialValidationType, addSchemaInfo);
            }
            static /*void */ Validate$4(/*this XAttribute*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                $.$spxl.System.Xml.Schema.Extensions.Validate$5(source, partialValidationType, schemas, validationEventHandler, false);
            }
            static /*void */ Validate$5(/*this XAttribute*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler, /*bool*/ addSchemaInfo)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(partialValidationType, "partialValidationType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(schemas, "schemas");
                new $.$spxl.System.Xml.Schema.XNodeValidator().$ctor$1(schemas, validationEventHandler).Validate(source, partialValidationType, addSchemaInfo);
            }
            static $h = 3051057;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":21810268,"p":[{"n":"source","p":1674801}],"n":"GetSchemaInfo","d":3051057,"h":4298018353,"f":33},{"r":21810268,"p":[{"n":"source","p":1150513}],"n":"GetSchemaInfo","o":"@$1","d":3051057,"h":8592985649,"f":33},{"r":65537,"p":[{"n":"source","p":1543729},{"n":"schemas","p":31968348},{"n":"validationEventHandler","p":25545820}],"n":"Validate","d":3051057,"h":12887952945,"f":33},{"r":65537,"p":[{"n":"source","p":1543729},{"n":"schemas","p":31968348},{"n":"validationEventHandler","p":25545820},{"n":"addSchemaInfo","p":262145}],"n":"Validate","o":"@$1","d":3051057,"h":17182920241,"f":33},{"r":65537,"p":[{"n":"source","p":1674801},{"n":"partialValidationType","p":30919772},{"n":"schemas","p":31968348},{"n":"validationEventHandler","p":25545820}],"n":"Validate","o":"@$2","d":3051057,"h":21477887537,"f":33},{"r":65537,"p":[{"n":"source","p":1674801},{"n":"partialValidationType","p":30919772},{"n":"schemas","p":31968348},{"n":"validationEventHandler","p":25545820},{"n":"addSchemaInfo","p":262145}],"n":"Validate","o":"@$3","d":3051057,"h":25772854833,"f":33},{"r":65537,"p":[{"n":"source","p":1150513},{"n":"partialValidationType","p":30919772},{"n":"schemas","p":31968348},{"n":"validationEventHandler","p":25545820}],"n":"Validate","o":"@$4","d":3051057,"h":30067822129,"f":33},{"r":65537,"p":[{"n":"source","p":1150513},{"n":"partialValidationType","p":30919772},{"n":"schemas","p":31968348},{"n":"validationEventHandler","p":25545820},{"n":"addSchemaInfo","p":262145}],"n":"Validate","o":"@$5","d":3051057,"h":34362789425,"f":33}],"h":3051057}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Schema.Extensions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XName", ($self) => class XName extends $.$spc.System.Object
        {
            /*XNamespace*/ _ns = null;
            /*string*/ _localName = null;
            /*int*/ _hashCode = 0;
            $ctor$1(/*XNamespace*/ ns, /*string*/ localName)
            {
                super.$ctor();
                {
                    this._ns = ns;
                    this._localName = $.$spx.System.Xml.XmlConvert.VerifyNCName(localName);
                    this._hashCode = $.$spxl.System.Xml.Linq.XNamespace.GetHashCode.call(ns) ^ $.$spc.System.String.GetHashCode.call(localName);
                }
                return this;
            }
            /*string */ get LocalName()
            {
                return this._localName;
            }
            /*XNamespace */ get Namespace()
            {
                return this._ns;
            }
            /*string */ get NamespaceName()
            {
                return this._ns.NamespaceName;
            }
            static/*conventional*/ /*string */ ToString()
            {
                if (this._ns.NamespaceName.length === 0)
                {
                    return this._localName;
                }
                return "{" + this._ns.NamespaceName + "}" + this._localName;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XName.ToString.apply(this, arguments); }
            static /*XName */ Get(/*string*/ expandedName)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(expandedName, "expandedName");
                if ($.$spc.System.String.get_Chars.call(expandedName, 0) === /*{*/ 123)
                {
                    /*int*/ let i = $.$spc.System.String.LastIndexOf.call(expandedName, /*}*/ 125);
                    if (i <= 1 || i === ((expandedName.length - 1) | 0))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_InvalidExpandedName, expandedName));
                    }
                    return $.$spxl.System.Xml.Linq.XNamespace.Get$1(expandedName, 1, ((i - 1) | 0)).GetName$1(expandedName, ((i + 1) | 0), ((((expandedName.length - i) | 0) - 1) | 0));
                }
                else 
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.None.GetName(expandedName);
                }
            }
            static /*XName */ Get$1(/*string*/ localName, /*string*/ namespaceName)
            {
                return $.$spxl.System.Xml.Linq.XNamespace.Get(namespaceName).GetName(localName);
            }
            static /*XName? */ op_Implicit(/*string?*/ expandedName)
            {
                return $.$spc.System.String.op_Inequality(expandedName, null) ? $.$spxl.System.Xml.Linq.XName.Get(expandedName) : null;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return this === obj;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$spxl.System.Xml.Linq.XName.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._hashCode;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$spxl.System.Xml.Linq.XName.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*XName?*/ left, /*XName?*/ right)
            {
                return left === right;
            }
            static /*bool */ op_Inequality(/*XName?*/ left, /*XName?*/ right)
            {
                return left !== right;
            }
            /*bool */ System$IEquatable$$$Equals(/*XName?*/ other)
            {
                return this === other;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2133553;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25771937329,"f":1},"n":"LocalName","d":2133553,"h":21476970033,"f":1},{"p":2199089,"g":{"r":0,"d":0,"h":34361871921,"f":1},"n":"Namespace","d":2133553,"h":30066904625,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42951806513,"f":1},"n":"NamespaceName","d":2133553,"h":38656839217,"f":1}],"m":[{"r":1310721,"n":"ToString","d":2133553,"h":47246773809,"f":32769},{"r":2133553,"p":[{"n":"expandedName","p":1310721}],"n":"Get","d":2133553,"h":51541741105,"f":33},{"r":2133553,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"Get","o":"@$1","d":2133553,"h":55836708401,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2133553,"h":64426642993,"f":32769},{"r":655361,"n":"GetHashCode","d":2133553,"h":68721610289,"f":32769}],"l":[{"t":2199089,"n":"_ns","d":2133553,"h":4297100849,"f":2},{"t":1310721,"n":"_localName","d":2133553,"h":8592068145,"f":2},{"t":655361,"n":"_hashCode","d":2133553,"h":12887035441,"f":2}],"c":[{"p":[{"n":"ns","p":2199089},{"n":"localName","p":1310721}],"n":".ctor","o":"$ctor$1","d":2133553,"h":17182002737,"f":8}],"i":[$.$spc.System.IEquatable$$($.$spxl.System.Xml.Linq.XName).$h,113377281],"h":2133553}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$spxl.System.Xml.Linq.XName), $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Xml.Linq.XName`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNodeDocumentOrderComparer", ($self) => class XNodeDocumentOrderComparer extends $.$spc.System.Object
        {
            /*int */ Compare(/*XNode?*/ x, /*XNode?*/ y)
            {
                return $.$spxl.System.Xml.Linq.XNode.CompareDocumentOrder(x, y);
            }
            /*int */ System$Collections$IComparer$Compare(/*object?*/ x, /*object?*/ y)
            {
                /*XNode?*/ let n1 = $.$as(x, $.$spxl.System.Xml.Linq.XNode);
                if (n1 === null && x !== null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "x");
                }
                /*XNode?*/ let n2 = $.$as(y, $.$spxl.System.Xml.Linq.XNode);
                if (n2 === null && y !== null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "y");
                }
                return this.Compare(n1, n2);
            }
            //Generated interface implemetation for System.Collections.Generic.IComparer<System.Xml.Linq.XNode?>.Compare(System.Xml.Linq.XNode?, System.Xml.Linq.XNode?)
            System$Collections$Generic$IComparer$$$Compare()
            {
                return this.Compare(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2395697;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"x","p":2264625},{"n":"y","p":2264625}],"n":"Compare","d":2395697,"h":4297362993,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":2395697,"h":12887297585,"f":1}],"i":[31391745,$.$spc.System.Collections.Generic.IComparer$$($.$spxl.System.Xml.Linq.XNode).$h],"h":2395697}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IComparer, $.$spc.System.Collections.Generic.IComparer$$($.$spxl.System.Xml.Linq.XNode) ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeDocumentOrderComparer`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNodeEqualityComparer", ($self) => class XNodeEqualityComparer extends $.$spc.System.Object
        {
            /*bool */ Equals$2(/*XNode?*/ x, /*XNode?*/ y)
            {
                return $.$spxl.System.Xml.Linq.XNode.DeepEquals(x, y);
            }
            /*int */ GetHashCode$1(/*XNode*/ obj)
            {
                return obj !== null ? obj.GetDeepHashCode() : 0;
            }
            /*bool */ System$Collections$IEqualityComparer$Equals(/*object?*/ x, /*object?*/ y)
            {
                /*XNode?*/ let n1 = $.$as(x, $.$spxl.System.Xml.Linq.XNode);
                if (n1 === null && x !== null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "x");
                }
                /*XNode?*/ let n2 = $.$as(y, $.$spxl.System.Xml.Linq.XNode);
                if (n2 === null && y !== null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "y");
                }
                return this.Equals$2(n1, n2);
            }
            /*int */ System$Collections$IEqualityComparer$GetHashCode(/*object*/ obj)
            {
                /*XNode?*/ let n = $.$as(obj, $.$spxl.System.Xml.Linq.XNode);
                if (n === null && obj !== null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "obj");
                }
                return this.GetHashCode$1(n);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Linq.XNode>.Equals(System.Xml.Linq.XNode?, System.Xml.Linq.XNode?)
            System$Collections$Generic$IEqualityComparer$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Linq.XNode>.GetHashCode(System.Xml.Linq.XNode)
            System$Collections$Generic$IEqualityComparer$$$GetHashCode()
            {
                return this.GetHashCode$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2461233;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"x","p":2264625},{"n":"y","p":2264625}],"n":"Equals","o":"@$2","d":2461233,"h":4297428529,"f":1},{"r":655361,"p":[{"n":"obj","p":2264625}],"n":"GetHashCode","o":"@$1","d":2461233,"h":8592395825,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":2461233,"h":21477297713,"f":1}],"i":[31784961,$.$spc.System.Collections.Generic.IEqualityComparer$$($.$spxl.System.Xml.Linq.XNode).$h],"h":2461233}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IEqualityComparer, $.$spc.System.Collections.Generic.IEqualityComparer$$($.$spxl.System.Xml.Linq.XNode) ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeEqualityComparer`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.Inserter", ($self) => class Inserter extends $.$spc.System.ValueType
        {
            /*XContainer*/  get _parent() { return this.$getField(0, 4); }
            /*XContainer*/  set _parent(value) { this.$setField(0, 4, value); }
            /*XNode?*/  get _previous() { return this.$getField(4, 4); }
            /*XNode?*/  set _previous(value) { this.$setField(4, 4, value); }
            /*string?*/  get _text() { return this.$getField(8, 4); }
            /*string?*/  set _text(value) { this.$setField(8, 4, value); }
            $ctor$2(/*XContainer*/ parent, /*XNode?*/ anchor)
            {
                super.$ctor$1();
                {
                    this._parent = parent;
                    this._previous = anchor;
                    this._text = null;
                }
                return this;
            }
            /*void */ Add(/*object?*/ content)
            {
                this.AddContent(content);
                if ($.$spc.System.String.op_Inequality(this._text, null))
                {
                    if (this._parent.content === null)
                    {
                        if (this._parent.SkipNotify())
                        {
                            this._parent.content = this._text;
                        }
                        else 
                        {
                            if (this._text.length > 0)
                            {
                                this.InsertNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(this._text));
                            }
                            else 
                            {
                                if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XElement))
                                {
                                    this._parent.NotifyChanging(this._parent, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                                    if (this._parent.content !== null)
                                    {
                                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                                    }
                                    this._parent.content = this._text;
                                    this._parent.NotifyChanged(this._parent, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                                }
                                else 
                                {
                                    this._parent.content = this._text;
                                }
                            }
                        }
                    }
                    else if (this._text.length > 0)
                    {
                        /*XText?*/ let prevXText = $.$as(this._previous, $.$spxl.System.Xml.Linq.XText);
                        if (prevXText !== null && !($.$is(this._previous, $.$spxl.System.Xml.Linq.XCData)))
                        {
                            prevXText.Value += this._text;
                        }
                        else 
                        {
                            this._parent.ConvertTextToNode();
                            this.InsertNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(this._text));
                        }
                    }
                }
            }
            /*void */ AddContent(/*object?*/ content)
            {
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.AddNode(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    this.AddString(s);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$9(x));
                    return;
                }
                /*object?[]?*/ let o = $.$as(content, $.$typeArray($.$spc.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.AddContent(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$spc.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.AddContent(obj);
                        }
                    }
                    return;
                }
                if ($.$is(content, $.$spxl.System.Xml.Linq.XAttribute))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_AddAttribute);
                }
                this.AddString($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            /*void */ AddNode(/*XNode*/ n)
            {
                this._parent.ValidateNode(n, this._previous);
                if (n.parent !== null)
                {
                    n = n.CloneNode();
                }
                else 
                {
                    /*XNode*/ let p = this._parent;
                    while(p.parent !== null)
                    {
                        p = p.parent;
                    }
                    if (n === p)
                    {
                        n = n.CloneNode();
                    }
                }
                this._parent.ConvertTextToNode();
                if ($.$spc.System.String.op_Inequality(this._text, null))
                {
                    if (this._text.length > 0)
                    {
                        /*XText?*/ let prevXText = $.$as(this._previous, $.$spxl.System.Xml.Linq.XText);
                        if (prevXText !== null && !($.$is(this._previous, $.$spxl.System.Xml.Linq.XCData)))
                        {
                            prevXText.Value += this._text;
                        }
                        else 
                        {
                            this.InsertNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(this._text));
                        }
                    }
                    this._text = null;
                }
                this.InsertNode(n);
            }
            /*void */ AddString(/*string*/ s)
            {
                this._parent.ValidateString(s);
                this._text += s;
            }
            /*void */ InsertNode(/*XNode*/ n)
            {
                /*bool*/ let notify = this._parent.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                if (n.parent !== null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                n.parent = this._parent;
                if (this._parent.content === null || $.$is(this._parent.content, $.$spc.System.String))
                {
                    n.next = n;
                    this._parent.content = n;
                }
                else if (this._previous === null)
                {
                    /*XNode*/ let last = $.$cast(this._parent.content, $.$spxl.System.Xml.Linq.XNode);
                    n.next = last.next;
                    last.next = n;
                }
                else 
                {
                    n.next = this._previous.next;
                    this._previous.next = n;
                    if (this._parent.content === this._previous)
                    {
                        this._parent.content = n;
                    }
                }
                this._previous = n;
                if (notify)
                {
                    this._parent.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                }
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._parent = this._parent;
                copy._previous = this._previous;
                copy._text = this._text;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._parent = null;
                this._previous = null;
                this._text = null;
            }
            static $h = 495153;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"content","p":131073}],"n":"Add","d":495153,"h":21475331633,"f":1},{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddContent","d":495153,"h":25770298929,"f":2},{"r":65537,"p":[{"n":"n","p":2264625}],"n":"AddNode","d":495153,"h":30065266225,"f":2},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AddString","d":495153,"h":34360233521,"f":2},{"r":65537,"p":[{"n":"n","p":2264625}],"n":"InsertNode","d":495153,"h":38655200817,"f":2}],"l":[{"t":1347121,"n":"_parent","d":495153,"h":4295462449,"f":2},{"t":2264625,"n":"_previous","d":495153,"h":8590429745,"f":2},{"t":1310721,"n":"_text","d":495153,"h":12885397041,"f":2}],"c":[{"p":[{"n":"parent","p":1347121},{"n":"anchor","p":2264625}],"n":".ctor","o":"$ctor$2","d":495153,"h":17180364337,"f":1},{"n":".ctor","o":"$ctor$3","d":495153,"h":42950168113,"f":1}],"h":495153}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.Inserter`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.NamespaceCache", ($self) => class NamespaceCache extends $.$spc.System.ValueType
        {
            /*XNamespace*/  get _ns() { return this.$getField(0, 4); }
            /*XNamespace*/  set _ns(value) { this.$setField(0, 4, value); }
            /*string*/  get _namespaceName() { return this.$getField(4, 4); }
            /*string*/  set _namespaceName(value) { this.$setField(4, 4, value); }
            /*XNamespace */ Get(/*string*/ namespaceName)
            {
                if (namespaceName === this._namespaceName)
                {
                    return this._ns;
                }
                this._namespaceName = namespaceName;
                this._ns = $.$spxl.System.Xml.Linq.XNamespace.Get(namespaceName);
                return this._ns;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._ns = this._ns;
                copy._namespaceName = this._namespaceName;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._ns = null;
                this._namespaceName = null;
            }
            static $h = 757297;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":2199089,"p":[{"n":"namespaceName","p":1310721}],"n":"Get","d":757297,"h":12885659185,"f":1}],"l":[{"t":2199089,"n":"_ns","d":757297,"h":4295724593,"f":2},{"t":1310721,"n":"_namespaceName","d":757297,"h":8590691889,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":757297,"h":17180626481,"f":1}],"h":757297}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.NamespaceCache`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.ElementWriter", ($self) => class ElementWriter extends $.$spc.System.ValueType
        {
            /*XmlWriter*/  get _writer() { return this.$getField(0, 4); }
            /*XmlWriter*/  set _writer(value) { this.$setField(0, 4, value); }
            /*NamespaceResolver*/  get _resolver() { return this.$getField(4, 12); }
            /*NamespaceResolver*/  set _resolver(value) { this.$setField(4, 12, value); }
            $ctor$2(/*XmlWriter*/ writer)
            {
                super.$ctor$1();
                {
                    this._writer = writer;
                    this._resolver = new $.$spxl.System.Xml.Linq.NamespaceResolver();
                }
                return this;
            }
            /*void */ WriteElement(/*XElement*/ e)
            {
                this.PushAncestors(e);
                /*XElement*/ let root = e;
                /*XNode*/ let n = e;
                while(true)
                {
                    /*XElement?*/ let current = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                    if (current !== null)
                    {
                        this.WriteStartElement(current);
                        if (current.content === null)
                        {
                            this.WriteEndElement();
                        }
                        else 
                        {
                            /*string?*/ let s = $.$as(current.content, $.$spc.System.String);
                            if ($.$spc.System.String.op_Inequality(s, null))
                            {
                                this._writer.WriteString(s);
                                this.WriteFullEndElement();
                            }
                            else 
                            {
                                n = ($.$cast(current.content, $.$spxl.System.Xml.Linq.XNode)).next;
                                continue;
                            }
                        }
                    }
                    else 
                    {
                        n.WriteTo(this._writer);
                    }
                    while(n !== root && n === n.parent.content)
                    {
                        n = n.parent;
                        this.WriteFullEndElement();
                    }
                    if (n === root)
                    {
                        break;
                    }
                    n = n.next;
                }
            }
            /*Task *//*async*/  WriteElementAsync(/*XElement*/ e, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.PushAncestors(e);
                    /*XElement*/ let root = e;
                    /*XNode*/ let n = e;
                    while(true)
                    {
                        /*XElement?*/ let current = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (current !== null)
                        {
                            await this.WriteStartElementAsync(current, cancellationToken).ConfigureAwait(false);
                            if (current.content === null)
                            {
                                await this.WriteEndElementAsync(cancellationToken).ConfigureAwait(false);
                            }
                            else 
                            {
                                /*string?*/ let s = $.$as(current.content, $.$spc.System.String);
                                if ($.$spc.System.String.op_Inequality(s, null))
                                {
                                    cancellationToken.ThrowIfCancellationRequested();
                                    await this._writer.WriteStringAsync(s).ConfigureAwait(false);
                                    await this.WriteFullEndElementAsync(cancellationToken).ConfigureAwait(false);
                                }
                                else 
                                {
                                    n = ($.$cast(current.content, $.$spxl.System.Xml.Linq.XNode)).next;
                                    continue;
                                }
                            }
                        }
                        else 
                        {
                            await n.WriteToAsync(this._writer, cancellationToken).ConfigureAwait(false);
                        }
                        while(n !== root && n === n.parent.content)
                        {
                            n = n.parent;
                            await this.WriteFullEndElementAsync(cancellationToken).ConfigureAwait(false);
                        }
                        if (n === root)
                        {
                            break;
                        }
                        n = n.next;
                    }
                });
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns, /*bool*/ allowDefaultNamespace)
            {
                /*string*/ let namespaceName = ns.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$spc.System.String.Empty;
                }
                /*string?*/ let prefix = this._resolver.GetPrefixOfNamespace(ns, allowDefaultNamespace);
                if ($.$spc.System.String.op_Inequality(prefix, null))
                {
                    return prefix;
                }
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    return "xml";
                }
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            /*void */ PushAncestors(/*XElement?*/ e)
            {
                while(true)
                {
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    if (e === null)
                    {
                        break;
                    }
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration)
                            {
                                this._resolver.AddFirst(a.Name.NamespaceName.length === 0 ? $.$spc.System.String.Empty : a.Name.LocalName, $.$spxl.System.Xml.Linq.XNamespace.Get(a.Value));
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
            }
            /*void */ PushElement(/*XElement*/ e)
            {
                this._resolver.PushScope();
                /*XAttribute?*/ let a = e.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if (a.IsNamespaceDeclaration)
                        {
                            this._resolver.Add(a.Name.NamespaceName.length === 0 ? $.$spc.System.String.Empty : a.Name.LocalName, $.$spxl.System.Xml.Linq.XNamespace.Get(a.Value));
                        }
                    }
                    while(a !== e.lastAttr);
                }
            }
            /*void */ WriteEndElement()
            {
                this._writer.WriteEndElement();
                this._resolver.PopScope();
            }
            /*Task *//*async*/  WriteEndElementAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await this._writer.WriteEndElementAsync().ConfigureAwait(false);
                    this._resolver.PopScope();
                });
            }
            /*void */ WriteFullEndElement()
            {
                this._writer.WriteFullEndElement();
                this._resolver.PopScope();
            }
            /*Task *//*async*/  WriteFullEndElementAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await this._writer.WriteFullEndElementAsync().ConfigureAwait(false);
                    this._resolver.PopScope();
                });
            }
            /*void */ WriteStartElement(/*XElement*/ e)
            {
                this.PushElement(e);
                /*XNamespace*/ let ns = e.Name.Namespace;
                this._writer.WriteStartElement$1(this.GetPrefixOfNamespace(ns, true), e.Name.LocalName, ns.NamespaceName);
                /*XAttribute?*/ let a = e.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        ns = a.Name.Namespace;
                        /*string*/ let localName = a.Name.LocalName;
                        /*string*/ let namespaceName = ns.NamespaceName;
                        this._writer.WriteAttributeString$2(this.GetPrefixOfNamespace(ns, false), localName, namespaceName.length === 0 && $.$spc.System.String.op_Equality(localName, "xmlns") ? "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/ : namespaceName, a.Value);
                    }
                    while(a !== e.lastAttr);
                }
            }
            /*Task *//*async*/  WriteStartElementAsync(/*XElement*/ e, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.PushElement(e);
                    /*XNamespace*/ let ns = e.Name.Namespace;
                    await this._writer.WriteStartElementAsync(this.GetPrefixOfNamespace(ns, true), e.Name.LocalName, ns.NamespaceName).ConfigureAwait(false);
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            ns = a.Name.Namespace;
                            /*string*/ let localName = a.Name.LocalName;
                            /*string*/ let namespaceName = ns.NamespaceName;
                            cancellationToken.ThrowIfCancellationRequested();
                            await this._writer.WriteAttributeStringAsync(this.GetPrefixOfNamespace(ns, false), localName, namespaceName.length === 0 && $.$spc.System.String.op_Equality(localName, "xmlns") ? "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/ : namespaceName, a.Value).ConfigureAwait(false);
                        }
                        while(a !== e.lastAttr);
                    }
                });
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._writer = this._writer;
                copy._resolver = this._resolver.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._writer = null;
                this._resolver = $.$default($.$spxl.System.Xml.Linq.NamespaceResolver);
            }
            static $h = 364081;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"e","p":1674801}],"n":"WriteElement","d":364081,"h":17180233265,"f":1},{"r":133300225,"p":[{"n":"e","p":1674801},{"n":"cancellationToken","p":125960193}],"n":"WriteElementAsync","d":364081,"h":21475200561,"f":4097},{"r":1310721,"p":[{"n":"ns","p":2199089},{"n":"allowDefaultNamespace","p":262145}],"n":"GetPrefixOfNamespace","d":364081,"h":25770167857,"f":2},{"r":65537,"p":[{"n":"e","p":1674801}],"n":"PushAncestors","d":364081,"h":30065135153,"f":2},{"r":65537,"p":[{"n":"e","p":1674801}],"n":"PushElement","d":364081,"h":34360102449,"f":2},{"r":65537,"n":"WriteEndElement","d":364081,"h":38655069745,"f":2},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"WriteEndElementAsync","d":364081,"h":42950037041,"f":4098},{"r":65537,"n":"WriteFullEndElement","d":364081,"h":47245004337,"f":2},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"WriteFullEndElementAsync","d":364081,"h":51539971633,"f":4098},{"r":65537,"p":[{"n":"e","p":1674801}],"n":"WriteStartElement","d":364081,"h":55834938929,"f":2},{"r":133300225,"p":[{"n":"e","p":1674801},{"n":"cancellationToken","p":125960193}],"n":"WriteStartElementAsync","d":364081,"h":60129906225,"f":4098}],"l":[{"t":58444892,"n":"_writer","d":364081,"h":4295331377,"f":2},{"t":822833,"n":"_resolver","d":364081,"h":8590298673,"f":2}],"c":[{"p":[{"n":"writer","p":58444892}],"n":".ctor","o":"$ctor$2","d":364081,"h":12885265969,"f":1},{"n":".ctor","o":"$ctor$3","d":364081,"h":64424873521,"f":1}],"h":364081}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.ElementWriter`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.NamespaceResolver", ($self) => class NamespaceResolver extends $.$spc.System.ValueType
        {
            static $_NamespaceDeclaration;
            static get NamespaceDeclaration()
            {
                let $cls = $.$spxl.System.Xml.Linq.NamespaceResolver;
                return $cls.$_NamespaceDeclaration ??= $asm.$ncls("$spxl.System.Xml.Linq.NamespaceResolver.NamespaceDeclaration", ($self) => class NamespaceDeclaration extends $.$spc.System.Object
                {
                    /*string*/ prefix = null;
                    /*XNamespace*/ ns = null;
                    /*int*/ scope = 0;
                    /*NamespaceDeclaration*/ prev = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.prefix = null;
                        this.ns = null;
                        this.prev = null;
                    }
                    static $h = 888369;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"prefix","d":888369,"h":4295855665,"f":1},{"t":2199089,"n":"ns","d":888369,"h":8590822961,"f":1},{"t":655361,"n":"scope","d":888369,"h":12885790257,"f":1},{"t":888369,"n":"prev","d":888369,"h":17180757553,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":888369,"h":21475724849,"f":1}],"d":822833,"h":888369}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Xml.Linq.NamespaceResolver.NamespaceDeclaration`; }
                }, $cls, ($v) => $cls.$_NamespaceDeclaration = $v);
            }
            /*int*/  get _scope() { return this.$getField(0, 4); }
            /*int*/  set _scope(value) { this.$setField(0, 4, value); }
            /*NamespaceDeclaration?*/  get _declaration() { return this.$getField(4, 4); }
            /*NamespaceDeclaration?*/  set _declaration(value) { this.$setField(4, 4, value); }
            /*NamespaceDeclaration?*/  get _rover() { return this.$getField(8, 4); }
            /*NamespaceDeclaration?*/  set _rover(value) { this.$setField(8, 4, value); }
            /*void */ PushScope()
            {
                this._scope++;
            }
            /*void */ PopScope()
            {
                /*NamespaceDeclaration?*/ let d = this._declaration;
                if (d !== null)
                {
                    do
                    {
                        d = d.prev;
                        if (d.scope !== this._scope)
                        {
                            break;
                        }
                        if (d === this._declaration)
                        {
                            this._declaration = null;
                        }
                        else 
                        {
                            this._declaration.prev = d.prev;
                        }
                        this._rover = null;
                    }
                    while(d !== this._declaration && this._declaration !== null);
                }
                this._scope--;
            }
            /*void */ Add(/*string*/ prefix, /*XNamespace*/ ns)
            {
                /*NamespaceDeclaration*/ let d = new $.$spxl.System.Xml.Linq.NamespaceResolver.NamespaceDeclaration().$ctor$1();
                d.prefix = prefix;
                d.ns = ns;
                d.scope = this._scope;
                if (this._declaration === null)
                {
                    this._declaration = d;
                }
                else 
                {
                    d.prev = this._declaration.prev;
                }
                this._declaration.prev = d;
                this._rover = null;
            }
            /*void */ AddFirst(/*string*/ prefix, /*XNamespace*/ ns)
            {
                /*NamespaceDeclaration*/ let d = new $.$spxl.System.Xml.Linq.NamespaceResolver.NamespaceDeclaration().$ctor$1();
                d.prefix = prefix;
                d.ns = ns;
                d.scope = this._scope;
                if (this._declaration === null)
                {
                    d.prev = d;
                }
                else 
                {
                    d.prev = this._declaration.prev;
                    this._declaration.prev = d;
                }
                this._declaration = d;
                this._rover = null;
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns, /*bool*/ allowDefaultNamespace)
            {
                if (this._rover !== null && $.$spxl.System.Xml.Linq.XNamespace.op_Equality(this._rover.ns, ns) && (allowDefaultNamespace || this._rover.prefix.length > 0))
                {
                    return this._rover.prefix;
                }
                /*NamespaceDeclaration?*/ let d = this._declaration;
                if (d !== null)
                {
                    do
                    {
                        d = d.prev;
                        if ($.$spxl.System.Xml.Linq.XNamespace.op_Equality(d.ns, ns))
                        {
                            /*NamespaceDeclaration*/ let x = this._declaration.prev;
                            while(x !== d && $.$spc.System.String.op_Inequality(x.prefix, d.prefix))
                            {
                                x = x.prev;
                            }
                            if (x === d)
                            {
                                if (allowDefaultNamespace)
                                {
                                    this._rover = d;
                                    return d.prefix;
                                }
                                else if (d.prefix.length > 0)
                                {
                                    return d.prefix;
                                }
                            }
                        }
                    }
                    while(d !== this._declaration);
                }
                return null;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._scope = this._scope;
                copy._declaration = this._declaration;
                copy._rover = this._rover;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._scope = 0;
                this._declaration = null;
                this._rover = null;
            }
            static $h = 822833;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"n":"PushScope","d":822833,"h":21475659313,"f":1},{"r":65537,"n":"PopScope","d":822833,"h":25770626609,"f":1},{"r":65537,"p":[{"n":"prefix","p":1310721},{"n":"ns","p":2199089}],"n":"Add","d":822833,"h":30065593905,"f":1},{"r":65537,"p":[{"n":"prefix","p":1310721},{"n":"ns","p":2199089}],"n":"AddFirst","d":822833,"h":34360561201,"f":1},{"r":1310721,"p":[{"n":"ns","p":2199089},{"n":"allowDefaultNamespace","p":262145}],"n":"GetPrefixOfNamespace","d":822833,"h":38655528497,"f":1}],"l":[{"t":655361,"n":"_scope","d":822833,"h":8590757425,"f":2},{"t":888369,"n":"_declaration","d":822833,"h":12885724721,"f":2},{"t":888369,"n":"_rover","d":822833,"h":17180692017,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":822833,"h":42950495793,"f":1}],"j":[888369],"h":822833}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.NamespaceResolver`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.StreamingElementWriter", ($self) => class StreamingElementWriter extends $.$spc.System.ValueType
        {
            /*XmlWriter*/  get _writer() { return this.$getField(0, 4); }
            /*XmlWriter*/  set _writer(value) { this.$setField(0, 4, value); }
            /*XStreamingElement?*/  get _element() { return this.$getField(4, 4); }
            /*XStreamingElement?*/  set _element(value) { this.$setField(4, 4, value); }
            /*List<XAttribute>*/  get _attributes() { return this.$getField(8, 4); }
            /*List<XAttribute>*/  set _attributes(value) { this.$setField(8, 4, value); }
            /*NamespaceResolver*/  get _resolver() { return this.$getField(12, 12); }
            /*NamespaceResolver*/  set _resolver(value) { this.$setField(12, 12, value); }
            $ctor$2(/*XmlWriter*/ w)
            {
                super.$ctor$1();
                {
                    this._writer = w;
                    this._element = null;
                    this._attributes = new ($.$spc.System.Collections.Generic.List$$($.$spxl.System.Xml.Linq.XAttribute))().$ctor$1();
                    this._resolver = new $.$spxl.System.Xml.Linq.NamespaceResolver();
                }
                return this;
            }
            /*void */ FlushElement()
            {
                if (this._element !== null)
                {
                    this.PushElement();
                    /*XNamespace*/ let ns = this._element.Name.Namespace;
                    this._writer.WriteStartElement$1(this.GetPrefixOfNamespace(ns, true), this._element.Name.LocalName, ns.NamespaceName);
                    var $en3 = this._attributes.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var a = $en3.Current;
                        {
                            ns = a.Name.Namespace;
                            /*string*/ let localName = a.Name.LocalName;
                            /*string*/ let namespaceName = ns.NamespaceName;
                            this._writer.WriteAttributeString$2(this.GetPrefixOfNamespace(ns, false), localName, namespaceName.length === 0 && $.$spc.System.String.op_Equality(localName, "xmlns") ? "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/ : namespaceName, a.Value);
                        }
                    }
                    this._element = null;
                    this._attributes.Clear();
                }
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns, /*bool*/ allowDefaultNamespace)
            {
                /*string*/ let namespaceName = ns.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$spc.System.String.Empty;
                }
                /*string?*/ let prefix = this._resolver.GetPrefixOfNamespace(ns, allowDefaultNamespace);
                if ($.$spc.System.String.op_Inequality(prefix, null))
                {
                    return prefix;
                }
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    return "xml";
                }
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            /*void */ PushElement()
            {
                this._resolver.PushScope();
                var $en2 = this._attributes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var a = $en2.Current;
                    {
                        if (a.IsNamespaceDeclaration)
                        {
                            this._resolver.Add(a.Name.NamespaceName.length === 0 ? $.$spc.System.String.Empty : a.Name.LocalName, $.$spxl.System.Xml.Linq.XNamespace.Get(a.Value));
                        }
                    }
                }
            }
            /*void */ Write(/*object?*/ content)
            {
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.WriteNode(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    this.WriteString(s);
                    return;
                }
                /*XAttribute?*/ let a = $.$as(content, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    this.WriteAttribute(a);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.WriteStreamingElement(x);
                    return;
                }
                /*object[]?*/ let o = $.$as(content, $.$typeArray($.$spc.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.Write(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$spc.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.Write(obj);
                        }
                    }
                    return;
                }
                this.WriteString($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            /*void */ WriteAttribute(/*XAttribute*/ a)
            {
                if (this._element === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_WriteAttribute);
                }
                this._attributes.Add(a);
            }
            /*void */ WriteNode(/*XNode*/ n)
            {
                this.FlushElement();
                n.WriteTo(this._writer);
            }
            /*void */ WriteStreamingElement(/*XStreamingElement*/ e)
            {
                this.FlushElement();
                this._element = e;
                this.Write(e.content);
                this.FlushElement();
                this._writer.WriteEndElement();
                this._resolver.PopScope();
            }
            /*void */ WriteString(/*string*/ s)
            {
                this.FlushElement();
                this._writer.WriteString(s);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._writer = this._writer;
                copy._element = this._element;
                copy._attributes = this._attributes;
                copy._resolver = this._resolver.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._writer = null;
                this._element = null;
                this._attributes = null;
                this._resolver = $.$default($.$spxl.System.Xml.Linq.NamespaceResolver);
            }
            static $h = 1084977;
            static $z = 24;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"n":"FlushElement","d":1084977,"h":25770888753,"f":2},{"r":1310721,"p":[{"n":"ns","p":2199089},{"n":"allowDefaultNamespace","p":262145}],"n":"GetPrefixOfNamespace","d":1084977,"h":30065856049,"f":2},{"r":65537,"n":"PushElement","d":1084977,"h":34360823345,"f":2},{"r":65537,"p":[{"n":"content","p":131073}],"n":"Write","d":1084977,"h":38655790641,"f":2},{"r":65537,"p":[{"n":"a","p":1150513}],"n":"WriteAttribute","d":1084977,"h":42950757937,"f":2},{"r":65537,"p":[{"n":"n","p":2264625}],"n":"WriteNode","d":1084977,"h":47245725233,"f":2},{"r":65537,"p":[{"n":"e","p":2919985}],"n":"WriteStreamingElement","d":1084977,"h":51540692529,"f":8},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"WriteString","d":1084977,"h":55835659825,"f":2}],"l":[{"t":58444892,"n":"_writer","d":1084977,"h":4296052273,"f":2},{"t":2919985,"n":"_element","d":1084977,"h":8591019569,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spxl.System.Xml.Linq.XAttribute).$h,"n":"_attributes","d":1084977,"h":12885986865,"f":2},{"t":822833,"n":"_resolver","d":1084977,"h":17180954161,"f":2}],"c":[{"p":[{"n":"w","p":58444892}],"n":".ctor","o":"$ctor$2","d":1084977,"h":21475921457,"f":1},{"n":".ctor","o":"$ctor$3","d":1084977,"h":60130627121,"f":1}],"h":1084977}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.StreamingElementWriter`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XAttribute", ($self) => class XAttribute extends $.$spxl.System.Xml.Linq.XObject
        {
            static /*IEnumerable<XAttribute> */ get EmptySequence()
            {
                return $.$spc.System.Array.Empty($.$spxl.System.Xml.Linq.XAttribute);
            }
            /*XAttribute?*/ next = null;
            /*XName*/ name = null;
            /*string*/ value = null;
            $ctor$2(/*XName*/ name, /*object*/ value)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                    /*string*/ let s = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
                    $.$spxl.System.Xml.Linq.XAttribute.ValidateAttribute(name, s);
                    this.name = name;
                    this.value = s;
                }
                return this;
            }
            $ctor$3(/*XAttribute*/ other)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this.name = other.name;
                    this.value = other.value;
                }
                return this;
            }
            /*bool */ get IsNamespaceDeclaration()
            {
                /*string*/ let namespaceName = this.name.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$spc.System.String.op_Equality(this.name.LocalName, "xmlns");
                }
                return namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/;
            }
            /*XName */ get Name()
            {
                return this.name;
            }
            /*XAttribute? */ get NextAttribute()
            {
                return this.parent !== null && ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr !== this ? this.next : null;
            }
            /*XmlNodeType */ get NodeType()
            {
                return 2/*XmlNodeType.Attribute*/;
            }
            /*XAttribute? */ get PreviousAttribute()
            {
                if (this.parent === null)
                {
                    return null;
                }
                /*XAttribute*/ let a = ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr;
                while(a.next !== this)
                {
                    a = a.next;
                }
                return a !== ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr ? a : null;
            }
            /*string */ get Value()
            {
                return this.value;
            }
            /*string */ set Value(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                $.$spxl.System.Xml.Linq.XAttribute.ValidateAttribute(this.name, value);
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.value = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*void */ Remove()
            {
                if (this.parent === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).RemoveAttribute(this);
            }
            /*void */ SetValue(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                this.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
            }
            static/*conventional*/ /*string */ ToString()
            {
                let sw = null;
                try
                {
                    sw = new $.$spc.System.IO.StringWriter().$ctor$5($.$spc.System.Globalization.CultureInfo.InvariantCulture);
                    /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                    ws.ConformanceLevel = 1/*ConformanceLevel.Fragment*/;
                    let w = null;
                    try
                    {
                        w = $.$spx.System.Xml.XmlWriter.Create$5(sw, ws);
                        w.WriteAttributeString$2(this.GetPrefixOfNamespace(this.name.Namespace), this.name.LocalName, this.name.NamespaceName, this.value);
                    }
                    finally
                    {
                        w?.System$IDisposable$Dispose();
                    }
                    return $.$spc.System.String.Trim.call($.$spc.System.IO.StringWriter.ToString.call(sw));
                }
                finally
                {
                    sw?.System$IDisposable$Dispose();
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XAttribute.ToString.apply(this, arguments); }
            static /*string? */ op_Explicit(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return attribute.value;
            }
            static /*bool */ op_Explicit$1(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$spc.System.String.ToLowerInvariant.call(attribute.value));
            }
            static /*bool? */ op_Explicit$2(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$spc.System.String.ToLowerInvariant.call(attribute.value));
            }
            static /*int */ op_Explicit$3(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToInt32(attribute.value);
            }
            static /*int? */ op_Explicit$4(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt32(attribute.value);
            }
            static /*uint */ op_Explicit$5(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToUInt32(attribute.value);
            }
            static /*uint? */ op_Explicit$6(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt32(attribute.value);
            }
            static /*long */ op_Explicit$7(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToInt64(attribute.value);
            }
            static /*long? */ op_Explicit$8(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt64(attribute.value);
            }
            static /*ulong */ op_Explicit$9(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToUInt64(attribute.value);
            }
            static /*ulong? */ op_Explicit$10(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt64(attribute.value);
            }
            static /*float */ op_Explicit$11(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToSingle(attribute.value);
            }
            static /*float? */ op_Explicit$12(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToSingle(attribute.value);
            }
            static /*double */ op_Explicit$13(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToDouble(attribute.value);
            }
            static /*double? */ op_Explicit$14(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDouble(attribute.value);
            }
            static /*decimal */ op_Explicit$15(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToDecimal(attribute.value);
            }
            static /*decimal? */ op_Explicit$16(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDecimal(attribute.value);
            }
            static /*DateTime */ op_Explicit$17(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spc.System.DateTime.Parse$2(attribute.value, $.$spc.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            static /*DateTime? */ op_Explicit$18(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spc.System.DateTime.Parse$2(attribute.value, $.$spc.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            static /*DateTimeOffset */ op_Explicit$19(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset(attribute.value);
            }
            static /*DateTimeOffset? */ op_Explicit$20(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset(attribute.value);
            }
            static /*TimeSpan */ op_Explicit$21(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(attribute.value);
            }
            static /*TimeSpan? */ op_Explicit$22(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(attribute.value);
            }
            static /*Guid */ op_Explicit$23(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToGuid(attribute.value);
            }
            static /*Guid? */ op_Explicit$24(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToGuid(attribute.value);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$spxl.System.Xml.Linq.XName.GetHashCode.call(this.name) ^ $.$spc.System.String.GetHashCode.call(this.value);
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns)
            {
                /*string*/ let namespaceName = ns.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$spc.System.String.Empty;
                }
                if (this.parent !== null)
                {
                    return ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).GetPrefixOfNamespace(ns);
                }
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    return "xml";
                }
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            static /*void */ ValidateAttribute(/*XName*/ name, /*string*/ value)
            {
                /*string*/ let namespaceName = name.NamespaceName;
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    if (value.length === 0)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_NamespaceDeclarationPrefixed, name.LocalName));
                    }
                    else if ($.$spc.System.String.op_Equality(value, "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/))
                    {
                        if ($.$spc.System.String.op_Inequality(name.LocalName, "xml"))
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_NamespaceDeclarationXml);
                        }
                    }
                    else if ($.$spc.System.String.op_Equality(value, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_NamespaceDeclarationXmlns);
                    }
                    else 
                    {
                        /*string*/ let localName = name.LocalName;
                        if ($.$spc.System.String.op_Equality(localName, "xml"))
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_NamespaceDeclarationXml);
                        }
                        else if ($.$spc.System.String.op_Equality(localName, "xmlns"))
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_NamespaceDeclarationXmlns);
                        }
                    }
                }
                else if (namespaceName.length === 0 && $.$spc.System.String.op_Equality(name.LocalName, "xmlns"))
                {
                    if ($.$spc.System.String.op_Equality(value, "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_NamespaceDeclarationXml);
                    }
                    else if ($.$spc.System.String.op_Equality(value, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_NamespaceDeclarationXmlns);
                    }
                }
            }
            static $h = 1150513;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2592305,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"g":{"r":0,"d":0,"h":8591085105,"f":33},"n":"EmptySequence","d":1150513,"h":4296117809,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":38655856177,"f":1},"n":"IsNamespaceDeclaration","d":1150513,"h":34360888881,"f":1},{"p":2133553,"g":{"r":0,"d":0,"h":47245790769,"f":1},"n":"Name","d":1150513,"h":42950823473,"f":1},{"p":1150513,"g":{"r":0,"d":0,"h":55835725361,"f":1},"n":"NextAttribute","d":1150513,"h":51540758065,"f":1},{"p":52874332,"g":{"r":0,"d":0,"h":64425659953,"f":32769},"n":"NodeType","d":1150513,"h":60130692657,"f":32769},{"p":1150513,"g":{"r":0,"d":0,"h":73015594545,"f":1},"n":"PreviousAttribute","d":1150513,"h":68720627249,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81605529137,"f":1},"s":{"r":0,"d":0,"h":85900496433,"f":1},"n":"Value","d":1150513,"h":77310561841,"f":1}],"m":[{"r":65537,"n":"Remove","d":1150513,"h":90195463729,"f":1},{"r":65537,"p":[{"n":"value","p":131073}],"n":"SetValue","d":1150513,"h":94490431025,"f":1},{"r":1310721,"n":"ToString","d":1150513,"h":98785398321,"f":32769},{"r":655361,"n":"GetDeepHashCode","d":1150513,"h":210454548017,"f":8},{"r":1310721,"p":[{"n":"ns","p":2199089}],"n":"GetPrefixOfNamespace","d":1150513,"h":214749515313,"f":8},{"r":65537,"p":[{"n":"name","p":2133553},{"n":"value","p":1310721}],"n":"ValidateAttribute","d":1150513,"h":219044482609,"f":34}],"l":[{"t":1150513,"n":"next","d":1150513,"h":12886052401,"f":8},{"t":2133553,"n":"name","d":1150513,"h":17181019697,"f":8},{"t":1310721,"n":"value","d":1150513,"h":21475986993,"f":8}],"c":[{"p":[{"n":"name","p":2133553},{"n":"value","p":131073}],"n":".ctor","o":"$ctor$2","d":1150513,"h":25770954289,"f":1},{"p":[{"n":"other","p":1150513}],"n":".ctor","o":"$ctor$3","d":1150513,"h":30065921585,"f":1}],"i":[13945948],"h":1150513,"a":[{"t":1543279,"c":4296510575,"a":[{"v":"MS.Internal.Xml.Linq.ComponentModel.XTypeDescriptionProvider\u00601[[System.Xml.Linq.XAttribute, System.Xml.Linq, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]],System.ComponentModel.TypeConverter","t":1310721}]}]}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XObject; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XAttribute`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNodeBuilder", ($self) => class XNodeBuilder extends $.$spx.System.Xml.XmlWriter
        {
            /*List<object>?*/ _content = null;
            /*XContainer?*/ _parent = null;
            /*XName?*/ _attrName = null;
            /*string?*/ _attrValue = null;
            /*XContainer*/ _root = null;
            $ctor$2(/*XContainer*/ container)
            {
                super.$ctor$1();
                {
                    this._root = container;
                }
                return this;
            }
            /*XmlWriterSettings */ get Settings()
            {
                /*XmlWriterSettings*/ let settings = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                settings.ConformanceLevel = 0/*ConformanceLevel.Auto*/;
                return settings;
            }
            /*WriteState */ get WriteState()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing)
                {
                    this.Close();
                }
            }
            /*void */ Close()
            {
                this._root.Add(this._content);
            }
            /*void */ Flush()
            {
            }
            /*string */ LookupPrefix(/*string*/ namespaceName)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ WriteBase64(/*byte[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$spxl.System.SR.NotSupported_WriteBase64);
            }
            /*void */ WriteCData(/*string?*/ text)
            {
                this.AddNode(new $.$spxl.System.Xml.Linq.XCData().$ctor$6(text));
            }
            /*void */ WriteCharEntity(/*char*/ ch)
            {
                this.AddString($.$spc.System.Char.ToString$2(ch));
            }
            /*void */ WriteChars(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                this.AddString($.$spc.System.String.Create$1(buffer, index, count));
            }
            /*void */ WriteComment(/*string?*/ text)
            {
                this.AddNode(new $.$spxl.System.Xml.Linq.XComment().$ctor$3(text));
            }
            /*void */ WriteDocType(/*string*/ name, /*string?*/ pubid, /*string?*/ sysid, /*string?*/ subset)
            {
                this.AddNode(new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(name, pubid, sysid, subset));
            }
            /*void */ WriteEndAttribute()
            {
                /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(this._attrName, this._attrValue);
                this._attrName = null;
                this._attrValue = null;
                if (this._parent !== null)
                {
                    this._parent.Add(a);
                }
                else 
                {
                    this.Add(a);
                }
            }
            /*void */ WriteEndDocument()
            {
            }
            /*void */ WriteEndElement()
            {
                this._parent = ($.$cast(this._parent, $.$spxl.System.Xml.Linq.XElement)).parent;
            }
            /*void */ WriteEntityRef(/*string*/ name)
            {
                switch(name)
                {
                    case "amp":
                    this.AddString("&");
                    break;
                    case "apos":
                    this.AddString("'");
                    break;
                    case "gt":
                    this.AddString(">");
                    break;
                    case "lt":
                    this.AddString("<");
                    break;
                    case "quot":
                    this.AddString("\"");
                    break;
                    default:
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$spxl.System.SR.NotSupported_WriteEntityRef);
                }
            }
            /*void */ WriteFullEndElement()
            {
                /*XElement*/ let e = $.$cast(this._parent, $.$spxl.System.Xml.Linq.XElement);
                if (e.IsEmpty)
                {
                    e.Add($.$spc.System.String.Empty);
                }
                this._parent = e.parent;
            }
            /*void */ WriteProcessingInstruction(/*string*/ name, /*string?*/ text)
            {
                if ($.$spc.System.String.op_Equality(name, "xml"))
                {
                    return;
                }
                this.AddNode(new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(name, text));
            }
            /*void */ WriteRaw(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                this.AddString($.$spc.System.String.Create$1(buffer, index, count));
            }
            /*void */ WriteRaw$1(/*string*/ data)
            {
                this.AddString(data);
            }
            /*void */ WriteStartAttribute$1(/*string?*/ prefix, /*string*/ localName, /*string?*/ namespaceName)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(prefix, "prefix");
                this._attrName = $.$spxl.System.Xml.Linq.XNamespace.Get(prefix.length === 0 ? $.$spc.System.String.Empty : namespaceName).GetName(localName);
                this._attrValue = $.$spc.System.String.Empty;
            }
            /*void */ WriteStartDocument()
            {
            }
            /*void */ WriteStartDocument$1(/*bool*/ standalone)
            {
            }
            /*void */ WriteStartElement$1(/*string?*/ prefix, /*string*/ localName, /*string?*/ namespaceName)
            {
                this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$5($.$spxl.System.Xml.Linq.XNamespace.Get(namespaceName).GetName(localName)));
            }
            /*void */ WriteString(/*string?*/ text)
            {
                this.AddString(text);
            }
            /*void */ WriteSurrogateCharEntity(/*char*/ lowCh, /*char*/ highCh)
            {
                this.AddString($.$spc.System.String.Create($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), [highCh, lowCh], null, null))));
            }
            /*void */ WriteValue$4(/*DateTimeOffset*/ value)
            {
                this.WriteString($.$spx.System.Xml.XmlConvert.ToString$18(value));
            }
            /*void */ WriteWhitespace(/*string?*/ ws)
            {
                this.AddString(ws);
            }
            /*void */ Add(/*object*/ o)
            {
                this._content ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Object))().$ctor$1();
                this._content.Add(o);
            }
            /*void */ AddNode(/*XNode*/ n)
            {
                if (this._parent !== null)
                {
                    this._parent.Add(n);
                }
                else 
                {
                    this.Add(n);
                }
                /*XContainer?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XContainer);
                if (c !== null)
                {
                    this._parent = c;
                }
            }
            /*void */ AddString(/*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                if ($.$spc.System.String.op_Inequality(this._attrValue, null))
                {
                    this._attrValue += s;
                }
                else if (this._parent !== null)
                {
                    this._parent.Add(s);
                }
                else 
                {
                    this.Add(s);
                }
            }
            static $h = 2330161;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":58444892,"p":[{"p":58510428,"g":{"r":0,"d":0,"h":34362068529,"f":32769},"n":"Settings","d":2330161,"h":30067101233,"f":32769},{"p":48614492,"g":{"r":0,"d":0,"h":42952003121,"f":32769},"n":"WriteState","d":2330161,"h":38657035825,"f":32769}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":2330161,"h":47246970417,"f":32772},{"r":65537,"n":"Close","d":2330161,"h":51541937713,"f":32769},{"r":65537,"n":"Flush","d":2330161,"h":55836905009,"f":32769},{"r":1310721,"p":[{"n":"namespaceName","p":1310721}],"n":"LookupPrefix","d":2330161,"h":60131872305,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"WriteBase64","d":2330161,"h":64426839601,"f":32769},{"r":65537,"p":[{"n":"text","p":1310721}],"n":"WriteCData","d":2330161,"h":68721806897,"f":32769},{"r":65537,"p":[{"n":"ch","p":458753}],"n":"WriteCharEntity","d":2330161,"h":73016774193,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"WriteChars","d":2330161,"h":77311741489,"f":32769},{"r":65537,"p":[{"n":"text","p":1310721}],"n":"WriteComment","d":2330161,"h":81606708785,"f":32769},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"pubid","p":1310721},{"n":"sysid","p":1310721},{"n":"subset","p":1310721}],"n":"WriteDocType","d":2330161,"h":85901676081,"f":32769},{"r":65537,"n":"WriteEndAttribute","d":2330161,"h":90196643377,"f":32769},{"r":65537,"n":"WriteEndDocument","d":2330161,"h":94491610673,"f":32769},{"r":65537,"n":"WriteEndElement","d":2330161,"h":98786577969,"f":32769},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"WriteEntityRef","d":2330161,"h":103081545265,"f":32769},{"r":65537,"n":"WriteFullEndElement","d":2330161,"h":107376512561,"f":32769},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"text","p":1310721}],"n":"WriteProcessingInstruction","d":2330161,"h":111671479857,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"WriteRaw","d":2330161,"h":115966447153,"f":32769},{"r":65537,"p":[{"n":"data","p":1310721}],"n":"WriteRaw","o":"@$1","d":2330161,"h":120261414449,"f":32769},{"r":65537,"p":[{"n":"prefix","p":1310721},{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"WriteStartAttribute","o":"@$1","d":2330161,"h":124556381745,"f":32769},{"r":65537,"n":"WriteStartDocument","d":2330161,"h":128851349041,"f":32769},{"r":65537,"p":[{"n":"standalone","p":262145}],"n":"WriteStartDocument","o":"@$1","d":2330161,"h":133146316337,"f":32769},{"r":65537,"p":[{"n":"prefix","p":1310721},{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"WriteStartElement","o":"@$1","d":2330161,"h":137441283633,"f":32769},{"r":65537,"p":[{"n":"text","p":1310721}],"n":"WriteString","d":2330161,"h":141736250929,"f":32769},{"r":65537,"p":[{"n":"lowCh","p":458753},{"n":"highCh","p":458753}],"n":"WriteSurrogateCharEntity","d":2330161,"h":146031218225,"f":32769},{"r":65537,"p":[{"n":"value","p":34340865}],"n":"WriteValue","o":"@$4","d":2330161,"h":150326185521,"f":32769},{"r":65537,"p":[{"n":"ws","p":1310721}],"n":"WriteWhitespace","d":2330161,"h":154621152817,"f":32769},{"r":65537,"p":[{"n":"o","p":131073}],"n":"Add","d":2330161,"h":158916120113,"f":2},{"r":65537,"p":[{"n":"n","p":2264625}],"n":"AddNode","d":2330161,"h":163211087409,"f":2},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AddString","d":2330161,"h":167506054705,"f":2}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.Object).$h,"n":"_content","d":2330161,"h":4297297457,"f":2},{"t":1347121,"n":"_parent","d":2330161,"h":8592264753,"f":2},{"t":2133553,"n":"_attrName","d":2330161,"h":12887232049,"f":2},{"t":1310721,"n":"_attrValue","d":2330161,"h":17182199345,"f":2},{"t":1347121,"n":"_root","d":2330161,"h":21477166641,"f":2}],"c":[{"p":[{"n":"container","p":1347121}],"n":".ctor","o":"$ctor$2","d":2330161,"h":25772133937,"f":1}],"i":[57475073,56885249],"h":2330161}; }
            static get $b() { return $.$spx.System.Xml.XmlWriter; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeBuilder`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNodeReader", ($self) => class XNodeReader extends $.$spx.System.Xml.XmlReader
        {
            /*object*/ _source = null;
            /*object?*/ _parent = null;
            /*ReadState*/ _state = 0;
            /*XNode*/ _root = null;
            /*XmlNameTable*/ _nameTable = null;
            /*bool*/ _omitDuplicateNamespaces = false;
            $ctor$2(/*XNode*/ node, /*XmlNameTable?*/ nameTable, /*ReaderOptions*/ options)
            {
                super.$ctor$1();
                {
                    this._source = node;
                    this._root = node;
                    this._nameTable = nameTable ?? $.$spxl.System.Xml.Linq.XNodeReader.CreateNameTable();
                    this._omitDuplicateNamespaces = (options & 1/*ReaderOptions.OmitDuplicateNamespaces*/) !== 0 ? true : false;
                }
                return this;
            }
            $ctor$3(/*XNode*/ node, /*XmlNameTable?*/ nameTable)
            {
                this.$ctor$2(node, nameTable, (node.GetSaveOptionsFromAnnotations() & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0 ? 1/*ReaderOptions.OmitDuplicateNamespaces*/ : 0/*ReaderOptions.None*/);
                {
                }
                return this;
            }
            /*int */ get AttributeCount()
            {
                if (!this.IsInteractive)
                {
                    return 0;
                }
                /*int*/ let count = 0;
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (!this._omitDuplicateNamespaces || !this.IsDuplicateNamespaceAttribute(a))
                            {
                                count++;
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return count;
            }
            /*string */ get BaseURI()
            {
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return o.BaseUri;
                }
                o = $.$as(this._parent, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return o.BaseUri;
                }
                return $.$spc.System.String.Empty;
            }
            /*int */ get Depth()
            {
                if (!this.IsInteractive)
                {
                    return 0;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return $.$spxl.System.Xml.Linq.XNodeReader.GetDepth(o);
                }
                o = $.$as(this._parent, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return (($.$spxl.System.Xml.Linq.XNodeReader.GetDepth(o) + 1) | 0);
                }
                return 0;
            }
            static /*int */ GetDepth(/*XObject*/ o)
            {
                /*int*/ let depth = 0;
                while(o.parent !== null)
                {
                    depth++;
                    o = o.parent;
                }
                if ($.$is(o, $.$spxl.System.Xml.Linq.XDocument))
                {
                    depth--;
                }
                return depth;
            }
            /*bool */ get EOF()
            {
                return this._state === 3/*ReadState.EndOfFile*/;
            }
            /*bool */ get HasAttributes()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null && e.lastAttr !== null)
                {
                    if (this._omitDuplicateNamespaces)
                    {
                        return this.GetFirstNonDuplicateNamespaceAttribute(e.lastAttr.next) !== null;
                    }
                    else 
                    {
                        return true;
                    }
                }
                else 
                {
                    return false;
                }
            }
            /*bool */ get HasValue()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    let $switch1 = o.NodeType;
                    switch($switch1)
                    {
                        case 2/*XmlNodeType.Attribute*/:
                        case 3/*XmlNodeType.Text*/:
                        case 4/*XmlNodeType.CDATA*/:
                        case 8/*XmlNodeType.Comment*/:
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        case 10/*XmlNodeType.DocumentType*/:
                        return true;
                        default:
                        return false;
                    }
                }
                return true;
            }
            /*bool */ get IsEmptyElement()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                return e !== null && e.IsEmpty;
            }
            /*string */ get LocalName()
            {
                return this._nameTable.Add$1(this.GetLocalName());
            }
            /*string */ GetLocalName()
            {
                if (!this.IsInteractive)
                {
                    return $.$spc.System.String.Empty;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.LocalName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return a.Name.LocalName;
                }
                /*XProcessingInstruction?*/ let p = $.$as(this._source, $.$spxl.System.Xml.Linq.XProcessingInstruction);
                if (p !== null)
                {
                    return p.Target;
                }
                /*XDocumentType?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XDocumentType);
                if (n !== null)
                {
                    return n.Name;
                }
                return $.$spc.System.String.Empty;
            }
            /*string */ get Name()
            {
                /*string*/ let prefix = this.GetPrefix();
                if (prefix.length === 0)
                {
                    return this._nameTable.Add$1(this.GetLocalName());
                }
                return this._nameTable.Add$1($.$spc.System.String.Concat$8(prefix, ":", this.GetLocalName()));
            }
            /*string */ get NamespaceURI()
            {
                return this._nameTable.Add$1(this.GetNamespaceURI());
            }
            /*string */ GetNamespaceURI()
            {
                if (!this.IsInteractive)
                {
                    return $.$spc.System.String.Empty;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.NamespaceName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    /*string*/ let namespaceName = a.Name.NamespaceName;
                    if (namespaceName.length === 0 && $.$spc.System.String.op_Equality(a.Name.LocalName, "xmlns"))
                    {
                        return "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/;
                    }
                    return namespaceName;
                }
                return $.$spc.System.String.Empty;
            }
            /*XmlNameTable */ get NameTable()
            {
                return this._nameTable;
            }
            /*XmlNodeType */ get NodeType()
            {
                if (!this.IsInteractive)
                {
                    return 0/*XmlNodeType.None*/;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    if (this.IsEndElement)
                    {
                        return 15/*XmlNodeType.EndElement*/;
                    }
                    /*XmlNodeType*/ let nt = o.NodeType;
                    if (nt !== 3/*XmlNodeType.Text*/)
                    {
                        return nt;
                    }
                    if (o.parent !== null && o.parent.parent === null && $.$is(o.parent, $.$spxl.System.Xml.Linq.XDocument))
                    {
                        return 13/*XmlNodeType.Whitespace*/;
                    }
                    return 3/*XmlNodeType.Text*/;
                }
                if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XDocument))
                {
                    return 13/*XmlNodeType.Whitespace*/;
                }
                return 3/*XmlNodeType.Text*/;
            }
            /*string */ get Prefix()
            {
                return this._nameTable.Add$1(this.GetPrefix());
            }
            /*string */ GetPrefix()
            {
                if (!this.IsInteractive)
                {
                    return $.$spc.System.String.Empty;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    /*string?*/ let prefix = e.GetPrefixOfNamespace(e.Name.Namespace);
                    if ($.$spc.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                    return $.$spc.System.String.Empty;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    /*string?*/ let prefix = a.GetPrefixOfNamespace(a.Name.Namespace);
                    if ($.$spc.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                }
                return $.$spc.System.String.Empty;
            }
            /*ReadState */ get ReadState()
            {
                return this._state;
            }
            /*XmlReaderSettings */ get Settings()
            {
                /*XmlReaderSettings*/ let settings = new $.$spx.System.Xml.XmlReaderSettings().$ctor$1();
                settings.CheckCharacters = false;
                return settings;
            }
            /*string */ get Value()
            {
                if (!this.IsInteractive)
                {
                    return $.$spc.System.String.Empty;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    let $switch1 = o.NodeType;
                    switch($switch1)
                    {
                        case 2/*XmlNodeType.Attribute*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XAttribute)).Value;
                        case 3/*XmlNodeType.Text*/:
                        case 4/*XmlNodeType.CDATA*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XText)).Value;
                        case 8/*XmlNodeType.Comment*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XComment)).Value;
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XProcessingInstruction)).Data;
                        case 10/*XmlNodeType.DocumentType*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XDocumentType)).InternalSubset ?? $.$spc.System.String.Empty;
                        default:
                        return $.$spc.System.String.Empty;
                    }
                }
                return $.$cast(this._source, $.$spc.System.String);
            }
            /*string */ get XmlLang()
            {
                if (!this.IsInteractive)
                {
                    return $.$spc.System.String.Empty;
                }
                /*XElement?*/ let e = this.GetElementInScope();
                if (e !== null)
                {
                    /*XName*/ let name = $.$spxl.System.Xml.Linq.XNamespace.Xml.GetName("lang");
                    do
                    {
                        /*XAttribute?*/ let a = e.Attribute(name);
                        if (a !== null)
                        {
                            return a.Value;
                        }
                        e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    }
                    while(e !== null);
                }
                return $.$spc.System.String.Empty;
            }
            /*XmlSpace */ get XmlSpace()
            {
                if (!this.IsInteractive)
                {
                    return 0/*XmlSpace.None*/;
                }
                /*XElement?*/ let e = this.GetElementInScope();
                if (e !== null)
                {
                    /*XName*/ let name = $.$spxl.System.Xml.Linq.XNamespace.Xml.GetName("space");
                    do
                    {
                        /*XAttribute?*/ let a = e.Attribute(name);
                        if (a !== null)
                        {
                            let $switch1 = $.$spc.System.MemoryExtensions.Trim$12($.$spc.System.MemoryExtensions.AsSpan$3(a.Value), $.$spc.System.String.op_Implicit(" \t\n\r"));
                            switch($switch1)
                            {
                                case "preserve":
                                return 2/*XmlSpace.Preserve*/;
                                case $.$default():
                                return 1/*XmlSpace.Default*/;
                                default:
                                break;
                            }
                        }
                        e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    }
                    while(e !== null);
                }
                return 0/*XmlSpace.None*/;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing && this.ReadState !== 4/*ReadState.Closed*/)
                {
                    this.Close();
                }
            }
            /*void */ Close()
            {
                this._source = null;
                this._parent = null;
                this._root = null;
                this._state = 4/*ReadState.Closed*/;
            }
            /*string? */ GetAttribute(/*string*/ name)
            {
                if (!this.IsInteractive)
                {
                    return null;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*string?*/ let localName, namespaceName;
                    $.$spxl.System.Xml.Linq.XNodeReader.GetNameInAttributeScope(name, e, $.$ref(() => localName, ($v) => localName = $v, $.$spc.System.String), $.$ref(() => namespaceName, ($v) => namespaceName = $v, $.$spc.System.String));
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$spc.System.String.op_Equality(a.Name.LocalName, localName) && $.$spc.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return null;
                                }
                                else 
                                {
                                    return a.Value;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                    return null;
                }
                /*XDocumentType?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XDocumentType);
                if (n !== null)
                {
                    switch(name)
                    {
                        case "PUBLIC":
                        return n.PublicId;
                        case "SYSTEM":
                        return n.SystemId;
                    }
                }
                return null;
            }
            /*string? */ GetAttribute$1(/*string*/ localName, /*string?*/ namespaceName)
            {
                if (!this.IsInteractive)
                {
                    return null;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    if ($.$spc.System.String.op_Equality(localName, "xmlns"))
                    {
                        if ($.$spc.System.String.op_Inequality(namespaceName, null) && namespaceName.length === 0)
                        {
                            return null;
                        }
                        if ($.$spc.System.String.op_Equality(namespaceName, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                        {
                            namespaceName = $.$spc.System.String.Empty;
                        }
                    }
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$spc.System.String.op_Equality(a.Name.LocalName, localName) && $.$spc.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return null;
                                }
                                else 
                                {
                                    return a.Value;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return null;
            }
            /*string */ GetAttribute$2(/*int*/ index)
            {
                if (!this.IsInteractive)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (!this._omitDuplicateNamespaces || !this.IsDuplicateNamespaceAttribute(a))
                            {
                                if (index-- === 0)
                                {
                                    return a.Value;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("index");
            }
            /*string? */ LookupNamespace(/*string*/ prefix)
            {
                if (!this.IsInteractive)
                {
                    return null;
                }
                if ($.$spc.System.String.op_Equality(prefix, null))
                {
                    return null;
                }
                /*XElement?*/ let e = this.GetElementInScope();
                if (e !== null)
                {
                    /*XNamespace?*/ let ns = prefix.length === 0 ? e.GetDefaultNamespace() : e.GetNamespaceOfPrefix(prefix);
                    if ($.$spxl.System.Xml.Linq.XNamespace.op_Inequality(ns, null))
                    {
                        return this._nameTable.Add$1(ns.NamespaceName);
                    }
                }
                return null;
            }
            /*bool */ MoveToAttribute(/*string*/ name)
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*string?*/ let localName, namespaceName;
                    $.$spxl.System.Xml.Linq.XNodeReader.GetNameInAttributeScope(name, e, $.$ref(() => localName, ($v) => localName = $v, $.$spc.System.String), $.$ref(() => namespaceName, ($v) => namespaceName = $v, $.$spc.System.String));
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$spc.System.String.op_Equality(a.Name.LocalName, localName) && $.$spc.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return false;
                                }
                                else 
                                {
                                    this._source = a;
                                    this._parent = null;
                                    return true;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return false;
            }
            /*bool */ MoveToAttribute$1(/*string*/ localName, /*string?*/ namespaceName)
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    if ($.$spc.System.String.op_Equality(localName, "xmlns"))
                    {
                        if ($.$spc.System.String.op_Inequality(namespaceName, null) && namespaceName.length === 0)
                        {
                            return false;
                        }
                        if ($.$spc.System.String.op_Equality(namespaceName, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                        {
                            namespaceName = $.$spc.System.String.Empty;
                        }
                    }
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$spc.System.String.op_Equality(a.Name.LocalName, localName) && $.$spc.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return false;
                                }
                                else 
                                {
                                    this._source = a;
                                    this._parent = null;
                                    return true;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return false;
            }
            /*void */ MoveToAttribute$2(/*int*/ index)
            {
                if (!this.IsInteractive)
                {
                    return;
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (!this._omitDuplicateNamespaces || !this.IsDuplicateNamespaceAttribute(a))
                            {
                                if (index-- === 0)
                                {
                                    this._source = a;
                                    this._parent = null;
                                    return;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("index");
            }
            /*bool */ MoveToElement()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute) ?? $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (a.parent !== null)
                    {
                        this._source = a.parent;
                        this._parent = null;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToFirstAttribute()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    if (e.lastAttr !== null)
                    {
                        if (this._omitDuplicateNamespaces)
                        {
                            /*object?*/ let na = this.GetFirstNonDuplicateNamespaceAttribute(e.lastAttr.next);
                            if (na === null)
                            {
                                return false;
                            }
                            this._source = na;
                        }
                        else 
                        {
                            this._source = e.lastAttr.next;
                        }
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToNextAttribute()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (this.IsEndElement)
                    {
                        return false;
                    }
                    if (e.lastAttr !== null)
                    {
                        if (this._omitDuplicateNamespaces)
                        {
                            /*object?*/ let na = this.GetFirstNonDuplicateNamespaceAttribute(e.lastAttr.next);
                            if (na === null)
                            {
                                return false;
                            }
                            this._source = na;
                        }
                        else 
                        {
                            this._source = e.lastAttr.next;
                        }
                        return true;
                    }
                    return false;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute) ?? $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (a.parent !== null && ($.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr !== a)
                    {
                        if (this._omitDuplicateNamespaces)
                        {
                            /*object?*/ let na = this.GetFirstNonDuplicateNamespaceAttribute(a.next);
                            if (na === null)
                            {
                                return false;
                            }
                            this._source = na;
                        }
                        else 
                        {
                            this._source = a.next;
                        }
                        this._parent = null;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ Read()
            {
                switch(this._state)
                {
                    case 0/*ReadState.Initial*/:
                    this._state = 1/*ReadState.Interactive*/;
                    /*XDocument?*/ let d = $.$as(this._source, $.$spxl.System.Xml.Linq.XDocument);
                    if (d !== null)
                    {
                        return this.ReadIntoDocument(d);
                    }
                    return true;
                    case 1/*ReadState.Interactive*/:
                    return this.Read$1(false);
                    default:
                    return false;
                }
            }
            /*bool */ ReadAttributeValue()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return this.ReadIntoAttribute(a);
                }
                return false;
            }
            /*bool */ ReadToDescendant$1(/*string*/ localName, /*string*/ namespaceName)
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                this.MoveToElement();
                /*XElement?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (c !== null && !c.IsEmpty)
                {
                    if (this.IsEndElement)
                    {
                        return false;
                    }
                    var $en3 = c.Descendants().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var e = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spc.System.String.op_Equality(e.Name.LocalName, localName) && $.$spc.System.String.op_Equality(e.Name.NamespaceName, namespaceName))
                            {
                                this._source = e;
                                return true;
                            }
                        }
                    }
                    this.IsEndElement = true;
                }
                return false;
            }
            /*bool */ ReadToFollowing$1(/*string*/ localName, /*string*/ namespaceName)
            {
                while(this.Read())
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        if (this.IsEndElement)
                        {
                            continue;
                        }
                        if ($.$spc.System.String.op_Equality(e.Name.LocalName, localName) && $.$spc.System.String.op_Equality(e.Name.NamespaceName, namespaceName))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*bool */ ReadToNextSibling$1(/*string*/ localName, /*string*/ namespaceName)
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                this.MoveToElement();
                if (this._source !== this._root)
                {
                    /*XNode?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                    if (n !== null)
                    {
                        var $en4 = n.ElementsAfterSelf().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var e = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if ($.$spc.System.String.op_Equality(e.Name.LocalName, localName) && $.$spc.System.String.op_Equality(e.Name.NamespaceName, namespaceName))
                                {
                                    this._source = e;
                                    this.IsEndElement = false;
                                    return true;
                                }
                            }
                        }
                        if ($.$is(n.parent, $.$spxl.System.Xml.Linq.XElement))
                        {
                            this._source = n.parent;
                            this.IsEndElement = true;
                            return false;
                        }
                    }
                    else 
                    {
                        if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XElement))
                        {
                            this._source = this._parent;
                            this._parent = null;
                            this.IsEndElement = true;
                            return false;
                        }
                    }
                }
                return this.ReadToEnd();
            }
            /*void */ ResolveEntity()
            {
            }
            /*void */ Skip()
            {
                if (!this.IsInteractive)
                {
                    return;
                }
                this.Read$1(true);
            }
            /*bool */ System$Xml$IXmlLineInfo$HasLineInfo()
            {
                if (this.IsEndElement)
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        return e.Annotation$1($.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation) !== null;
                    }
                }
                else 
                {
                    /*IXmlLineInfo?*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null)
                    {
                        return li.System$Xml$IXmlLineInfo$HasLineInfo();
                    }
                }
                return false;
            }
            /*int */ get System$Xml$IXmlLineInfo$LineNumber()
            {
                if (this.IsEndElement)
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        /*LineInfoEndElementAnnotation?*/ let a = e.Annotation$1($.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation);
                        if (a !== null)
                        {
                            return a.lineNumber;
                        }
                    }
                }
                else 
                {
                    /*IXmlLineInfo?*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null)
                    {
                        return li.System$Xml$IXmlLineInfo$LineNumber;
                    }
                }
                return 0;
            }
            /*int */ get System$Xml$IXmlLineInfo$LinePosition()
            {
                if (this.IsEndElement)
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        /*LineInfoEndElementAnnotation?*/ let a = e.Annotation$1($.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation);
                        if (a !== null)
                        {
                            return a.linePosition;
                        }
                    }
                }
                else 
                {
                    /*IXmlLineInfo?*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null)
                    {
                        return li.System$Xml$IXmlLineInfo$LinePosition;
                    }
                }
                return 0;
            }
            /*bool */ get IsEndElement()
            {
                return this._parent === this._source;
            }
            /*bool */ set IsEndElement(value)
            {
                this._parent = value ? this._source : null;
            }
            /*bool */ get IsInteractive()
            {
                return this._state === 1/*ReadState.Interactive*/;
            }
            static /*NameTable */ CreateNameTable()
            {
                /*var*/ let nameTable = new $.$spx.System.Xml.NameTable().$ctor$2();
                nameTable.Add$1($.$spc.System.String.Empty);
                nameTable.Add$1("http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/);
                nameTable.Add$1("http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/);
                return nameTable;
            }
            /*XElement? */ GetElementInAttributeScope()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (this.IsEndElement)
                    {
                        return null;
                    }
                    return e;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                a = $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return null;
            }
            /*XElement? */ GetElementInScope()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e;
                }
                /*XNode?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    return $.$as(n.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                e = $.$as(this._parent, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e;
                }
                a = $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return null;
            }
            static /*void */ GetNameInAttributeScope(/*string?*/ qualifiedName, /*XElement*/ e, /*out string?*/ localName, /*out string?*/ namespaceName)
            {
                if (!$.$spc.System.String.IsNullOrEmpty(qualifiedName))
                {
                    /*int*/ let i = $.$spc.System.String.IndexOf.call(qualifiedName, /*:*/ 58);
                    if (i !== 0 && i !== ((qualifiedName.length - 1) | 0))
                    {
                        if (i === -1)
                        {
                            localName.$v = qualifiedName;
                            namespaceName.$v = $.$spc.System.String.Empty;
                            return;
                        }
                        /*XNamespace?*/ let ns = e.GetNamespaceOfPrefix($.$spc.System.String.Substring$1.call(qualifiedName, 0, i));
                        if ($.$spxl.System.Xml.Linq.XNamespace.op_Inequality(ns, null))
                        {
                            localName.$v = $.$spc.System.String.Substring.call(qualifiedName, ((i + 1) | 0));
                            namespaceName.$v = ns.NamespaceName;
                            return;
                        }
                    }
                }
                localName.$v = null;
                namespaceName.$v = null;
            }
            /*bool */ Read$1(/*bool*/ skipContent)
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (e.IsEmpty || this.IsEndElement || skipContent)
                    {
                        return this.ReadOverNode(e);
                    }
                    return this.ReadIntoElement(e);
                }
                /*XNode?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    return this.ReadOverNode(n);
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return this.ReadOverAttribute(a, skipContent);
                }
                return this.ReadOverText(skipContent);
            }
            /*bool */ ReadIntoDocument(/*XDocument*/ d)
            {
                /*XNode?*/ let n = $.$as(d.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this._source = n.next;
                    return true;
                }
                /*string?*/ let s = $.$as(d.content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    if (s.length > 0)
                    {
                        this._source = s;
                        this._parent = d;
                        return true;
                    }
                }
                return this.ReadToEnd();
            }
            /*bool */ ReadIntoElement(/*XElement*/ e)
            {
                /*XNode?*/ let n = $.$as(e.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this._source = n.next;
                    return true;
                }
                /*string?*/ let s = $.$as(e.content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    if (s.length > 0)
                    {
                        this._source = s;
                        this._parent = e;
                    }
                    else 
                    {
                        this._source = e;
                        this.IsEndElement = true;
                    }
                    return true;
                }
                return this.ReadToEnd();
            }
            /*bool */ ReadIntoAttribute(/*XAttribute*/ a)
            {
                this._source = a.value;
                this._parent = a;
                return true;
            }
            /*bool */ ReadOverAttribute(/*XAttribute*/ a, /*bool*/ skipContent)
            {
                /*XElement?*/ let e = $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (e.IsEmpty || skipContent)
                    {
                        return this.ReadOverNode(e);
                    }
                    return this.ReadIntoElement(e);
                }
                return this.ReadToEnd();
            }
            /*bool */ ReadOverNode(/*XNode*/ n)
            {
                if (n === this._root)
                {
                    return this.ReadToEnd();
                }
                /*XNode?*/ let next = n.next;
                if (null === next || next === n || n === n.parent.content)
                {
                    if (n.parent === null || (n.parent.parent === null && $.$is(n.parent, $.$spxl.System.Xml.Linq.XDocument)))
                    {
                        return this.ReadToEnd();
                    }
                    this._source = n.parent;
                    this.IsEndElement = true;
                }
                else 
                {
                    this._source = next;
                    this.IsEndElement = false;
                }
                return true;
            }
            /*bool */ ReadOverText(/*bool*/ skipContent)
            {
                if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XElement))
                {
                    this._source = this._parent;
                    this._parent = null;
                    this.IsEndElement = true;
                    return true;
                }
                /*XAttribute?*/ let parent = $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (parent !== null)
                {
                    this._parent = null;
                    return this.ReadOverAttribute(parent, skipContent);
                }
                return this.ReadToEnd();
            }
            /*bool */ ReadToEnd()
            {
                this._state = 3/*ReadState.EndOfFile*/;
                return false;
            }
            /*bool */ IsDuplicateNamespaceAttribute(/*XAttribute*/ candidateAttribute)
            {
                if (!candidateAttribute.IsNamespaceDeclaration)
                {
                    return false;
                }
                else 
                {
                    return this.IsDuplicateNamespaceAttributeInner(candidateAttribute);
                }
            }
            /*bool */ IsDuplicateNamespaceAttributeInner(/*XAttribute*/ candidateAttribute)
            {
                if ($.$spc.System.String.op_Equality(candidateAttribute.Name.LocalName, "xml"))
                {
                    return true;
                }
                /*XElement?*/ let element = $.$as(candidateAttribute.parent, $.$spxl.System.Xml.Linq.XElement);
                if (element === this._root || element === null)
                {
                    return false;
                }
                element = $.$as(element.parent, $.$spxl.System.Xml.Linq.XElement);
                while(element !== null)
                {
                    /*XAttribute?*/ let a = element.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            if ($.$spxl.System.Xml.Linq.XName.op_Equality(a.name, candidateAttribute.name))
                            {
                                if ($.$spc.System.String.op_Equality(a.Value, candidateAttribute.Value))
                                {
                                    return true;
                                }
                                else 
                                {
                                    return false;
                                }
                            }
                            a = a.next;
                        }
                        while(a !== element.lastAttr);
                    }
                    if (element === this._root)
                    {
                        return false;
                    }
                    element = $.$as(element.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return false;
            }
            /*XAttribute? */ GetFirstNonDuplicateNamespaceAttribute(/*XAttribute*/ candidate)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._omitDuplicateNamespaces, "This method should only be called if we're omitting duplicate namespace attribute. For perf reason it's better to test this flag in the caller method.");
                if (!this.IsDuplicateNamespaceAttribute(candidate))
                {
                    return candidate;
                }
                /*XElement?*/ let e = $.$as(candidate.parent, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null && candidate !== e.lastAttr)
                {
                    do
                    {
                        candidate = candidate.next;
                        if (!this.IsDuplicateNamespaceAttribute(candidate))
                        {
                            return candidate;
                        }
                    }
                    while(candidate !== e.lastAttr);
                }
                return null;
            }
            static $h = 2526769;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":53398620,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42952199729,"f":32769},"n":"AttributeCount","d":2526769,"h":38657232433,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":51542134321,"f":32769},"n":"BaseURI","d":2526769,"h":47247167025,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":60132068913,"f":32769},"n":"Depth","d":2526769,"h":55837101617,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":73016970801,"f":32769},"n":"EOF","d":2526769,"h":68722003505,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":81606905393,"f":32769},"n":"HasAttributes","d":2526769,"h":77311938097,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":90196839985,"f":32769},"n":"HasValue","d":2526769,"h":85901872689,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":98786774577,"f":32769},"n":"IsEmptyElement","d":2526769,"h":94491807281,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":107376709169,"f":32769},"n":"LocalName","d":2526769,"h":103081741873,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":120261611057,"f":32769},"n":"Name","d":2526769,"h":115966643761,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":128851545649,"f":32769},"n":"NamespaceURI","d":2526769,"h":124556578353,"f":32769},{"p":52087900,"g":{"r":0,"d":0,"h":141736447537,"f":32769},"n":"NameTable","d":2526769,"h":137441480241,"f":32769},{"p":52874332,"g":{"r":0,"d":0,"h":150326382129,"f":32769},"n":"NodeType","d":2526769,"h":146031414833,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":158916316721,"f":32769},"n":"Prefix","d":2526769,"h":154621349425,"f":32769},{"p":14928988,"g":{"r":0,"d":0,"h":171801218609,"f":32769},"n":"ReadState","d":2526769,"h":167506251313,"f":32769},{"p":53529692,"g":{"r":0,"d":0,"h":180391153201,"f":32769},"n":"Settings","d":2526769,"h":176096185905,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":188981087793,"f":32769},"n":"Value","d":2526769,"h":184686120497,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":197571022385,"f":32769},"n":"XmlLang","d":2526769,"h":193276055089,"f":32769},{"p":54053980,"g":{"r":0,"d":0,"h":206160956977,"f":32769},"n":"XmlSpace","d":2526769,"h":201865989681,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":300650237489,"f":2},"n":"{13945948}.LineNumber","o":"System$Xml$IXmlLineInfo$LineNumber","d":2526769,"h":296355270193,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":309240172081,"f":2},"n":"{13945948}.LinePosition","o":"System$Xml$IXmlLineInfo$LinePosition","d":2526769,"h":304945204785,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":317830106673,"f":2},"s":{"r":0,"d":0,"h":322125073969,"f":2},"n":"IsEndElement","d":2526769,"h":313535139377,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":330715008561,"f":2},"n":"IsInteractive","d":2526769,"h":326420041265,"f":2}],"m":[{"r":655361,"p":[{"n":"o","p":2592305}],"n":"GetDepth","d":2526769,"h":64427036209,"f":34},{"r":1310721,"n":"GetLocalName","d":2526769,"h":111671676465,"f":2},{"r":1310721,"n":"GetNamespaceURI","d":2526769,"h":133146512945,"f":2},{"r":1310721,"n":"GetPrefix","d":2526769,"h":163211284017,"f":2},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":2526769,"h":210455924273,"f":32772},{"r":65537,"n":"Close","d":2526769,"h":214750891569,"f":32769},{"r":1310721,"p":[{"n":"name","p":1310721}],"n":"GetAttribute","d":2526769,"h":219045858865,"f":32769},{"r":1310721,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"GetAttribute","o":"@$1","d":2526769,"h":223340826161,"f":32769},{"r":1310721,"p":[{"n":"index","p":655361}],"n":"GetAttribute","o":"@$2","d":2526769,"h":227635793457,"f":32769},{"r":1310721,"p":[{"n":"prefix","p":1310721}],"n":"LookupNamespace","d":2526769,"h":231930760753,"f":32769},{"r":262145,"p":[{"n":"name","p":1310721}],"n":"MoveToAttribute","d":2526769,"h":236225728049,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"MoveToAttribute","o":"@$1","d":2526769,"h":240520695345,"f":32769},{"r":65537,"p":[{"n":"index","p":655361}],"n":"MoveToAttribute","o":"@$2","d":2526769,"h":244815662641,"f":32769},{"r":262145,"n":"MoveToElement","d":2526769,"h":249110629937,"f":32769},{"r":262145,"n":"MoveToFirstAttribute","d":2526769,"h":253405597233,"f":32769},{"r":262145,"n":"MoveToNextAttribute","d":2526769,"h":257700564529,"f":32769},{"r":262145,"n":"Read","d":2526769,"h":261995531825,"f":32769},{"r":262145,"n":"ReadAttributeValue","d":2526769,"h":266290499121,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"ReadToDescendant","o":"@$1","d":2526769,"h":270585466417,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"ReadToFollowing","o":"@$1","d":2526769,"h":274880433713,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"ReadToNextSibling","o":"@$1","d":2526769,"h":279175401009,"f":32769},{"r":65537,"n":"ResolveEntity","d":2526769,"h":283470368305,"f":32769},{"r":65537,"n":"Skip","d":2526769,"h":287765335601,"f":32769},{"r":14273628,"n":"CreateNameTable","d":2526769,"h":335009975857,"f":34},{"r":1674801,"n":"GetElementInAttributeScope","d":2526769,"h":339304943153,"f":2},{"r":1674801,"n":"GetElementInScope","d":2526769,"h":343599910449,"f":2},{"r":65537,"p":[{"n":"qualifiedName","p":1310721},{"n":"e","p":1674801},{"n":"localName","p":1310721,"f":2},{"n":"namespaceName","p":1310721,"f":2}],"n":"GetNameInAttributeScope","d":2526769,"h":347894877745,"f":34},{"r":262145,"p":[{"n":"skipContent","p":262145}],"n":"Read","o":"@$1","d":2526769,"h":352189845041,"f":2},{"r":262145,"p":[{"n":"d","p":1543729}],"n":"ReadIntoDocument","d":2526769,"h":356484812337,"f":2},{"r":262145,"p":[{"n":"e","p":1674801}],"n":"ReadIntoElement","d":2526769,"h":360779779633,"f":2},{"r":262145,"p":[{"n":"a","p":1150513}],"n":"ReadIntoAttribute","d":2526769,"h":365074746929,"f":2},{"r":262145,"p":[{"n":"a","p":1150513},{"n":"skipContent","p":262145}],"n":"ReadOverAttribute","d":2526769,"h":369369714225,"f":2},{"r":262145,"p":[{"n":"n","p":2264625}],"n":"ReadOverNode","d":2526769,"h":373664681521,"f":2},{"r":262145,"p":[{"n":"skipContent","p":262145}],"n":"ReadOverText","d":2526769,"h":377959648817,"f":2},{"r":262145,"n":"ReadToEnd","d":2526769,"h":382254616113,"f":2},{"r":262145,"p":[{"n":"candidateAttribute","p":1150513}],"n":"IsDuplicateNamespaceAttribute","d":2526769,"h":386549583409,"f":2},{"r":262145,"p":[{"n":"candidateAttribute","p":1150513}],"n":"IsDuplicateNamespaceAttributeInner","d":2526769,"h":390844550705,"f":2},{"r":1150513,"p":[{"n":"candidate","p":1150513}],"n":"GetFirstNonDuplicateNamespaceAttribute","d":2526769,"h":395139518001,"f":2}],"l":[{"t":131073,"n":"_source","d":2526769,"h":4297494065,"f":2},{"t":131073,"n":"_parent","d":2526769,"h":8592461361,"f":2},{"t":14928988,"n":"_state","d":2526769,"h":12887428657,"f":2},{"t":2264625,"n":"_root","d":2526769,"h":17182395953,"f":2},{"t":52087900,"n":"_nameTable","d":2526769,"h":21477363249,"f":2},{"t":262145,"n":"_omitDuplicateNamespaces","d":2526769,"h":25772330545,"f":2}],"c":[{"p":[{"n":"node","p":2264625},{"n":"nameTable","p":52087900},{"n":"options","p":953905}],"n":".ctor","o":"$ctor$2","d":2526769,"h":30067297841,"f":8},{"p":[{"n":"node","p":2264625},{"n":"nameTable","p":52087900}],"n":".ctor","o":"$ctor$3","d":2526769,"h":34362265137,"f":8}],"i":[57475073,13945948],"h":2526769}; }
            static get $b() { return $.$spx.System.Xml.XmlReader; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeReader`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XComment", ($self) => class XComment extends $.$spxl.System.Xml.Linq.XNode
        {
            /*string*/ value = null;
            $ctor$3(/*string*/ value)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                    this.value = value;
                }
                return this;
            }
            $ctor$4(/*XComment*/ other)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this.value = other.value;
                }
                return this;
            }
            $ctor$5(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    this.value = r.Value;
                    r.Read();
                }
                return this;
            }
            /*XmlNodeType */ get NodeType()
            {
                return 8/*XmlNodeType.Comment*/;
            }
            /*string */ get Value()
            {
                return this.value;
            }
            /*string */ set Value(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.value = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                writer.WriteComment(this.value);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return writer.WriteCommentAsync(this.value);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XComment().$ctor$4(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XComment?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XComment);
                return other !== null && $.$spc.System.String.op_Equality(this.value, other.value);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$spc.System.String.GetHashCode.call(this.value);
            }
            static $h = 1281585;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2264625,"p":[{"p":52874332,"g":{"r":0,"d":0,"h":25771085361,"f":32769},"n":"NodeType","d":1281585,"h":21476118065,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":34361019953,"f":1},"s":{"r":0,"d":0,"h":38655987249,"f":1},"n":"Value","d":1281585,"h":30066052657,"f":1}],"m":[{"r":65537,"p":[{"n":"writer","p":58444892}],"n":"WriteTo","d":1281585,"h":42950954545,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58444892},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":1281585,"h":47245921841,"f":32769},{"r":2264625,"n":"CloneNode","d":1281585,"h":51540889137,"f":32776},{"r":262145,"p":[{"n":"node","p":2264625}],"n":"DeepEquals","o":"@$1","d":1281585,"h":55835856433,"f":32776},{"r":655361,"n":"GetDeepHashCode","d":1281585,"h":60130823729,"f":32776}],"l":[{"t":1310721,"n":"value","d":1281585,"h":4296248881,"f":8}],"c":[{"p":[{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$3","d":1281585,"h":8591216177,"f":1},{"p":[{"n":"other","p":1281585}],"n":".ctor","o":"$ctor$4","d":1281585,"h":12886183473,"f":1},{"p":[{"n":"r","p":53398620}],"n":".ctor","o":"$ctor$5","d":1281585,"h":17181150769,"f":8}],"i":[13945948],"h":1281585}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XComment`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XDocumentType", ($self) => class XDocumentType extends $.$spxl.System.Xml.Linq.XNode
        {
            /*string*/ _name = null;
            /*string?*/ _publicId = null;
            /*string?*/ _systemId = null;
            /*string?*/ _internalSubset = null;
            $ctor$3(/*string*/ name, /*string?*/ publicId, /*string?*/ systemId, /*string?*/ internalSubset)
            {
                super.$ctor$2();
                {
                    this._name = $.$spx.System.Xml.XmlConvert.VerifyName(name);
                    this._publicId = publicId;
                    this._systemId = systemId;
                    this._internalSubset = internalSubset;
                }
                return this;
            }
            $ctor$4(/*XDocumentType*/ other)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this._name = other._name;
                    this._publicId = other._publicId;
                    this._systemId = other._systemId;
                    this._internalSubset = other._internalSubset;
                }
                return this;
            }
            $ctor$5(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    this._name = r.Name;
                    this._publicId = r.GetAttribute("PUBLIC");
                    this._systemId = r.GetAttribute("SYSTEM");
                    this._internalSubset = r.Value;
                    r.Read();
                }
                return this;
            }
            /*string? */ get InternalSubset()
            {
                return this._internalSubset;
            }
            /*string? */ set InternalSubset(value)
            {
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this._internalSubset = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*string */ get Name()
            {
                return this._name;
            }
            /*string */ set Name(value)
            {
                value = $.$spx.System.Xml.XmlConvert.VerifyName(value);
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                this._name = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                }
            }
            /*XmlNodeType */ get NodeType()
            {
                return 10/*XmlNodeType.DocumentType*/;
            }
            /*string? */ get PublicId()
            {
                return this._publicId;
            }
            /*string? */ set PublicId(value)
            {
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this._publicId = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*string? */ get SystemId()
            {
                return this._systemId;
            }
            /*string? */ set SystemId(value)
            {
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this._systemId = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                writer.WriteDocType(this._name, this._publicId, this._systemId, this._internalSubset);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return writer.WriteDocTypeAsync(this._name, this._publicId, this._systemId, this._internalSubset);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$4(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XDocumentType?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XDocumentType);
                return other !== null && $.$spc.System.String.op_Equality(this._name, other._name) && $.$spc.System.String.op_Equality(this._publicId, other._publicId) && $.$spc.System.String.op_Equality(this._systemId, other.SystemId) && $.$spc.System.String.op_Equality(this._internalSubset, other._internalSubset);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$spc.System.String.GetHashCode.call(this._name) ^ ($.$spc.System.String.op_Inequality(this._publicId, null) ? $.$spc.System.String.GetHashCode.call(this._publicId) : 0) ^ ($.$spc.System.String.op_Inequality(this._systemId, null) ? $.$spc.System.String.GetHashCode.call(this._systemId) : 0) ^ ($.$spc.System.String.op_Inequality(this._internalSubset, null) ? $.$spc.System.String.GetHashCode.call(this._internalSubset) : 0);
            }
            static $h = 1609265;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2264625,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":38656314929,"f":1},"s":{"r":0,"d":0,"h":42951282225,"f":1},"n":"InternalSubset","d":1609265,"h":34361347633,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51541216817,"f":1},"s":{"r":0,"d":0,"h":55836184113,"f":1},"n":"Name","d":1609265,"h":47246249521,"f":1},{"p":52874332,"g":{"r":0,"d":0,"h":64426118705,"f":32769},"n":"NodeType","d":1609265,"h":60131151409,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":73016053297,"f":1},"s":{"r":0,"d":0,"h":77311020593,"f":1},"n":"PublicId","d":1609265,"h":68721086001,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85900955185,"f":1},"s":{"r":0,"d":0,"h":90195922481,"f":1},"n":"SystemId","d":1609265,"h":81605987889,"f":1}],"m":[{"r":65537,"p":[{"n":"writer","p":58444892}],"n":"WriteTo","d":1609265,"h":94490889777,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58444892},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":1609265,"h":98785857073,"f":32769},{"r":2264625,"n":"CloneNode","d":1609265,"h":103080824369,"f":32776},{"r":262145,"p":[{"n":"node","p":2264625}],"n":"DeepEquals","o":"@$1","d":1609265,"h":107375791665,"f":32776},{"r":655361,"n":"GetDeepHashCode","d":1609265,"h":111670758961,"f":32776}],"l":[{"t":1310721,"n":"_name","d":1609265,"h":4296576561,"f":2},{"t":1310721,"n":"_publicId","d":1609265,"h":8591543857,"f":2},{"t":1310721,"n":"_systemId","d":1609265,"h":12886511153,"f":2},{"t":1310721,"n":"_internalSubset","d":1609265,"h":17181478449,"f":2}],"c":[{"p":[{"n":"name","p":1310721},{"n":"publicId","p":1310721},{"n":"systemId","p":1310721},{"n":"internalSubset","p":1310721}],"n":".ctor","o":"$ctor$3","d":1609265,"h":21476445745,"f":1},{"p":[{"n":"other","p":1609265}],"n":".ctor","o":"$ctor$4","d":1609265,"h":25771413041,"f":1},{"p":[{"n":"r","p":53398620}],"n":".ctor","o":"$ctor$5","d":1609265,"h":30066380337,"f":8}],"i":[13945948],"h":1609265}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XDocumentType`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XProcessingInstruction", ($self) => class XProcessingInstruction extends $.$spxl.System.Xml.Linq.XNode
        {
            /*string*/ target = null;
            /*string*/ data = null;
            $ctor$3(/*string*/ target, /*string*/ data)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(data, "data");
                    $.$spxl.System.Xml.Linq.XProcessingInstruction.ValidateName(target);
                    this.target = target;
                    this.data = data;
                }
                return this;
            }
            $ctor$4(/*XProcessingInstruction*/ other)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this.target = other.target;
                    this.data = other.data;
                }
                return this;
            }
            $ctor$5(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    this.target = r.Name;
                    this.data = r.Value;
                    r.Read();
                }
                return this;
            }
            /*string */ get Data()
            {
                return this.data;
            }
            /*string */ set Data(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.data = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*XmlNodeType */ get NodeType()
            {
                return 7/*XmlNodeType.ProcessingInstruction*/;
            }
            /*string */ get Target()
            {
                return this.target;
            }
            /*string */ set Target(value)
            {
                $.$spxl.System.Xml.Linq.XProcessingInstruction.ValidateName(value);
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                this.target = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                writer.WriteProcessingInstruction(this.target, this.data);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return writer.WriteProcessingInstructionAsync(this.target, this.data);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$4(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XProcessingInstruction?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XProcessingInstruction);
                return other !== null && $.$spc.System.String.op_Equality(this.target, other.target) && $.$spc.System.String.op_Equality(this.data, other.data);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$spc.System.String.GetHashCode.call(this.target) ^ $.$spc.System.String.GetHashCode.call(this.data);
            }
            static /*void */ ValidateName(/*string*/ name)
            {
                $.$spx.System.Xml.XmlConvert.VerifyNCName(name);
                if ($.$spc.System.String.Equals$5(name, "xml", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_InvalidPIName, name));
                }
            }
            static $h = 2854449;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2264625,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30067625521,"f":1},"s":{"r":0,"d":0,"h":34362592817,"f":1},"n":"Data","d":2854449,"h":25772658225,"f":1},{"p":52874332,"g":{"r":0,"d":0,"h":42952527409,"f":32769},"n":"NodeType","d":2854449,"h":38657560113,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":51542462001,"f":1},"s":{"r":0,"d":0,"h":55837429297,"f":1},"n":"Target","d":2854449,"h":47247494705,"f":1}],"m":[{"r":65537,"p":[{"n":"writer","p":58444892}],"n":"WriteTo","d":2854449,"h":60132396593,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58444892},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":2854449,"h":64427363889,"f":32769},{"r":2264625,"n":"CloneNode","d":2854449,"h":68722331185,"f":32776},{"r":262145,"p":[{"n":"node","p":2264625}],"n":"DeepEquals","o":"@$1","d":2854449,"h":73017298481,"f":32776},{"r":655361,"n":"GetDeepHashCode","d":2854449,"h":77312265777,"f":32776},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"ValidateName","d":2854449,"h":81607233073,"f":34}],"l":[{"t":1310721,"n":"target","d":2854449,"h":4297821745,"f":8},{"t":1310721,"n":"data","d":2854449,"h":8592789041,"f":8}],"c":[{"p":[{"n":"target","p":1310721},{"n":"data","p":1310721}],"n":".ctor","o":"$ctor$3","d":2854449,"h":12887756337,"f":1},{"p":[{"n":"other","p":2854449}],"n":".ctor","o":"$ctor$4","d":2854449,"h":17182723633,"f":1},{"p":[{"n":"r","p":53398620}],"n":".ctor","o":"$ctor$5","d":2854449,"h":21477690929,"f":8}],"i":[13945948],"h":2854449}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XProcessingInstruction`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XText", ($self) => class XText extends $.$spxl.System.Xml.Linq.XNode
        {
            /*string*/ text = null;
            $ctor$3(/*string*/ value)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                    this.text = value;
                }
                return this;
            }
            $ctor$4(/*XText*/ other)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this.text = other.text;
                }
                return this;
            }
            $ctor$5(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    this.text = r.Value;
                    r.Read();
                }
                return this;
            }
            /*XmlNodeType */ get NodeType()
            {
                return 3/*XmlNodeType.Text*/;
            }
            /*string */ get Value()
            {
                return this.text;
            }
            /*string */ set Value(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.text = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if ($.$is(this.parent, $.$spxl.System.Xml.Linq.XDocument))
                {
                    writer.WriteWhitespace(this.text);
                }
                else 
                {
                    writer.WriteString(this.text);
                }
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return $.$is(this.parent, $.$spxl.System.Xml.Linq.XDocument) ? writer.WriteWhitespaceAsync(this.text) : writer.WriteStringAsync(this.text);
            }
            /*void */ AppendText(/*StringBuilder*/ sb)
            {
                sb.Append$2(this.text);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XText().$ctor$4(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                return node !== null && this.NodeType === node.NodeType && $.$spc.System.String.op_Equality(this.text, ($.$cast(node, $.$spxl.System.Xml.Linq.XText)).text);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$spc.System.String.GetHashCode.call(this.text);
            }
            static $h = 2985521;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2264625,"p":[{"p":52874332,"g":{"r":0,"d":0,"h":25772789297,"f":32769},"n":"NodeType","d":2985521,"h":21477822001,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":34362723889,"f":1},"s":{"r":0,"d":0,"h":38657691185,"f":1},"n":"Value","d":2985521,"h":30067756593,"f":1}],"m":[{"r":65537,"p":[{"n":"writer","p":58444892}],"n":"WriteTo","d":2985521,"h":42952658481,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58444892},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":2985521,"h":47247625777,"f":32769},{"r":65537,"p":[{"n":"sb","p":122945537}],"n":"AppendText","d":2985521,"h":51542593073,"f":32776},{"r":2264625,"n":"CloneNode","d":2985521,"h":55837560369,"f":32776},{"r":262145,"p":[{"n":"node","p":2264625}],"n":"DeepEquals","o":"@$1","d":2985521,"h":60132527665,"f":32776},{"r":655361,"n":"GetDeepHashCode","d":2985521,"h":64427494961,"f":32776}],"l":[{"t":1310721,"n":"text","d":2985521,"h":4297952817,"f":8}],"c":[{"p":[{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$3","d":2985521,"h":8592920113,"f":1},{"p":[{"n":"other","p":2985521}],"n":".ctor","o":"$ctor$4","d":2985521,"h":12887887409,"f":1},{"p":[{"n":"r","p":53398620}],"n":".ctor","o":"$ctor$5","d":2985521,"h":17182854705,"f":8}],"i":[13945948],"h":2985521}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XText`; }
        });
        
        $asm.$cls("$spxl.System.Xml.XPath.XNodeNavigator", ($self) => class XNodeNavigator extends $.$spx.System.Xml.XPath.XPathNavigator
        {
            /*string*/ static xmlPrefixNamespace = null;
            /*string*/ static xmlnsPrefixNamespace = null;
            /*int*/ static DocumentContentMask = 386;
            static /*ReadOnlySpan<int> */ get ElementContentMasks()
            {
                return this.$cacheElementContentMasks ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Int32))().$ctor$2([ 0, (1 << 1/*XmlNodeType.Element*/), 0, 0, (1 << 4/*XmlNodeType.CDATA*/) | (1 << 3/*XmlNodeType.Text*/), 0, 0, (1 << 7/*XmlNodeType.ProcessingInstruction*/), (1 << 8/*XmlNodeType.Comment*/), (1 << 1/*XmlNodeType.Element*/) | (1 << 4/*XmlNodeType.CDATA*/) | (1 << 3/*XmlNodeType.Text*/) | (1 << 7/*XmlNodeType.ProcessingInstruction*/) | (1 << 8/*XmlNodeType.Comment*/) ]);
            }
            /*int*/ static TextMask = 24;
            /*XAttribute?*/ static s_XmlNamespaceDeclaration = null;
            /*XObject*/ _source = null;
            /*XElement?*/ _parent = null;
            /*XmlNameTable*/ _nameTable = null;
            $ctor$3(/*XNode*/ node, /*XmlNameTable?*/ nameTable)
            {
                super.$ctor$2();
                {
                    this._source = node;
                    this._nameTable = nameTable ?? $.$spxl.System.Xml.XPath.XNodeNavigator.CreateNameTable();
                }
                return this;
            }
            $ctor$4(/*XNodeNavigator*/ other)
            {
                super.$ctor$2();
                {
                    this._source = other._source;
                    this._parent = other._parent;
                    this._nameTable = other._nameTable;
                }
                return this;
            }
            /*string */ get BaseURI()
            {
                if (this._source !== null)
                {
                    return this._source.BaseUri;
                }
                if (this._parent !== null)
                {
                    return this._parent.BaseUri;
                }
                return $.$spc.System.String.Empty;
            }
            /*bool */ get HasAttributes()
            {
                /*XElement?*/ let element = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (element !== null)
                {
                    var $en3 = element.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var attribute = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!attribute.IsNamespaceDeclaration)
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ get HasChildren()
            {
                /*XContainer?*/ let container = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (container !== null)
                {
                    var $en3 = container.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, node))
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ get IsEmptyElement()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                return e !== null && e.IsEmpty;
            }
            /*string */ get LocalName()
            {
                return this._nameTable.Add$1(this.GetLocalName());
            }
            /*string */ GetLocalName()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.LocalName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (this._parent !== null && a.Name.NamespaceName.length === 0)
                    {
                        return $.$spc.System.String.Empty;
                    }
                    return a.Name.LocalName;
                }
                /*XProcessingInstruction?*/ let p = $.$as(this._source, $.$spxl.System.Xml.Linq.XProcessingInstruction);
                if (p !== null)
                {
                    return p.Target;
                }
                return $.$spc.System.String.Empty;
            }
            /*string */ get Name()
            {
                /*string*/ let prefix = this.GetPrefix();
                if (prefix.length === 0)
                {
                    return this._nameTable.Add$1(this.GetLocalName());
                }
                return this._nameTable.Add$1($.$spc.System.String.Concat$8(prefix, ":", this.GetLocalName()));
            }
            /*string */ get NamespaceURI()
            {
                return this._nameTable.Add$1(this.GetNamespaceURI());
            }
            /*string */ GetNamespaceURI()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.NamespaceName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (this._parent !== null)
                    {
                        return $.$spc.System.String.Empty;
                    }
                    return a.Name.NamespaceName;
                }
                return $.$spc.System.String.Empty;
            }
            /*XmlNameTable */ get NameTable()
            {
                return this._nameTable;
            }
            /*XPathNodeType */ get NodeType()
            {
                if (this._source !== null)
                {
                    let $switch1 = this._source.NodeType;
                    switch($switch1)
                    {
                        case 1/*XmlNodeType.Element*/:
                        return 1/*XPathNodeType.Element*/;
                        case 2/*XmlNodeType.Attribute*/:
                        /*XAttribute*/ let attribute = $.$cast(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                        return attribute.IsNamespaceDeclaration ? 3/*XPathNodeType.Namespace*/ : 2/*XPathNodeType.Attribute*/;
                        case 9/*XmlNodeType.Document*/:
                        return 0/*XPathNodeType.Root*/;
                        case 8/*XmlNodeType.Comment*/:
                        return 8/*XPathNodeType.Comment*/;
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        return 7/*XPathNodeType.ProcessingInstruction*/;
                        default:
                        return 4/*XPathNodeType.Text*/;
                    }
                }
                return 4/*XPathNodeType.Text*/;
            }
            /*string */ get Prefix()
            {
                return this._nameTable.Add$1(this.GetPrefix());
            }
            /*string */ GetPrefix()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    /*string?*/ let prefix = e.GetPrefixOfNamespace(e.Name.Namespace);
                    if ($.$spc.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                    return $.$spc.System.String.Empty;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (this._parent !== null)
                    {
                        return $.$spc.System.String.Empty;
                    }
                    /*string?*/ let prefix = a.GetPrefixOfNamespace(a.Name.Namespace);
                    if ($.$spc.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                }
                return $.$spc.System.String.Empty;
            }
            /*object */ get UnderlyingObject()
            {
                return this._source;
            }
            /*string */ get Value()
            {
                if (this._source !== null)
                {
                    let $switch1 = this._source.NodeType;
                    switch($switch1)
                    {
                        case 1/*XmlNodeType.Element*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XElement)).Value;
                        case 2/*XmlNodeType.Attribute*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XAttribute)).Value;
                        case 9/*XmlNodeType.Document*/:
                        /*XElement?*/ let root = ($.$cast(this._source, $.$spxl.System.Xml.Linq.XDocument)).Root;
                        return root !== null ? root.Value : $.$spc.System.String.Empty;
                        case 3/*XmlNodeType.Text*/:
                        case 4/*XmlNodeType.CDATA*/:
                        return $.$spxl.System.Xml.XPath.XNodeNavigator.CollectText($.$cast(this._source, $.$spxl.System.Xml.Linq.XText));
                        case 8/*XmlNodeType.Comment*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XComment)).Value;
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XProcessingInstruction)).Data;
                        default:
                        return $.$spc.System.String.Empty;
                    }
                }
                return $.$spc.System.String.Empty;
            }
            /*XPathNavigator */ Clone()
            {
                return new $.$spxl.System.Xml.XPath.XNodeNavigator().$ctor$4(this);
            }
            /*bool */ IsSamePosition(/*XPathNavigator*/ navigator)
            {
                /*XNodeNavigator?*/ let other = $.$as(navigator, $.$spxl.System.Xml.XPath.XNodeNavigator);
                if (other === null)
                {
                    return false;
                }
                return $.$spxl.System.Xml.XPath.XNodeNavigator.IsSamePosition$1(this, other);
            }
            /*bool */ MoveTo(/*XPathNavigator*/ navigator)
            {
                /*XNodeNavigator?*/ let other = $.$as(navigator, $.$spxl.System.Xml.XPath.XNodeNavigator);
                if (other !== null)
                {
                    this._source = other._source;
                    this._parent = other._parent;
                    return true;
                }
                return false;
            }
            /*bool */ MoveToAttribute(/*string*/ localName, /*string*/ namespaceName)
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    var $en3 = e.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var attribute = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spc.System.String.op_Equality(attribute.Name.LocalName, localName) && $.$spc.System.String.op_Equality(attribute.Name.NamespaceName, namespaceName) && !attribute.IsNamespaceDeclaration)
                            {
                                this._source = attribute;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToChild(/*string*/ localName, /*string*/ namespaceName)
            {
                /*XContainer?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (c !== null)
                {
                    var $en3 = c.Elements().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spc.System.String.op_Equality(element.Name.LocalName, localName) && $.$spc.System.String.op_Equality(element.Name.NamespaceName, namespaceName))
                            {
                                this._source = element;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToChild$1(/*XPathNodeType*/ type)
            {
                /*XContainer?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (c !== null)
                {
                    /*int*/ let mask = $.$spxl.System.Xml.XPath.XNodeNavigator.GetElementContentMask(type);
                    if ((24/*TextMask*/ & mask) !== 0 && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(c) === null && $.$is(c, $.$spxl.System.Xml.Linq.XDocument))
                    {
                        mask &= ~24/*TextMask*/;
                    }
                    var $en3 = c.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (((1 << node.NodeType) & mask) !== 0)
                            {
                                this._source = node;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToFirstAttribute()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    var $en3 = e.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var attribute = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!attribute.IsNamespaceDeclaration)
                            {
                                this._source = attribute;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToFirstChild()
            {
                /*XContainer?*/ let container = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (container !== null)
                {
                    var $en3 = container.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, node))
                            {
                                this._source = node;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToFirstNamespace(/*XPathNamespaceScope*/ scope)
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    /*XAttribute?*/ let a = null;
                    switch(scope)
                    {
                        case 2/*XPathNamespaceScope.Local*/:
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationLocal(e);
                        break;
                        case 1/*XPathNamespaceScope.ExcludeXml*/:
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e);
                        while(a !== null && $.$spc.System.String.op_Equality(a.Name.LocalName, "xml"))
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                        }
                        break;
                        case 0/*XPathNamespaceScope.All*/:
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e) ?? $.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration();
                        break;
                    }
                    if (a !== null)
                    {
                        this._source = a;
                        this._parent = e;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToId(/*string*/ id)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$spxl.System.SR.NotSupported_MoveToId);
            }
            /*bool */ MoveToNamespace(/*string*/ localName)
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if ($.$spc.System.String.op_Equality(localName, "xmlns"))
                    {
                        return false;
                    }
                    if ($.$spc.System.String.op_Inequality(localName, null) && localName.length === 0)
                    {
                        localName = "xmlns";
                    }
                    /*XAttribute?*/ let a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e);
                    while(a !== null)
                    {
                        if ($.$spc.System.String.op_Equality(a.Name.LocalName, localName))
                        {
                            this._source = a;
                            this._parent = e;
                            return true;
                        }
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                    }
                    if ($.$spc.System.String.op_Equality(localName, "xml"))
                    {
                        this._source = $.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration();
                        this._parent = e;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToNext()
            {
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    /*XContainer?*/ let container = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentNode);
                    if (container !== null)
                    {
                        /*XNode?*/ let next;
                        for(/*XNode*/ let node = currentNode; node !== null; node = next)
                        {
                            next = node.NextNode;
                            if (next === null)
                            {
                                break;
                            }
                            if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, next) && !($.$is(node, $.$spxl.System.Xml.Linq.XText) && $.$is(next, $.$spxl.System.Xml.Linq.XText)))
                            {
                                this._source = next;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToNext$1(/*string*/ localName, /*string*/ namespaceName)
            {
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    var $en3 = currentNode.ElementsAfterSelf().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spc.System.String.op_Equality(element.Name.LocalName, localName) && $.$spc.System.String.op_Equality(element.Name.NamespaceName, namespaceName))
                            {
                                this._source = element;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToNext$2(/*XPathNodeType*/ type)
            {
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    /*XContainer?*/ let container = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentNode);
                    if (container !== null)
                    {
                        /*int*/ let mask = $.$spxl.System.Xml.XPath.XNodeNavigator.GetElementContentMask(type);
                        if ((24/*TextMask*/ & mask) !== 0 && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(container) === null && $.$is(container, $.$spxl.System.Xml.Linq.XDocument))
                        {
                            mask &= ~24/*TextMask*/;
                        }
                        /*XNode?*/ let next;
                        for(/*XNode*/ let node = currentNode; ; node = next)
                        {
                            next = node.NextNode;
                            if (next === null)
                            {
                                break;
                            }
                            if (((1 << next.NodeType) & mask) !== 0 && !($.$is(node, $.$spxl.System.Xml.Linq.XText) && $.$is(next, $.$spxl.System.Xml.Linq.XText)))
                            {
                                this._source = next;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToNextAttribute()
            {
                /*XAttribute?*/ let currentAttribute = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (currentAttribute !== null && this._parent === null)
                {
                    /*XElement?*/ let e = $.$cast($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentAttribute), $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        for(/*XAttribute?*/ let attribute = currentAttribute.NextAttribute; attribute !== null; attribute = attribute.NextAttribute)
                        {
                            if (!attribute.IsNamespaceDeclaration)
                            {
                                this._source = attribute;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToNextNamespace(/*XPathNamespaceScope*/ scope)
            {
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null && this._parent !== null && !$.$spxl.System.Xml.XPath.XNodeNavigator.IsXmlNamespaceDeclaration(a))
                {
                    switch(scope)
                    {
                        case 2/*XPathNamespaceScope.Local*/:
                        if ($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(a) !== this._parent)
                        {
                            return false;
                        }
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationLocal(a);
                        break;
                        case 1/*XPathNamespaceScope.ExcludeXml*/:
                        do
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                        }
                        while(a !== null && ($.$spc.System.String.op_Equality(a.Name.LocalName, "xml") || $.$spxl.System.Xml.XPath.XNodeNavigator.HasNamespaceDeclarationInScope(a, this._parent)));
                        break;
                        case 0/*XPathNamespaceScope.All*/:
                        do
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                        }
                        while(a !== null && $.$spxl.System.Xml.XPath.XNodeNavigator.HasNamespaceDeclarationInScope(a, this._parent));
                        if (a === null && !$.$spxl.System.Xml.XPath.XNodeNavigator.HasNamespaceDeclarationInScope($.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration(), this._parent))
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration();
                        }
                        break;
                    }
                    if (a !== null)
                    {
                        this._source = a;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToParent()
            {
                if (this._parent !== null)
                {
                    this._source = this._parent;
                    this._parent = null;
                    return true;
                }
                /*XNode?*/ let parentNode = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(this._source);
                if (parentNode !== null)
                {
                    this._source = parentNode;
                    return true;
                }
                return false;
            }
            /*bool */ MoveToPrevious()
            {
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    /*XContainer?*/ let container = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentNode);
                    if (container !== null)
                    {
                        /*XNode?*/ let previous = null;
                        var $en4 = container.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var node = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (node === currentNode)
                                {
                                    if (previous !== null)
                                    {
                                        this._source = previous;
                                        return true;
                                    }
                                    return false;
                                }
                                if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, node))
                                {
                                    previous = node;
                                }
                            }
                        }
                    }
                }
                return false;
            }
            /*XmlReader */ ReadSubtree()
            {
                /*XContainer?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (c === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_BadNodeType, $.$box(this.NodeType, $.$spx.System.Xml.XPath.XPathNodeType)));
                }
                return c.CreateReader();
            }
            /*bool */ System$Xml$IXmlLineInfo$HasLineInfo()
            {
                /*IXmlLineInfo*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                if (li !== null)
                {
                    return li.System$Xml$IXmlLineInfo$HasLineInfo();
                }
                return false;
            }
            /*int */ get System$Xml$IXmlLineInfo$LineNumber()
            {
                /*IXmlLineInfo*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                if (li !== null)
                {
                    return li.System$Xml$IXmlLineInfo$LineNumber;
                }
                return 0;
            }
            /*int */ get System$Xml$IXmlLineInfo$LinePosition()
            {
                /*IXmlLineInfo*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                if (li !== null)
                {
                    return li.System$Xml$IXmlLineInfo$LinePosition;
                }
                return 0;
            }
            static /*string */ CollectText(/*XText*/ n)
            {
                /*string*/ let s = n.Value;
                if ($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n) !== null)
                {
                    var $en3 = n.NodesAfterSelf().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            /*XText?*/ let t = $.$as(node, $.$spxl.System.Xml.Linq.XText);
                            if (t === null)
                            {
                                break;
                            }
                            s += t.Value;
                        }
                    }
                }
                return s;
            }
            static /*NameTable */ CreateNameTable()
            {
                /*var*/ let nameTable = new $.$spx.System.Xml.NameTable().$ctor$2();
                nameTable.Add$1($.$spc.System.String.Empty);
                nameTable.Add$1($.$spxl.System.Xml.XPath.XNodeNavigator.xmlnsPrefixNamespace);
                nameTable.Add$1($.$spxl.System.Xml.XPath.XNodeNavigator.xmlPrefixNamespace);
                return nameTable;
            }
            static /*bool */ IsContent(/*XContainer*/ c, /*XNode*/ n)
            {
                if ($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(c) !== null || $.$is(c, $.$spxl.System.Xml.Linq.XElement))
                {
                    return true;
                }
                return ((1 << n.NodeType) & 386/*DocumentContentMask*/) !== 0;
            }
            static /*bool */ IsSamePosition$1(/*XNodeNavigator*/ n1, /*XNodeNavigator*/ n2)
            {
                return n1._source === n2._source && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n1._source) === $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n2._source);
            }
            static /*bool */ IsXmlNamespaceDeclaration(/*XAttribute*/ a)
            {
                return $.$cast(a, $.$spc.System.Object) === $.$cast($.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration(), $.$spc.System.Object);
            }
            static /*int */ GetElementContentMask(/*XPathNodeType*/ type)
            {
                return $.$spxl.System.Xml.XPath.XNodeNavigator.ElementContentMasks.get_Item(type).$v;
            }
            static /*XAttribute? */ GetFirstNamespaceDeclarationGlobal(/*XElement*/ e)
            {
                /*XElement?*/ let ce = e;
                do
                {
                    /*XAttribute?*/ let a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationLocal(ce);
                    if (a !== null)
                    {
                        return a;
                    }
                    ce = ce.Parent;
                }
                while(ce !== null);
                return null;
            }
            static /*XAttribute? */ GetFirstNamespaceDeclarationLocal(/*XElement*/ e)
            {
                var $en2 = e.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var attribute = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (attribute.IsNamespaceDeclaration)
                        {
                            return attribute;
                        }
                    }
                }
                return null;
            }
            static /*XAttribute? */ GetNextNamespaceDeclarationGlobal(/*XAttribute*/ a)
            {
                /*XElement?*/ let e = $.$cast($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(a), $.$spxl.System.Xml.Linq.XElement);
                if (e === null)
                {
                    return null;
                }
                /*XAttribute?*/ let next = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationLocal(a);
                if (next !== null)
                {
                    return next;
                }
                e = e.Parent;
                if (e === null)
                {
                    return null;
                }
                return $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e);
            }
            static /*XAttribute? */ GetNextNamespaceDeclarationLocal(/*XAttribute*/ a)
            {
                /*XElement?*/ let e = a.Parent;
                if (e === null)
                {
                    return null;
                }
                /*XAttribute?*/ let ca = a;
                ca = ca.NextAttribute;
                while(ca !== null)
                {
                    if (ca.IsNamespaceDeclaration)
                    {
                        return ca;
                    }
                    ca = ca.NextAttribute;
                }
                return null;
            }
            static /*XAttribute */ GetXmlNamespaceDeclaration()
            {
                if ($.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration === null)
                {
                    $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spxl.System.Xml.Linq.XAttribute, $.$ref(() => $.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration, ($v) => $.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration = $v, $.$spxl.System.Xml.Linq.XAttribute), new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2($.$spxl.System.Xml.Linq.XNamespace.Xmlns.GetName("xml"), $.$spxl.System.Xml.XPath.XNodeNavigator.xmlPrefixNamespace), null);
                }
                return $.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration;
            }
            static /*bool */ HasNamespaceDeclarationInScope(/*XAttribute*/ a, /*XElement*/ e)
            {
                /*XName*/ let name = a.Name;
                /*XElement?*/ let ce = e;
                while(ce !== null && ce !== $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(a))
                {
                    if (ce.Attribute(name) !== null)
                    {
                        return true;
                    }
                    ce = ce.Parent;
                }
                return false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.xmlPrefixNamespace = $.$spxl.System.Xml.Linq.XNamespace.Xml.NamespaceName;
                }
                {
                    this.xmlnsPrefixNamespace = $.$spxl.System.Xml.Linq.XNamespace.Xmlns.NamespaceName;
                }
            }
            static $h = 3313201;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":59296860,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":21478149681,"f":34},"n":"ElementContentMasks","d":3313201,"h":17183182385,"f":34},{"p":1310721,"g":{"r":0,"d":0,"h":60132855345,"f":32769},"n":"BaseURI","d":3313201,"h":55837888049,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":68722789937,"f":32769},"n":"HasAttributes","d":3313201,"h":64427822641,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":77312724529,"f":32769},"n":"HasChildren","d":3313201,"h":73017757233,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":85902659121,"f":32769},"n":"IsEmptyElement","d":3313201,"h":81607691825,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":94492593713,"f":32769},"n":"LocalName","d":3313201,"h":90197626417,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":107377495601,"f":32769},"n":"Name","d":3313201,"h":103082528305,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":115967430193,"f":32769},"n":"NamespaceURI","d":3313201,"h":111672462897,"f":32769},{"p":52087900,"g":{"r":0,"d":0,"h":128852332081,"f":32769},"n":"NameTable","d":3313201,"h":124557364785,"f":32769},{"p":59886684,"g":{"r":0,"d":0,"h":137442266673,"f":32769},"n":"NodeType","d":3313201,"h":133147299377,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":146032201265,"f":32769},"n":"Prefix","d":3313201,"h":141737233969,"f":32769},{"p":131073,"g":{"r":0,"d":0,"h":158917103153,"f":32769},"n":"UnderlyingObject","d":3313201,"h":154622135857,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":167507037745,"f":32769},"n":"Value","d":3313201,"h":163212070449,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":261996318257,"f":2},"n":"{13945948}.LineNumber","o":"System$Xml$IXmlLineInfo$LineNumber","d":3313201,"h":257701350961,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":270586252849,"f":2},"n":"{13945948}.LinePosition","o":"System$Xml$IXmlLineInfo$LinePosition","d":3313201,"h":266291285553,"f":2}],"m":[{"r":1310721,"n":"GetLocalName","d":3313201,"h":98787561009,"f":2},{"r":1310721,"n":"GetNamespaceURI","d":3313201,"h":120262397489,"f":2},{"r":1310721,"n":"GetPrefix","d":3313201,"h":150327168561,"f":2},{"r":59296860,"n":"Clone","d":3313201,"h":171802005041,"f":32769},{"r":262145,"p":[{"n":"navigator","p":59296860}],"n":"IsSamePosition","d":3313201,"h":176096972337,"f":32769},{"r":262145,"p":[{"n":"navigator","p":59296860}],"n":"MoveTo","d":3313201,"h":180391939633,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"MoveToAttribute","d":3313201,"h":184686906929,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"MoveToChild","d":3313201,"h":188981874225,"f":32769},{"r":262145,"p":[{"n":"type","p":59886684}],"n":"MoveToChild","o":"@$1","d":3313201,"h":193276841521,"f":32769},{"r":262145,"n":"MoveToFirstAttribute","d":3313201,"h":197571808817,"f":32769},{"r":262145,"n":"MoveToFirstChild","d":3313201,"h":201866776113,"f":32769},{"r":262145,"p":[{"n":"scope","p":59231324}],"n":"MoveToFirstNamespace","d":3313201,"h":206161743409,"f":32769},{"r":262145,"p":[{"n":"id","p":1310721}],"n":"MoveToId","d":3313201,"h":210456710705,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721}],"n":"MoveToNamespace","d":3313201,"h":214751678001,"f":32769},{"r":262145,"n":"MoveToNext","d":3313201,"h":219046645297,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"MoveToNext","o":"@$1","d":3313201,"h":223341612593,"f":32769},{"r":262145,"p":[{"n":"type","p":59886684}],"n":"MoveToNext","o":"@$2","d":3313201,"h":227636579889,"f":32769},{"r":262145,"n":"MoveToNextAttribute","d":3313201,"h":231931547185,"f":32769},{"r":262145,"p":[{"n":"scope","p":59231324}],"n":"MoveToNextNamespace","d":3313201,"h":236226514481,"f":32769},{"r":262145,"n":"MoveToParent","d":3313201,"h":240521481777,"f":32769},{"r":262145,"n":"MoveToPrevious","d":3313201,"h":244816449073,"f":32769},{"r":53398620,"n":"ReadSubtree","d":3313201,"h":249111416369,"f":32769},{"r":1310721,"p":[{"n":"n","p":2985521}],"n":"CollectText","d":3313201,"h":274881220145,"f":34},{"r":14273628,"n":"CreateNameTable","d":3313201,"h":279176187441,"f":34},{"r":262145,"p":[{"n":"c","p":1347121},{"n":"n","p":2264625}],"n":"IsContent","d":3313201,"h":283471154737,"f":34},{"r":262145,"p":[{"n":"n1","p":3313201},{"n":"n2","p":3313201}],"n":"IsSamePosition","o":"@$1","d":3313201,"h":287766122033,"f":34},{"r":262145,"p":[{"n":"a","p":1150513}],"n":"IsXmlNamespaceDeclaration","d":3313201,"h":292061089329,"f":34},{"r":655361,"p":[{"n":"type","p":59886684}],"n":"GetElementContentMask","d":3313201,"h":296356056625,"f":34},{"r":1150513,"p":[{"n":"e","p":1674801}],"n":"GetFirstNamespaceDeclarationGlobal","d":3313201,"h":300651023921,"f":34},{"r":1150513,"p":[{"n":"e","p":1674801}],"n":"GetFirstNamespaceDeclarationLocal","d":3313201,"h":304945991217,"f":34},{"r":1150513,"p":[{"n":"a","p":1150513}],"n":"GetNextNamespaceDeclarationGlobal","d":3313201,"h":309240958513,"f":34},{"r":1150513,"p":[{"n":"a","p":1150513}],"n":"GetNextNamespaceDeclarationLocal","d":3313201,"h":313535925809,"f":34},{"r":1150513,"n":"GetXmlNamespaceDeclaration","d":3313201,"h":317830893105,"f":34},{"r":262145,"p":[{"n":"a","p":1150513},{"n":"e","p":1674801}],"n":"HasNamespaceDeclarationInScope","d":3313201,"h":322125860401,"f":34}],"l":[{"t":1310721,"n":"xmlPrefixNamespace","d":3313201,"h":4298280497,"f":40},{"t":1310721,"n":"xmlnsPrefixNamespace","d":3313201,"h":8593247793,"f":40},{"t":655361,"n":"DocumentContentMask","d":3313201,"h":12888215089,"f":34},{"t":655361,"n":"TextMask","d":3313201,"h":25773116977,"f":34},{"t":1150513,"n":"s_XmlNamespaceDeclaration","d":3313201,"h":30068084273,"f":34},{"t":2592305,"n":"_source","d":3313201,"h":34363051569,"f":2},{"t":1674801,"n":"_parent","d":3313201,"h":38658018865,"f":2},{"t":52087900,"n":"_nameTable","d":3313201,"h":42952986161,"f":2}],"c":[{"p":[{"n":"node","p":2264625},{"n":"nameTable","p":52087900}],"n":".ctor","o":"$ctor$3","d":3313201,"h":47247953457,"f":1},{"p":[{"n":"other","p":3313201}],"n":".ctor","o":"$ctor$4","d":3313201,"h":51542920753,"f":1}],"i":[57147393,58575964,14011484,13945948],"h":3313201}; }
            static get $b() { return $.$spx.System.Xml.XPath.XPathNavigator; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spx.System.Xml.XPath.IXPathNavigable, $.$spx.System.Xml.IXmlNamespaceResolver, $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.XPath.XNodeNavigator`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.XObjectChange", ($self) => class XObjectChange extends $.$spc.System.Enum
        {
            static Add = 0;
            static Remove = 1;
            static Name = 2;
            static Value = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Remove": 1n,
                    "Name": 2n,
                    "Value": 3n
                };
            }
            static $h = 2657841;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2657841,"n":"Add","d":2657841,"h":4297625137,"f":33},{"t":2657841,"n":"Remove","d":2657841,"h":8592592433,"f":33},{"t":2657841,"n":"Name","d":2657841,"h":12887559729,"f":33},{"t":2657841,"n":"Value","d":2657841,"h":17182527025,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2657841,"h":21477494321,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2657841}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.XObjectChange`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.LoadOptions", ($self) => class LoadOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static PreserveWhitespace = 1;
            static SetBaseUri = 2;
            static SetLineInfo = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "PreserveWhitespace": 1n,
                    "SetBaseUri": 2n,
                    "SetLineInfo": 4n
                };
            }
            static $h = 691761;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":691761,"n":"None","d":691761,"h":4295659057,"f":33},{"t":691761,"n":"PreserveWhitespace","d":691761,"h":8590626353,"f":33},{"t":691761,"n":"SetBaseUri","d":691761,"h":12885593649,"f":33},{"t":691761,"n":"SetLineInfo","d":691761,"h":17180560945,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":691761,"h":21475528241,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":691761,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.LoadOptions`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.SaveOptions", ($self) => class SaveOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static DisableFormatting = 1;
            static OmitDuplicateNamespaces = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "DisableFormatting": 1n,
                    "OmitDuplicateNamespaces": 2n
                };
            }
            static $h = 1019441;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1019441,"n":"None","d":1019441,"h":4295986737,"f":33},{"t":1019441,"n":"DisableFormatting","d":1019441,"h":8590954033,"f":33},{"t":1019441,"n":"OmitDuplicateNamespaces","d":1019441,"h":12885921329,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1019441,"h":17180888625,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1019441,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.SaveOptions`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.ReaderOptions", ($self) => class ReaderOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static OmitDuplicateNamespaces = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OmitDuplicateNamespaces": 1n
                };
            }
            static $h = 953905;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":953905,"n":"None","d":953905,"h":4295921201,"f":33},{"t":953905,"n":"OmitDuplicateNamespaces","d":953905,"h":8590888497,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":953905,"h":12885855793,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":953905,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.ReaderOptions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XDocument", ($self) => class XDocument extends $.$spxl.System.Xml.Linq.XContainer
        {
            /*XDeclaration?*/ _declaration = null;
            $ctor$5()
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            $ctor$6(/*params object?[]*/ content)
            {
                this.$ctor$5();
                {
                    this.AddContentSkipNotify(content);
                }
                return this;
            }
            $ctor$7(/*XDeclaration?*/ declaration, /*params object?[]*/ content)
            {
                this.$ctor$6(content);
                {
                    this._declaration = declaration;
                }
                return this;
            }
            $ctor$8(/*XDocument*/ other)
            {
                super.$ctor$4(other);
                {
                    if (other._declaration !== null)
                    {
                        this._declaration = new $.$spxl.System.Xml.Linq.XDeclaration().$ctor$2(other._declaration);
                    }
                }
                return this;
            }
            /*XDeclaration? */ get Declaration()
            {
                return this._declaration;
            }
            /*XDeclaration? */ set Declaration(value)
            {
                this._declaration = value;
            }
            /*XDocumentType? */ get DocumentType()
            {
                return this.GetFirstNode($.$spxl.System.Xml.Linq.XDocumentType);
            }
            /*XmlNodeType */ get NodeType()
            {
                return 9/*XmlNodeType.Document*/;
            }
            /*XElement? */ get Root()
            {
                return this.GetFirstNode($.$spxl.System.Xml.Linq.XElement);
            }
            static /*XDocument */ Load(/*string*/ uri)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Load$1(uri, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Load$1(/*string*/ uri, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$1(uri, rs);
                    return $.$spxl.System.Xml.Linq.XDocument.Load$7(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*XDocument */ Load$2(/*Stream*/ stream)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Load$3(stream, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Load$3(/*Stream*/ stream, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$4(stream, rs);
                    return $.$spxl.System.Xml.Linq.XDocument.Load$7(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*Task<XDocument> *//*async*/  LoadAsync(/*Stream*/ stream, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument), $.$spxl.System.Xml.Linq.XDocument, async () => 
                {
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$4(stream, rs);
                        return await $.$spxl.System.Xml.Linq.XDocument.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*XDocument */ Load$4(/*TextReader*/ textReader)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Load$5(textReader, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Load$5(/*TextReader*/ textReader, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$8(textReader, rs);
                    return $.$spxl.System.Xml.Linq.XDocument.Load$7(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*Task<XDocument> *//*async*/  LoadAsync$1(/*TextReader*/ textReader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument), $.$spxl.System.Xml.Linq.XDocument, async () => 
                {
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$8(textReader, rs);
                        return await $.$spxl.System.Xml.Linq.XDocument.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*XDocument */ Load$6(/*XmlReader*/ reader)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Load$7(reader, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Load$7(/*XmlReader*/ reader, /*LoadOptions*/ options)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                if (reader.ReadState === 0/*ReadState.Initial*/)
                {
                    reader.Read();
                }
                /*XDocument*/ let d = $.$spxl.System.Xml.Linq.XDocument.InitLoad(reader, options);
                d.ReadContentFrom$1(reader, options);
                if (!reader.EOF)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                }
                if (d.Root === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingRoot);
                }
                return d;
            }
            static /*Task<XDocument> */ LoadAsync$2(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spxl.System.Xml.Linq.XDocument, cancellationToken);
                }
                return $.$spxl.System.Xml.Linq.XDocument.LoadAsyncInternal(reader, options, cancellationToken);
            }
            static /*Task<XDocument> *//*async*/  LoadAsyncInternal(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument), $.$spxl.System.Xml.Linq.XDocument, async () => 
                {
                    if (reader.ReadState === 0/*ReadState.Initial*/)
                    {
                        await reader.ReadAsync().ConfigureAwait$2(false);
                    }
                    /*XDocument*/ let d = $.$spxl.System.Xml.Linq.XDocument.InitLoad(reader, options);
                    await d.ReadContentFromAsync$1(reader, options, cancellationToken).ConfigureAwait(false);
                    if (!reader.EOF)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                    }
                    if (d.Root === null)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingRoot);
                    }
                    return d;
                });
            }
            static /*XDocument */ InitLoad(/*XmlReader*/ reader, /*LoadOptions*/ options)
            {
                /*XDocument*/ let d = new $.$spxl.System.Xml.Linq.XDocument().$ctor$5();
                if ((options & 2/*LoadOptions.SetBaseUri*/) !== 0)
                {
                    /*string?*/ let baseUri = reader.BaseURI;
                    if (!$.$spc.System.String.IsNullOrEmpty(baseUri))
                    {
                        d.SetBaseUri(baseUri);
                    }
                }
                if ((options & 4/*LoadOptions.SetLineInfo*/) !== 0)
                {
                    /*IXmlLineInfo?*/ let li = $.$as(reader, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null && li.System$Xml$IXmlLineInfo$HasLineInfo())
                    {
                        d.SetLineInfo(li.System$Xml$IXmlLineInfo$LineNumber, li.System$Xml$IXmlLineInfo$LinePosition);
                    }
                }
                if (reader.NodeType === 17/*XmlNodeType.XmlDeclaration*/)
                {
                    d.Declaration = new $.$spxl.System.Xml.Linq.XDeclaration().$ctor$3(reader);
                }
                return d;
            }
            static /*XDocument */ Parse(/*string*/ text)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Parse$1(text, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Parse$1(/*string*/ text, /*LoadOptions*/ options)
            {
                let sr = null;
                try
                {
                    sr = new $.$spc.System.IO.StringReader().$ctor$3(text);
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$8(sr, rs);
                        return $.$spxl.System.Xml.Linq.XDocument.Load$7(r, options);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                }
                finally
                {
                    sr?.System$IDisposable$Dispose();
                }
            }
            /*void */ Save(/*Stream*/ stream)
            {
                this.Save$1(stream, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save$1(/*Stream*/ stream, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                if (this._declaration !== null && !$.$spc.System.String.IsNullOrEmpty(this._declaration.Encoding))
                {
                    try
                    {
                        ws.Encoding = $.$spc.System.Text.Encoding.GetEncoding$2(this._declaration.Encoding);
                    }
                    catch($e)
                    {
                    }
                }
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$3(stream, ws);
                    this.Save$4(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*Task *//*async*/  SaveAsync(/*Stream*/ stream, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    if (this._declaration !== null && !$.$spc.System.String.IsNullOrEmpty(this._declaration.Encoding))
                    {
                        try
                        {
                            ws.Encoding = $.$spc.System.Text.Encoding.GetEncoding$2(this._declaration.Encoding);
                        }
                        catch($e)
                        {
                        }
                    }
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create$3(stream, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$spc.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.WriteToAsync(w, cancellationToken).ConfigureAwait(false);
                        await w.FlushAsync().ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            /*void */ Save$2(/*TextWriter*/ textWriter)
            {
                this.Save$3(textWriter, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save$3(/*TextWriter*/ textWriter, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$5(textWriter, ws);
                    this.Save$4(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*void */ Save$4(/*XmlWriter*/ writer)
            {
                this.WriteTo(writer);
            }
            /*Task *//*async*/  SaveAsync$1(/*TextWriter*/ textWriter, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create$5(textWriter, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$spc.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.WriteToAsync(w, cancellationToken).ConfigureAwait(false);
                        await w.FlushAsync().ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            /*void */ Save$5(/*string*/ fileName)
            {
                this.Save$6(fileName, this.GetSaveOptionsFromAnnotations());
            }
            /*Task */ SaveAsync$2(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return this.WriteToAsync(writer, cancellationToken);
            }
            /*void */ Save$6(/*string*/ fileName, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                if (this._declaration !== null && !$.$spc.System.String.IsNullOrEmpty(this._declaration.Encoding))
                {
                    try
                    {
                        ws.Encoding = $.$spc.System.Text.Encoding.GetEncoding$2(this._declaration.Encoding);
                    }
                    catch($e)
                    {
                    }
                }
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$1(fileName, ws);
                    this.Save$4(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (this._declaration !== null && $.$spc.System.String.op_Equality(this._declaration.Standalone, "yes"))
                {
                    writer.WriteStartDocument$1(true);
                }
                else if (this._declaration !== null && $.$spc.System.String.op_Equality(this._declaration.Standalone, "no"))
                {
                    writer.WriteStartDocument$1(false);
                }
                else 
                {
                    writer.WriteStartDocument();
                }
                this.WriteContentTo(writer);
                writer.WriteEndDocument();
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return this.WriteToAsyncInternal(writer, cancellationToken);
            }
            /*Task *//*async*/  WriteToAsyncInternal(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*Task*/ let tStart;
                    if (this._declaration !== null && $.$spc.System.String.op_Equality(this._declaration.Standalone, "yes"))
                    {
                        tStart = writer.WriteStartDocumentAsync$1(true);
                    }
                    else if (this._declaration !== null && $.$spc.System.String.op_Equality(this._declaration.Standalone, "no"))
                    {
                        tStart = writer.WriteStartDocumentAsync$1(false);
                    }
                    else 
                    {
                        tStart = writer.WriteStartDocumentAsync();
                    }
                    await tStart.ConfigureAwait(false);
                    await this.WriteContentToAsync(writer, cancellationToken).ConfigureAwait(false);
                    await writer.WriteEndDocumentAsync().ConfigureAwait(false);
                });
            }
            /*void */ AddAttribute(/*XAttribute*/ a)
            {
                throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_AddAttribute);
            }
            /*void */ AddAttributeSkipNotify(/*XAttribute*/ a)
            {
                throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_AddAttribute);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XDocument().$ctor$8(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XDocument?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XDocument);
                return other !== null && this.ContentsEqual(other);
            }
            /*int */ GetDeepHashCode()
            {
                return this.ContentsHashCode();
            }
            /*T? */ GetFirstNode(T, )
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*T?*/ let e = $.$as(n, T);
                        if ($.$box(e, T) !== null)
                        {
                            return e;
                        }
                    }
                    while(n !== this.content);
                }
                return null;
            }
            /*void */ ValidateNode(/*XNode*/ node, /*XNode?*/ previous)
            {
                let $switch1 = node.NodeType;
                switch($switch1)
                {
                    case 3/*XmlNodeType.Text*/:
                    this.ValidateString(($.$cast(node, $.$spxl.System.Xml.Linq.XText)).Value);
                    break;
                    case 1/*XmlNodeType.Element*/:
                    this.ValidateDocument(previous, 10/*XmlNodeType.DocumentType*/, 0/*XmlNodeType.None*/);
                    break;
                    case 10/*XmlNodeType.DocumentType*/:
                    this.ValidateDocument(previous, 0/*XmlNodeType.None*/, 1/*XmlNodeType.Element*/);
                    break;
                    case 4/*XmlNodeType.CDATA*/:
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_AddNode, $.$box(4/*XmlNodeType.CDATA*/, $.$spx.System.Xml.XmlNodeType)));
                    case 9/*XmlNodeType.Document*/:
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_AddNode, $.$box(9/*XmlNodeType.Document*/, $.$spx.System.Xml.XmlNodeType)));
                }
            }
            /*void */ ValidateDocument(/*XNode?*/ previous, /*XmlNodeType*/ allowBefore, /*XmlNodeType*/ allowAfter)
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    if (previous === null)
                    {
                        allowBefore = allowAfter;
                    }
                    do
                    {
                        n = n.next;
                        /*XmlNodeType*/ let nt = n.NodeType;
                        if (nt === 1/*XmlNodeType.Element*/ || nt === 10/*XmlNodeType.DocumentType*/)
                        {
                            if (nt !== allowBefore)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_DocumentStructure);
                            }
                            allowBefore = 0/*XmlNodeType.None*/;
                        }
                        if (n === previous)
                        {
                            allowBefore = allowAfter;
                        }
                    }
                    while(n !== this.content);
                }
            }
            /*void */ ValidateString(/*string*/ s)
            {
                if ($.$spc.System.MemoryExtensions.ContainsAnyExcept$11($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(s), $.$spc.System.String.op_Implicit(" \t\r\n")))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_AddNonWhitespace);
                }
            }
            static $h = 1543729;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1347121,"p":[{"p":1478193,"g":{"r":0,"d":0,"h":30066314801,"f":1},"s":{"r":0,"d":0,"h":34361282097,"f":1},"n":"Declaration","d":1543729,"h":25771347505,"f":1},{"p":1609265,"g":{"r":0,"d":0,"h":42951216689,"f":1},"n":"DocumentType","d":1543729,"h":38656249393,"f":1},{"p":52874332,"g":{"r":0,"d":0,"h":51541151281,"f":32769},"n":"NodeType","d":1543729,"h":47246183985,"f":32769},{"p":1674801,"g":{"r":0,"d":0,"h":60131085873,"f":1},"n":"Root","d":1543729,"h":55836118577,"f":1}],"m":[{"r":1543729,"p":[{"n":"uri","p":1310721}],"n":"Load","d":1543729,"h":64426053169,"f":33},{"r":1543729,"p":[{"n":"uri","p":1310721},{"n":"options","p":691761}],"n":"Load","o":"@$1","d":1543729,"h":68721020465,"f":33},{"r":1543729,"p":[{"n":"stream","p":62128129}],"n":"Load","o":"@$2","d":1543729,"h":73015987761,"f":33},{"r":1543729,"p":[{"n":"stream","p":62128129},{"n":"options","p":691761}],"n":"Load","o":"@$3","d":1543729,"h":77310955057,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,"p":[{"n":"stream","p":62128129},{"n":"options","p":691761},{"n":"cancellationToken","p":125960193}],"n":"LoadAsync","d":1543729,"h":81605922353,"f":4129},{"r":1543729,"p":[{"n":"textReader","p":62849025}],"n":"Load","o":"@$4","d":1543729,"h":85900889649,"f":33},{"r":1543729,"p":[{"n":"textReader","p":62849025},{"n":"options","p":691761}],"n":"Load","o":"@$5","d":1543729,"h":90195856945,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,"p":[{"n":"textReader","p":62849025},{"n":"options","p":691761},{"n":"cancellationToken","p":125960193}],"n":"LoadAsync","o":"@$1","d":1543729,"h":94490824241,"f":4129},{"r":1543729,"p":[{"n":"reader","p":53398620}],"n":"Load","o":"@$6","d":1543729,"h":98785791537,"f":33},{"r":1543729,"p":[{"n":"reader","p":53398620},{"n":"options","p":691761}],"n":"Load","o":"@$7","d":1543729,"h":103080758833,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,"p":[{"n":"reader","p":53398620},{"n":"options","p":691761},{"n":"cancellationToken","p":125960193}],"n":"LoadAsync","o":"@$2","d":1543729,"h":107375726129,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,"p":[{"n":"reader","p":53398620},{"n":"options","p":691761},{"n":"cancellationToken","p":125960193}],"n":"LoadAsyncInternal","d":1543729,"h":111670693425,"f":4130},{"r":1543729,"p":[{"n":"reader","p":53398620},{"n":"options","p":691761}],"n":"InitLoad","d":1543729,"h":115965660721,"f":34},{"r":1543729,"p":[{"n":"text","p":1310721}],"n":"Parse","d":1543729,"h":120260628017,"f":33},{"r":1543729,"p":[{"n":"text","p":1310721},{"n":"options","p":691761}],"n":"Parse","o":"@$1","d":1543729,"h":124555595313,"f":33},{"r":65537,"p":[{"n":"stream","p":62128129}],"n":"Save","d":1543729,"h":128850562609,"f":1},{"r":65537,"p":[{"n":"stream","p":62128129},{"n":"options","p":1019441}],"n":"Save","o":"@$1","d":1543729,"h":133145529905,"f":1},{"r":133300225,"p":[{"n":"stream","p":62128129},{"n":"options","p":1019441},{"n":"cancellationToken","p":125960193}],"n":"SaveAsync","d":1543729,"h":137440497201,"f":4097},{"r":65537,"p":[{"n":"textWriter","p":62980097}],"n":"Save","o":"@$2","d":1543729,"h":141735464497,"f":1},{"r":65537,"p":[{"n":"textWriter","p":62980097},{"n":"options","p":1019441}],"n":"Save","o":"@$3","d":1543729,"h":146030431793,"f":1},{"r":65537,"p":[{"n":"writer","p":58444892}],"n":"Save","o":"@$4","d":1543729,"h":150325399089,"f":1},{"r":133300225,"p":[{"n":"textWriter","p":62980097},{"n":"options","p":1019441},{"n":"cancellationToken","p":125960193}],"n":"SaveAsync","o":"@$1","d":1543729,"h":154620366385,"f":4097},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"Save","o":"@$5","d":1543729,"h":158915333681,"f":1},{"r":133300225,"p":[{"n":"writer","p":58444892},{"n":"cancellationToken","p":125960193}],"n":"SaveAsync","o":"@$2","d":1543729,"h":163210300977,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"options","p":1019441}],"n":"Save","o":"@$6","d":1543729,"h":167505268273,"f":1},{"r":65537,"p":[{"n":"writer","p":58444892}],"n":"WriteTo","d":1543729,"h":171800235569,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58444892},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":1543729,"h":176095202865,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58444892},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsyncInternal","d":1543729,"h":180390170161,"f":4098},{"r":65537,"p":[{"n":"a","p":1150513}],"n":"AddAttribute","d":1543729,"h":184685137457,"f":32776},{"r":65537,"p":[{"n":"a","p":1150513}],"n":"AddAttributeSkipNotify","d":1543729,"h":188980104753,"f":32776},{"r":2264625,"n":"CloneNode","d":1543729,"h":193275072049,"f":32776},{"r":262145,"p":[{"n":"node","p":2264625}],"n":"DeepEquals","o":"@$1","d":1543729,"h":197570039345,"f":32776},{"r":655361,"n":"GetDeepHashCode","d":1543729,"h":201865006641,"f":32776},{"r":(T) => T.$h,"g":["T"],"n":"GetFirstNode","d":1543729,"h":206159973937,"f":131074},{"r":65537,"p":[{"n":"node","p":2264625},{"n":"previous","p":2264625}],"n":"ValidateNode","d":1543729,"h":210454941233,"f":32776},{"r":65537,"p":[{"n":"previous","p":2264625},{"n":"allowBefore","p":52874332},{"n":"allowAfter","p":52874332}],"n":"ValidateDocument","d":1543729,"h":214749908529,"f":2},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"ValidateString","d":1543729,"h":219044875825,"f":32776}],"l":[{"t":1478193,"n":"_declaration","d":1543729,"h":4296511025,"f":2}],"c":[{"n":".ctor","o":"$ctor$5","d":1543729,"h":8591478321,"f":1},{"p":[{"n":"content","p":0,"f":16}],"n":".ctor","o":"$ctor$6","d":1543729,"h":12886445617,"f":1},{"p":[{"n":"declaration","p":1478193},{"n":"content","p":0,"f":16}],"n":".ctor","o":"$ctor$7","d":1543729,"h":17181412913,"f":1},{"p":[{"n":"other","p":1543729}],"n":".ctor","o":"$ctor$8","d":1543729,"h":21476380209,"f":1}],"i":[13945948],"h":1543729}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XContainer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XDocument`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XElement", ($self) => class XElement extends $.$spxl.System.Xml.Linq.XContainer
        {
            static /*IEnumerable<XElement> */ get EmptySequence()
            {
                return $.$spc.System.Array.Empty($.$spxl.System.Xml.Linq.XElement);
            }
            /*XName*/ name = null;
            /*XAttribute?*/ lastAttr = null;
            $ctor$5(/*XName*/ name)
            {
                super.$ctor$3();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                    this.name = name;
                }
                return this;
            }
            $ctor$6(/*XName*/ name, /*object?*/ content)
            {
                this.$ctor$5(name);
                {
                    this.AddContentSkipNotify(content);
                }
                return this;
            }
            $ctor$7(/*XName*/ name, /*params object?[]*/ content)
            {
                this.$ctor$6(name, $.$cast(content, $.$spc.System.Object));
                {
                }
                return this;
            }
            $ctor$8(/*XElement*/ other)
            {
                super.$ctor$4(other);
                {
                    this.name = other.name;
                    /*XAttribute?*/ let a = other.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            this.AppendAttributeSkipNotify(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(a));
                        }
                        while(a !== other.lastAttr);
                    }
                }
                return this;
            }
            $ctor$9(/*XStreamingElement*/ other)
            {
                super.$ctor$3();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this.name = other.name;
                    this.AddContentSkipNotify(other.content);
                }
                return this;
            }
            $ctor$10()
            {
                this.$ctor$5($.$spxl.System.Xml.Linq.XName.op_Implicit($.$default()));
                {
                }
                return this;
            }
            $ctor$11(/*XmlReader*/ r)
            {
                this.$ctor$13(r, 0/*LoadOptions.None*/);
                {
                }
                return this;
            }
            $ctor$12(/*AsyncConstructionSentry*/ _)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            static $_AsyncConstructionSentry;
            static get AsyncConstructionSentry()
            {
                let $cls = $.$spxl.System.Xml.Linq.XElement;
                return $cls.$_AsyncConstructionSentry ??= $asm.$nstr("$spxl.System.Xml.Linq.XElement.AsyncConstructionSentry", ($self) => class AsyncConstructionSentry extends $.$spc.System.ValueType
                {
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        return copy;
                    }
                    static $h = 1740337;
                    static $z = 0;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"c":[{"n":".ctor","o":"$ctor$2","d":1740337,"h":4296707633,"f":1}],"d":1674801,"h":1740337}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Xml.Linq.XElement.AsyncConstructionSentry`; }
                }, $cls, ($v) => $cls.$_AsyncConstructionSentry = $v);
            }
            $ctor$13(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                super.$ctor$3();
                {
                    this.ReadElementFrom(r, o);
                }
                return this;
            }
            static /*Task<XElement> *//*async*/  CreateAsync(/*XmlReader*/ r, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    /*XElement*/ let xe = new $.$spxl.System.Xml.Linq.XElement().$ctor$12($.$default($.$spxl.System.Xml.Linq.XElement.AsyncConstructionSentry));
                    await xe.ReadElementFromAsync(r, 0/*LoadOptions.None*/, cancellationToken).ConfigureAwait(false);
                    return xe;
                });
            }
            /*void */ Save(/*string*/ fileName)
            {
                this.Save$1(fileName, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save$1(/*string*/ fileName, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$1(fileName, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*XAttribute? */ get FirstAttribute()
            {
                return this.lastAttr?.next;
            }
            /*bool */ get HasAttributes()
            {
                return this.lastAttr !== null;
            }
            /*bool */ get HasElements()
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        if ($.$is(n, $.$spxl.System.Xml.Linq.XElement))
                        {
                            return true;
                        }
                        n = n.next;
                    }
                    while(n !== this.content);
                }
                return false;
            }
            /*bool */ get IsEmpty()
            {
                return this.content === null;
            }
            /*XAttribute? */ get LastAttribute()
            {
                return this.lastAttr;
            }
            /*XName */ get Name()
            {
                return this.name;
            }
            /*XName */ set Name(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                this.name = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                }
            }
            /*XmlNodeType */ get NodeType()
            {
                return 1/*XmlNodeType.Element*/;
            }
            /*string */ get Value()
            {
                if (this.content === null)
                {
                    return $.$spc.System.String.Empty;
                }
                /*string?*/ let s = $.$as(this.content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    return s;
                }
                /*StringBuilder*/ let sb = $.$spxl.System.Text.StringBuilderCache.Acquire(16);
                this.AppendText(sb);
                return $.$spxl.System.Text.StringBuilderCache.GetStringAndRelease(sb);
            }
            /*string */ set Value(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                this.RemoveNodes();
                this.Add(value);
            }
            /*IEnumerable<XElement> */ AncestorsAndSelf()
            {
                return this.GetAncestors(null, true);
            }
            /*IEnumerable<XElement> */ AncestorsAndSelf$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetAncestors(name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*XAttribute? */ Attribute(/*XName*/ name)
            {
                /*XAttribute?*/ let a = this.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(a.name, name))
                        {
                            return a;
                        }
                    }
                    while(a !== this.lastAttr);
                }
                return null;
            }
            /*IEnumerable<XAttribute> */ Attributes()
            {
                return this.GetAttributes(null);
            }
            /*IEnumerable<XAttribute> */ Attributes$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetAttributes(name) : $.$spxl.System.Xml.Linq.XAttribute.EmptySequence;
            }
            /*IEnumerable<XNode> */ DescendantNodesAndSelf()
            {
                return this.GetDescendantNodes(true);
            }
            /*IEnumerable<XElement> */ DescendantsAndSelf()
            {
                return this.GetDescendants(null, true);
            }
            /*IEnumerable<XElement> */ DescendantsAndSelf$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetDescendants(name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*XNamespace */ GetDefaultNamespace()
            {
                /*string?*/ let namespaceName = this.GetNamespaceOfPrefixInScope("xmlns", null);
                return $.$spc.System.String.op_Inequality(namespaceName, null) ? $.$spxl.System.Xml.Linq.XNamespace.Get(namespaceName) : $.$spxl.System.Xml.Linq.XNamespace.None;
            }
            /*XNamespace? */ GetNamespaceOfPrefix(/*string*/ prefix)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(prefix, "prefix");
                if ($.$spc.System.String.op_Equality(prefix, "xmlns"))
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.Xmlns;
                }
                /*string?*/ let namespaceName = this.GetNamespaceOfPrefixInScope(prefix, null);
                if ($.$spc.System.String.op_Inequality(namespaceName, null))
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.Get(namespaceName);
                }
                if ($.$spc.System.String.op_Equality(prefix, "xml"))
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.Xml;
                }
                return null;
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(ns, "ns");
                /*string*/ let namespaceName = ns.NamespaceName;
                /*bool*/ let hasInScopeNamespace = false;
                /*XElement?*/ let e = this;
                do
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        /*bool*/ let hasLocalNamespace = false;
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration)
                            {
                                if ($.$spc.System.String.op_Equality(a.Value, namespaceName))
                                {
                                    if (a.Name.NamespaceName.length !== 0 && (!hasInScopeNamespace || $.$spc.System.String.op_Equality(this.GetNamespaceOfPrefixInScope(a.Name.LocalName, e), null)))
                                    {
                                        return a.Name.LocalName;
                                    }
                                }
                                hasLocalNamespace = true;
                            }
                        }
                        while(a !== e.lastAttr);
                        hasInScopeNamespace = $.$spc.System.Boolean.op_BitwiseOr(hasInScopeNamespace, hasLocalNamespace);
                    }
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                while(e !== null);
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    if (!hasInScopeNamespace || $.$spc.System.String.op_Equality(this.GetNamespaceOfPrefixInScope("xml", null), null))
                    {
                        return "xml";
                    }
                }
                else if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            static /*XElement */ Load(/*string*/ uri)
            {
                return $.$spxl.System.Xml.Linq.XElement.Load$1(uri, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Load$1(/*string*/ uri, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$1(uri, rs);
                    return $.$spxl.System.Xml.Linq.XElement.Load$7(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*XElement */ Load$2(/*Stream*/ stream)
            {
                return $.$spxl.System.Xml.Linq.XElement.Load$3(stream, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Load$3(/*Stream*/ stream, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$4(stream, rs);
                    return $.$spxl.System.Xml.Linq.XElement.Load$7(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*Task<XElement> *//*async*/  LoadAsync(/*Stream*/ stream, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$4(stream, rs);
                        return await $.$spxl.System.Xml.Linq.XElement.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*XElement */ Load$4(/*TextReader*/ textReader)
            {
                return $.$spxl.System.Xml.Linq.XElement.Load$5(textReader, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Load$5(/*TextReader*/ textReader, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$8(textReader, rs);
                    return $.$spxl.System.Xml.Linq.XElement.Load$7(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*Task<XElement> *//*async*/  LoadAsync$1(/*TextReader*/ textReader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$8(textReader, rs);
                        return await $.$spxl.System.Xml.Linq.XElement.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*XElement */ Load$6(/*XmlReader*/ reader)
            {
                return $.$spxl.System.Xml.Linq.XElement.Load$7(reader, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Load$7(/*XmlReader*/ reader, /*LoadOptions*/ options)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                if (reader.MoveToContent() !== 1/*XmlNodeType.Element*/)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format$1($.$spxl.System.SR.InvalidOperation_ExpectedNodeType, $.$box(1/*XmlNodeType.Element*/, $.$spx.System.Xml.XmlNodeType), $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                }
                /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$13(reader, options);
                reader.MoveToContent();
                if (!reader.EOF)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                }
                return e;
            }
            static /*Task<XElement> */ LoadAsync$2(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spxl.System.Xml.Linq.XElement, cancellationToken);
                }
                return $.$spxl.System.Xml.Linq.XElement.LoadAsyncInternal(reader, options, cancellationToken);
            }
            static /*Task<XElement> *//*async*/  LoadAsyncInternal(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    if (await reader.MoveToContentAsync().ConfigureAwait$2(false) !== 1/*XmlNodeType.Element*/)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format$1($.$spxl.System.SR.InvalidOperation_ExpectedNodeType, $.$box(1/*XmlNodeType.Element*/, $.$spx.System.Xml.XmlNodeType), $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                    }
                    /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$12($.$default($.$spxl.System.Xml.Linq.XElement.AsyncConstructionSentry));
                    await e.ReadElementFromAsync(reader, options, cancellationToken).ConfigureAwait(false);
                    cancellationToken.ThrowIfCancellationRequested();
                    await reader.MoveToContentAsync().ConfigureAwait$2(false);
                    if (!reader.EOF)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                    }
                    return e;
                });
            }
            static /*XElement */ Parse(/*string*/ text)
            {
                return $.$spxl.System.Xml.Linq.XElement.Parse$1(text, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Parse$1(/*string*/ text, /*LoadOptions*/ options)
            {
                let sr = null;
                try
                {
                    sr = new $.$spc.System.IO.StringReader().$ctor$3(text);
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$8(sr, rs);
                        return $.$spxl.System.Xml.Linq.XElement.Load$7(r, options);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                }
                finally
                {
                    sr?.System$IDisposable$Dispose();
                }
            }
            /*void */ RemoveAll()
            {
                this.RemoveAttributes();
                this.RemoveNodes();
            }
            /*void */ RemoveAttributes()
            {
                if (this.SkipNotify())
                {
                    this.RemoveAttributesSkipNotify();
                    return;
                }
                while(this.lastAttr !== null)
                {
                    /*XAttribute*/ let a = this.lastAttr.next;
                    this.NotifyChanging(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                    if (this.lastAttr === null || a !== this.lastAttr.next)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                    }
                    if (a !== this.lastAttr)
                    {
                        this.lastAttr.next = a.next;
                    }
                    else 
                    {
                        this.lastAttr = null;
                    }
                    a.parent = null;
                    a.next = null;
                    this.NotifyChanged(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                }
            }
            /*void */ ReplaceAll(/*object?*/ content)
            {
                content = $.$spxl.System.Xml.Linq.XContainer.GetContentSnapshot(content);
                this.RemoveAll();
                this.Add(content);
            }
            /*void */ ReplaceAll$1(/*params object?[]*/ content)
            {
                this.ReplaceAll($.$cast(content, $.$spc.System.Object));
            }
            /*void */ ReplaceAttributes(/*object?*/ content)
            {
                content = $.$spxl.System.Xml.Linq.XContainer.GetContentSnapshot(content);
                this.RemoveAttributes();
                this.Add(content);
            }
            /*void */ ReplaceAttributes$1(/*params object?[]*/ content)
            {
                this.ReplaceAttributes($.$cast(content, $.$spc.System.Object));
            }
            /*void */ Save$2(/*Stream*/ stream)
            {
                this.Save$3(stream, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save$3(/*Stream*/ stream, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$3(stream, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*Task *//*async*/  SaveAsync(/*Stream*/ stream, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create$3(stream, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$spc.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.SaveAsync$2(w, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            /*void */ Save$4(/*TextWriter*/ textWriter)
            {
                this.Save$5(textWriter, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save$5(/*TextWriter*/ textWriter, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$5(textWriter, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*Task *//*async*/  SaveAsync$1(/*TextWriter*/ textWriter, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create$5(textWriter, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$spc.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.SaveAsync$2(w, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            /*void */ Save$6(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                writer.WriteStartDocument();
                this.WriteTo(writer);
                writer.WriteEndDocument();
            }
            /*Task */ SaveAsync$2(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return this.SaveAsyncInternal(writer, cancellationToken);
            }
            /*Task *//*async*/  SaveAsyncInternal(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await writer.WriteStartDocumentAsync().ConfigureAwait(false);
                    await this.WriteToAsync(writer, cancellationToken).ConfigureAwait(false);
                    cancellationToken.ThrowIfCancellationRequested();
                    await writer.WriteEndDocumentAsync().ConfigureAwait(false);
                });
            }
            /*void */ SetAttributeValue(/*XName*/ name, /*object?*/ value)
            {
                /*XAttribute?*/ let a = this.Attribute(name);
                if (value === null)
                {
                    if (a !== null)
                    {
                        this.RemoveAttribute(a);
                    }
                }
                else 
                {
                    if (a !== null)
                    {
                        a.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
                    }
                    else 
                    {
                        this.AppendAttribute(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(name, value));
                    }
                }
            }
            /*void */ SetElementValue(/*XName*/ name, /*object?*/ value)
            {
                /*XElement?*/ let e = this.Element(name);
                if (value === null)
                {
                    if (e !== null)
                    {
                        this.RemoveNode(e);
                    }
                }
                else 
                {
                    if (e !== null)
                    {
                        e.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
                    }
                    else 
                    {
                        this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$6(name, $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value)));
                    }
                }
            }
            /*void */ SetValue(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                this.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                new $.$spxl.System.Xml.Linq.ElementWriter().$ctor$2(writer).WriteElement(this);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return new $.$spxl.System.Xml.Linq.ElementWriter().$ctor$2(writer).WriteElementAsync(this, cancellationToken);
            }
            static /*string? */ op_Explicit(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return element.Value;
            }
            static /*bool */ op_Explicit$1(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$spc.System.String.ToLowerInvariant.call(element.Value));
            }
            static /*bool? */ op_Explicit$2(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$spc.System.String.ToLowerInvariant.call(element.Value));
            }
            static /*int */ op_Explicit$3(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToInt32(element.Value);
            }
            static /*int? */ op_Explicit$4(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt32(element.Value);
            }
            static /*uint */ op_Explicit$5(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToUInt32(element.Value);
            }
            static /*uint? */ op_Explicit$6(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt32(element.Value);
            }
            static /*long */ op_Explicit$7(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToInt64(element.Value);
            }
            static /*long? */ op_Explicit$8(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt64(element.Value);
            }
            static /*ulong */ op_Explicit$9(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToUInt64(element.Value);
            }
            static /*ulong? */ op_Explicit$10(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt64(element.Value);
            }
            static /*float */ op_Explicit$11(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToSingle(element.Value);
            }
            static /*float? */ op_Explicit$12(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToSingle(element.Value);
            }
            static /*double */ op_Explicit$13(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToDouble(element.Value);
            }
            static /*double? */ op_Explicit$14(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDouble(element.Value);
            }
            static /*decimal */ op_Explicit$15(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToDecimal(element.Value);
            }
            static /*decimal? */ op_Explicit$16(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDecimal(element.Value);
            }
            static /*DateTime */ op_Explicit$17(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spc.System.DateTime.Parse$2(element.Value, $.$spc.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            static /*DateTime? */ op_Explicit$18(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spc.System.DateTime.Parse$2(element.Value, $.$spc.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            static /*DateTimeOffset */ op_Explicit$19(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset(element.Value);
            }
            static /*DateTimeOffset? */ op_Explicit$20(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset(element.Value);
            }
            static /*TimeSpan */ op_Explicit$21(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(element.Value);
            }
            static /*TimeSpan? */ op_Explicit$22(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(element.Value);
            }
            static /*Guid */ op_Explicit$23(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToGuid(element.Value);
            }
            static /*Guid? */ op_Explicit$24(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToGuid(element.Value);
            }
            /*XmlSchema? */ System$Xml$Serialization$IXmlSerializable$GetSchema()
            {
                return null;
            }
            /*void */ System$Xml$Serialization$IXmlSerializable$ReadXml(/*XmlReader*/ reader)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                if (this.parent !== null || this.annotations !== null || this.content !== null || this.lastAttr !== null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_DeserializeInstance);
                }
                if (reader.MoveToContent() !== 1/*XmlNodeType.Element*/)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format$1($.$spxl.System.SR.InvalidOperation_ExpectedNodeType, $.$box(1/*XmlNodeType.Element*/, $.$spx.System.Xml.XmlNodeType), $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                }
                this.ReadElementFrom(reader, 0/*LoadOptions.None*/);
            }
            /*void */ System$Xml$Serialization$IXmlSerializable$WriteXml(/*XmlWriter*/ writer)
            {
                this.WriteTo(writer);
            }
            /*void */ AddAttribute(/*XAttribute*/ a)
            {
                if (this.Attribute(a.Name) !== null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_DuplicateAttribute);
                }
                if (a.parent !== null)
                {
                    a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(a);
                }
                this.AppendAttribute(a);
            }
            /*void */ AddAttributeSkipNotify(/*XAttribute*/ a)
            {
                if (this.Attribute(a.Name) !== null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_DuplicateAttribute);
                }
                if (a.parent !== null)
                {
                    a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(a);
                }
                this.AppendAttributeSkipNotify(a);
            }
            /*void */ AppendAttribute(/*XAttribute*/ a)
            {
                /*bool*/ let notify = this.NotifyChanging(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                if (a.parent !== null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                this.AppendAttributeSkipNotify(a);
                if (notify)
                {
                    this.NotifyChanged(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                }
            }
            /*void */ AppendAttributeSkipNotify(/*XAttribute*/ a)
            {
                a.parent = this;
                if (this.lastAttr === null)
                {
                    a.next = a;
                }
                else 
                {
                    a.next = this.lastAttr.next;
                    this.lastAttr.next = a;
                }
                this.lastAttr = a;
            }
            /*bool */ AttributesEqual(/*XElement*/ e)
            {
                /*XAttribute?*/ let a1 = this.lastAttr;
                /*XAttribute?*/ let a2 = e.lastAttr;
                if (a1 !== null && a2 !== null)
                {
                    do
                    {
                        a1 = a1.next;
                        a2 = a2.next;
                        if ($.$spxl.System.Xml.Linq.XName.op_Inequality(a1.name, a2.name) || $.$spc.System.String.op_Inequality(a1.value, a2.value))
                        {
                            return false;
                        }
                    }
                    while(a1 !== this.lastAttr);
                    return a2 === e.lastAttr;
                }
                return a1 === null && a2 === null;
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XElement().$ctor$8(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XElement?*/ let e = $.$as(node, $.$spxl.System.Xml.Linq.XElement);
                return e !== null && $.$spxl.System.Xml.Linq.XName.op_Equality(this.name, e.name) && this.ContentsEqual(e) && this.AttributesEqual(e);
            }
            /*IEnumerable<XAttribute> */ GetAttributes(/*XName?*/ name)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*XAttribute?*/ let a = this.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(a.name, name))
                            {
                                yield a;
                            }
                        }
                        while(a.parent === this && a !== this.lastAttr);
                    }
                }.bind(this));
            }
            /*string? */ GetNamespaceOfPrefixInScope(/*string*/ prefix, /*XElement?*/ outOfScope)
            {
                /*XElement?*/ let e = this;
                while(e !== outOfScope)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(e !== null, "e != null");
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration && $.$spc.System.String.op_Equality(a.Name.LocalName, prefix))
                            {
                                return a.Value;
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return null;
            }
            /*int */ GetDeepHashCode()
            {
                /*int*/ let h = $.$spxl.System.Xml.Linq.XName.GetHashCode.call(this.name);
                h ^= this.ContentsHashCode();
                /*XAttribute?*/ let a = this.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        h ^= a.GetDeepHashCode();
                    }
                    while(a !== this.lastAttr);
                }
                return h;
            }
            /*void */ ReadElementFrom(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                this.ReadElementFromImpl(r, o);
                if (!r.IsEmptyElement)
                {
                    r.Read();
                    this.ReadContentFrom$1(r, o);
                }
                r.Read();
            }
            /*Task *//*async*/  ReadElementFromAsync(/*XmlReader*/ r, /*LoadOptions*/ o, /*CancellationToken*/ cancellationTokentoken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.ReadElementFromImpl(r, o);
                    if (!r.IsEmptyElement)
                    {
                        cancellationTokentoken.ThrowIfCancellationRequested();
                        await r.ReadAsync().ConfigureAwait$2(false);
                        await this.ReadContentFromAsync$1(r, o, cancellationTokentoken).ConfigureAwait(false);
                    }
                    cancellationTokentoken.ThrowIfCancellationRequested();
                    await r.ReadAsync().ConfigureAwait$2(false);
                });
            }
            /*void */ ReadElementFromImpl(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                if (r.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                this.name = $.$spxl.System.Xml.Linq.XNamespace.Get(r.NamespaceURI).GetName(r.LocalName);
                if ((o & 2/*LoadOptions.SetBaseUri*/) !== 0)
                {
                    /*string?*/ let baseUri = r.BaseURI;
                    if (!$.$spc.System.String.IsNullOrEmpty(baseUri))
                    {
                        this.SetBaseUri(baseUri);
                    }
                }
                /*IXmlLineInfo?*/ let li = null;
                if ((o & 4/*LoadOptions.SetLineInfo*/) !== 0)
                {
                    li = $.$as(r, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null && li.System$Xml$IXmlLineInfo$HasLineInfo())
                    {
                        this.SetLineInfo(li.System$Xml$IXmlLineInfo$LineNumber, li.System$Xml$IXmlLineInfo$LinePosition);
                    }
                }
                if (r.MoveToFirstAttribute())
                {
                    do
                    {
                        /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2($.$spxl.System.Xml.Linq.XNamespace.Get(r.Prefix.length === 0 ? $.$spc.System.String.Empty : r.NamespaceURI).GetName(r.LocalName), r.Value);
                        if (li !== null && li.System$Xml$IXmlLineInfo$HasLineInfo())
                        {
                            a.SetLineInfo(li.System$Xml$IXmlLineInfo$LineNumber, li.System$Xml$IXmlLineInfo$LinePosition);
                        }
                        this.AppendAttributeSkipNotify(a);
                    }
                    while(r.MoveToNextAttribute());
                    r.MoveToElement();
                }
            }
            /*void */ RemoveAttribute(/*XAttribute*/ a)
            {
                /*bool*/ let notify = this.NotifyChanging(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                if (a.parent !== this)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                /*XAttribute?*/ let p = this.lastAttr, n;
                while((n = p.next) !== a)
                {
                    p = n;
                }
                if (p === a)
                {
                    this.lastAttr = null;
                }
                else 
                {
                    if (this.lastAttr === a)
                    {
                        this.lastAttr = p;
                    }
                    p.next = a.next;
                }
                a.parent = null;
                a.next = null;
                if (notify)
                {
                    this.NotifyChanged(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                }
            }
            /*void */ RemoveAttributesSkipNotify()
            {
                if (this.lastAttr !== null)
                {
                    /*XAttribute*/ let a = this.lastAttr;
                    do
                    {
                        /*XAttribute*/ let next = a.next;
                        a.parent = null;
                        a.next = null;
                        a = next;
                    }
                    while(a !== this.lastAttr);
                    this.lastAttr = null;
                }
            }
            /*void */ SetEndElementLineInfo(/*int*/ lineNumber, /*int*/ linePosition)
            {
                this.AddAnnotation(new $.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation().$ctor$2(lineNumber, linePosition));
            }
            /*void */ ValidateNode(/*XNode*/ node, /*XNode?*/ previous)
            {
                if ($.$is(node, $.$spxl.System.Xml.Linq.XDocument))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_AddNode, $.$box(9/*XmlNodeType.Document*/, $.$spx.System.Xml.XmlNodeType)));
                }
                if ($.$is(node, $.$spxl.System.Xml.Linq.XDocumentType))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_AddNode, $.$box(10/*XmlNodeType.DocumentType*/, $.$spx.System.Xml.XmlNodeType)));
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.name = null;
            }
            static $h = 1674801;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1347121,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"g":{"r":0,"d":0,"h":8591609393,"f":33},"n":"EmptySequence","d":1674801,"h":4296642097,"f":33},{"p":1150513,"g":{"r":0,"d":0,"h":81606053425,"f":1},"n":"FirstAttribute","d":1674801,"h":77311086129,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":90195988017,"f":1},"n":"HasAttributes","d":1674801,"h":85901020721,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":98785922609,"f":1},"n":"HasElements","d":1674801,"h":94490955313,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":107375857201,"f":1},"n":"IsEmpty","d":1674801,"h":103080889905,"f":1},{"p":1150513,"g":{"r":0,"d":0,"h":115965791793,"f":1},"n":"LastAttribute","d":1674801,"h":111670824497,"f":1},{"p":2133553,"g":{"r":0,"d":0,"h":124555726385,"f":1},"s":{"r":0,"d":0,"h":128850693681,"f":1},"n":"Name","d":1674801,"h":120260759089,"f":1},{"p":52874332,"g":{"r":0,"d":0,"h":137440628273,"f":32769},"n":"NodeType","d":1674801,"h":133145660977,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":146030562865,"f":1},"s":{"r":0,"d":0,"h":150325530161,"f":1},"n":"Value","d":1674801,"h":141735595569,"f":1}],"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"r","p":53398620},{"n":"cancellationToken","p":125960193}],"n":"CreateAsync","d":1674801,"h":64426184241,"f":4136},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"Save","d":1674801,"h":68721151537,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"options","p":1019441}],"n":"Save","o":"@$1","d":1674801,"h":73016118833,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"AncestorsAndSelf","d":1674801,"h":154620497457,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2133553}],"n":"AncestorsAndSelf","o":"@$1","d":1674801,"h":158915464753,"f":1},{"r":1150513,"p":[{"n":"name","p":2133553}],"n":"Attribute","d":1674801,"h":163210432049,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"n":"Attributes","d":1674801,"h":167505399345,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"name","p":2133553}],"n":"Attributes","o":"@$1","d":1674801,"h":171800366641,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"DescendantNodesAndSelf","d":1674801,"h":176095333937,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"DescendantsAndSelf","d":1674801,"h":180390301233,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2133553}],"n":"DescendantsAndSelf","o":"@$1","d":1674801,"h":184685268529,"f":1},{"r":2199089,"n":"GetDefaultNamespace","d":1674801,"h":188980235825,"f":1},{"r":2199089,"p":[{"n":"prefix","p":1310721}],"n":"GetNamespaceOfPrefix","d":1674801,"h":193275203121,"f":1},{"r":1310721,"p":[{"n":"ns","p":2199089}],"n":"GetPrefixOfNamespace","d":1674801,"h":197570170417,"f":1},{"r":1674801,"p":[{"n":"uri","p":1310721}],"n":"Load","d":1674801,"h":201865137713,"f":33},{"r":1674801,"p":[{"n":"uri","p":1310721},{"n":"options","p":691761}],"n":"Load","o":"@$1","d":1674801,"h":206160105009,"f":33},{"r":1674801,"p":[{"n":"stream","p":62128129}],"n":"Load","o":"@$2","d":1674801,"h":210455072305,"f":33},{"r":1674801,"p":[{"n":"stream","p":62128129},{"n":"options","p":691761}],"n":"Load","o":"@$3","d":1674801,"h":214750039601,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"stream","p":62128129},{"n":"options","p":691761},{"n":"cancellationToken","p":125960193}],"n":"LoadAsync","d":1674801,"h":219045006897,"f":4129},{"r":1674801,"p":[{"n":"textReader","p":62849025}],"n":"Load","o":"@$4","d":1674801,"h":223339974193,"f":33},{"r":1674801,"p":[{"n":"textReader","p":62849025},{"n":"options","p":691761}],"n":"Load","o":"@$5","d":1674801,"h":227634941489,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"textReader","p":62849025},{"n":"options","p":691761},{"n":"cancellationToken","p":125960193}],"n":"LoadAsync","o":"@$1","d":1674801,"h":231929908785,"f":4129},{"r":1674801,"p":[{"n":"reader","p":53398620}],"n":"Load","o":"@$6","d":1674801,"h":236224876081,"f":33},{"r":1674801,"p":[{"n":"reader","p":53398620},{"n":"options","p":691761}],"n":"Load","o":"@$7","d":1674801,"h":240519843377,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"reader","p":53398620},{"n":"options","p":691761},{"n":"cancellationToken","p":125960193}],"n":"LoadAsync","o":"@$2","d":1674801,"h":244814810673,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"reader","p":53398620},{"n":"options","p":691761},{"n":"cancellationToken","p":125960193}],"n":"LoadAsyncInternal","d":1674801,"h":249109777969,"f":4130},{"r":1674801,"p":[{"n":"text","p":1310721}],"n":"Parse","d":1674801,"h":253404745265,"f":33},{"r":1674801,"p":[{"n":"text","p":1310721},{"n":"options","p":691761}],"n":"Parse","o":"@$1","d":1674801,"h":257699712561,"f":33},{"r":65537,"n":"RemoveAll","d":1674801,"h":261994679857,"f":1},{"r":65537,"n":"RemoveAttributes","d":1674801,"h":266289647153,"f":1},{"r":65537,"p":[{"n":"content","p":131073}],"n":"ReplaceAll","d":1674801,"h":270584614449,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"ReplaceAll","o":"@$1","d":1674801,"h":274879581745,"f":1},{"r":65537,"p":[{"n":"content","p":131073}],"n":"ReplaceAttributes","d":1674801,"h":279174549041,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"ReplaceAttributes","o":"@$1","d":1674801,"h":283469516337,"f":1},{"r":65537,"p":[{"n":"stream","p":62128129}],"n":"Save","o":"@$2","d":1674801,"h":287764483633,"f":1},{"r":65537,"p":[{"n":"stream","p":62128129},{"n":"options","p":1019441}],"n":"Save","o":"@$3","d":1674801,"h":292059450929,"f":1},{"r":133300225,"p":[{"n":"stream","p":62128129},{"n":"options","p":1019441},{"n":"cancellationToken","p":125960193}],"n":"SaveAsync","d":1674801,"h":296354418225,"f":4097},{"r":65537,"p":[{"n":"textWriter","p":62980097}],"n":"Save","o":"@$4","d":1674801,"h":300649385521,"f":1},{"r":65537,"p":[{"n":"textWriter","p":62980097},{"n":"options","p":1019441}],"n":"Save","o":"@$5","d":1674801,"h":304944352817,"f":1},{"r":133300225,"p":[{"n":"textWriter","p":62980097},{"n":"options","p":1019441},{"n":"cancellationToken","p":125960193}],"n":"SaveAsync","o":"@$1","d":1674801,"h":309239320113,"f":4097},{"r":65537,"p":[{"n":"writer","p":58444892}],"n":"Save","o":"@$6","d":1674801,"h":313534287409,"f":1},{"r":133300225,"p":[{"n":"writer","p":58444892},{"n":"cancellationToken","p":125960193}],"n":"SaveAsync","o":"@$2","d":1674801,"h":317829254705,"f":1},{"r":133300225,"p":[{"n":"writer","p":58444892},{"n":"cancellationToken","p":125960193}],"n":"SaveAsyncInternal","d":1674801,"h":322124222001,"f":4098},{"r":65537,"p":[{"n":"name","p":2133553},{"n":"value","p":131073}],"n":"SetAttributeValue","d":1674801,"h":326419189297,"f":1},{"r":65537,"p":[{"n":"name","p":2133553},{"n":"value","p":131073}],"n":"SetElementValue","d":1674801,"h":330714156593,"f":1},{"r":65537,"p":[{"n":"value","p":131073}],"n":"SetValue","d":1674801,"h":335009123889,"f":1},{"r":65537,"p":[{"n":"writer","p":58444892}],"n":"WriteTo","d":1674801,"h":339304091185,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58444892},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":1674801,"h":343599058481,"f":32769},{"r":65537,"p":[{"n":"a","p":1150513}],"n":"AddAttribute","d":1674801,"h":468153110065,"f":32776},{"r":65537,"p":[{"n":"a","p":1150513}],"n":"AddAttributeSkipNotify","d":1674801,"h":472448077361,"f":32776},{"r":65537,"p":[{"n":"a","p":1150513}],"n":"AppendAttribute","d":1674801,"h":476743044657,"f":8},{"r":65537,"p":[{"n":"a","p":1150513}],"n":"AppendAttributeSkipNotify","d":1674801,"h":481038011953,"f":8},{"r":262145,"p":[{"n":"e","p":1674801}],"n":"AttributesEqual","d":1674801,"h":485332979249,"f":2},{"r":2264625,"n":"CloneNode","d":1674801,"h":489627946545,"f":32776},{"r":262145,"p":[{"n":"node","p":2264625}],"n":"DeepEquals","o":"@$1","d":1674801,"h":493922913841,"f":32776},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"name","p":2133553}],"n":"GetAttributes","d":1674801,"h":498217881137,"f":2},{"r":1310721,"p":[{"n":"prefix","p":1310721},{"n":"outOfScope","p":1674801}],"n":"GetNamespaceOfPrefixInScope","d":1674801,"h":502512848433,"f":2},{"r":655361,"n":"GetDeepHashCode","d":1674801,"h":506807815729,"f":32776},{"r":65537,"p":[{"n":"r","p":53398620},{"n":"o","p":691761}],"n":"ReadElementFrom","d":1674801,"h":511102783025,"f":2},{"r":133300225,"p":[{"n":"r","p":53398620},{"n":"o","p":691761},{"n":"cancellationTokentoken","p":125960193}],"n":"ReadElementFromAsync","d":1674801,"h":515397750321,"f":4098},{"r":65537,"p":[{"n":"r","p":53398620},{"n":"o","p":691761}],"n":"ReadElementFromImpl","d":1674801,"h":519692717617,"f":2},{"r":65537,"p":[{"n":"a","p":1150513}],"n":"RemoveAttribute","d":1674801,"h":523987684913,"f":8},{"r":65537,"n":"RemoveAttributesSkipNotify","d":1674801,"h":528282652209,"f":2},{"r":65537,"p":[{"n":"lineNumber","p":655361},{"n":"linePosition","p":655361}],"n":"SetEndElementLineInfo","d":1674801,"h":532577619505,"f":8},{"r":65537,"p":[{"n":"node","p":2264625},{"n":"previous","p":2264625}],"n":"ValidateNode","d":1674801,"h":536872586801,"f":32776}],"l":[{"t":2133553,"n":"name","d":1674801,"h":12886576689,"f":8},{"t":1150513,"n":"lastAttr","d":1674801,"h":17181543985,"f":8}],"c":[{"p":[{"n":"name","p":2133553}],"n":".ctor","o":"$ctor$5","d":1674801,"h":21476511281,"f":1},{"p":[{"n":"name","p":2133553},{"n":"content","p":131073}],"n":".ctor","o":"$ctor$6","d":1674801,"h":25771478577,"f":1},{"p":[{"n":"name","p":2133553},{"n":"content","p":0,"f":16}],"n":".ctor","o":"$ctor$7","d":1674801,"h":30066445873,"f":1},{"p":[{"n":"other","p":1674801}],"n":".ctor","o":"$ctor$8","d":1674801,"h":34361413169,"f":1},{"p":[{"n":"other","p":2919985}],"n":".ctor","o":"$ctor$9","d":1674801,"h":38656380465,"f":1},{"n":".ctor","o":"$ctor$10","d":1674801,"h":42951347761,"f":8},{"p":[{"n":"r","p":53398620}],"n":".ctor","o":"$ctor$11","d":1674801,"h":47246315057,"f":8},{"p":[{"n":"_","p":1740337}],"n":".ctor","o":"$ctor$12","d":1674801,"h":51541282353,"f":2},{"p":[{"n":"r","p":53398620},{"n":"o","p":691761}],"n":".ctor","o":"$ctor$13","d":1674801,"h":60131216945,"f":8}],"i":[13945948,37276764],"j":[1740337],"h":1674801,"a":[{"t":44878940,"c":12929780828,"a":[{"t":1310721}],"n":[{"n":"IsAny","v":true,"t":262145}]},{"t":1543279,"c":4296510575,"a":[{"v":"MS.Internal.Xml.Linq.ComponentModel.XTypeDescriptionProvider\u00601[[System.Xml.Linq.XElement, System.Xml.Linq, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]],System.ComponentModel.TypeConverter","t":1310721}]}]}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XContainer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo, $.$spx.System.Xml.Serialization.IXmlSerializable ]; }
            static get $fullName() { return `System.Xml.Linq.XElement`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Schema.XmlSchemaInfoEqualityComparer", ($self) => class XmlSchemaInfoEqualityComparer extends $.$spc.System.Object
        {
            /*bool */ Equals$2(/*XmlSchemaInfo?*/ si1, /*XmlSchemaInfo?*/ si2)
            {
                if (si1 === si2)
                {
                    return true;
                }
                if (si1 === null || si2 === null)
                {
                    return false;
                }
                return si1.ContentType === si2.ContentType && si1.IsDefault === si2.IsDefault && si1.IsNil === si2.IsNil && $.$cast(si1.MemberType, $.$spc.System.Object) === $.$cast(si2.MemberType, $.$spc.System.Object) && $.$cast(si1.SchemaAttribute, $.$spc.System.Object) === $.$cast(si2.SchemaAttribute, $.$spc.System.Object) && $.$cast(si1.SchemaElement, $.$spc.System.Object) === $.$cast(si2.SchemaElement, $.$spc.System.Object) && $.$cast(si1.SchemaType, $.$spc.System.Object) === $.$cast(si2.SchemaType, $.$spc.System.Object) && si1.Validity === si2.Validity;
            }
            /*int */ GetHashCode$1(/*XmlSchemaInfo?*/ si)
            {
                if (si === null)
                {
                    return 0;
                }
                /*int*/ let h = si.ContentType;
                if (si.IsDefault)
                {
                    h ^= 1;
                }
                if (si.IsNil)
                {
                    h ^= 1;
                }
                /*XmlSchemaSimpleType?*/ let memberType = si.MemberType;
                if (memberType !== null)
                {
                    h ^= $.$spc.System.Object.GetHashCode.call(memberType);
                }
                /*XmlSchemaAttribute?*/ let schemaAttribute = si.SchemaAttribute;
                if (schemaAttribute !== null)
                {
                    h ^= $.$spc.System.Object.GetHashCode.call(schemaAttribute);
                }
                /*XmlSchemaElement?*/ let schemaElement = si.SchemaElement;
                if (schemaElement !== null)
                {
                    h ^= $.$spc.System.Object.GetHashCode.call(schemaElement);
                }
                /*XmlSchemaType?*/ let schemaType = si.SchemaType;
                if (schemaType !== null)
                {
                    h ^= $.$spc.System.Object.GetHashCode.call(schemaType);
                }
                h ^= si.Validity;
                return h;
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Schema.XmlSchemaInfo>.Equals(System.Xml.Schema.XmlSchemaInfo?, System.Xml.Schema.XmlSchemaInfo?)
            System$Collections$Generic$IEqualityComparer$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Schema.XmlSchemaInfo>.GetHashCode(System.Xml.Schema.XmlSchemaInfo)
            System$Collections$Generic$IEqualityComparer$$$GetHashCode()
            {
                return this.GetHashCode$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 3116593;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"si1","p":30133340},{"n":"si2","p":30133340}],"n":"Equals","o":"@$2","d":3116593,"h":4298083889,"f":1},{"r":655361,"p":[{"n":"si","p":30133340}],"n":"GetHashCode","o":"@$1","d":3116593,"h":8593051185,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":3116593,"h":12888018481,"f":1}],"i":[$.$spc.System.Collections.Generic.IEqualityComparer$$($.$spx.System.Xml.Schema.XmlSchemaInfo).$h],"h":3116593}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEqualityComparer$$($.$spx.System.Xml.Schema.XmlSchemaInfo) ]; }
            static get $fullName() { return `System.Xml.Schema.XmlSchemaInfoEqualityComparer`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.LineInfoEndElementAnnotation", ($self) => class LineInfoEndElementAnnotation extends $.$spxl.System.Xml.Linq.LineInfoAnnotation
        {
            $ctor$2(/*int*/ lineNumber, /*int*/ linePosition)
            {
                super.$ctor$1(lineNumber, linePosition);
                {
                }
                return this;
            }
            static $h = 626225;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":560689,"c":[{"p":[{"n":"lineNumber","p":655361},{"n":"linePosition","p":655361}],"n":".ctor","o":"$ctor$2","d":626225,"h":4295593521,"f":1}],"h":626225}; }
            static get $b() { return $.$spxl.System.Xml.Linq.LineInfoAnnotation; }
            static get $fullName() { return `System.Xml.Linq.LineInfoEndElementAnnotation`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XObjectChangeEventArgs", ($self) => class XObjectChangeEventArgs extends $.$spc.System.EventArgs
        {
            /*XObjectChange*/ _objectChange = 0;
            /*XObjectChangeEventArgs*/ static Add = null;
            /*XObjectChangeEventArgs*/ static Remove = null;
            /*XObjectChangeEventArgs*/ static Name = null;
            /*XObjectChangeEventArgs*/ static Value = null;
            $ctor$2(/*XObjectChange*/ objectChange)
            {
                super.$ctor$1();
                {
                    this._objectChange = objectChange;
                }
                return this;
            }
            /*XObjectChange */ get ObjectChange()
            {
                return this._objectChange;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Add = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(0/*XObjectChange.Add*/);
                }
                {
                    this.Remove = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(1/*XObjectChange.Remove*/);
                }
                {
                    this.Name = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(2/*XObjectChange.Name*/);
                }
                {
                    this.Value = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(3/*XObjectChange.Value*/);
                }
            }
            static $h = 2788913;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":2657841,"g":{"r":0,"d":0,"h":34362527281,"f":1},"n":"ObjectChange","d":2788913,"h":30067559985,"f":1}],"l":[{"t":2657841,"n":"_objectChange","d":2788913,"h":4297756209,"f":2},{"t":2788913,"n":"Add","d":2788913,"h":8592723505,"f":33},{"t":2788913,"n":"Remove","d":2788913,"h":12887690801,"f":33},{"t":2788913,"n":"Name","d":2788913,"h":17182658097,"f":33},{"t":2788913,"n":"Value","d":2788913,"h":21477625393,"f":33}],"c":[{"p":[{"n":"objectChange","p":2657841}],"n":".ctor","o":"$ctor$2","d":2788913,"h":25772592689,"f":1}],"h":2788913}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Xml.Linq.XObjectChangeEventArgs`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XCData", ($self) => class XCData extends $.$spxl.System.Xml.Linq.XText
        {
            $ctor$6(/*string*/ value)
            {
                super.$ctor$3(value);
                {
                }
                return this;
            }
            $ctor$7(/*XCData*/ other)
            {
                super.$ctor$4(other);
                {
                }
                return this;
            }
            $ctor$8(/*XmlReader*/ r)
            {
                super.$ctor$5(r);
                {
                }
                return this;
            }
            /*XmlNodeType */ get NodeType()
            {
                return 4/*XmlNodeType.CDATA*/;
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                writer.WriteCData(this.text);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return writer.WriteCDataAsync(this.text);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XCData().$ctor$7(this);
            }
            static $h = 1216049;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2985521,"p":[{"p":52874332,"g":{"r":0,"d":0,"h":21476052529,"f":32769},"n":"NodeType","d":1216049,"h":17181085233,"f":32769}],"m":[{"r":65537,"p":[{"n":"writer","p":58444892}],"n":"WriteTo","d":1216049,"h":25771019825,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58444892},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":1216049,"h":30065987121,"f":32769},{"r":2264625,"n":"CloneNode","d":1216049,"h":34360954417,"f":32776}],"c":[{"p":[{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$6","d":1216049,"h":4296183345,"f":1},{"p":[{"n":"other","p":1216049}],"n":".ctor","o":"$ctor$7","d":1216049,"h":8591150641,"f":1},{"p":[{"n":"r","p":53398620}],"n":".ctor","o":"$ctor$8","d":1216049,"h":12886117937,"f":8}],"i":[13945948],"h":1216049}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XText; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XCData`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Channels", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Console", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Collections.Specialized", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Reflection.Emit", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Linq.Expressions", "NetJs.System.Text.RegularExpressions", "NetJs.System.Net.NetworkInformation", "NetJs.System.Net.Security", "NetJs.System.Net.Quic", "NetJs.System.Net.Http", "NetJs.System.Private.Xml"))