
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Private.Xml.Linq", 
    {"h":51628,"f":"System.Private.Xml.Linq","v":"1.0.35.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Private.Xml.Linq","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Private.Xml.Linq","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$spxl.System.Xml.Linq.XObject", ($self) => class XObject extends $.$spc.System.Object
        {
            /*XContainer?*/ parent = null;
            /*object?*/ annotations = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string */ get BaseUri()
            {
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        break;
                    }
                    /*BaseUriAnnotation?*/ let a = o.Annotation$1($.$spxl.System.Xml.Linq.BaseUriAnnotation);
                    if (a !== null)
                    {
                        return a.baseUri;
                    }
                    o = o.parent;
                }
                return $.$spc.System.String.Empty;
            }
            /*XDocument? */ get Document()
            {
                /*XObject*/ let n = this;
                while(n.parent !== null)
                {
                    n = n.parent;
                }
                /*XDocument?*/ let doc = $.$as(n, $.$spxl.System.Xml.Linq.XDocument);
                return doc;
            }
            /*XElement? */ get Parent()
            {
                return $.$as(this.parent, $.$spxl.System.Xml.Linq.XElement);
            }
            /*void */ AddAnnotation(/*object*/ annotation)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(annotation, "annotation");
                if (this.annotations === null)
                {
                    this.annotations = $.$is(annotation, $.$typeArray($.$spc.System.Object)) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [annotation], [-1], null) : annotation;
                }
                else 
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                    if (a === null)
                    {
                        this.annotations = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [this.annotations, annotation], [-1], null);
                    }
                    else 
                    {
                        /*int*/ let i = 0;
                        while(i < a.length && $.$spc.System.Array.$ReadT1.call(a, i) !== null)
                        {
                            i++;
                        }
                        if (i === a.length)
                        {
                            $.$spc.System.Array.Resize($.$spc.System.Object, $.$ref(() => a, ($v) => a = $v, $.$typeArray($.$spc.System.Object)), ((i * 2) | 0));
                            this.annotations = a;
                        }
                        $.$spc.System.Array.$WriteT1.call(a, annotation, i);
                    }
                }
            }
            /*object? */ Annotation(/*Type*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                    if (a === null)
                    {
                        if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(this.annotations, type))
                        {
                            return this.annotations;
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < a.length; i++)
                        {
                            /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(obj, type))
                            {
                                return obj;
                            }
                        }
                    }
                }
                return null;
            }
            /*object? */ AnnotationForSealedType(/*Type*/ type)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Inequality$1(type, null), "type != null");
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                    if (a === null)
                    {
                        if ($.$spc.System.Type.op_Equality$1($.$spc.System.Object.GetType.call(this.annotations), type))
                        {
                            return this.annotations;
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < a.length; i++)
                        {
                            /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if ($.$spc.System.Type.op_Equality$1($.$spc.System.Object.GetType.call(obj), type))
                            {
                                return obj;
                            }
                        }
                    }
                }
                return null;
            }
            /*T? */ Annotation$1(T)
            {
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                    if (a === null)
                    {
                        return $.$as(this.annotations, T);
                    }
                    for(/*int*/ let i = 0; i < a.length; i++)
                    {
                        /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(a, i);
                        if (obj === null)
                        {
                            break;
                        }
                        /*T?*/ let result = $.$as(obj, T);
                        if ($.$box(result, T) !== null)
                        {
                            return result;
                        }
                    }
                }
                return null;
            }
            /*IEnumerable<object> */ Annotations(/*Type*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                return this.AnnotationsIterator(type);
            }
            /*IEnumerable<object> */ AnnotationsIterator(/*Type*/ type)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    if (this.annotations !== null)
                    {
                        /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                        if (a === null)
                        {
                            if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(this.annotations, type))
                            {
                                yield this.annotations;
                            }
                        }
                        else 
                        {
                            for(/*int*/ let i = 0; i < a.length; i++)
                            {
                                /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(a, i);
                                if (obj === null)
                                {
                                    break;
                                }
                                if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(obj, type))
                                {
                                    yield obj;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*IEnumerable<T> */ Annotations$1(T)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    if (this.annotations !== null)
                    {
                        /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                        if (a === null)
                        {
                            /*T?*/ let result = $.$as(this.annotations, T);
                            if ($.$box(result, T) !== null)
                            {
                                yield result;
                            }
                        }
                        else 
                        {
                            for(/*int*/ let i = 0; i < a.length; i++)
                            {
                                /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(a, i);
                                if (obj === null)
                                {
                                    break;
                                }
                                /*T?*/ let result = $.$as(obj, T);
                                if ($.$box(result, T) !== null)
                                {
                                    yield result;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*void */ RemoveAnnotations(/*Type*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                    if (a === null)
                    {
                        if ($.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(this.annotations, type))
                        {
                            this.annotations = null;
                        }
                    }
                    else 
                    {
                        /*int*/ let i = 0, j = 0;
                        while(i < a.length)
                        {
                            /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if (!$.$spxl.System.Xml.Linq.XHelper.IsInstanceOfType(obj, type))
                            {
                                $.$spc.System.Array.$WriteT1.call(a, obj, j++);
                            }
                            i++;
                        }
                        if (j === 0)
                        {
                            this.annotations = null;
                        }
                        else 
                        {
                            while(j < i)
                            {
                                $.$spc.System.Array.$WriteT1.call(a, null, j++);
                            }
                        }
                    }
                }
            }
            /*void */ RemoveAnnotations$1(T)
            {
                if (this.annotations !== null)
                {
                    /*object?[]?*/ let a = $.$as(this.annotations, $.$typeArray($.$spc.System.Object));
                    if (a === null)
                    {
                        if ($.$is(this.annotations, T))
                        {
                            this.annotations = null;
                        }
                    }
                    else 
                    {
                        /*int*/ let i = 0, j = 0;
                        while(i < a.length)
                        {
                            /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(a, i);
                            if (obj === null)
                            {
                                break;
                            }
                            if (!($.$is(obj, T)))
                            {
                                $.$spc.System.Array.$WriteT1.call(a, obj, j++);
                            }
                            i++;
                        }
                        if (j === 0)
                        {
                            this.annotations = null;
                        }
                        else 
                        {
                            while(j < i)
                            {
                                $.$spc.System.Array.$WriteT1.call(a, null, j++);
                            }
                        }
                    }
                }
            }
            /*EventHandler<XObjectChangeEventArgs>*/ add_Changed(value)
            {
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    a = new $.$spxl.System.Xml.Linq.XObjectChangeAnnotation().$ctor$1();
                    this.AddAnnotation(a);
                }
                a.changed = $.$spc.System.Delegate.Combine(a.changed, value);
            }
            /*EventHandler<XObjectChangeEventArgs>*/ remove_Changed(value)
            {
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    return;
                }
                a.changed = $.$spc.System.Delegate.Remove(a.changed, value);
                if (a.changing === null && a.changed === null)
                {
                    this.RemoveAnnotations$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                }
            }
            /*EventHandler<XObjectChangeEventArgs>*/ add_Changing(value)
            {
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    a = new $.$spxl.System.Xml.Linq.XObjectChangeAnnotation().$ctor$1();
                    this.AddAnnotation(a);
                }
                a.changing = $.$spc.System.Delegate.Combine(a.changing, value);
            }
            /*EventHandler<XObjectChangeEventArgs>*/ remove_Changing(value)
            {
                if (value === null)
                {
                    return;
                }
                /*XObjectChangeAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                if (a === null)
                {
                    return;
                }
                a.changing = $.$spc.System.Delegate.Remove(a.changing, value);
                if (a.changing === null && a.changed === null)
                {
                    this.RemoveAnnotations$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                }
            }
            /*bool */ System$Xml$IXmlLineInfo$HasLineInfo()
            {
                return this.Annotation$1($.$spxl.System.Xml.Linq.LineInfoAnnotation) !== null;
            }
            /*int */ get System$Xml$IXmlLineInfo$LineNumber()
            {
                /*LineInfoAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.LineInfoAnnotation);
                if (a !== null)
                {
                    return a.lineNumber;
                }
                return 0;
            }
            /*int */ get System$Xml$IXmlLineInfo$LinePosition()
            {
                /*LineInfoAnnotation?*/ let a = this.Annotation$1($.$spxl.System.Xml.Linq.LineInfoAnnotation);
                if (a !== null)
                {
                    return a.linePosition;
                }
                return 0;
            }
            /*bool */ get HasBaseUri()
            {
                return this.Annotation$1($.$spxl.System.Xml.Linq.BaseUriAnnotation) !== null;
            }
            /*bool */ NotifyChanged(/*object*/ sender, /*XObjectChangeEventArgs*/ e)
            {
                /*bool*/ let notify = false;
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        break;
                    }
                    /*XObjectChangeAnnotation?*/ let a = o.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                    if (a !== null)
                    {
                        notify = true;
                        a.changed?.Invoke(sender, e);
                    }
                    o = o.parent;
                }
                return notify;
            }
            /*bool */ NotifyChanging(/*object*/ sender, /*XObjectChangeEventArgs*/ e)
            {
                /*bool*/ let notify = false;
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        break;
                    }
                    /*XObjectChangeAnnotation?*/ let a = o.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation);
                    if (a !== null)
                    {
                        notify = true;
                        a.changing?.Invoke(sender, e);
                    }
                    o = o.parent;
                }
                return notify;
            }
            /*void */ SetBaseUri(/*string*/ baseUri)
            {
                this.AddAnnotation(new $.$spxl.System.Xml.Linq.BaseUriAnnotation().$ctor$1(baseUri));
            }
            /*void */ SetLineInfo(/*int*/ lineNumber, /*int*/ linePosition)
            {
                this.AddAnnotation(new $.$spxl.System.Xml.Linq.LineInfoAnnotation().$ctor$1(lineNumber, linePosition));
            }
            /*bool */ SkipNotify()
            {
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        return true;
                    }
                    if (o.Annotation$1($.$spxl.System.Xml.Linq.XObjectChangeAnnotation) !== null)
                    {
                        return false;
                    }
                    o = o.parent;
                }
            }
            /*SaveOptions */ GetSaveOptionsFromAnnotations()
            {
                /*XObject?*/ let o = this;
                while(true)
                {
                    while(o !== null && o.annotations === null)
                    {
                        o = o.parent;
                    }
                    if (o === null)
                    {
                        return 0/*SaveOptions.None*/;
                    }
                    /*object?*/ let saveOptions = o.AnnotationForSealedType($.$spxl.System.Xml.Linq.SaveOptions.$type);
                    if (saveOptions !== null)
                    {
                        return $.$cast(saveOptions, $.$spxl.System.Xml.Linq.SaveOptions);
                    }
                    o = o.parent;
                }
            }
            static $h = 2607532;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21477444012,"f":1},"n":"BaseUri","d":2607532,"h":17182476716,"f":1},{"p":1558956,"g":{"r":0,"d":0,"h":30067378604,"f":1},"n":"Document","d":2607532,"h":25772411308,"f":1},{"p":52865181,"g":{"r":0,"d":0,"h":38657313196,"f":257},"n":"NodeType","d":2607532,"h":34362345900,"f":257},{"p":1690028,"g":{"r":0,"d":0,"h":47247247788,"f":1},"n":"Parent","d":2607532,"h":42952280492,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":124556659116,"f":2},"n":"{13936797}.LineNumber","o":"System$Xml$IXmlLineInfo$LineNumber","d":2607532,"h":120261691820,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":133146593708,"f":2},"n":"{13936797}.LinePosition","o":"System$Xml$IXmlLineInfo$LinePosition","d":2607532,"h":128851626412,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":141736528300,"f":8},"n":"HasBaseUri","d":2607532,"h":137441561004,"f":8}],"m":[{"r":65537,"p":[{"n":"annotation","p":131073}],"n":"AddAnnotation","d":2607532,"h":51542215084,"f":1},{"r":131073,"p":[{"n":"type","p":142606337}],"n":"Annotation","d":2607532,"h":55837182380,"f":1},{"r":131073,"p":[{"n":"type","p":142606337}],"n":"AnnotationForSealedType","d":2607532,"h":60132149676,"f":2},{"r":(T) => T.$h,"g":["T"],"n":"Annotation","o":"@$1","d":2607532,"h":64427116972,"f":131073},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Object).$h,"p":[{"n":"type","p":142606337}],"n":"Annotations","d":2607532,"h":68722084268,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Object).$h,"p":[{"n":"type","p":142606337}],"n":"AnnotationsIterator","d":2607532,"h":73017051564,"f":2},{"r":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h,"g":["T"],"n":"Annotations","o":"@$1","d":2607532,"h":77312018860,"f":131073},{"r":65537,"p":[{"n":"type","p":142606337}],"n":"RemoveAnnotations","d":2607532,"h":81606986156,"f":1},{"r":65537,"g":["T"],"n":"RemoveAnnotations","o":"@$1","d":2607532,"h":85901953452,"f":131073},{"r":262145,"p":[{"n":"sender","p":131073},{"n":"e","p":2804140}],"n":"NotifyChanged","d":2607532,"h":146031495596,"f":8},{"r":262145,"p":[{"n":"sender","p":131073},{"n":"e","p":2804140}],"n":"NotifyChanging","d":2607532,"h":150326462892,"f":8},{"r":65537,"p":[{"n":"baseUri","p":1310721}],"n":"SetBaseUri","d":2607532,"h":154621430188,"f":8},{"r":65537,"p":[{"n":"lineNumber","p":655361},{"n":"linePosition","p":655361}],"n":"SetLineInfo","d":2607532,"h":158916397484,"f":8},{"r":262145,"n":"SkipNotify","d":2607532,"h":163211364780,"f":8},{"r":1034668,"n":"GetSaveOptionsFromAnnotations","d":2607532,"h":167506332076,"f":8}],"l":[{"t":1362348,"n":"parent","d":2607532,"h":4297574828,"f":8},{"t":131073,"n":"annotations","d":2607532,"h":8592542124,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":2607532,"h":12887509420,"f":8}],"e":[{"e":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h}],"n":"add_Changed","d":2607532,"h":94491888044,"f":1},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h}],"n":"remove_Changed","d":2607532,"h":98786855340,"f":1},"n":"Changed","d":2607532,"h":90196920748,"f":1},{"e":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h}],"n":"add_Changing","d":2607532,"h":107376789932,"f":1},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h}],"n":"remove_Changing","d":2607532,"h":111671757228,"f":1},"n":"Changing","d":2607532,"h":103081822636,"f":1}],"i":[13936797],"h":2607532}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XObject`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNode", ($self) => class XNode extends $.$spxl.System.Xml.Linq.XObject
        {
            /*XNode?*/ next = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*XNode? */ get NextNode()
            {
                return this.parent === null || this === this.parent.content ? null : this.next;
            }
            /*XNode? */ get PreviousNode()
            {
                if (this.parent === null)
                {
                    return null;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this.parent.content !== null, "parent.content != null");
                /*XNode*/ let n = ($.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode)).next;
                /*XNode?*/ let p = null;
                while(n !== this)
                {
                    p = n;
                    n = n.next;
                }
                return p;
            }
            /*XNodeDocumentOrderComparer*/ static DocumentOrderComparer$ = null;
            static /*XNodeDocumentOrderComparer */ get DocumentOrderComparer()
            {
                return $.$spxl.System.Xml.Linq.XNode.DocumentOrderComparer$ ??= new $.$spxl.System.Xml.Linq.XNodeDocumentOrderComparer().$ctor$1();
            }
            /*XNodeEqualityComparer*/ static EqualityComparer$ = null;
            static /*XNodeEqualityComparer */ get EqualityComparer()
            {
                return $.$spxl.System.Xml.Linq.XNode.EqualityComparer$ ??= new $.$spxl.System.Xml.Linq.XNodeEqualityComparer().$ctor$1();
            }
            /*void */ AddAfterSelf(/*object?*/ content)
            {
                if (this.parent === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$2(this.parent, this).Add(content);
            }
            /*void */ AddAfterSelf$1(/*params object?[]*/ content)
            {
                this.AddAfterSelf($.$cast(content, $.$spc.System.Object));
            }
            /*void */ AddBeforeSelf(/*object?*/ content)
            {
                if (this.parent === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                /*XNode?*/ let p = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                while(p.next !== this)
                {
                    p = p.next;
                }
                if (p === this.parent.content)
                {
                    p = null;
                }
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$2(this.parent, p).Add(content);
            }
            /*void */ AddBeforeSelf$1(/*params object?[]*/ content)
            {
                this.AddBeforeSelf($.$cast(content, $.$spc.System.Object));
            }
            /*IEnumerable<XElement> */ Ancestors()
            {
                return this.GetAncestors(null, false);
            }
            /*IEnumerable<XElement> */ Ancestors$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetAncestors(name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*int */ CompareDocumentOrder(/*XNode?*/ n1, /*XNode?*/ n2)
            {
                if (n1 === n2)
                {
                    return 0;
                }
                if (n1 === null)
                {
                    return -1;
                }
                if (n2 === null)
                {
                    return 1;
                }
                if (n1.parent !== n2.parent)
                {
                    /*int*/ let height = 0;
                    /*XNode*/ let p1 = n1;
                    while(p1.parent !== null)
                    {
                        p1 = p1.parent;
                        height++;
                    }
                    /*XNode*/ let p2 = n2;
                    while(p2.parent !== null)
                    {
                        p2 = p2.parent;
                        height--;
                    }
                    if (p1 !== p2)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingAncestor);
                    }
                    if (height < 0)
                    {
                        do
                        {
                            n2 = n2.parent;
                            height++;
                        }
                        while(height !== 0);
                        if (n1 === n2)
                        {
                            return -1;
                        }
                    }
                    else if (height > 0)
                    {
                        do
                        {
                            n1 = n1.parent;
                            height--;
                        }
                        while(height !== 0);
                        if (n1 === n2)
                        {
                            return 1;
                        }
                    }
                    while(n1.parent !== n2.parent)
                    {
                        n1 = n1.parent;
                        n2 = n2.parent;
                    }
                }
                else if (n1.parent === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingAncestor);
                }
                /*XNode*/ let n = $.$cast(n1.parent.content, $.$spxl.System.Xml.Linq.XNode);
                while(true)
                {
                    n = n.next;
                    if (n === n1)
                    {
                        return -1;
                    }
                    if (n === n2)
                    {
                        return 1;
                    }
                }
            }
            /*XmlReader */ CreateReader()
            {
                return new $.$spxl.System.Xml.Linq.XNodeReader().$ctor$3(this, null);
            }
            /*XmlReader */ CreateReader$1(/*ReaderOptions*/ readerOptions)
            {
                return new $.$spxl.System.Xml.Linq.XNodeReader().$ctor$2(this, null, readerOptions);
            }
            /*IEnumerable<XNode> */ NodesAfterSelf()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*XNode*/ let n = this;
                    while(n.parent !== null && n !== n.parent.content)
                    {
                        n = n.next;
                        yield n;
                    }
                }.bind(this));
            }
            /*IEnumerable<XNode> */ NodesBeforeSelf()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    if (this.parent !== null)
                    {
                        /*XNode*/ let n = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                        do
                        {
                            n = n.next;
                            if (n === this)
                            {
                                break;
                            }
                            yield n;
                        }
                        while(this.parent !== null && this.parent === n.parent);
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ ElementsAfterSelf()
            {
                return this.GetElementsAfterSelf(null);
            }
            /*IEnumerable<XElement> */ ElementsAfterSelf$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetElementsAfterSelf(name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*IEnumerable<XElement> */ ElementsBeforeSelf()
            {
                return this.GetElementsBeforeSelf(null);
            }
            /*IEnumerable<XElement> */ ElementsBeforeSelf$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetElementsBeforeSelf(name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*bool */ IsAfter(/*XNode?*/ node)
            {
                return $.$spxl.System.Xml.Linq.XNode.CompareDocumentOrder(this, node) > 0;
            }
            /*bool */ IsBefore(/*XNode?*/ node)
            {
                return $.$spxl.System.Xml.Linq.XNode.CompareDocumentOrder(this, node) < 0;
            }
            static /*XNode */ ReadFrom(/*XmlReader*/ reader)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                if (reader.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                let $switch1 = reader.NodeType;
                switch($switch1)
                {
                    case 3/*XmlNodeType.Text*/:
                    case 14/*XmlNodeType.SignificantWhitespace*/:
                    case 13/*XmlNodeType.Whitespace*/:
                    return new $.$spxl.System.Xml.Linq.XText().$ctor$5(reader);
                    case 4/*XmlNodeType.CDATA*/:
                    return new $.$spxl.System.Xml.Linq.XCData().$ctor$8(reader);
                    case 8/*XmlNodeType.Comment*/:
                    return new $.$spxl.System.Xml.Linq.XComment().$ctor$5(reader);
                    case 10/*XmlNodeType.DocumentType*/:
                    return new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$5(reader);
                    case 1/*XmlNodeType.Element*/:
                    return new $.$spxl.System.Xml.Linq.XElement().$ctor$11(reader);
                    case 7/*XmlNodeType.ProcessingInstruction*/:
                    return new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$5(reader);
                    default:
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                }
            }
            static /*Task<XNode> */ ReadFromAsync(/*XmlReader*/ reader, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spxl.System.Xml.Linq.XNode, cancellationToken);
                }
                return $.$spxl.System.Xml.Linq.XNode.ReadFromAsyncInternal(reader, cancellationToken);
            }
            static /*Task<XNode> *//*async*/  ReadFromAsyncInternal(/*XmlReader*/ reader, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XNode), $.$spxl.System.Xml.Linq.XNode, async () => 
                {
                    if (reader.ReadState !== 1/*ReadState.Interactive*/)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                    }
                    /*XNode*/ let ret;
                    let $switch1 = reader.NodeType;
                    switch($switch1)
                    {
                        case 3/*XmlNodeType.Text*/:
                        case 14/*XmlNodeType.SignificantWhitespace*/:
                        case 13/*XmlNodeType.Whitespace*/:
                        ret = new $.$spxl.System.Xml.Linq.XText().$ctor$3(reader.Value);
                        break;
                        case 4/*XmlNodeType.CDATA*/:
                        ret = new $.$spxl.System.Xml.Linq.XCData().$ctor$6(reader.Value);
                        break;
                        case 8/*XmlNodeType.Comment*/:
                        ret = new $.$spxl.System.Xml.Linq.XComment().$ctor$3(reader.Value);
                        break;
                        case 10/*XmlNodeType.DocumentType*/:
                        /*var*/ let name = reader.Name;
                        /*var*/ let publicId = reader.GetAttribute("PUBLIC");
                        /*var*/ let systemId = reader.GetAttribute("SYSTEM");
                        /*var*/ let internalSubset = reader.Value;
                        ret = new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(name, publicId, systemId, internalSubset);
                        break;
                        case 1/*XmlNodeType.Element*/:
                        return await $.$spxl.System.Xml.Linq.XElement.CreateAsync(reader, cancellationToken).ConfigureAwait$2(false);
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        /*var*/ let target = reader.Name;
                        /*var*/ let data = reader.Value;
                        ret = new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(target, data);
                        break;
                        default:
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                    }
                    cancellationToken.ThrowIfCancellationRequested();
                    await reader.ReadAsync().ConfigureAwait$2(false);
                    return ret;
                });
            }
            /*void */ Remove()
            {
                if (this.parent === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                this.parent.RemoveNode(this);
            }
            /*void */ ReplaceWith(/*object?*/ content)
            {
                if (this.parent === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                /*XContainer*/ let c = this.parent;
                /*XNode?*/ let p = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                while(p.next !== this)
                {
                    p = p.next;
                }
                if (p === this.parent.content)
                {
                    p = null;
                }
                this.parent.RemoveNode(this);
                if (p !== null && p.parent !== c)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$2(c, p).Add(content);
            }
            /*void */ ReplaceWith$1(/*params object?[]*/ content)
            {
                this.ReplaceWith($.$cast(content, $.$spc.System.Object));
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.GetXmlString(this.GetSaveOptionsFromAnnotations());
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XNode.ToString.apply(this, arguments); }
            /*string */ ToString$1(/*SaveOptions*/ options)
            {
                return this.GetXmlString(options);
            }
            static /*bool */ DeepEquals(/*XNode?*/ n1, /*XNode?*/ n2)
            {
                if (n1 === n2)
                {
                    return true;
                }
                if (n1 === null || n2 === null)
                {
                    return false;
                }
                return n1.DeepEquals$1(n2);
            }
            /*void */ AppendText(/*StringBuilder*/ sb)
            {
            }
            /*IEnumerable<XElement> */ GetAncestors(/*XName?*/ name, /*bool*/ self)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*XElement?*/ let e = $.$as((self ? this : this.parent), $.$spxl.System.Xml.Linq.XElement);
                    while(e !== null)
                    {
                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                        {
                            yield e;
                        }
                        e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ GetElementsAfterSelf(/*XName?*/ name)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*XNode*/ let n = this;
                    while(n.parent !== null && n !== n.parent.content)
                    {
                        n = n.next;
                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                        {
                            yield e;
                        }
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ GetElementsBeforeSelf(/*XName?*/ name)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    if (this.parent !== null)
                    {
                        /*XNode*/ let n = $.$cast(this.parent.content, $.$spxl.System.Xml.Linq.XNode);
                        do
                        {
                            n = n.next;
                            if (n === this)
                            {
                                break;
                            }
                            /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                            if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                            {
                                yield e;
                            }
                        }
                        while(this.parent !== null && this.parent === n.parent);
                    }
                }.bind(this));
            }
            static /*XmlReaderSettings */ GetXmlReaderSettings(/*LoadOptions*/ o)
            {
                /*XmlReaderSettings*/ let rs = new $.$spx.System.Xml.XmlReaderSettings().$ctor$1();
                if ((o & 1/*LoadOptions.PreserveWhitespace*/) === 0)
                {
                    rs.IgnoreWhitespace = true;
                }
                rs.DtdProcessing = $.$cast(2, $.$spx.System.Xml.DtdProcessing);
                rs.MaxCharactersFromEntities = $.$cast(10000000n, $.$spc.System.Int64);
                return rs;
            }
            static /*XmlWriterSettings */ GetXmlWriterSettings(/*SaveOptions*/ o)
            {
                /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                if ((o & 1/*SaveOptions.DisableFormatting*/) === 0)
                {
                    ws.Indent = true;
                }
                if ((o & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0)
                {
                    ws.NamespaceHandling |= 1/*NamespaceHandling.OmitDuplicates*/;
                }
                return ws;
            }
            /*string */ GetXmlString(/*SaveOptions*/ o)
            {
                let sw = null;
                try
                {
                    sw = new $.$spc.System.IO.StringWriter().$ctor$5($.$spc.System.Globalization.CultureInfo.InvariantCulture);
                    /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                    ws.OmitXmlDeclaration = true;
                    if ((o & 1/*SaveOptions.DisableFormatting*/) === 0)
                    {
                        ws.Indent = true;
                    }
                    if ((o & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0)
                    {
                        ws.NamespaceHandling |= 1/*NamespaceHandling.OmitDuplicates*/;
                    }
                    if ($.$is(this, $.$spxl.System.Xml.Linq.XText))
                    {
                        ws.ConformanceLevel = 1/*ConformanceLevel.Fragment*/;
                    }
                    let w = null;
                    try
                    {
                        w = $.$spx.System.Xml.XmlWriter.Create$5(sw, ws);
                        /*XDocument?*/ let n = $.$as(this, $.$spxl.System.Xml.Linq.XDocument);
                        if (n !== null)
                        {
                            n.WriteContentTo(w);
                        }
                        else 
                        {
                            this.WriteTo(w);
                        }
                    }
                    finally
                    {
                        w?.System$IDisposable$Dispose();
                    }
                    return $.$spc.System.IO.StringWriter.ToString.call(sw);
                }
                finally
                {
                    sw?.System$IDisposable$Dispose();
                }
            }
            static $h = 2279852;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2607532,"p":[{"p":2279852,"g":{"r":0,"d":0,"h":17182149036,"f":1},"n":"NextNode","d":2279852,"h":12887181740,"f":1},{"p":2279852,"g":{"r":0,"d":0,"h":25772083628,"f":1},"n":"PreviousNode","d":2279852,"h":21477116332,"f":1},{"p":2410924,"g":{"r":0,"d":0,"h":38656985516,"f":33},"n":"DocumentOrderComparer","d":2279852,"h":34362018220,"f":33},{"p":2476460,"g":{"r":0,"d":0,"h":51541887404,"f":33},"n":"EqualityComparer","d":2279852,"h":47246920108,"f":33}],"m":[{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddAfterSelf","d":2279852,"h":55836854700,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"AddAfterSelf","o":"@$1","d":2279852,"h":60131821996,"f":1},{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddBeforeSelf","d":2279852,"h":64426789292,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"AddBeforeSelf","o":"@$1","d":2279852,"h":68721756588,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"Ancestors","d":2279852,"h":73016723884,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2148780}],"n":"Ancestors","o":"@$1","d":2279852,"h":77311691180,"f":1},{"r":655361,"p":[{"n":"n1","p":2279852},{"n":"n2","p":2279852}],"n":"CompareDocumentOrder","d":2279852,"h":81606658476,"f":33},{"r":53389469,"n":"CreateReader","d":2279852,"h":85901625772,"f":1},{"r":53389469,"p":[{"n":"readerOptions","p":969132}],"n":"CreateReader","o":"@$1","d":2279852,"h":90196593068,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"NodesAfterSelf","d":2279852,"h":94491560364,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"NodesBeforeSelf","d":2279852,"h":98786527660,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"ElementsAfterSelf","d":2279852,"h":103081494956,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2148780}],"n":"ElementsAfterSelf","o":"@$1","d":2279852,"h":107376462252,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"ElementsBeforeSelf","d":2279852,"h":111671429548,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2148780}],"n":"ElementsBeforeSelf","o":"@$1","d":2279852,"h":115966396844,"f":1},{"r":262145,"p":[{"n":"node","p":2279852}],"n":"IsAfter","d":2279852,"h":120261364140,"f":1},{"r":262145,"p":[{"n":"node","p":2279852}],"n":"IsBefore","d":2279852,"h":124556331436,"f":1},{"r":2279852,"p":[{"n":"reader","p":53389469}],"n":"ReadFrom","d":2279852,"h":128851298732,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"reader","p":53389469},{"n":"cancellationToken","p":125960193}],"n":"ReadFromAsync","d":2279852,"h":133146266028,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"reader","p":53389469},{"n":"cancellationToken","p":125960193}],"n":"ReadFromAsyncInternal","d":2279852,"h":137441233324,"f":4130},{"r":65537,"n":"Remove","d":2279852,"h":141736200620,"f":1},{"r":65537,"p":[{"n":"content","p":131073}],"n":"ReplaceWith","d":2279852,"h":146031167916,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"ReplaceWith","o":"@$1","d":2279852,"h":150326135212,"f":1},{"r":1310721,"n":"ToString","d":2279852,"h":154621102508,"f":32769},{"r":1310721,"p":[{"n":"options","p":1034668}],"n":"ToString","o":"@$1","d":2279852,"h":158916069804,"f":1},{"r":262145,"p":[{"n":"n1","p":2279852},{"n":"n2","p":2279852}],"n":"DeepEquals","d":2279852,"h":163211037100,"f":33},{"r":65537,"p":[{"n":"writer","p":58435741}],"n":"WriteTo","d":2279852,"h":167506004396,"f":257},{"r":133300225,"p":[{"n":"writer","p":58435741},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":2279852,"h":171800971692,"f":257},{"r":65537,"p":[{"n":"sb","p":122945537}],"n":"AppendText","d":2279852,"h":176095938988,"f":136},{"r":2279852,"n":"CloneNode","d":2279852,"h":180390906284,"f":264},{"r":262145,"p":[{"n":"node","p":2279852}],"n":"DeepEquals","o":"@$1","d":2279852,"h":184685873580,"f":264},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2148780},{"n":"self","p":262145}],"n":"GetAncestors","d":2279852,"h":188980840876,"f":8},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2148780}],"n":"GetElementsAfterSelf","d":2279852,"h":193275808172,"f":2},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2148780}],"n":"GetElementsBeforeSelf","d":2279852,"h":197570775468,"f":2},{"r":655361,"n":"GetDeepHashCode","d":2279852,"h":201865742764,"f":264},{"r":53520541,"p":[{"n":"o","p":706988}],"n":"GetXmlReaderSettings","d":2279852,"h":206160710060,"f":40},{"r":58501277,"p":[{"n":"o","p":1034668}],"n":"GetXmlWriterSettings","d":2279852,"h":210455677356,"f":40},{"r":1310721,"p":[{"n":"o","p":1034668}],"n":"GetXmlString","d":2279852,"h":214750644652,"f":2}],"l":[{"t":2279852,"n":"next","d":2279852,"h":4297247148,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":2279852,"h":8592214444,"f":8}],"i":[13936797],"h":2279852}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XObject; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XNode`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XContainer", ($self) => class XContainer extends $.$spxl.System.Xml.Linq.XNode
        {
            /*object?*/ content = null;
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*XContainer*/ other)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    if ($.$is(other.content, $.$spc.System.String))
                    {
                        this.content = other.content;
                    }
                    else 
                    {
                        /*XNode?*/ let n = $.$cast(other.content, $.$spxl.System.Xml.Linq.XNode);
                        if (n !== null)
                        {
                            do
                            {
                                n = n.next;
                                this.AppendNodeSkipNotify(n.CloneNode());
                            }
                            while(n !== other.content);
                        }
                    }
                }
                return this;
            }
            /*XNode? */ get FirstNode()
            {
                return this.LastNode?.next;
            }
            /*XNode? */ get LastNode()
            {
                if (this.content === null)
                {
                    return null;
                }
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    return n;
                }
                /*string?*/ let s = $.$as(this.content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    if (s.length === 0)
                    {
                        return null;
                    }
                    /*XText*/ let t = new $.$spxl.System.Xml.Linq.XText().$ctor$3(s);
                    t.parent = this;
                    t.next = t;
                    $.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => this.content, ($v) => this.content = $v, $.$spc.System.Object), t, s);
                }
                return $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
            }
            /*void */ Add(/*object?*/ content)
            {
                if (this.SkipNotify())
                {
                    this.AddContentSkipNotify(content);
                    return;
                }
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.AddNode(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    this.AddString(s);
                    return;
                }
                /*XAttribute?*/ let a = $.$as(content, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    this.AddAttribute(a);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$9(x));
                    return;
                }
                /*object?[]?*/ let o = $.$as(content, $.$typeArray($.$spc.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.Add(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$spc.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.Add(obj);
                        }
                    }
                    return;
                }
                this.AddString($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            /*void */ Add$1(/*params object?[]*/ content)
            {
                this.Add($.$cast(content, $.$spc.System.Object));
            }
            /*void */ AddFirst(/*object?*/ content)
            {
                new $.$spxl.System.Xml.Linq.Inserter().$ctor$2(this, null).Add(content);
            }
            /*void */ AddFirst$1(/*params object?[]*/ content)
            {
                this.AddFirst($.$cast(content, $.$spc.System.Object));
            }
            /*XmlWriter */ CreateWriter()
            {
                /*XmlWriterSettings*/ let settings = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                settings.ConformanceLevel = $.$is(this, $.$spxl.System.Xml.Linq.XDocument) ? 2/*ConformanceLevel.Document*/ : 1/*ConformanceLevel.Fragment*/;
                return $.$spx.System.Xml.XmlWriter.Create$9(new $.$spxl.System.Xml.Linq.XNodeBuilder().$ctor$2(this), settings);
            }
            /*IEnumerable<XNode> */ DescendantNodes()
            {
                return this.GetDescendantNodes(false);
            }
            /*IEnumerable<XElement> */ Descendants()
            {
                return this.GetDescendants(null, false);
            }
            /*IEnumerable<XElement> */ Descendants$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetDescendants(name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*XElement? */ Element(/*XName*/ name)
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (e !== null && $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                        {
                            return e;
                        }
                    }
                    while(n !== this.content);
                }
                return null;
            }
            /*IEnumerable<XElement> */ Elements()
            {
                return this.GetElements(null);
            }
            /*IEnumerable<XElement> */ Elements$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetElements(name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*IEnumerable<XNode> */ Nodes()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*XNode?*/ let n = this.LastNode;
                    if (n !== null)
                    {
                        do
                        {
                            n = n.next;
                            yield n;
                        }
                        while(n.parent === this && n !== this.content);
                    }
                }.bind(this));
            }
            /*void */ RemoveNodes()
            {
                if (this.SkipNotify())
                {
                    this.RemoveNodesSkipNotify();
                    return;
                }
                while(this.content !== null)
                {
                    /*string?*/ let s = $.$as(this.content, $.$spc.System.String);
                    if ($.$spc.System.String.op_Inequality(s, null))
                    {
                        if (s.length > 0)
                        {
                            this.ConvertTextToNode();
                        }
                        else 
                        {
                            if ($.$is(this, $.$spxl.System.Xml.Linq.XElement))
                            {
                                this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                                if (s !== this.content)
                                {
                                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                                }
                                this.content = null;
                                this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                            }
                            else 
                            {
                                this.content = null;
                            }
                        }
                    }
                    /*XNode?*/ let last = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                    if (last !== null)
                    {
                        /*XNode*/ let n = last.next;
                        this.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                        if (last !== this.content || n !== last.next)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                        }
                        if (n !== last)
                        {
                            last.next = n.next;
                        }
                        else 
                        {
                            this.content = null;
                        }
                        n.parent = null;
                        n.next = null;
                        this.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                    }
                }
            }
            /*void */ ReplaceNodes(/*object?*/ content)
            {
                content = $.$spxl.System.Xml.Linq.XContainer.GetContentSnapshot(content);
                this.RemoveNodes();
                this.Add(content);
            }
            /*void */ ReplaceNodes$1(/*params object?[]*/ content)
            {
                this.ReplaceNodes($.$cast(content, $.$spc.System.Object));
            }
            /*void */ AddAttribute(/*XAttribute*/ a)
            {
            }
            /*void */ AddAttributeSkipNotify(/*XAttribute*/ a)
            {
            }
            /*void */ AddContentSkipNotify(/*object?*/ content)
            {
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.AddNodeSkipNotify(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    this.AddStringSkipNotify(s);
                    return;
                }
                /*XAttribute?*/ let a = $.$as(content, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    this.AddAttributeSkipNotify(a);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XElement().$ctor$9(x));
                    return;
                }
                /*object?[]?*/ let o = $.$as(content, $.$typeArray($.$spc.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.AddContentSkipNotify(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$spc.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.AddContentSkipNotify(obj);
                        }
                    }
                    return;
                }
                this.AddStringSkipNotify($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            /*void */ AddNode(/*XNode*/ n)
            {
                this.ValidateNode(n, this);
                if (n.parent !== null)
                {
                    n = n.CloneNode();
                }
                else 
                {
                    /*XNode*/ let p = this;
                    while(p.parent !== null)
                    {
                        p = p.parent;
                    }
                    if (n === p)
                    {
                        n = n.CloneNode();
                    }
                }
                this.ConvertTextToNode();
                this.AppendNode(n);
            }
            /*void */ AddNodeSkipNotify(/*XNode*/ n)
            {
                this.ValidateNode(n, this);
                if (n.parent !== null)
                {
                    n = n.CloneNode();
                }
                else 
                {
                    /*XNode*/ let p = this;
                    while(p.parent !== null)
                    {
                        p = p.parent;
                    }
                    if (n === p)
                    {
                        n = n.CloneNode();
                    }
                }
                this.ConvertTextToNode();
                this.AppendNodeSkipNotify(n);
            }
            /*void */ AddString(/*string*/ s)
            {
                this.ValidateString(s);
                if (this.content === null)
                {
                    if (s.length > 0)
                    {
                        this.AppendNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(s));
                    }
                    else 
                    {
                        if ($.$is(this, $.$spxl.System.Xml.Linq.XElement))
                        {
                            this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                            if (this.content !== null)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                            }
                            this.content = s;
                            this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                        }
                        else 
                        {
                            this.content = s;
                        }
                    }
                }
                else if (s.length > 0)
                {
                    this.ConvertTextToNode();
                    /*XText?*/ let tn = $.$as(this.content, $.$spxl.System.Xml.Linq.XText);
                    if (tn !== null && !($.$is(tn, $.$spxl.System.Xml.Linq.XCData)))
                    {
                        tn.Value += s;
                    }
                    else 
                    {
                        this.AppendNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(s));
                    }
                }
            }
            /*void */ AddStringSkipNotify(/*string*/ s)
            {
                this.ValidateString(s);
                if (this.content === null)
                {
                    this.content = s;
                }
                else if (s.length > 0)
                {
                    /*string?*/ let stringContent = $.$as(this.content, $.$spc.System.String);
                    if ($.$spc.System.String.op_Inequality(stringContent, null))
                    {
                        this.content = stringContent + s;
                    }
                    else 
                    {
                        /*XText?*/ let tn = $.$as(this.content, $.$spxl.System.Xml.Linq.XText);
                        if (tn !== null && !($.$is(tn, $.$spxl.System.Xml.Linq.XCData)))
                        {
                            tn.text += s;
                        }
                        else 
                        {
                            this.AppendNodeSkipNotify(new $.$spxl.System.Xml.Linq.XText().$ctor$3(s));
                        }
                    }
                }
            }
            /*void */ AppendNode(/*XNode*/ n)
            {
                /*bool*/ let notify = this.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                if (n.parent !== null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                this.AppendNodeSkipNotify(n);
                if (notify)
                {
                    this.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                }
            }
            /*void */ AppendNodeSkipNotify(/*XNode*/ n)
            {
                n.parent = this;
                if (this.content === null || $.$is(this.content, $.$spc.System.String))
                {
                    n.next = n;
                }
                else 
                {
                    /*XNode*/ let x = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                    n.next = x.next;
                    x.next = n;
                }
                this.content = n;
            }
            /*void */ AppendText(/*StringBuilder*/ sb)
            {
                /*string?*/ let s = $.$as(this.content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    sb.Append$2(s);
                }
                else 
                {
                    /*XNode?*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                    if (n !== null)
                    {
                        do
                        {
                            n = n.next;
                            n.AppendText(sb);
                        }
                        while(n !== this.content);
                    }
                }
            }
            /*string? */ GetTextOnly()
            {
                if (this.content === null)
                {
                    return null;
                }
                /*string?*/ let s = $.$as(this.content, $.$spc.System.String);
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    /*XNode*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                    do
                    {
                        n = n.next;
                        if (n.NodeType !== 3/*XmlNodeType.Text*/)
                        {
                            return null;
                        }
                        s += ($.$cast(n, $.$spxl.System.Xml.Linq.XText)).Value;
                    }
                    while(n !== this.content);
                }
                return s;
            }
            /*string */ CollectText(/*ref XNode?*/ n)
            {
                /*string*/ let s = "";
                while(n.$v !== null && n.$v.NodeType === 3/*XmlNodeType.Text*/)
                {
                    s += ($.$cast(n.$v, $.$spxl.System.Xml.Linq.XText)).Value;
                    n.$v = n.$v !== this.content ? n.$v.next : null;
                }
                return s;
            }
            /*bool */ ContentsEqual(/*XContainer*/ e)
            {
                if (this.content === e.content)
                {
                    return true;
                }
                /*string?*/ let s = this.GetTextOnly();
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    return $.$spc.System.String.op_Equality(s, e.GetTextOnly());
                }
                /*XNode?*/ let n1 = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                /*XNode?*/ let n2 = $.$as(e.content, $.$spxl.System.Xml.Linq.XNode);
                if (n1 !== null && n2 !== null)
                {
                    n1 = n1.next;
                    n2 = n2.next;
                    while(true)
                    {
                        if ($.$spc.System.String.op_Inequality(this.CollectText($.$ref(() => n1, ($v) => n1 = $v, $.$spxl.System.Xml.Linq.XNode)), e.CollectText($.$ref(() => n2, ($v) => n2 = $v, $.$spxl.System.Xml.Linq.XNode))))
                        {
                            break;
                        }
                        if (n1 === null && n2 === null)
                        {
                            return true;
                        }
                        if (n1 === null || n2 === null || !n1.DeepEquals$1(n2))
                        {
                            break;
                        }
                        n1 = n1 !== this.content ? n1.next : null;
                        n2 = n2 !== e.content ? n2.next : null;
                    }
                }
                return false;
            }
            /*int */ ContentsHashCode()
            {
                /*string?*/ let s = this.GetTextOnly();
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    return $.$spc.System.String.GetHashCode.call(s);
                }
                /*int*/ let h = 0;
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*string*/ let text = this.CollectText($.$ref(() => n, ($v) => n = $v, $.$spxl.System.Xml.Linq.XNode));
                        if (text.length > 0)
                        {
                            h ^= $.$spc.System.String.GetHashCode.call(text);
                        }
                        if (n === null)
                        {
                            break;
                        }
                        h ^= n.GetDeepHashCode();
                    }
                    while(n !== this.content);
                }
                return h;
            }
            /*void */ ConvertTextToNode()
            {
                /*string?*/ let s = $.$as(this.content, $.$spc.System.String);
                if (!$.$spc.System.String.IsNullOrEmpty(s))
                {
                    /*XText*/ let t = new $.$spxl.System.Xml.Linq.XText().$ctor$3(s);
                    t.parent = this;
                    t.next = t;
                    this.content = t;
                }
            }
            /*IEnumerable<XNode> */ GetDescendantNodes(/*bool*/ self)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    if (self)
                    {
                        yield this;
                    }
                    /*XNode*/ let n = this;
                    while(true)
                    {
                        /*XContainer?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XContainer);
                        /*XNode?*/ let first;
                        if (c !== null && (first = c.FirstNode) !== null)
                        {
                            n = first;
                        }
                        else 
                        {
                            while(n !== null && n !== this && n === n.parent.content)
                            {
                                n = n.parent;
                            }
                            if (n === null || n === this)
                            {
                                break;
                            }
                            n = n.next;
                        }
                        yield n;
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ GetDescendants(/*XName?*/ name, /*bool*/ self)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    if (self)
                    {
                        /*XElement*/ let e = $.$cast(this, $.$spxl.System.Xml.Linq.XElement);
                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                        {
                            yield e;
                        }
                    }
                    /*XNode*/ let n = this;
                    /*XContainer?*/ let c = this;
                    while(true)
                    {
                        if (c !== null && $.$is(c.content, $.$spxl.System.Xml.Linq.XNode))
                        {
                            n = ($.$cast(c.content, $.$spxl.System.Xml.Linq.XNode)).next;
                        }
                        else 
                        {
                            while(n !== this && n === n.parent.content)
                            {
                                n = n.parent;
                            }
                            if (n === this)
                            {
                                break;
                            }
                            n = n.next;
                        }
                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                        {
                            yield e;
                        }
                        c = e;
                    }
                }.bind(this));
            }
            /*IEnumerable<XElement> */ GetElements(/*XName?*/ name)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                    if (n !== null)
                    {
                        do
                        {
                            n = n.next;
                            /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                            if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                            {
                                yield e;
                            }
                        }
                        while(n.parent === this && n !== this.content);
                    }
                }.bind(this));
            }
            static /*string */ GetStringValue(/*object*/ value)
            {
                /*string?*/ let s = (() =>
                {
                    {
                        let stringValue;
                        if ((stringValue = value, $.$is(stringValue, $.$spc.System.String)))
                        {
                            return stringValue;
                        }
                    }
                    {
                        let intValue;
                        if ((intValue = value, $.$is(intValue, $.$spc.System.Int32)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$6(intValue);
                        }
                    }
                    {
                        let doubleValue;
                        if ((doubleValue = value, $.$is(doubleValue, $.$spc.System.Double)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$13(doubleValue);
                        }
                    }
                    {
                        let longValue;
                        if ((longValue = value, $.$is(longValue, $.$spc.System.Int64)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$7(longValue);
                        }
                    }
                    {
                        let floatValue;
                        if ((floatValue = value, $.$is(floatValue, $.$spc.System.Single)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$12(floatValue);
                        }
                    }
                    {
                        let decimalValue;
                        if ((decimalValue = value, $.$is(decimalValue, $.$spc.System.Decimal)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$3(decimalValue);
                        }
                    }
                    {
                        let shortValue;
                        if ((shortValue = value, $.$is(shortValue, $.$spc.System.Int16)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$5(shortValue);
                        }
                    }
                    {
                        let sbyteValue;
                        if ((sbyteValue = value, $.$is(sbyteValue, $.$spc.System.SByte)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$4(sbyteValue);
                        }
                    }
                    {
                        let boolValue;
                        if ((boolValue = value, $.$is(boolValue, $.$spc.System.Boolean)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$1(boolValue);
                        }
                    }
                    {
                        let dtValue;
                        if ((dtValue = value, $.$is(dtValue, $.$spc.System.DateTime)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$17(dtValue, 3/*XmlDateTimeSerializationMode.RoundtripKind*/);
                        }
                    }
                    {
                        let dtoValue;
                        if ((dtoValue = value, $.$is(dtoValue, $.$spc.System.DateTimeOffset)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$18(dtoValue);
                        }
                    }
                    {
                        let tsValue;
                        if ((tsValue = value, $.$is(tsValue, $.$spc.System.TimeSpan)))
                        {
                            return $.$spx.System.Xml.XmlConvert.ToString$14(tsValue);
                        }
                    }
                    if (value === $.$spxl.System.Xml.Linq.XObject)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_XObjectValue);
                    }
                    return $.$spc.System.Object.ToString.call(value);
                })();
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_ConvertToString);
                }
                return s;
            }
            /*void */ ReadContentFrom(/*XmlReader*/ r)
            {
                if (r.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$1(this);
                while(cr.ReadContentFrom(this, r) && r.Read())
                {
                }
            }
            /*void */ ReadContentFrom$1(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                if ((o & (2/*LoadOptions.SetBaseUri*/ | 4/*LoadOptions.SetLineInfo*/)) === 0)
                {
                    this.ReadContentFrom(r);
                    return;
                }
                if (r.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$2(this, r, o);
                while(cr.ReadContentFromContainer(this, r) && r.Read())
                {
                }
            }
            /*Task *//*async*/  ReadContentFromAsync(/*XmlReader*/ r, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (r.ReadState !== 1/*ReadState.Interactive*/)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                    }
                    /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$1(this);
                    do
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                    while(await cr.ReadContentFromAsync(this, r).ConfigureAwait(false) && await r.ReadAsync().ConfigureAwait$2(false));
                });
            }
            /*Task *//*async*/  ReadContentFromAsync$1(/*XmlReader*/ r, /*LoadOptions*/ o, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if ((o & (2/*LoadOptions.SetBaseUri*/ | 4/*LoadOptions.SetLineInfo*/)) === 0)
                    {
                        await this.ReadContentFromAsync(r, cancellationToken).ConfigureAwait(false);
                        return;
                    }
                    if (r.ReadState !== 1/*ReadState.Interactive*/)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                    }
                    /*ContentReader*/ let cr = new $.$spxl.System.Xml.Linq.XContainer.ContentReader().$ctor$2(this, r, o);
                    do
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                    while(await cr.ReadContentFromContainerAsync(this, r).ConfigureAwait(false) && await r.ReadAsync().ConfigureAwait$2(false));
                });
            }
            static $_ContentReader;
            static get ContentReader()
            {
                let $cls = $.$spxl.System.Xml.Linq.XContainer;
                return $cls.$_ContentReader ??= $asm.$ncls("$spxl.System.Xml.Linq.XContainer.ContentReader", ($self) => class ContentReader extends $.$spc.System.Object
                {
                    /*NamespaceCache*/ _eCache;
                    /*NamespaceCache*/ _aCache;
                    /*IXmlLineInfo?*/ _lineInfo = null;
                    /*XContainer*/ _currentContainer = null;
                    /*string?*/ _baseUri = null;
                    $ctor$1(/*XContainer*/ rootContainer)
                    {
                        super.$ctor();
                        {
                            this._currentContainer = rootContainer;
                        }
                        return this;
                    }
                    $ctor$2(/*XContainer*/ rootContainer, /*XmlReader*/ r, /*LoadOptions*/ o)
                    {
                        super.$ctor();
                        {
                            this._currentContainer = rootContainer;
                            this._baseUri = (o & 2/*LoadOptions.SetBaseUri*/) !== 0 ? r.BaseURI : null;
                            this._lineInfo = (o & 4/*LoadOptions.SetLineInfo*/) !== 0 ? $.$as(r, $.$spx.System.Xml.IXmlLineInfo) : null;
                        }
                        return this;
                    }
                    /*bool */ ReadContentFrom(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        let $switch1 = r.NodeType;
                        switch($switch1)
                        {
                            case 1/*XmlNodeType.Element*/:
                            /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$5(this._eCache.Get(r.NamespaceURI).GetName(r.LocalName));
                            if (r.MoveToFirstAttribute())
                            {
                                do
                                {
                                    e.AppendAttributeSkipNotify(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(this._aCache.Get(r.Prefix.length === 0 ? $.$spc.System.String.Empty : r.NamespaceURI).GetName(r.LocalName), r.Value));
                                }
                                while(r.MoveToNextAttribute());
                                r.MoveToElement();
                            }
                            this._currentContainer.AddNodeSkipNotify(e);
                            if (!r.IsEmptyElement)
                            {
                                this._currentContainer = e;
                            }
                            break;
                            case 15/*XmlNodeType.EndElement*/:
                            this._currentContainer.content ??= $.$spc.System.String.Empty;
                            if (this._currentContainer === rootContainer)
                            {
                                return false;
                            }
                            this._currentContainer = this._currentContainer.parent;
                            break;
                            case 3/*XmlNodeType.Text*/:
                            case 14/*XmlNodeType.SignificantWhitespace*/:
                            case 13/*XmlNodeType.Whitespace*/:
                            this._currentContainer.AddStringSkipNotify(r.Value);
                            break;
                            case 4/*XmlNodeType.CDATA*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XCData().$ctor$6(r.Value));
                            break;
                            case 8/*XmlNodeType.Comment*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XComment().$ctor$3(r.Value));
                            break;
                            case 7/*XmlNodeType.ProcessingInstruction*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, r.Value));
                            break;
                            case 10/*XmlNodeType.DocumentType*/:
                            this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute("PUBLIC"), r.GetAttribute("SYSTEM"), r.Value));
                            break;
                            case 5/*XmlNodeType.EntityReference*/:
                            if (!r.CanResolveEntity)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                            }
                            r.ResolveEntity();
                            break;
                            case 16/*XmlNodeType.EndEntity*/:
                            break;
                            default:
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                        }
                        return true;
                    }
                    /*ValueTask<bool> *//*async*/  ReadContentFromAsync(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                        {
                            let $switch1 = r.NodeType;
                            switch($switch1)
                            {
                                case 1/*XmlNodeType.Element*/:
                                /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$5(this._eCache.Get(r.NamespaceURI).GetName(r.LocalName));
                                if (r.MoveToFirstAttribute())
                                {
                                    do
                                    {
                                        e.AppendAttributeSkipNotify(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(this._aCache.Get(r.Prefix.length === 0 ? $.$spc.System.String.Empty : r.NamespaceURI).GetName(r.LocalName), await r.GetValueAsync().ConfigureAwait$2(false)));
                                    }
                                    while(r.MoveToNextAttribute());
                                    r.MoveToElement();
                                }
                                this._currentContainer.AddNodeSkipNotify(e);
                                if (!r.IsEmptyElement)
                                {
                                    this._currentContainer = e;
                                }
                                break;
                                case 15/*XmlNodeType.EndElement*/:
                                this._currentContainer.content ??= $.$spc.System.String.Empty;
                                if (this._currentContainer === rootContainer)
                                {
                                    return false;
                                }
                                this._currentContainer = this._currentContainer.parent;
                                break;
                                case 3/*XmlNodeType.Text*/:
                                case 14/*XmlNodeType.SignificantWhitespace*/:
                                case 13/*XmlNodeType.Whitespace*/:
                                this._currentContainer.AddStringSkipNotify(await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 4/*XmlNodeType.CDATA*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XCData().$ctor$6(await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 8/*XmlNodeType.Comment*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XComment().$ctor$3(await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 7/*XmlNodeType.ProcessingInstruction*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 10/*XmlNodeType.DocumentType*/:
                                this._currentContainer.AddNodeSkipNotify(new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute("PUBLIC"), r.GetAttribute("SYSTEM"), await r.GetValueAsync().ConfigureAwait$2(false)));
                                break;
                                case 5/*XmlNodeType.EntityReference*/:
                                if (!r.CanResolveEntity)
                                {
                                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                                }
                                r.ResolveEntity();
                                break;
                                case 16/*XmlNodeType.EndEntity*/:
                                break;
                                default:
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                            }
                            return true;
                        });
                    }
                    /*bool */ ReadContentFromContainer(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        /*XNode?*/ let newNode = null;
                        /*string*/ let baseUri = r.BaseURI;
                        let $switch1 = r.NodeType;
                        switch($switch1)
                        {
                            case 1/*XmlNodeType.Element*/:
                            {
                                /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$5(this._eCache.Get(r.NamespaceURI).GetName(r.LocalName));
                                if ($.$spc.System.String.op_Inequality(this._baseUri, null) && $.$spc.System.String.op_Inequality(this._baseUri, baseUri))
                                {
                                    e.SetBaseUri(baseUri);
                                }
                                if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                {
                                    e.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                }
                                if (r.MoveToFirstAttribute())
                                {
                                    do
                                    {
                                        /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(this._aCache.Get(r.Prefix.length === 0 ? $.$spc.System.String.Empty : r.NamespaceURI).GetName(r.LocalName), r.Value);
                                        if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                        {
                                            a.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                        }
                                        e.AppendAttributeSkipNotify(a);
                                    }
                                    while(r.MoveToNextAttribute());
                                    r.MoveToElement();
                                }
                                this._currentContainer.AddNodeSkipNotify(e);
                                if (!r.IsEmptyElement)
                                {
                                    this._currentContainer = e;
                                    if ($.$spc.System.String.op_Inequality(this._baseUri, null))
                                    {
                                        this._baseUri = baseUri;
                                    }
                                }
                                break;
                            }
                            case 15/*XmlNodeType.EndElement*/:
                            {
                                this._currentContainer.content ??= $.$spc.System.String.Empty;
                                /*XElement?*/ let e = $.$as(this._currentContainer, $.$spxl.System.Xml.Linq.XElement);
                                $.$spc.System.Diagnostics.Debug.Assert$1(e !== null, "EndElement received but the current container is not an element.");
                                if (e !== null && this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                {
                                    e.SetEndElementLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                }
                                if (this._currentContainer === rootContainer)
                                {
                                    return false;
                                }
                                if ($.$spc.System.String.op_Inequality(this._baseUri, null) && this._currentContainer.HasBaseUri)
                                {
                                    this._baseUri = this._currentContainer.parent.BaseUri;
                                }
                                this._currentContainer = this._currentContainer.parent;
                                break;
                            }
                            case 3/*XmlNodeType.Text*/:
                            case 14/*XmlNodeType.SignificantWhitespace*/:
                            case 13/*XmlNodeType.Whitespace*/:
                            if (($.$spc.System.String.op_Inequality(this._baseUri, null) && $.$spc.System.String.op_Inequality(this._baseUri, baseUri)) || (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo()))
                            {
                                newNode = new $.$spxl.System.Xml.Linq.XText().$ctor$3(r.Value);
                            }
                            else 
                            {
                                this._currentContainer.AddStringSkipNotify(r.Value);
                            }
                            break;
                            case 4/*XmlNodeType.CDATA*/:
                            newNode = new $.$spxl.System.Xml.Linq.XCData().$ctor$6(r.Value);
                            break;
                            case 8/*XmlNodeType.Comment*/:
                            newNode = new $.$spxl.System.Xml.Linq.XComment().$ctor$3(r.Value);
                            break;
                            case 7/*XmlNodeType.ProcessingInstruction*/:
                            newNode = new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, r.Value);
                            break;
                            case 10/*XmlNodeType.DocumentType*/:
                            newNode = new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute("PUBLIC"), r.GetAttribute("SYSTEM"), r.Value);
                            break;
                            case 5/*XmlNodeType.EntityReference*/:
                            if (!r.CanResolveEntity)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                            }
                            r.ResolveEntity();
                            break;
                            case 16/*XmlNodeType.EndEntity*/:
                            break;
                            default:
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                        }
                        if (newNode !== null)
                        {
                            if ($.$spc.System.String.op_Inequality(this._baseUri, null) && $.$spc.System.String.op_Inequality(this._baseUri, baseUri))
                            {
                                newNode.SetBaseUri(baseUri);
                            }
                            if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                            {
                                newNode.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                            }
                            this._currentContainer.AddNodeSkipNotify(newNode);
                        }
                        return true;
                    }
                    /*ValueTask<bool> *//*async*/  ReadContentFromContainerAsync(/*XContainer*/ rootContainer, /*XmlReader*/ r)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                        {
                            /*XNode?*/ let newNode = null;
                            /*string*/ let baseUri = r.BaseURI;
                            let $switch1 = r.NodeType;
                            switch($switch1)
                            {
                                case 1/*XmlNodeType.Element*/:
                                {
                                    /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$5(this._eCache.Get(r.NamespaceURI).GetName(r.LocalName));
                                    if ($.$spc.System.String.op_Inequality(this._baseUri, null) && $.$spc.System.String.op_Inequality(this._baseUri, baseUri))
                                    {
                                        e.SetBaseUri(baseUri);
                                    }
                                    if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                    {
                                        e.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                    }
                                    if (r.MoveToFirstAttribute())
                                    {
                                        do
                                        {
                                            /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(this._aCache.Get(r.Prefix.length === 0 ? $.$spc.System.String.Empty : r.NamespaceURI).GetName(r.LocalName), await r.GetValueAsync().ConfigureAwait$2(false));
                                            if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                            {
                                                a.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                            }
                                            e.AppendAttributeSkipNotify(a);
                                        }
                                        while(r.MoveToNextAttribute());
                                        r.MoveToElement();
                                    }
                                    this._currentContainer.AddNodeSkipNotify(e);
                                    if (!r.IsEmptyElement)
                                    {
                                        this._currentContainer = e;
                                        if ($.$spc.System.String.op_Inequality(this._baseUri, null))
                                        {
                                            this._baseUri = baseUri;
                                        }
                                    }
                                    break;
                                }
                                case 15/*XmlNodeType.EndElement*/:
                                {
                                    this._currentContainer.content ??= $.$spc.System.String.Empty;
                                    /*XElement?*/ let e = $.$as(this._currentContainer, $.$spxl.System.Xml.Linq.XElement);
                                    $.$spc.System.Diagnostics.Debug.Assert$1(e !== null, "EndElement received but the current container is not an element.");
                                    if (e !== null && this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                    {
                                        e.SetEndElementLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                    }
                                    if (this._currentContainer === rootContainer)
                                    {
                                        return false;
                                    }
                                    if ($.$spc.System.String.op_Inequality(this._baseUri, null) && this._currentContainer.HasBaseUri)
                                    {
                                        this._baseUri = this._currentContainer.parent.BaseUri;
                                    }
                                    this._currentContainer = this._currentContainer.parent;
                                    break;
                                }
                                case 3/*XmlNodeType.Text*/:
                                case 14/*XmlNodeType.SignificantWhitespace*/:
                                case 13/*XmlNodeType.Whitespace*/:
                                if (($.$spc.System.String.op_Inequality(this._baseUri, null) && $.$spc.System.String.op_Inequality(this._baseUri, baseUri)) || (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo()))
                                {
                                    newNode = new $.$spxl.System.Xml.Linq.XText().$ctor$3(await r.GetValueAsync().ConfigureAwait$2(false));
                                }
                                else 
                                {
                                    this._currentContainer.AddStringSkipNotify(await r.GetValueAsync().ConfigureAwait$2(false));
                                }
                                break;
                                case 4/*XmlNodeType.CDATA*/:
                                newNode = new $.$spxl.System.Xml.Linq.XCData().$ctor$6(await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 8/*XmlNodeType.Comment*/:
                                newNode = new $.$spxl.System.Xml.Linq.XComment().$ctor$3(await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 7/*XmlNodeType.ProcessingInstruction*/:
                                newNode = new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(r.Name, await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 10/*XmlNodeType.DocumentType*/:
                                newNode = new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(r.LocalName, r.GetAttribute("PUBLIC"), r.GetAttribute("SYSTEM"), await r.GetValueAsync().ConfigureAwait$2(false));
                                break;
                                case 5/*XmlNodeType.EntityReference*/:
                                if (!r.CanResolveEntity)
                                {
                                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_UnresolvedEntityReference);
                                }
                                r.ResolveEntity();
                                break;
                                case 16/*XmlNodeType.EndEntity*/:
                                break;
                                default:
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedNodeType, $.$box(r.NodeType, $.$spx.System.Xml.XmlNodeType)));
                            }
                            if (newNode !== null)
                            {
                                if ($.$spc.System.String.op_Inequality(this._baseUri, null) && $.$spc.System.String.op_Inequality(this._baseUri, baseUri))
                                {
                                    newNode.SetBaseUri(baseUri);
                                }
                                if (this._lineInfo !== null && this._lineInfo.System$Xml$IXmlLineInfo$HasLineInfo())
                                {
                                    newNode.SetLineInfo(this._lineInfo.System$Xml$IXmlLineInfo$LineNumber, this._lineInfo.System$Xml$IXmlLineInfo$LinePosition);
                                }
                                this._currentContainer.AddNodeSkipNotify(newNode);
                            }
                            return true;
                        });
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._eCache = $.$default($.$spxl.System.Xml.Linq.NamespaceCache);
                        this._aCache = $.$default($.$spxl.System.Xml.Linq.NamespaceCache);
                    }
                    static $h = 1427884;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"rootContainer","p":1362348},{"n":"r","p":53389469}],"n":"ReadContentFrom","d":1427884,"h":34361166252,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"rootContainer","p":1362348},{"n":"r","p":53389469}],"n":"ReadContentFromAsync","d":1427884,"h":38656133548,"f":4097},{"r":262145,"p":[{"n":"rootContainer","p":1362348},{"n":"r","p":53389469}],"n":"ReadContentFromContainer","d":1427884,"h":42951100844,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"rootContainer","p":1362348},{"n":"r","p":53389469}],"n":"ReadContentFromContainerAsync","d":1427884,"h":47246068140,"f":4097}],"l":[{"t":772524,"n":"_eCache","d":1427884,"h":4296395180,"f":2},{"t":772524,"n":"_aCache","d":1427884,"h":8591362476,"f":2},{"t":13936797,"n":"_lineInfo","d":1427884,"h":12886329772,"f":2},{"t":1362348,"n":"_currentContainer","d":1427884,"h":17181297068,"f":2},{"t":1310721,"n":"_baseUri","d":1427884,"h":21476264364,"f":2}],"c":[{"p":[{"n":"rootContainer","p":1362348}],"n":".ctor","o":"$ctor$1","d":1427884,"h":25771231660,"f":1},{"p":[{"n":"rootContainer","p":1362348},{"n":"r","p":53389469},{"n":"o","p":706988}],"n":".ctor","o":"$ctor$2","d":1427884,"h":30066198956,"f":1}],"d":1362348,"h":1427884}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Xml.Linq.XContainer.ContentReader`; }
                }, $cls, ($v) => $cls.$_ContentReader = $v);
            }
            /*void */ RemoveNode(/*XNode*/ n)
            {
                /*bool*/ let notify = this.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                if (n.parent !== this)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this.content !== null, "content != null");
                /*XNode*/ let p = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                while(p.next !== n)
                {
                    p = p.next;
                }
                if (p === n)
                {
                    this.content = null;
                }
                else 
                {
                    if (this.content === n)
                    {
                        this.content = p;
                    }
                    p.next = n.next;
                }
                n.parent = null;
                n.next = null;
                if (notify)
                {
                    this.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                }
            }
            /*void */ RemoveNodesSkipNotify()
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        /*XNode*/ let next = n.next;
                        n.parent = null;
                        n.next = null;
                        n = next;
                    }
                    while(n !== this.content);
                }
                this.content = null;
            }
            /*void */ ValidateNode(/*XNode*/ node, /*XNode?*/ previous)
            {
            }
            /*void */ ValidateString(/*string*/ s)
            {
            }
            /*void */ WriteContentTo(/*XmlWriter*/ writer)
            {
                if (this.content !== null)
                {
                    /*string?*/ let stringContent = $.$as(this.content, $.$spc.System.String);
                    if ($.$spc.System.String.op_Inequality(stringContent, null))
                    {
                        if ($.$is(this, $.$spxl.System.Xml.Linq.XDocument))
                        {
                            writer.WriteWhitespace(stringContent);
                        }
                        else 
                        {
                            writer.WriteString(stringContent);
                        }
                    }
                    else 
                    {
                        /*XNode*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                        do
                        {
                            n = n.next;
                            n.WriteTo(writer);
                        }
                        while(n !== this.content);
                    }
                }
            }
            /*Task *//*async*/  WriteContentToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (this.content !== null)
                    {
                        /*string?*/ let stringContent = $.$as(this.content, $.$spc.System.String);
                        if ($.$spc.System.String.op_Inequality(stringContent, null))
                        {
                            cancellationToken.ThrowIfCancellationRequested();
                            /*Task*/ let tWrite;
                            if ($.$is(this, $.$spxl.System.Xml.Linq.XDocument))
                            {
                                tWrite = writer.WriteWhitespaceAsync(stringContent);
                            }
                            else 
                            {
                                tWrite = writer.WriteStringAsync(stringContent);
                            }
                            await tWrite.ConfigureAwait(false);
                        }
                        else 
                        {
                            /*XNode*/ let n = $.$cast(this.content, $.$spxl.System.Xml.Linq.XNode);
                            do
                            {
                                n = n.next;
                                await n.WriteToAsync(writer, cancellationToken).ConfigureAwait(false);
                            }
                            while(n !== this.content);
                        }
                    }
                });
            }
            static /*void */ AddContentToList(/*List<object?>*/ list, /*object?*/ content)
            {
                /*IEnumerable?*/ let e = $.$is(content, $.$spc.System.String) ? null : $.$as(content, $.$spc.System.Collections.IEnumerable);
                if (e === null)
                {
                    list.Add(content);
                }
                else 
                {
                    var $en3 = e.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (obj !== null)
                            {
                                $.$spxl.System.Xml.Linq.XContainer.AddContentToList(list, obj);
                            }
                        }
                    }
                }
            }
            static /*object? */ GetContentSnapshot(/*object?*/ content)
            {
                if ($.$is(content, $.$spc.System.String) || !($.$is(content, $.$spc.System.Collections.IEnumerable)))
                {
                    return content;
                }
                /*List<object?>*/ let list = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Object))().$ctor$1();
                $.$spxl.System.Xml.Linq.XContainer.AddContentToList(list, content);
                return list;
            }
            static $h = 1362348;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2279852,"p":[{"p":2279852,"g":{"r":0,"d":0,"h":21476198828,"f":1},"n":"FirstNode","d":1362348,"h":17181231532,"f":1},{"p":2279852,"g":{"r":0,"d":0,"h":30066133420,"f":1},"n":"LastNode","d":1362348,"h":25771166124,"f":1}],"m":[{"r":65537,"p":[{"n":"content","p":131073}],"n":"Add","d":1362348,"h":34361100716,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"Add","o":"@$1","d":1362348,"h":38656068012,"f":1},{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddFirst","d":1362348,"h":42951035308,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"AddFirst","o":"@$1","d":1362348,"h":47246002604,"f":1},{"r":58435741,"n":"CreateWriter","d":1362348,"h":51540969900,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"DescendantNodes","d":1362348,"h":55835937196,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"Descendants","d":1362348,"h":60130904492,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2148780}],"n":"Descendants","o":"@$1","d":1362348,"h":64425871788,"f":1},{"r":1690028,"p":[{"n":"name","p":2148780}],"n":"Element","d":1362348,"h":68720839084,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"Elements","d":1362348,"h":73015806380,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2148780}],"n":"Elements","o":"@$1","d":1362348,"h":77310773676,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"Nodes","d":1362348,"h":81605740972,"f":1},{"r":65537,"n":"RemoveNodes","d":1362348,"h":85900708268,"f":1},{"r":65537,"p":[{"n":"content","p":131073}],"n":"ReplaceNodes","d":1362348,"h":90195675564,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"ReplaceNodes","o":"@$1","d":1362348,"h":94490642860,"f":1},{"r":65537,"p":[{"n":"a","p":1165740}],"n":"AddAttribute","d":1362348,"h":98785610156,"f":136},{"r":65537,"p":[{"n":"a","p":1165740}],"n":"AddAttributeSkipNotify","d":1362348,"h":103080577452,"f":136},{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddContentSkipNotify","d":1362348,"h":107375544748,"f":8},{"r":65537,"p":[{"n":"n","p":2279852}],"n":"AddNode","d":1362348,"h":111670512044,"f":8},{"r":65537,"p":[{"n":"n","p":2279852}],"n":"AddNodeSkipNotify","d":1362348,"h":115965479340,"f":8},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AddString","d":1362348,"h":120260446636,"f":8},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AddStringSkipNotify","d":1362348,"h":124555413932,"f":8},{"r":65537,"p":[{"n":"n","p":2279852}],"n":"AppendNode","d":1362348,"h":128850381228,"f":8},{"r":65537,"p":[{"n":"n","p":2279852}],"n":"AppendNodeSkipNotify","d":1362348,"h":133145348524,"f":8},{"r":65537,"p":[{"n":"sb","p":122945537}],"n":"AppendText","d":1362348,"h":137440315820,"f":32776},{"r":1310721,"n":"GetTextOnly","d":1362348,"h":141735283116,"f":2},{"r":1310721,"p":[{"n":"n","p":2279852,"f":4}],"n":"CollectText","d":1362348,"h":146030250412,"f":2},{"r":262145,"p":[{"n":"e","p":1362348}],"n":"ContentsEqual","d":1362348,"h":150325217708,"f":8},{"r":655361,"n":"ContentsHashCode","d":1362348,"h":154620185004,"f":8},{"r":65537,"n":"ConvertTextToNode","d":1362348,"h":158915152300,"f":8},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"self","p":262145}],"n":"GetDescendantNodes","d":1362348,"h":163210119596,"f":8},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2148780},{"n":"self","p":262145}],"n":"GetDescendants","d":1362348,"h":167505086892,"f":8},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2148780}],"n":"GetElements","d":1362348,"h":171800054188,"f":2},{"r":1310721,"p":[{"n":"value","p":131073}],"n":"GetStringValue","d":1362348,"h":176095021484,"f":40},{"r":65537,"p":[{"n":"r","p":53389469}],"n":"ReadContentFrom","d":1362348,"h":180389988780,"f":8},{"r":65537,"p":[{"n":"r","p":53389469},{"n":"o","p":706988}],"n":"ReadContentFrom","o":"@$1","d":1362348,"h":184684956076,"f":8},{"r":133300225,"p":[{"n":"r","p":53389469},{"n":"cancellationToken","p":125960193}],"n":"ReadContentFromAsync","d":1362348,"h":188979923372,"f":4104},{"r":133300225,"p":[{"n":"r","p":53389469},{"n":"o","p":706988},{"n":"cancellationToken","p":125960193}],"n":"ReadContentFromAsync","o":"@$1","d":1362348,"h":193274890668,"f":4104},{"r":65537,"p":[{"n":"n","p":2279852}],"n":"RemoveNode","d":1362348,"h":201864825260,"f":8},{"r":65537,"n":"RemoveNodesSkipNotify","d":1362348,"h":206159792556,"f":2},{"r":65537,"p":[{"n":"node","p":2279852},{"n":"previous","p":2279852}],"n":"ValidateNode","d":1362348,"h":210454759852,"f":136},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"ValidateString","d":1362348,"h":214749727148,"f":136},{"r":65537,"p":[{"n":"writer","p":58435741}],"n":"WriteContentTo","d":1362348,"h":219044694444,"f":8},{"r":133300225,"p":[{"n":"writer","p":58435741},{"n":"cancellationToken","p":125960193}],"n":"WriteContentToAsync","d":1362348,"h":223339661740,"f":4104},{"r":65537,"p":[{"n":"list","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Object).$h},{"n":"content","p":131073}],"n":"AddContentToList","d":1362348,"h":227634629036,"f":34},{"r":131073,"p":[{"n":"content","p":131073}],"n":"GetContentSnapshot","d":1362348,"h":231929596332,"f":40}],"l":[{"t":131073,"n":"content","d":1362348,"h":4296329644,"f":8}],"c":[{"n":".ctor","o":"$ctor$3","d":1362348,"h":8591296940,"f":8},{"p":[{"n":"other","p":1362348}],"n":".ctor","o":"$ctor$4","d":1362348,"h":12886264236,"f":8}],"i":[13936797],"j":[1427884],"h":1362348}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XContainer`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.BaseUriAnnotation", ($self) => class BaseUriAnnotation extends $.$spc.System.Object
        {
            /*string*/ baseUri = null;
            $ctor$1(/*string*/ baseUri)
            {
                super.$ctor();
                {
                    this.baseUri = baseUri;
                }
                return this;
            }
            static $h = 313772;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"baseUri","d":313772,"h":4295281068,"f":8}],"c":[{"p":[{"n":"baseUri","p":1310721}],"n":".ctor","o":"$ctor$1","d":313772,"h":8590248364,"f":1}],"h":313772}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.BaseUriAnnotation`; }
        });
        
        $asm.$cls("$spxl.System.Collections.Generic.EnumerableHelpers", ($self) => class EnumerableHelpers
        {
            static /*void */ Reset(T, /*ref T*/ enumerator)
            {
                return $.$dsp(enumerator.$v, T, ($t) => $t.System$Collections$IEnumerator$Reset,);
            }
            static /*IEnumerator<T> */ GetEmptyEnumerator(T)
            {
                return ($.$spc.System.Array.Empty(T)).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            static /*T[] */ ToArray(T, /*IEnumerable<T>*/ source, /*out int*/ length)
            {
                /*int*/ let ArrayMaxLength = 2147483591;
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Array.MaxLength === ArrayMaxLength, "Array.MaxLength == ArrayMaxLength");
                let ic;
                if ($.$is(source, $.$spc.System.Collections.Generic.ICollection$$(T), { set $v(v){ ic = v; } }))
                {
                    /*int*/ let count = ic.System$Collections$Generic$ICollection$$$Count;
                    if (count !== 0)
                    {
                        /*T[]*/ let arr = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [count], null);
                        ic.System$Collections$Generic$ICollection$$$CopyTo(arr, 0, [T]);
                        length.$v = count;
                        return arr;
                    }
                }
                else 
                {
                    let en = null;
                    try
                    {
                        en = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                        if (en.System$Collections$IEnumerator$MoveNext())
                        {
                            /*int*/ let DefaultCapacity = 4;
                            /*T[]*/ let arr = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [DefaultCapacity], null);
                            $.$spc.System.Array.$WriteT1.call(arr, en.System$Collections$Generic$IEnumerator$$$Current, 0);
                            /*int*/ let count = 1;
                            while(en.System$Collections$IEnumerator$MoveNext())
                            {
                                if (count === arr.length)
                                {
                                    /*int*/ let newLength = count << 1;
                                    if ((newLength >>> 0) > ArrayMaxLength)
                                    {
                                        newLength = ArrayMaxLength <= count ? ((count + 1) | 0) : ArrayMaxLength;
                                    }
                                    $.$spc.System.Array.Resize(T, $.$ref(() => arr, ($v) => arr = $v, $.$typeArray(T)), newLength);
                                }
                                $.$spc.System.Array.$WriteT1.call(arr, en.System$Collections$Generic$IEnumerator$$$Current, count++);
                            }
                            length.$v = count;
                            return arr;
                        }
                    }
                    finally
                    {
                        en?.System$IDisposable$Dispose();
                    }
                }
                length.$v = 0;
                return $.$spc.System.Array.Empty(T);
            }
            static $h = 117164;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"enumerator","p":(T) => T.$h,"f":4}],"g":["T"],"n":"Reset","d":117164,"h":4295084460,"f":131112},{"r":(T) => $.$spc.System.Collections.Generic.IEnumerator$$(T).$h,"g":["T"],"n":"GetEmptyEnumerator","d":117164,"h":8590051756,"f":131112},{"r":0,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"length","p":655361,"f":2}],"g":["T"],"n":"ToArray","d":117164,"h":12885019052,"f":131112}],"h":117164}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Collections.Generic.EnumerableHelpers`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.LineInfoAnnotation", ($self) => class LineInfoAnnotation extends $.$spc.System.Object
        {
            /*int*/ lineNumber = 0;
            /*int*/ linePosition = 0;
            $ctor$1(/*int*/ lineNumber, /*int*/ linePosition)
            {
                super.$ctor();
                {
                    this.lineNumber = lineNumber;
                    this.linePosition = linePosition;
                }
                return this;
            }
            static $h = 575916;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"lineNumber","d":575916,"h":4295543212,"f":8},{"t":655361,"n":"linePosition","d":575916,"h":8590510508,"f":8}],"c":[{"p":[{"n":"lineNumber","p":655361},{"n":"linePosition","p":655361}],"n":".ctor","o":"$ctor$1","d":575916,"h":12885477804,"f":1}],"h":575916}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.LineInfoAnnotation`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XDeclaration", ($self) => class XDeclaration extends $.$spc.System.Object
        {
            /*string?*/ _version = null;
            /*string?*/ _encoding = null;
            /*string?*/ _standalone = null;
            $ctor$1(/*string?*/ version, /*string?*/ encoding, /*string?*/ standalone)
            {
                super.$ctor();
                {
                    this._version = version;
                    this._encoding = encoding;
                    this._standalone = standalone;
                }
                return this;
            }
            $ctor$2(/*XDeclaration*/ other)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this._version = other._version;
                    this._encoding = other._encoding;
                    this._standalone = other._standalone;
                }
                return this;
            }
            $ctor$3(/*XmlReader*/ r)
            {
                super.$ctor();
                {
                    this._version = r.GetAttribute("version");
                    this._encoding = r.GetAttribute("encoding");
                    this._standalone = r.GetAttribute("standalone");
                    r.Read();
                }
                return this;
            }
            /*string? */ get Encoding()
            {
                return this._encoding;
            }
            /*string? */ set Encoding(value)
            {
                this._encoding = value;
            }
            /*string? */ get Standalone()
            {
                return this._standalone;
            }
            /*string? */ set Standalone(value)
            {
                this._standalone = value;
            }
            /*string? */ get Version()
            {
                return this._version;
            }
            /*string? */ set Version(value)
            {
                this._version = value;
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*StringBuilder*/ let sb = $.$spxl.System.Text.StringBuilderCache.Acquire(16);
                sb.Append$2("<?xml");
                if ($.$spc.System.String.op_Inequality(this._version, null))
                {
                    sb.Append$2(" version=\"");
                    sb.Append$2(this._version);
                    sb.Append$7(/*\"*/ 34);
                }
                if ($.$spc.System.String.op_Inequality(this._encoding, null))
                {
                    sb.Append$2(" encoding=\"");
                    sb.Append$2(this._encoding);
                    sb.Append$7(/*\"*/ 34);
                }
                if ($.$spc.System.String.op_Inequality(this._standalone, null))
                {
                    sb.Append$2(" standalone=\"");
                    sb.Append$2(this._standalone);
                    sb.Append$7(/*\"*/ 34);
                }
                sb.Append$2("?>");
                return $.$spxl.System.Text.StringBuilderCache.GetStringAndRelease(sb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XDeclaration.ToString.apply(this, arguments); }
            static $h = 1493420;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":34361231788,"f":1},"s":{"r":0,"d":0,"h":38656199084,"f":1},"n":"Encoding","d":1493420,"h":30066264492,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":47246133676,"f":1},"s":{"r":0,"d":0,"h":51541100972,"f":1},"n":"Standalone","d":1493420,"h":42951166380,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":60131035564,"f":1},"s":{"r":0,"d":0,"h":64426002860,"f":1},"n":"Version","d":1493420,"h":55836068268,"f":1}],"m":[{"r":1310721,"n":"ToString","d":1493420,"h":68720970156,"f":32769}],"l":[{"t":1310721,"n":"_version","d":1493420,"h":4296460716,"f":2},{"t":1310721,"n":"_encoding","d":1493420,"h":8591428012,"f":2},{"t":1310721,"n":"_standalone","d":1493420,"h":12886395308,"f":2}],"c":[{"p":[{"n":"version","p":1310721},{"n":"encoding","p":1310721},{"n":"standalone","p":1310721}],"n":".ctor","o":"$ctor$1","d":1493420,"h":17181362604,"f":1},{"p":[{"n":"other","p":1493420}],"n":".ctor","o":"$ctor$2","d":1493420,"h":21476329900,"f":1},{"p":[{"n":"r","p":53389469}],"n":".ctor","o":"$ctor$3","d":1493420,"h":25771297196,"f":8}],"h":1493420}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XDeclaration`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XHashtable<>", (TValue) => $asm.$gt("$spxl.System.Xml.Linq.XHashtable<>", [TValue], ($self) => class XHashtable$$ extends $.$spc.System.Object
        {
            /*XHashtableState*/ _state = null;
            static $_ExtractKeyDelegate;
            static get ExtractKeyDelegate()
            {
                let $cls = $.$spxl.System.Xml.Linq.XHashtable$$(TValue);
                return $cls.$_ExtractKeyDelegate ??= $asm.$ncls("$spxl.System.Xml.Linq.XHashtable$$.ExtractKeyDelegate", ($self) => class ExtractKeyDelegate extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*string?*/ Invoke(/**/ value)
                    {
                        return this.$nativeFunction.call(this.$target, value);
                    }
                    static $h = 1886636;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":1310721,"p":[{"n":"value","p":TValue?.$h??1507328}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":129},{"r":57016321,"p":[{"n":"value","p":TValue?.$h??1507328},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":129},{"r":1310721,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[57212929,113377281],"d":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>.ExtractKeyDelegate`; }
                }, $cls, ($v) => $cls.$_ExtractKeyDelegate = $v);
            }
            $ctor$1(/*ExtractKeyDelegate*/ extractKey, /*int*/ capacity)
            {
                super.$ctor();
                {
                    this._state = new ($.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState)().$ctor$1(extractKey, capacity);
                }
                return this;
            }
            /*bool */ TryGetValue(/*string*/ key, /*int*/ index, /*int*/ count, /*out TValue*/ value)
            {
                return this._state.TryGetValue(key, index, count, value);
            }
            /*TValue */ Add(/*TValue*/ value)
            {
                /*TValue*/ let newValue;
                while(true)
                {
                    if (this._state.TryAdd(value, $.$ref(() => newValue, ($v) => newValue = $v, TValue)))
                    {
                        return newValue;
                    }
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            /*XHashtableState*/ let newState = this._state.Resize();
                            $.$spc.System.Threading.Thread.MemoryBarrier();
                            this._state = newState;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                }
            }
            static $_XHashtableState;
            static get XHashtableState()
            {
                let $cls = $.$spxl.System.Xml.Linq.XHashtable$$(TValue);
                return $cls.$_XHashtableState ??= $asm.$ncls("$spxl.System.Xml.Linq.XHashtable$$.XHashtableState", ($self) => class XHashtableState extends $.$spc.System.Object
                {
                    /*int[]*/ _buckets = null;
                    /*Entry[]*/ _entries = null;
                    /*int*/ _numEntries = 0;
                    /*ExtractKeyDelegate*/ _extractKey = null;
                    /*int*/ static EndOfList = 0;
                    /*int*/ static FullList = -1;
                    $ctor$1(/*ExtractKeyDelegate*/ extractKey, /*int*/ capacity)
                    {
                        super.$ctor();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Numerics.BitOperations.IsPow2(capacity), "capacity must be a power of 2");
                            $.$spc.System.Diagnostics.Debug.Assert$1(extractKey !== null, "extractKey may not be null");
                            this._buckets = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [capacity], null);
                            this._entries = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.Entry), null, [capacity], null);
                            this._extractKey = extractKey;
                        }
                        return this;
                    }
                    /*XHashtableState */ Resize()
                    {
                        if (this._numEntries < this._buckets.length)
                        {
                            return this;
                        }
                        /*int*/ let newSize = 0;
                        for(/*int*/ let bucketIdx = 0; bucketIdx < this._buckets.length; bucketIdx++)
                        {
                            /*int*/ let entryIdx = $.$spc.System.Array.$ReadT1.call(this._buckets, bucketIdx);
                            if (entryIdx === 0/*EndOfList*/)
                            {
                                entryIdx = $.$spc.System.Threading.Interlocked.CompareExchange($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$spc.System.Int32, this._buckets, bucketIdx, false, true), -1/*FullList*/, 0/*EndOfList*/);
                            }
                            while(entryIdx > 0/*EndOfList*/)
                            {
                                if ($.$spc.System.String.op_Inequality(this._extractKey.Invoke($.$spc.System.Array.$ReadT1.call(this._entries, entryIdx).Value), null))
                                {
                                    newSize++;
                                }
                                if ($.$spc.System.Array.$ReadT1.call(this._entries, entryIdx).Next === 0/*EndOfList*/)
                                {
                                    entryIdx = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => $.$spc.System.Array.$ReadT1.call(this._entries, entryIdx).Next, ($v) => $.$spc.System.Array.$ReadT1.call(this._entries, entryIdx).Next = $v, $.$spc.System.Int32), -1/*FullList*/, 0/*EndOfList*/);
                                }
                                else 
                                {
                                    entryIdx = $.$spc.System.Array.$ReadT1.call(this._entries, entryIdx).Next;
                                }
                            }
                            $.$spc.System.Diagnostics.Debug.Assert$1(entryIdx === 0/*EndOfList*/, "Resize() should only be called by one thread");
                        }
                        if (newSize < $.trunc(this._buckets.length / 2))
                        {
                            newSize = this._buckets.length;
                        }
                        else 
                        {
                            newSize = ((this._buckets.length * 2) | 0);
                            if (newSize < 0)
                            {
                                throw new $.$spc.System.OverflowException().$ctor$13();
                            }
                        }
                        /*XHashtableState*/ let newHashtable = new ($.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState)().$ctor$1(this._extractKey, newSize);
                        for(/*int*/ let bucketIdx = 0; bucketIdx < this._buckets.length; bucketIdx++)
                        {
                            /*int*/ let entryIdx = $.$spc.System.Array.$ReadT1.call(this._buckets, bucketIdx);
                            while(entryIdx > 0/*EndOfList*/)
                            {
                                newHashtable.TryAdd($.$spc.System.Array.$ReadT1.call(this._entries, entryIdx).Value, $.$discardRef());
                                entryIdx = $.$spc.System.Array.$ReadT1.call(this._entries, entryIdx).Next;
                            }
                            $.$spc.System.Diagnostics.Debug.Assert$1(entryIdx === -1/*FullList*/, "Linked list should have been closed when it was counted");
                        }
                        return newHashtable;
                    }
                    /*bool */ TryGetValue(/*string*/ key, /*int*/ index, /*int*/ count, /*out TValue*/ value)
                    {
                        /*int*/ let hashCode = $.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.ComputeHashCode(key, index, count);
                        /*int*/ let entryIndex = 0;
                        if (this.FindEntry(hashCode, key, index, count, $.$ref(() => entryIndex, ($v) => entryIndex = $v, $.$spc.System.Int32)))
                        {
                            value.$v = $.$spc.System.Array.$ReadT1.call(this._entries, entryIndex).Value;
                            return true;
                        }
                        value.$v = $.$default(TValue);
                        return false;
                    }
                    /*bool */ TryAdd(/*TValue*/ value, /*out TValue*/ newValue)
                    {
                        /*int*/ let newEntry, entryIndex;
                        /*string?*/ let key;
                        /*int*/ let hashCode;
                        newValue.$v = value;
                        key = this._extractKey.Invoke(value);
                        if ($.$spc.System.String.op_Equality(key, null))
                        {
                            return true;
                        }
                        hashCode = $.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.ComputeHashCode(key, 0, key.length);
                        newEntry = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._numEntries, ($v) => this._numEntries = $v, $.$spc.System.Int32));
                        if (newEntry < 0 || newEntry >= this._buckets.length)
                        {
                            return false;
                        }
                        $.$spc.System.Array.$ReadT1.call(this._entries, newEntry).Value = value;
                        $.$spc.System.Array.$ReadT1.call(this._entries, newEntry).HashCode = hashCode;
                        $.$spc.System.Threading.Thread.MemoryBarrier();
                        entryIndex = 0;
                        while(!this.FindEntry(hashCode, key, 0, key.length, $.$ref(() => entryIndex, ($v) => entryIndex = $v, $.$spc.System.Int32)))
                        {
                            if (entryIndex === 0)
                            {
                                entryIndex = $.$spc.System.Threading.Interlocked.CompareExchange($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$spc.System.Int32, this._buckets, hashCode & (((this._buckets.length - 1) | 0)), false, true), newEntry, 0/*EndOfList*/);
                            }
                            else 
                            {
                                entryIndex = $.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => $.$spc.System.Array.$ReadT1.call(this._entries, entryIndex).Next, ($v) => $.$spc.System.Array.$ReadT1.call(this._entries, entryIndex).Next = $v, $.$spc.System.Int32), newEntry, 0/*EndOfList*/);
                            }
                            if (entryIndex <= 0/*EndOfList*/)
                            {
                                return entryIndex === 0/*EndOfList*/;
                            }
                        }
                        newValue.$v = $.$spc.System.Array.$ReadT1.call(this._entries, entryIndex).Value;
                        return true;
                    }
                    /*bool */ FindEntry(/*int*/ hashCode, /*string*/ key, /*int*/ index, /*int*/ count, /*ref int*/ entryIndex)
                    {
                        /*int*/ let previousIndex = entryIndex.$v;
                        /*int*/ let currentIndex;
                        if (previousIndex === 0)
                        {
                            currentIndex = $.$spc.System.Array.$ReadT1.call(this._buckets, hashCode & (((this._buckets.length - 1) | 0)));
                        }
                        else 
                        {
                            currentIndex = previousIndex;
                        }
                        while(currentIndex > 0/*EndOfList*/)
                        {
                            if ($.$spc.System.Array.$ReadT1.call(this._entries, currentIndex).HashCode === hashCode)
                            {
                                /*string?*/ let keyCompare = this._extractKey.Invoke($.$spc.System.Array.$ReadT1.call(this._entries, currentIndex).Value);
                                if ($.$spc.System.String.op_Equality(keyCompare, null))
                                {
                                    if ($.$spc.System.Array.$ReadT1.call(this._entries, currentIndex).Next > 0/*EndOfList*/)
                                    {
                                        $.$spc.System.Array.$ReadT1.call(this._entries, currentIndex).Value = $.$default(TValue);
                                        currentIndex = $.$spc.System.Array.$ReadT1.call(this._entries, currentIndex).Next;
                                        if (previousIndex === 0)
                                        {
                                            $.$spc.System.Array.$WriteT1.call(this._buckets, currentIndex, hashCode & (((this._buckets.length - 1) | 0)));
                                        }
                                        else 
                                        {
                                            $.$spc.System.Array.$ReadT1.call(this._entries, previousIndex).Next = currentIndex;
                                        }
                                        continue;
                                    }
                                }
                                else 
                                {
                                    if (count === keyCompare.length && $.$spc.System.String.CompareOrdinal$2(key, index, keyCompare, 0, count) === 0)
                                    {
                                        entryIndex.$v = currentIndex;
                                        return true;
                                    }
                                }
                            }
                            previousIndex = currentIndex;
                            currentIndex = $.$spc.System.Array.$ReadT1.call(this._entries, currentIndex).Next;
                        }
                        entryIndex.$v = previousIndex;
                        return false;
                    }
                    static /*int */ ComputeHashCode(/*string*/ key, /*int*/ index, /*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(key, null), "key should have been checked previously for null");
                        return $.$spc.System.String.GetHashCode$2($.$spc.System.MemoryExtensions.AsSpan$7(key, index, count));
                    }
                    static $_Entry;
                    static get Entry()
                    {
                        let $cls = $.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState;
                        return $cls.$_Entry ??= $asm.$nstr("$spxl.System.Xml.Linq.XHashtable$$.XHashtableState.Entry", ($self) => class Entry extends $.$spc.System.ValueType
                        {
                            /*TValue*/  get Value() { return this.$getField(0, 4); }
                            /*TValue*/  set Value(value) { this.$setField(0, 4, value); }
                            /*int*/  get HashCode() { return this.$getField(4, 4); }
                            /*int*/  set HashCode(value) { this.$setField(4, 4, value); }
                            /*int*/  get Next() { return this.$getField(8, 4); }
                            /*int*/  set Next(value) { this.$setField(8, 4, value); }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy.Value = this.Value;
                                copy.HashCode = this.HashCode;
                                copy.Next = this.Next;
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this.Value = $.$default(TValue);
                                this.HashCode = 0;
                                this.Next = 0;
                            }
                            static $h = 2017708;
                            static $z = 12;
                            static $f = 0b10000001011000000;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":TValue?.$h??1507328,"n":"Value","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"t":655361,"n":"HashCode","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"t":655361,"n":"Next","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"d":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.$h,"h":this.$h}; }
                            static get $b() { return $.$spc.System.ValueType; }
                            static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>.XHashtableState.Entry`; }
                        }, $cls, ($v) => $cls.$_Entry = $v);
                    }
                    static $h = 1952172;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":this.$h,"n":"Resize","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":1},{"r":262145,"p":[{"n":"key","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361},{"n":"value","p":TValue?.$h??1507328,"f":2}],"n":"TryGetValue","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},{"r":262145,"p":[{"n":"value","p":TValue?.$h??1507328},{"n":"newValue","p":TValue?.$h??1507328,"f":2}],"n":"TryAdd","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},{"r":262145,"p":[{"n":"hashCode","p":655361},{"n":"key","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361},{"n":"entryIndex","p":655361,"f":4}],"n":"FindEntry","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2},{"r":655361,"p":[{"n":"key","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"ComputeHashCode","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":34}],"l":[{"t":0,"n":"_buckets","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":0,"n":"_entries","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":655361,"n":"_numEntries","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).ExtractKeyDelegate.$h,"n":"_extractKey","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":655361,"n":"EndOfList","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":34},{"t":655361,"n":"FullList","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":34}],"c":[{"p":[{"n":"extractKey","p":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).ExtractKeyDelegate.$h},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1}],"j":[$.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.Entry.$h],"d":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>.XHashtableState`; }
                }, $cls, ($v) => $cls.$_XHashtableState = $v);
            }
            static $h = 1821100;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"key","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361},{"n":"value","p":TValue?.$h??1507328,"f":2}],"n":"TryGetValue","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},{"r":TValue?.$h??1507328,"p":[{"n":"value","p":TValue?.$h??1507328}],"n":"Add","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"l":[{"t":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.$h,"n":"_state","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2}],"c":[{"p":[{"n":"extractKey","p":$.$spxl.System.Xml.Linq.XHashtable$$(TValue).ExtractKeyDelegate.$h},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"g":[TValue?.$h??1507328],"j":[$.$spxl.System.Xml.Linq.XHashtable$$(TValue).ExtractKeyDelegate.$h,$.$spxl.System.Xml.Linq.XHashtable$$(TValue).XHashtableState.$h],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XHashtable<${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$spxl.System.Xml.Linq.XHelper", ($self) => class XHelper
        {
            static /*bool */ IsInstanceOfType(/*object?*/ o, /*Type*/ type)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Inequality$1(type, null), "type != null");
                return o !== null && type.IsAssignableFrom($.$spc.System.Object.GetType.call(o));
            }
            static $h = 2083244;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"o","p":131073},{"n":"type","p":142606337}],"n":"IsInstanceOfType","d":2083244,"h":4297050540,"f":40}],"h":2083244}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XHelper`; }
        });
        
        $asm.$cls("$spxl.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$spxl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Private.Xml.Linq", $.$spxl.System.SR.$type.Assembly);
                    $.$spxl.System.SR.s_resourceManager = temp;
                }
                return $.$spxl.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$spxl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$spxl.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_AddAttribute()
            {
                return "An attribute cannot be added to content.";
            }
            static /*string */ get Argument_AddNode()
            {
                return "A node of type {0} cannot be added to content.";
            }
            static /*string */ FormatArgument_AddNode(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("A node of type {0} cannot be added to content.", arg1);
            }
            static /*string */ get Argument_AddNonWhitespace()
            {
                return "Non-whitespace characters cannot be added to content.";
            }
            static /*string */ get Argument_ConvertToString()
            {
                return "The argument cannot be converted to a string.";
            }
            static /*string */ get Argument_InvalidExpandedName()
            {
                return "'{0}' is an invalid expanded name.";
            }
            static /*string */ FormatArgument_InvalidExpandedName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("'{0}' is an invalid expanded name.", arg1);
            }
            static /*string */ get Argument_InvalidPIName()
            {
                return "'{0}' is an invalid name for a processing instruction.";
            }
            static /*string */ FormatArgument_InvalidPIName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("'{0}' is an invalid name for a processing instruction.", arg1);
            }
            static /*string */ get Argument_MustBeDerivedFrom()
            {
                return "The argument must be derived from {0}.";
            }
            static /*string */ FormatArgument_MustBeDerivedFrom(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The argument must be derived from {0}.", arg1);
            }
            static /*string */ get Argument_NamespaceDeclarationPrefixed()
            {
                return "The prefix '{0}' cannot be bound to the empty namespace name.";
            }
            static /*string */ FormatArgument_NamespaceDeclarationPrefixed(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The prefix '{0}' cannot be bound to the empty namespace name.", arg1);
            }
            static /*string */ get Argument_NamespaceDeclarationXml()
            {
                return "The prefix 'xml' is bound to the namespace name 'http://www.w3.org/XML/1998/namespace'. Other prefixes must not be bound to this namespace name, and it must not be declared as the default namespace.";
            }
            static /*string */ get Argument_NamespaceDeclarationXmlns()
            {
                return "The prefix 'xmlns' is bound to the namespace name 'http://www.w3.org/2000/xmlns/'. It must not be declared. Other prefixes must not be bound to this namespace name, and it must not be declared as the default namespace.";
            }
            static /*string */ get Argument_XObjectValue()
            {
                return "An XObject cannot be used as a value.";
            }
            static /*string */ get InvalidOperation_DeserializeInstance()
            {
                return "This instance cannot be deserialized.";
            }
            static /*string */ get InvalidOperation_DocumentStructure()
            {
                return "This operation would create an incorrectly structured document.";
            }
            static /*string */ get InvalidOperation_DuplicateAttribute()
            {
                return "Duplicate attribute.";
            }
            static /*string */ get InvalidOperation_ExpectedEndOfFile()
            {
                return "The XmlReader state should be EndOfFile after this operation.";
            }
            static /*string */ get InvalidOperation_ExpectedInteractive()
            {
                return "The XmlReader state should be Interactive.";
            }
            static /*string */ get InvalidOperation_ExpectedNodeType()
            {
                return "The XmlReader must be on a node of type {0} instead of a node of type {1}.";
            }
            static /*string */ FormatInvalidOperation_ExpectedNodeType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The XmlReader must be on a node of type {0} instead of a node of type {1}.", arg1, arg2);
            }
            static /*string */ get InvalidOperation_ExternalCode()
            {
                return "This operation was corrupted by external code.";
            }
            static /*string */ get InvalidOperation_MissingAncestor()
            {
                return "A common ancestor is missing.";
            }
            static /*string */ get InvalidOperation_MissingParent()
            {
                return "The parent is missing.";
            }
            static /*string */ get InvalidOperation_MissingRoot()
            {
                return "The root element is missing.";
            }
            static /*string */ get InvalidOperation_UnexpectedNodeType()
            {
                return "The XmlReader should not be on a node of type {0}.";
            }
            static /*string */ FormatInvalidOperation_UnexpectedNodeType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The XmlReader should not be on a node of type {0}.", arg1);
            }
            static /*string */ get InvalidOperation_UnresolvedEntityReference()
            {
                return "The XmlReader cannot resolve entity references.";
            }
            static /*string */ get InvalidOperation_WriteAttribute()
            {
                return "An attribute cannot be written after content.";
            }
            static /*string */ get NotSupported_WriteBase64()
            {
                return "This XmlWriter does not support base64 encoded data.";
            }
            static /*string */ get NotSupported_WriteEntityRef()
            {
                return "This XmlWriter does not support entity references.";
            }
            static /*string */ get Argument_CreateNavigator()
            {
                return "This XPathNavigator cannot be created on a node of type {0}.";
            }
            static /*string */ FormatArgument_CreateNavigator(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("This XPathNavigator cannot be created on a node of type {0}.", arg1);
            }
            static /*string */ get InvalidOperation_BadNodeType()
            {
                return "This operation is not valid on a node of type {0}.";
            }
            static /*string */ FormatInvalidOperation_BadNodeType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("This operation is not valid on a node of type {0}.", arg1);
            }
            static /*string */ get InvalidOperation_UnexpectedEvaluation()
            {
                return "The XPath expression evaluated to unexpected type {0}.";
            }
            static /*string */ FormatInvalidOperation_UnexpectedEvaluation(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The XPath expression evaluated to unexpected type {0}.", arg1);
            }
            static /*string */ get NotSupported_MoveToId()
            {
                return "This XPathNavigator does not support IDs.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$spxl.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$spxl.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$spxl.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$spxl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$spxl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$spxl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$spxl.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 182700;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":182700}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$spxl.System.Text.StringBuilderCache", ($self) => class StringBuilderCache
        {
            /*int*/ static MaxBuilderSize = 360;
            /*int*/ static DefaultCapacity = 16;
            /*StringBuilder?*/ static t_cachedInstance = null;
            static /*StringBuilder */ Acquire(/*int*/ capacity)
            {
                if (capacity <= 360/*MaxBuilderSize*/)
                {
                    /*StringBuilder?*/ let sb = $.$spxl.System.Text.StringBuilderCache.t_cachedInstance;
                    if (sb !== null)
                    {
                        if (capacity <= sb.Capacity)
                        {
                            $.$spxl.System.Text.StringBuilderCache.t_cachedInstance = null;
                            sb.Clear();
                            return sb;
                        }
                    }
                }
                return new $.$spc.System.Text.StringBuilder().$ctor$2(capacity);
            }
            static /*void */ Release(/*StringBuilder*/ sb)
            {
                if (sb.Capacity <= 360/*MaxBuilderSize*/)
                {
                    $.$spxl.System.Text.StringBuilderCache.t_cachedInstance = sb;
                }
            }
            static /*string */ GetStringAndRelease(/*StringBuilder*/ sb)
            {
                /*string*/ let result = $.$spc.System.Text.StringBuilder.ToString.call(sb);
                $.$spxl.System.Text.StringBuilderCache.Release(sb);
                return result;
            }
            static $h = 248236;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":122945537,"p":[{"n":"capacity","p":655361,"f":65,"v":16}],"n":"Acquire","d":248236,"h":17180117420,"f":33},{"r":65537,"p":[{"n":"sb","p":122945537}],"n":"Release","d":248236,"h":21475084716,"f":33},{"r":1310721,"p":[{"n":"sb","p":122945537}],"n":"GetStringAndRelease","d":248236,"h":25770052012,"f":33}],"l":[{"t":655361,"n":"MaxBuilderSize","d":248236,"h":4295215532,"f":40},{"t":655361,"n":"DefaultCapacity","d":248236,"h":8590182828,"f":34},{"t":122945537,"n":"t_cachedInstance","d":248236,"h":12885150124,"f":34,"a":[{"t":140181505,"c":4435148801}]}],"h":248236}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Text.StringBuilderCache`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XObjectChangeAnnotation", ($self) => class XObjectChangeAnnotation extends $.$spc.System.Object
        {
            /*EventHandler<XObjectChangeEventArgs>?*/ changing = null;
            /*EventHandler<XObjectChangeEventArgs>?*/ changed = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2738604;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,"n":"changing","d":2738604,"h":4297705900,"f":8},{"t":$.$spc.System.EventHandler$$($.$spxl.System.Xml.Linq.XObjectChangeEventArgs).$h,"n":"changed","d":2738604,"h":8592673196,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":2738604,"h":12887640492,"f":1}],"h":2738604}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XObjectChangeAnnotation`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XStreamingElement", ($self) => class XStreamingElement extends $.$spc.System.Object
        {
            /*XName*/ name = null;
            /*object?*/ content = null;
            $ctor$1(/*XName*/ name)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                    this.name = name;
                }
                return this;
            }
            $ctor$2(/*XName*/ name, /*object?*/ content)
            {
                this.$ctor$1(name);
                {
                    this.content = $.$is(content, $.$spc.System.Collections.Generic.List$$($.$spc.System.Object)) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [content], [-1], null) : content;
                }
                return this;
            }
            $ctor$3(/*XName*/ name, /*params object?[]*/ content)
            {
                this.$ctor$1(name);
                {
                    this.content = content;
                }
                return this;
            }
            /*XName */ get Name()
            {
                return this.name;
            }
            /*XName */ set Name(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                this.name = value;
            }
            /*void */ Add(/*object?*/ content)
            {
                if (content !== null)
                {
                    /*List<object>?*/ let list = $.$as(this.content, $.$spc.System.Collections.Generic.List$$($.$spc.System.Object));
                    if (list === null)
                    {
                        list = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Object))().$ctor$1();
                        if (this.content !== null)
                        {
                            list.Add(this.content);
                        }
                        this.content = list;
                    }
                    list.Add(content);
                }
            }
            /*void */ Add$1(/*params object?[]*/ content)
            {
                this.Add($.$cast(content, $.$spc.System.Object));
            }
            /*void */ Save(/*Stream*/ stream)
            {
                this.Save$1(stream, 0/*SaveOptions.None*/);
            }
            /*void */ Save$1(/*Stream*/ stream, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$3(stream, ws);
                    this.Save$4(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*void */ Save$2(/*TextWriter*/ textWriter)
            {
                this.Save$3(textWriter, 0/*SaveOptions.None*/);
            }
            /*void */ Save$3(/*TextWriter*/ textWriter, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$5(textWriter, ws);
                    this.Save$4(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*void */ Save$4(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                writer.WriteStartDocument();
                this.WriteTo(writer);
                writer.WriteEndDocument();
            }
            /*void */ Save$5(/*string*/ fileName)
            {
                this.Save$6(fileName, 0/*SaveOptions.None*/);
            }
            /*void */ Save$6(/*string*/ fileName, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$1(fileName, ws);
                    this.Save$4(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.GetXmlString(0/*SaveOptions.None*/);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XStreamingElement.ToString.apply(this, arguments); }
            /*string */ ToString$1(/*SaveOptions*/ options)
            {
                return this.GetXmlString(options);
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                new $.$spxl.System.Xml.Linq.StreamingElementWriter().$ctor$2(writer).WriteStreamingElement(this);
            }
            /*string */ GetXmlString(/*SaveOptions*/ o)
            {
                let sw = null;
                try
                {
                    sw = new $.$spc.System.IO.StringWriter().$ctor$5($.$spc.System.Globalization.CultureInfo.InvariantCulture);
                    /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                    ws.OmitXmlDeclaration = true;
                    if ((o & 1/*SaveOptions.DisableFormatting*/) === 0)
                    {
                        ws.Indent = true;
                    }
                    if ((o & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0)
                    {
                        ws.NamespaceHandling |= 1/*NamespaceHandling.OmitDuplicates*/;
                    }
                    let w = null;
                    try
                    {
                        w = $.$spx.System.Xml.XmlWriter.Create$5(sw, ws);
                        this.WriteTo(w);
                    }
                    finally
                    {
                        w?.System$IDisposable$Dispose();
                    }
                    return $.$spc.System.IO.StringWriter.ToString.call(sw);
                }
                finally
                {
                    sw?.System$IDisposable$Dispose();
                }
            }
            static $h = 2935212;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2148780,"g":{"r":0,"d":0,"h":30067706284,"f":1},"s":{"r":0,"d":0,"h":34362673580,"f":1},"n":"Name","d":2935212,"h":25772738988,"f":1}],"m":[{"r":65537,"p":[{"n":"content","p":131073}],"n":"Add","d":2935212,"h":38657640876,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"Add","o":"@$1","d":2935212,"h":42952608172,"f":1},{"r":65537,"p":[{"n":"stream","p":62193665}],"n":"Save","d":2935212,"h":47247575468,"f":1},{"r":65537,"p":[{"n":"stream","p":62193665},{"n":"options","p":1034668}],"n":"Save","o":"@$1","d":2935212,"h":51542542764,"f":1},{"r":65537,"p":[{"n":"textWriter","p":63045633}],"n":"Save","o":"@$2","d":2935212,"h":55837510060,"f":1},{"r":65537,"p":[{"n":"textWriter","p":63045633},{"n":"options","p":1034668}],"n":"Save","o":"@$3","d":2935212,"h":60132477356,"f":1},{"r":65537,"p":[{"n":"writer","p":58435741}],"n":"Save","o":"@$4","d":2935212,"h":64427444652,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"Save","o":"@$5","d":2935212,"h":68722411948,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"options","p":1034668}],"n":"Save","o":"@$6","d":2935212,"h":73017379244,"f":1},{"r":1310721,"n":"ToString","d":2935212,"h":77312346540,"f":32769},{"r":1310721,"p":[{"n":"options","p":1034668}],"n":"ToString","o":"@$1","d":2935212,"h":81607313836,"f":1},{"r":65537,"p":[{"n":"writer","p":58435741}],"n":"WriteTo","d":2935212,"h":85902281132,"f":1},{"r":1310721,"p":[{"n":"o","p":1034668}],"n":"GetXmlString","d":2935212,"h":90197248428,"f":2}],"l":[{"t":2148780,"n":"name","d":2935212,"h":4297902508,"f":8},{"t":131073,"n":"content","d":2935212,"h":8592869804,"f":8}],"c":[{"p":[{"n":"name","p":2148780}],"n":".ctor","o":"$ctor$1","d":2935212,"h":12887837100,"f":1},{"p":[{"n":"name","p":2148780},{"n":"content","p":131073}],"n":".ctor","o":"$ctor$2","d":2935212,"h":17182804396,"f":1},{"p":[{"n":"name","p":2148780},{"n":"content","p":0,"f":16}],"n":".ctor","o":"$ctor$3","d":2935212,"h":21477771692,"f":1}],"h":2935212}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XStreamingElement`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNamespace", ($self) => class XNamespace extends $.$spc.System.Object
        {
            /*string*/ static xmlPrefixNamespace = null;
            /*string*/ static xmlnsPrefixNamespace = null;
            /*XHashtable<WeakReference<XNamespace>>?*/ static s_namespaces = null;
            /*WeakReference<XNamespace>?*/ static s_refNone = null;
            /*WeakReference<XNamespace>?*/ static s_refXml = null;
            /*WeakReference<XNamespace>?*/ static s_refXmlns = null;
            /*string*/ _namespaceName = null;
            /*int*/ _hashCode = 0;
            /*XHashtable<XName>*/ _names = null;
            /*int*/ static NamesCapacity = 8;
            /*int*/ static NamespacesCapacity = 32;
            $ctor$1(/*string*/ namespaceName)
            {
                super.$ctor();
                {
                    this._namespaceName = namespaceName;
                    this._hashCode = $.$spc.System.String.GetHashCode.call(namespaceName);
                    this._names = new ($.$spxl.System.Xml.Linq.XHashtable$$($.$spxl.System.Xml.Linq.XName))().$ctor$1(new $.$spxl.System.Xml.Linq.XHashtable$$($.$spxl.System.Xml.Linq.XName).ExtractKeyDelegate().$ctor($.$spxl.System.Xml.Linq.XNamespace, $.$spxl.System.Xml.Linq.XNamespace.ExtractLocalName), 8/*NamesCapacity*/);
                }
                return this;
            }
            /*string */ get NamespaceName()
            {
                return this._namespaceName;
            }
            /*XName */ GetName(/*string*/ localName)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(localName, "localName");
                return this.GetName$1(localName, 0, localName.length);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this._namespaceName;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XNamespace.ToString.apply(this, arguments); }
            static /*XNamespace */ get None()
            {
                return $.$spxl.System.Xml.Linq.XNamespace.EnsureNamespace($.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_refNone, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_refNone = $v, $.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), $.$spc.System.String.Empty);
            }
            static /*XNamespace */ get Xml()
            {
                return $.$spxl.System.Xml.Linq.XNamespace.EnsureNamespace($.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_refXml, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_refXml = $v, $.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), "http://www.w3.org/XML/1998/namespace"/*xmlPrefixNamespace*/);
            }
            static /*XNamespace */ get Xmlns()
            {
                return $.$spxl.System.Xml.Linq.XNamespace.EnsureNamespace($.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_refXmlns, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_refXmlns = $v, $.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), "http://www.w3.org/2000/xmlns/"/*xmlnsPrefixNamespace*/);
            }
            static /*XNamespace */ Get(/*string*/ namespaceName)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(namespaceName, "namespaceName");
                return $.$spxl.System.Xml.Linq.XNamespace.Get$1(namespaceName, 0, namespaceName.length);
            }
            static /*XNamespace? */ op_Implicit(/*string?*/ namespaceName)
            {
                return $.$spc.System.String.op_Inequality(namespaceName, null) ? $.$spxl.System.Xml.Linq.XNamespace.Get(namespaceName) : null;
            }
            static /*XName */ op_Addition(/*XNamespace*/ ns, /*string*/ localName)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(ns, "ns");
                return ns.GetName(localName);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return this === obj;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$spxl.System.Xml.Linq.XNamespace.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._hashCode;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$spxl.System.Xml.Linq.XNamespace.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*XNamespace?*/ left, /*XNamespace?*/ right)
            {
                return left === right;
            }
            static /*bool */ op_Inequality(/*XNamespace?*/ left, /*XNamespace?*/ right)
            {
                return left !== right;
            }
            /*XName */ GetName$1(/*string*/ localName, /*int*/ index, /*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index >= 0 && index <= localName.length, "Caller should have checked that index was in bounds");
                $.$spc.System.Diagnostics.Debug.Assert$1(count >= 0 && ((index + count) | 0) <= localName.length, "Caller should have checked that count was in bounds");
                /*XName?*/ let name;
                if (this._names.TryGetValue(localName, index, count, $.$ref(() => name, ($v) => name = $v, $.$spxl.System.Xml.Linq.XName)))
                {
                    return name;
                }
                return this._names.Add(new $.$spxl.System.Xml.Linq.XName().$ctor$1(this, $.$spc.System.String.Substring$1.call(localName, index, count)));
            }
            static /*XNamespace */ Get$1(/*string*/ namespaceName, /*int*/ index, /*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index >= 0 && index <= namespaceName.length, "Caller should have checked that index was in bounds");
                $.$spc.System.Diagnostics.Debug.Assert$1(count >= 0 && ((index + count) | 0) <= namespaceName.length, "Caller should have checked that count was in bounds");
                if (count === 0)
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.None;
                }
                if ($.$spxl.System.Xml.Linq.XNamespace.s_namespaces === null)
                {
                    $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spxl.System.Xml.Linq.XHashtable$$($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)), $.$ref(() => $.$spxl.System.Xml.Linq.XNamespace.s_namespaces, ($v) => $.$spxl.System.Xml.Linq.XNamespace.s_namespaces = $v, $.$spxl.System.Xml.Linq.XHashtable$$($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))), new ($.$spxl.System.Xml.Linq.XHashtable$$($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)))().$ctor$1(new $.$spxl.System.Xml.Linq.XHashtable$$($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)).ExtractKeyDelegate().$ctor($.$spxl.System.Xml.Linq.XNamespace, $.$spxl.System.Xml.Linq.XNamespace.ExtractNamespace), 32/*NamespacesCapacity*/), null);
                }
                /*WeakReference<XNamespace>?*/ let refNamespace;
                /*XNamespace?*/ let ns;
                do
                {
                    if (!$.$spxl.System.Xml.Linq.XNamespace.s_namespaces.TryGetValue(namespaceName, index, count, $.$ref(() => refNamespace, ($v) => refNamespace = $v, $.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))))
                    {
                        if (count === "http://www.w3.org/XML/1998/namespace"/*xmlPrefixNamespace*/.length && $.$spc.System.String.CompareOrdinal$2(namespaceName, index, "http://www.w3.org/XML/1998/namespace"/*xmlPrefixNamespace*/, 0, count) === 0)
                        {
                            return $.$spxl.System.Xml.Linq.XNamespace.Xml;
                        }
                        if (count === "http://www.w3.org/2000/xmlns/"/*xmlnsPrefixNamespace*/.length && $.$spc.System.String.CompareOrdinal$2(namespaceName, index, "http://www.w3.org/2000/xmlns/"/*xmlnsPrefixNamespace*/, 0, count) === 0)
                        {
                            return $.$spxl.System.Xml.Linq.XNamespace.Xmlns;
                        }
                        refNamespace = $.$spxl.System.Xml.Linq.XNamespace.s_namespaces.Add(new ($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))().$ctor$1(new $.$spxl.System.Xml.Linq.XNamespace().$ctor$1($.$spc.System.String.Substring$1.call(namespaceName, index, count))));
                    }
                    /*XNamespace?*/ let target;
                    ns = refNamespace !== null && refNamespace.TryGetTarget($.$ref(() => target, ($v) => target = $v, $.$spxl.System.Xml.Linq.XNamespace)) ? target : null;
                }
                while($.$spxl.System.Xml.Linq.XNamespace.op_Equality(ns, null));
                return ns;
            }
            static /*string */ ExtractLocalName(/*XName*/ n)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spxl.System.Xml.Linq.XName.op_Inequality(n, null), "Null name should never exist here");
                return n.LocalName;
            }
            static /*string? */ ExtractNamespace(/*WeakReference<XNamespace>?*/ r)
            {
                /*XNamespace?*/ let target;
                return !(r === null) && r.TryGetTarget($.$ref(() => target, ($v) => target = $v, $.$spxl.System.Xml.Linq.XNamespace)) ? target.NamespaceName : null;
            }
            static /*XNamespace */ EnsureNamespace(/*ref WeakReference<XNamespace>?*/ refNmsp, /*string*/ namespaceName)
            {
                /*WeakReference<XNamespace>?*/ let refOld;
                while(true)
                {
                    refOld = refNmsp.$v;
                    /*XNamespace?*/ let ns;
                    if (refOld !== null && refOld.TryGetTarget($.$ref(() => ns, ($v) => ns = $v, $.$spxl.System.Xml.Linq.XNamespace)))
                    {
                        return ns;
                    }
                    $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace), refNmsp, new ($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace))().$ctor$1(new $.$spxl.System.Xml.Linq.XNamespace().$ctor$1(namespaceName)), refOld);
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.xmlPrefixNamespace = "http://www.w3.org/XML/1998/namespace";
                }
                {
                    this.xmlnsPrefixNamespace = "http://www.w3.org/2000/xmlns/";
                }
            }
            static $h = 2214316;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":60131756460,"f":1},"n":"NamespaceName","d":2214316,"h":55836789164,"f":1},{"p":2214316,"g":{"r":0,"d":0,"h":77311625644,"f":33},"n":"None","d":2214316,"h":73016658348,"f":33},{"p":2214316,"g":{"r":0,"d":0,"h":85901560236,"f":33},"n":"Xml","d":2214316,"h":81606592940,"f":33},{"p":2214316,"g":{"r":0,"d":0,"h":94491494828,"f":33},"n":"Xmlns","d":2214316,"h":90196527532,"f":33}],"m":[{"r":2148780,"p":[{"n":"localName","p":1310721}],"n":"GetName","d":2214316,"h":64426723756,"f":1},{"r":1310721,"n":"ToString","d":2214316,"h":68721691052,"f":32769},{"r":2214316,"p":[{"n":"namespaceName","p":1310721}],"n":"Get","d":2214316,"h":98786462124,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2214316,"h":111671364012,"f":32769},{"r":655361,"n":"GetHashCode","d":2214316,"h":115966331308,"f":32769},{"r":2148780,"p":[{"n":"localName","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetName","o":"@$1","d":2214316,"h":128851233196,"f":8},{"r":2214316,"p":[{"n":"namespaceName","p":1310721},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"Get","o":"@$1","d":2214316,"h":133146200492,"f":40},{"r":1310721,"p":[{"n":"n","p":2148780}],"n":"ExtractLocalName","d":2214316,"h":137441167788,"f":34},{"r":1310721,"p":[{"n":"r","p":$.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h}],"n":"ExtractNamespace","d":2214316,"h":141736135084,"f":34},{"r":2214316,"p":[{"n":"refNmsp","p":$.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,"f":4},{"n":"namespaceName","p":1310721}],"n":"EnsureNamespace","d":2214316,"h":146031102380,"f":34}],"l":[{"t":1310721,"n":"xmlPrefixNamespace","d":2214316,"h":4297181612,"f":40},{"t":1310721,"n":"xmlnsPrefixNamespace","d":2214316,"h":8592148908,"f":40},{"t":$.$spxl.System.Xml.Linq.XHashtable$$($.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace)).$h,"n":"s_namespaces","d":2214316,"h":12887116204,"f":34},{"t":$.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,"n":"s_refNone","d":2214316,"h":17182083500,"f":34},{"t":$.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,"n":"s_refXml","d":2214316,"h":21477050796,"f":34},{"t":$.$spc.System.WeakReference$$($.$spxl.System.Xml.Linq.XNamespace).$h,"n":"s_refXmlns","d":2214316,"h":25772018092,"f":34},{"t":1310721,"n":"_namespaceName","d":2214316,"h":30066985388,"f":2},{"t":655361,"n":"_hashCode","d":2214316,"h":34361952684,"f":2},{"t":$.$spxl.System.Xml.Linq.XHashtable$$($.$spxl.System.Xml.Linq.XName).$h,"n":"_names","d":2214316,"h":38656919980,"f":2},{"t":655361,"n":"NamesCapacity","d":2214316,"h":42951887276,"f":34},{"t":655361,"n":"NamespacesCapacity","d":2214316,"h":47246854572,"f":34}],"c":[{"p":[{"n":"namespaceName","p":1310721}],"n":".ctor","o":"$ctor$1","d":2214316,"h":51541821868,"f":8}],"h":2214316}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.XNamespace`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Schema.XNodeValidator", ($self) => class XNodeValidator extends $.$spc.System.Object
        {
            /*XmlSchemaSet*/ schemas = null;
            /*ValidationEventHandler?*/ validationEventHandler = null;
            /*XObject?*/ source = null;
            /*bool*/ addSchemaInfo = false;
            /*XmlNamespaceManager?*/ namespaceManager = null;
            /*XmlSchemaValidator?*/ validator = null;
            /*HashSet<XmlSchemaInfo>?*/ schemaInfos = null;
            /*ArrayList?*/ defaultAttributes = null;
            /*XName*/ xsiTypeName = null;
            /*XName*/ xsiNilName = null;
            $ctor$1(/*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                super.$ctor();
                {
                    this.schemas = schemas;
                    this.validationEventHandler = validationEventHandler;
                    /*XNamespace*/ let xsi = $.$spxl.System.Xml.Linq.XNamespace.Get("http://www.w3.org/2001/XMLSchema-instance");
                    this.xsiTypeName = xsi.GetName("type");
                    this.xsiNilName = xsi.GetName("nil");
                }
                return this;
            }
            /*void */ Validate(/*XObject*/ source, /*XmlSchemaObject?*/ partialValidationType, /*bool*/ addSchemaInfo)
            {
                this.source = source;
                this.addSchemaInfo = addSchemaInfo;
                /*XmlSchemaValidationFlags*/ let validationFlags = 16/*XmlSchemaValidationFlags.AllowXmlAttributes*/;
                /*XmlNodeType*/ let nt = source.NodeType;
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    switch($switchJumpState1 ?? nt)
                    {
                        case 9/*XmlNodeType.Document*/:
                        source = ($.$cast(source, $.$spxl.System.Xml.Linq.XDocument)).Root;
                        if (source === null)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingRoot);
                        }
                        validationFlags |= 8/*XmlSchemaValidationFlags.ProcessIdentityConstraints*/;
                        break;
                        case 1/*XmlNodeType.Element*/:
                        break;
                        case 2/*XmlNodeType.Attribute*/:
                        if (($.$cast(source, $.$spxl.System.Xml.Linq.XAttribute)).IsNamespaceDeclaration)
                        {
                            $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                            continue $switchJumpStart1;
                        }
                        if (source.Parent === null)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingParent);
                        }
                        break;
                        default:
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_BadNodeType, $.$box(nt, $.$spx.System.Xml.XmlNodeType)));
                    }
                    break;
                }
                this.namespaceManager = new $.$spx.System.Xml.XmlNamespaceManager().$ctor$2(this.schemas.NameTable);
                this.PushAncestorsAndSelf(source.Parent);
                this.validator = new $.$spx.System.Xml.Schema.XmlSchemaValidator().$ctor$1(this.schemas.NameTable, this.schemas, this.namespaceManager, validationFlags);
                this.validator.add_ValidationEventHandler(new $.$spx.System.Xml.Schema.ValidationEventHandler().$ctor(this, this.ValidationCallback));
                this.validator.XmlResolver = null;
                if (partialValidationType !== null)
                {
                    this.validator.Initialize$1(partialValidationType);
                }
                else 
                {
                    this.validator.Initialize();
                }
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(source);
                if (nt === 2/*XmlNodeType.Attribute*/)
                {
                    this.ValidateAttribute($.$cast(source, $.$spxl.System.Xml.Linq.XAttribute));
                }
                else 
                {
                    this.ValidateElement($.$cast(source, $.$spxl.System.Xml.Linq.XElement));
                }
                this.validator.EndValidation();
                this.RestoreLineInfo(original);
            }
            /*XmlSchemaInfo */ GetDefaultAttributeSchemaInfo(/*XmlSchemaAttribute*/ sa)
            {
                /*XmlSchemaInfo*/ let si = new $.$spx.System.Xml.Schema.XmlSchemaInfo().$ctor$1();
                si.IsDefault = true;
                si.IsNil = false;
                si.SchemaAttribute = sa;
                $.$spc.System.Diagnostics.Debug.Assert$1(sa.AttributeSchemaType !== null, "sa.AttributeSchemaType != null");
                /*XmlSchemaSimpleType*/ let st = sa.AttributeSchemaType;
                si.SchemaType = st;
                $.$spc.System.Diagnostics.Debug.Assert$1(st.Datatype !== null, "st.Datatype != null");
                if (st.Datatype.Variety === 2/*XmlSchemaDatatypeVariety.Union*/)
                {
                    /*string?*/ let value = this.GetDefaultValue(sa);
                    $.$spc.System.Diagnostics.Debug.Assert$1(st.Content !== null, "st.Content != null");
                    let $i1 = 0;
                    let $arr1 = ($.$cast(st.Content, $.$spx.System.Xml.Schema.XmlSchemaSimpleTypeUnion)).BaseMemberTypes;
                    while ($i1 < $arr1.length)
                    {
                        let mt = $arr1[$i1++];
                        /*object?*/ let typedValue = null;
                        try
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(mt.Datatype !== null, "mt.Datatype != null");
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(value, null), "value != null");
                            typedValue = mt.Datatype.ParseValue(value, this.schemas.NameTable, this.namespaceManager);
                        }
                        catch($e)
                        {
                        }
                        if (typedValue !== null)
                        {
                            si.MemberType = mt;
                            break;
                        }
                    }
                }
                si.Validity = 1/*XmlSchemaValidity.Valid*/;
                return si;
            }
            /*string? */ GetDefaultValue(/*XmlSchemaAttribute*/ sa)
            {
                /*XmlSchemaAttribute?*/ let saCopy = sa;
                /*XmlQualifiedName*/ let name = saCopy.RefName;
                if (!name.IsEmpty)
                {
                    saCopy = $.$as(this.schemas.GlobalAttributes.get_Item(name), $.$spx.System.Xml.Schema.XmlSchemaAttribute);
                    if (saCopy === null)
                    {
                        return null;
                    }
                }
                /*string?*/ let s = saCopy.FixedValue;
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    return s;
                }
                return saCopy.DefaultValue;
            }
            /*string? */ GetDefaultValue$1(/*XmlSchemaElement*/ se)
            {
                /*XmlSchemaElement?*/ let seCopy = se;
                /*XmlQualifiedName*/ let name = seCopy.RefName;
                if (!name.IsEmpty)
                {
                    seCopy = $.$as(this.schemas.GlobalElements.get_Item(name), $.$spx.System.Xml.Schema.XmlSchemaElement);
                    if (seCopy === null)
                    {
                        return null;
                    }
                }
                /*string?*/ let s = seCopy.FixedValue;
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    return s;
                }
                return seCopy.DefaultValue;
            }
            /*void */ ReplaceSchemaInfo(/*XObject*/ o, /*XmlSchemaInfo*/ schemaInfo)
            {
                this.schemaInfos ??= new ($.$spc.System.Collections.Generic.HashSet$$($.$spx.System.Xml.Schema.XmlSchemaInfo))().$ctor$2(new $.$spxl.System.Xml.Schema.XmlSchemaInfoEqualityComparer().$ctor$1());
                /*XmlSchemaInfo?*/ let si = o.Annotation$1($.$spx.System.Xml.Schema.XmlSchemaInfo);
                if (si !== null)
                {
                    this.schemaInfos.Add(si);
                    o.RemoveAnnotations$1($.$spx.System.Xml.Schema.XmlSchemaInfo);
                }
                if (!this.schemaInfos.TryGetValue(schemaInfo, $.$ref(() => si, ($v) => si = $v, $.$spx.System.Xml.Schema.XmlSchemaInfo)))
                {
                    si = schemaInfo;
                    this.schemaInfos.Add(si);
                }
                o.AddAnnotation(si);
            }
            /*void */ PushAncestorsAndSelf(/*XElement?*/ e)
            {
                while(e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration)
                            {
                                /*string*/ let localName = a.Name.LocalName;
                                if ($.$spc.System.String.op_Equality(localName, "xmlns"))
                                {
                                    localName = $.$spc.System.String.Empty;
                                }
                                if (!this.namespaceManager.HasNamespace(localName))
                                {
                                    this.namespaceManager.AddNamespace(localName, a.Value);
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                }
            }
            /*void */ PushElement(/*XElement*/ e, /*ref string?*/ xsiType, /*ref string?*/ xsiNil)
            {
                this.namespaceManager.PushScope();
                /*XAttribute?*/ let a = e.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if (a.IsNamespaceDeclaration)
                        {
                            /*string*/ let localName = a.Name.LocalName;
                            if ($.$spc.System.String.op_Equality(localName, "xmlns"))
                            {
                                localName = $.$spc.System.String.Empty;
                            }
                            this.namespaceManager.AddNamespace(localName, a.Value);
                        }
                        else 
                        {
                            /*XName*/ let name = a.Name;
                            if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, this.xsiTypeName))
                            {
                                xsiType.$v = a.Value;
                            }
                            else if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, this.xsiNilName))
                            {
                                xsiNil.$v = a.Value;
                            }
                        }
                    }
                    while(a !== e.lastAttr);
                }
            }
            /*IXmlLineInfo */ SaveLineInfo(/*XObject?*/ source)
            {
                /*IXmlLineInfo*/ let previousLineInfo = this.validator.LineInfoProvider;
                this.validator.LineInfoProvider = $.$as(source, $.$spx.System.Xml.IXmlLineInfo);
                return previousLineInfo;
            }
            /*void */ RestoreLineInfo(/*IXmlLineInfo*/ originalLineInfo)
            {
                this.validator.LineInfoProvider = originalLineInfo;
            }
            /*void */ ValidateAttribute(/*XAttribute*/ a)
            {
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(a);
                /*XmlSchemaInfo?*/ let si = this.addSchemaInfo ? new $.$spx.System.Xml.Schema.XmlSchemaInfo().$ctor$1() : null;
                this.source = a;
                this.validator.ValidateAttribute(a.Name.LocalName, a.Name.NamespaceName, a.Value, si);
                if (this.addSchemaInfo)
                {
                    this.ReplaceSchemaInfo(a, si);
                }
                this.RestoreLineInfo(original);
            }
            /*void */ ValidateAttributes(/*XElement*/ e)
            {
                /*XAttribute?*/ let a = e.lastAttr;
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(a);
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if (!a.IsNamespaceDeclaration)
                        {
                            this.ValidateAttribute(a);
                        }
                    }
                    while(a !== e.lastAttr);
                    this.source = e;
                }
                if (this.addSchemaInfo)
                {
                    if (this.defaultAttributes === null)
                    {
                        this.defaultAttributes = new $.$spc.System.Collections.ArrayList().$ctor$1();
                    }
                    else 
                    {
                        this.defaultAttributes.Clear();
                    }
                    this.validator.GetUnspecifiedDefaultAttributes(this.defaultAttributes);
                    var $en3 = this.defaultAttributes.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var sa = $en3.Current;
                        {
                            a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2($.$spxl.System.Xml.Linq.XNamespace.Get(sa.QualifiedName.Namespace).GetName(sa.QualifiedName.Name), this.GetDefaultValue(sa));
                            this.ReplaceSchemaInfo(a, this.GetDefaultAttributeSchemaInfo(sa));
                            e.Add(a);
                        }
                    }
                }
                this.RestoreLineInfo(original);
            }
            /*void */ ValidateElement(/*XElement*/ e)
            {
                /*XmlSchemaInfo?*/ let si = this.addSchemaInfo ? new $.$spx.System.Xml.Schema.XmlSchemaInfo().$ctor$1() : null;
                /*string?*/ let xsiType = null;
                /*string?*/ let xsiNil = null;
                this.PushElement(e, $.$ref(() => xsiType, ($v) => xsiType = $v, $.$spc.System.String), $.$ref(() => xsiNil, ($v) => xsiNil = $v, $.$spc.System.String));
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(e);
                this.source = e;
                this.validator.ValidateElement$1(e.Name.LocalName, e.Name.NamespaceName, si, xsiType, xsiNil, null, null);
                this.ValidateAttributes(e);
                this.validator.ValidateEndOfAttributes(si);
                this.ValidateNodes(e);
                this.validator.ValidateEndElement(si);
                if (this.addSchemaInfo)
                {
                    if (si.Validity === 1/*XmlSchemaValidity.Valid*/ && si.IsDefault)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(si.SchemaElement !== null, "si.SchemaElement != null");
                        e.Value = this.GetDefaultValue$1(si.SchemaElement);
                    }
                    this.ReplaceSchemaInfo(e, si);
                }
                this.RestoreLineInfo(original);
                this.namespaceManager.PopScope();
            }
            /*void */ ValidateNodes(/*XElement*/ e)
            {
                /*XNode?*/ let n = $.$as(e.content, $.$spxl.System.Xml.Linq.XNode);
                /*IXmlLineInfo*/ let original = this.SaveLineInfo(n);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*XElement?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (c !== null)
                        {
                            this.ValidateElement(c);
                        }
                        else 
                        {
                            /*XText?*/ let t = $.$as(n, $.$spxl.System.Xml.Linq.XText);
                            if (t !== null)
                            {
                                /*string*/ let s = t.Value;
                                if (s.length > 0)
                                {
                                    this.validator.LineInfoProvider = $.$as(t, $.$spx.System.Xml.IXmlLineInfo);
                                    this.validator.ValidateText(s);
                                }
                            }
                        }
                    }
                    while(n !== e.content);
                    this.source = e;
                }
                else 
                {
                    /*string?*/ let s = $.$as(e.content, $.$spc.System.String);
                    if ($.$spc.System.String.op_Inequality(s, null) && s.length > 0)
                    {
                        this.validator.ValidateText(s);
                    }
                }
                this.RestoreLineInfo(original);
            }
            /*void */ ValidationCallback(/*object?*/ sender, /*ValidationEventArgs*/ e)
            {
                if (this.validationEventHandler !== null)
                {
                    this.validationEventHandler.Invoke(this.source, e);
                }
                else if (e.Severity === 0/*XmlSeverityType.Error*/)
                {
                    throw e.Exception;
                }
            }
            static $h = 3197356;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"source","p":2607532},{"n":"partialValidationType","p":30910621},{"n":"addSchemaInfo","p":262145}],"n":"Validate","d":3197356,"h":51542804908,"f":1},{"r":30124189,"p":[{"n":"sa","p":27764893}],"n":"GetDefaultAttributeSchemaInfo","d":3197356,"h":55837772204,"f":2},{"r":1310721,"p":[{"n":"sa","p":27764893}],"n":"GetDefaultValue","d":3197356,"h":60132739500,"f":2},{"r":1310721,"p":[{"n":"se","p":29075613}],"n":"GetDefaultValue","o":"@$1","d":3197356,"h":64427706796,"f":2},{"r":65537,"p":[{"n":"o","p":2607532},{"n":"schemaInfo","p":30124189}],"n":"ReplaceSchemaInfo","d":3197356,"h":68722674092,"f":2},{"r":65537,"p":[{"n":"e","p":1690028}],"n":"PushAncestorsAndSelf","d":3197356,"h":73017641388,"f":2},{"r":65537,"p":[{"n":"e","p":1690028},{"n":"xsiType","p":1310721,"f":4},{"n":"xsiNil","p":1310721,"f":4}],"n":"PushElement","d":3197356,"h":77312608684,"f":2},{"r":13936797,"p":[{"n":"source","p":2607532}],"n":"SaveLineInfo","d":3197356,"h":81607575980,"f":2},{"r":65537,"p":[{"n":"originalLineInfo","p":13936797}],"n":"RestoreLineInfo","d":3197356,"h":85902543276,"f":2},{"r":65537,"p":[{"n":"a","p":1165740}],"n":"ValidateAttribute","d":3197356,"h":90197510572,"f":2},{"r":65537,"p":[{"n":"e","p":1690028}],"n":"ValidateAttributes","d":3197356,"h":94492477868,"f":2},{"r":65537,"p":[{"n":"e","p":1690028}],"n":"ValidateElement","d":3197356,"h":98787445164,"f":2},{"r":65537,"p":[{"n":"e","p":1690028}],"n":"ValidateNodes","d":3197356,"h":103082412460,"f":2},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":25471133}],"n":"ValidationCallback","d":3197356,"h":107377379756,"f":2}],"l":[{"t":31959197,"n":"schemas","d":3197356,"h":4298164652,"f":2},{"t":25536669,"n":"validationEventHandler","d":3197356,"h":8593131948,"f":2},{"t":2607532,"n":"source","d":3197356,"h":12888099244,"f":2},{"t":262145,"n":"addSchemaInfo","d":3197356,"h":17183066540,"f":2},{"t":51882141,"n":"namespaceManager","d":3197356,"h":21478033836,"f":2},{"t":33073309,"n":"validator","d":3197356,"h":25773001132,"f":2},{"t":$.$spc.System.Collections.Generic.HashSet$$($.$spx.System.Xml.Schema.XmlSchemaInfo).$h,"n":"schemaInfos","d":3197356,"h":30067968428,"f":2},{"t":23658497,"n":"defaultAttributes","d":3197356,"h":34362935724,"f":2},{"t":2148780,"n":"xsiTypeName","d":3197356,"h":38657903020,"f":2},{"t":2148780,"n":"xsiNilName","d":3197356,"h":42952870316,"f":2}],"c":[{"p":[{"n":"schemas","p":31959197},{"n":"validationEventHandler","p":25536669}],"n":".ctor","o":"$ctor$1","d":3197356,"h":47247837612,"f":1}],"h":3197356}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Schema.XNodeValidator`; }
        });
        
        $asm.$cls("$spxl.System.Xml.XPath.XObjectExtensions", ($self) => class XObjectExtensions
        {
            static /*XContainer? */ GetParent(/*this XObject*/ obj)
            {
                /*XContainer?*/ let ret = obj.Parent ?? obj.Document;
                if (ret === obj)
                {
                    return null;
                }
                return ret;
            }
            static $h = 3393964;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1362348,"p":[{"n":"obj","p":2607532}],"n":"GetParent","d":3393964,"h":4298361260,"f":33}],"h":3393964}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.XPath.XObjectExtensions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.Extensions", ($self) => class Extensions
        {
            static /*IEnumerable<XAttribute> */ Attributes(/*this IEnumerable<XElement?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetAttributes(source, null);
            }
            static /*IEnumerable<XAttribute> */ Attributes$1(/*this IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetAttributes(source, name) : $.$spxl.System.Xml.Linq.XAttribute.EmptySequence;
            }
            static /*IEnumerable<XElement> */ Ancestors(T, /*this IEnumerable<T?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetAncestors(T, source, null, false);
            }
            static /*IEnumerable<XElement> */ Ancestors$1(T, /*this IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetAncestors(T, source, name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<XElement> */ AncestorsAndSelf(/*this IEnumerable<XElement?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetAncestors($.$spxl.System.Xml.Linq.XElement, source, null, true);
            }
            static /*IEnumerable<XElement> */ AncestorsAndSelf$1(/*this IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetAncestors($.$spxl.System.Xml.Linq.XElement, source, name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<XNode> */ Nodes(T, /*this IEnumerable<T?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.NodesIterator(T, source);
            }
            static /*IEnumerable<XNode> */ NodesIterator(T, /*IEnumerable<T?>*/ source)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                /*XNode?*/ let n = root.LastNode;
                                if (n !== null)
                                {
                                    do
                                    {
                                        n = n.next;
                                        yield n;
                                    }
                                    while(n.parent === root && n !== root.content);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XNode> */ DescendantNodes(T, /*this IEnumerable<T?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendantNodes(T, source, false);
            }
            static /*IEnumerable<XElement> */ Descendants(T, /*this IEnumerable<T?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendants(T, source, null, false);
            }
            static /*IEnumerable<XElement> */ Descendants$1(T, /*this IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetDescendants(T, source, name, false) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<XNode> */ DescendantNodesAndSelf(/*this IEnumerable<XElement?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendantNodes($.$spxl.System.Xml.Linq.XElement, source, true);
            }
            static /*IEnumerable<XElement> */ DescendantsAndSelf(/*this IEnumerable<XElement?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetDescendants($.$spxl.System.Xml.Linq.XElement, source, null, true);
            }
            static /*IEnumerable<XElement> */ DescendantsAndSelf$1(/*this IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetDescendants($.$spxl.System.Xml.Linq.XElement, source, name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<XElement> */ Elements(T, /*this IEnumerable<T?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.GetElements(T, source, null);
            }
            static /*IEnumerable<XElement> */ Elements$1(T, /*this IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? $.$spxl.System.Xml.Linq.Extensions.GetElements(T, source, name) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            static /*IEnumerable<T> */ InDocumentOrder(T, /*this IEnumerable<T>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spxl.System.Xml.Linq.Extensions.DocumentOrderIterator(T, source);
            }
            static /*IEnumerable<T> */ DocumentOrderIterator(T, /*IEnumerable<T>*/ source)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*int*/ let count;
                    /*T[]*/ let items = $.$spxl.System.Collections.Generic.EnumerableHelpers.ToArray(T, source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32));
                    if (count > 0)
                    {
                        $.$spc.System.Array.Sort$14($.$spxl.System.Xml.Linq.XNode, items, 0, count, $.$spxl.System.Xml.Linq.XNode.DocumentOrderComparer);
                        for(/*int*/ let i = 0; i !== count; ++i)
                        {
                            yield $.$spc.System.Array.$ReadT1.call(items, i);
                        }
                    }
                }.bind(this));
            }
            static /*void */ Remove(/*this IEnumerable<XAttribute?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                /*int*/ let count;
                /*XAttribute?[]*/ let attributes = $.$spxl.System.Collections.Generic.EnumerableHelpers.ToArray($.$spxl.System.Xml.Linq.XAttribute, source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32));
                for(/*int*/ let i = 0; i < count; i++)
                {
                    $.$spc.System.Array.$ReadT1.call(attributes, i)?.Remove();
                }
            }
            static /*void */ Remove$1(T, /*this IEnumerable<T?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                /*int*/ let count;
                /*T?[]*/ let nodes = $.$spxl.System.Collections.Generic.EnumerableHelpers.ToArray(T, source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32));
                for(/*int*/ let i = 0; i < count; i++)
                {
                    $.$dsp($.$spc.System.Array.$ReadT1.call(nodes, i), T, ($t) => $t.Remove,);
                }
            }
            static /*IEnumerable<XAttribute> */ GetAttributes(/*IEnumerable<XElement?>*/ source, /*XName?*/ name)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var e = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (e !== null)
                            {
                                /*XAttribute?*/ let a = e.lastAttr;
                                if (a !== null)
                                {
                                    do
                                    {
                                        a = a.next;
                                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(a.name, name))
                                        {
                                            yield a;
                                        }
                                    }
                                    while(a.parent === e && a !== e.lastAttr);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XElement> */ GetAncestors(T, /*IEnumerable<T?>*/ source, /*XName?*/ name, /*bool*/ self)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (node !== null)
                            {
                                /*XElement?*/ let e = $.$as((self ? node : node.parent), $.$spxl.System.Xml.Linq.XElement);
                                while(e !== null)
                                {
                                    if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                                    {
                                        yield e;
                                    }
                                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XNode> */ GetDescendantNodes(T, /*IEnumerable<T?>*/ source, /*bool*/ self)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                if (self)
                                {
                                    yield root;
                                }
                                /*XNode?*/ let n = root;
                                while(true)
                                {
                                    /*XContainer?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XContainer);
                                    /*XNode?*/ let first;
                                    if (c !== null && (first = c.FirstNode) !== null)
                                    {
                                        n = first;
                                    }
                                    else 
                                    {
                                        while(n !== null && n !== root && n === n.parent.content)
                                        {
                                            n = n.parent;
                                        }
                                        if (n === null || n === root)
                                        {
                                            break;
                                        }
                                        n = n.next;
                                    }
                                    yield n;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XElement> */ GetDescendants(T, /*IEnumerable<T?>*/ source, /*XName?*/ name, /*bool*/ self)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                if (self)
                                {
                                    /*XElement*/ let e = $.$cast(root, $.$spxl.System.Xml.Linq.XElement);
                                    if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name))
                                    {
                                        yield e;
                                    }
                                }
                                /*XNode?*/ let n = root;
                                /*XContainer?*/ let c = root;
                                while(true)
                                {
                                    if (c !== null && $.$is(c.content, $.$spxl.System.Xml.Linq.XNode))
                                    {
                                        n = ($.$cast(c.content, $.$spxl.System.Xml.Linq.XNode)).next;
                                    }
                                    else 
                                    {
                                        while(n !== null && n !== root && n === n.parent.content)
                                        {
                                            n = n.parent;
                                        }
                                        if (n === null || n === root)
                                        {
                                            break;
                                        }
                                        n = n.next;
                                    }
                                    /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                                    if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                                    {
                                        yield e;
                                    }
                                    c = e;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<XElement> */ GetElements(T, /*IEnumerable<T?>*/ source, /*XName?*/ name)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var root = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (root !== null)
                            {
                                /*XNode?*/ let n = $.$as(root.content, $.$spxl.System.Xml.Linq.XNode);
                                if (n !== null)
                                {
                                    do
                                    {
                                        n = n.next;
                                        /*XElement?*/ let e = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                                        if (e !== null && ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(e.name, name)))
                                        {
                                            yield e;
                                        }
                                    }
                                    while(n.parent === root && n !== root.content);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static $h = 444844;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h}],"n":"Attributes","d":444844,"h":4295412140,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h},{"n":"name","p":2148780}],"n":"Attributes","o":"@$1","d":444844,"h":8590379436,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Ancestors","d":444844,"h":12885346732,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2148780}],"g":["T"],"n":"Ancestors","o":"@$1","d":444844,"h":17180314028,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h}],"n":"AncestorsAndSelf","d":444844,"h":21475281324,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h},{"n":"name","p":2148780}],"n":"AncestorsAndSelf","o":"@$1","d":444844,"h":25770248620,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Nodes","d":444844,"h":30065215916,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"NodesIterator","d":444844,"h":34360183212,"f":131106},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"DescendantNodes","d":444844,"h":38655150508,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Descendants","d":444844,"h":42950117804,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2148780}],"g":["T"],"n":"Descendants","o":"@$1","d":444844,"h":47245085100,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h}],"n":"DescendantNodesAndSelf","d":444844,"h":51540052396,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h}],"n":"DescendantsAndSelf","d":444844,"h":55835019692,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h},{"n":"name","p":2148780}],"n":"DescendantsAndSelf","o":"@$1","d":444844,"h":60129986988,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Elements","d":444844,"h":64424954284,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2148780}],"g":["T"],"n":"Elements","o":"@$1","d":444844,"h":68719921580,"f":131105},{"r":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"InDocumentOrder","d":444844,"h":73014888876,"f":131105},{"r":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"DocumentOrderIterator","d":444844,"h":77309856172,"f":131106},{"r":65537,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h}],"n":"Remove","d":444844,"h":81604823468,"f":33},{"r":65537,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"g":["T"],"n":"Remove","o":"@$1","d":444844,"h":85899790764,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"source","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h},{"n":"name","p":2148780}],"n":"GetAttributes","d":444844,"h":90194758060,"f":34},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2148780},{"n":"self","p":262145}],"g":["T"],"n":"GetAncestors","d":444844,"h":94489725356,"f":131106},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"self","p":262145}],"g":["T"],"n":"GetDescendantNodes","d":444844,"h":98784692652,"f":131106},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2148780},{"n":"self","p":262145}],"g":["T"],"n":"GetDescendants","d":444844,"h":103079659948,"f":131106},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"source","p":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h},{"n":"name","p":2148780}],"g":["T"],"n":"GetElements","d":444844,"h":107374627244,"f":131106}],"h":444844}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Linq.Extensions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Schema.Extensions", ($self) => class Extensions
        {
            static /*IXmlSchemaInfo? */ GetSchemaInfo(/*this XElement*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.Annotation$1($.$spx.System.Xml.Schema.IXmlSchemaInfo);
            }
            static /*IXmlSchemaInfo? */ GetSchemaInfo$1(/*this XAttribute*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.Annotation$1($.$spx.System.Xml.Schema.IXmlSchemaInfo);
            }
            static /*void */ Validate(/*this XDocument*/ source, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                $.$spxl.System.Xml.Schema.Extensions.Validate$1(source, schemas, validationEventHandler, false);
            }
            static /*void */ Validate$1(/*this XDocument*/ source, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler, /*bool*/ addSchemaInfo)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(schemas, "schemas");
                new $.$spxl.System.Xml.Schema.XNodeValidator().$ctor$1(schemas, validationEventHandler).Validate(source, null, addSchemaInfo);
            }
            static /*void */ Validate$2(/*this XElement*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                $.$spxl.System.Xml.Schema.Extensions.Validate$3(source, partialValidationType, schemas, validationEventHandler, false);
            }
            static /*void */ Validate$3(/*this XElement*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler, /*bool*/ addSchemaInfo)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(partialValidationType, "partialValidationType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(schemas, "schemas");
                new $.$spxl.System.Xml.Schema.XNodeValidator().$ctor$1(schemas, validationEventHandler).Validate(source, partialValidationType, addSchemaInfo);
            }
            static /*void */ Validate$4(/*this XAttribute*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler)
            {
                $.$spxl.System.Xml.Schema.Extensions.Validate$5(source, partialValidationType, schemas, validationEventHandler, false);
            }
            static /*void */ Validate$5(/*this XAttribute*/ source, /*XmlSchemaObject*/ partialValidationType, /*XmlSchemaSet*/ schemas, /*ValidationEventHandler?*/ validationEventHandler, /*bool*/ addSchemaInfo)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(partialValidationType, "partialValidationType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(schemas, "schemas");
                new $.$spxl.System.Xml.Schema.XNodeValidator().$ctor$1(schemas, validationEventHandler).Validate(source, partialValidationType, addSchemaInfo);
            }
            static $h = 3066284;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":21801117,"p":[{"n":"source","p":1690028}],"n":"GetSchemaInfo","d":3066284,"h":4298033580,"f":33},{"r":21801117,"p":[{"n":"source","p":1165740}],"n":"GetSchemaInfo","o":"@$1","d":3066284,"h":8593000876,"f":33},{"r":65537,"p":[{"n":"source","p":1558956},{"n":"schemas","p":31959197},{"n":"validationEventHandler","p":25536669}],"n":"Validate","d":3066284,"h":12887968172,"f":33},{"r":65537,"p":[{"n":"source","p":1558956},{"n":"schemas","p":31959197},{"n":"validationEventHandler","p":25536669},{"n":"addSchemaInfo","p":262145}],"n":"Validate","o":"@$1","d":3066284,"h":17182935468,"f":33},{"r":65537,"p":[{"n":"source","p":1690028},{"n":"partialValidationType","p":30910621},{"n":"schemas","p":31959197},{"n":"validationEventHandler","p":25536669}],"n":"Validate","o":"@$2","d":3066284,"h":21477902764,"f":33},{"r":65537,"p":[{"n":"source","p":1690028},{"n":"partialValidationType","p":30910621},{"n":"schemas","p":31959197},{"n":"validationEventHandler","p":25536669},{"n":"addSchemaInfo","p":262145}],"n":"Validate","o":"@$3","d":3066284,"h":25772870060,"f":33},{"r":65537,"p":[{"n":"source","p":1165740},{"n":"partialValidationType","p":30910621},{"n":"schemas","p":31959197},{"n":"validationEventHandler","p":25536669}],"n":"Validate","o":"@$4","d":3066284,"h":30067837356,"f":33},{"r":65537,"p":[{"n":"source","p":1165740},{"n":"partialValidationType","p":30910621},{"n":"schemas","p":31959197},{"n":"validationEventHandler","p":25536669},{"n":"addSchemaInfo","p":262145}],"n":"Validate","o":"@$5","d":3066284,"h":34362804652,"f":33}],"h":3066284}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.Schema.Extensions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.XPath.XPathEvaluator", ($self) => class XPathEvaluator
        {
            static /*object */ Evaluate(T, /*XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                /*XPathNavigator*/ let navigator = $.$spxl.System.Xml.XPath.Extensions.CreateNavigator(node);
                /*object*/ let result = navigator.Evaluate$1(expression, resolver);
                /*XPathNodeIterator?*/ let iterator = $.$as(result, $.$spx.System.Xml.XPath.XPathNodeIterator);
                if (iterator !== null)
                {
                    return $.$spxl.System.Xml.XPath.XPathEvaluator.EvaluateIterator(T, iterator);
                }
                if (!($.$is(result, T)))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedEvaluation, $.$spc.System.Object.GetType.call(result)));
                }
                return $.$box($.$cast(result, T), T);
            }
            static /*IEnumerable<T> */ EvaluateIterator(T, /*XPathNodeIterator*/ result)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = result.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var navigator = $en3.Current;
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(navigator.UnderlyingObject !== null, "navigator.UnderlyingObject != null");
                            /*object*/ let r = navigator.UnderlyingObject;
                            if (!($.$is(r, T)))
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_UnexpectedEvaluation, $.$spc.System.Object.GetType.call(r)));
                            }
                            yield $.$cast(r, T);
                            /*XText?*/ let t = $.$as(r, $.$spxl.System.Xml.Linq.XText);
                            if (t !== null && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(t) !== null)
                            {
                                do
                                {
                                    t = $.$as(t.NextNode, $.$spxl.System.Xml.Linq.XText);
                                    if (t === null)
                                    {
                                        break;
                                    }
                                    yield $.$cast($.$cast(t, $.$spc.System.Object), T);
                                }
                                while(t !== $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(t).LastNode);
                            }
                        }
                    }
                }.bind(this));
            }
            static $h = 3459500;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131073,"p":[{"n":"node","p":2279852},{"n":"expression","p":1310721},{"n":"resolver","p":14002333}],"g":["T"],"n":"Evaluate","d":3459500,"h":4298426796,"f":131105},{"r":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h,"p":[{"n":"result","p":59746461}],"g":["T"],"n":"EvaluateIterator","d":3459500,"h":8593394092,"f":131106}],"h":3459500}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.XPath.XPathEvaluator`; }
        });
        
        $asm.$cls("$spxl.System.Xml.XPath.Extensions", ($self) => class Extensions
        {
            static /*XPathNavigator */ CreateNavigator(/*this XNode*/ node)
            {
                return $.$spxl.System.Xml.XPath.Extensions.CreateNavigator$1(node, null);
            }
            static /*XPathNavigator */ CreateNavigator$1(/*this XNode*/ node, /*XmlNameTable?*/ nameTable)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(node, "node");
                if ($.$is(node, $.$spxl.System.Xml.Linq.XDocumentType))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_CreateNavigator, $.$box(10/*XmlNodeType.DocumentType*/, $.$spx.System.Xml.XmlNodeType)));
                }
                /*XText?*/ let text = $.$as(node, $.$spxl.System.Xml.Linq.XText);
                if (text !== null)
                {
                    if ($.$is($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(text), $.$spxl.System.Xml.Linq.XDocument))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_CreateNavigator, $.$box(13/*XmlNodeType.Whitespace*/, $.$spx.System.Xml.XmlNodeType)));
                    }
                    node = $.$spxl.System.Xml.XPath.Extensions.CalibrateText(text);
                }
                return new $.$spxl.System.Xml.XPath.XNodeNavigator().$ctor$3(node, nameTable);
            }
            static /*object */ XPathEvaluate(/*this XNode*/ node, /*string*/ expression)
            {
                return $.$spxl.System.Xml.XPath.Extensions.XPathEvaluate$1(node, expression, null);
            }
            static /*object */ XPathEvaluate$1(/*this XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(node, "node");
                return $.$spxl.System.Xml.XPath.XPathEvaluator.Evaluate($.$spc.System.Object, node, expression, resolver);
            }
            static /*XElement? */ XPathSelectElement(/*this XNode*/ node, /*string*/ expression)
            {
                return $.$spxl.System.Xml.XPath.Extensions.XPathSelectElement$1(node, expression, null);
            }
            static /*XElement? */ XPathSelectElement$1(/*this XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                return $.$sl.System.Linq.Enumerable.FirstOrDefault($.$spxl.System.Xml.Linq.XElement, $.$spxl.System.Xml.XPath.Extensions.XPathSelectElements$1(node, expression, resolver));
            }
            static /*IEnumerable<XElement> */ XPathSelectElements(/*this XNode*/ node, /*string*/ expression)
            {
                return $.$spxl.System.Xml.XPath.Extensions.XPathSelectElements$1(node, expression, null);
            }
            static /*IEnumerable<XElement> */ XPathSelectElements$1(/*this XNode*/ node, /*string*/ expression, /*IXmlNamespaceResolver?*/ resolver)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(node, "node");
                return $.$cast($.$spxl.System.Xml.XPath.XPathEvaluator.Evaluate($.$spxl.System.Xml.Linq.XElement, node, expression, resolver), $.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement));
            }
            static /*XText */ CalibrateText(/*XText*/ n)
            {
                /*XContainer?*/ let parentNode = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n);
                if (parentNode === null)
                {
                    return n;
                }
                var $en2 = parentNode.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var node = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*XText?*/ let t = $.$as(node, $.$spxl.System.Xml.Linq.XText);
                        /*bool*/ let isTextNode = t !== null;
                        if (isTextNode && node === n)
                        {
                            return t;
                        }
                    }
                }
                $.$spc.System.Diagnostics.Debug.Fail("Parent node doesn't contain itself.");
                return null;
            }
            static $h = 3262892;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":59287709,"p":[{"n":"node","p":2279852}],"n":"CreateNavigator","d":3262892,"h":4298230188,"f":33},{"r":59287709,"p":[{"n":"node","p":2279852},{"n":"nameTable","p":52078749}],"n":"CreateNavigator","o":"@$1","d":3262892,"h":8593197484,"f":33},{"r":131073,"p":[{"n":"node","p":2279852},{"n":"expression","p":1310721}],"n":"XPathEvaluate","d":3262892,"h":12888164780,"f":33},{"r":131073,"p":[{"n":"node","p":2279852},{"n":"expression","p":1310721},{"n":"resolver","p":14002333}],"n":"XPathEvaluate","o":"@$1","d":3262892,"h":17183132076,"f":33},{"r":1690028,"p":[{"n":"node","p":2279852},{"n":"expression","p":1310721}],"n":"XPathSelectElement","d":3262892,"h":21478099372,"f":33},{"r":1690028,"p":[{"n":"node","p":2279852},{"n":"expression","p":1310721},{"n":"resolver","p":14002333}],"n":"XPathSelectElement","o":"@$1","d":3262892,"h":25773066668,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"node","p":2279852},{"n":"expression","p":1310721}],"n":"XPathSelectElements","d":3262892,"h":30068033964,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"node","p":2279852},{"n":"expression","p":1310721},{"n":"resolver","p":14002333}],"n":"XPathSelectElements","o":"@$1","d":3262892,"h":34363001260,"f":33},{"r":3000748,"p":[{"n":"n","p":3000748}],"n":"CalibrateText","d":3262892,"h":38657968556,"f":34}],"h":3262892}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Xml.XPath.Extensions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XName", ($self) => class XName extends $.$spc.System.Object
        {
            /*XNamespace*/ _ns = null;
            /*string*/ _localName = null;
            /*int*/ _hashCode = 0;
            $ctor$1(/*XNamespace*/ ns, /*string*/ localName)
            {
                super.$ctor();
                {
                    this._ns = ns;
                    this._localName = $.$spx.System.Xml.XmlConvert.VerifyNCName(localName);
                    this._hashCode = $.$spxl.System.Xml.Linq.XNamespace.GetHashCode.call(ns) ^ $.$spc.System.String.GetHashCode.call(localName);
                }
                return this;
            }
            /*string */ get LocalName()
            {
                return this._localName;
            }
            /*XNamespace */ get Namespace()
            {
                return this._ns;
            }
            /*string */ get NamespaceName()
            {
                return this._ns.NamespaceName;
            }
            static/*conventional*/ /*string */ ToString()
            {
                if (this._ns.NamespaceName.length === 0)
                {
                    return this._localName;
                }
                return "{" + this._ns.NamespaceName + "}" + this._localName;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XName.ToString.apply(this, arguments); }
            static /*XName */ Get(/*string*/ expandedName)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(expandedName, "expandedName");
                if ($.$spc.System.String.get_Chars.call(expandedName, 0) === /*{*/ 123)
                {
                    /*int*/ let i = $.$spc.System.String.LastIndexOf.call(expandedName, /*}*/ 125);
                    if (i <= 1 || i === ((expandedName.length - 1) | 0))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_InvalidExpandedName, expandedName));
                    }
                    return $.$spxl.System.Xml.Linq.XNamespace.Get$1(expandedName, 1, ((i - 1) | 0)).GetName$1(expandedName, ((i + 1) | 0), ((((expandedName.length - i) | 0) - 1) | 0));
                }
                else 
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.None.GetName(expandedName);
                }
            }
            static /*XName */ Get$1(/*string*/ localName, /*string*/ namespaceName)
            {
                return $.$spxl.System.Xml.Linq.XNamespace.Get(namespaceName).GetName(localName);
            }
            static /*XName? */ op_Implicit(/*string?*/ expandedName)
            {
                return $.$spc.System.String.op_Inequality(expandedName, null) ? $.$spxl.System.Xml.Linq.XName.Get(expandedName) : null;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return this === obj;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$spxl.System.Xml.Linq.XName.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._hashCode;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$spxl.System.Xml.Linq.XName.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*XName?*/ left, /*XName?*/ right)
            {
                return left === right;
            }
            static /*bool */ op_Inequality(/*XName?*/ left, /*XName?*/ right)
            {
                return left !== right;
            }
            /*bool */ System$IEquatable$$$Equals(/*XName?*/ other)
            {
                return this === other;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2148780;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25771952556,"f":1},"n":"LocalName","d":2148780,"h":21476985260,"f":1},{"p":2214316,"g":{"r":0,"d":0,"h":34361887148,"f":1},"n":"Namespace","d":2148780,"h":30066919852,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42951821740,"f":1},"n":"NamespaceName","d":2148780,"h":38656854444,"f":1}],"m":[{"r":1310721,"n":"ToString","d":2148780,"h":47246789036,"f":32769},{"r":2148780,"p":[{"n":"expandedName","p":1310721}],"n":"Get","d":2148780,"h":51541756332,"f":33},{"r":2148780,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"Get","o":"@$1","d":2148780,"h":55836723628,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2148780,"h":64426658220,"f":32769},{"r":655361,"n":"GetHashCode","d":2148780,"h":68721625516,"f":32769}],"l":[{"t":2214316,"n":"_ns","d":2148780,"h":4297116076,"f":2},{"t":1310721,"n":"_localName","d":2148780,"h":8592083372,"f":2},{"t":655361,"n":"_hashCode","d":2148780,"h":12887050668,"f":2}],"c":[{"p":[{"n":"ns","p":2214316},{"n":"localName","p":1310721}],"n":".ctor","o":"$ctor$1","d":2148780,"h":17182017964,"f":8}],"i":[$.$spc.System.IEquatable$$($.$spxl.System.Xml.Linq.XName).$h,113377281],"h":2148780}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$spxl.System.Xml.Linq.XName), $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Xml.Linq.XName`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNodeEqualityComparer", ($self) => class XNodeEqualityComparer extends $.$spc.System.Object
        {
            /*bool */ Equals$2(/*XNode?*/ x, /*XNode?*/ y)
            {
                return $.$spxl.System.Xml.Linq.XNode.DeepEquals(x, y);
            }
            /*int */ GetHashCode$1(/*XNode*/ obj)
            {
                return obj !== null ? obj.GetDeepHashCode() : 0;
            }
            /*bool */ System$Collections$IEqualityComparer$Equals(/*object?*/ x, /*object?*/ y)
            {
                /*XNode?*/ let n1 = $.$as(x, $.$spxl.System.Xml.Linq.XNode);
                if (n1 === null && x !== null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "x");
                }
                /*XNode?*/ let n2 = $.$as(y, $.$spxl.System.Xml.Linq.XNode);
                if (n2 === null && y !== null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "y");
                }
                return this.Equals$2(n1, n2);
            }
            /*int */ System$Collections$IEqualityComparer$GetHashCode(/*object*/ obj)
            {
                /*XNode?*/ let n = $.$as(obj, $.$spxl.System.Xml.Linq.XNode);
                if (n === null && obj !== null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "obj");
                }
                return this.GetHashCode$1(n);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Linq.XNode>.Equals(System.Xml.Linq.XNode?, System.Xml.Linq.XNode?)
            System$Collections$Generic$IEqualityComparer$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Linq.XNode>.GetHashCode(System.Xml.Linq.XNode)
            System$Collections$Generic$IEqualityComparer$$$GetHashCode()
            {
                return this.GetHashCode$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2476460;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"x","p":2279852},{"n":"y","p":2279852}],"n":"Equals","o":"@$2","d":2476460,"h":4297443756,"f":1},{"r":655361,"p":[{"n":"obj","p":2279852}],"n":"GetHashCode","o":"@$1","d":2476460,"h":8592411052,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":2476460,"h":21477312940,"f":1}],"i":[31850497,$.$spc.System.Collections.Generic.IEqualityComparer$$($.$spxl.System.Xml.Linq.XNode).$h],"h":2476460}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IEqualityComparer, $.$spc.System.Collections.Generic.IEqualityComparer$$($.$spxl.System.Xml.Linq.XNode) ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeEqualityComparer`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNodeDocumentOrderComparer", ($self) => class XNodeDocumentOrderComparer extends $.$spc.System.Object
        {
            /*int */ Compare(/*XNode?*/ x, /*XNode?*/ y)
            {
                return $.$spxl.System.Xml.Linq.XNode.CompareDocumentOrder(x, y);
            }
            /*int */ System$Collections$IComparer$Compare(/*object?*/ x, /*object?*/ y)
            {
                /*XNode?*/ let n1 = $.$as(x, $.$spxl.System.Xml.Linq.XNode);
                if (n1 === null && x !== null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "x");
                }
                /*XNode?*/ let n2 = $.$as(y, $.$spxl.System.Xml.Linq.XNode);
                if (n2 === null && y !== null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_MustBeDerivedFrom, $.$spxl.System.Xml.Linq.XNode.$type), "y");
                }
                return this.Compare(n1, n2);
            }
            //Generated interface implemetation for System.Collections.Generic.IComparer<System.Xml.Linq.XNode?>.Compare(System.Xml.Linq.XNode?, System.Xml.Linq.XNode?)
            System$Collections$Generic$IComparer$$$Compare()
            {
                return this.Compare(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2410924;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"x","p":2279852},{"n":"y","p":2279852}],"n":"Compare","d":2410924,"h":4297378220,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":2410924,"h":12887312812,"f":1}],"i":[31457281,$.$spc.System.Collections.Generic.IComparer$$($.$spxl.System.Xml.Linq.XNode).$h],"h":2410924}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IComparer, $.$spc.System.Collections.Generic.IComparer$$($.$spxl.System.Xml.Linq.XNode) ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeDocumentOrderComparer`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.Inserter", ($self) => class Inserter extends $.$spc.System.ValueType
        {
            /*XContainer*/  get _parent() { return this.$getField(0, 4); }
            /*XContainer*/  set _parent(value) { this.$setField(0, 4, value); }
            /*XNode?*/  get _previous() { return this.$getField(4, 4); }
            /*XNode?*/  set _previous(value) { this.$setField(4, 4, value); }
            /*string?*/  get _text() { return this.$getField(8, 4); }
            /*string?*/  set _text(value) { this.$setField(8, 4, value); }
            $ctor$2(/*XContainer*/ parent, /*XNode?*/ anchor)
            {
                super.$ctor$1();
                {
                    this._parent = parent;
                    this._previous = anchor;
                    this._text = null;
                }
                return this;
            }
            /*void */ Add(/*object?*/ content)
            {
                this.AddContent(content);
                if ($.$spc.System.String.op_Inequality(this._text, null))
                {
                    if (this._parent.content === null)
                    {
                        if (this._parent.SkipNotify())
                        {
                            this._parent.content = this._text;
                        }
                        else 
                        {
                            if (this._text.length > 0)
                            {
                                this.InsertNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(this._text));
                            }
                            else 
                            {
                                if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XElement))
                                {
                                    this._parent.NotifyChanging(this._parent, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                                    if (this._parent.content !== null)
                                    {
                                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                                    }
                                    this._parent.content = this._text;
                                    this._parent.NotifyChanged(this._parent, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                                }
                                else 
                                {
                                    this._parent.content = this._text;
                                }
                            }
                        }
                    }
                    else if (this._text.length > 0)
                    {
                        /*XText?*/ let prevXText = $.$as(this._previous, $.$spxl.System.Xml.Linq.XText);
                        if (prevXText !== null && !($.$is(this._previous, $.$spxl.System.Xml.Linq.XCData)))
                        {
                            prevXText.Value += this._text;
                        }
                        else 
                        {
                            this._parent.ConvertTextToNode();
                            this.InsertNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(this._text));
                        }
                    }
                }
            }
            /*void */ AddContent(/*object?*/ content)
            {
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.AddNode(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    this.AddString(s);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$9(x));
                    return;
                }
                /*object?[]?*/ let o = $.$as(content, $.$typeArray($.$spc.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.AddContent(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$spc.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.AddContent(obj);
                        }
                    }
                    return;
                }
                if ($.$is(content, $.$spxl.System.Xml.Linq.XAttribute))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_AddAttribute);
                }
                this.AddString($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            /*void */ AddNode(/*XNode*/ n)
            {
                this._parent.ValidateNode(n, this._previous);
                if (n.parent !== null)
                {
                    n = n.CloneNode();
                }
                else 
                {
                    /*XNode*/ let p = this._parent;
                    while(p.parent !== null)
                    {
                        p = p.parent;
                    }
                    if (n === p)
                    {
                        n = n.CloneNode();
                    }
                }
                this._parent.ConvertTextToNode();
                if ($.$spc.System.String.op_Inequality(this._text, null))
                {
                    if (this._text.length > 0)
                    {
                        /*XText?*/ let prevXText = $.$as(this._previous, $.$spxl.System.Xml.Linq.XText);
                        if (prevXText !== null && !($.$is(this._previous, $.$spxl.System.Xml.Linq.XCData)))
                        {
                            prevXText.Value += this._text;
                        }
                        else 
                        {
                            this.InsertNode(new $.$spxl.System.Xml.Linq.XText().$ctor$3(this._text));
                        }
                    }
                    this._text = null;
                }
                this.InsertNode(n);
            }
            /*void */ AddString(/*string*/ s)
            {
                this._parent.ValidateString(s);
                this._text += s;
            }
            /*void */ InsertNode(/*XNode*/ n)
            {
                /*bool*/ let notify = this._parent.NotifyChanging(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                if (n.parent !== null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                n.parent = this._parent;
                if (this._parent.content === null || $.$is(this._parent.content, $.$spc.System.String))
                {
                    n.next = n;
                    this._parent.content = n;
                }
                else if (this._previous === null)
                {
                    /*XNode*/ let last = $.$cast(this._parent.content, $.$spxl.System.Xml.Linq.XNode);
                    n.next = last.next;
                    last.next = n;
                }
                else 
                {
                    n.next = this._previous.next;
                    this._previous.next = n;
                    if (this._parent.content === this._previous)
                    {
                        this._parent.content = n;
                    }
                }
                this._previous = n;
                if (notify)
                {
                    this._parent.NotifyChanged(n, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                }
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._parent = this._parent;
                copy._previous = this._previous;
                copy._text = this._text;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._parent = null;
                this._previous = null;
                this._text = null;
            }
            static $h = 510380;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"content","p":131073}],"n":"Add","d":510380,"h":21475346860,"f":1},{"r":65537,"p":[{"n":"content","p":131073}],"n":"AddContent","d":510380,"h":25770314156,"f":2},{"r":65537,"p":[{"n":"n","p":2279852}],"n":"AddNode","d":510380,"h":30065281452,"f":2},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AddString","d":510380,"h":34360248748,"f":2},{"r":65537,"p":[{"n":"n","p":2279852}],"n":"InsertNode","d":510380,"h":38655216044,"f":2}],"l":[{"t":1362348,"n":"_parent","d":510380,"h":4295477676,"f":2},{"t":2279852,"n":"_previous","d":510380,"h":8590444972,"f":2},{"t":1310721,"n":"_text","d":510380,"h":12885412268,"f":2}],"c":[{"p":[{"n":"parent","p":1362348},{"n":"anchor","p":2279852}],"n":".ctor","o":"$ctor$2","d":510380,"h":17180379564,"f":1},{"n":".ctor","o":"$ctor$3","d":510380,"h":42950183340,"f":1}],"h":510380}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.Inserter`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.NamespaceCache", ($self) => class NamespaceCache extends $.$spc.System.ValueType
        {
            /*XNamespace*/  get _ns() { return this.$getField(0, 4); }
            /*XNamespace*/  set _ns(value) { this.$setField(0, 4, value); }
            /*string*/  get _namespaceName() { return this.$getField(4, 4); }
            /*string*/  set _namespaceName(value) { this.$setField(4, 4, value); }
            /*XNamespace */ Get(/*string*/ namespaceName)
            {
                if (namespaceName === this._namespaceName)
                {
                    return this._ns;
                }
                this._namespaceName = namespaceName;
                this._ns = $.$spxl.System.Xml.Linq.XNamespace.Get(namespaceName);
                return this._ns;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._ns = this._ns;
                copy._namespaceName = this._namespaceName;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._ns = null;
                this._namespaceName = null;
            }
            static $h = 772524;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":2214316,"p":[{"n":"namespaceName","p":1310721}],"n":"Get","d":772524,"h":12885674412,"f":1}],"l":[{"t":2214316,"n":"_ns","d":772524,"h":4295739820,"f":2},{"t":1310721,"n":"_namespaceName","d":772524,"h":8590707116,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":772524,"h":17180641708,"f":1}],"h":772524}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.NamespaceCache`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.ElementWriter", ($self) => class ElementWriter extends $.$spc.System.ValueType
        {
            /*XmlWriter*/  get _writer() { return this.$getField(0, 4); }
            /*XmlWriter*/  set _writer(value) { this.$setField(0, 4, value); }
            /*NamespaceResolver*/  get _resolver() { return this.$getField(4, 12); }
            /*NamespaceResolver*/  set _resolver(value) { this.$setField(4, 12, value); }
            $ctor$2(/*XmlWriter*/ writer)
            {
                super.$ctor$1();
                {
                    this._writer = writer;
                    this._resolver = new $.$spxl.System.Xml.Linq.NamespaceResolver();
                }
                return this;
            }
            /*void */ WriteElement(/*XElement*/ e)
            {
                this.PushAncestors(e);
                /*XElement*/ let root = e;
                /*XNode*/ let n = e;
                while(true)
                {
                    /*XElement?*/ let current = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                    if (current !== null)
                    {
                        this.WriteStartElement(current);
                        if (current.content === null)
                        {
                            this.WriteEndElement();
                        }
                        else 
                        {
                            /*string?*/ let s = $.$as(current.content, $.$spc.System.String);
                            if ($.$spc.System.String.op_Inequality(s, null))
                            {
                                this._writer.WriteString(s);
                                this.WriteFullEndElement();
                            }
                            else 
                            {
                                n = ($.$cast(current.content, $.$spxl.System.Xml.Linq.XNode)).next;
                                continue;
                            }
                        }
                    }
                    else 
                    {
                        n.WriteTo(this._writer);
                    }
                    while(n !== root && n === n.parent.content)
                    {
                        n = n.parent;
                        this.WriteFullEndElement();
                    }
                    if (n === root)
                    {
                        break;
                    }
                    n = n.next;
                }
            }
            /*Task *//*async*/  WriteElementAsync(/*XElement*/ e, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.PushAncestors(e);
                    /*XElement*/ let root = e;
                    /*XNode*/ let n = e;
                    while(true)
                    {
                        /*XElement?*/ let current = $.$as(n, $.$spxl.System.Xml.Linq.XElement);
                        if (current !== null)
                        {
                            await this.WriteStartElementAsync(current, cancellationToken).ConfigureAwait(false);
                            if (current.content === null)
                            {
                                await this.WriteEndElementAsync(cancellationToken).ConfigureAwait(false);
                            }
                            else 
                            {
                                /*string?*/ let s = $.$as(current.content, $.$spc.System.String);
                                if ($.$spc.System.String.op_Inequality(s, null))
                                {
                                    cancellationToken.ThrowIfCancellationRequested();
                                    await this._writer.WriteStringAsync(s).ConfigureAwait(false);
                                    await this.WriteFullEndElementAsync(cancellationToken).ConfigureAwait(false);
                                }
                                else 
                                {
                                    n = ($.$cast(current.content, $.$spxl.System.Xml.Linq.XNode)).next;
                                    continue;
                                }
                            }
                        }
                        else 
                        {
                            await n.WriteToAsync(this._writer, cancellationToken).ConfigureAwait(false);
                        }
                        while(n !== root && n === n.parent.content)
                        {
                            n = n.parent;
                            await this.WriteFullEndElementAsync(cancellationToken).ConfigureAwait(false);
                        }
                        if (n === root)
                        {
                            break;
                        }
                        n = n.next;
                    }
                });
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns, /*bool*/ allowDefaultNamespace)
            {
                /*string*/ let namespaceName = ns.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$spc.System.String.Empty;
                }
                /*string?*/ let prefix = this._resolver.GetPrefixOfNamespace(ns, allowDefaultNamespace);
                if ($.$spc.System.String.op_Inequality(prefix, null))
                {
                    return prefix;
                }
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    return "xml";
                }
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            /*void */ PushAncestors(/*XElement?*/ e)
            {
                while(true)
                {
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    if (e === null)
                    {
                        break;
                    }
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration)
                            {
                                this._resolver.AddFirst(a.Name.NamespaceName.length === 0 ? $.$spc.System.String.Empty : a.Name.LocalName, $.$spxl.System.Xml.Linq.XNamespace.Get(a.Value));
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
            }
            /*void */ PushElement(/*XElement*/ e)
            {
                this._resolver.PushScope();
                /*XAttribute?*/ let a = e.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if (a.IsNamespaceDeclaration)
                        {
                            this._resolver.Add(a.Name.NamespaceName.length === 0 ? $.$spc.System.String.Empty : a.Name.LocalName, $.$spxl.System.Xml.Linq.XNamespace.Get(a.Value));
                        }
                    }
                    while(a !== e.lastAttr);
                }
            }
            /*void */ WriteEndElement()
            {
                this._writer.WriteEndElement();
                this._resolver.PopScope();
            }
            /*Task *//*async*/  WriteEndElementAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await this._writer.WriteEndElementAsync().ConfigureAwait(false);
                    this._resolver.PopScope();
                });
            }
            /*void */ WriteFullEndElement()
            {
                this._writer.WriteFullEndElement();
                this._resolver.PopScope();
            }
            /*Task *//*async*/  WriteFullEndElementAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await this._writer.WriteFullEndElementAsync().ConfigureAwait(false);
                    this._resolver.PopScope();
                });
            }
            /*void */ WriteStartElement(/*XElement*/ e)
            {
                this.PushElement(e);
                /*XNamespace*/ let ns = e.Name.Namespace;
                this._writer.WriteStartElement$1(this.GetPrefixOfNamespace(ns, true), e.Name.LocalName, ns.NamespaceName);
                /*XAttribute?*/ let a = e.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        ns = a.Name.Namespace;
                        /*string*/ let localName = a.Name.LocalName;
                        /*string*/ let namespaceName = ns.NamespaceName;
                        this._writer.WriteAttributeString$2(this.GetPrefixOfNamespace(ns, false), localName, namespaceName.length === 0 && $.$spc.System.String.op_Equality(localName, "xmlns") ? "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/ : namespaceName, a.Value);
                    }
                    while(a !== e.lastAttr);
                }
            }
            /*Task *//*async*/  WriteStartElementAsync(/*XElement*/ e, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.PushElement(e);
                    /*XNamespace*/ let ns = e.Name.Namespace;
                    await this._writer.WriteStartElementAsync(this.GetPrefixOfNamespace(ns, true), e.Name.LocalName, ns.NamespaceName).ConfigureAwait(false);
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            ns = a.Name.Namespace;
                            /*string*/ let localName = a.Name.LocalName;
                            /*string*/ let namespaceName = ns.NamespaceName;
                            cancellationToken.ThrowIfCancellationRequested();
                            await this._writer.WriteAttributeStringAsync(this.GetPrefixOfNamespace(ns, false), localName, namespaceName.length === 0 && $.$spc.System.String.op_Equality(localName, "xmlns") ? "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/ : namespaceName, a.Value).ConfigureAwait(false);
                        }
                        while(a !== e.lastAttr);
                    }
                });
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._writer = this._writer;
                copy._resolver = this._resolver.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._writer = null;
                this._resolver = $.$default($.$spxl.System.Xml.Linq.NamespaceResolver);
            }
            static $h = 379308;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"e","p":1690028}],"n":"WriteElement","d":379308,"h":17180248492,"f":1},{"r":133300225,"p":[{"n":"e","p":1690028},{"n":"cancellationToken","p":125960193}],"n":"WriteElementAsync","d":379308,"h":21475215788,"f":4097},{"r":1310721,"p":[{"n":"ns","p":2214316},{"n":"allowDefaultNamespace","p":262145}],"n":"GetPrefixOfNamespace","d":379308,"h":25770183084,"f":2},{"r":65537,"p":[{"n":"e","p":1690028}],"n":"PushAncestors","d":379308,"h":30065150380,"f":2},{"r":65537,"p":[{"n":"e","p":1690028}],"n":"PushElement","d":379308,"h":34360117676,"f":2},{"r":65537,"n":"WriteEndElement","d":379308,"h":38655084972,"f":2},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"WriteEndElementAsync","d":379308,"h":42950052268,"f":4098},{"r":65537,"n":"WriteFullEndElement","d":379308,"h":47245019564,"f":2},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"WriteFullEndElementAsync","d":379308,"h":51539986860,"f":4098},{"r":65537,"p":[{"n":"e","p":1690028}],"n":"WriteStartElement","d":379308,"h":55834954156,"f":2},{"r":133300225,"p":[{"n":"e","p":1690028},{"n":"cancellationToken","p":125960193}],"n":"WriteStartElementAsync","d":379308,"h":60129921452,"f":4098}],"l":[{"t":58435741,"n":"_writer","d":379308,"h":4295346604,"f":2},{"t":838060,"n":"_resolver","d":379308,"h":8590313900,"f":2}],"c":[{"p":[{"n":"writer","p":58435741}],"n":".ctor","o":"$ctor$2","d":379308,"h":12885281196,"f":1},{"n":".ctor","o":"$ctor$3","d":379308,"h":64424888748,"f":1}],"h":379308}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.ElementWriter`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.NamespaceResolver", ($self) => class NamespaceResolver extends $.$spc.System.ValueType
        {
            static $_NamespaceDeclaration;
            static get NamespaceDeclaration()
            {
                let $cls = $.$spxl.System.Xml.Linq.NamespaceResolver;
                return $cls.$_NamespaceDeclaration ??= $asm.$ncls("$spxl.System.Xml.Linq.NamespaceResolver.NamespaceDeclaration", ($self) => class NamespaceDeclaration extends $.$spc.System.Object
                {
                    /*string*/ prefix = null;
                    /*XNamespace*/ ns = null;
                    /*int*/ scope = 0;
                    /*NamespaceDeclaration*/ prev = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.prefix = null;
                        this.ns = null;
                        this.prev = null;
                    }
                    static $h = 903596;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"prefix","d":903596,"h":4295870892,"f":1},{"t":2214316,"n":"ns","d":903596,"h":8590838188,"f":1},{"t":655361,"n":"scope","d":903596,"h":12885805484,"f":1},{"t":903596,"n":"prev","d":903596,"h":17180772780,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":903596,"h":21475740076,"f":1}],"d":838060,"h":903596}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Xml.Linq.NamespaceResolver.NamespaceDeclaration`; }
                }, $cls, ($v) => $cls.$_NamespaceDeclaration = $v);
            }
            /*int*/  get _scope() { return this.$getField(0, 4); }
            /*int*/  set _scope(value) { this.$setField(0, 4, value); }
            /*NamespaceDeclaration?*/  get _declaration() { return this.$getField(4, 4); }
            /*NamespaceDeclaration?*/  set _declaration(value) { this.$setField(4, 4, value); }
            /*NamespaceDeclaration?*/  get _rover() { return this.$getField(8, 4); }
            /*NamespaceDeclaration?*/  set _rover(value) { this.$setField(8, 4, value); }
            /*void */ PushScope()
            {
                this._scope++;
            }
            /*void */ PopScope()
            {
                /*NamespaceDeclaration?*/ let d = this._declaration;
                if (d !== null)
                {
                    do
                    {
                        d = d.prev;
                        if (d.scope !== this._scope)
                        {
                            break;
                        }
                        if (d === this._declaration)
                        {
                            this._declaration = null;
                        }
                        else 
                        {
                            this._declaration.prev = d.prev;
                        }
                        this._rover = null;
                    }
                    while(d !== this._declaration && this._declaration !== null);
                }
                this._scope--;
            }
            /*void */ Add(/*string*/ prefix, /*XNamespace*/ ns)
            {
                /*NamespaceDeclaration*/ let d = new $.$spxl.System.Xml.Linq.NamespaceResolver.NamespaceDeclaration().$ctor$1();
                d.prefix = prefix;
                d.ns = ns;
                d.scope = this._scope;
                if (this._declaration === null)
                {
                    this._declaration = d;
                }
                else 
                {
                    d.prev = this._declaration.prev;
                }
                this._declaration.prev = d;
                this._rover = null;
            }
            /*void */ AddFirst(/*string*/ prefix, /*XNamespace*/ ns)
            {
                /*NamespaceDeclaration*/ let d = new $.$spxl.System.Xml.Linq.NamespaceResolver.NamespaceDeclaration().$ctor$1();
                d.prefix = prefix;
                d.ns = ns;
                d.scope = this._scope;
                if (this._declaration === null)
                {
                    d.prev = d;
                }
                else 
                {
                    d.prev = this._declaration.prev;
                    this._declaration.prev = d;
                }
                this._declaration = d;
                this._rover = null;
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns, /*bool*/ allowDefaultNamespace)
            {
                if (this._rover !== null && $.$spxl.System.Xml.Linq.XNamespace.op_Equality(this._rover.ns, ns) && (allowDefaultNamespace || this._rover.prefix.length > 0))
                {
                    return this._rover.prefix;
                }
                /*NamespaceDeclaration?*/ let d = this._declaration;
                if (d !== null)
                {
                    do
                    {
                        d = d.prev;
                        if ($.$spxl.System.Xml.Linq.XNamespace.op_Equality(d.ns, ns))
                        {
                            /*NamespaceDeclaration*/ let x = this._declaration.prev;
                            while(x !== d && $.$spc.System.String.op_Inequality(x.prefix, d.prefix))
                            {
                                x = x.prev;
                            }
                            if (x === d)
                            {
                                if (allowDefaultNamespace)
                                {
                                    this._rover = d;
                                    return d.prefix;
                                }
                                else if (d.prefix.length > 0)
                                {
                                    return d.prefix;
                                }
                            }
                        }
                    }
                    while(d !== this._declaration);
                }
                return null;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._scope = this._scope;
                copy._declaration = this._declaration;
                copy._rover = this._rover;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._scope = 0;
                this._declaration = null;
                this._rover = null;
            }
            static $h = 838060;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"n":"PushScope","d":838060,"h":21475674540,"f":1},{"r":65537,"n":"PopScope","d":838060,"h":25770641836,"f":1},{"r":65537,"p":[{"n":"prefix","p":1310721},{"n":"ns","p":2214316}],"n":"Add","d":838060,"h":30065609132,"f":1},{"r":65537,"p":[{"n":"prefix","p":1310721},{"n":"ns","p":2214316}],"n":"AddFirst","d":838060,"h":34360576428,"f":1},{"r":1310721,"p":[{"n":"ns","p":2214316},{"n":"allowDefaultNamespace","p":262145}],"n":"GetPrefixOfNamespace","d":838060,"h":38655543724,"f":1}],"l":[{"t":655361,"n":"_scope","d":838060,"h":8590772652,"f":2},{"t":903596,"n":"_declaration","d":838060,"h":12885739948,"f":2},{"t":903596,"n":"_rover","d":838060,"h":17180707244,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":838060,"h":42950511020,"f":1}],"j":[903596],"h":838060}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.NamespaceResolver`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.StreamingElementWriter", ($self) => class StreamingElementWriter extends $.$spc.System.ValueType
        {
            /*XmlWriter*/  get _writer() { return this.$getField(0, 4); }
            /*XmlWriter*/  set _writer(value) { this.$setField(0, 4, value); }
            /*XStreamingElement?*/  get _element() { return this.$getField(4, 4); }
            /*XStreamingElement?*/  set _element(value) { this.$setField(4, 4, value); }
            /*List<XAttribute>*/  get _attributes() { return this.$getField(8, 4); }
            /*List<XAttribute>*/  set _attributes(value) { this.$setField(8, 4, value); }
            /*NamespaceResolver*/  get _resolver() { return this.$getField(12, 12); }
            /*NamespaceResolver*/  set _resolver(value) { this.$setField(12, 12, value); }
            $ctor$2(/*XmlWriter*/ w)
            {
                super.$ctor$1();
                {
                    this._writer = w;
                    this._element = null;
                    this._attributes = new ($.$spc.System.Collections.Generic.List$$($.$spxl.System.Xml.Linq.XAttribute))().$ctor$1();
                    this._resolver = new $.$spxl.System.Xml.Linq.NamespaceResolver();
                }
                return this;
            }
            /*void */ FlushElement()
            {
                if (this._element !== null)
                {
                    this.PushElement();
                    /*XNamespace*/ let ns = this._element.Name.Namespace;
                    this._writer.WriteStartElement$1(this.GetPrefixOfNamespace(ns, true), this._element.Name.LocalName, ns.NamespaceName);
                    var $en3 = this._attributes.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var a = $en3.Current;
                        {
                            ns = a.Name.Namespace;
                            /*string*/ let localName = a.Name.LocalName;
                            /*string*/ let namespaceName = ns.NamespaceName;
                            this._writer.WriteAttributeString$2(this.GetPrefixOfNamespace(ns, false), localName, namespaceName.length === 0 && $.$spc.System.String.op_Equality(localName, "xmlns") ? "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/ : namespaceName, a.Value);
                        }
                    }
                    this._element = null;
                    this._attributes.Clear();
                }
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns, /*bool*/ allowDefaultNamespace)
            {
                /*string*/ let namespaceName = ns.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$spc.System.String.Empty;
                }
                /*string?*/ let prefix = this._resolver.GetPrefixOfNamespace(ns, allowDefaultNamespace);
                if ($.$spc.System.String.op_Inequality(prefix, null))
                {
                    return prefix;
                }
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    return "xml";
                }
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            /*void */ PushElement()
            {
                this._resolver.PushScope();
                var $en2 = this._attributes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var a = $en2.Current;
                    {
                        if (a.IsNamespaceDeclaration)
                        {
                            this._resolver.Add(a.Name.NamespaceName.length === 0 ? $.$spc.System.String.Empty : a.Name.LocalName, $.$spxl.System.Xml.Linq.XNamespace.Get(a.Value));
                        }
                    }
                }
            }
            /*void */ Write(/*object?*/ content)
            {
                if (content === null)
                {
                    return;
                }
                /*XNode?*/ let n = $.$as(content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this.WriteNode(n);
                    return;
                }
                /*string?*/ let s = $.$as(content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    this.WriteString(s);
                    return;
                }
                /*XAttribute?*/ let a = $.$as(content, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    this.WriteAttribute(a);
                    return;
                }
                /*XStreamingElement?*/ let x = $.$as(content, $.$spxl.System.Xml.Linq.XStreamingElement);
                if (x !== null)
                {
                    this.WriteStreamingElement(x);
                    return;
                }
                /*object[]?*/ let o = $.$as(content, $.$typeArray($.$spc.System.Object));
                if (o !== null)
                {
                    let $i1 = 0;
                    let $arr1 = o;
                    while ($i1 < $arr1.length)
                    {
                        let obj = $arr1[$i1++];
                        this.Write(obj);
                    }
                    return;
                }
                /*IEnumerable?*/ let e = $.$as(content, $.$spc.System.Collections.IEnumerable);
                if (e !== null)
                {
                    var $en3 = e.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.Write(obj);
                        }
                    }
                    return;
                }
                this.WriteString($.$spxl.System.Xml.Linq.XContainer.GetStringValue(content));
            }
            /*void */ WriteAttribute(/*XAttribute*/ a)
            {
                if (this._element === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_WriteAttribute);
                }
                this._attributes.Add(a);
            }
            /*void */ WriteNode(/*XNode*/ n)
            {
                this.FlushElement();
                n.WriteTo(this._writer);
            }
            /*void */ WriteStreamingElement(/*XStreamingElement*/ e)
            {
                this.FlushElement();
                this._element = e;
                this.Write(e.content);
                this.FlushElement();
                this._writer.WriteEndElement();
                this._resolver.PopScope();
            }
            /*void */ WriteString(/*string*/ s)
            {
                this.FlushElement();
                this._writer.WriteString(s);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._writer = this._writer;
                copy._element = this._element;
                copy._attributes = this._attributes;
                copy._resolver = this._resolver.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._writer = null;
                this._element = null;
                this._attributes = null;
                this._resolver = $.$default($.$spxl.System.Xml.Linq.NamespaceResolver);
            }
            static $h = 1100204;
            static $z = 24;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"n":"FlushElement","d":1100204,"h":25770903980,"f":2},{"r":1310721,"p":[{"n":"ns","p":2214316},{"n":"allowDefaultNamespace","p":262145}],"n":"GetPrefixOfNamespace","d":1100204,"h":30065871276,"f":2},{"r":65537,"n":"PushElement","d":1100204,"h":34360838572,"f":2},{"r":65537,"p":[{"n":"content","p":131073}],"n":"Write","d":1100204,"h":38655805868,"f":2},{"r":65537,"p":[{"n":"a","p":1165740}],"n":"WriteAttribute","d":1100204,"h":42950773164,"f":2},{"r":65537,"p":[{"n":"n","p":2279852}],"n":"WriteNode","d":1100204,"h":47245740460,"f":2},{"r":65537,"p":[{"n":"e","p":2935212}],"n":"WriteStreamingElement","d":1100204,"h":51540707756,"f":8},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"WriteString","d":1100204,"h":55835675052,"f":2}],"l":[{"t":58435741,"n":"_writer","d":1100204,"h":4296067500,"f":2},{"t":2935212,"n":"_element","d":1100204,"h":8591034796,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spxl.System.Xml.Linq.XAttribute).$h,"n":"_attributes","d":1100204,"h":12886002092,"f":2},{"t":838060,"n":"_resolver","d":1100204,"h":17180969388,"f":2}],"c":[{"p":[{"n":"w","p":58435741}],"n":".ctor","o":"$ctor$2","d":1100204,"h":21475936684,"f":1},{"n":".ctor","o":"$ctor$3","d":1100204,"h":60130642348,"f":1}],"h":1100204}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Xml.Linq.StreamingElementWriter`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XAttribute", ($self) => class XAttribute extends $.$spxl.System.Xml.Linq.XObject
        {
            static /*IEnumerable<XAttribute> */ get EmptySequence()
            {
                return $.$spc.System.Array.Empty($.$spxl.System.Xml.Linq.XAttribute);
            }
            /*XAttribute?*/ next = null;
            /*XName*/ name = null;
            /*string*/ value = null;
            $ctor$2(/*XName*/ name, /*object*/ value)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                    /*string*/ let s = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
                    $.$spxl.System.Xml.Linq.XAttribute.ValidateAttribute(name, s);
                    this.name = name;
                    this.value = s;
                }
                return this;
            }
            $ctor$3(/*XAttribute*/ other)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this.name = other.name;
                    this.value = other.value;
                }
                return this;
            }
            /*bool */ get IsNamespaceDeclaration()
            {
                /*string*/ let namespaceName = this.name.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$spc.System.String.op_Equality(this.name.LocalName, "xmlns");
                }
                return namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/;
            }
            /*XName */ get Name()
            {
                return this.name;
            }
            /*XAttribute? */ get NextAttribute()
            {
                return this.parent !== null && ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr !== this ? this.next : null;
            }
            /*XmlNodeType */ get NodeType()
            {
                return 2/*XmlNodeType.Attribute*/;
            }
            /*XAttribute? */ get PreviousAttribute()
            {
                if (this.parent === null)
                {
                    return null;
                }
                /*XAttribute*/ let a = ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr;
                while(a.next !== this)
                {
                    a = a.next;
                }
                return a !== ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr ? a : null;
            }
            /*string */ get Value()
            {
                return this.value;
            }
            /*string */ set Value(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                $.$spxl.System.Xml.Linq.XAttribute.ValidateAttribute(this.name, value);
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.value = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*void */ Remove()
            {
                if (this.parent === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingParent);
                }
                ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).RemoveAttribute(this);
            }
            /*void */ SetValue(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                this.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
            }
            static/*conventional*/ /*string */ ToString()
            {
                let sw = null;
                try
                {
                    sw = new $.$spc.System.IO.StringWriter().$ctor$5($.$spc.System.Globalization.CultureInfo.InvariantCulture);
                    /*XmlWriterSettings*/ let ws = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                    ws.ConformanceLevel = 1/*ConformanceLevel.Fragment*/;
                    let w = null;
                    try
                    {
                        w = $.$spx.System.Xml.XmlWriter.Create$5(sw, ws);
                        w.WriteAttributeString$2(this.GetPrefixOfNamespace(this.name.Namespace), this.name.LocalName, this.name.NamespaceName, this.value);
                    }
                    finally
                    {
                        w?.System$IDisposable$Dispose();
                    }
                    return $.$spc.System.String.Trim.call($.$spc.System.IO.StringWriter.ToString.call(sw));
                }
                finally
                {
                    sw?.System$IDisposable$Dispose();
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$spxl.System.Xml.Linq.XAttribute.ToString.apply(this, arguments); }
            static /*string? */ op_Explicit(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return attribute.value;
            }
            static /*bool */ op_Explicit$1(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$spc.System.String.ToLowerInvariant.call(attribute.value));
            }
            static /*bool? */ op_Explicit$2(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$spc.System.String.ToLowerInvariant.call(attribute.value));
            }
            static /*int */ op_Explicit$3(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToInt32(attribute.value);
            }
            static /*int? */ op_Explicit$4(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt32(attribute.value);
            }
            static /*uint */ op_Explicit$5(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToUInt32(attribute.value);
            }
            static /*uint? */ op_Explicit$6(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt32(attribute.value);
            }
            static /*long */ op_Explicit$7(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToInt64(attribute.value);
            }
            static /*long? */ op_Explicit$8(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt64(attribute.value);
            }
            static /*ulong */ op_Explicit$9(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToUInt64(attribute.value);
            }
            static /*ulong? */ op_Explicit$10(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt64(attribute.value);
            }
            static /*float */ op_Explicit$11(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToSingle(attribute.value);
            }
            static /*float? */ op_Explicit$12(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToSingle(attribute.value);
            }
            static /*double */ op_Explicit$13(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToDouble(attribute.value);
            }
            static /*double? */ op_Explicit$14(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDouble(attribute.value);
            }
            static /*decimal */ op_Explicit$15(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToDecimal(attribute.value);
            }
            static /*decimal? */ op_Explicit$16(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDecimal(attribute.value);
            }
            static /*DateTime */ op_Explicit$17(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spc.System.DateTime.Parse$2(attribute.value, $.$spc.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            static /*DateTime? */ op_Explicit$18(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spc.System.DateTime.Parse$2(attribute.value, $.$spc.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            static /*DateTimeOffset */ op_Explicit$19(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset(attribute.value);
            }
            static /*DateTimeOffset? */ op_Explicit$20(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset(attribute.value);
            }
            static /*TimeSpan */ op_Explicit$21(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(attribute.value);
            }
            static /*TimeSpan? */ op_Explicit$22(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(attribute.value);
            }
            static /*Guid */ op_Explicit$23(/*XAttribute*/ attribute)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attribute, "attribute");
                return $.$spx.System.Xml.XmlConvert.ToGuid(attribute.value);
            }
            static /*Guid? */ op_Explicit$24(/*XAttribute?*/ attribute)
            {
                if (attribute === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToGuid(attribute.value);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$spxl.System.Xml.Linq.XName.GetHashCode.call(this.name) ^ $.$spc.System.String.GetHashCode.call(this.value);
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns)
            {
                /*string*/ let namespaceName = ns.NamespaceName;
                if (namespaceName.length === 0)
                {
                    return $.$spc.System.String.Empty;
                }
                if (this.parent !== null)
                {
                    return ($.$cast(this.parent, $.$spxl.System.Xml.Linq.XElement)).GetPrefixOfNamespace(ns);
                }
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    return "xml";
                }
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            static /*void */ ValidateAttribute(/*XName*/ name, /*string*/ value)
            {
                /*string*/ let namespaceName = name.NamespaceName;
                if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    if (value.length === 0)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_NamespaceDeclarationPrefixed, name.LocalName));
                    }
                    else if ($.$spc.System.String.op_Equality(value, "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/))
                    {
                        if ($.$spc.System.String.op_Inequality(name.LocalName, "xml"))
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_NamespaceDeclarationXml);
                        }
                    }
                    else if ($.$spc.System.String.op_Equality(value, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_NamespaceDeclarationXmlns);
                    }
                    else 
                    {
                        /*string*/ let localName = name.LocalName;
                        if ($.$spc.System.String.op_Equality(localName, "xml"))
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_NamespaceDeclarationXml);
                        }
                        else if ($.$spc.System.String.op_Equality(localName, "xmlns"))
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_NamespaceDeclarationXmlns);
                        }
                    }
                }
                else if (namespaceName.length === 0 && $.$spc.System.String.op_Equality(name.LocalName, "xmlns"))
                {
                    if ($.$spc.System.String.op_Equality(value, "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_NamespaceDeclarationXml);
                    }
                    else if ($.$spc.System.String.op_Equality(value, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_NamespaceDeclarationXmlns);
                    }
                }
            }
            static $h = 1165740;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2607532,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"g":{"r":0,"d":0,"h":8591100332,"f":33},"n":"EmptySequence","d":1165740,"h":4296133036,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":38655871404,"f":1},"n":"IsNamespaceDeclaration","d":1165740,"h":34360904108,"f":1},{"p":2148780,"g":{"r":0,"d":0,"h":47245805996,"f":1},"n":"Name","d":1165740,"h":42950838700,"f":1},{"p":1165740,"g":{"r":0,"d":0,"h":55835740588,"f":1},"n":"NextAttribute","d":1165740,"h":51540773292,"f":1},{"p":52865181,"g":{"r":0,"d":0,"h":64425675180,"f":32769},"n":"NodeType","d":1165740,"h":60130707884,"f":32769},{"p":1165740,"g":{"r":0,"d":0,"h":73015609772,"f":1},"n":"PreviousAttribute","d":1165740,"h":68720642476,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81605544364,"f":1},"s":{"r":0,"d":0,"h":85900511660,"f":1},"n":"Value","d":1165740,"h":77310577068,"f":1}],"m":[{"r":65537,"n":"Remove","d":1165740,"h":90195478956,"f":1},{"r":65537,"p":[{"n":"value","p":131073}],"n":"SetValue","d":1165740,"h":94490446252,"f":1},{"r":1310721,"n":"ToString","d":1165740,"h":98785413548,"f":32769},{"r":655361,"n":"GetDeepHashCode","d":1165740,"h":210454563244,"f":8},{"r":1310721,"p":[{"n":"ns","p":2214316}],"n":"GetPrefixOfNamespace","d":1165740,"h":214749530540,"f":8},{"r":65537,"p":[{"n":"name","p":2148780},{"n":"value","p":1310721}],"n":"ValidateAttribute","d":1165740,"h":219044497836,"f":34}],"l":[{"t":1165740,"n":"next","d":1165740,"h":12886067628,"f":8},{"t":2148780,"n":"name","d":1165740,"h":17181034924,"f":8},{"t":1310721,"n":"value","d":1165740,"h":21476002220,"f":8}],"c":[{"p":[{"n":"name","p":2148780},{"n":"value","p":131073}],"n":".ctor","o":"$ctor$2","d":1165740,"h":25770969516,"f":1},{"p":[{"n":"other","p":1165740}],"n":".ctor","o":"$ctor$3","d":1165740,"h":30065936812,"f":1}],"i":[13936797],"h":1165740,"a":[{"t":1570691,"c":4296537987,"a":[{"v":"MS.Internal.Xml.Linq.ComponentModel.XTypeDescriptionProvider\u00601[[System.Xml.Linq.XAttribute, System.Xml.Linq, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]],System.ComponentModel.TypeConverter","t":1310721}]}]}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XObject; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XAttribute`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNodeBuilder", ($self) => class XNodeBuilder extends $.$spx.System.Xml.XmlWriter
        {
            /*List<object>?*/ _content = null;
            /*XContainer?*/ _parent = null;
            /*XName?*/ _attrName = null;
            /*string?*/ _attrValue = null;
            /*XContainer*/ _root = null;
            $ctor$2(/*XContainer*/ container)
            {
                super.$ctor$1();
                {
                    this._root = container;
                }
                return this;
            }
            /*XmlWriterSettings */ get Settings()
            {
                /*XmlWriterSettings*/ let settings = new $.$spx.System.Xml.XmlWriterSettings().$ctor$1();
                settings.ConformanceLevel = 0/*ConformanceLevel.Auto*/;
                return settings;
            }
            /*WriteState */ get WriteState()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing)
                {
                    this.Close();
                }
            }
            /*void */ Close()
            {
                this._root.Add(this._content);
            }
            /*void */ Flush()
            {
            }
            /*string */ LookupPrefix(/*string*/ namespaceName)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ WriteBase64(/*byte[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$spxl.System.SR.NotSupported_WriteBase64);
            }
            /*void */ WriteCData(/*string?*/ text)
            {
                this.AddNode(new $.$spxl.System.Xml.Linq.XCData().$ctor$6(text));
            }
            /*void */ WriteCharEntity(/*char*/ ch)
            {
                this.AddString($.$spc.System.Char.ToString$2(ch));
            }
            /*void */ WriteChars(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                this.AddString($.$spc.System.String.Create$1(buffer, index, count));
            }
            /*void */ WriteComment(/*string?*/ text)
            {
                this.AddNode(new $.$spxl.System.Xml.Linq.XComment().$ctor$3(text));
            }
            /*void */ WriteDocType(/*string*/ name, /*string?*/ pubid, /*string?*/ sysid, /*string?*/ subset)
            {
                this.AddNode(new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$3(name, pubid, sysid, subset));
            }
            /*void */ WriteEndAttribute()
            {
                /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(this._attrName, this._attrValue);
                this._attrName = null;
                this._attrValue = null;
                if (this._parent !== null)
                {
                    this._parent.Add(a);
                }
                else 
                {
                    this.Add(a);
                }
            }
            /*void */ WriteEndDocument()
            {
            }
            /*void */ WriteEndElement()
            {
                this._parent = ($.$cast(this._parent, $.$spxl.System.Xml.Linq.XElement)).parent;
            }
            /*void */ WriteEntityRef(/*string*/ name)
            {
                switch(name)
                {
                    case "amp":
                    this.AddString("&");
                    break;
                    case "apos":
                    this.AddString("'");
                    break;
                    case "gt":
                    this.AddString(">");
                    break;
                    case "lt":
                    this.AddString("<");
                    break;
                    case "quot":
                    this.AddString("\"");
                    break;
                    default:
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$spxl.System.SR.NotSupported_WriteEntityRef);
                }
            }
            /*void */ WriteFullEndElement()
            {
                /*XElement*/ let e = $.$cast(this._parent, $.$spxl.System.Xml.Linq.XElement);
                if (e.IsEmpty)
                {
                    e.Add($.$spc.System.String.Empty);
                }
                this._parent = e.parent;
            }
            /*void */ WriteProcessingInstruction(/*string*/ name, /*string?*/ text)
            {
                if ($.$spc.System.String.op_Equality(name, "xml"))
                {
                    return;
                }
                this.AddNode(new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$3(name, text));
            }
            /*void */ WriteRaw(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                this.AddString($.$spc.System.String.Create$1(buffer, index, count));
            }
            /*void */ WriteRaw$1(/*string*/ data)
            {
                this.AddString(data);
            }
            /*void */ WriteStartAttribute$1(/*string?*/ prefix, /*string*/ localName, /*string?*/ namespaceName)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(prefix, "prefix");
                this._attrName = $.$spxl.System.Xml.Linq.XNamespace.Get(prefix.length === 0 ? $.$spc.System.String.Empty : namespaceName).GetName(localName);
                this._attrValue = $.$spc.System.String.Empty;
            }
            /*void */ WriteStartDocument()
            {
            }
            /*void */ WriteStartDocument$1(/*bool*/ standalone)
            {
            }
            /*void */ WriteStartElement$1(/*string?*/ prefix, /*string*/ localName, /*string?*/ namespaceName)
            {
                this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$5($.$spxl.System.Xml.Linq.XNamespace.Get(namespaceName).GetName(localName)));
            }
            /*void */ WriteString(/*string?*/ text)
            {
                this.AddString(text);
            }
            /*void */ WriteSurrogateCharEntity(/*char*/ lowCh, /*char*/ highCh)
            {
                this.AddString($.$spc.System.String.Create($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), [highCh, lowCh], null, null))));
            }
            /*void */ WriteValue$4(/*DateTimeOffset*/ value)
            {
                this.WriteString($.$spx.System.Xml.XmlConvert.ToString$18(value));
            }
            /*void */ WriteWhitespace(/*string?*/ ws)
            {
                this.AddString(ws);
            }
            /*void */ Add(/*object*/ o)
            {
                this._content ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Object))().$ctor$1();
                this._content.Add(o);
            }
            /*void */ AddNode(/*XNode*/ n)
            {
                if (this._parent !== null)
                {
                    this._parent.Add(n);
                }
                else 
                {
                    this.Add(n);
                }
                /*XContainer?*/ let c = $.$as(n, $.$spxl.System.Xml.Linq.XContainer);
                if (c !== null)
                {
                    this._parent = c;
                }
            }
            /*void */ AddString(/*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                if ($.$spc.System.String.op_Inequality(this._attrValue, null))
                {
                    this._attrValue += s;
                }
                else if (this._parent !== null)
                {
                    this._parent.Add(s);
                }
                else 
                {
                    this.Add(s);
                }
            }
            static $h = 2345388;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":58435741,"p":[{"p":58501277,"g":{"r":0,"d":0,"h":34362083756,"f":32769},"n":"Settings","d":2345388,"h":30067116460,"f":32769},{"p":48605341,"g":{"r":0,"d":0,"h":42952018348,"f":32769},"n":"WriteState","d":2345388,"h":38657051052,"f":32769}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":2345388,"h":47246985644,"f":32772},{"r":65537,"n":"Close","d":2345388,"h":51541952940,"f":32769},{"r":65537,"n":"Flush","d":2345388,"h":55836920236,"f":32769},{"r":1310721,"p":[{"n":"namespaceName","p":1310721}],"n":"LookupPrefix","d":2345388,"h":60131887532,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"WriteBase64","d":2345388,"h":64426854828,"f":32769},{"r":65537,"p":[{"n":"text","p":1310721}],"n":"WriteCData","d":2345388,"h":68721822124,"f":32769},{"r":65537,"p":[{"n":"ch","p":458753}],"n":"WriteCharEntity","d":2345388,"h":73016789420,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"WriteChars","d":2345388,"h":77311756716,"f":32769},{"r":65537,"p":[{"n":"text","p":1310721}],"n":"WriteComment","d":2345388,"h":81606724012,"f":32769},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"pubid","p":1310721},{"n":"sysid","p":1310721},{"n":"subset","p":1310721}],"n":"WriteDocType","d":2345388,"h":85901691308,"f":32769},{"r":65537,"n":"WriteEndAttribute","d":2345388,"h":90196658604,"f":32769},{"r":65537,"n":"WriteEndDocument","d":2345388,"h":94491625900,"f":32769},{"r":65537,"n":"WriteEndElement","d":2345388,"h":98786593196,"f":32769},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"WriteEntityRef","d":2345388,"h":103081560492,"f":32769},{"r":65537,"n":"WriteFullEndElement","d":2345388,"h":107376527788,"f":32769},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"text","p":1310721}],"n":"WriteProcessingInstruction","d":2345388,"h":111671495084,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"WriteRaw","d":2345388,"h":115966462380,"f":32769},{"r":65537,"p":[{"n":"data","p":1310721}],"n":"WriteRaw","o":"@$1","d":2345388,"h":120261429676,"f":32769},{"r":65537,"p":[{"n":"prefix","p":1310721},{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"WriteStartAttribute","o":"@$1","d":2345388,"h":124556396972,"f":32769},{"r":65537,"n":"WriteStartDocument","d":2345388,"h":128851364268,"f":32769},{"r":65537,"p":[{"n":"standalone","p":262145}],"n":"WriteStartDocument","o":"@$1","d":2345388,"h":133146331564,"f":32769},{"r":65537,"p":[{"n":"prefix","p":1310721},{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"WriteStartElement","o":"@$1","d":2345388,"h":137441298860,"f":32769},{"r":65537,"p":[{"n":"text","p":1310721}],"n":"WriteString","d":2345388,"h":141736266156,"f":32769},{"r":65537,"p":[{"n":"lowCh","p":458753},{"n":"highCh","p":458753}],"n":"WriteSurrogateCharEntity","d":2345388,"h":146031233452,"f":32769},{"r":65537,"p":[{"n":"value","p":34406401}],"n":"WriteValue","o":"@$4","d":2345388,"h":150326200748,"f":32769},{"r":65537,"p":[{"n":"ws","p":1310721}],"n":"WriteWhitespace","d":2345388,"h":154621168044,"f":32769},{"r":65537,"p":[{"n":"o","p":131073}],"n":"Add","d":2345388,"h":158916135340,"f":2},{"r":65537,"p":[{"n":"n","p":2279852}],"n":"AddNode","d":2345388,"h":163211102636,"f":2},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AddString","d":2345388,"h":167506069932,"f":2}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.Object).$h,"n":"_content","d":2345388,"h":4297312684,"f":2},{"t":1362348,"n":"_parent","d":2345388,"h":8592279980,"f":2},{"t":2148780,"n":"_attrName","d":2345388,"h":12887247276,"f":2},{"t":1310721,"n":"_attrValue","d":2345388,"h":17182214572,"f":2},{"t":1362348,"n":"_root","d":2345388,"h":21477181868,"f":2}],"c":[{"p":[{"n":"container","p":1362348}],"n":".ctor","o":"$ctor$2","d":2345388,"h":25772149164,"f":1}],"i":[57540609,56950785],"h":2345388}; }
            static get $b() { return $.$spx.System.Xml.XmlWriter; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeBuilder`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XNodeReader", ($self) => class XNodeReader extends $.$spx.System.Xml.XmlReader
        {
            /*object*/ _source = null;
            /*object?*/ _parent = null;
            /*ReadState*/ _state = 0;
            /*XNode*/ _root = null;
            /*XmlNameTable*/ _nameTable = null;
            /*bool*/ _omitDuplicateNamespaces = false;
            $ctor$2(/*XNode*/ node, /*XmlNameTable?*/ nameTable, /*ReaderOptions*/ options)
            {
                super.$ctor$1();
                {
                    this._source = node;
                    this._root = node;
                    this._nameTable = nameTable ?? $.$spxl.System.Xml.Linq.XNodeReader.CreateNameTable();
                    this._omitDuplicateNamespaces = (options & 1/*ReaderOptions.OmitDuplicateNamespaces*/) !== 0 ? true : false;
                }
                return this;
            }
            $ctor$3(/*XNode*/ node, /*XmlNameTable?*/ nameTable)
            {
                this.$ctor$2(node, nameTable, (node.GetSaveOptionsFromAnnotations() & 2/*SaveOptions.OmitDuplicateNamespaces*/) !== 0 ? 1/*ReaderOptions.OmitDuplicateNamespaces*/ : 0/*ReaderOptions.None*/);
                {
                }
                return this;
            }
            /*int */ get AttributeCount()
            {
                if (!this.IsInteractive)
                {
                    return 0;
                }
                /*int*/ let count = 0;
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (!this._omitDuplicateNamespaces || !this.IsDuplicateNamespaceAttribute(a))
                            {
                                count++;
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return count;
            }
            /*string */ get BaseURI()
            {
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return o.BaseUri;
                }
                o = $.$as(this._parent, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return o.BaseUri;
                }
                return $.$spc.System.String.Empty;
            }
            /*int */ get Depth()
            {
                if (!this.IsInteractive)
                {
                    return 0;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return $.$spxl.System.Xml.Linq.XNodeReader.GetDepth(o);
                }
                o = $.$as(this._parent, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    return (($.$spxl.System.Xml.Linq.XNodeReader.GetDepth(o) + 1) | 0);
                }
                return 0;
            }
            static /*int */ GetDepth(/*XObject*/ o)
            {
                /*int*/ let depth = 0;
                while(o.parent !== null)
                {
                    depth++;
                    o = o.parent;
                }
                if ($.$is(o, $.$spxl.System.Xml.Linq.XDocument))
                {
                    depth--;
                }
                return depth;
            }
            /*bool */ get EOF()
            {
                return this._state === 3/*ReadState.EndOfFile*/;
            }
            /*bool */ get HasAttributes()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null && e.lastAttr !== null)
                {
                    if (this._omitDuplicateNamespaces)
                    {
                        return this.GetFirstNonDuplicateNamespaceAttribute(e.lastAttr.next) !== null;
                    }
                    else 
                    {
                        return true;
                    }
                }
                else 
                {
                    return false;
                }
            }
            /*bool */ get HasValue()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    let $switch1 = o.NodeType;
                    switch($switch1)
                    {
                        case 2/*XmlNodeType.Attribute*/:
                        case 3/*XmlNodeType.Text*/:
                        case 4/*XmlNodeType.CDATA*/:
                        case 8/*XmlNodeType.Comment*/:
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        case 10/*XmlNodeType.DocumentType*/:
                        return true;
                        default:
                        return false;
                    }
                }
                return true;
            }
            /*bool */ get IsEmptyElement()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                return e !== null && e.IsEmpty;
            }
            /*string */ get LocalName()
            {
                return this._nameTable.Add$1(this.GetLocalName());
            }
            /*string */ GetLocalName()
            {
                if (!this.IsInteractive)
                {
                    return $.$spc.System.String.Empty;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.LocalName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return a.Name.LocalName;
                }
                /*XProcessingInstruction?*/ let p = $.$as(this._source, $.$spxl.System.Xml.Linq.XProcessingInstruction);
                if (p !== null)
                {
                    return p.Target;
                }
                /*XDocumentType?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XDocumentType);
                if (n !== null)
                {
                    return n.Name;
                }
                return $.$spc.System.String.Empty;
            }
            /*string */ get Name()
            {
                /*string*/ let prefix = this.GetPrefix();
                if (prefix.length === 0)
                {
                    return this._nameTable.Add$1(this.GetLocalName());
                }
                return this._nameTable.Add$1($.$spc.System.String.Concat$8(prefix, ":", this.GetLocalName()));
            }
            /*string */ get NamespaceURI()
            {
                return this._nameTable.Add$1(this.GetNamespaceURI());
            }
            /*string */ GetNamespaceURI()
            {
                if (!this.IsInteractive)
                {
                    return $.$spc.System.String.Empty;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.NamespaceName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    /*string*/ let namespaceName = a.Name.NamespaceName;
                    if (namespaceName.length === 0 && $.$spc.System.String.op_Equality(a.Name.LocalName, "xmlns"))
                    {
                        return "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/;
                    }
                    return namespaceName;
                }
                return $.$spc.System.String.Empty;
            }
            /*XmlNameTable */ get NameTable()
            {
                return this._nameTable;
            }
            /*XmlNodeType */ get NodeType()
            {
                if (!this.IsInteractive)
                {
                    return 0/*XmlNodeType.None*/;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    if (this.IsEndElement)
                    {
                        return 15/*XmlNodeType.EndElement*/;
                    }
                    /*XmlNodeType*/ let nt = o.NodeType;
                    if (nt !== 3/*XmlNodeType.Text*/)
                    {
                        return nt;
                    }
                    if (o.parent !== null && o.parent.parent === null && $.$is(o.parent, $.$spxl.System.Xml.Linq.XDocument))
                    {
                        return 13/*XmlNodeType.Whitespace*/;
                    }
                    return 3/*XmlNodeType.Text*/;
                }
                if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XDocument))
                {
                    return 13/*XmlNodeType.Whitespace*/;
                }
                return 3/*XmlNodeType.Text*/;
            }
            /*string */ get Prefix()
            {
                return this._nameTable.Add$1(this.GetPrefix());
            }
            /*string */ GetPrefix()
            {
                if (!this.IsInteractive)
                {
                    return $.$spc.System.String.Empty;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    /*string?*/ let prefix = e.GetPrefixOfNamespace(e.Name.Namespace);
                    if ($.$spc.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                    return $.$spc.System.String.Empty;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    /*string?*/ let prefix = a.GetPrefixOfNamespace(a.Name.Namespace);
                    if ($.$spc.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                }
                return $.$spc.System.String.Empty;
            }
            /*ReadState */ get ReadState()
            {
                return this._state;
            }
            /*XmlReaderSettings */ get Settings()
            {
                /*XmlReaderSettings*/ let settings = new $.$spx.System.Xml.XmlReaderSettings().$ctor$1();
                settings.CheckCharacters = false;
                return settings;
            }
            /*string */ get Value()
            {
                if (!this.IsInteractive)
                {
                    return $.$spc.System.String.Empty;
                }
                /*XObject?*/ let o = $.$as(this._source, $.$spxl.System.Xml.Linq.XObject);
                if (o !== null)
                {
                    let $switch1 = o.NodeType;
                    switch($switch1)
                    {
                        case 2/*XmlNodeType.Attribute*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XAttribute)).Value;
                        case 3/*XmlNodeType.Text*/:
                        case 4/*XmlNodeType.CDATA*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XText)).Value;
                        case 8/*XmlNodeType.Comment*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XComment)).Value;
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XProcessingInstruction)).Data;
                        case 10/*XmlNodeType.DocumentType*/:
                        return ($.$cast(o, $.$spxl.System.Xml.Linq.XDocumentType)).InternalSubset ?? $.$spc.System.String.Empty;
                        default:
                        return $.$spc.System.String.Empty;
                    }
                }
                return $.$cast(this._source, $.$spc.System.String);
            }
            /*string */ get XmlLang()
            {
                if (!this.IsInteractive)
                {
                    return $.$spc.System.String.Empty;
                }
                /*XElement?*/ let e = this.GetElementInScope();
                if (e !== null)
                {
                    /*XName*/ let name = $.$spxl.System.Xml.Linq.XNamespace.Xml.GetName("lang");
                    do
                    {
                        /*XAttribute?*/ let a = e.Attribute(name);
                        if (a !== null)
                        {
                            return a.Value;
                        }
                        e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    }
                    while(e !== null);
                }
                return $.$spc.System.String.Empty;
            }
            /*XmlSpace */ get XmlSpace()
            {
                if (!this.IsInteractive)
                {
                    return 0/*XmlSpace.None*/;
                }
                /*XElement?*/ let e = this.GetElementInScope();
                if (e !== null)
                {
                    /*XName*/ let name = $.$spxl.System.Xml.Linq.XNamespace.Xml.GetName("space");
                    do
                    {
                        /*XAttribute?*/ let a = e.Attribute(name);
                        if (a !== null)
                        {
                            let $switch1 = $.$spc.System.MemoryExtensions.Trim$12($.$spc.System.MemoryExtensions.AsSpan$3(a.Value), $.$spc.System.String.op_Implicit(" \t\n\r"));
                            switch($switch1)
                            {
                                case "preserve":
                                return 2/*XmlSpace.Preserve*/;
                                case $.$default():
                                return 1/*XmlSpace.Default*/;
                                default:
                                break;
                            }
                        }
                        e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                    }
                    while(e !== null);
                }
                return 0/*XmlSpace.None*/;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing && this.ReadState !== 4/*ReadState.Closed*/)
                {
                    this.Close();
                }
            }
            /*void */ Close()
            {
                this._source = null;
                this._parent = null;
                this._root = null;
                this._state = 4/*ReadState.Closed*/;
            }
            /*string? */ GetAttribute(/*string*/ name)
            {
                if (!this.IsInteractive)
                {
                    return null;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*string?*/ let localName, namespaceName;
                    $.$spxl.System.Xml.Linq.XNodeReader.GetNameInAttributeScope(name, e, $.$ref(() => localName, ($v) => localName = $v, $.$spc.System.String), $.$ref(() => namespaceName, ($v) => namespaceName = $v, $.$spc.System.String));
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$spc.System.String.op_Equality(a.Name.LocalName, localName) && $.$spc.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return null;
                                }
                                else 
                                {
                                    return a.Value;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                    return null;
                }
                /*XDocumentType?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XDocumentType);
                if (n !== null)
                {
                    switch(name)
                    {
                        case "PUBLIC":
                        return n.PublicId;
                        case "SYSTEM":
                        return n.SystemId;
                    }
                }
                return null;
            }
            /*string? */ GetAttribute$1(/*string*/ localName, /*string?*/ namespaceName)
            {
                if (!this.IsInteractive)
                {
                    return null;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    if ($.$spc.System.String.op_Equality(localName, "xmlns"))
                    {
                        if ($.$spc.System.String.op_Inequality(namespaceName, null) && namespaceName.length === 0)
                        {
                            return null;
                        }
                        if ($.$spc.System.String.op_Equality(namespaceName, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                        {
                            namespaceName = $.$spc.System.String.Empty;
                        }
                    }
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$spc.System.String.op_Equality(a.Name.LocalName, localName) && $.$spc.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return null;
                                }
                                else 
                                {
                                    return a.Value;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return null;
            }
            /*string */ GetAttribute$2(/*int*/ index)
            {
                if (!this.IsInteractive)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (!this._omitDuplicateNamespaces || !this.IsDuplicateNamespaceAttribute(a))
                            {
                                if (index-- === 0)
                                {
                                    return a.Value;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("index");
            }
            /*string? */ LookupNamespace(/*string*/ prefix)
            {
                if (!this.IsInteractive)
                {
                    return null;
                }
                if ($.$spc.System.String.op_Equality(prefix, null))
                {
                    return null;
                }
                /*XElement?*/ let e = this.GetElementInScope();
                if (e !== null)
                {
                    /*XNamespace?*/ let ns = prefix.length === 0 ? e.GetDefaultNamespace() : e.GetNamespaceOfPrefix(prefix);
                    if ($.$spxl.System.Xml.Linq.XNamespace.op_Inequality(ns, null))
                    {
                        return this._nameTable.Add$1(ns.NamespaceName);
                    }
                }
                return null;
            }
            /*bool */ MoveToAttribute(/*string*/ name)
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*string?*/ let localName, namespaceName;
                    $.$spxl.System.Xml.Linq.XNodeReader.GetNameInAttributeScope(name, e, $.$ref(() => localName, ($v) => localName = $v, $.$spc.System.String), $.$ref(() => namespaceName, ($v) => namespaceName = $v, $.$spc.System.String));
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$spc.System.String.op_Equality(a.Name.LocalName, localName) && $.$spc.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return false;
                                }
                                else 
                                {
                                    this._source = a;
                                    this._parent = null;
                                    return true;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return false;
            }
            /*bool */ MoveToAttribute$1(/*string*/ localName, /*string?*/ namespaceName)
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    if ($.$spc.System.String.op_Equality(localName, "xmlns"))
                    {
                        if ($.$spc.System.String.op_Inequality(namespaceName, null) && namespaceName.length === 0)
                        {
                            return false;
                        }
                        if ($.$spc.System.String.op_Equality(namespaceName, "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/))
                        {
                            namespaceName = $.$spc.System.String.Empty;
                        }
                    }
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$spc.System.String.op_Equality(a.Name.LocalName, localName) && $.$spc.System.String.op_Equality(a.Name.NamespaceName, namespaceName))
                            {
                                if (this._omitDuplicateNamespaces && this.IsDuplicateNamespaceAttribute(a))
                                {
                                    return false;
                                }
                                else 
                                {
                                    this._source = a;
                                    this._parent = null;
                                    return true;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                return false;
            }
            /*void */ MoveToAttribute$2(/*int*/ index)
            {
                if (!this.IsInteractive)
                {
                    return;
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (!this._omitDuplicateNamespaces || !this.IsDuplicateNamespaceAttribute(a))
                            {
                                if (index-- === 0)
                                {
                                    this._source = a;
                                    this._parent = null;
                                    return;
                                }
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                }
                throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("index");
            }
            /*bool */ MoveToElement()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute) ?? $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (a.parent !== null)
                    {
                        this._source = a.parent;
                        this._parent = null;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToFirstAttribute()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = this.GetElementInAttributeScope();
                if (e !== null)
                {
                    if (e.lastAttr !== null)
                    {
                        if (this._omitDuplicateNamespaces)
                        {
                            /*object?*/ let na = this.GetFirstNonDuplicateNamespaceAttribute(e.lastAttr.next);
                            if (na === null)
                            {
                                return false;
                            }
                            this._source = na;
                        }
                        else 
                        {
                            this._source = e.lastAttr.next;
                        }
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToNextAttribute()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (this.IsEndElement)
                    {
                        return false;
                    }
                    if (e.lastAttr !== null)
                    {
                        if (this._omitDuplicateNamespaces)
                        {
                            /*object?*/ let na = this.GetFirstNonDuplicateNamespaceAttribute(e.lastAttr.next);
                            if (na === null)
                            {
                                return false;
                            }
                            this._source = na;
                        }
                        else 
                        {
                            this._source = e.lastAttr.next;
                        }
                        return true;
                    }
                    return false;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute) ?? $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (a.parent !== null && ($.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement)).lastAttr !== a)
                    {
                        if (this._omitDuplicateNamespaces)
                        {
                            /*object?*/ let na = this.GetFirstNonDuplicateNamespaceAttribute(a.next);
                            if (na === null)
                            {
                                return false;
                            }
                            this._source = na;
                        }
                        else 
                        {
                            this._source = a.next;
                        }
                        this._parent = null;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ Read()
            {
                switch(this._state)
                {
                    case 0/*ReadState.Initial*/:
                    this._state = 1/*ReadState.Interactive*/;
                    /*XDocument?*/ let d = $.$as(this._source, $.$spxl.System.Xml.Linq.XDocument);
                    if (d !== null)
                    {
                        return this.ReadIntoDocument(d);
                    }
                    return true;
                    case 1/*ReadState.Interactive*/:
                    return this.Read$1(false);
                    default:
                    return false;
                }
            }
            /*bool */ ReadAttributeValue()
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return this.ReadIntoAttribute(a);
                }
                return false;
            }
            /*bool */ ReadToDescendant$1(/*string*/ localName, /*string*/ namespaceName)
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                this.MoveToElement();
                /*XElement?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (c !== null && !c.IsEmpty)
                {
                    if (this.IsEndElement)
                    {
                        return false;
                    }
                    var $en3 = c.Descendants().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var e = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spc.System.String.op_Equality(e.Name.LocalName, localName) && $.$spc.System.String.op_Equality(e.Name.NamespaceName, namespaceName))
                            {
                                this._source = e;
                                return true;
                            }
                        }
                    }
                    this.IsEndElement = true;
                }
                return false;
            }
            /*bool */ ReadToFollowing$1(/*string*/ localName, /*string*/ namespaceName)
            {
                while(this.Read())
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        if (this.IsEndElement)
                        {
                            continue;
                        }
                        if ($.$spc.System.String.op_Equality(e.Name.LocalName, localName) && $.$spc.System.String.op_Equality(e.Name.NamespaceName, namespaceName))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*bool */ ReadToNextSibling$1(/*string*/ localName, /*string*/ namespaceName)
            {
                if (!this.IsInteractive)
                {
                    return false;
                }
                this.MoveToElement();
                if (this._source !== this._root)
                {
                    /*XNode?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                    if (n !== null)
                    {
                        var $en4 = n.ElementsAfterSelf().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var e = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if ($.$spc.System.String.op_Equality(e.Name.LocalName, localName) && $.$spc.System.String.op_Equality(e.Name.NamespaceName, namespaceName))
                                {
                                    this._source = e;
                                    this.IsEndElement = false;
                                    return true;
                                }
                            }
                        }
                        if ($.$is(n.parent, $.$spxl.System.Xml.Linq.XElement))
                        {
                            this._source = n.parent;
                            this.IsEndElement = true;
                            return false;
                        }
                    }
                    else 
                    {
                        if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XElement))
                        {
                            this._source = this._parent;
                            this._parent = null;
                            this.IsEndElement = true;
                            return false;
                        }
                    }
                }
                return this.ReadToEnd();
            }
            /*void */ ResolveEntity()
            {
            }
            /*void */ Skip()
            {
                if (!this.IsInteractive)
                {
                    return;
                }
                this.Read$1(true);
            }
            /*bool */ System$Xml$IXmlLineInfo$HasLineInfo()
            {
                if (this.IsEndElement)
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        return e.Annotation$1($.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation) !== null;
                    }
                }
                else 
                {
                    /*IXmlLineInfo?*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null)
                    {
                        return li.System$Xml$IXmlLineInfo$HasLineInfo();
                    }
                }
                return false;
            }
            /*int */ get System$Xml$IXmlLineInfo$LineNumber()
            {
                if (this.IsEndElement)
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        /*LineInfoEndElementAnnotation?*/ let a = e.Annotation$1($.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation);
                        if (a !== null)
                        {
                            return a.lineNumber;
                        }
                    }
                }
                else 
                {
                    /*IXmlLineInfo?*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null)
                    {
                        return li.System$Xml$IXmlLineInfo$LineNumber;
                    }
                }
                return 0;
            }
            /*int */ get System$Xml$IXmlLineInfo$LinePosition()
            {
                if (this.IsEndElement)
                {
                    /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        /*LineInfoEndElementAnnotation?*/ let a = e.Annotation$1($.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation);
                        if (a !== null)
                        {
                            return a.linePosition;
                        }
                    }
                }
                else 
                {
                    /*IXmlLineInfo?*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null)
                    {
                        return li.System$Xml$IXmlLineInfo$LinePosition;
                    }
                }
                return 0;
            }
            /*bool */ get IsEndElement()
            {
                return this._parent === this._source;
            }
            /*bool */ set IsEndElement(value)
            {
                this._parent = value ? this._source : null;
            }
            /*bool */ get IsInteractive()
            {
                return this._state === 1/*ReadState.Interactive*/;
            }
            static /*NameTable */ CreateNameTable()
            {
                /*var*/ let nameTable = new $.$spx.System.Xml.NameTable().$ctor$2();
                nameTable.Add$1($.$spc.System.String.Empty);
                nameTable.Add$1("http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/);
                nameTable.Add$1("http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/);
                return nameTable;
            }
            /*XElement? */ GetElementInAttributeScope()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (this.IsEndElement)
                    {
                        return null;
                    }
                    return e;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                a = $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return null;
            }
            /*XElement? */ GetElementInScope()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e;
                }
                /*XNode?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    return $.$as(n.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                e = $.$as(this._parent, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e;
                }
                a = $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return null;
            }
            static /*void */ GetNameInAttributeScope(/*string?*/ qualifiedName, /*XElement*/ e, /*out string?*/ localName, /*out string?*/ namespaceName)
            {
                if (!$.$spc.System.String.IsNullOrEmpty(qualifiedName))
                {
                    /*int*/ let i = $.$spc.System.String.IndexOf.call(qualifiedName, /*:*/ 58);
                    if (i !== 0 && i !== ((qualifiedName.length - 1) | 0))
                    {
                        if (i === -1)
                        {
                            localName.$v = qualifiedName;
                            namespaceName.$v = $.$spc.System.String.Empty;
                            return;
                        }
                        /*XNamespace?*/ let ns = e.GetNamespaceOfPrefix($.$spc.System.String.Substring$1.call(qualifiedName, 0, i));
                        if ($.$spxl.System.Xml.Linq.XNamespace.op_Inequality(ns, null))
                        {
                            localName.$v = $.$spc.System.String.Substring.call(qualifiedName, ((i + 1) | 0));
                            namespaceName.$v = ns.NamespaceName;
                            return;
                        }
                    }
                }
                localName.$v = null;
                namespaceName.$v = null;
            }
            /*bool */ Read$1(/*bool*/ skipContent)
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (e.IsEmpty || this.IsEndElement || skipContent)
                    {
                        return this.ReadOverNode(e);
                    }
                    return this.ReadIntoElement(e);
                }
                /*XNode?*/ let n = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    return this.ReadOverNode(n);
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    return this.ReadOverAttribute(a, skipContent);
                }
                return this.ReadOverText(skipContent);
            }
            /*bool */ ReadIntoDocument(/*XDocument*/ d)
            {
                /*XNode?*/ let n = $.$as(d.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this._source = n.next;
                    return true;
                }
                /*string?*/ let s = $.$as(d.content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    if (s.length > 0)
                    {
                        this._source = s;
                        this._parent = d;
                        return true;
                    }
                }
                return this.ReadToEnd();
            }
            /*bool */ ReadIntoElement(/*XElement*/ e)
            {
                /*XNode?*/ let n = $.$as(e.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    this._source = n.next;
                    return true;
                }
                /*string?*/ let s = $.$as(e.content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    if (s.length > 0)
                    {
                        this._source = s;
                        this._parent = e;
                    }
                    else 
                    {
                        this._source = e;
                        this.IsEndElement = true;
                    }
                    return true;
                }
                return this.ReadToEnd();
            }
            /*bool */ ReadIntoAttribute(/*XAttribute*/ a)
            {
                this._source = a.value;
                this._parent = a;
                return true;
            }
            /*bool */ ReadOverAttribute(/*XAttribute*/ a, /*bool*/ skipContent)
            {
                /*XElement?*/ let e = $.$cast(a.parent, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if (e.IsEmpty || skipContent)
                    {
                        return this.ReadOverNode(e);
                    }
                    return this.ReadIntoElement(e);
                }
                return this.ReadToEnd();
            }
            /*bool */ ReadOverNode(/*XNode*/ n)
            {
                if (n === this._root)
                {
                    return this.ReadToEnd();
                }
                /*XNode?*/ let next = n.next;
                if (null === next || next === n || n === n.parent.content)
                {
                    if (n.parent === null || (n.parent.parent === null && $.$is(n.parent, $.$spxl.System.Xml.Linq.XDocument)))
                    {
                        return this.ReadToEnd();
                    }
                    this._source = n.parent;
                    this.IsEndElement = true;
                }
                else 
                {
                    this._source = next;
                    this.IsEndElement = false;
                }
                return true;
            }
            /*bool */ ReadOverText(/*bool*/ skipContent)
            {
                if ($.$is(this._parent, $.$spxl.System.Xml.Linq.XElement))
                {
                    this._source = this._parent;
                    this._parent = null;
                    this.IsEndElement = true;
                    return true;
                }
                /*XAttribute?*/ let parent = $.$as(this._parent, $.$spxl.System.Xml.Linq.XAttribute);
                if (parent !== null)
                {
                    this._parent = null;
                    return this.ReadOverAttribute(parent, skipContent);
                }
                return this.ReadToEnd();
            }
            /*bool */ ReadToEnd()
            {
                this._state = 3/*ReadState.EndOfFile*/;
                return false;
            }
            /*bool */ IsDuplicateNamespaceAttribute(/*XAttribute*/ candidateAttribute)
            {
                if (!candidateAttribute.IsNamespaceDeclaration)
                {
                    return false;
                }
                else 
                {
                    return this.IsDuplicateNamespaceAttributeInner(candidateAttribute);
                }
            }
            /*bool */ IsDuplicateNamespaceAttributeInner(/*XAttribute*/ candidateAttribute)
            {
                if ($.$spc.System.String.op_Equality(candidateAttribute.Name.LocalName, "xml"))
                {
                    return true;
                }
                /*XElement?*/ let element = $.$as(candidateAttribute.parent, $.$spxl.System.Xml.Linq.XElement);
                if (element === this._root || element === null)
                {
                    return false;
                }
                element = $.$as(element.parent, $.$spxl.System.Xml.Linq.XElement);
                while(element !== null)
                {
                    /*XAttribute?*/ let a = element.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            if ($.$spxl.System.Xml.Linq.XName.op_Equality(a.name, candidateAttribute.name))
                            {
                                if ($.$spc.System.String.op_Equality(a.Value, candidateAttribute.Value))
                                {
                                    return true;
                                }
                                else 
                                {
                                    return false;
                                }
                            }
                            a = a.next;
                        }
                        while(a !== element.lastAttr);
                    }
                    if (element === this._root)
                    {
                        return false;
                    }
                    element = $.$as(element.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return false;
            }
            /*XAttribute? */ GetFirstNonDuplicateNamespaceAttribute(/*XAttribute*/ candidate)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._omitDuplicateNamespaces, "This method should only be called if we're omitting duplicate namespace attribute. For perf reason it's better to test this flag in the caller method.");
                if (!this.IsDuplicateNamespaceAttribute(candidate))
                {
                    return candidate;
                }
                /*XElement?*/ let e = $.$as(candidate.parent, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null && candidate !== e.lastAttr)
                {
                    do
                    {
                        candidate = candidate.next;
                        if (!this.IsDuplicateNamespaceAttribute(candidate))
                        {
                            return candidate;
                        }
                    }
                    while(candidate !== e.lastAttr);
                }
                return null;
            }
            static $h = 2541996;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":53389469,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42952214956,"f":32769},"n":"AttributeCount","d":2541996,"h":38657247660,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":51542149548,"f":32769},"n":"BaseURI","d":2541996,"h":47247182252,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":60132084140,"f":32769},"n":"Depth","d":2541996,"h":55837116844,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":73016986028,"f":32769},"n":"EOF","d":2541996,"h":68722018732,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":81606920620,"f":32769},"n":"HasAttributes","d":2541996,"h":77311953324,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":90196855212,"f":32769},"n":"HasValue","d":2541996,"h":85901887916,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":98786789804,"f":32769},"n":"IsEmptyElement","d":2541996,"h":94491822508,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":107376724396,"f":32769},"n":"LocalName","d":2541996,"h":103081757100,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":120261626284,"f":32769},"n":"Name","d":2541996,"h":115966658988,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":128851560876,"f":32769},"n":"NamespaceURI","d":2541996,"h":124556593580,"f":32769},{"p":52078749,"g":{"r":0,"d":0,"h":141736462764,"f":32769},"n":"NameTable","d":2541996,"h":137441495468,"f":32769},{"p":52865181,"g":{"r":0,"d":0,"h":150326397356,"f":32769},"n":"NodeType","d":2541996,"h":146031430060,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":158916331948,"f":32769},"n":"Prefix","d":2541996,"h":154621364652,"f":32769},{"p":14919837,"g":{"r":0,"d":0,"h":171801233836,"f":32769},"n":"ReadState","d":2541996,"h":167506266540,"f":32769},{"p":53520541,"g":{"r":0,"d":0,"h":180391168428,"f":32769},"n":"Settings","d":2541996,"h":176096201132,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":188981103020,"f":32769},"n":"Value","d":2541996,"h":184686135724,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":197571037612,"f":32769},"n":"XmlLang","d":2541996,"h":193276070316,"f":32769},{"p":54044829,"g":{"r":0,"d":0,"h":206160972204,"f":32769},"n":"XmlSpace","d":2541996,"h":201866004908,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":300650252716,"f":2},"n":"{13936797}.LineNumber","o":"System$Xml$IXmlLineInfo$LineNumber","d":2541996,"h":296355285420,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":309240187308,"f":2},"n":"{13936797}.LinePosition","o":"System$Xml$IXmlLineInfo$LinePosition","d":2541996,"h":304945220012,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":317830121900,"f":2},"s":{"r":0,"d":0,"h":322125089196,"f":2},"n":"IsEndElement","d":2541996,"h":313535154604,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":330715023788,"f":2},"n":"IsInteractive","d":2541996,"h":326420056492,"f":2}],"m":[{"r":655361,"p":[{"n":"o","p":2607532}],"n":"GetDepth","d":2541996,"h":64427051436,"f":34},{"r":1310721,"n":"GetLocalName","d":2541996,"h":111671691692,"f":2},{"r":1310721,"n":"GetNamespaceURI","d":2541996,"h":133146528172,"f":2},{"r":1310721,"n":"GetPrefix","d":2541996,"h":163211299244,"f":2},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":2541996,"h":210455939500,"f":32772},{"r":65537,"n":"Close","d":2541996,"h":214750906796,"f":32769},{"r":1310721,"p":[{"n":"name","p":1310721}],"n":"GetAttribute","d":2541996,"h":219045874092,"f":32769},{"r":1310721,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"GetAttribute","o":"@$1","d":2541996,"h":223340841388,"f":32769},{"r":1310721,"p":[{"n":"index","p":655361}],"n":"GetAttribute","o":"@$2","d":2541996,"h":227635808684,"f":32769},{"r":1310721,"p":[{"n":"prefix","p":1310721}],"n":"LookupNamespace","d":2541996,"h":231930775980,"f":32769},{"r":262145,"p":[{"n":"name","p":1310721}],"n":"MoveToAttribute","d":2541996,"h":236225743276,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"MoveToAttribute","o":"@$1","d":2541996,"h":240520710572,"f":32769},{"r":65537,"p":[{"n":"index","p":655361}],"n":"MoveToAttribute","o":"@$2","d":2541996,"h":244815677868,"f":32769},{"r":262145,"n":"MoveToElement","d":2541996,"h":249110645164,"f":32769},{"r":262145,"n":"MoveToFirstAttribute","d":2541996,"h":253405612460,"f":32769},{"r":262145,"n":"MoveToNextAttribute","d":2541996,"h":257700579756,"f":32769},{"r":262145,"n":"Read","d":2541996,"h":261995547052,"f":32769},{"r":262145,"n":"ReadAttributeValue","d":2541996,"h":266290514348,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"ReadToDescendant","o":"@$1","d":2541996,"h":270585481644,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"ReadToFollowing","o":"@$1","d":2541996,"h":274880448940,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"ReadToNextSibling","o":"@$1","d":2541996,"h":279175416236,"f":32769},{"r":65537,"n":"ResolveEntity","d":2541996,"h":283470383532,"f":32769},{"r":65537,"n":"Skip","d":2541996,"h":287765350828,"f":32769},{"r":14264477,"n":"CreateNameTable","d":2541996,"h":335009991084,"f":34},{"r":1690028,"n":"GetElementInAttributeScope","d":2541996,"h":339304958380,"f":2},{"r":1690028,"n":"GetElementInScope","d":2541996,"h":343599925676,"f":2},{"r":65537,"p":[{"n":"qualifiedName","p":1310721},{"n":"e","p":1690028},{"n":"localName","p":1310721,"f":2},{"n":"namespaceName","p":1310721,"f":2}],"n":"GetNameInAttributeScope","d":2541996,"h":347894892972,"f":34},{"r":262145,"p":[{"n":"skipContent","p":262145}],"n":"Read","o":"@$1","d":2541996,"h":352189860268,"f":2},{"r":262145,"p":[{"n":"d","p":1558956}],"n":"ReadIntoDocument","d":2541996,"h":356484827564,"f":2},{"r":262145,"p":[{"n":"e","p":1690028}],"n":"ReadIntoElement","d":2541996,"h":360779794860,"f":2},{"r":262145,"p":[{"n":"a","p":1165740}],"n":"ReadIntoAttribute","d":2541996,"h":365074762156,"f":2},{"r":262145,"p":[{"n":"a","p":1165740},{"n":"skipContent","p":262145}],"n":"ReadOverAttribute","d":2541996,"h":369369729452,"f":2},{"r":262145,"p":[{"n":"n","p":2279852}],"n":"ReadOverNode","d":2541996,"h":373664696748,"f":2},{"r":262145,"p":[{"n":"skipContent","p":262145}],"n":"ReadOverText","d":2541996,"h":377959664044,"f":2},{"r":262145,"n":"ReadToEnd","d":2541996,"h":382254631340,"f":2},{"r":262145,"p":[{"n":"candidateAttribute","p":1165740}],"n":"IsDuplicateNamespaceAttribute","d":2541996,"h":386549598636,"f":2},{"r":262145,"p":[{"n":"candidateAttribute","p":1165740}],"n":"IsDuplicateNamespaceAttributeInner","d":2541996,"h":390844565932,"f":2},{"r":1165740,"p":[{"n":"candidate","p":1165740}],"n":"GetFirstNonDuplicateNamespaceAttribute","d":2541996,"h":395139533228,"f":2}],"l":[{"t":131073,"n":"_source","d":2541996,"h":4297509292,"f":2},{"t":131073,"n":"_parent","d":2541996,"h":8592476588,"f":2},{"t":14919837,"n":"_state","d":2541996,"h":12887443884,"f":2},{"t":2279852,"n":"_root","d":2541996,"h":17182411180,"f":2},{"t":52078749,"n":"_nameTable","d":2541996,"h":21477378476,"f":2},{"t":262145,"n":"_omitDuplicateNamespaces","d":2541996,"h":25772345772,"f":2}],"c":[{"p":[{"n":"node","p":2279852},{"n":"nameTable","p":52078749},{"n":"options","p":969132}],"n":".ctor","o":"$ctor$2","d":2541996,"h":30067313068,"f":8},{"p":[{"n":"node","p":2279852},{"n":"nameTable","p":52078749}],"n":".ctor","o":"$ctor$3","d":2541996,"h":34362280364,"f":8}],"i":[57540609,13936797],"h":2541996}; }
            static get $b() { return $.$spx.System.Xml.XmlReader; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XNodeReader`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XDocumentType", ($self) => class XDocumentType extends $.$spxl.System.Xml.Linq.XNode
        {
            /*string*/ _name = null;
            /*string?*/ _publicId = null;
            /*string?*/ _systemId = null;
            /*string?*/ _internalSubset = null;
            $ctor$3(/*string*/ name, /*string?*/ publicId, /*string?*/ systemId, /*string?*/ internalSubset)
            {
                super.$ctor$2();
                {
                    this._name = $.$spx.System.Xml.XmlConvert.VerifyName(name);
                    this._publicId = publicId;
                    this._systemId = systemId;
                    this._internalSubset = internalSubset;
                }
                return this;
            }
            $ctor$4(/*XDocumentType*/ other)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this._name = other._name;
                    this._publicId = other._publicId;
                    this._systemId = other._systemId;
                    this._internalSubset = other._internalSubset;
                }
                return this;
            }
            $ctor$5(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    this._name = r.Name;
                    this._publicId = r.GetAttribute("PUBLIC");
                    this._systemId = r.GetAttribute("SYSTEM");
                    this._internalSubset = r.Value;
                    r.Read();
                }
                return this;
            }
            /*string? */ get InternalSubset()
            {
                return this._internalSubset;
            }
            /*string? */ set InternalSubset(value)
            {
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this._internalSubset = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*string */ get Name()
            {
                return this._name;
            }
            /*string */ set Name(value)
            {
                value = $.$spx.System.Xml.XmlConvert.VerifyName(value);
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                this._name = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                }
            }
            /*XmlNodeType */ get NodeType()
            {
                return 10/*XmlNodeType.DocumentType*/;
            }
            /*string? */ get PublicId()
            {
                return this._publicId;
            }
            /*string? */ set PublicId(value)
            {
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this._publicId = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*string? */ get SystemId()
            {
                return this._systemId;
            }
            /*string? */ set SystemId(value)
            {
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this._systemId = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                writer.WriteDocType(this._name, this._publicId, this._systemId, this._internalSubset);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return writer.WriteDocTypeAsync(this._name, this._publicId, this._systemId, this._internalSubset);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XDocumentType().$ctor$4(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XDocumentType?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XDocumentType);
                return other !== null && $.$spc.System.String.op_Equality(this._name, other._name) && $.$spc.System.String.op_Equality(this._publicId, other._publicId) && $.$spc.System.String.op_Equality(this._systemId, other.SystemId) && $.$spc.System.String.op_Equality(this._internalSubset, other._internalSubset);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$spc.System.String.GetHashCode.call(this._name) ^ ($.$spc.System.String.op_Inequality(this._publicId, null) ? $.$spc.System.String.GetHashCode.call(this._publicId) : 0) ^ ($.$spc.System.String.op_Inequality(this._systemId, null) ? $.$spc.System.String.GetHashCode.call(this._systemId) : 0) ^ ($.$spc.System.String.op_Inequality(this._internalSubset, null) ? $.$spc.System.String.GetHashCode.call(this._internalSubset) : 0);
            }
            static $h = 1624492;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2279852,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":38656330156,"f":1},"s":{"r":0,"d":0,"h":42951297452,"f":1},"n":"InternalSubset","d":1624492,"h":34361362860,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51541232044,"f":1},"s":{"r":0,"d":0,"h":55836199340,"f":1},"n":"Name","d":1624492,"h":47246264748,"f":1},{"p":52865181,"g":{"r":0,"d":0,"h":64426133932,"f":32769},"n":"NodeType","d":1624492,"h":60131166636,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":73016068524,"f":1},"s":{"r":0,"d":0,"h":77311035820,"f":1},"n":"PublicId","d":1624492,"h":68721101228,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85900970412,"f":1},"s":{"r":0,"d":0,"h":90195937708,"f":1},"n":"SystemId","d":1624492,"h":81606003116,"f":1}],"m":[{"r":65537,"p":[{"n":"writer","p":58435741}],"n":"WriteTo","d":1624492,"h":94490905004,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58435741},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":1624492,"h":98785872300,"f":32769},{"r":2279852,"n":"CloneNode","d":1624492,"h":103080839596,"f":32776},{"r":262145,"p":[{"n":"node","p":2279852}],"n":"DeepEquals","o":"@$1","d":1624492,"h":107375806892,"f":32776},{"r":655361,"n":"GetDeepHashCode","d":1624492,"h":111670774188,"f":32776}],"l":[{"t":1310721,"n":"_name","d":1624492,"h":4296591788,"f":2},{"t":1310721,"n":"_publicId","d":1624492,"h":8591559084,"f":2},{"t":1310721,"n":"_systemId","d":1624492,"h":12886526380,"f":2},{"t":1310721,"n":"_internalSubset","d":1624492,"h":17181493676,"f":2}],"c":[{"p":[{"n":"name","p":1310721},{"n":"publicId","p":1310721},{"n":"systemId","p":1310721},{"n":"internalSubset","p":1310721}],"n":".ctor","o":"$ctor$3","d":1624492,"h":21476460972,"f":1},{"p":[{"n":"other","p":1624492}],"n":".ctor","o":"$ctor$4","d":1624492,"h":25771428268,"f":1},{"p":[{"n":"r","p":53389469}],"n":".ctor","o":"$ctor$5","d":1624492,"h":30066395564,"f":8}],"i":[13936797],"h":1624492}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XDocumentType`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XComment", ($self) => class XComment extends $.$spxl.System.Xml.Linq.XNode
        {
            /*string*/ value = null;
            $ctor$3(/*string*/ value)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                    this.value = value;
                }
                return this;
            }
            $ctor$4(/*XComment*/ other)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this.value = other.value;
                }
                return this;
            }
            $ctor$5(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    this.value = r.Value;
                    r.Read();
                }
                return this;
            }
            /*XmlNodeType */ get NodeType()
            {
                return 8/*XmlNodeType.Comment*/;
            }
            /*string */ get Value()
            {
                return this.value;
            }
            /*string */ set Value(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.value = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                writer.WriteComment(this.value);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return writer.WriteCommentAsync(this.value);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XComment().$ctor$4(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XComment?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XComment);
                return other !== null && $.$spc.System.String.op_Equality(this.value, other.value);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$spc.System.String.GetHashCode.call(this.value);
            }
            static $h = 1296812;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2279852,"p":[{"p":52865181,"g":{"r":0,"d":0,"h":25771100588,"f":32769},"n":"NodeType","d":1296812,"h":21476133292,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":34361035180,"f":1},"s":{"r":0,"d":0,"h":38656002476,"f":1},"n":"Value","d":1296812,"h":30066067884,"f":1}],"m":[{"r":65537,"p":[{"n":"writer","p":58435741}],"n":"WriteTo","d":1296812,"h":42950969772,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58435741},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":1296812,"h":47245937068,"f":32769},{"r":2279852,"n":"CloneNode","d":1296812,"h":51540904364,"f":32776},{"r":262145,"p":[{"n":"node","p":2279852}],"n":"DeepEquals","o":"@$1","d":1296812,"h":55835871660,"f":32776},{"r":655361,"n":"GetDeepHashCode","d":1296812,"h":60130838956,"f":32776}],"l":[{"t":1310721,"n":"value","d":1296812,"h":4296264108,"f":8}],"c":[{"p":[{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$3","d":1296812,"h":8591231404,"f":1},{"p":[{"n":"other","p":1296812}],"n":".ctor","o":"$ctor$4","d":1296812,"h":12886198700,"f":1},{"p":[{"n":"r","p":53389469}],"n":".ctor","o":"$ctor$5","d":1296812,"h":17181165996,"f":8}],"i":[13936797],"h":1296812}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XComment`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XProcessingInstruction", ($self) => class XProcessingInstruction extends $.$spxl.System.Xml.Linq.XNode
        {
            /*string*/ target = null;
            /*string*/ data = null;
            $ctor$3(/*string*/ target, /*string*/ data)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(data, "data");
                    $.$spxl.System.Xml.Linq.XProcessingInstruction.ValidateName(target);
                    this.target = target;
                    this.data = data;
                }
                return this;
            }
            $ctor$4(/*XProcessingInstruction*/ other)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this.target = other.target;
                    this.data = other.data;
                }
                return this;
            }
            $ctor$5(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    this.target = r.Name;
                    this.data = r.Value;
                    r.Read();
                }
                return this;
            }
            /*string */ get Data()
            {
                return this.data;
            }
            /*string */ set Data(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.data = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*XmlNodeType */ get NodeType()
            {
                return 7/*XmlNodeType.ProcessingInstruction*/;
            }
            /*string */ get Target()
            {
                return this.target;
            }
            /*string */ set Target(value)
            {
                $.$spxl.System.Xml.Linq.XProcessingInstruction.ValidateName(value);
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                this.target = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                writer.WriteProcessingInstruction(this.target, this.data);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return writer.WriteProcessingInstructionAsync(this.target, this.data);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XProcessingInstruction().$ctor$4(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XProcessingInstruction?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XProcessingInstruction);
                return other !== null && $.$spc.System.String.op_Equality(this.target, other.target) && $.$spc.System.String.op_Equality(this.data, other.data);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$spc.System.String.GetHashCode.call(this.target) ^ $.$spc.System.String.GetHashCode.call(this.data);
            }
            static /*void */ ValidateName(/*string*/ name)
            {
                $.$spx.System.Xml.XmlConvert.VerifyNCName(name);
                if ($.$spc.System.String.Equals$5(name, "xml", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_InvalidPIName, name));
                }
            }
            static $h = 2869676;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2279852,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30067640748,"f":1},"s":{"r":0,"d":0,"h":34362608044,"f":1},"n":"Data","d":2869676,"h":25772673452,"f":1},{"p":52865181,"g":{"r":0,"d":0,"h":42952542636,"f":32769},"n":"NodeType","d":2869676,"h":38657575340,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":51542477228,"f":1},"s":{"r":0,"d":0,"h":55837444524,"f":1},"n":"Target","d":2869676,"h":47247509932,"f":1}],"m":[{"r":65537,"p":[{"n":"writer","p":58435741}],"n":"WriteTo","d":2869676,"h":60132411820,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58435741},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":2869676,"h":64427379116,"f":32769},{"r":2279852,"n":"CloneNode","d":2869676,"h":68722346412,"f":32776},{"r":262145,"p":[{"n":"node","p":2279852}],"n":"DeepEquals","o":"@$1","d":2869676,"h":73017313708,"f":32776},{"r":655361,"n":"GetDeepHashCode","d":2869676,"h":77312281004,"f":32776},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"ValidateName","d":2869676,"h":81607248300,"f":34}],"l":[{"t":1310721,"n":"target","d":2869676,"h":4297836972,"f":8},{"t":1310721,"n":"data","d":2869676,"h":8592804268,"f":8}],"c":[{"p":[{"n":"target","p":1310721},{"n":"data","p":1310721}],"n":".ctor","o":"$ctor$3","d":2869676,"h":12887771564,"f":1},{"p":[{"n":"other","p":2869676}],"n":".ctor","o":"$ctor$4","d":2869676,"h":17182738860,"f":1},{"p":[{"n":"r","p":53389469}],"n":".ctor","o":"$ctor$5","d":2869676,"h":21477706156,"f":8}],"i":[13936797],"h":2869676}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XProcessingInstruction`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XText", ($self) => class XText extends $.$spxl.System.Xml.Linq.XNode
        {
            /*string*/ text = null;
            $ctor$3(/*string*/ value)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                    this.text = value;
                }
                return this;
            }
            $ctor$4(/*XText*/ other)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this.text = other.text;
                }
                return this;
            }
            $ctor$5(/*XmlReader*/ r)
            {
                super.$ctor$2();
                {
                    this.text = r.Value;
                    r.Read();
                }
                return this;
            }
            /*XmlNodeType */ get NodeType()
            {
                return 3/*XmlNodeType.Text*/;
            }
            /*string */ get Value()
            {
                return this.text;
            }
            /*string */ set Value(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                this.text = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Value);
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if ($.$is(this.parent, $.$spxl.System.Xml.Linq.XDocument))
                {
                    writer.WriteWhitespace(this.text);
                }
                else 
                {
                    writer.WriteString(this.text);
                }
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return $.$is(this.parent, $.$spxl.System.Xml.Linq.XDocument) ? writer.WriteWhitespaceAsync(this.text) : writer.WriteStringAsync(this.text);
            }
            /*void */ AppendText(/*StringBuilder*/ sb)
            {
                sb.Append$2(this.text);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XText().$ctor$4(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                return node !== null && this.NodeType === node.NodeType && $.$spc.System.String.op_Equality(this.text, ($.$cast(node, $.$spxl.System.Xml.Linq.XText)).text);
            }
            /*int */ GetDeepHashCode()
            {
                return $.$spc.System.String.GetHashCode.call(this.text);
            }
            static $h = 3000748;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2279852,"p":[{"p":52865181,"g":{"r":0,"d":0,"h":25772804524,"f":32769},"n":"NodeType","d":3000748,"h":21477837228,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":34362739116,"f":1},"s":{"r":0,"d":0,"h":38657706412,"f":1},"n":"Value","d":3000748,"h":30067771820,"f":1}],"m":[{"r":65537,"p":[{"n":"writer","p":58435741}],"n":"WriteTo","d":3000748,"h":42952673708,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58435741},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":3000748,"h":47247641004,"f":32769},{"r":65537,"p":[{"n":"sb","p":122945537}],"n":"AppendText","d":3000748,"h":51542608300,"f":32776},{"r":2279852,"n":"CloneNode","d":3000748,"h":55837575596,"f":32776},{"r":262145,"p":[{"n":"node","p":2279852}],"n":"DeepEquals","o":"@$1","d":3000748,"h":60132542892,"f":32776},{"r":655361,"n":"GetDeepHashCode","d":3000748,"h":64427510188,"f":32776}],"l":[{"t":1310721,"n":"text","d":3000748,"h":4297968044,"f":8}],"c":[{"p":[{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$3","d":3000748,"h":8592935340,"f":1},{"p":[{"n":"other","p":3000748}],"n":".ctor","o":"$ctor$4","d":3000748,"h":12887902636,"f":1},{"p":[{"n":"r","p":53389469}],"n":".ctor","o":"$ctor$5","d":3000748,"h":17182869932,"f":8}],"i":[13936797],"h":3000748}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XNode; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XText`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.XObjectChange", ($self) => class XObjectChange extends $.$spc.System.Enum
        {
            static Add = 0;
            static Remove = 1;
            static Name = 2;
            static Value = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Remove": 1n,
                    "Name": 2n,
                    "Value": 3n
                };
            }
            static $h = 2673068;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2673068,"n":"Add","d":2673068,"h":4297640364,"f":33},{"t":2673068,"n":"Remove","d":2673068,"h":8592607660,"f":33},{"t":2673068,"n":"Name","d":2673068,"h":12887574956,"f":33},{"t":2673068,"n":"Value","d":2673068,"h":17182542252,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2673068,"h":21477509548,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2673068}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.XObjectChange`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.LoadOptions", ($self) => class LoadOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static PreserveWhitespace = 1;
            static SetBaseUri = 2;
            static SetLineInfo = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "PreserveWhitespace": 1n,
                    "SetBaseUri": 2n,
                    "SetLineInfo": 4n
                };
            }
            static $h = 706988;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":706988,"n":"None","d":706988,"h":4295674284,"f":33},{"t":706988,"n":"PreserveWhitespace","d":706988,"h":8590641580,"f":33},{"t":706988,"n":"SetBaseUri","d":706988,"h":12885608876,"f":33},{"t":706988,"n":"SetLineInfo","d":706988,"h":17180576172,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":706988,"h":21475543468,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":706988,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.LoadOptions`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.SaveOptions", ($self) => class SaveOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static DisableFormatting = 1;
            static OmitDuplicateNamespaces = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "DisableFormatting": 1n,
                    "OmitDuplicateNamespaces": 2n
                };
            }
            static $h = 1034668;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1034668,"n":"None","d":1034668,"h":4296001964,"f":33},{"t":1034668,"n":"DisableFormatting","d":1034668,"h":8590969260,"f":33},{"t":1034668,"n":"OmitDuplicateNamespaces","d":1034668,"h":12885936556,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1034668,"h":17180903852,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1034668,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.SaveOptions`; }
        });
        
        $asm.$str("$spxl.System.Xml.Linq.ReaderOptions", ($self) => class ReaderOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static OmitDuplicateNamespaces = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OmitDuplicateNamespaces": 1n
                };
            }
            static $h = 969132;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":969132,"n":"None","d":969132,"h":4295936428,"f":33},{"t":969132,"n":"OmitDuplicateNamespaces","d":969132,"h":8590903724,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":969132,"h":12885871020,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":969132,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Xml.Linq.ReaderOptions`; }
        });
        
        $asm.$cls("$spxl.System.Xml.XPath.XNodeNavigator", ($self) => class XNodeNavigator extends $.$spx.System.Xml.XPath.XPathNavigator
        {
            /*string*/ static xmlPrefixNamespace = null;
            /*string*/ static xmlnsPrefixNamespace = null;
            /*int*/ static DocumentContentMask = 386;
            static /*ReadOnlySpan<int> */ get ElementContentMasks()
            {
                return this.$cacheElementContentMasks ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Int32))().$ctor$2([ 0, (1 << 1/*XmlNodeType.Element*/), 0, 0, (1 << 4/*XmlNodeType.CDATA*/) | (1 << 3/*XmlNodeType.Text*/), 0, 0, (1 << 7/*XmlNodeType.ProcessingInstruction*/), (1 << 8/*XmlNodeType.Comment*/), (1 << 1/*XmlNodeType.Element*/) | (1 << 4/*XmlNodeType.CDATA*/) | (1 << 3/*XmlNodeType.Text*/) | (1 << 7/*XmlNodeType.ProcessingInstruction*/) | (1 << 8/*XmlNodeType.Comment*/) ]);
            }
            /*int*/ static TextMask = 24;
            /*XAttribute?*/ static s_XmlNamespaceDeclaration = null;
            /*XObject*/ _source = null;
            /*XElement?*/ _parent = null;
            /*XmlNameTable*/ _nameTable = null;
            $ctor$3(/*XNode*/ node, /*XmlNameTable?*/ nameTable)
            {
                super.$ctor$2();
                {
                    this._source = node;
                    this._nameTable = nameTable ?? $.$spxl.System.Xml.XPath.XNodeNavigator.CreateNameTable();
                }
                return this;
            }
            $ctor$4(/*XNodeNavigator*/ other)
            {
                super.$ctor$2();
                {
                    this._source = other._source;
                    this._parent = other._parent;
                    this._nameTable = other._nameTable;
                }
                return this;
            }
            /*string */ get BaseURI()
            {
                if (this._source !== null)
                {
                    return this._source.BaseUri;
                }
                if (this._parent !== null)
                {
                    return this._parent.BaseUri;
                }
                return $.$spc.System.String.Empty;
            }
            /*bool */ get HasAttributes()
            {
                /*XElement?*/ let element = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (element !== null)
                {
                    var $en3 = element.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var attribute = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!attribute.IsNamespaceDeclaration)
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ get HasChildren()
            {
                /*XContainer?*/ let container = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (container !== null)
                {
                    var $en3 = container.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, node))
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ get IsEmptyElement()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                return e !== null && e.IsEmpty;
            }
            /*string */ get LocalName()
            {
                return this._nameTable.Add$1(this.GetLocalName());
            }
            /*string */ GetLocalName()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.LocalName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (this._parent !== null && a.Name.NamespaceName.length === 0)
                    {
                        return $.$spc.System.String.Empty;
                    }
                    return a.Name.LocalName;
                }
                /*XProcessingInstruction?*/ let p = $.$as(this._source, $.$spxl.System.Xml.Linq.XProcessingInstruction);
                if (p !== null)
                {
                    return p.Target;
                }
                return $.$spc.System.String.Empty;
            }
            /*string */ get Name()
            {
                /*string*/ let prefix = this.GetPrefix();
                if (prefix.length === 0)
                {
                    return this._nameTable.Add$1(this.GetLocalName());
                }
                return this._nameTable.Add$1($.$spc.System.String.Concat$8(prefix, ":", this.GetLocalName()));
            }
            /*string */ get NamespaceURI()
            {
                return this._nameTable.Add$1(this.GetNamespaceURI());
            }
            /*string */ GetNamespaceURI()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    return e.Name.NamespaceName;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (this._parent !== null)
                    {
                        return $.$spc.System.String.Empty;
                    }
                    return a.Name.NamespaceName;
                }
                return $.$spc.System.String.Empty;
            }
            /*XmlNameTable */ get NameTable()
            {
                return this._nameTable;
            }
            /*XPathNodeType */ get NodeType()
            {
                if (this._source !== null)
                {
                    let $switch1 = this._source.NodeType;
                    switch($switch1)
                    {
                        case 1/*XmlNodeType.Element*/:
                        return 1/*XPathNodeType.Element*/;
                        case 2/*XmlNodeType.Attribute*/:
                        /*XAttribute*/ let attribute = $.$cast(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                        return attribute.IsNamespaceDeclaration ? 3/*XPathNodeType.Namespace*/ : 2/*XPathNodeType.Attribute*/;
                        case 9/*XmlNodeType.Document*/:
                        return 0/*XPathNodeType.Root*/;
                        case 8/*XmlNodeType.Comment*/:
                        return 8/*XPathNodeType.Comment*/;
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        return 7/*XPathNodeType.ProcessingInstruction*/;
                        default:
                        return 4/*XPathNodeType.Text*/;
                    }
                }
                return 4/*XPathNodeType.Text*/;
            }
            /*string */ get Prefix()
            {
                return this._nameTable.Add$1(this.GetPrefix());
            }
            /*string */ GetPrefix()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    /*string?*/ let prefix = e.GetPrefixOfNamespace(e.Name.Namespace);
                    if ($.$spc.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                    return $.$spc.System.String.Empty;
                }
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null)
                {
                    if (this._parent !== null)
                    {
                        return $.$spc.System.String.Empty;
                    }
                    /*string?*/ let prefix = a.GetPrefixOfNamespace(a.Name.Namespace);
                    if ($.$spc.System.String.op_Inequality(prefix, null))
                    {
                        return prefix;
                    }
                }
                return $.$spc.System.String.Empty;
            }
            /*object */ get UnderlyingObject()
            {
                return this._source;
            }
            /*string */ get Value()
            {
                if (this._source !== null)
                {
                    let $switch1 = this._source.NodeType;
                    switch($switch1)
                    {
                        case 1/*XmlNodeType.Element*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XElement)).Value;
                        case 2/*XmlNodeType.Attribute*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XAttribute)).Value;
                        case 9/*XmlNodeType.Document*/:
                        /*XElement?*/ let root = ($.$cast(this._source, $.$spxl.System.Xml.Linq.XDocument)).Root;
                        return root !== null ? root.Value : $.$spc.System.String.Empty;
                        case 3/*XmlNodeType.Text*/:
                        case 4/*XmlNodeType.CDATA*/:
                        return $.$spxl.System.Xml.XPath.XNodeNavigator.CollectText($.$cast(this._source, $.$spxl.System.Xml.Linq.XText));
                        case 8/*XmlNodeType.Comment*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XComment)).Value;
                        case 7/*XmlNodeType.ProcessingInstruction*/:
                        return ($.$cast(this._source, $.$spxl.System.Xml.Linq.XProcessingInstruction)).Data;
                        default:
                        return $.$spc.System.String.Empty;
                    }
                }
                return $.$spc.System.String.Empty;
            }
            /*XPathNavigator */ Clone()
            {
                return new $.$spxl.System.Xml.XPath.XNodeNavigator().$ctor$4(this);
            }
            /*bool */ IsSamePosition(/*XPathNavigator*/ navigator)
            {
                /*XNodeNavigator?*/ let other = $.$as(navigator, $.$spxl.System.Xml.XPath.XNodeNavigator);
                if (other === null)
                {
                    return false;
                }
                return $.$spxl.System.Xml.XPath.XNodeNavigator.IsSamePosition$1(this, other);
            }
            /*bool */ MoveTo(/*XPathNavigator*/ navigator)
            {
                /*XNodeNavigator?*/ let other = $.$as(navigator, $.$spxl.System.Xml.XPath.XNodeNavigator);
                if (other !== null)
                {
                    this._source = other._source;
                    this._parent = other._parent;
                    return true;
                }
                return false;
            }
            /*bool */ MoveToAttribute(/*string*/ localName, /*string*/ namespaceName)
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    var $en3 = e.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var attribute = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spc.System.String.op_Equality(attribute.Name.LocalName, localName) && $.$spc.System.String.op_Equality(attribute.Name.NamespaceName, namespaceName) && !attribute.IsNamespaceDeclaration)
                            {
                                this._source = attribute;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToChild(/*string*/ localName, /*string*/ namespaceName)
            {
                /*XContainer?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (c !== null)
                {
                    var $en3 = c.Elements().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spc.System.String.op_Equality(element.Name.LocalName, localName) && $.$spc.System.String.op_Equality(element.Name.NamespaceName, namespaceName))
                            {
                                this._source = element;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToChild$1(/*XPathNodeType*/ type)
            {
                /*XContainer?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (c !== null)
                {
                    /*int*/ let mask = $.$spxl.System.Xml.XPath.XNodeNavigator.GetElementContentMask(type);
                    if ((24/*TextMask*/ & mask) !== 0 && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(c) === null && $.$is(c, $.$spxl.System.Xml.Linq.XDocument))
                    {
                        mask &= ~24/*TextMask*/;
                    }
                    var $en3 = c.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (((1 << node.NodeType) & mask) !== 0)
                            {
                                this._source = node;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToFirstAttribute()
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    var $en3 = e.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var attribute = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!attribute.IsNamespaceDeclaration)
                            {
                                this._source = attribute;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToFirstChild()
            {
                /*XContainer?*/ let container = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (container !== null)
                {
                    var $en3 = container.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, node))
                            {
                                this._source = node;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToFirstNamespace(/*XPathNamespaceScope*/ scope)
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    /*XAttribute?*/ let a = null;
                    switch(scope)
                    {
                        case 2/*XPathNamespaceScope.Local*/:
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationLocal(e);
                        break;
                        case 1/*XPathNamespaceScope.ExcludeXml*/:
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e);
                        while(a !== null && $.$spc.System.String.op_Equality(a.Name.LocalName, "xml"))
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                        }
                        break;
                        case 0/*XPathNamespaceScope.All*/:
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e) ?? $.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration();
                        break;
                    }
                    if (a !== null)
                    {
                        this._source = a;
                        this._parent = e;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToId(/*string*/ id)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$spxl.System.SR.NotSupported_MoveToId);
            }
            /*bool */ MoveToNamespace(/*string*/ localName)
            {
                /*XElement?*/ let e = $.$as(this._source, $.$spxl.System.Xml.Linq.XElement);
                if (e !== null)
                {
                    if ($.$spc.System.String.op_Equality(localName, "xmlns"))
                    {
                        return false;
                    }
                    if ($.$spc.System.String.op_Inequality(localName, null) && localName.length === 0)
                    {
                        localName = "xmlns";
                    }
                    /*XAttribute?*/ let a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e);
                    while(a !== null)
                    {
                        if ($.$spc.System.String.op_Equality(a.Name.LocalName, localName))
                        {
                            this._source = a;
                            this._parent = e;
                            return true;
                        }
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                    }
                    if ($.$spc.System.String.op_Equality(localName, "xml"))
                    {
                        this._source = $.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration();
                        this._parent = e;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToNext()
            {
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    /*XContainer?*/ let container = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentNode);
                    if (container !== null)
                    {
                        /*XNode?*/ let next;
                        for(/*XNode*/ let node = currentNode; node !== null; node = next)
                        {
                            next = node.NextNode;
                            if (next === null)
                            {
                                break;
                            }
                            if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, next) && !($.$is(node, $.$spxl.System.Xml.Linq.XText) && $.$is(next, $.$spxl.System.Xml.Linq.XText)))
                            {
                                this._source = next;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToNext$1(/*string*/ localName, /*string*/ namespaceName)
            {
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    var $en3 = currentNode.ElementsAfterSelf().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spc.System.String.op_Equality(element.Name.LocalName, localName) && $.$spc.System.String.op_Equality(element.Name.NamespaceName, namespaceName))
                            {
                                this._source = element;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToNext$2(/*XPathNodeType*/ type)
            {
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    /*XContainer?*/ let container = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentNode);
                    if (container !== null)
                    {
                        /*int*/ let mask = $.$spxl.System.Xml.XPath.XNodeNavigator.GetElementContentMask(type);
                        if ((24/*TextMask*/ & mask) !== 0 && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(container) === null && $.$is(container, $.$spxl.System.Xml.Linq.XDocument))
                        {
                            mask &= ~24/*TextMask*/;
                        }
                        /*XNode?*/ let next;
                        for(/*XNode*/ let node = currentNode; ; node = next)
                        {
                            next = node.NextNode;
                            if (next === null)
                            {
                                break;
                            }
                            if (((1 << next.NodeType) & mask) !== 0 && !($.$is(node, $.$spxl.System.Xml.Linq.XText) && $.$is(next, $.$spxl.System.Xml.Linq.XText)))
                            {
                                this._source = next;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToNextAttribute()
            {
                /*XAttribute?*/ let currentAttribute = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (currentAttribute !== null && this._parent === null)
                {
                    /*XElement?*/ let e = $.$cast($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentAttribute), $.$spxl.System.Xml.Linq.XElement);
                    if (e !== null)
                    {
                        for(/*XAttribute?*/ let attribute = currentAttribute.NextAttribute; attribute !== null; attribute = attribute.NextAttribute)
                        {
                            if (!attribute.IsNamespaceDeclaration)
                            {
                                this._source = attribute;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /*bool */ MoveToNextNamespace(/*XPathNamespaceScope*/ scope)
            {
                /*XAttribute?*/ let a = $.$as(this._source, $.$spxl.System.Xml.Linq.XAttribute);
                if (a !== null && this._parent !== null && !$.$spxl.System.Xml.XPath.XNodeNavigator.IsXmlNamespaceDeclaration(a))
                {
                    switch(scope)
                    {
                        case 2/*XPathNamespaceScope.Local*/:
                        if ($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(a) !== this._parent)
                        {
                            return false;
                        }
                        a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationLocal(a);
                        break;
                        case 1/*XPathNamespaceScope.ExcludeXml*/:
                        do
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                        }
                        while(a !== null && ($.$spc.System.String.op_Equality(a.Name.LocalName, "xml") || $.$spxl.System.Xml.XPath.XNodeNavigator.HasNamespaceDeclarationInScope(a, this._parent)));
                        break;
                        case 0/*XPathNamespaceScope.All*/:
                        do
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationGlobal(a);
                        }
                        while(a !== null && $.$spxl.System.Xml.XPath.XNodeNavigator.HasNamespaceDeclarationInScope(a, this._parent));
                        if (a === null && !$.$spxl.System.Xml.XPath.XNodeNavigator.HasNamespaceDeclarationInScope($.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration(), this._parent))
                        {
                            a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration();
                        }
                        break;
                    }
                    if (a !== null)
                    {
                        this._source = a;
                        return true;
                    }
                }
                return false;
            }
            /*bool */ MoveToParent()
            {
                if (this._parent !== null)
                {
                    this._source = this._parent;
                    this._parent = null;
                    return true;
                }
                /*XNode?*/ let parentNode = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(this._source);
                if (parentNode !== null)
                {
                    this._source = parentNode;
                    return true;
                }
                return false;
            }
            /*bool */ MoveToPrevious()
            {
                /*XNode?*/ let currentNode = $.$as(this._source, $.$spxl.System.Xml.Linq.XNode);
                if (currentNode !== null)
                {
                    /*XContainer?*/ let container = $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(currentNode);
                    if (container !== null)
                    {
                        /*XNode?*/ let previous = null;
                        var $en4 = container.Nodes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var node = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (node === currentNode)
                                {
                                    if (previous !== null)
                                    {
                                        this._source = previous;
                                        return true;
                                    }
                                    return false;
                                }
                                if ($.$spxl.System.Xml.XPath.XNodeNavigator.IsContent(container, node))
                                {
                                    previous = node;
                                }
                            }
                        }
                    }
                }
                return false;
            }
            /*XmlReader */ ReadSubtree()
            {
                /*XContainer?*/ let c = $.$as(this._source, $.$spxl.System.Xml.Linq.XContainer);
                if (c === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.InvalidOperation_BadNodeType, $.$box(this.NodeType, $.$spx.System.Xml.XPath.XPathNodeType)));
                }
                return c.CreateReader();
            }
            /*bool */ System$Xml$IXmlLineInfo$HasLineInfo()
            {
                /*IXmlLineInfo*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                if (li !== null)
                {
                    return li.System$Xml$IXmlLineInfo$HasLineInfo();
                }
                return false;
            }
            /*int */ get System$Xml$IXmlLineInfo$LineNumber()
            {
                /*IXmlLineInfo*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                if (li !== null)
                {
                    return li.System$Xml$IXmlLineInfo$LineNumber;
                }
                return 0;
            }
            /*int */ get System$Xml$IXmlLineInfo$LinePosition()
            {
                /*IXmlLineInfo*/ let li = $.$as(this._source, $.$spx.System.Xml.IXmlLineInfo);
                if (li !== null)
                {
                    return li.System$Xml$IXmlLineInfo$LinePosition;
                }
                return 0;
            }
            static /*string */ CollectText(/*XText*/ n)
            {
                /*string*/ let s = n.Value;
                if ($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n) !== null)
                {
                    var $en3 = n.NodesAfterSelf().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var node = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            /*XText?*/ let t = $.$as(node, $.$spxl.System.Xml.Linq.XText);
                            if (t === null)
                            {
                                break;
                            }
                            s += t.Value;
                        }
                    }
                }
                return s;
            }
            static /*NameTable */ CreateNameTable()
            {
                /*var*/ let nameTable = new $.$spx.System.Xml.NameTable().$ctor$2();
                nameTable.Add$1($.$spc.System.String.Empty);
                nameTable.Add$1($.$spxl.System.Xml.XPath.XNodeNavigator.xmlnsPrefixNamespace);
                nameTable.Add$1($.$spxl.System.Xml.XPath.XNodeNavigator.xmlPrefixNamespace);
                return nameTable;
            }
            static /*bool */ IsContent(/*XContainer*/ c, /*XNode*/ n)
            {
                if ($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(c) !== null || $.$is(c, $.$spxl.System.Xml.Linq.XElement))
                {
                    return true;
                }
                return ((1 << n.NodeType) & 386/*DocumentContentMask*/) !== 0;
            }
            static /*bool */ IsSamePosition$1(/*XNodeNavigator*/ n1, /*XNodeNavigator*/ n2)
            {
                return n1._source === n2._source && $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n1._source) === $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(n2._source);
            }
            static /*bool */ IsXmlNamespaceDeclaration(/*XAttribute*/ a)
            {
                return $.$cast(a, $.$spc.System.Object) === $.$cast($.$spxl.System.Xml.XPath.XNodeNavigator.GetXmlNamespaceDeclaration(), $.$spc.System.Object);
            }
            static /*int */ GetElementContentMask(/*XPathNodeType*/ type)
            {
                return $.$spxl.System.Xml.XPath.XNodeNavigator.ElementContentMasks.get_Item(type).$v;
            }
            static /*XAttribute? */ GetFirstNamespaceDeclarationGlobal(/*XElement*/ e)
            {
                /*XElement?*/ let ce = e;
                do
                {
                    /*XAttribute?*/ let a = $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationLocal(ce);
                    if (a !== null)
                    {
                        return a;
                    }
                    ce = ce.Parent;
                }
                while(ce !== null);
                return null;
            }
            static /*XAttribute? */ GetFirstNamespaceDeclarationLocal(/*XElement*/ e)
            {
                var $en2 = e.Attributes().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var attribute = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (attribute.IsNamespaceDeclaration)
                        {
                            return attribute;
                        }
                    }
                }
                return null;
            }
            static /*XAttribute? */ GetNextNamespaceDeclarationGlobal(/*XAttribute*/ a)
            {
                /*XElement?*/ let e = $.$cast($.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(a), $.$spxl.System.Xml.Linq.XElement);
                if (e === null)
                {
                    return null;
                }
                /*XAttribute?*/ let next = $.$spxl.System.Xml.XPath.XNodeNavigator.GetNextNamespaceDeclarationLocal(a);
                if (next !== null)
                {
                    return next;
                }
                e = e.Parent;
                if (e === null)
                {
                    return null;
                }
                return $.$spxl.System.Xml.XPath.XNodeNavigator.GetFirstNamespaceDeclarationGlobal(e);
            }
            static /*XAttribute? */ GetNextNamespaceDeclarationLocal(/*XAttribute*/ a)
            {
                /*XElement?*/ let e = a.Parent;
                if (e === null)
                {
                    return null;
                }
                /*XAttribute?*/ let ca = a;
                ca = ca.NextAttribute;
                while(ca !== null)
                {
                    if (ca.IsNamespaceDeclaration)
                    {
                        return ca;
                    }
                    ca = ca.NextAttribute;
                }
                return null;
            }
            static /*XAttribute */ GetXmlNamespaceDeclaration()
            {
                if ($.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration === null)
                {
                    $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spxl.System.Xml.Linq.XAttribute, $.$ref(() => $.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration, ($v) => $.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration = $v, $.$spxl.System.Xml.Linq.XAttribute), new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2($.$spxl.System.Xml.Linq.XNamespace.Xmlns.GetName("xml"), $.$spxl.System.Xml.XPath.XNodeNavigator.xmlPrefixNamespace), null);
                }
                return $.$spxl.System.Xml.XPath.XNodeNavigator.s_XmlNamespaceDeclaration;
            }
            static /*bool */ HasNamespaceDeclarationInScope(/*XAttribute*/ a, /*XElement*/ e)
            {
                /*XName*/ let name = a.Name;
                /*XElement?*/ let ce = e;
                while(ce !== null && ce !== $.$spxl.System.Xml.XPath.XObjectExtensions.GetParent(a))
                {
                    if (ce.Attribute(name) !== null)
                    {
                        return true;
                    }
                    ce = ce.Parent;
                }
                return false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.xmlPrefixNamespace = $.$spxl.System.Xml.Linq.XNamespace.Xml.NamespaceName;
                }
                {
                    this.xmlnsPrefixNamespace = $.$spxl.System.Xml.Linq.XNamespace.Xmlns.NamespaceName;
                }
            }
            static $h = 3328428;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":59287709,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":21478164908,"f":34},"n":"ElementContentMasks","d":3328428,"h":17183197612,"f":34},{"p":1310721,"g":{"r":0,"d":0,"h":60132870572,"f":32769},"n":"BaseURI","d":3328428,"h":55837903276,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":68722805164,"f":32769},"n":"HasAttributes","d":3328428,"h":64427837868,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":77312739756,"f":32769},"n":"HasChildren","d":3328428,"h":73017772460,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":85902674348,"f":32769},"n":"IsEmptyElement","d":3328428,"h":81607707052,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":94492608940,"f":32769},"n":"LocalName","d":3328428,"h":90197641644,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":107377510828,"f":32769},"n":"Name","d":3328428,"h":103082543532,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":115967445420,"f":32769},"n":"NamespaceURI","d":3328428,"h":111672478124,"f":32769},{"p":52078749,"g":{"r":0,"d":0,"h":128852347308,"f":32769},"n":"NameTable","d":3328428,"h":124557380012,"f":32769},{"p":59877533,"g":{"r":0,"d":0,"h":137442281900,"f":32769},"n":"NodeType","d":3328428,"h":133147314604,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":146032216492,"f":32769},"n":"Prefix","d":3328428,"h":141737249196,"f":32769},{"p":131073,"g":{"r":0,"d":0,"h":158917118380,"f":32769},"n":"UnderlyingObject","d":3328428,"h":154622151084,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":167507052972,"f":32769},"n":"Value","d":3328428,"h":163212085676,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":261996333484,"f":2},"n":"{13936797}.LineNumber","o":"System$Xml$IXmlLineInfo$LineNumber","d":3328428,"h":257701366188,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":270586268076,"f":2},"n":"{13936797}.LinePosition","o":"System$Xml$IXmlLineInfo$LinePosition","d":3328428,"h":266291300780,"f":2}],"m":[{"r":1310721,"n":"GetLocalName","d":3328428,"h":98787576236,"f":2},{"r":1310721,"n":"GetNamespaceURI","d":3328428,"h":120262412716,"f":2},{"r":1310721,"n":"GetPrefix","d":3328428,"h":150327183788,"f":2},{"r":59287709,"n":"Clone","d":3328428,"h":171802020268,"f":32769},{"r":262145,"p":[{"n":"navigator","p":59287709}],"n":"IsSamePosition","d":3328428,"h":176096987564,"f":32769},{"r":262145,"p":[{"n":"navigator","p":59287709}],"n":"MoveTo","d":3328428,"h":180391954860,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"MoveToAttribute","d":3328428,"h":184686922156,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"MoveToChild","d":3328428,"h":188981889452,"f":32769},{"r":262145,"p":[{"n":"type","p":59877533}],"n":"MoveToChild","o":"@$1","d":3328428,"h":193276856748,"f":32769},{"r":262145,"n":"MoveToFirstAttribute","d":3328428,"h":197571824044,"f":32769},{"r":262145,"n":"MoveToFirstChild","d":3328428,"h":201866791340,"f":32769},{"r":262145,"p":[{"n":"scope","p":59222173}],"n":"MoveToFirstNamespace","d":3328428,"h":206161758636,"f":32769},{"r":262145,"p":[{"n":"id","p":1310721}],"n":"MoveToId","d":3328428,"h":210456725932,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721}],"n":"MoveToNamespace","d":3328428,"h":214751693228,"f":32769},{"r":262145,"n":"MoveToNext","d":3328428,"h":219046660524,"f":32769},{"r":262145,"p":[{"n":"localName","p":1310721},{"n":"namespaceName","p":1310721}],"n":"MoveToNext","o":"@$1","d":3328428,"h":223341627820,"f":32769},{"r":262145,"p":[{"n":"type","p":59877533}],"n":"MoveToNext","o":"@$2","d":3328428,"h":227636595116,"f":32769},{"r":262145,"n":"MoveToNextAttribute","d":3328428,"h":231931562412,"f":32769},{"r":262145,"p":[{"n":"scope","p":59222173}],"n":"MoveToNextNamespace","d":3328428,"h":236226529708,"f":32769},{"r":262145,"n":"MoveToParent","d":3328428,"h":240521497004,"f":32769},{"r":262145,"n":"MoveToPrevious","d":3328428,"h":244816464300,"f":32769},{"r":53389469,"n":"ReadSubtree","d":3328428,"h":249111431596,"f":32769},{"r":1310721,"p":[{"n":"n","p":3000748}],"n":"CollectText","d":3328428,"h":274881235372,"f":34},{"r":14264477,"n":"CreateNameTable","d":3328428,"h":279176202668,"f":34},{"r":262145,"p":[{"n":"c","p":1362348},{"n":"n","p":2279852}],"n":"IsContent","d":3328428,"h":283471169964,"f":34},{"r":262145,"p":[{"n":"n1","p":3328428},{"n":"n2","p":3328428}],"n":"IsSamePosition","o":"@$1","d":3328428,"h":287766137260,"f":34},{"r":262145,"p":[{"n":"a","p":1165740}],"n":"IsXmlNamespaceDeclaration","d":3328428,"h":292061104556,"f":34},{"r":655361,"p":[{"n":"type","p":59877533}],"n":"GetElementContentMask","d":3328428,"h":296356071852,"f":34},{"r":1165740,"p":[{"n":"e","p":1690028}],"n":"GetFirstNamespaceDeclarationGlobal","d":3328428,"h":300651039148,"f":34},{"r":1165740,"p":[{"n":"e","p":1690028}],"n":"GetFirstNamespaceDeclarationLocal","d":3328428,"h":304946006444,"f":34},{"r":1165740,"p":[{"n":"a","p":1165740}],"n":"GetNextNamespaceDeclarationGlobal","d":3328428,"h":309240973740,"f":34},{"r":1165740,"p":[{"n":"a","p":1165740}],"n":"GetNextNamespaceDeclarationLocal","d":3328428,"h":313535941036,"f":34},{"r":1165740,"n":"GetXmlNamespaceDeclaration","d":3328428,"h":317830908332,"f":34},{"r":262145,"p":[{"n":"a","p":1165740},{"n":"e","p":1690028}],"n":"HasNamespaceDeclarationInScope","d":3328428,"h":322125875628,"f":34}],"l":[{"t":1310721,"n":"xmlPrefixNamespace","d":3328428,"h":4298295724,"f":40},{"t":1310721,"n":"xmlnsPrefixNamespace","d":3328428,"h":8593263020,"f":40},{"t":655361,"n":"DocumentContentMask","d":3328428,"h":12888230316,"f":34},{"t":655361,"n":"TextMask","d":3328428,"h":25773132204,"f":34},{"t":1165740,"n":"s_XmlNamespaceDeclaration","d":3328428,"h":30068099500,"f":34},{"t":2607532,"n":"_source","d":3328428,"h":34363066796,"f":2},{"t":1690028,"n":"_parent","d":3328428,"h":38658034092,"f":2},{"t":52078749,"n":"_nameTable","d":3328428,"h":42953001388,"f":2}],"c":[{"p":[{"n":"node","p":2279852},{"n":"nameTable","p":52078749}],"n":".ctor","o":"$ctor$3","d":3328428,"h":47247968684,"f":1},{"p":[{"n":"other","p":3328428}],"n":".ctor","o":"$ctor$4","d":3328428,"h":51542935980,"f":1}],"i":[57212929,58566813,14002333,13936797],"h":3328428}; }
            static get $b() { return $.$spx.System.Xml.XPath.XPathNavigator; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spx.System.Xml.XPath.IXPathNavigable, $.$spx.System.Xml.IXmlNamespaceResolver, $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.XPath.XNodeNavigator`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XDocument", ($self) => class XDocument extends $.$spxl.System.Xml.Linq.XContainer
        {
            /*XDeclaration?*/ _declaration = null;
            $ctor$5()
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            $ctor$6(/*params object?[]*/ content)
            {
                this.$ctor$5();
                {
                    this.AddContentSkipNotify(content);
                }
                return this;
            }
            $ctor$7(/*XDeclaration?*/ declaration, /*params object?[]*/ content)
            {
                this.$ctor$6(content);
                {
                    this._declaration = declaration;
                }
                return this;
            }
            $ctor$8(/*XDocument*/ other)
            {
                super.$ctor$4(other);
                {
                    if (other._declaration !== null)
                    {
                        this._declaration = new $.$spxl.System.Xml.Linq.XDeclaration().$ctor$2(other._declaration);
                    }
                }
                return this;
            }
            /*XDeclaration? */ get Declaration()
            {
                return this._declaration;
            }
            /*XDeclaration? */ set Declaration(value)
            {
                this._declaration = value;
            }
            /*XDocumentType? */ get DocumentType()
            {
                return this.GetFirstNode($.$spxl.System.Xml.Linq.XDocumentType);
            }
            /*XmlNodeType */ get NodeType()
            {
                return 9/*XmlNodeType.Document*/;
            }
            /*XElement? */ get Root()
            {
                return this.GetFirstNode($.$spxl.System.Xml.Linq.XElement);
            }
            static /*XDocument */ Load(/*string*/ uri)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Load$1(uri, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Load$1(/*string*/ uri, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$1(uri, rs);
                    return $.$spxl.System.Xml.Linq.XDocument.Load$7(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*XDocument */ Load$2(/*Stream*/ stream)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Load$3(stream, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Load$3(/*Stream*/ stream, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$4(stream, rs);
                    return $.$spxl.System.Xml.Linq.XDocument.Load$7(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*Task<XDocument> *//*async*/  LoadAsync(/*Stream*/ stream, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument), $.$spxl.System.Xml.Linq.XDocument, async () => 
                {
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$4(stream, rs);
                        return await $.$spxl.System.Xml.Linq.XDocument.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*XDocument */ Load$4(/*TextReader*/ textReader)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Load$5(textReader, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Load$5(/*TextReader*/ textReader, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$8(textReader, rs);
                    return $.$spxl.System.Xml.Linq.XDocument.Load$7(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*Task<XDocument> *//*async*/  LoadAsync$1(/*TextReader*/ textReader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument), $.$spxl.System.Xml.Linq.XDocument, async () => 
                {
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$8(textReader, rs);
                        return await $.$spxl.System.Xml.Linq.XDocument.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*XDocument */ Load$6(/*XmlReader*/ reader)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Load$7(reader, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Load$7(/*XmlReader*/ reader, /*LoadOptions*/ options)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                if (reader.ReadState === 0/*ReadState.Initial*/)
                {
                    reader.Read();
                }
                /*XDocument*/ let d = $.$spxl.System.Xml.Linq.XDocument.InitLoad(reader, options);
                d.ReadContentFrom$1(reader, options);
                if (!reader.EOF)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                }
                if (d.Root === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingRoot);
                }
                return d;
            }
            static /*Task<XDocument> */ LoadAsync$2(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spxl.System.Xml.Linq.XDocument, cancellationToken);
                }
                return $.$spxl.System.Xml.Linq.XDocument.LoadAsyncInternal(reader, options, cancellationToken);
            }
            static /*Task<XDocument> *//*async*/  LoadAsyncInternal(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument), $.$spxl.System.Xml.Linq.XDocument, async () => 
                {
                    if (reader.ReadState === 0/*ReadState.Initial*/)
                    {
                        await reader.ReadAsync().ConfigureAwait$2(false);
                    }
                    /*XDocument*/ let d = $.$spxl.System.Xml.Linq.XDocument.InitLoad(reader, options);
                    await d.ReadContentFromAsync$1(reader, options, cancellationToken).ConfigureAwait(false);
                    if (!reader.EOF)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                    }
                    if (d.Root === null)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_MissingRoot);
                    }
                    return d;
                });
            }
            static /*XDocument */ InitLoad(/*XmlReader*/ reader, /*LoadOptions*/ options)
            {
                /*XDocument*/ let d = new $.$spxl.System.Xml.Linq.XDocument().$ctor$5();
                if ((options & 2/*LoadOptions.SetBaseUri*/) !== 0)
                {
                    /*string?*/ let baseUri = reader.BaseURI;
                    if (!$.$spc.System.String.IsNullOrEmpty(baseUri))
                    {
                        d.SetBaseUri(baseUri);
                    }
                }
                if ((options & 4/*LoadOptions.SetLineInfo*/) !== 0)
                {
                    /*IXmlLineInfo?*/ let li = $.$as(reader, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null && li.System$Xml$IXmlLineInfo$HasLineInfo())
                    {
                        d.SetLineInfo(li.System$Xml$IXmlLineInfo$LineNumber, li.System$Xml$IXmlLineInfo$LinePosition);
                    }
                }
                if (reader.NodeType === 17/*XmlNodeType.XmlDeclaration*/)
                {
                    d.Declaration = new $.$spxl.System.Xml.Linq.XDeclaration().$ctor$3(reader);
                }
                return d;
            }
            static /*XDocument */ Parse(/*string*/ text)
            {
                return $.$spxl.System.Xml.Linq.XDocument.Parse$1(text, 0/*LoadOptions.None*/);
            }
            static /*XDocument */ Parse$1(/*string*/ text, /*LoadOptions*/ options)
            {
                let sr = null;
                try
                {
                    sr = new $.$spc.System.IO.StringReader().$ctor$3(text);
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$8(sr, rs);
                        return $.$spxl.System.Xml.Linq.XDocument.Load$7(r, options);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                }
                finally
                {
                    sr?.System$IDisposable$Dispose();
                }
            }
            /*void */ Save(/*Stream*/ stream)
            {
                this.Save$1(stream, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save$1(/*Stream*/ stream, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                if (this._declaration !== null && !$.$spc.System.String.IsNullOrEmpty(this._declaration.Encoding))
                {
                    try
                    {
                        ws.Encoding = $.$spc.System.Text.Encoding.GetEncoding$2(this._declaration.Encoding);
                    }
                    catch($e)
                    {
                    }
                }
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$3(stream, ws);
                    this.Save$4(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*Task *//*async*/  SaveAsync(/*Stream*/ stream, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    if (this._declaration !== null && !$.$spc.System.String.IsNullOrEmpty(this._declaration.Encoding))
                    {
                        try
                        {
                            ws.Encoding = $.$spc.System.Text.Encoding.GetEncoding$2(this._declaration.Encoding);
                        }
                        catch($e)
                        {
                        }
                    }
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create$3(stream, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$spc.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.WriteToAsync(w, cancellationToken).ConfigureAwait(false);
                        await w.FlushAsync().ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            /*void */ Save$2(/*TextWriter*/ textWriter)
            {
                this.Save$3(textWriter, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save$3(/*TextWriter*/ textWriter, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$5(textWriter, ws);
                    this.Save$4(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*void */ Save$4(/*XmlWriter*/ writer)
            {
                this.WriteTo(writer);
            }
            /*Task *//*async*/  SaveAsync$1(/*TextWriter*/ textWriter, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create$5(textWriter, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$spc.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.WriteToAsync(w, cancellationToken).ConfigureAwait(false);
                        await w.FlushAsync().ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            /*void */ Save$5(/*string*/ fileName)
            {
                this.Save$6(fileName, this.GetSaveOptionsFromAnnotations());
            }
            /*Task */ SaveAsync$2(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return this.WriteToAsync(writer, cancellationToken);
            }
            /*void */ Save$6(/*string*/ fileName, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                if (this._declaration !== null && !$.$spc.System.String.IsNullOrEmpty(this._declaration.Encoding))
                {
                    try
                    {
                        ws.Encoding = $.$spc.System.Text.Encoding.GetEncoding$2(this._declaration.Encoding);
                    }
                    catch($e)
                    {
                    }
                }
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$1(fileName, ws);
                    this.Save$4(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (this._declaration !== null && $.$spc.System.String.op_Equality(this._declaration.Standalone, "yes"))
                {
                    writer.WriteStartDocument$1(true);
                }
                else if (this._declaration !== null && $.$spc.System.String.op_Equality(this._declaration.Standalone, "no"))
                {
                    writer.WriteStartDocument$1(false);
                }
                else 
                {
                    writer.WriteStartDocument();
                }
                this.WriteContentTo(writer);
                writer.WriteEndDocument();
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return this.WriteToAsyncInternal(writer, cancellationToken);
            }
            /*Task *//*async*/  WriteToAsyncInternal(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*Task*/ let tStart;
                    if (this._declaration !== null && $.$spc.System.String.op_Equality(this._declaration.Standalone, "yes"))
                    {
                        tStart = writer.WriteStartDocumentAsync$1(true);
                    }
                    else if (this._declaration !== null && $.$spc.System.String.op_Equality(this._declaration.Standalone, "no"))
                    {
                        tStart = writer.WriteStartDocumentAsync$1(false);
                    }
                    else 
                    {
                        tStart = writer.WriteStartDocumentAsync();
                    }
                    await tStart.ConfigureAwait(false);
                    await this.WriteContentToAsync(writer, cancellationToken).ConfigureAwait(false);
                    await writer.WriteEndDocumentAsync().ConfigureAwait(false);
                });
            }
            /*void */ AddAttribute(/*XAttribute*/ a)
            {
                throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_AddAttribute);
            }
            /*void */ AddAttributeSkipNotify(/*XAttribute*/ a)
            {
                throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_AddAttribute);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XDocument().$ctor$8(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XDocument?*/ let other = $.$as(node, $.$spxl.System.Xml.Linq.XDocument);
                return other !== null && this.ContentsEqual(other);
            }
            /*int */ GetDeepHashCode()
            {
                return this.ContentsHashCode();
            }
            /*T? */ GetFirstNode(T)
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        n = n.next;
                        /*T?*/ let e = $.$as(n, T);
                        if ($.$box(e, T) !== null)
                        {
                            return e;
                        }
                    }
                    while(n !== this.content);
                }
                return null;
            }
            /*void */ ValidateNode(/*XNode*/ node, /*XNode?*/ previous)
            {
                let $switch1 = node.NodeType;
                switch($switch1)
                {
                    case 3/*XmlNodeType.Text*/:
                    this.ValidateString(($.$cast(node, $.$spxl.System.Xml.Linq.XText)).Value);
                    break;
                    case 1/*XmlNodeType.Element*/:
                    this.ValidateDocument(previous, 10/*XmlNodeType.DocumentType*/, 0/*XmlNodeType.None*/);
                    break;
                    case 10/*XmlNodeType.DocumentType*/:
                    this.ValidateDocument(previous, 0/*XmlNodeType.None*/, 1/*XmlNodeType.Element*/);
                    break;
                    case 4/*XmlNodeType.CDATA*/:
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_AddNode, $.$box(4/*XmlNodeType.CDATA*/, $.$spx.System.Xml.XmlNodeType)));
                    case 9/*XmlNodeType.Document*/:
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_AddNode, $.$box(9/*XmlNodeType.Document*/, $.$spx.System.Xml.XmlNodeType)));
                }
            }
            /*void */ ValidateDocument(/*XNode?*/ previous, /*XmlNodeType*/ allowBefore, /*XmlNodeType*/ allowAfter)
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    if (previous === null)
                    {
                        allowBefore = allowAfter;
                    }
                    do
                    {
                        n = n.next;
                        /*XmlNodeType*/ let nt = n.NodeType;
                        if (nt === 1/*XmlNodeType.Element*/ || nt === 10/*XmlNodeType.DocumentType*/)
                        {
                            if (nt !== allowBefore)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_DocumentStructure);
                            }
                            allowBefore = 0/*XmlNodeType.None*/;
                        }
                        if (n === previous)
                        {
                            allowBefore = allowAfter;
                        }
                    }
                    while(n !== this.content);
                }
            }
            /*void */ ValidateString(/*string*/ s)
            {
                if ($.$spc.System.MemoryExtensions.ContainsAnyExcept$11($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(s), $.$spc.System.String.op_Implicit(" \t\r\n")))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Argument_AddNonWhitespace);
                }
            }
            static $h = 1558956;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1362348,"p":[{"p":1493420,"g":{"r":0,"d":0,"h":30066330028,"f":1},"s":{"r":0,"d":0,"h":34361297324,"f":1},"n":"Declaration","d":1558956,"h":25771362732,"f":1},{"p":1624492,"g":{"r":0,"d":0,"h":42951231916,"f":1},"n":"DocumentType","d":1558956,"h":38656264620,"f":1},{"p":52865181,"g":{"r":0,"d":0,"h":51541166508,"f":32769},"n":"NodeType","d":1558956,"h":47246199212,"f":32769},{"p":1690028,"g":{"r":0,"d":0,"h":60131101100,"f":1},"n":"Root","d":1558956,"h":55836133804,"f":1}],"m":[{"r":1558956,"p":[{"n":"uri","p":1310721}],"n":"Load","d":1558956,"h":64426068396,"f":33},{"r":1558956,"p":[{"n":"uri","p":1310721},{"n":"options","p":706988}],"n":"Load","o":"@$1","d":1558956,"h":68721035692,"f":33},{"r":1558956,"p":[{"n":"stream","p":62193665}],"n":"Load","o":"@$2","d":1558956,"h":73016002988,"f":33},{"r":1558956,"p":[{"n":"stream","p":62193665},{"n":"options","p":706988}],"n":"Load","o":"@$3","d":1558956,"h":77310970284,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,"p":[{"n":"stream","p":62193665},{"n":"options","p":706988},{"n":"cancellationToken","p":125960193}],"n":"LoadAsync","d":1558956,"h":81605937580,"f":4129},{"r":1558956,"p":[{"n":"textReader","p":62914561}],"n":"Load","o":"@$4","d":1558956,"h":85900904876,"f":33},{"r":1558956,"p":[{"n":"textReader","p":62914561},{"n":"options","p":706988}],"n":"Load","o":"@$5","d":1558956,"h":90195872172,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,"p":[{"n":"textReader","p":62914561},{"n":"options","p":706988},{"n":"cancellationToken","p":125960193}],"n":"LoadAsync","o":"@$1","d":1558956,"h":94490839468,"f":4129},{"r":1558956,"p":[{"n":"reader","p":53389469}],"n":"Load","o":"@$6","d":1558956,"h":98785806764,"f":33},{"r":1558956,"p":[{"n":"reader","p":53389469},{"n":"options","p":706988}],"n":"Load","o":"@$7","d":1558956,"h":103080774060,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,"p":[{"n":"reader","p":53389469},{"n":"options","p":706988},{"n":"cancellationToken","p":125960193}],"n":"LoadAsync","o":"@$2","d":1558956,"h":107375741356,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XDocument).$h,"p":[{"n":"reader","p":53389469},{"n":"options","p":706988},{"n":"cancellationToken","p":125960193}],"n":"LoadAsyncInternal","d":1558956,"h":111670708652,"f":4130},{"r":1558956,"p":[{"n":"reader","p":53389469},{"n":"options","p":706988}],"n":"InitLoad","d":1558956,"h":115965675948,"f":34},{"r":1558956,"p":[{"n":"text","p":1310721}],"n":"Parse","d":1558956,"h":120260643244,"f":33},{"r":1558956,"p":[{"n":"text","p":1310721},{"n":"options","p":706988}],"n":"Parse","o":"@$1","d":1558956,"h":124555610540,"f":33},{"r":65537,"p":[{"n":"stream","p":62193665}],"n":"Save","d":1558956,"h":128850577836,"f":1},{"r":65537,"p":[{"n":"stream","p":62193665},{"n":"options","p":1034668}],"n":"Save","o":"@$1","d":1558956,"h":133145545132,"f":1},{"r":133300225,"p":[{"n":"stream","p":62193665},{"n":"options","p":1034668},{"n":"cancellationToken","p":125960193}],"n":"SaveAsync","d":1558956,"h":137440512428,"f":4097},{"r":65537,"p":[{"n":"textWriter","p":63045633}],"n":"Save","o":"@$2","d":1558956,"h":141735479724,"f":1},{"r":65537,"p":[{"n":"textWriter","p":63045633},{"n":"options","p":1034668}],"n":"Save","o":"@$3","d":1558956,"h":146030447020,"f":1},{"r":65537,"p":[{"n":"writer","p":58435741}],"n":"Save","o":"@$4","d":1558956,"h":150325414316,"f":1},{"r":133300225,"p":[{"n":"textWriter","p":63045633},{"n":"options","p":1034668},{"n":"cancellationToken","p":125960193}],"n":"SaveAsync","o":"@$1","d":1558956,"h":154620381612,"f":4097},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"Save","o":"@$5","d":1558956,"h":158915348908,"f":1},{"r":133300225,"p":[{"n":"writer","p":58435741},{"n":"cancellationToken","p":125960193}],"n":"SaveAsync","o":"@$2","d":1558956,"h":163210316204,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"options","p":1034668}],"n":"Save","o":"@$6","d":1558956,"h":167505283500,"f":1},{"r":65537,"p":[{"n":"writer","p":58435741}],"n":"WriteTo","d":1558956,"h":171800250796,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58435741},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":1558956,"h":176095218092,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58435741},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsyncInternal","d":1558956,"h":180390185388,"f":4098},{"r":65537,"p":[{"n":"a","p":1165740}],"n":"AddAttribute","d":1558956,"h":184685152684,"f":32776},{"r":65537,"p":[{"n":"a","p":1165740}],"n":"AddAttributeSkipNotify","d":1558956,"h":188980119980,"f":32776},{"r":2279852,"n":"CloneNode","d":1558956,"h":193275087276,"f":32776},{"r":262145,"p":[{"n":"node","p":2279852}],"n":"DeepEquals","o":"@$1","d":1558956,"h":197570054572,"f":32776},{"r":655361,"n":"GetDeepHashCode","d":1558956,"h":201865021868,"f":32776},{"r":(T) => T.$h,"g":["T"],"n":"GetFirstNode","d":1558956,"h":206159989164,"f":131074},{"r":65537,"p":[{"n":"node","p":2279852},{"n":"previous","p":2279852}],"n":"ValidateNode","d":1558956,"h":210454956460,"f":32776},{"r":65537,"p":[{"n":"previous","p":2279852},{"n":"allowBefore","p":52865181},{"n":"allowAfter","p":52865181}],"n":"ValidateDocument","d":1558956,"h":214749923756,"f":2},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"ValidateString","d":1558956,"h":219044891052,"f":32776}],"l":[{"t":1493420,"n":"_declaration","d":1558956,"h":4296526252,"f":2}],"c":[{"n":".ctor","o":"$ctor$5","d":1558956,"h":8591493548,"f":1},{"p":[{"n":"content","p":0,"f":16}],"n":".ctor","o":"$ctor$6","d":1558956,"h":12886460844,"f":1},{"p":[{"n":"declaration","p":1493420},{"n":"content","p":0,"f":16}],"n":".ctor","o":"$ctor$7","d":1558956,"h":17181428140,"f":1},{"p":[{"n":"other","p":1558956}],"n":".ctor","o":"$ctor$8","d":1558956,"h":21476395436,"f":1}],"i":[13936797],"h":1558956}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XContainer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XDocument`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XElement", ($self) => class XElement extends $.$spxl.System.Xml.Linq.XContainer
        {
            static /*IEnumerable<XElement> */ get EmptySequence()
            {
                return $.$spc.System.Array.Empty($.$spxl.System.Xml.Linq.XElement);
            }
            /*XName*/ name = null;
            /*XAttribute?*/ lastAttr = null;
            $ctor$5(/*XName*/ name)
            {
                super.$ctor$3();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                    this.name = name;
                }
                return this;
            }
            $ctor$6(/*XName*/ name, /*object?*/ content)
            {
                this.$ctor$5(name);
                {
                    this.AddContentSkipNotify(content);
                }
                return this;
            }
            $ctor$7(/*XName*/ name, /*params object?[]*/ content)
            {
                this.$ctor$6(name, $.$cast(content, $.$spc.System.Object));
                {
                }
                return this;
            }
            $ctor$8(/*XElement*/ other)
            {
                super.$ctor$4(other);
                {
                    this.name = other.name;
                    /*XAttribute?*/ let a = other.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            this.AppendAttributeSkipNotify(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(a));
                        }
                        while(a !== other.lastAttr);
                    }
                }
                return this;
            }
            $ctor$9(/*XStreamingElement*/ other)
            {
                super.$ctor$3();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                    this.name = other.name;
                    this.AddContentSkipNotify(other.content);
                }
                return this;
            }
            $ctor$10()
            {
                this.$ctor$5($.$spxl.System.Xml.Linq.XName.op_Implicit($.$default()));
                {
                }
                return this;
            }
            $ctor$11(/*XmlReader*/ r)
            {
                this.$ctor$13(r, 0/*LoadOptions.None*/);
                {
                }
                return this;
            }
            $ctor$12(/*AsyncConstructionSentry*/ _)
            {
                super.$ctor$3();
                {
                }
                return this;
            }
            static $_AsyncConstructionSentry;
            static get AsyncConstructionSentry()
            {
                let $cls = $.$spxl.System.Xml.Linq.XElement;
                return $cls.$_AsyncConstructionSentry ??= $asm.$nstr("$spxl.System.Xml.Linq.XElement.AsyncConstructionSentry", ($self) => class AsyncConstructionSentry extends $.$spc.System.ValueType
                {
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        return copy;
                    }
                    static $h = 1755564;
                    static $z = 0;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"c":[{"n":".ctor","o":"$ctor$2","d":1755564,"h":4296722860,"f":1}],"d":1690028,"h":1755564}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Xml.Linq.XElement.AsyncConstructionSentry`; }
                }, $cls, ($v) => $cls.$_AsyncConstructionSentry = $v);
            }
            $ctor$13(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                super.$ctor$3();
                {
                    this.ReadElementFrom(r, o);
                }
                return this;
            }
            static /*Task<XElement> *//*async*/  CreateAsync(/*XmlReader*/ r, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    /*XElement*/ let xe = new $.$spxl.System.Xml.Linq.XElement().$ctor$12($.$default($.$spxl.System.Xml.Linq.XElement.AsyncConstructionSentry));
                    await xe.ReadElementFromAsync(r, 0/*LoadOptions.None*/, cancellationToken).ConfigureAwait(false);
                    return xe;
                });
            }
            /*void */ Save(/*string*/ fileName)
            {
                this.Save$1(fileName, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save$1(/*string*/ fileName, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$1(fileName, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*XAttribute? */ get FirstAttribute()
            {
                return this.lastAttr?.next;
            }
            /*bool */ get HasAttributes()
            {
                return this.lastAttr !== null;
            }
            /*bool */ get HasElements()
            {
                /*XNode?*/ let n = $.$as(this.content, $.$spxl.System.Xml.Linq.XNode);
                if (n !== null)
                {
                    do
                    {
                        if ($.$is(n, $.$spxl.System.Xml.Linq.XElement))
                        {
                            return true;
                        }
                        n = n.next;
                    }
                    while(n !== this.content);
                }
                return false;
            }
            /*bool */ get IsEmpty()
            {
                return this.content === null;
            }
            /*XAttribute? */ get LastAttribute()
            {
                return this.lastAttr;
            }
            /*XName */ get Name()
            {
                return this.name;
            }
            /*XName */ set Name(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                /*bool*/ let notify = this.NotifyChanging(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                this.name = value;
                if (notify)
                {
                    this.NotifyChanged(this, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Name);
                }
            }
            /*XmlNodeType */ get NodeType()
            {
                return 1/*XmlNodeType.Element*/;
            }
            /*string */ get Value()
            {
                if (this.content === null)
                {
                    return $.$spc.System.String.Empty;
                }
                /*string?*/ let s = $.$as(this.content, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(s, null))
                {
                    return s;
                }
                /*StringBuilder*/ let sb = $.$spxl.System.Text.StringBuilderCache.Acquire(16);
                this.AppendText(sb);
                return $.$spxl.System.Text.StringBuilderCache.GetStringAndRelease(sb);
            }
            /*string */ set Value(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                this.RemoveNodes();
                this.Add(value);
            }
            /*IEnumerable<XElement> */ AncestorsAndSelf()
            {
                return this.GetAncestors(null, true);
            }
            /*IEnumerable<XElement> */ AncestorsAndSelf$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetAncestors(name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*XAttribute? */ Attribute(/*XName*/ name)
            {
                /*XAttribute?*/ let a = this.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        if ($.$spxl.System.Xml.Linq.XName.op_Equality(a.name, name))
                        {
                            return a;
                        }
                    }
                    while(a !== this.lastAttr);
                }
                return null;
            }
            /*IEnumerable<XAttribute> */ Attributes()
            {
                return this.GetAttributes(null);
            }
            /*IEnumerable<XAttribute> */ Attributes$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetAttributes(name) : $.$spxl.System.Xml.Linq.XAttribute.EmptySequence;
            }
            /*IEnumerable<XNode> */ DescendantNodesAndSelf()
            {
                return this.GetDescendantNodes(true);
            }
            /*IEnumerable<XElement> */ DescendantsAndSelf()
            {
                return this.GetDescendants(null, true);
            }
            /*IEnumerable<XElement> */ DescendantsAndSelf$1(/*XName?*/ name)
            {
                return $.$spxl.System.Xml.Linq.XName.op_Inequality(name, null) ? this.GetDescendants(name, true) : $.$spxl.System.Xml.Linq.XElement.EmptySequence;
            }
            /*XNamespace */ GetDefaultNamespace()
            {
                /*string?*/ let namespaceName = this.GetNamespaceOfPrefixInScope("xmlns", null);
                return $.$spc.System.String.op_Inequality(namespaceName, null) ? $.$spxl.System.Xml.Linq.XNamespace.Get(namespaceName) : $.$spxl.System.Xml.Linq.XNamespace.None;
            }
            /*XNamespace? */ GetNamespaceOfPrefix(/*string*/ prefix)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(prefix, "prefix");
                if ($.$spc.System.String.op_Equality(prefix, "xmlns"))
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.Xmlns;
                }
                /*string?*/ let namespaceName = this.GetNamespaceOfPrefixInScope(prefix, null);
                if ($.$spc.System.String.op_Inequality(namespaceName, null))
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.Get(namespaceName);
                }
                if ($.$spc.System.String.op_Equality(prefix, "xml"))
                {
                    return $.$spxl.System.Xml.Linq.XNamespace.Xml;
                }
                return null;
            }
            /*string? */ GetPrefixOfNamespace(/*XNamespace*/ ns)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(ns, "ns");
                /*string*/ let namespaceName = ns.NamespaceName;
                /*bool*/ let hasInScopeNamespace = false;
                /*XElement?*/ let e = this;
                do
                {
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        /*bool*/ let hasLocalNamespace = false;
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration)
                            {
                                if ($.$spc.System.String.op_Equality(a.Value, namespaceName))
                                {
                                    if (a.Name.NamespaceName.length !== 0 && (!hasInScopeNamespace || $.$spc.System.String.op_Equality(this.GetNamespaceOfPrefixInScope(a.Name.LocalName, e), null)))
                                    {
                                        return a.Name.LocalName;
                                    }
                                }
                                hasLocalNamespace = true;
                            }
                        }
                        while(a !== e.lastAttr);
                        hasInScopeNamespace = $.$spc.System.Boolean.op_BitwiseOr(hasInScopeNamespace, hasLocalNamespace);
                    }
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                while(e !== null);
                if (namespaceName === "http://www.w3.org/XML/1998/namespace"/*XNamespace.xmlPrefixNamespace*/)
                {
                    if (!hasInScopeNamespace || $.$spc.System.String.op_Equality(this.GetNamespaceOfPrefixInScope("xml", null), null))
                    {
                        return "xml";
                    }
                }
                else if (namespaceName === "http://www.w3.org/2000/xmlns/"/*XNamespace.xmlnsPrefixNamespace*/)
                {
                    return "xmlns";
                }
                return null;
            }
            static /*XElement */ Load(/*string*/ uri)
            {
                return $.$spxl.System.Xml.Linq.XElement.Load$1(uri, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Load$1(/*string*/ uri, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$1(uri, rs);
                    return $.$spxl.System.Xml.Linq.XElement.Load$7(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*XElement */ Load$2(/*Stream*/ stream)
            {
                return $.$spxl.System.Xml.Linq.XElement.Load$3(stream, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Load$3(/*Stream*/ stream, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$4(stream, rs);
                    return $.$spxl.System.Xml.Linq.XElement.Load$7(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*Task<XElement> *//*async*/  LoadAsync(/*Stream*/ stream, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$4(stream, rs);
                        return await $.$spxl.System.Xml.Linq.XElement.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*XElement */ Load$4(/*TextReader*/ textReader)
            {
                return $.$spxl.System.Xml.Linq.XElement.Load$5(textReader, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Load$5(/*TextReader*/ textReader, /*LoadOptions*/ options)
            {
                /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                let r = null;
                try
                {
                    r = $.$spx.System.Xml.XmlReader.Create$8(textReader, rs);
                    return $.$spxl.System.Xml.Linq.XElement.Load$7(r, options);
                }
                finally
                {
                    r?.System$IDisposable$Dispose();
                }
            }
            static /*Task<XElement> *//*async*/  LoadAsync$1(/*TextReader*/ textReader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    rs.Async = true;
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$8(textReader, rs);
                        return await $.$spxl.System.Xml.Linq.XElement.LoadAsync$2(r, options, cancellationToken).ConfigureAwait$2(false);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*XElement */ Load$6(/*XmlReader*/ reader)
            {
                return $.$spxl.System.Xml.Linq.XElement.Load$7(reader, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Load$7(/*XmlReader*/ reader, /*LoadOptions*/ options)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                if (reader.MoveToContent() !== 1/*XmlNodeType.Element*/)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format$1($.$spxl.System.SR.InvalidOperation_ExpectedNodeType, $.$box(1/*XmlNodeType.Element*/, $.$spx.System.Xml.XmlNodeType), $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                }
                /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$13(reader, options);
                reader.MoveToContent();
                if (!reader.EOF)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                }
                return e;
            }
            static /*Task<XElement> */ LoadAsync$2(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spxl.System.Xml.Linq.XElement, cancellationToken);
                }
                return $.$spxl.System.Xml.Linq.XElement.LoadAsyncInternal(reader, options, cancellationToken);
            }
            static /*Task<XElement> *//*async*/  LoadAsyncInternal(/*XmlReader*/ reader, /*LoadOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement), $.$spxl.System.Xml.Linq.XElement, async () => 
                {
                    if (await reader.MoveToContentAsync().ConfigureAwait$2(false) !== 1/*XmlNodeType.Element*/)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format$1($.$spxl.System.SR.InvalidOperation_ExpectedNodeType, $.$box(1/*XmlNodeType.Element*/, $.$spx.System.Xml.XmlNodeType), $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                    }
                    /*XElement*/ let e = new $.$spxl.System.Xml.Linq.XElement().$ctor$12($.$default($.$spxl.System.Xml.Linq.XElement.AsyncConstructionSentry));
                    await e.ReadElementFromAsync(reader, options, cancellationToken).ConfigureAwait(false);
                    cancellationToken.ThrowIfCancellationRequested();
                    await reader.MoveToContentAsync().ConfigureAwait$2(false);
                    if (!reader.EOF)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedEndOfFile);
                    }
                    return e;
                });
            }
            static /*XElement */ Parse(/*string*/ text)
            {
                return $.$spxl.System.Xml.Linq.XElement.Parse$1(text, 0/*LoadOptions.None*/);
            }
            static /*XElement */ Parse$1(/*string*/ text, /*LoadOptions*/ options)
            {
                let sr = null;
                try
                {
                    sr = new $.$spc.System.IO.StringReader().$ctor$3(text);
                    /*XmlReaderSettings*/ let rs = $.$spxl.System.Xml.Linq.XNode.GetXmlReaderSettings(options);
                    let r = null;
                    try
                    {
                        r = $.$spx.System.Xml.XmlReader.Create$8(sr, rs);
                        return $.$spxl.System.Xml.Linq.XElement.Load$7(r, options);
                    }
                    finally
                    {
                        r?.System$IDisposable$Dispose();
                    }
                }
                finally
                {
                    sr?.System$IDisposable$Dispose();
                }
            }
            /*void */ RemoveAll()
            {
                this.RemoveAttributes();
                this.RemoveNodes();
            }
            /*void */ RemoveAttributes()
            {
                if (this.SkipNotify())
                {
                    this.RemoveAttributesSkipNotify();
                    return;
                }
                while(this.lastAttr !== null)
                {
                    /*XAttribute*/ let a = this.lastAttr.next;
                    this.NotifyChanging(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                    if (this.lastAttr === null || a !== this.lastAttr.next)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                    }
                    if (a !== this.lastAttr)
                    {
                        this.lastAttr.next = a.next;
                    }
                    else 
                    {
                        this.lastAttr = null;
                    }
                    a.parent = null;
                    a.next = null;
                    this.NotifyChanged(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                }
            }
            /*void */ ReplaceAll(/*object?*/ content)
            {
                content = $.$spxl.System.Xml.Linq.XContainer.GetContentSnapshot(content);
                this.RemoveAll();
                this.Add(content);
            }
            /*void */ ReplaceAll$1(/*params object?[]*/ content)
            {
                this.ReplaceAll($.$cast(content, $.$spc.System.Object));
            }
            /*void */ ReplaceAttributes(/*object?*/ content)
            {
                content = $.$spxl.System.Xml.Linq.XContainer.GetContentSnapshot(content);
                this.RemoveAttributes();
                this.Add(content);
            }
            /*void */ ReplaceAttributes$1(/*params object?[]*/ content)
            {
                this.ReplaceAttributes($.$cast(content, $.$spc.System.Object));
            }
            /*void */ Save$2(/*Stream*/ stream)
            {
                this.Save$3(stream, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save$3(/*Stream*/ stream, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$3(stream, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*Task *//*async*/  SaveAsync(/*Stream*/ stream, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create$3(stream, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$spc.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.SaveAsync$2(w, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            /*void */ Save$4(/*TextWriter*/ textWriter)
            {
                this.Save$5(textWriter, this.GetSaveOptionsFromAnnotations());
            }
            /*void */ Save$5(/*TextWriter*/ textWriter, /*SaveOptions*/ options)
            {
                /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                let w = null;
                try
                {
                    w = $.$spx.System.Xml.XmlWriter.Create$5(textWriter, ws);
                    this.Save$6(w);
                }
                finally
                {
                    w?.System$IDisposable$Dispose();
                }
            }
            /*Task *//*async*/  SaveAsync$1(/*TextWriter*/ textWriter, /*SaveOptions*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*XmlWriterSettings*/ let ws = $.$spxl.System.Xml.Linq.XNode.GetXmlWriterSettings(options);
                    ws.Async = true;
                    /*XmlWriter*/ let w = $.$spx.System.Xml.XmlWriter.Create$5(textWriter, ws);
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = $.$spc.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait(w, false);
                        await this.SaveAsync$2(w, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        $disposable1?.Dispose();
                    }
                });
            }
            /*void */ Save$6(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                writer.WriteStartDocument();
                this.WriteTo(writer);
                writer.WriteEndDocument();
            }
            /*Task */ SaveAsync$2(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return this.SaveAsyncInternal(writer, cancellationToken);
            }
            /*Task *//*async*/  SaveAsyncInternal(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await writer.WriteStartDocumentAsync().ConfigureAwait(false);
                    await this.WriteToAsync(writer, cancellationToken).ConfigureAwait(false);
                    cancellationToken.ThrowIfCancellationRequested();
                    await writer.WriteEndDocumentAsync().ConfigureAwait(false);
                });
            }
            /*void */ SetAttributeValue(/*XName*/ name, /*object?*/ value)
            {
                /*XAttribute?*/ let a = this.Attribute(name);
                if (value === null)
                {
                    if (a !== null)
                    {
                        this.RemoveAttribute(a);
                    }
                }
                else 
                {
                    if (a !== null)
                    {
                        a.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
                    }
                    else 
                    {
                        this.AppendAttribute(new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2(name, value));
                    }
                }
            }
            /*void */ SetElementValue(/*XName*/ name, /*object?*/ value)
            {
                /*XElement?*/ let e = this.Element(name);
                if (value === null)
                {
                    if (e !== null)
                    {
                        this.RemoveNode(e);
                    }
                }
                else 
                {
                    if (e !== null)
                    {
                        e.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
                    }
                    else 
                    {
                        this.AddNode(new $.$spxl.System.Xml.Linq.XElement().$ctor$6(name, $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value)));
                    }
                }
            }
            /*void */ SetValue(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                this.Value = $.$spxl.System.Xml.Linq.XContainer.GetStringValue(value);
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                new $.$spxl.System.Xml.Linq.ElementWriter().$ctor$2(writer).WriteElement(this);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return new $.$spxl.System.Xml.Linq.ElementWriter().$ctor$2(writer).WriteElementAsync(this, cancellationToken);
            }
            static /*string? */ op_Explicit(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return element.Value;
            }
            static /*bool */ op_Explicit$1(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$spc.System.String.ToLowerInvariant.call(element.Value));
            }
            static /*bool? */ op_Explicit$2(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToBoolean($.$spc.System.String.ToLowerInvariant.call(element.Value));
            }
            static /*int */ op_Explicit$3(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToInt32(element.Value);
            }
            static /*int? */ op_Explicit$4(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt32(element.Value);
            }
            static /*uint */ op_Explicit$5(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToUInt32(element.Value);
            }
            static /*uint? */ op_Explicit$6(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt32(element.Value);
            }
            static /*long */ op_Explicit$7(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToInt64(element.Value);
            }
            static /*long? */ op_Explicit$8(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToInt64(element.Value);
            }
            static /*ulong */ op_Explicit$9(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToUInt64(element.Value);
            }
            static /*ulong? */ op_Explicit$10(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToUInt64(element.Value);
            }
            static /*float */ op_Explicit$11(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToSingle(element.Value);
            }
            static /*float? */ op_Explicit$12(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToSingle(element.Value);
            }
            static /*double */ op_Explicit$13(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToDouble(element.Value);
            }
            static /*double? */ op_Explicit$14(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDouble(element.Value);
            }
            static /*decimal */ op_Explicit$15(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToDecimal(element.Value);
            }
            static /*decimal? */ op_Explicit$16(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDecimal(element.Value);
            }
            static /*DateTime */ op_Explicit$17(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spc.System.DateTime.Parse$2(element.Value, $.$spc.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            static /*DateTime? */ op_Explicit$18(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spc.System.DateTime.Parse$2(element.Value, $.$spc.System.Globalization.CultureInfo.InvariantCulture, 128/*System.Globalization.DateTimeStyles.RoundtripKind*/);
            }
            static /*DateTimeOffset */ op_Explicit$19(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset(element.Value);
            }
            static /*DateTimeOffset? */ op_Explicit$20(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToDateTimeOffset(element.Value);
            }
            static /*TimeSpan */ op_Explicit$21(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(element.Value);
            }
            static /*TimeSpan? */ op_Explicit$22(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToTimeSpan(element.Value);
            }
            static /*Guid */ op_Explicit$23(/*XElement*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(element, "element");
                return $.$spx.System.Xml.XmlConvert.ToGuid(element.Value);
            }
            static /*Guid? */ op_Explicit$24(/*XElement?*/ element)
            {
                if (element === null)
                {
                    return null;
                }
                return $.$spx.System.Xml.XmlConvert.ToGuid(element.Value);
            }
            /*XmlSchema? */ System$Xml$Serialization$IXmlSerializable$GetSchema()
            {
                return null;
            }
            /*void */ System$Xml$Serialization$IXmlSerializable$ReadXml(/*XmlReader*/ reader)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(reader, "reader");
                if (this.parent !== null || this.annotations !== null || this.content !== null || this.lastAttr !== null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_DeserializeInstance);
                }
                if (reader.MoveToContent() !== 1/*XmlNodeType.Element*/)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.Format$1($.$spxl.System.SR.InvalidOperation_ExpectedNodeType, $.$box(1/*XmlNodeType.Element*/, $.$spx.System.Xml.XmlNodeType), $.$box(reader.NodeType, $.$spx.System.Xml.XmlNodeType)));
                }
                this.ReadElementFrom(reader, 0/*LoadOptions.None*/);
            }
            /*void */ System$Xml$Serialization$IXmlSerializable$WriteXml(/*XmlWriter*/ writer)
            {
                this.WriteTo(writer);
            }
            /*void */ AddAttribute(/*XAttribute*/ a)
            {
                if (this.Attribute(a.Name) !== null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_DuplicateAttribute);
                }
                if (a.parent !== null)
                {
                    a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(a);
                }
                this.AppendAttribute(a);
            }
            /*void */ AddAttributeSkipNotify(/*XAttribute*/ a)
            {
                if (this.Attribute(a.Name) !== null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_DuplicateAttribute);
                }
                if (a.parent !== null)
                {
                    a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$3(a);
                }
                this.AppendAttributeSkipNotify(a);
            }
            /*void */ AppendAttribute(/*XAttribute*/ a)
            {
                /*bool*/ let notify = this.NotifyChanging(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                if (a.parent !== null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                this.AppendAttributeSkipNotify(a);
                if (notify)
                {
                    this.NotifyChanged(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Add);
                }
            }
            /*void */ AppendAttributeSkipNotify(/*XAttribute*/ a)
            {
                a.parent = this;
                if (this.lastAttr === null)
                {
                    a.next = a;
                }
                else 
                {
                    a.next = this.lastAttr.next;
                    this.lastAttr.next = a;
                }
                this.lastAttr = a;
            }
            /*bool */ AttributesEqual(/*XElement*/ e)
            {
                /*XAttribute?*/ let a1 = this.lastAttr;
                /*XAttribute?*/ let a2 = e.lastAttr;
                if (a1 !== null && a2 !== null)
                {
                    do
                    {
                        a1 = a1.next;
                        a2 = a2.next;
                        if ($.$spxl.System.Xml.Linq.XName.op_Inequality(a1.name, a2.name) || $.$spc.System.String.op_Inequality(a1.value, a2.value))
                        {
                            return false;
                        }
                    }
                    while(a1 !== this.lastAttr);
                    return a2 === e.lastAttr;
                }
                return a1 === null && a2 === null;
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XElement().$ctor$8(this);
            }
            /*bool */ DeepEquals$1(/*XNode*/ node)
            {
                /*XElement?*/ let e = $.$as(node, $.$spxl.System.Xml.Linq.XElement);
                return e !== null && $.$spxl.System.Xml.Linq.XName.op_Equality(this.name, e.name) && this.ContentsEqual(e) && this.AttributesEqual(e);
            }
            /*IEnumerable<XAttribute> */ GetAttributes(/*XName?*/ name)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*XAttribute?*/ let a = this.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if ($.$spxl.System.Xml.Linq.XName.op_Equality(name, null) || $.$spxl.System.Xml.Linq.XName.op_Equality(a.name, name))
                            {
                                yield a;
                            }
                        }
                        while(a.parent === this && a !== this.lastAttr);
                    }
                }.bind(this));
            }
            /*string? */ GetNamespaceOfPrefixInScope(/*string*/ prefix, /*XElement?*/ outOfScope)
            {
                /*XElement?*/ let e = this;
                while(e !== outOfScope)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(e !== null, "e != null");
                    /*XAttribute?*/ let a = e.lastAttr;
                    if (a !== null)
                    {
                        do
                        {
                            a = a.next;
                            if (a.IsNamespaceDeclaration && $.$spc.System.String.op_Equality(a.Name.LocalName, prefix))
                            {
                                return a.Value;
                            }
                        }
                        while(a !== e.lastAttr);
                    }
                    e = $.$as(e.parent, $.$spxl.System.Xml.Linq.XElement);
                }
                return null;
            }
            /*int */ GetDeepHashCode()
            {
                /*int*/ let h = $.$spxl.System.Xml.Linq.XName.GetHashCode.call(this.name);
                h ^= this.ContentsHashCode();
                /*XAttribute?*/ let a = this.lastAttr;
                if (a !== null)
                {
                    do
                    {
                        a = a.next;
                        h ^= a.GetDeepHashCode();
                    }
                    while(a !== this.lastAttr);
                }
                return h;
            }
            /*void */ ReadElementFrom(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                this.ReadElementFromImpl(r, o);
                if (!r.IsEmptyElement)
                {
                    r.Read();
                    this.ReadContentFrom$1(r, o);
                }
                r.Read();
            }
            /*Task *//*async*/  ReadElementFromAsync(/*XmlReader*/ r, /*LoadOptions*/ o, /*CancellationToken*/ cancellationTokentoken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.ReadElementFromImpl(r, o);
                    if (!r.IsEmptyElement)
                    {
                        cancellationTokentoken.ThrowIfCancellationRequested();
                        await r.ReadAsync().ConfigureAwait$2(false);
                        await this.ReadContentFromAsync$1(r, o, cancellationTokentoken).ConfigureAwait(false);
                    }
                    cancellationTokentoken.ThrowIfCancellationRequested();
                    await r.ReadAsync().ConfigureAwait$2(false);
                });
            }
            /*void */ ReadElementFromImpl(/*XmlReader*/ r, /*LoadOptions*/ o)
            {
                if (r.ReadState !== 1/*ReadState.Interactive*/)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExpectedInteractive);
                }
                this.name = $.$spxl.System.Xml.Linq.XNamespace.Get(r.NamespaceURI).GetName(r.LocalName);
                if ((o & 2/*LoadOptions.SetBaseUri*/) !== 0)
                {
                    /*string?*/ let baseUri = r.BaseURI;
                    if (!$.$spc.System.String.IsNullOrEmpty(baseUri))
                    {
                        this.SetBaseUri(baseUri);
                    }
                }
                /*IXmlLineInfo?*/ let li = null;
                if ((o & 4/*LoadOptions.SetLineInfo*/) !== 0)
                {
                    li = $.$as(r, $.$spx.System.Xml.IXmlLineInfo);
                    if (li !== null && li.System$Xml$IXmlLineInfo$HasLineInfo())
                    {
                        this.SetLineInfo(li.System$Xml$IXmlLineInfo$LineNumber, li.System$Xml$IXmlLineInfo$LinePosition);
                    }
                }
                if (r.MoveToFirstAttribute())
                {
                    do
                    {
                        /*XAttribute*/ let a = new $.$spxl.System.Xml.Linq.XAttribute().$ctor$2($.$spxl.System.Xml.Linq.XNamespace.Get(r.Prefix.length === 0 ? $.$spc.System.String.Empty : r.NamespaceURI).GetName(r.LocalName), r.Value);
                        if (li !== null && li.System$Xml$IXmlLineInfo$HasLineInfo())
                        {
                            a.SetLineInfo(li.System$Xml$IXmlLineInfo$LineNumber, li.System$Xml$IXmlLineInfo$LinePosition);
                        }
                        this.AppendAttributeSkipNotify(a);
                    }
                    while(r.MoveToNextAttribute());
                    r.MoveToElement();
                }
            }
            /*void */ RemoveAttribute(/*XAttribute*/ a)
            {
                /*bool*/ let notify = this.NotifyChanging(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                if (a.parent !== this)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spxl.System.SR.InvalidOperation_ExternalCode);
                }
                /*XAttribute?*/ let p = this.lastAttr, n;
                while((n = p.next) !== a)
                {
                    p = n;
                }
                if (p === a)
                {
                    this.lastAttr = null;
                }
                else 
                {
                    if (this.lastAttr === a)
                    {
                        this.lastAttr = p;
                    }
                    p.next = a.next;
                }
                a.parent = null;
                a.next = null;
                if (notify)
                {
                    this.NotifyChanged(a, $.$spxl.System.Xml.Linq.XObjectChangeEventArgs.Remove);
                }
            }
            /*void */ RemoveAttributesSkipNotify()
            {
                if (this.lastAttr !== null)
                {
                    /*XAttribute*/ let a = this.lastAttr;
                    do
                    {
                        /*XAttribute*/ let next = a.next;
                        a.parent = null;
                        a.next = null;
                        a = next;
                    }
                    while(a !== this.lastAttr);
                    this.lastAttr = null;
                }
            }
            /*void */ SetEndElementLineInfo(/*int*/ lineNumber, /*int*/ linePosition)
            {
                this.AddAnnotation(new $.$spxl.System.Xml.Linq.LineInfoEndElementAnnotation().$ctor$2(lineNumber, linePosition));
            }
            /*void */ ValidateNode(/*XNode*/ node, /*XNode?*/ previous)
            {
                if ($.$is(node, $.$spxl.System.Xml.Linq.XDocument))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_AddNode, $.$box(9/*XmlNodeType.Document*/, $.$spx.System.Xml.XmlNodeType)));
                }
                if ($.$is(node, $.$spxl.System.Xml.Linq.XDocumentType))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$spxl.System.SR.Format($.$spxl.System.SR.Argument_AddNode, $.$box(10/*XmlNodeType.DocumentType*/, $.$spx.System.Xml.XmlNodeType)));
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.name = null;
            }
            static $h = 1690028;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1362348,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"g":{"r":0,"d":0,"h":8591624620,"f":33},"n":"EmptySequence","d":1690028,"h":4296657324,"f":33},{"p":1165740,"g":{"r":0,"d":0,"h":81606068652,"f":1},"n":"FirstAttribute","d":1690028,"h":77311101356,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":90196003244,"f":1},"n":"HasAttributes","d":1690028,"h":85901035948,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":98785937836,"f":1},"n":"HasElements","d":1690028,"h":94490970540,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":107375872428,"f":1},"n":"IsEmpty","d":1690028,"h":103080905132,"f":1},{"p":1165740,"g":{"r":0,"d":0,"h":115965807020,"f":1},"n":"LastAttribute","d":1690028,"h":111670839724,"f":1},{"p":2148780,"g":{"r":0,"d":0,"h":124555741612,"f":1},"s":{"r":0,"d":0,"h":128850708908,"f":1},"n":"Name","d":1690028,"h":120260774316,"f":1},{"p":52865181,"g":{"r":0,"d":0,"h":137440643500,"f":32769},"n":"NodeType","d":1690028,"h":133145676204,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":146030578092,"f":1},"s":{"r":0,"d":0,"h":150325545388,"f":1},"n":"Value","d":1690028,"h":141735610796,"f":1}],"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"r","p":53389469},{"n":"cancellationToken","p":125960193}],"n":"CreateAsync","d":1690028,"h":64426199468,"f":4136},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"Save","d":1690028,"h":68721166764,"f":1},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"options","p":1034668}],"n":"Save","o":"@$1","d":1690028,"h":73016134060,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"AncestorsAndSelf","d":1690028,"h":154620512684,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2148780}],"n":"AncestorsAndSelf","o":"@$1","d":1690028,"h":158915479980,"f":1},{"r":1165740,"p":[{"n":"name","p":2148780}],"n":"Attribute","d":1690028,"h":163210447276,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"n":"Attributes","d":1690028,"h":167505414572,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"name","p":2148780}],"n":"Attributes","o":"@$1","d":1690028,"h":171800381868,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XNode).$h,"n":"DescendantNodesAndSelf","d":1690028,"h":176095349164,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"n":"DescendantsAndSelf","d":1690028,"h":180390316460,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"name","p":2148780}],"n":"DescendantsAndSelf","o":"@$1","d":1690028,"h":184685283756,"f":1},{"r":2214316,"n":"GetDefaultNamespace","d":1690028,"h":188980251052,"f":1},{"r":2214316,"p":[{"n":"prefix","p":1310721}],"n":"GetNamespaceOfPrefix","d":1690028,"h":193275218348,"f":1},{"r":1310721,"p":[{"n":"ns","p":2214316}],"n":"GetPrefixOfNamespace","d":1690028,"h":197570185644,"f":1},{"r":1690028,"p":[{"n":"uri","p":1310721}],"n":"Load","d":1690028,"h":201865152940,"f":33},{"r":1690028,"p":[{"n":"uri","p":1310721},{"n":"options","p":706988}],"n":"Load","o":"@$1","d":1690028,"h":206160120236,"f":33},{"r":1690028,"p":[{"n":"stream","p":62193665}],"n":"Load","o":"@$2","d":1690028,"h":210455087532,"f":33},{"r":1690028,"p":[{"n":"stream","p":62193665},{"n":"options","p":706988}],"n":"Load","o":"@$3","d":1690028,"h":214750054828,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"stream","p":62193665},{"n":"options","p":706988},{"n":"cancellationToken","p":125960193}],"n":"LoadAsync","d":1690028,"h":219045022124,"f":4129},{"r":1690028,"p":[{"n":"textReader","p":62914561}],"n":"Load","o":"@$4","d":1690028,"h":223339989420,"f":33},{"r":1690028,"p":[{"n":"textReader","p":62914561},{"n":"options","p":706988}],"n":"Load","o":"@$5","d":1690028,"h":227634956716,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"textReader","p":62914561},{"n":"options","p":706988},{"n":"cancellationToken","p":125960193}],"n":"LoadAsync","o":"@$1","d":1690028,"h":231929924012,"f":4129},{"r":1690028,"p":[{"n":"reader","p":53389469}],"n":"Load","o":"@$6","d":1690028,"h":236224891308,"f":33},{"r":1690028,"p":[{"n":"reader","p":53389469},{"n":"options","p":706988}],"n":"Load","o":"@$7","d":1690028,"h":240519858604,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"reader","p":53389469},{"n":"options","p":706988},{"n":"cancellationToken","p":125960193}],"n":"LoadAsync","o":"@$2","d":1690028,"h":244814825900,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spxl.System.Xml.Linq.XElement).$h,"p":[{"n":"reader","p":53389469},{"n":"options","p":706988},{"n":"cancellationToken","p":125960193}],"n":"LoadAsyncInternal","d":1690028,"h":249109793196,"f":4130},{"r":1690028,"p":[{"n":"text","p":1310721}],"n":"Parse","d":1690028,"h":253404760492,"f":33},{"r":1690028,"p":[{"n":"text","p":1310721},{"n":"options","p":706988}],"n":"Parse","o":"@$1","d":1690028,"h":257699727788,"f":33},{"r":65537,"n":"RemoveAll","d":1690028,"h":261994695084,"f":1},{"r":65537,"n":"RemoveAttributes","d":1690028,"h":266289662380,"f":1},{"r":65537,"p":[{"n":"content","p":131073}],"n":"ReplaceAll","d":1690028,"h":270584629676,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"ReplaceAll","o":"@$1","d":1690028,"h":274879596972,"f":1},{"r":65537,"p":[{"n":"content","p":131073}],"n":"ReplaceAttributes","d":1690028,"h":279174564268,"f":1},{"r":65537,"p":[{"n":"content","p":0,"f":16}],"n":"ReplaceAttributes","o":"@$1","d":1690028,"h":283469531564,"f":1},{"r":65537,"p":[{"n":"stream","p":62193665}],"n":"Save","o":"@$2","d":1690028,"h":287764498860,"f":1},{"r":65537,"p":[{"n":"stream","p":62193665},{"n":"options","p":1034668}],"n":"Save","o":"@$3","d":1690028,"h":292059466156,"f":1},{"r":133300225,"p":[{"n":"stream","p":62193665},{"n":"options","p":1034668},{"n":"cancellationToken","p":125960193}],"n":"SaveAsync","d":1690028,"h":296354433452,"f":4097},{"r":65537,"p":[{"n":"textWriter","p":63045633}],"n":"Save","o":"@$4","d":1690028,"h":300649400748,"f":1},{"r":65537,"p":[{"n":"textWriter","p":63045633},{"n":"options","p":1034668}],"n":"Save","o":"@$5","d":1690028,"h":304944368044,"f":1},{"r":133300225,"p":[{"n":"textWriter","p":63045633},{"n":"options","p":1034668},{"n":"cancellationToken","p":125960193}],"n":"SaveAsync","o":"@$1","d":1690028,"h":309239335340,"f":4097},{"r":65537,"p":[{"n":"writer","p":58435741}],"n":"Save","o":"@$6","d":1690028,"h":313534302636,"f":1},{"r":133300225,"p":[{"n":"writer","p":58435741},{"n":"cancellationToken","p":125960193}],"n":"SaveAsync","o":"@$2","d":1690028,"h":317829269932,"f":1},{"r":133300225,"p":[{"n":"writer","p":58435741},{"n":"cancellationToken","p":125960193}],"n":"SaveAsyncInternal","d":1690028,"h":322124237228,"f":4098},{"r":65537,"p":[{"n":"name","p":2148780},{"n":"value","p":131073}],"n":"SetAttributeValue","d":1690028,"h":326419204524,"f":1},{"r":65537,"p":[{"n":"name","p":2148780},{"n":"value","p":131073}],"n":"SetElementValue","d":1690028,"h":330714171820,"f":1},{"r":65537,"p":[{"n":"value","p":131073}],"n":"SetValue","d":1690028,"h":335009139116,"f":1},{"r":65537,"p":[{"n":"writer","p":58435741}],"n":"WriteTo","d":1690028,"h":339304106412,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58435741},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":1690028,"h":343599073708,"f":32769},{"r":65537,"p":[{"n":"a","p":1165740}],"n":"AddAttribute","d":1690028,"h":468153125292,"f":32776},{"r":65537,"p":[{"n":"a","p":1165740}],"n":"AddAttributeSkipNotify","d":1690028,"h":472448092588,"f":32776},{"r":65537,"p":[{"n":"a","p":1165740}],"n":"AppendAttribute","d":1690028,"h":476743059884,"f":8},{"r":65537,"p":[{"n":"a","p":1165740}],"n":"AppendAttributeSkipNotify","d":1690028,"h":481038027180,"f":8},{"r":262145,"p":[{"n":"e","p":1690028}],"n":"AttributesEqual","d":1690028,"h":485332994476,"f":2},{"r":2279852,"n":"CloneNode","d":1690028,"h":489627961772,"f":32776},{"r":262145,"p":[{"n":"node","p":2279852}],"n":"DeepEquals","o":"@$1","d":1690028,"h":493922929068,"f":32776},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spxl.System.Xml.Linq.XAttribute).$h,"p":[{"n":"name","p":2148780}],"n":"GetAttributes","d":1690028,"h":498217896364,"f":2},{"r":1310721,"p":[{"n":"prefix","p":1310721},{"n":"outOfScope","p":1690028}],"n":"GetNamespaceOfPrefixInScope","d":1690028,"h":502512863660,"f":2},{"r":655361,"n":"GetDeepHashCode","d":1690028,"h":506807830956,"f":32776},{"r":65537,"p":[{"n":"r","p":53389469},{"n":"o","p":706988}],"n":"ReadElementFrom","d":1690028,"h":511102798252,"f":2},{"r":133300225,"p":[{"n":"r","p":53389469},{"n":"o","p":706988},{"n":"cancellationTokentoken","p":125960193}],"n":"ReadElementFromAsync","d":1690028,"h":515397765548,"f":4098},{"r":65537,"p":[{"n":"r","p":53389469},{"n":"o","p":706988}],"n":"ReadElementFromImpl","d":1690028,"h":519692732844,"f":2},{"r":65537,"p":[{"n":"a","p":1165740}],"n":"RemoveAttribute","d":1690028,"h":523987700140,"f":8},{"r":65537,"n":"RemoveAttributesSkipNotify","d":1690028,"h":528282667436,"f":2},{"r":65537,"p":[{"n":"lineNumber","p":655361},{"n":"linePosition","p":655361}],"n":"SetEndElementLineInfo","d":1690028,"h":532577634732,"f":8},{"r":65537,"p":[{"n":"node","p":2279852},{"n":"previous","p":2279852}],"n":"ValidateNode","d":1690028,"h":536872602028,"f":32776}],"l":[{"t":2148780,"n":"name","d":1690028,"h":12886591916,"f":8},{"t":1165740,"n":"lastAttr","d":1690028,"h":17181559212,"f":8}],"c":[{"p":[{"n":"name","p":2148780}],"n":".ctor","o":"$ctor$5","d":1690028,"h":21476526508,"f":1},{"p":[{"n":"name","p":2148780},{"n":"content","p":131073}],"n":".ctor","o":"$ctor$6","d":1690028,"h":25771493804,"f":1},{"p":[{"n":"name","p":2148780},{"n":"content","p":0,"f":16}],"n":".ctor","o":"$ctor$7","d":1690028,"h":30066461100,"f":1},{"p":[{"n":"other","p":1690028}],"n":".ctor","o":"$ctor$8","d":1690028,"h":34361428396,"f":1},{"p":[{"n":"other","p":2935212}],"n":".ctor","o":"$ctor$9","d":1690028,"h":38656395692,"f":1},{"n":".ctor","o":"$ctor$10","d":1690028,"h":42951362988,"f":8},{"p":[{"n":"r","p":53389469}],"n":".ctor","o":"$ctor$11","d":1690028,"h":47246330284,"f":8},{"p":[{"n":"_","p":1755564}],"n":".ctor","o":"$ctor$12","d":1690028,"h":51541297580,"f":2},{"p":[{"n":"r","p":53389469},{"n":"o","p":706988}],"n":".ctor","o":"$ctor$13","d":1690028,"h":60131232172,"f":8}],"i":[13936797,37267613],"j":[1755564],"h":1690028,"a":[{"t":44869789,"c":12929771677,"a":[{"t":1310721}],"n":[{"n":"IsAny","v":true,"t":262145}]},{"t":1570691,"c":4296537987,"a":[{"v":"MS.Internal.Xml.Linq.ComponentModel.XTypeDescriptionProvider\u00601[[System.Xml.Linq.XElement, System.Xml.Linq, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]],System.ComponentModel.TypeConverter","t":1310721}]}]}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XContainer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo, $.$spx.System.Xml.Serialization.IXmlSerializable ]; }
            static get $fullName() { return `System.Xml.Linq.XElement`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Schema.XmlSchemaInfoEqualityComparer", ($self) => class XmlSchemaInfoEqualityComparer extends $.$spc.System.Object
        {
            /*bool */ Equals$2(/*XmlSchemaInfo?*/ si1, /*XmlSchemaInfo?*/ si2)
            {
                if (si1 === si2)
                {
                    return true;
                }
                if (si1 === null || si2 === null)
                {
                    return false;
                }
                return si1.ContentType === si2.ContentType && si1.IsDefault === si2.IsDefault && si1.IsNil === si2.IsNil && $.$cast(si1.MemberType, $.$spc.System.Object) === $.$cast(si2.MemberType, $.$spc.System.Object) && $.$cast(si1.SchemaAttribute, $.$spc.System.Object) === $.$cast(si2.SchemaAttribute, $.$spc.System.Object) && $.$cast(si1.SchemaElement, $.$spc.System.Object) === $.$cast(si2.SchemaElement, $.$spc.System.Object) && $.$cast(si1.SchemaType, $.$spc.System.Object) === $.$cast(si2.SchemaType, $.$spc.System.Object) && si1.Validity === si2.Validity;
            }
            /*int */ GetHashCode$1(/*XmlSchemaInfo?*/ si)
            {
                if (si === null)
                {
                    return 0;
                }
                /*int*/ let h = si.ContentType;
                if (si.IsDefault)
                {
                    h ^= 1;
                }
                if (si.IsNil)
                {
                    h ^= 1;
                }
                /*XmlSchemaSimpleType?*/ let memberType = si.MemberType;
                if (memberType !== null)
                {
                    h ^= $.$spc.System.Object.GetHashCode.call(memberType);
                }
                /*XmlSchemaAttribute?*/ let schemaAttribute = si.SchemaAttribute;
                if (schemaAttribute !== null)
                {
                    h ^= $.$spc.System.Object.GetHashCode.call(schemaAttribute);
                }
                /*XmlSchemaElement?*/ let schemaElement = si.SchemaElement;
                if (schemaElement !== null)
                {
                    h ^= $.$spc.System.Object.GetHashCode.call(schemaElement);
                }
                /*XmlSchemaType?*/ let schemaType = si.SchemaType;
                if (schemaType !== null)
                {
                    h ^= $.$spc.System.Object.GetHashCode.call(schemaType);
                }
                h ^= si.Validity;
                return h;
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Schema.XmlSchemaInfo>.Equals(System.Xml.Schema.XmlSchemaInfo?, System.Xml.Schema.XmlSchemaInfo?)
            System$Collections$Generic$IEqualityComparer$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Xml.Schema.XmlSchemaInfo>.GetHashCode(System.Xml.Schema.XmlSchemaInfo)
            System$Collections$Generic$IEqualityComparer$$$GetHashCode()
            {
                return this.GetHashCode$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 3131820;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"si1","p":30124189},{"n":"si2","p":30124189}],"n":"Equals","o":"@$2","d":3131820,"h":4298099116,"f":1},{"r":655361,"p":[{"n":"si","p":30124189}],"n":"GetHashCode","o":"@$1","d":3131820,"h":8593066412,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":3131820,"h":12888033708,"f":1}],"i":[$.$spc.System.Collections.Generic.IEqualityComparer$$($.$spx.System.Xml.Schema.XmlSchemaInfo).$h],"h":3131820}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEqualityComparer$$($.$spx.System.Xml.Schema.XmlSchemaInfo) ]; }
            static get $fullName() { return `System.Xml.Schema.XmlSchemaInfoEqualityComparer`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.LineInfoEndElementAnnotation", ($self) => class LineInfoEndElementAnnotation extends $.$spxl.System.Xml.Linq.LineInfoAnnotation
        {
            $ctor$2(/*int*/ lineNumber, /*int*/ linePosition)
            {
                super.$ctor$1(lineNumber, linePosition);
                {
                }
                return this;
            }
            static $h = 641452;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":575916,"c":[{"p":[{"n":"lineNumber","p":655361},{"n":"linePosition","p":655361}],"n":".ctor","o":"$ctor$2","d":641452,"h":4295608748,"f":1}],"h":641452}; }
            static get $b() { return $.$spxl.System.Xml.Linq.LineInfoAnnotation; }
            static get $fullName() { return `System.Xml.Linq.LineInfoEndElementAnnotation`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XObjectChangeEventArgs", ($self) => class XObjectChangeEventArgs extends $.$spc.System.EventArgs
        {
            /*XObjectChange*/ _objectChange = 0;
            /*XObjectChangeEventArgs*/ static Add = null;
            /*XObjectChangeEventArgs*/ static Remove = null;
            /*XObjectChangeEventArgs*/ static Name = null;
            /*XObjectChangeEventArgs*/ static Value = null;
            $ctor$2(/*XObjectChange*/ objectChange)
            {
                super.$ctor$1();
                {
                    this._objectChange = objectChange;
                }
                return this;
            }
            /*XObjectChange */ get ObjectChange()
            {
                return this._objectChange;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Add = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(0/*XObjectChange.Add*/);
                }
                {
                    this.Remove = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(1/*XObjectChange.Remove*/);
                }
                {
                    this.Name = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(2/*XObjectChange.Name*/);
                }
                {
                    this.Value = new $.$spxl.System.Xml.Linq.XObjectChangeEventArgs().$ctor$2(3/*XObjectChange.Value*/);
                }
            }
            static $h = 2804140;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":2673068,"g":{"r":0,"d":0,"h":34362542508,"f":1},"n":"ObjectChange","d":2804140,"h":30067575212,"f":1}],"l":[{"t":2673068,"n":"_objectChange","d":2804140,"h":4297771436,"f":2},{"t":2804140,"n":"Add","d":2804140,"h":8592738732,"f":33},{"t":2804140,"n":"Remove","d":2804140,"h":12887706028,"f":33},{"t":2804140,"n":"Name","d":2804140,"h":17182673324,"f":33},{"t":2804140,"n":"Value","d":2804140,"h":21477640620,"f":33}],"c":[{"p":[{"n":"objectChange","p":2673068}],"n":".ctor","o":"$ctor$2","d":2804140,"h":25772607916,"f":1}],"h":2804140}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Xml.Linq.XObjectChangeEventArgs`; }
        });
        
        $asm.$cls("$spxl.System.Xml.Linq.XCData", ($self) => class XCData extends $.$spxl.System.Xml.Linq.XText
        {
            $ctor$6(/*string*/ value)
            {
                super.$ctor$3(value);
                {
                }
                return this;
            }
            $ctor$7(/*XCData*/ other)
            {
                super.$ctor$4(other);
                {
                }
                return this;
            }
            $ctor$8(/*XmlReader*/ r)
            {
                super.$ctor$5(r);
                {
                }
                return this;
            }
            /*XmlNodeType */ get NodeType()
            {
                return 4/*XmlNodeType.CDATA*/;
            }
            /*void */ WriteTo(/*XmlWriter*/ writer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                writer.WriteCData(this.text);
            }
            /*Task */ WriteToAsync(/*XmlWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(writer, "writer");
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return writer.WriteCDataAsync(this.text);
            }
            /*XNode */ CloneNode()
            {
                return new $.$spxl.System.Xml.Linq.XCData().$ctor$7(this);
            }
            static $h = 1231276;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3000748,"p":[{"p":52865181,"g":{"r":0,"d":0,"h":21476067756,"f":32769},"n":"NodeType","d":1231276,"h":17181100460,"f":32769}],"m":[{"r":65537,"p":[{"n":"writer","p":58435741}],"n":"WriteTo","d":1231276,"h":25771035052,"f":32769},{"r":133300225,"p":[{"n":"writer","p":58435741},{"n":"cancellationToken","p":125960193}],"n":"WriteToAsync","d":1231276,"h":30066002348,"f":32769},{"r":2279852,"n":"CloneNode","d":1231276,"h":34360969644,"f":32776}],"c":[{"p":[{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$6","d":1231276,"h":4296198572,"f":1},{"p":[{"n":"other","p":1231276}],"n":".ctor","o":"$ctor$7","d":1231276,"h":8591165868,"f":1},{"p":[{"n":"r","p":53389469}],"n":".ctor","o":"$ctor$8","d":1231276,"h":12886133164,"f":8}],"i":[13936797],"h":1231276}; }
            static get $b() { return $.$spxl.System.Xml.Linq.XText; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spx.System.Xml.IXmlLineInfo ]; }
            static get $fullName() { return `System.Xml.Linq.XCData`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml"))