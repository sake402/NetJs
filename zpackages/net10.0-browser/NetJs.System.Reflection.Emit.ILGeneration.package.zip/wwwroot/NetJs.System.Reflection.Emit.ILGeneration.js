
//--TRIMMABLE-BOUNDARY-START(66)
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Reflection.Emit.ILGeneration", 
    {
  "h": 66,
  "f": "System.Reflection.Emit.ILGeneration",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.Reflection.Emit.ILGeneration",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.Reflection.Emit.ILGeneration",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))
//--TRIMMABLE-BOUNDARY-END(66)
