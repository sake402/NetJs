
//--TRIMMABLE-BOUNDARY-START(64)
(async function () {
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sl, $sci, $sic, $stt, $sim, $stee, $srm) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.Reflection.Emit", 
    {
  "h": 64,
  "f": "System.Reflection.Emit",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Reflection.Emit",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Reflection.Emit",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2228288)
        $asm.$cls(`$sre.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(940600066112)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(940600066112)
            
            //--TRIMMABLE-BOUNDARY-START(820340981824)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(820340981824);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(820340981824)
            
            //--TRIMMABLE-BOUNDARY-START(953484968000)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(953484968000);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sre.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(953484968000)
            
            //--TRIMMABLE-BOUNDARY-START(816046014528)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(816046014528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sre.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sre.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(816046014528)
            
            //--TRIMMABLE-BOUNDARY-START(811751047232)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(811751047232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sre.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(811751047232)
            
            //--TRIMMABLE-BOUNDARY-START(201865691200)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865691200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sre.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(201865691200)
            
            //--TRIMMABLE-BOUNDARY-START(197570723904)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570723904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sre.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(197570723904)
            
            //--TRIMMABLE-BOUNDARY-START(193275756608)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275756608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sre.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(193275756608)
            
            //--TRIMMABLE-BOUNDARY-START(206160658496)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160658496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sre.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(206160658496)
            
            //--TRIMMABLE-BOUNDARY-START(184685822016)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685822016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sre.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(184685822016)
            
            //--TRIMMABLE-BOUNDARY-START(180390854720)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390854720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sre.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(180390854720)
            
            //--TRIMMABLE-BOUNDARY-START(176095887424)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095887424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sre.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(176095887424)
            
            //--TRIMMABLE-BOUNDARY-START(188980789312)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980789312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sre.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(188980789312)
            
            //--TRIMMABLE-BOUNDARY-START(936305098816)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(936305098816)
            
            //--TRIMMABLE-BOUNDARY-START(927715164224)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(927715164224)
            
            //--TRIMMABLE-BOUNDARY-START(932010131520)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(807456079936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$sre.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.Reflection.Emit", $.$sre.S.SR.$type.Assembly);
                    $.$sre.S.SR.s_resourceManager = temp;
                }
                return $.$sre.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(932010131520)
            
            //--TRIMMABLE-BOUNDARY-START(171800920128)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592707715136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sre.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(949190000704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sre.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(171800920128)
            
            //--TRIMMABLE-BOUNDARY-START(841815818304)
            static /*string */ get InvalidOperation_CannotPopulateMultipleTimes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(635657388096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot populate assembly metadata multiple times.";
            }
            //--TRIMMABLE-BOUNDARY-END(841815818304)
            
            //--TRIMMABLE-BOUNDARY-START(38656933952)
            static /*string */ get Argument_CannotSetParentToInterface()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326419742784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot set parent to an interface.";
            }
            //--TRIMMABLE-BOUNDARY-END(38656933952)
            
            //--TRIMMABLE-BOUNDARY-START(828930916416)
            static /*string */ get InvalidOperation_BadInterfaceNotAbstract()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(609887584320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Interface must be declared abstract.";
            }
            //--TRIMMABLE-BOUNDARY-END(828930916416)
            
            //--TRIMMABLE-BOUNDARY-START(824635949120)
            static /*string */ get InvalidOperation_AModuleRequired()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(601297649728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Assembly needs at least one module defined.";
            }
            //--TRIMMABLE-BOUNDARY-END(824635949120)
            
            //--TRIMMABLE-BOUNDARY-START(867585622080)
            static /*string */ get InvalidOperation_NoMultiModuleAssembly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(687196995648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "You cannot have more than one dynamic module in each dynamic assembly in this version of the runtime.";
            }
            //--TRIMMABLE-BOUNDARY-END(867585622080)
            
            //--TRIMMABLE-BOUNDARY-START(901945360448)
            static /*string */ get NotSupported_DynamicModule()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(755916472384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The invoked member is not supported in a dynamic module.";
            }
            //--TRIMMABLE-BOUNDARY-END(901945360448)
            
            //--TRIMMABLE-BOUNDARY-START(98786476096)
            static /*string */ get Argument_InvalidTypeCodeForTypeArgument()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446678827072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The type code may not be used as a type argument of a custom attribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(98786476096)
            
            //--TRIMMABLE-BOUNDARY-START(923420196928)
            static /*string */ get NotSupported_UnmanagedTypeOnlyForFields()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(798866145344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return " 'UnmanagedType.{0}' named parameter is only valid for fields.";
            }
            //--TRIMMABLE-BOUNDARY-END(923420196928)
            
            //--TRIMMABLE-BOUNDARY-START(257700266048)
            static /*string */ FormatNotSupported_UnmanagedTypeOnlyForFields(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257700266048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9(" 'UnmanagedType.{0}' named parameter is only valid for fields.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(257700266048)
            
            //--TRIMMABLE-BOUNDARY-START(77311639616)
            static /*string */ get Argument_InvalidCustomAttributeLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403729154112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Custom attribute '{0}' data length is only '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(77311639616)
            
            //--TRIMMABLE-BOUNDARY-START(223340527680)
            static /*string */ FormatArgument_InvalidCustomAttributeLength(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340527680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Custom attribute '{0}' data length is only '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(223340527680)
            
            //--TRIMMABLE-BOUNDARY-START(94491508800)
            static /*string */ get Argument_InvalidProlog()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438088892480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Custom attribute '{0}' prolog invalid.";
            }
            //--TRIMMABLE-BOUNDARY-END(94491508800)
            
            //--TRIMMABLE-BOUNDARY-START(236225429568)
            static /*string */ FormatArgument_InvalidProlog(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225429568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Custom attribute '{0}' prolog invalid.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(236225429568)
            
            //--TRIMMABLE-BOUNDARY-START(154621050944)
            static /*string */ get Argument_UnknownNamedType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(558347976768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Custom attribute '{0}' has unknown named type '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(154621050944)
            
            //--TRIMMABLE-BOUNDARY-START(244815364160)
            static /*string */ FormatArgument_UnknownNamedType(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815364160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Custom attribute '{0}' has unknown named type '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(244815364160)
            
            //--TRIMMABLE-BOUNDARY-START(897650393152)
            static /*string */ get NotImplemented_TypeForValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(747326537792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Type '{0}' not handled in the custom attribute value decoder.";
            }
            //--TRIMMABLE-BOUNDARY-END(897650393152)
            
            //--TRIMMABLE-BOUNDARY-START(253405298752)
            static /*string */ FormatNotImplemented_TypeForValue(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405298752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Type '{0}' not handled in the custom attribute value decoder.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(253405298752)
            
            //--TRIMMABLE-BOUNDARY-START(51541835840)
            static /*string */ get Argument_DllNameCannotBeEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352189546560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "DllName cannot be empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(51541835840)
            
            //--TRIMMABLE-BOUNDARY-START(167505952832)
            static /*string */ get ArgumentOutOfRange_ParamSequence()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584117780544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified parameter index is not in range.";
            }
            //--TRIMMABLE-BOUNDARY-END(167505952832)
            
            //--TRIMMABLE-BOUNDARY-START(73016672320)
            static /*string */ get Argument_InvalidArgumentForAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395139219520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid constructor argument {0} provided for MarshalAs attribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(73016672320)
            
            //--TRIMMABLE-BOUNDARY-START(219045560384)
            static /*string */ FormatArgument_InvalidArgumentForAttribute(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045560384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Invalid constructor argument {0} provided for MarshalAs attribute.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(219045560384)
            
            //--TRIMMABLE-BOUNDARY-START(90196541504)
            static /*string */ get Argument_InvalidParameterForUnmanagedType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429498957888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Named parameter {0} is not valid for UnmanagedType.{1} type.";
            }
            //--TRIMMABLE-BOUNDARY-END(90196541504)
            
            //--TRIMMABLE-BOUNDARY-START(231930462272)
            static /*string */ FormatArgument_InvalidParameterForUnmanagedType(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930462272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Named parameter {0} is not valid for UnmanagedType.{1} type.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(231930462272)
            
            //--TRIMMABLE-BOUNDARY-START(150326083648)
            static /*string */ get Argument_SizeConstMustBeSpecified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(549758042176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "SizeConst parameter must be specified for UnmanagedType.ByValTStr type.";
            }
            //--TRIMMABLE-BOUNDARY-END(150326083648)
            
            //--TRIMMABLE-BOUNDARY-START(854700720192)
            static /*string */ get InvalidOperation_GenericParametersAlreadySet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(661427191872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The generic parameters are already defined on this MethodBuilder.";
            }
            //--TRIMMABLE-BOUNDARY-END(854700720192)
            
            //--TRIMMABLE-BOUNDARY-START(146031116352)
            static /*string */ get Argument_ShouldOnlySetVisibilityFlags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541168107584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Should only set visibility flags when creating EnumBuilder.";
            }
            //--TRIMMABLE-BOUNDARY-END(146031116352)
            
            //--TRIMMABLE-BOUNDARY-START(42951901248)
            static /*string */ get Argument_ConstantDoesntMatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335009677376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Constant does not match the defined type.";
            }
            //--TRIMMABLE-BOUNDARY-END(42951901248)
            
            //--TRIMMABLE-BOUNDARY-START(47246868544)
            static /*string */ get Argument_ConstantNull()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343599611968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Null is not a valid constant value for this type.";
            }
            //--TRIMMABLE-BOUNDARY-END(47246868544)
            
            //--TRIMMABLE-BOUNDARY-START(876175556672)
            static /*string */ get InvalidOperation_NoUnderlyingTypeOnEnum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(704376864832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Underlying type information on enumeration is not specified.";
            }
            //--TRIMMABLE-BOUNDARY-END(876175556672)
            
            //--TRIMMABLE-BOUNDARY-START(880470523968)
            static /*string */ get InvalidOperation_ShouldNotHaveMethodBody()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(712966799424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Method body should not exist.";
            }
            //--TRIMMABLE-BOUNDARY-END(880470523968)
            
            //--TRIMMABLE-BOUNDARY-START(846110785600)
            static /*string */ get InvalidOperation_ConstructorNotAllowedOnInterface()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(644247322688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Interface cannot have constructors.";
            }
            //--TRIMMABLE-BOUNDARY-END(846110785600)
            
            //--TRIMMABLE-BOUNDARY-START(158916018240)
            static /*string */ get Argument_UnmatchedMethodForLocal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(566937911360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Local passed in does not belong to this ILGenerator.";
            }
            //--TRIMMABLE-BOUNDARY-END(158916018240)
            
            //--TRIMMABLE-BOUNDARY-START(81606606912)
            static /*string */ get Argument_InvalidLabel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412319088704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid Label.";
            }
            //--TRIMMABLE-BOUNDARY-END(81606606912)
            
            //--TRIMMABLE-BOUNDARY-START(120261312576)
            static /*string */ get Argument_MustBeSwitchOpCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489628500032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Only 'OpCode.Switch' can be used.";
            }
            //--TRIMMABLE-BOUNDARY-END(120261312576)
            
            //--TRIMMABLE-BOUNDARY-START(133146214464)
            static /*string */ get Argument_NotMethodCallOpcode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515398303808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified opcode cannot be passed to EmitCall.";
            }
            //--TRIMMABLE-BOUNDARY-END(133146214464)
            
            //--TRIMMABLE-BOUNDARY-START(850405752896)
            static /*string */ get InvalidOperation_DefaultConstructorILGen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(652837257280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to access ILGenerator on a constructor created with DefineDefaultConstructor.";
            }
            //--TRIMMABLE-BOUNDARY-END(850405752896)
            
            //--TRIMMABLE-BOUNDARY-START(910535295040)
            static /*string */ get NotSupported_NoParentDefaultConstructor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(773096341568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Parent does not have a default constructor. The default constructor must be explicitly defined.";
            }
            //--TRIMMABLE-BOUNDARY-END(910535295040)
            
            //--TRIMMABLE-BOUNDARY-START(889060458560)
            static /*string */ get InvalidOperation_TypeHasBeenCreated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(730146668608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to change after type has been created.";
            }
            //--TRIMMABLE-BOUNDARY-END(889060458560)
            
            //--TRIMMABLE-BOUNDARY-START(919125229632)
            static /*string */ get NotSupported_TypeNotYetCreated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(790276210752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The invoked member is not supported before the type is created.";
            }
            //--TRIMMABLE-BOUNDARY-END(919125229632)
            
            //--TRIMMABLE-BOUNDARY-START(124556279872)
            static /*string */ get Argument_NoStaticVirtual()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498218434624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Method cannot be both static and virtual.";
            }
            //--TRIMMABLE-BOUNDARY-END(124556279872)
            
            //--TRIMMABLE-BOUNDARY-START(17182097472)
            static /*string */ get Argument_BadExceptionCodeGen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283470069824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Incorrect code generation for exception block.";
            }
            //--TRIMMABLE-BOUNDARY-END(17182097472)
            
            //--TRIMMABLE-BOUNDARY-START(128851247168)
            static /*string */ get Argument_NotInExceptionBlock()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506808369216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Not currently in an exception block.";
            }
            //--TRIMMABLE-BOUNDARY-END(128851247168)
            
            //--TRIMMABLE-BOUNDARY-START(141736149056)
            static /*string */ get Argument_ShouldNotSpecifyExceptionType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532578172992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Should not specify exception type for catch clause for filter block.";
            }
            //--TRIMMABLE-BOUNDARY-END(141736149056)
            
            //--TRIMMABLE-BOUNDARY-START(12887130176)
            static /*string */ get Arg_NotGenericMethodDefinition()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274880135232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "{0} is not a GenericMethodDefinition. MakeGenericMethod may only be called on a method for which MethodBase.IsGenericMethodDefinition is true.";
            }
            //--TRIMMABLE-BOUNDARY-END(12887130176)
            
            //--TRIMMABLE-BOUNDARY-START(214750593088)
            static /*string */ FormatArg_NotGenericMethodDefinition(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750593088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("{0} is not a GenericMethodDefinition. MakeGenericMethod may only be called on a method for which MethodBase.IsGenericMethodDefinition is true.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(214750593088)
            
            //--TRIMMABLE-BOUNDARY-START(871880589376)
            static /*string */ get InvalidOperation_NotAVarArgCallingConvention()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(695786930240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Calling convention must be VarArgs.";
            }
            //--TRIMMABLE-BOUNDARY-END(871880589376)
            
            //--TRIMMABLE-BOUNDARY-START(163210985536)
            static /*string */ get ArgumentException_BadMethodImplBody()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(575527845952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "MethodOverride's body must be from this type.";
            }
            //--TRIMMABLE-BOUNDARY-END(163210985536)
            
            //--TRIMMABLE-BOUNDARY-START(55836803136)
            static /*string */ get Argument_GenericParameter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360779481152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Method must be called on a Type for which Type.IsGenericParameter is false.";
            }
            //--TRIMMABLE-BOUNDARY-END(55836803136)
            
            //--TRIMMABLE-BOUNDARY-START(85901574208)
            static /*string */ get Argument_InvalidMethodOverride()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420909023296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Type '{0}' tried to override method '{1}' but does not implement or inherit that method.";
            }
            //--TRIMMABLE-BOUNDARY-END(85901574208)
            
            //--TRIMMABLE-BOUNDARY-START(227635494976)
            static /*string */ FormatArgument_InvalidMethodOverride(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635494976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Type '{0}' tried to override method '{1}' but does not implement or inherit that method.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(227635494976)
            
            //--TRIMMABLE-BOUNDARY-START(68721705024)
            static /*string */ get Argument_InterfaceNotFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386549284928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Interface not found.";
            }
            //--TRIMMABLE-BOUNDARY-END(68721705024)
            
            //--TRIMMABLE-BOUNDARY-START(103081443392)
            static /*string */ get Argument_MethodOverridden()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455268761664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Method '{0}' on type '{1}' is overriding a method that has been overridden.";
            }
            //--TRIMMABLE-BOUNDARY-END(103081443392)
            
            //--TRIMMABLE-BOUNDARY-START(240520396864)
            static /*string */ FormatArgument_MethodOverridden(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240520396864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Method '{0}' on type '{1}' is overriding a method that has been overridden.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(240520396864)
            
            //--TRIMMABLE-BOUNDARY-START(115966345280)
            static /*string */ get Argument_MustBeInterface()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481038565440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Type passed must be an interface.";
            }
            //--TRIMMABLE-BOUNDARY-END(115966345280)
            
            //--TRIMMABLE-BOUNDARY-START(833225883712)
            static /*string */ get InvalidOperation_BadMethodBody()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(618477518912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Method '{0}' cannot have a method body";
            }
            //--TRIMMABLE-BOUNDARY-END(833225883712)
            
            //--TRIMMABLE-BOUNDARY-START(249110331456)
            static /*string */ FormatInvalidOperation_BadMethodBody(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249110331456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Method '{0}' cannot have a method body", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(249110331456)
            
            //--TRIMMABLE-BOUNDARY-START(837520851008)
            static /*string */ get InvalidOperation_BadTypeAttributesNotAbstract()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(627067453504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Type must be declared abstract if any of its methods are abstract.";
            }
            //--TRIMMABLE-BOUNDARY-END(837520851008)
            
            //--TRIMMABLE-BOUNDARY-START(8592162880)
            static /*string */ get AmbiguousMatch_MemberInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266290200640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Ambiguous match found for '{0} {1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(8592162880)
            
            //--TRIMMABLE-BOUNDARY-START(210455625792)
            static /*string */ FormatAmbiguousMatch_MemberInfo(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455625792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Ambiguous match found for '{0} {1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(210455625792)
            
            //--TRIMMABLE-BOUNDARY-START(137441181760)
            static /*string */ get Argument_RedefinedLabel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523988238400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Label defined multiple times.";
            }
            //--TRIMMABLE-BOUNDARY-END(137441181760)
            
            //--TRIMMABLE-BOUNDARY-START(21477064768)
            static /*string */ get Argument_BadPInvokeMethod()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292060004416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "PInvoke methods must be static and native and cannot be abstract.";
            }
            //--TRIMMABLE-BOUNDARY-END(21477064768)
            
            //--TRIMMABLE-BOUNDARY-START(25772032064)
            static /*string */ get Argument_BadPInvokeOnInterface()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300649939008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "PInvoke methods cannot exist on interfaces.";
            }
            //--TRIMMABLE-BOUNDARY-END(25772032064)
            
            //--TRIMMABLE-BOUNDARY-START(107376410688)
            static /*string */ get Argument_MethodRedefined()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463858696256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Method has been already defined.";
            }
            //--TRIMMABLE-BOUNDARY-END(107376410688)
            
            //--TRIMMABLE-BOUNDARY-START(60131770432)
            static /*string */ get Argument_GlobalMembersMustBeStatic()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369369415744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Global members must be static.";
            }
            //--TRIMMABLE-BOUNDARY-END(60131770432)
            
            //--TRIMMABLE-BOUNDARY-START(858995687488)
            static /*string */ get InvalidOperation_GlobalsHaveBeenCreated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(670017126464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Type definition of the global function has been completed.";
            }
            //--TRIMMABLE-BOUNDARY-END(858995687488)
            
            //--TRIMMABLE-BOUNDARY-START(34361966656)
            static /*string */ get Argument_BadSizeForData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317829808192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Data size must be &gt; 1 and &lt; 0x3f0000.";
            }
            //--TRIMMABLE-BOUNDARY-END(34361966656)
            
            //--TRIMMABLE-BOUNDARY-START(884765491264)
            static /*string */ get InvalidOperation_TokenNotPopulated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(721556734016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "MetadataToken for the member is not generated until the assembly saved.";
            }
            //--TRIMMABLE-BOUNDARY-END(884765491264)
            
            //--TRIMMABLE-BOUNDARY-START(30066999360)
            static /*string */ get Argument_BadSigFormat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309239873600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Incorrect signature format.";
            }
            //--TRIMMABLE-BOUNDARY-END(30066999360)
            
            //--TRIMMABLE-BOUNDARY-START(64426737728)
            static /*string */ get Argument_HasToBeArrayClass()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377959350336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Must be an array type.";
            }
            //--TRIMMABLE-BOUNDARY-END(64426737728)
            
            //--TRIMMABLE-BOUNDARY-START(906240327744)
            static /*string */ get NotSupported_NonReflectedType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(764506406976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Not supported in a non-reflected type.";
            }
            //--TRIMMABLE-BOUNDARY-END(906240327744)
            
            //--TRIMMABLE-BOUNDARY-START(914830262336)
            static /*string */ get NotSupported_SymbolMethod()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(781686276160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Not supported in an array method of a type definition that is not complete.";
            }
            //--TRIMMABLE-BOUNDARY-END(914830262336)
            
            //--TRIMMABLE-BOUNDARY-START(863290654784)
            static /*string */ get InvalidOperation_InvalidDocument()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(678607061056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid source document.";
            }
            //--TRIMMABLE-BOUNDARY-END(863290654784)
            
            //--TRIMMABLE-BOUNDARY-START(893355425856)
            static /*string */ get InvalidOperation_UnmatchingSymScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(738736603200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unmatching symbol scope.";
            }
            //--TRIMMABLE-BOUNDARY-END(893355425856)
            
            //--TRIMMABLE-BOUNDARY-START(111671377984)
            static /*string */ get Argument_MustBeEnum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472448630848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Type provided must be an Enum.";
            }
            //--TRIMMABLE-BOUNDARY-END(111671377984)
            
            //--TRIMMABLE-BOUNDARY-START(4297195584)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297195584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(940600066112)
                    this.s_usingResourceKeys = $.$sre.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(940600066112)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297195584)
            
            static $h = 2228288;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2228288
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228288)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata"));
})();
//--TRIMMABLE-BOUNDARY-END(64)
