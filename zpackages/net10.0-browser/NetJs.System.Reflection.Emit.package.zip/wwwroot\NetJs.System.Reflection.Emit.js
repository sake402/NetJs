
(function ($global, $, $spc, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $stt, $sr, $scc, $sris, $sic, $sim, $sl, $sci, $srm) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Reflection.Emit", 
    {"h":38878,"f":"System.Reflection.Emit","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Reflection.Emit","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Reflection.Emit","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sre.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sre.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Reflection.Emit", $.$sre.System.SR.$type.Assembly);
                    $.$sre.System.SR.s_resourceManager = temp;
                }
                return $.$sre.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sre.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sre.System.SR.resourceCulture = value;
            }
            static /*string */ get InvalidOperation_CannotPopulateMultipleTimes()
            {
                return "Cannot populate assembly metadata multiple times.";
            }
            static /*string */ get Argument_CannotSetParentToInterface()
            {
                return "Cannot set parent to an interface.";
            }
            static /*string */ get InvalidOperation_BadInterfaceNotAbstract()
            {
                return "Interface must be declared abstract.";
            }
            static /*string */ get InvalidOperation_AModuleRequired()
            {
                return "Assembly needs at least one module defined.";
            }
            static /*string */ get InvalidOperation_NoMultiModuleAssembly()
            {
                return "You cannot have more than one dynamic module in each dynamic assembly in this version of the runtime.";
            }
            static /*string */ get NotSupported_DynamicModule()
            {
                return "The invoked member is not supported in a dynamic module.";
            }
            static /*string */ get Argument_InvalidTypeCodeForTypeArgument()
            {
                return "The type code may not be used as a type argument of a custom attribute.";
            }
            static /*string */ get NotSupported_UnmanagedTypeOnlyForFields()
            {
                return " 'UnmanagedType.{0}' named parameter is only valid for fields.";
            }
            static /*string */ FormatNotSupported_UnmanagedTypeOnlyForFields(/*object*/ arg1)
            {
                return $.$spc.System.String.Format(" 'UnmanagedType.{0}' named parameter is only valid for fields.", arg1);
            }
            static /*string */ get Argument_InvalidCustomAttributeLength()
            {
                return "Custom attribute '{0}' data length is only '{1}'.";
            }
            static /*string */ FormatArgument_InvalidCustomAttributeLength(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Custom attribute '{0}' data length is only '{1}'.", arg1, arg2);
            }
            static /*string */ get Argument_InvalidProlog()
            {
                return "Custom attribute '{0}' prolog invalid.";
            }
            static /*string */ FormatArgument_InvalidProlog(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Custom attribute '{0}' prolog invalid.", arg1);
            }
            static /*string */ get Argument_UnknownNamedType()
            {
                return "Custom attribute '{0}' has unknown named type '{1}'.";
            }
            static /*string */ FormatArgument_UnknownNamedType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Custom attribute '{0}' has unknown named type '{1}'.", arg1, arg2);
            }
            static /*string */ get NotImplemented_TypeForValue()
            {
                return "Type '{0}' not handled in the custom attribute value decoder.";
            }
            static /*string */ FormatNotImplemented_TypeForValue(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Type '{0}' not handled in the custom attribute value decoder.", arg1);
            }
            static /*string */ get Argument_DllNameCannotBeEmpty()
            {
                return "DllName cannot be empty.";
            }
            static /*string */ get ArgumentOutOfRange_ParamSequence()
            {
                return "The specified parameter index is not in range.";
            }
            static /*string */ get Argument_InvalidArgumentForAttribute()
            {
                return "Invalid constructor argument {0} provided for MarshalAs attribute.";
            }
            static /*string */ FormatArgument_InvalidArgumentForAttribute(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Invalid constructor argument {0} provided for MarshalAs attribute.", arg1);
            }
            static /*string */ get Argument_InvalidParameterForUnmanagedType()
            {
                return "Named parameter {0} is not valid for UnmanagedType.{1} type.";
            }
            static /*string */ FormatArgument_InvalidParameterForUnmanagedType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Named parameter {0} is not valid for UnmanagedType.{1} type.", arg1, arg2);
            }
            static /*string */ get Argument_SizeConstMustBeSpecified()
            {
                return "SizeConst parameter must be specified for UnmanagedType.ByValTStr type.";
            }
            static /*string */ get InvalidOperation_GenericParametersAlreadySet()
            {
                return "The generic parameters are already defined on this MethodBuilder.";
            }
            static /*string */ get Argument_ShouldOnlySetVisibilityFlags()
            {
                return "Should only set visibility flags when creating EnumBuilder.";
            }
            static /*string */ get Argument_ConstantDoesntMatch()
            {
                return "Constant does not match the defined type.";
            }
            static /*string */ get Argument_ConstantNull()
            {
                return "Null is not a valid constant value for this type.";
            }
            static /*string */ get InvalidOperation_NoUnderlyingTypeOnEnum()
            {
                return "Underlying type information on enumeration is not specified.";
            }
            static /*string */ get InvalidOperation_ShouldNotHaveMethodBody()
            {
                return "Method body should not exist.";
            }
            static /*string */ get InvalidOperation_ConstructorNotAllowedOnInterface()
            {
                return "Interface cannot have constructors.";
            }
            static /*string */ get Argument_UnmatchedMethodForLocal()
            {
                return "Local passed in does not belong to this ILGenerator.";
            }
            static /*string */ get Argument_InvalidLabel()
            {
                return "Invalid Label.";
            }
            static /*string */ get Argument_MustBeSwitchOpCode()
            {
                return "Only 'OpCode.Switch' can be used.";
            }
            static /*string */ get Argument_NotMethodCallOpcode()
            {
                return "The specified opcode cannot be passed to EmitCall.";
            }
            static /*string */ get InvalidOperation_DefaultConstructorILGen()
            {
                return "Unable to access ILGenerator on a constructor created with DefineDefaultConstructor.";
            }
            static /*string */ get NotSupported_NoParentDefaultConstructor()
            {
                return "Parent does not have a default constructor. The default constructor must be explicitly defined.";
            }
            static /*string */ get InvalidOperation_TypeHasBeenCreated()
            {
                return "Unable to change after type has been created.";
            }
            static /*string */ get NotSupported_TypeNotYetCreated()
            {
                return "The invoked member is not supported before the type is created.";
            }
            static /*string */ get Argument_NoStaticVirtual()
            {
                return "Method cannot be both static and virtual.";
            }
            static /*string */ get Argument_BadExceptionCodeGen()
            {
                return "Incorrect code generation for exception block.";
            }
            static /*string */ get Argument_NotInExceptionBlock()
            {
                return "Not currently in an exception block.";
            }
            static /*string */ get Argument_ShouldNotSpecifyExceptionType()
            {
                return "Should not specify exception type for catch clause for filter block.";
            }
            static /*string */ get Arg_NotGenericMethodDefinition()
            {
                return "{0} is not a GenericMethodDefinition. MakeGenericMethod may only be called on a method for which MethodBase.IsGenericMethodDefinition is true.";
            }
            static /*string */ FormatArg_NotGenericMethodDefinition(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("{0} is not a GenericMethodDefinition. MakeGenericMethod may only be called on a method for which MethodBase.IsGenericMethodDefinition is true.", arg1);
            }
            static /*string */ get InvalidOperation_NotAVarArgCallingConvention()
            {
                return "Calling convention must be VarArgs.";
            }
            static /*string */ get ArgumentException_BadMethodImplBody()
            {
                return "MethodOverride's body must be from this type.";
            }
            static /*string */ get Argument_GenericParameter()
            {
                return "Method must be called on a Type for which Type.IsGenericParameter is false.";
            }
            static /*string */ get Argument_InvalidMethodOverride()
            {
                return "Type '{0}' tried to override method '{1}' but does not implement or inherit that method.";
            }
            static /*string */ FormatArgument_InvalidMethodOverride(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Type '{0}' tried to override method '{1}' but does not implement or inherit that method.", arg1, arg2);
            }
            static /*string */ get Argument_InterfaceNotFound()
            {
                return "Interface not found.";
            }
            static /*string */ get Argument_MethodOverridden()
            {
                return "Method '{0}' on type '{1}' is overriding a method that has been overridden.";
            }
            static /*string */ FormatArgument_MethodOverridden(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Method '{0}' on type '{1}' is overriding a method that has been overridden.", arg1, arg2);
            }
            static /*string */ get Argument_MustBeInterface()
            {
                return "Type passed must be an interface.";
            }
            static /*string */ get InvalidOperation_BadMethodBody()
            {
                return "Method '{0}' cannot have a method body";
            }
            static /*string */ FormatInvalidOperation_BadMethodBody(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Method '{0}' cannot have a method body", arg1);
            }
            static /*string */ get InvalidOperation_BadTypeAttributesNotAbstract()
            {
                return "Type must be declared abstract if any of its methods are abstract.";
            }
            static /*string */ get AmbiguousMatch_MemberInfo()
            {
                return "Ambiguous match found for '{0} {1}'";
            }
            static /*string */ FormatAmbiguousMatch_MemberInfo(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Ambiguous match found for '{0} {1}'", arg1, arg2);
            }
            static /*string */ get Argument_RedefinedLabel()
            {
                return "Label defined multiple times.";
            }
            static /*string */ get Argument_BadPInvokeMethod()
            {
                return "PInvoke methods must be static and native and cannot be abstract.";
            }
            static /*string */ get Argument_BadPInvokeOnInterface()
            {
                return "PInvoke methods cannot exist on interfaces.";
            }
            static /*string */ get Argument_MethodRedefined()
            {
                return "Method has been already defined.";
            }
            static /*string */ get Argument_GlobalMembersMustBeStatic()
            {
                return "Global members must be static.";
            }
            static /*string */ get InvalidOperation_GlobalsHaveBeenCreated()
            {
                return "Type definition of the global function has been completed.";
            }
            static /*string */ get Argument_BadSizeForData()
            {
                return "Data size must be &gt; 1 and &lt; 0x3f0000.";
            }
            static /*string */ get InvalidOperation_TokenNotPopulated()
            {
                return "MetadataToken for the member is not generated until the assembly saved.";
            }
            static /*string */ get Argument_BadSigFormat()
            {
                return "Incorrect signature format.";
            }
            static /*string */ get Argument_HasToBeArrayClass()
            {
                return "Must be an array type.";
            }
            static /*string */ get NotSupported_NonReflectedType()
            {
                return "Not supported in a non-reflected type.";
            }
            static /*string */ get NotSupported_SymbolMethod()
            {
                return "Not supported in an array method of a type definition that is not complete.";
            }
            static /*string */ get InvalidOperation_InvalidDocument()
            {
                return "Invalid source document.";
            }
            static /*string */ get InvalidOperation_UnmatchingSymScope()
            {
                return "Unmatching symbol scope.";
            }
            static /*string */ get Argument_MustBeEnum()
            {
                return "Type provided must be an Enum.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sre.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sre.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sre.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sre.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sre.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sre.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sre.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sre.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sre.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sre.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sre.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sre.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sre.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 104414;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":104414}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Reflection.Metadata"))