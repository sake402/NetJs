
//--TRIMMABLE-BOUNDARY-START(26)
(function ($global, $, $$, $sc, $sm, $spu, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Resources.Writer", 
    {
  "h": 26,
  "f": "System.Resources.Writer",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.Resources.Writer",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.Resources.Writer",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131098)
        $asm.$cls("$srw.System.Resources.IResourceWriter", ($self) => class IResourceWriter
        {
            static $h = 131098;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098394),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddResource",
      "o": "System$Resources$IResourceWriter$AddResource$2",
      "d": 131098,
      "h": 4295098394,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295098394),
//--TRIMMABLE-BOUNDARY-START(8590065690),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "AddResource",
      "o": "System$Resources$IResourceWriter$AddResource$1",
      "d": 131098,
      "h": 8590065690,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590065690),
//--TRIMMABLE-BOUNDARY-START(12885032986),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "AddResource",
      "o": "System$Resources$IResourceWriter$AddResource",
      "d": 131098,
      "h": 12885032986,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885032986),
//--TRIMMABLE-BOUNDARY-START(17180000282),
    {
      "r": 65537,
      "n": "Close",
      "o": "System$Resources$IResourceWriter$Close",
      "d": 131098,
      "h": 17180000282,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180000282),
//--TRIMMABLE-BOUNDARY-START(21474967578),
    {
      "r": 65537,
      "n": "Generate",
      "o": "System$Resources$IResourceWriter$Generate",
      "d": 131098,
      "h": 21474967578,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21474967578)
  ],
  "i": [90177537
  ],
  "h": 131098
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Resources.IResourceWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131098)
        
        
        //--TRIMMABLE-BOUNDARY-START(458778)
        $asm.$cls("$srw.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(150324314138)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(150324314138)
            
            //--TRIMMABLE-BOUNDARY-START(141734379546)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(141734379546)
            
            //--TRIMMABLE-BOUNDARY-START(146029346842)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$srw.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Resources.Writer", $.$srw.System.SR.$type.Assembly);
                    $.$srw.System.SR.s_resourceManager = temp;
                }
                return $.$srw.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(146029346842)
            
            //--TRIMMABLE-BOUNDARY-START(17180327962)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srw.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209216026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srw.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(17180327962)
            
            //--TRIMMABLE-BOUNDARY-START(128849477658)
            static /*string */ get InvalidOperation_ResourceWriterSaved()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899804698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The resource writer has already been closed and cannot be edited.";
            }
            //--TRIMMABLE-BOUNDARY-END(128849477658)
            
            //--TRIMMABLE-BOUNDARY-START(8590393370)
            static /*string */ get Argument_StreamNotWritable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130000922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stream was not writable.";
            }
            //--TRIMMABLE-BOUNDARY-END(8590393370)
            
            //--TRIMMABLE-BOUNDARY-START(137439412250)
            static /*string */ get NotSupported_UnseekableStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stream does not support seeking.";
            }
            //--TRIMMABLE-BOUNDARY-END(137439412250)
            
            //--TRIMMABLE-BOUNDARY-START(133144444954)
            static /*string */ get NotSupported_BinarySerializedResources()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This platform does not support binary serialized resources.";
            }
            //--TRIMMABLE-BOUNDARY-END(133144444954)
            
            //--TRIMMABLE-BOUNDARY-START(12885360666)
            static /*string */ get ArgumentOutOfRange_StreamLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stream length must be non-negative and less than 2^31 - 1 - origin.";
            }
            //--TRIMMABLE-BOUNDARY-END(12885360666)
            
            //--TRIMMABLE-BOUNDARY-START(154619281434)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(154619281434)
            
            //--TRIMMABLE-BOUNDARY-START(124554510362)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554510362);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554510362)
            
            //--TRIMMABLE-BOUNDARY-START(167504183322)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504183322);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$srw.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504183322)
            
            //--TRIMMABLE-BOUNDARY-START(115964575770)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964575770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srw.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(115964575770)
            
            //--TRIMMABLE-BOUNDARY-START(120259543066)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$srw.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(120259543066)
            
            //--TRIMMABLE-BOUNDARY-START(21475295258)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(21475295258)
            
            //--TRIMMABLE-BOUNDARY-START(25770262554)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(25770262554)
            
            //--TRIMMABLE-BOUNDARY-START(30065229850)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30065229850)
            
            //--TRIMMABLE-BOUNDARY-START(34360197146)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$srw.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(34360197146)
            
            //--TRIMMABLE-BOUNDARY-START(38655164442)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38655164442)
            
            //--TRIMMABLE-BOUNDARY-START(42950131738)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(42950131738)
            
            //--TRIMMABLE-BOUNDARY-START(47245099034)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(47245099034)
            
            //--TRIMMABLE-BOUNDARY-START(51540066330)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$srw.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(51540066330)
            
            //--TRIMMABLE-BOUNDARY-START(4295426074)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(154619281434)
                    this.s_usingResourceKeys = $.$srw.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(154619281434)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295426074)
            
            static $h = 458778;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 458778
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458778)
        
        
        //--TRIMMABLE-BOUNDARY-START(262170)
        $asm.$cls("$srw.System.Resources.ResourceWriter", ($self) => class ResourceWriter extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(158914052122)
            /*Func<Type, string>?*/ TypeNameConverter = null;
            //--TRIMMABLE-BOUNDARY-END(158914052122)
            
            //--TRIMMABLE-BOUNDARY-START(34360000538)
            /*void */ AddResource$2(/*string*/ name, /*Stream?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this.AddResourceInternal(name, value, false);
            }
            //--TRIMMABLE-BOUNDARY-END(34360000538)
            
            //--TRIMMABLE-BOUNDARY-START(55834837018)
            /*void */ AddResourceData(/*string*/ name, /*string*/ typeName, /*byte[]*/ serializedData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(typeName, "typeName");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serializedData, "serializedData");
                this.AddResourceData$1(name, typeName, $.$cast(serializedData, $.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(55834837018)
            
            //--TRIMMABLE-BOUNDARY-START(128849281050)
            static /*string */ get ResourceReaderTypeName()
            {
                return "System.Resources.ResourceReader, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"/*ResourceReaderFullyQualifiedName*/;
            }
            //--TRIMMABLE-BOUNDARY-END(128849281050)
            
            //--TRIMMABLE-BOUNDARY-START(133144248346)
            static /*string */ get ResourceSetTypeName()
            {
                return "System.Resources.RuntimeResourceSet"/*ResSetTypeName*/;
            }
            //--TRIMMABLE-BOUNDARY-END(133144248346)
            
            //--TRIMMABLE-BOUNDARY-START(163209019418)
            static /*void */ WriteData(/*BinaryWriter*/ writer, /*object*/ dataContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209019418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]?*/ let data = $.$as(dataContext, $.$typeArray($.$$.System.Byte));
                $.$$.System.Diagnostics.Debug.Assert$2(data !== null, "data != null");
                writer.Write$3(data);
            }
            //--TRIMMABLE-BOUNDARY-END(163209019418)
            
            //--TRIMMABLE-BOUNDARY-START(68719738906)
            /*int*/ static AverageNameSize = 40;
            //--TRIMMABLE-BOUNDARY-END(68719738906)
            
            //--TRIMMABLE-BOUNDARY-START(124554313754)
            /*string*/ static ResourceReaderFullyQualifiedName = null;
            //--TRIMMABLE-BOUNDARY-END(124554313754)
            
            //--TRIMMABLE-BOUNDARY-START(137439215642)
            /*string*/ static ResSetTypeName = null;
            //--TRIMMABLE-BOUNDARY-END(137439215642)
            
            //--TRIMMABLE-BOUNDARY-START(141734182938)
            /*int*/ static ResSetVersion = 2;
            //--TRIMMABLE-BOUNDARY-END(141734182938)
            
            //--TRIMMABLE-BOUNDARY-START(17180131354)
            /*SortedDictionary<string, object?>?*/ _resourceList = null;
            //--TRIMMABLE-BOUNDARY-END(17180131354)
            
            //--TRIMMABLE-BOUNDARY-START(8590196762)
            /*Stream*/ _output = null;
            //--TRIMMABLE-BOUNDARY-END(8590196762)
            
            //--TRIMMABLE-BOUNDARY-START(4295229466)
            /*Dictionary<string, object?>*/ _caseInsensitiveDups = null;
            //--TRIMMABLE-BOUNDARY-END(4295229466)
            
            //--TRIMMABLE-BOUNDARY-START(12885164058)
            /*Dictionary<string, PrecannedResource>?*/ _preserializedData = null;
            //--TRIMMABLE-BOUNDARY-END(12885164058)
            
            //--TRIMMABLE-BOUNDARY-START(21475098650)
            $ctor$2(/*string*/ fileName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475098650);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(fileName, "fileName");
                    this._output = new $.$$.System.IO.FileStream().$ctor$14(fileName, 2/*FileMode.Create*/, 2/*FileAccess.Write*/, 0/*FileShare.None*/);
                    this._resourceList = new ($.$sc.System.Collections.Generic.SortedDictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$2($.$srw.System.Resources.FastResourceComparer.Default);
                    this._caseInsensitiveDups = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098650)
            
            //--TRIMMABLE-BOUNDARY-START(25770065946)
            $ctor$1(/*Stream*/ stream)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770065946);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                    if (!stream.CanWrite)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$srw.System.SR.Argument_StreamNotWritable);
                    }
                    this._output = stream;
                    this._resourceList = new ($.$sc.System.Collections.Generic.SortedDictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$2($.$srw.System.Resources.FastResourceComparer.Default);
                    this._caseInsensitiveDups = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770065946)
            
            //--TRIMMABLE-BOUNDARY-START(38654967834)
            /*void */ AddResource$4(/*string*/ name, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this._caseInsensitiveDups.Add(name, null);
                this._resourceList.Add(name, value);
            }
            //--TRIMMABLE-BOUNDARY-END(38654967834)
            
            //--TRIMMABLE-BOUNDARY-START(42949935130)
            /*void */ AddResource$3(/*string*/ name, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949935130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                if (value !== null && $.$is(value, $.$$.System.IO.Stream))
                {
                    this.AddResourceInternal(name, $.$cast(value, $.$$.System.IO.Stream), false);
                }
                else 
                {
                    this._caseInsensitiveDups.Add(name, null);
                    this._resourceList.Add(name, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949935130)
            
            //--TRIMMABLE-BOUNDARY-START(47244902426)
            /*void */ AddResource$1(/*string*/ name, /*Stream?*/ value, /*bool*/ closeAfterWrite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244902426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this.AddResourceInternal(name, value, closeAfterWrite);
            }
            //--TRIMMABLE-BOUNDARY-END(47244902426)
            
            //--TRIMMABLE-BOUNDARY-START(64424771610)
            /*void */ AddResourceInternal(/*string*/ name, /*Stream?*/ value, /*bool*/ closeAfterWrite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424771610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._resourceList !== null, "_resourceList != null");
                if (value === null)
                {
                    this._caseInsensitiveDups.Add(name, null);
                    this._resourceList.Add(name, value);
                }
                else 
                {
                    if (!value.CanSeek)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$srw.System.SR.NotSupported_UnseekableStream);
                    }
                    this._caseInsensitiveDups.Add(name, null);
                    this._resourceList.Add(name, new $.$srw.System.Resources.ResourceWriter.StreamWrapper().$ctor$1(value, closeAfterWrite));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424771610)
            
            //--TRIMMABLE-BOUNDARY-START(51539869722)
            /*void */ AddResource(/*string*/ name, /*byte[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539869722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this._caseInsensitiveDups.Add(name, null);
                this._resourceList.Add(name, value);
            }
            //--TRIMMABLE-BOUNDARY-END(51539869722)
            
            //--TRIMMABLE-BOUNDARY-START(60129804314)
            /*void */ AddResourceData$1(/*string*/ name, /*string*/ typeName, /*object*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129804314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._resourceList === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this._caseInsensitiveDups.Add(name, null);
                this._preserializedData ??= new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$srw.System.Resources.ResourceWriter.PrecannedResource))().$ctor$6($.$srw.System.Resources.FastResourceComparer.Default);
                this._preserializedData.Add(name, new $.$srw.System.Resources.ResourceWriter.PrecannedResource().$ctor$1(typeName, data));
            }
            //--TRIMMABLE-BOUNDARY-END(60129804314)
            
            //--TRIMMABLE-BOUNDARY-START(327706)
            static $_PrecannedResource;
            static get PrecannedResource()
            {
                let $cls = $.$srw.System.Resources.ResourceWriter;
                return $cls.$_PrecannedResource ??= $asm.$ncls("$srw.System.Resources.ResourceWriter.PrecannedResource", ($self) => class PrecannedResource extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12885229594)
                    /*string*/ TypeName = null;
                    //--TRIMMABLE-BOUNDARY-END(12885229594)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590262298)
                    /*object*/ Data = null;
                    //--TRIMMABLE-BOUNDARY-END(8590262298)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295295002)
                    $ctor$1(/*string*/ typeName, /*object*/ data)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295295002);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.TypeName = typeName;
                            this.Data = data;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295295002)
                    
                    static $h = 327706;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885229594),
    {
      "t": 1310721,
      "n": "TypeName",
      "d": 327706,
      "h": 12885229594,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885229594),
//--TRIMMABLE-BOUNDARY-START(8590262298),
    {
      "t": 131073,
      "n": "Data",
      "d": 327706,
      "h": 8590262298,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590262298)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295002),
    {
      "p": [
        {
          "n": "typeName",
          "p": 1310721
        },
        {
          "n": "data",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327706,
      "h": 4295295002,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295295002)
  ],
  "d": 262170,
  "h": 327706
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Resources.ResourceWriter.PrecannedResource`; }
                }, $cls, ($v) => $cls.$_PrecannedResource = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327706)
            
            //--TRIMMABLE-BOUNDARY-START(393242)
            static $_StreamWrapper;
            static get StreamWrapper()
            {
                let $cls = $.$srw.System.Resources.ResourceWriter;
                return $cls.$_StreamWrapper ??= $asm.$ncls("$srw.System.Resources.ResourceWriter.StreamWrapper", ($self) => class StreamWrapper extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12885295130)
                    /*Stream*/ Stream = null;
                    //--TRIMMABLE-BOUNDARY-END(12885295130)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590327834)
                    /*bool*/ CloseAfterWrite = false;
                    //--TRIMMABLE-BOUNDARY-END(8590327834)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295360538)
                    $ctor$1(/*Stream*/ s, /*bool*/ closeAfterWrite)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295360538);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Stream = s;
                            this.CloseAfterWrite = closeAfterWrite;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295360538)
                    
                    static $h = 393242;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885295130),
    {
      "t": 94830593,
      "n": "Stream",
      "d": 393242,
      "h": 12885295130,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885295130),
//--TRIMMABLE-BOUNDARY-START(8590327834),
    {
      "t": 262145,
      "n": "CloseAfterWrite",
      "d": 393242,
      "h": 8590327834,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590327834)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360538),
    {
      "p": [
        {
          "n": "s",
          "p": 94830593
        },
        {
          "n": "closeAfterWrite",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393242,
      "h": 4295360538,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295360538)
  ],
  "d": 262170,
  "h": 393242
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Resources.ResourceWriter.StreamWrapper`; }
                }, $cls, ($v) => $cls.$_StreamWrapper = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393242)
            
            //--TRIMMABLE-BOUNDARY-START(73014706202)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
            }
            //--TRIMMABLE-BOUNDARY-END(73014706202)
            
            //--TRIMMABLE-BOUNDARY-START(77309673498)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309673498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (disposing)
                {
                    if (this._resourceList !== null)
                    {
                        this.Generate();
                    }
                    this._output?.Dispose();
                }
                this._output = null;
                this._caseInsensitiveDups = null;
            }
            //--TRIMMABLE-BOUNDARY-END(77309673498)
            
            //--TRIMMABLE-BOUNDARY-START(81604640794)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
            }
            //--TRIMMABLE-BOUNDARY-END(81604640794)
            
            //--TRIMMABLE-BOUNDARY-START(90194575386)
            /*void */ Generate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194575386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._resourceList === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                /*BinaryWriter*/ let bw = new $.$$.System.IO.BinaryWriter().$ctor$3(this._output, $.$$.System.Text.Encoding.UTF8);
                /*List<string>*/ let typeNames = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                bw.Write$11($.$$.System.Resources.ResourceManager.MagicNumber);
                bw.Write$11($.$$.System.Resources.ResourceManager.HeaderVersionNumber);
                /*MemoryStream*/ let resMgrHeaderBlob = new $.$$.System.IO.MemoryStream().$ctor$9(240);
                /*BinaryWriter*/ let resMgrHeaderPart = new $.$$.System.IO.BinaryWriter().$ctor$4(resMgrHeaderBlob);
                resMgrHeaderPart.Write$17($.$srw.System.Resources.ResourceWriter.ResourceReaderTypeName);
                resMgrHeaderPart.Write$17($.$srw.System.Resources.ResourceWriter.ResourceSetTypeName);
                resMgrHeaderPart.Flush();
                bw.Write$11($.$cast(resMgrHeaderBlob.Length, $.$$.System.Int32));
                $.$$.System.Diagnostics.Debug.Assert$2(resMgrHeaderBlob.Length > 0n, "ResourceWriter: Expected non empty header");
                resMgrHeaderBlob.Seek(0n, 0/*SeekOrigin.Begin*/);
                resMgrHeaderBlob.CopyTo(bw.BaseStream, $.$cast(resMgrHeaderBlob.Length, $.$$.System.Int32));
                bw.Write$11(2/*ResSetVersion*/);
                /*int*/ let numResources = this._resourceList.Count;
                if (this._preserializedData !== null)
                {
                    numResources += this._preserializedData.Count;
                }
                bw.Write$11(numResources);
                /*int[]*/ let nameHashes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [numResources], null);
                /*int[]*/ let namePositions = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [numResources], null);
                /*int*/ let curNameNumber = 0;
                /*MemoryStream*/ let nameSection = new $.$$.System.IO.MemoryStream().$ctor$9(((numResources * 40/*AverageNameSize*/) | 0));
                /*BinaryWriter*/ let names = new $.$$.System.IO.BinaryWriter().$ctor$3(nameSection, $.$$.System.Text.Encoding.Unicode);
                /*Stream*/ let dataSection = new $.$$.System.IO.MemoryStream().$ctor$3();
                let $disposable1 = null;
                try
                {
                    $disposable1 = dataSection;
                    /*BinaryWriter*/ let data = new $.$$.System.IO.BinaryWriter().$ctor$3(dataSection, $.$$.System.Text.Encoding.UTF8);
                    if (this._preserializedData !== null)
                    {
                        var $en4 = this._preserializedData.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var entry = $en4.Current;
                            {
                                this._resourceList.Add(entry.Key, entry.Value);
                            }
                        }
                    }
                    var $en3 = this._resourceList.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var item = $en3.Current;
                        {
                            $.$$.System.Array.$WriteT1.call(nameHashes, $.$srw.System.Resources.FastResourceComparer.HashFunction(item.Key), curNameNumber);
                            $.$$.System.Array.$WriteT1.call(namePositions, $.$cast(names.Seek(0, 1/*SeekOrigin.Current*/), $.$$.System.Int32), curNameNumber++);
                            names.Write$17(item.Key);
                            names.Write$11($.$cast(data.Seek(0, 1/*SeekOrigin.Current*/), $.$$.System.Int32));
                            /*object?*/ let value = item.Value;
                            /*ResourceTypeCode*/ let typeCode = $.$srw.System.Resources.ResourceWriter.FindTypeCode(value, typeNames);
                            data.Write7BitEncodedInt(typeCode);
                            /*var*/ let userProvidedResource = $.$as(value, $.$srw.System.Resources.ResourceWriter.PrecannedResource);
                            if (userProvidedResource !== null)
                            {
                                $.$srw.System.Resources.ResourceWriter.WriteData(data, userProvidedResource.Data);
                            }
                            else 
                            {
                                $.$srw.System.Resources.ResourceWriter.WriteValue(typeCode, value, data);
                            }
                        }
                    }
                    bw.Write$11(typeNames.Count);
                    var $en3 = typeNames.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var typeName = $en3.Current;
                        {
                            bw.Write$17(typeName);
                        }
                    }
                    $.$$.System.Array.Sort$16($.$$.System.Int32, $.$$.System.Int32, nameHashes, namePositions);
                    bw.Flush();
                    /*int*/ let alignBytes = ($.$cast(bw.BaseStream.Position, $.$$.System.Int32)) & 7;
                    if (alignBytes > 0)
                    {
                        for(/*int*/ let i = 0; i < ((8 - alignBytes) | 0); i++)
                        {
                            bw.Write$4($.$$.System.String.get_Chars.call("PAD", i % 3));
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2((bw.BaseStream.Position & 7n) === 0n, "ResourceWriter: Name hashes array won't be 8 byte aligned!  Ack!");
                    let $i2 = 0;
                    let $arr2 = nameHashes;
                    while ($i2 < $arr2.length)
                    {
                        let hash = $arr2[$i2++];
                        bw.Write$11(hash);
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2((bw.BaseStream.Position & 3n) === 0n, "ResourceWriter: Name positions array won't be 4 byte aligned!  Ack!");
                    let $i3 = 0;
                    let $arr3 = namePositions;
                    while ($i3 < $arr3.length)
                    {
                        let pos = $arr3[$i3++];
                        bw.Write$11(pos);
                    }
                    bw.Flush();
                    names.Flush();
                    data.Flush();
                    /*int*/ let startOfDataSection = $.$cast((bw.Seek(0, 1/*SeekOrigin.Current*/) + nameSection.Length), $.$$.System.Int32);
                    startOfDataSection += 4;
                    bw.Write$11(startOfDataSection);
                    if (nameSection.Length > 0n)
                    {
                        nameSection.Seek(0n, 0/*SeekOrigin.Begin*/);
                        nameSection.CopyTo(bw.BaseStream, $.$cast(nameSection.Length, $.$$.System.Int32));
                    }
                    names.Dispose();
                    $.$$.System.Diagnostics.Debug.Assert$2(BigInt(startOfDataSection) === bw.Seek(0, 1/*SeekOrigin.Current*/), "ResourceWriter::Generate - start of data section is wrong!");
                    dataSection.Position = 0n;
                    dataSection.CopyTo$1(bw.BaseStream);
                    data.Dispose();
                }
                finally
                {
                    $disposable1?.System$IDisposable$Dispose();
                }
                bw.Flush();
                this._resourceList = null;
            }
            //--TRIMMABLE-BOUNDARY-END(90194575386)
            
            //--TRIMMABLE-BOUNDARY-START(85899608090)
            static /*ResourceTypeCode */ FindTypeCode(/*object?*/ value, /*List<string>*/ types)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899608090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return 0/*ResourceTypeCode.Null*/;
                }
                /*Type*/ let type = $.$$.System.Object.GetType.call(value);
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.String.$type))
                {
                    return 1/*ResourceTypeCode.String*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Int32.$type))
                {
                    return 8/*ResourceTypeCode.Int32*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Boolean.$type))
                {
                    return 2/*ResourceTypeCode.Boolean*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Char.$type))
                {
                    return 3/*ResourceTypeCode.Char*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Byte.$type))
                {
                    return 4/*ResourceTypeCode.Byte*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.SByte.$type))
                {
                    return 5/*ResourceTypeCode.SByte*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Int16.$type))
                {
                    return 6/*ResourceTypeCode.Int16*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Int64.$type))
                {
                    return 10/*ResourceTypeCode.Int64*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.UInt16.$type))
                {
                    return 7/*ResourceTypeCode.UInt16*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.UInt32.$type))
                {
                    return 9/*ResourceTypeCode.UInt32*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.UInt64.$type))
                {
                    return 11/*ResourceTypeCode.UInt64*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Single.$type))
                {
                    return 12/*ResourceTypeCode.Single*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Double.$type))
                {
                    return 13/*ResourceTypeCode.Double*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Decimal.$type))
                {
                    return 14/*ResourceTypeCode.Decimal*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.DateTime.$type))
                {
                    return 15/*ResourceTypeCode.DateTime*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.TimeSpan.$type))
                {
                    return 16/*ResourceTypeCode.TimeSpan*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$typeArray($.$$.System.Byte).$type))
                {
                    return 32/*ResourceTypeCode.ByteArray*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$srw.System.Resources.ResourceWriter.StreamWrapper.$type))
                {
                    return 33/*ResourceTypeCode.Stream*/;
                }
                /*string*/ let typeName;
                if ($.$$.System.Type.op_Equality$1(type, $.$srw.System.Resources.ResourceWriter.PrecannedResource.$type))
                {
                    typeName = ($.$cast(value, $.$srw.System.Resources.ResourceWriter.PrecannedResource)).TypeName;
                    if ($.$$.System.String.StartsWith$2.call(typeName, "ResourceTypeCode.", 4/*StringComparison.Ordinal*/))
                    {
                        typeName = $.$$.System.String.Substring$1.call(typeName, 17);
                        /*ResourceTypeCode*/ let typeCode = $.$$.System.Enum.Parse$7($.$srw.System.Resources.ResourceTypeCode, typeName);
                        return typeCode;
                    }
                }
                else 
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$16($.$srw.System.SR.NotSupported_BinarySerializedResources);
                }
                /*int*/ let typeIndex = types.IndexOf$2(typeName);
                if (typeIndex === -1)
                {
                    typeIndex = types.Count;
                    types.Add(typeName);
                }
                return (typeIndex + 64/*ResourceTypeCode.StartOfUserTypes*/);
            }
            //--TRIMMABLE-BOUNDARY-END(85899608090)
            
            //--TRIMMABLE-BOUNDARY-START(167503986714)
            static /*void */ WriteValue(/*ResourceTypeCode*/ typeCode, /*object?*/ value, /*BinaryWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503986714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(writer !== null, "writer != null");
                switch(typeCode)
                {
                    case 0/*ResourceTypeCode.Null*/:
                    break;
                    case 1/*ResourceTypeCode.String*/:
                    writer.Write$17($.$cast(value, $.$$.System.String));
                    break;
                    case 2/*ResourceTypeCode.Boolean*/:
                    writer.Write($.$cast(value, $.$$.System.Boolean));
                    break;
                    case 3/*ResourceTypeCode.Char*/:
                    writer.Write$18($.$cast(value, $.$$.System.Char));
                    break;
                    case 4/*ResourceTypeCode.Byte*/:
                    writer.Write$1($.$cast(value, $.$$.System.Byte));
                    break;
                    case 5/*ResourceTypeCode.SByte*/:
                    writer.Write$15($.$cast(value, $.$$.System.SByte));
                    break;
                    case 6/*ResourceTypeCode.Int16*/:
                    writer.Write$10($.$cast(value, $.$$.System.Int16));
                    break;
                    case 7/*ResourceTypeCode.UInt16*/:
                    writer.Write$18($.$cast(value, $.$$.System.UInt16));
                    break;
                    case 8/*ResourceTypeCode.Int32*/:
                    writer.Write$11($.$cast(value, $.$$.System.Int32));
                    break;
                    case 9/*ResourceTypeCode.UInt32*/:
                    writer.Write$19($.$cast(value, $.$$.System.UInt32));
                    break;
                    case 10/*ResourceTypeCode.Int64*/:
                    writer.Write$12($.$cast(value, $.$$.System.Int64));
                    break;
                    case 11/*ResourceTypeCode.UInt64*/:
                    writer.Write$20($.$cast(value, $.$$.System.UInt64));
                    break;
                    case 12/*ResourceTypeCode.Single*/:
                    writer.Write$16($.$cast(value, $.$$.System.Single));
                    break;
                    case 13/*ResourceTypeCode.Double*/:
                    writer.Write$8($.$cast(value, $.$$.System.Double));
                    break;
                    case 14/*ResourceTypeCode.Decimal*/:
                    writer.Write$7($.$cast(value, $.$$.System.Decimal));
                    break;
                    case 15/*ResourceTypeCode.DateTime*/:
                    /*long*/ let data = ($.$cast(value, $.$$.System.DateTime)).ToBinary();
                    writer.Write$12(data);
                    break;
                    case 16/*ResourceTypeCode.TimeSpan*/:
                    writer.Write$12(($.$cast(value, $.$$.System.TimeSpan)).Ticks);
                    break;
                    case 32/*ResourceTypeCode.ByteArray*/:
                    {
                        /*byte[]*/ let bytes = $.$cast(value, $.$typeArray($.$$.System.Byte));
                        writer.Write$11(bytes.length);
                        writer.Write$2(bytes, 0, bytes.length);
                        break;
                    }
                    case 33/*ResourceTypeCode.Stream*/:
                    {
                        /*StreamWrapper*/ let sw = $.$cast(value, $.$srw.System.Resources.ResourceWriter.StreamWrapper);
                        if ($.$$.System.Type.op_Equality$1($.$$.System.Object.GetType.call(sw.Stream), $.$$.System.IO.MemoryStream.$type))
                        {
                            /*MemoryStream*/ let ms = $.$cast(sw.Stream, $.$$.System.IO.MemoryStream);
                            if (ms.Length > BigInt(2147483647/*int.MaxValue*/))
                            {
                                throw new $.$$.System.ArgumentException().$ctor$14($.$srw.System.SR.ArgumentOutOfRange_StreamLength);
                            }
                            /*byte[]*/ let arr = ms.ToArray();
                            writer.Write$11(arr.length);
                            writer.Write$2(arr, 0, arr.length);
                        }
                        else 
                        {
                            /*Stream*/ let s = sw.Stream;
                            if (s.Length > BigInt(2147483647/*int.MaxValue*/))
                            {
                                throw new $.$$.System.ArgumentException().$ctor$14($.$srw.System.SR.ArgumentOutOfRange_StreamLength);
                            }
                            s.Position = 0n;
                            writer.Write$11($.$cast(s.Length, $.$$.System.Int32));
                            /*byte[]*/ let buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [4096], null);
                            /*int*/ let read;
                            while((read = s.Read(buffer, 0, buffer.length)) !== 0)
                            {
                                writer.Write$2(buffer, 0, read);
                            }
                            if (sw.CloseAfterWrite)
                            {
                                s.Close();
                            }
                        }
                        break;
                    }
                    default:
                    $.$$.System.Diagnostics.Debug.Assert$4(typeCode >= 64/*ResourceTypeCode.StartOfUserTypes*/, `ResourceReader: Unsupported ResourceTypeCode in .resources file!  ${typeCode}`);
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$16($.$srw.System.SR.NotSupported_BinarySerializedResources);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167503986714)
            
            //--TRIMMABLE-BOUNDARY-START(4295098394)
            //Generated interface implemetation for System.Resources.IResourceWriter.AddResource(string, string?)
            System$Resources$IResourceWriter$AddResource$2()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddResource$4(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098394)
            
            //--TRIMMABLE-BOUNDARY-START(8590065690)
            //Generated interface implemetation for System.Resources.IResourceWriter.AddResource(string, object?)
            System$Resources$IResourceWriter$AddResource$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddResource$3(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590065690)
            
            //--TRIMMABLE-BOUNDARY-START(12885032986)
            //Generated interface implemetation for System.Resources.IResourceWriter.AddResource(string, byte[]?)
            System$Resources$IResourceWriter$AddResource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885032986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddResource(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885032986)
            
            //--TRIMMABLE-BOUNDARY-START(17180000282)
            //Generated interface implemetation for System.Resources.IResourceWriter.Close()
            System$Resources$IResourceWriter$Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Close(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180000282)
            
            //--TRIMMABLE-BOUNDARY-START(21474967578)
            //Generated interface implemetation for System.Resources.IResourceWriter.Generate()
            System$Resources$IResourceWriter$Generate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Generate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21474967578)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(124554313754)
                    this.ResourceReaderFullyQualifiedName = "System.Resources.ResourceReader, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089";
                    //--TRIMMABLE-BOUNDARY-END(124554313754)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439215642)
                    this.ResSetTypeName = "System.Resources.RuntimeResourceSet";
                    //--TRIMMABLE-BOUNDARY-END(137439215642)
                    
                }
            }
            static $h = 262170;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(158914052122),
    {
      "p": $.$$.System.Func$$$($.$$.System.Type, $.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964379162,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324117530,
        "f": 83886081
      },
      "n": "TypeNameConverter",
      "d": 262170,
      "h": 158914052122,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914052122),
//--TRIMMABLE-BOUNDARY-START(128849281050),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784509978,
        "f": 50331682
      },
      "n": "ResourceReaderTypeName",
      "d": 262170,
      "h": 128849281050,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(128849281050),
//--TRIMMABLE-BOUNDARY-START(133144248346),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374444570,
        "f": 50331682
      },
      "n": "ResourceSetTypeName",
      "d": 262170,
      "h": 133144248346,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(133144248346)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360000538),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 94830593
        }
      ],
      "n": "AddResource",
      "o": "@$2",
      "d": 262170,
      "h": 34360000538,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360000538),
//--TRIMMABLE-BOUNDARY-START(55834837018),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "typeName",
          "p": 1310721
        },
        {
          "n": "serializedData",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "AddResourceData",
      "d": 262170,
      "h": 55834837018,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834837018),
//--TRIMMABLE-BOUNDARY-START(163209019418),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 91160577
        },
        {
          "n": "dataContext",
          "p": 131073
        }
      ],
      "n": "WriteData",
      "d": 262170,
      "h": 163209019418,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(163209019418),
//--TRIMMABLE-BOUNDARY-START(38654967834),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddResource",
      "o": "@$4",
      "d": 262170,
      "h": 38654967834,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654967834),
//--TRIMMABLE-BOUNDARY-START(42949935130),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "AddResource",
      "o": "@$3",
      "d": 262170,
      "h": 42949935130,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949935130),
//--TRIMMABLE-BOUNDARY-START(47244902426),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 94830593
        },
        {
          "n": "closeAfterWrite",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "AddResource",
      "o": "@$1",
      "d": 262170,
      "h": 47244902426,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244902426),
//--TRIMMABLE-BOUNDARY-START(64424771610),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 94830593
        },
        {
          "n": "closeAfterWrite",
          "p": 262145
        }
      ],
      "n": "AddResourceInternal",
      "d": 262170,
      "h": 64424771610,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64424771610),
//--TRIMMABLE-BOUNDARY-START(51539869722),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "AddResource",
      "d": 262170,
      "h": 51539869722,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539869722),
//--TRIMMABLE-BOUNDARY-START(60129804314),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "typeName",
          "p": 1310721
        },
        {
          "n": "data",
          "p": 131073
        }
      ],
      "n": "AddResourceData",
      "o": "@$1",
      "d": 262170,
      "h": 60129804314,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60129804314),
//--TRIMMABLE-BOUNDARY-START(73014706202),
    {
      "r": 65537,
      "n": "Close",
      "d": 262170,
      "h": 73014706202,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014706202),
//--TRIMMABLE-BOUNDARY-START(77309673498),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 262170,
      "h": 77309673498,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77309673498),
//--TRIMMABLE-BOUNDARY-START(81604640794),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 262170,
      "h": 81604640794,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604640794),
//--TRIMMABLE-BOUNDARY-START(90194575386),
    {
      "r": 65537,
      "n": "Generate",
      "d": 262170,
      "h": 90194575386,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194575386),
//--TRIMMABLE-BOUNDARY-START(85899608090),
    {
      "r": 196634,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "types",
          "p": $.$$.System.Collections.Generic.List$$($.$$.System.String).$h
        }
      ],
      "n": "FindTypeCode",
      "d": 262170,
      "h": 85899608090,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85899608090),
//--TRIMMABLE-BOUNDARY-START(167503986714),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeCode",
          "p": 196634
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "writer",
          "p": 91160577
        }
      ],
      "n": "WriteValue",
      "d": 262170,
      "h": 167503986714,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(167503986714)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(68719738906),
    {
      "t": 655361,
      "n": "AverageNameSize",
      "d": 262170,
      "h": 68719738906,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68719738906),
//--TRIMMABLE-BOUNDARY-START(124554313754),
    {
      "t": 1310721,
      "n": "ResourceReaderFullyQualifiedName",
      "d": 262170,
      "h": 124554313754,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554313754),
//--TRIMMABLE-BOUNDARY-START(137439215642),
    {
      "t": 1310721,
      "n": "ResSetTypeName",
      "d": 262170,
      "h": 137439215642,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(137439215642),
//--TRIMMABLE-BOUNDARY-START(141734182938),
    {
      "t": 655361,
      "n": "ResSetVersion",
      "d": 262170,
      "h": 141734182938,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(141734182938),
//--TRIMMABLE-BOUNDARY-START(17180131354),
    {
      "t": $.$sc.System.Collections.Generic.SortedDictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "n": "_resourceList",
      "d": 262170,
      "h": 17180131354,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180131354),
//--TRIMMABLE-BOUNDARY-START(8590196762),
    {
      "t": 94830593,
      "n": "_output",
      "d": 262170,
      "h": 8590196762,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196762),
//--TRIMMABLE-BOUNDARY-START(4295229466),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "n": "_caseInsensitiveDups",
      "d": 262170,
      "h": 4295229466,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229466),
//--TRIMMABLE-BOUNDARY-START(12885164058),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$srw.System.Resources.ResourceWriter.PrecannedResource).$h,
      "n": "_preserializedData",
      "d": 262170,
      "h": 12885164058,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885164058)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475098650),
    {
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262170,
      "h": 21475098650,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475098650),
//--TRIMMABLE-BOUNDARY-START(25770065946),
    {
      "p": [
        {
          "n": "stream",
          "p": 94830593
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262170,
      "h": 25770065946,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770065946)
  ],
  "i": [131098,90177537
  ],
  "j": [327706,393242
  ],
  "h": 262170
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srw.System.Resources.IResourceWriter, $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Resources.ResourceWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262170)
        
        
        //--TRIMMABLE-BOUNDARY-START(196634)
        $asm.$str("$srw.System.Resources.ResourceTypeCode", ($self) => class ResourceTypeCode extends $.$$.System.Enum
        {
            static Null = 0;
            static String = 1;
            static Boolean = 2;
            static Char = 3;
            static Byte = 4;
            static SByte = 5;
            static Int16 = 6;
            static UInt16 = 7;
            static Int32 = 8;
            static UInt32 = 9;
            static Int64 = 10;
            static UInt64 = 11;
            static Single = 12;
            static Double = 13;
            static Decimal = 14;
            static DateTime = 15;
            static TimeSpan = 16;
            static LastPrimitive = 16;
            static ByteArray = 32;
            static Stream = 33;
            static StartOfUserTypes = 64;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Null": 0n,
                    "String": 1n,
                    "Boolean": 2n,
                    "Char": 3n,
                    "Byte": 4n,
                    "SByte": 5n,
                    "Int16": 6n,
                    "UInt16": 7n,
                    "Int32": 8n,
                    "UInt32": 9n,
                    "Int64": 10n,
                    "UInt64": 11n,
                    "Single": 12n,
                    "Double": 13n,
                    "Decimal": 14n,
                    "DateTime": 15n,
                    "TimeSpan": 16n,
                    "LastPrimitive": 16n,
                    "ByteArray": 32n,
                    "Stream": 33n,
                    "StartOfUserTypes": 64n
                };
            }
            static $h = 196634;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(55834771482),
    {
      "t": 196634,
      "n": "Null",
      "d": 196634,
      "h": 55834771482,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834771482),
//--TRIMMABLE-BOUNDARY-START(77309607962),
    {
      "t": 196634,
      "n": "String",
      "d": 196634,
      "h": 77309607962,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77309607962),
//--TRIMMABLE-BOUNDARY-START(8590131226),
    {
      "t": 196634,
      "n": "Boolean",
      "d": 196634,
      "h": 8590131226,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590131226),
//--TRIMMABLE-BOUNDARY-START(21475033114),
    {
      "t": 196634,
      "n": "Char",
      "d": 196634,
      "h": 21475033114,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475033114),
//--TRIMMABLE-BOUNDARY-START(12885098522),
    {
      "t": 196634,
      "n": "Byte",
      "d": 196634,
      "h": 12885098522,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885098522),
//--TRIMMABLE-BOUNDARY-START(60129738778),
    {
      "t": 196634,
      "n": "SByte",
      "d": 196634,
      "h": 60129738778,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60129738778),
//--TRIMMABLE-BOUNDARY-START(38654902298),
    {
      "t": 196634,
      "n": "Int16",
      "d": 196634,
      "h": 38654902298,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654902298),
//--TRIMMABLE-BOUNDARY-START(85899542554),
    {
      "t": 196634,
      "n": "UInt16",
      "d": 196634,
      "h": 85899542554,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899542554),
//--TRIMMABLE-BOUNDARY-START(42949869594),
    {
      "t": 196634,
      "n": "Int32",
      "d": 196634,
      "h": 42949869594,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949869594),
//--TRIMMABLE-BOUNDARY-START(90194509850),
    {
      "t": 196634,
      "n": "UInt32",
      "d": 196634,
      "h": 90194509850,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90194509850),
//--TRIMMABLE-BOUNDARY-START(47244836890),
    {
      "t": 196634,
      "n": "Int64",
      "d": 196634,
      "h": 47244836890,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47244836890),
//--TRIMMABLE-BOUNDARY-START(94489477146),
    {
      "t": 196634,
      "n": "UInt64",
      "d": 196634,
      "h": 94489477146,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489477146),
//--TRIMMABLE-BOUNDARY-START(64424706074),
    {
      "t": 196634,
      "n": "Single",
      "d": 196634,
      "h": 64424706074,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424706074),
//--TRIMMABLE-BOUNDARY-START(34359935002),
    {
      "t": 196634,
      "n": "Double",
      "d": 196634,
      "h": 34359935002,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34359935002),
//--TRIMMABLE-BOUNDARY-START(30064967706),
    {
      "t": 196634,
      "n": "Decimal",
      "d": 196634,
      "h": 30064967706,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064967706),
//--TRIMMABLE-BOUNDARY-START(25770000410),
    {
      "t": 196634,
      "n": "DateTime",
      "d": 196634,
      "h": 25770000410,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770000410),
//--TRIMMABLE-BOUNDARY-START(81604575258),
    {
      "t": 196634,
      "n": "TimeSpan",
      "d": 196634,
      "h": 81604575258,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604575258),
//--TRIMMABLE-BOUNDARY-START(51539804186),
    {
      "t": 196634,
      "n": "LastPrimitive",
      "d": 196634,
      "h": 51539804186,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539804186),
//--TRIMMABLE-BOUNDARY-START(17180065818),
    {
      "t": 196634,
      "n": "ByteArray",
      "d": 196634,
      "h": 17180065818,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180065818),
//--TRIMMABLE-BOUNDARY-START(73014640666),
    {
      "t": 196634,
      "n": "Stream",
      "d": 196634,
      "h": 73014640666,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73014640666),
//--TRIMMABLE-BOUNDARY-START(68719673370),
    {
      "t": 196634,
      "n": "StartOfUserTypes",
      "d": 196634,
      "h": 68719673370,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68719673370)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163930),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196634,
      "h": 4295163930,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163930)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 196634
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Resources.ResourceTypeCode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196634)
        
        
        //--TRIMMABLE-BOUNDARY-START(65562)
        $asm.$cls("$srw.System.Resources.FastResourceComparer", ($self) => class FastResourceComparer extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17179934746)
            /*FastResourceComparer*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(17179934746)
            
            //--TRIMMABLE-BOUNDARY-START(25769869338)
            /*int */ GetHashCode$1(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srw.System.Resources.FastResourceComparer.HashFunction(key);
            }
            //--TRIMMABLE-BOUNDARY-END(25769869338)
            
            //--TRIMMABLE-BOUNDARY-START(30064836634)
            static /*int */ HashFunction(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let hash = 5381;
                for(/*int*/ let i = 0; i < key.length; i++)
                {
                    hash = ((((hash << 5) >>> 0) + hash) >>> 0) ^ $.$$.System.String.get_Chars.call(key, i);
                }
                return (hash | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(30064836634)
            
            //--TRIMMABLE-BOUNDARY-START(12884967450)
            /*int */ Compare(/*string?*/ a, /*string?*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.CompareOrdinal$2(a, b);
            }
            //--TRIMMABLE-BOUNDARY-END(12884967450)
            
            //--TRIMMABLE-BOUNDARY-START(21474902042)
            /*bool */ Equals$2(/*string?*/ a, /*string?*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Equals$3(a, b);
            }
            //--TRIMMABLE-BOUNDARY-END(21474902042)
            
            //--TRIMMABLE-BOUNDARY-START(4354277377)
            //Generated interface implemetation for System.Collections.Generic.IComparer<string>.Compare(string?, string?)
            System$Collections$Generic$IComparer$$$Compare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354277377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Compare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354277377)
            
            //--TRIMMABLE-BOUNDARY-START(4354605057)
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<string>.Equals(string?, string?)
            System$Collections$Generic$IEqualityComparer$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354605057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354605057)
            
            //--TRIMMABLE-BOUNDARY-START(8649572353)
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<string>.GetHashCode(string)
            System$Collections$Generic$IEqualityComparer$$$GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649572353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetHashCode$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649572353)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-START(4295032858)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17179934746)
                    this.Default = new $.$srw.System.Resources.FastResourceComparer().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(17179934746)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295032858)
            
            static $h = 65562;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769869338),
    {
      "r": 655361,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetHashCode",
      "o": "@$1",
      "d": 65562,
      "h": 25769869338,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769869338),
//--TRIMMABLE-BOUNDARY-START(30064836634),
    {
      "r": 655361,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "HashFunction",
      "d": 65562,
      "h": 30064836634,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30064836634),
//--TRIMMABLE-BOUNDARY-START(12884967450),
    {
      "r": 655361,
      "p": [
        {
          "n": "a",
          "p": 1310721
        },
        {
          "n": "b",
          "p": 1310721
        }
      ],
      "n": "Compare",
      "d": 65562,
      "h": 12884967450,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12884967450),
//--TRIMMABLE-BOUNDARY-START(21474902042),
    {
      "r": 262145,
      "p": [
        {
          "n": "a",
          "p": 1310721
        },
        {
          "n": "b",
          "p": 1310721
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 65562,
      "h": 21474902042,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474902042)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17179934746),
    {
      "t": 65562,
      "n": "Default",
      "d": 65562,
      "h": 17179934746,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17179934746)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590000154),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65562,
      "h": 8590000154,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000154)
  ],
  "i": [$.$$.System.Collections.Generic.IComparer$$($.$$.System.String).$h,$.$$.System.Collections.Generic.IEqualityComparer$$($.$$.System.String).$h
  ],
  "h": 65562
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IComparer$$($.$$.System.String), $.$$.System.Collections.Generic.IEqualityComparer$$($.$$.System.String) ]; }
            static get $fullName() { return `System.Resources.FastResourceComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65562)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime"))
//--TRIMMABLE-BOUNDARY-END(26)
