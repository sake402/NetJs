
//--TRIMMABLE-BOUNDARY-START(26)
(async function () {
(function ($global, $, $$, $sc, $sm, $spu, $sr) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.Resources.Writer", 
    {
  "h": 26,
  "f": "System.Resources.Writer",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Resources.Writer",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Resources.Writer",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131098)
        $asm.$cls(`$srw.SR.IResourceWriter`, ($self) => class IResourceWriter
        {
            static $h = 131098;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885032986),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddResource",
      "o": "SR$IResourceWriter$AddResource$2",
      "d": 131098,
      "h": 12885032986,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885032986),
//--TRIMMABLE-BOUNDARY-START(8590065690),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "AddResource",
      "o": "SR$IResourceWriter$AddResource$1",
      "d": 131098,
      "h": 8590065690,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590065690),
//--TRIMMABLE-BOUNDARY-START(4295098394),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "AddResource",
      "o": "SR$IResourceWriter$AddResource",
      "d": 131098,
      "h": 4295098394,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295098394),
//--TRIMMABLE-BOUNDARY-START(17180000282),
    {
      "r": 65537,
      "n": "Close",
      "o": "SR$IResourceWriter$Close",
      "d": 131098,
      "h": 17180000282,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180000282),
//--TRIMMABLE-BOUNDARY-START(21474967578),
    {
      "r": 65537,
      "n": "Generate",
      "o": "SR$IResourceWriter$Generate",
      "d": 131098,
      "h": 21474967578,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21474967578)
  ],
  "h": 131098
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Resources.IResourceWriter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Resources${separator}IResourceWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131098)
        
        

        //--TRIMMABLE-BOUNDARY-START(458778)
        $asm.$cls(`$srw.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(150324314138)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(150324314138)
            
            //--TRIMMABLE-BOUNDARY-START(141734379546)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(141734379546)
            
            //--TRIMMABLE-BOUNDARY-START(146029346842)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$srw.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.Resources.Writer", $.$srw.S.SR.$type.Assembly);
                    $.$srw.S.SR.s_resourceManager = temp;
                }
                return $.$srw.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(146029346842)
            
            //--TRIMMABLE-BOUNDARY-START(17180327962)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srw.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209216026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srw.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(17180327962)
            
            //--TRIMMABLE-BOUNDARY-START(128849477658)
            static /*string */ get InvalidOperation_ResourceWriterSaved()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899804698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The resource writer has already been closed and cannot be edited.";
            }
            //--TRIMMABLE-BOUNDARY-END(128849477658)
            
            //--TRIMMABLE-BOUNDARY-START(8590393370)
            static /*string */ get Argument_StreamNotWritable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130000922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stream was not writable.";
            }
            //--TRIMMABLE-BOUNDARY-END(8590393370)
            
            //--TRIMMABLE-BOUNDARY-START(137439412250)
            static /*string */ get NotSupported_UnseekableStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stream does not support seeking.";
            }
            //--TRIMMABLE-BOUNDARY-END(137439412250)
            
            //--TRIMMABLE-BOUNDARY-START(133144444954)
            static /*string */ get NotSupported_BinarySerializedResources()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This platform does not support binary serialized resources.";
            }
            //--TRIMMABLE-BOUNDARY-END(133144444954)
            
            //--TRIMMABLE-BOUNDARY-START(12885360666)
            static /*string */ get ArgumentOutOfRange_StreamLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stream length must be non-negative and less than 2^31 - 1 - origin.";
            }
            //--TRIMMABLE-BOUNDARY-END(12885360666)
            
            //--TRIMMABLE-BOUNDARY-START(154619281434)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(154619281434)
            
            //--TRIMMABLE-BOUNDARY-START(124554510362)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554510362);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554510362)
            
            //--TRIMMABLE-BOUNDARY-START(167504183322)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504183322);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$srw.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504183322)
            
            //--TRIMMABLE-BOUNDARY-START(120259543066)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srw.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srw.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(120259543066)
            
            //--TRIMMABLE-BOUNDARY-START(115964575770)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964575770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$srw.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(115964575770)
            
            //--TRIMMABLE-BOUNDARY-START(47245099034)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srw.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(47245099034)
            
            //--TRIMMABLE-BOUNDARY-START(42950131738)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srw.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(42950131738)
            
            //--TRIMMABLE-BOUNDARY-START(38655164442)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srw.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(38655164442)
            
            //--TRIMMABLE-BOUNDARY-START(51540066330)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$srw.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(51540066330)
            
            //--TRIMMABLE-BOUNDARY-START(30065229850)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srw.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(30065229850)
            
            //--TRIMMABLE-BOUNDARY-START(25770262554)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srw.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(25770262554)
            
            //--TRIMMABLE-BOUNDARY-START(21475295258)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srw.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(21475295258)
            
            //--TRIMMABLE-BOUNDARY-START(34360197146)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$srw.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(34360197146)
            
            //--TRIMMABLE-BOUNDARY-START(4295426074)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(154619281434)
                    this.s_usingResourceKeys = $.$srw.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(154619281434)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295426074)
            
            static $h = 458778;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 458778
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458778)
        
        

        //--TRIMMABLE-BOUNDARY-START(262170)
        $asm.$cls(`$srw.SR.ResourceWriter`, ($self) => class ResourceWriter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(150324117530)
            /*Func<Type, string>?*/ TypeNameConverter = null;
            //--TRIMMABLE-BOUNDARY-END(150324117530)
            
            //--TRIMMABLE-BOUNDARY-START(42949935130)
            /*void */ AddResource$2(/*string*/ name, /*Stream?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949935130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$srw.S.SR.InvalidOperation_ResourceWriterSaved);
                }
                this.AddResourceInternal(name, value, false);
            }
            //--TRIMMABLE-BOUNDARY-END(42949935130)
            
            //--TRIMMABLE-BOUNDARY-START(55834837018)
            /*void */ AddResourceData(/*string*/ name, /*string*/ typeName, /*byte[]*/ serializedData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(name, "name");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(typeName, "typeName");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serializedData, "serializedData");
                this.AddResourceData$1(name, typeName, $.$cast(serializedData, $.$$.S.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(55834837018)
            
            //--TRIMMABLE-BOUNDARY-START(124554313754)
            static /*string */ get ResourceReaderTypeName()
            {
                return "System.Resources.ResourceReader, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"/*ResourceReaderFullyQualifiedName*/;
            }
            //--TRIMMABLE-BOUNDARY-END(124554313754)
            
            //--TRIMMABLE-BOUNDARY-START(128849281050)
            static /*string */ get ResourceSetTypeName()
            {
                return "System.Resources.RuntimeResourceSet"/*ResSetTypeName*/;
            }
            //--TRIMMABLE-BOUNDARY-END(128849281050)
            
            //--TRIMMABLE-BOUNDARY-START(154619084826)
            static /*void */ WriteData(/*BinaryWriter*/ writer, /*object*/ dataContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619084826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]?*/ let data = $.$as(dataContext, $.$typeArray($.$$.S.Byte));
                $.$$.SD.Debug.Assert$4(data !== null, "data != null");
                writer.Write$3(data);
            }
            //--TRIMMABLE-BOUNDARY-END(154619084826)
            
            //--TRIMMABLE-BOUNDARY-START(68719738906)
            /*int*/ static AverageNameSize = 40;
            //--TRIMMABLE-BOUNDARY-END(68719738906)
            
            //--TRIMMABLE-BOUNDARY-START(120259346458)
            /*string*/ static ResourceReaderFullyQualifiedName = null;
            //--TRIMMABLE-BOUNDARY-END(120259346458)
            
            //--TRIMMABLE-BOUNDARY-START(133144248346)
            /*string*/ static ResSetTypeName = null;
            //--TRIMMABLE-BOUNDARY-END(133144248346)
            
            //--TRIMMABLE-BOUNDARY-START(137439215642)
            /*int*/ static ResSetVersion = 2;
            //--TRIMMABLE-BOUNDARY-END(137439215642)
            
            //--TRIMMABLE-BOUNDARY-START(17180131354)
            /*SortedDictionary<string, object?>?*/ _resourceList = null;
            //--TRIMMABLE-BOUNDARY-END(17180131354)
            
            //--TRIMMABLE-BOUNDARY-START(8590196762)
            /*Stream*/ _output = null;
            //--TRIMMABLE-BOUNDARY-END(8590196762)
            
            //--TRIMMABLE-BOUNDARY-START(4295229466)
            /*Dictionary<string, object?>*/ _caseInsensitiveDups = null;
            //--TRIMMABLE-BOUNDARY-END(4295229466)
            
            //--TRIMMABLE-BOUNDARY-START(12885164058)
            /*Dictionary<string, PrecannedResource>?*/ _preserializedData = null;
            //--TRIMMABLE-BOUNDARY-END(12885164058)
            
            //--TRIMMABLE-BOUNDARY-START(30065033242)
            $ctor$2(/*string*/ fileName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065033242);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(fileName, "fileName");
                    this._output = new $.$$.SI.FileStream().$ctor$14(fileName, 2/*FileMode.Create*/, 2/*FileAccess.Write*/, 0/*FileShare.None*/);
                    this._resourceList = new ($.$sc.SCG.SortedDictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$2($.$srw.SR.FastResourceComparer.Default);
                    this._caseInsensitiveDups = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$6($.$$.S.StringComparer.OrdinalIgnoreCase);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065033242)
            
            //--TRIMMABLE-BOUNDARY-START(25770065946)
            $ctor$1(/*Stream*/ stream)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770065946);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                    if (!stream.CanWrite)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$14($.$srw.S.SR.Argument_StreamNotWritable);
                    }
                    this._output = stream;
                    this._resourceList = new ($.$sc.SCG.SortedDictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$2($.$srw.SR.FastResourceComparer.Default);
                    this._caseInsensitiveDups = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$6($.$$.S.StringComparer.OrdinalIgnoreCase);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770065946)
            
            //--TRIMMABLE-BOUNDARY-START(51539869722)
            /*void */ AddResource$4(/*string*/ name, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539869722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$srw.S.SR.InvalidOperation_ResourceWriterSaved);
                }
                this._caseInsensitiveDups.Add(name, null);
                this._resourceList.Add(name, value);
            }
            //--TRIMMABLE-BOUNDARY-END(51539869722)
            
            //--TRIMMABLE-BOUNDARY-START(47244902426)
            /*void */ AddResource$3(/*string*/ name, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244902426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$srw.S.SR.InvalidOperation_ResourceWriterSaved);
                }
                if (value !== null && $.$is(value, $.$$.SI.Stream))
                {
                    this.AddResourceInternal(name, $.$cast(value, $.$$.SI.Stream), false);
                }
                else 
                {
                    this._caseInsensitiveDups.Add(name, null);
                    this._resourceList.Add(name, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244902426)
            
            //--TRIMMABLE-BOUNDARY-START(38654967834)
            /*void */ AddResource$1(/*string*/ name, /*Stream?*/ value, /*bool*/ closeAfterWrite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$srw.S.SR.InvalidOperation_ResourceWriterSaved);
                }
                this.AddResourceInternal(name, value, closeAfterWrite);
            }
            //--TRIMMABLE-BOUNDARY-END(38654967834)
            
            //--TRIMMABLE-BOUNDARY-START(64424771610)
            /*void */ AddResourceInternal(/*string*/ name, /*Stream?*/ value, /*bool*/ closeAfterWrite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424771610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._resourceList !== null, "_resourceList != null");
                if (value === null)
                {
                    this._caseInsensitiveDups.Add(name, null);
                    this._resourceList.Add(name, value);
                }
                else 
                {
                    if (!value.CanSeek)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$14($.$srw.S.SR.NotSupported_UnseekableStream);
                    }
                    this._caseInsensitiveDups.Add(name, null);
                    this._resourceList.Add(name, new $.$srw.SR.ResourceWriter.StreamWrapper().$ctor$1(value, closeAfterWrite));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424771610)
            
            //--TRIMMABLE-BOUNDARY-START(34360000538)
            /*void */ AddResource(/*string*/ name, /*byte[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$srw.S.SR.InvalidOperation_ResourceWriterSaved);
                }
                this._caseInsensitiveDups.Add(name, null);
                this._resourceList.Add(name, value);
            }
            //--TRIMMABLE-BOUNDARY-END(34360000538)
            
            //--TRIMMABLE-BOUNDARY-START(60129804314)
            /*void */ AddResourceData$1(/*string*/ name, /*string*/ typeName, /*object*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129804314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._resourceList === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$srw.S.SR.InvalidOperation_ResourceWriterSaved);
                }
                this._caseInsensitiveDups.Add(name, null);
                this._preserializedData ??= new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$srw.SR.ResourceWriter.PrecannedResource))().$ctor$6($.$srw.SR.FastResourceComparer.Default);
                this._preserializedData.Add(name, new $.$srw.SR.ResourceWriter.PrecannedResource().$ctor$1(typeName, data));
            }
            //--TRIMMABLE-BOUNDARY-END(60129804314)
            
            //--TRIMMABLE-BOUNDARY-START(327706)
            static $_PrecannedResource;
            static get PrecannedResource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srw.SR.ResourceWriter;
                return $cls.$_PrecannedResource ??= $asm.$ncls(`$srw.SR.ResourceWriter.PrecannedResource`, ($self) => class PrecannedResource extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12885229594)
                    /*string*/ TypeName = null;
                    //--TRIMMABLE-BOUNDARY-END(12885229594)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590262298)
                    /*object*/ Data = null;
                    //--TRIMMABLE-BOUNDARY-END(8590262298)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295295002)
                    $ctor$1(/*string*/ typeName, /*object*/ data)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295295002);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.TypeName = typeName;
                            this.Data = data;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295295002)
                    
                    static $h = 327706;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885229594),
    {
      "t": 1310721,
      "n": "TypeName",
      "d": 327706,
      "h": 12885229594,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885229594),
//--TRIMMABLE-BOUNDARY-START(8590262298),
    {
      "t": 131073,
      "n": "Data",
      "d": 327706,
      "h": 8590262298,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590262298)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295002),
    {
      "p": [
        {
          "n": "typeName",
          "p": 1310721
        },
        {
          "n": "data",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327706,
      "h": 4295295002,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295295002)
  ],
  "d": 262170,
  "h": 327706
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Resources.ResourceWriter+PrecannedResource`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Resources${separator}ResourceWriter${separator}PrecannedResource`; }
                }, $cls, ($v) => $cls.$_PrecannedResource = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327706)
            
            //--TRIMMABLE-BOUNDARY-START(393242)
            static $_StreamWrapper;
            static get StreamWrapper()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(393242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srw.SR.ResourceWriter;
                return $cls.$_StreamWrapper ??= $asm.$ncls(`$srw.SR.ResourceWriter.StreamWrapper`, ($self) => class StreamWrapper extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12885295130)
                    /*Stream*/ Stream = null;
                    //--TRIMMABLE-BOUNDARY-END(12885295130)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590327834)
                    /*bool*/ CloseAfterWrite = false;
                    //--TRIMMABLE-BOUNDARY-END(8590327834)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295360538)
                    $ctor$1(/*Stream*/ s, /*bool*/ closeAfterWrite)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295360538);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Stream = s;
                            this.CloseAfterWrite = closeAfterWrite;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295360538)
                    
                    static $h = 393242;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885295130),
    {
      "t": 95748097,
      "n": "Stream",
      "d": 393242,
      "h": 12885295130,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885295130),
//--TRIMMABLE-BOUNDARY-START(8590327834),
    {
      "t": 262145,
      "n": "CloseAfterWrite",
      "d": 393242,
      "h": 8590327834,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590327834)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360538),
    {
      "p": [
        {
          "n": "s",
          "p": 95748097
        },
        {
          "n": "closeAfterWrite",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393242,
      "h": 4295360538,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295360538)
  ],
  "d": 262170,
  "h": 393242
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Resources.ResourceWriter+StreamWrapper`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Resources${separator}ResourceWriter${separator}StreamWrapper`; }
                }, $cls, ($v) => $cls.$_StreamWrapper = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393242)
            
            //--TRIMMABLE-BOUNDARY-START(73014706202)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
            }
            //--TRIMMABLE-BOUNDARY-END(73014706202)
            
            //--TRIMMABLE-BOUNDARY-START(81604640794)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (disposing)
                {
                    if (this._resourceList !== null)
                    {
                        this.Generate();
                    }
                    this._output?.Dispose();
                }
                this._output = null;
                this._caseInsensitiveDups = null;
            }
            //--TRIMMABLE-BOUNDARY-END(81604640794)
            
            //--TRIMMABLE-BOUNDARY-START(77309673498)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309673498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
            }
            //--TRIMMABLE-BOUNDARY-END(77309673498)
            
            //--TRIMMABLE-BOUNDARY-START(90194575386)
            /*void */ Generate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194575386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._resourceList === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$srw.S.SR.InvalidOperation_ResourceWriterSaved);
                }
                /*BinaryWriter*/ let bw = new $.$$.SI.BinaryWriter().$ctor$3(this._output, $.$$.ST.Encoding.UTF8);
                /*List<string>*/ let typeNames = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                bw.Write$11($.$$.SR$1.ResourceManager.MagicNumber);
                bw.Write$11($.$$.SR$1.ResourceManager.HeaderVersionNumber);
                /*MemoryStream*/ let resMgrHeaderBlob = new $.$$.SI.MemoryStream().$ctor$9(240);
                /*BinaryWriter*/ let resMgrHeaderPart = new $.$$.SI.BinaryWriter().$ctor$4(resMgrHeaderBlob);
                resMgrHeaderPart.Write$17($.$srw.SR.ResourceWriter.ResourceReaderTypeName);
                resMgrHeaderPart.Write$17($.$srw.SR.ResourceWriter.ResourceSetTypeName);
                resMgrHeaderPart.Flush();
                bw.Write$11($.$cast(resMgrHeaderBlob.Length, $.$$.S.Int32));
                $.$$.SD.Debug.Assert$4(resMgrHeaderBlob.Length > 0n, "ResourceWriter: Expected non empty header");
                resMgrHeaderBlob.Seek(0n, 0/*SeekOrigin.Begin*/);
                resMgrHeaderBlob.CopyTo(bw.BaseStream, $.$cast(resMgrHeaderBlob.Length, $.$$.S.Int32));
                bw.Write$11(2/*ResSetVersion*/);
                /*int*/ let numResources = this._resourceList.Count;
                if (this._preserializedData !== null)
                {
                    numResources += this._preserializedData.Count;
                }
                bw.Write$11(numResources);
                /*int[]*/ let nameHashes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [numResources], null);
                /*int[]*/ let namePositions = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [numResources], null);
                /*int*/ let curNameNumber = 0;
                /*MemoryStream*/ let nameSection = new $.$$.SI.MemoryStream().$ctor$9(((numResources * 40/*AverageNameSize*/) | 0));
                /*BinaryWriter*/ let names = new $.$$.SI.BinaryWriter().$ctor$3(nameSection, $.$$.ST.Encoding.Unicode);
                /*Stream*/ let dataSection = new $.$$.SI.MemoryStream().$ctor$3();
                let $disposable1 = null;
                try
                {
                    $disposable1 = dataSection;
                    /*BinaryWriter*/ let data = new $.$$.SI.BinaryWriter().$ctor$3(dataSection, $.$$.ST.Encoding.UTF8);
                    if (this._preserializedData !== null)
                    {
                        let $en2 = this._preserializedData.GetEnumerator();
                        while ($en2.MoveNext())
                        {
                            let entry = $en2.Current;
                            {
                                this._resourceList.Add(entry.Key, entry.Value);
                            }
                        }
                    }
                    let $en3 = this._resourceList.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        let item = $en3.Current;
                        {
                            $.$$.System.Array.$WriteT1.call(nameHashes, $.$srw.SR.FastResourceComparer.HashFunction(item.Key), curNameNumber);
                            $.$$.System.Array.$WriteT1.call(namePositions, $.$cast(names.Seek(0, 1/*SeekOrigin.Current*/), $.$$.S.Int32), curNameNumber++);
                            names.Write$17(item.Key);
                            names.Write$11($.$cast(data.Seek(0, 1/*SeekOrigin.Current*/), $.$$.S.Int32));
                            /*object?*/ let value = item.Value;
                            /*ResourceTypeCode*/ let typeCode = $.$srw.SR.ResourceWriter.FindTypeCode(value, typeNames);
                            data.Write7BitEncodedInt(typeCode);
                            /*var*/ let userProvidedResource = $.$as(value, $.$srw.SR.ResourceWriter.PrecannedResource);
                            if (userProvidedResource !== null)
                            {
                                $.$srw.SR.ResourceWriter.WriteData(data, userProvidedResource.Data);
                            }
                            else 
                            {
                                $.$srw.SR.ResourceWriter.WriteValue(typeCode, value, data);
                            }
                        }
                    }
                    bw.Write$11(typeNames.Count);
                    let $en4 = typeNames.GetEnumerator();
                    while ($en4.MoveNext())
                    {
                        let typeName = $en4.Current;
                        {
                            bw.Write$17(typeName);
                        }
                    }
                    $.$$.S.Array.Sort$16($.$$.S.Int32, $.$$.S.Int32, nameHashes, namePositions);
                    bw.Flush();
                    /*int*/ let alignBytes = ($.$cast(bw.BaseStream.Position, $.$$.S.Int32)) & 7;
                    if (alignBytes > 0)
                    {
                        for(/*int*/ let i = 0; i < ((8 - alignBytes) | 0); i++)
                        {
                            bw.Write$4($.$$.S.String.get_Chars.call("PAD", i % 3));
                        }
                    }
                    $.$$.SD.Debug.Assert$4((bw.BaseStream.Position & 7n) === 0n, "ResourceWriter: Name hashes array won't be 8 byte aligned!  Ack!");
                    let $i5 = 0;
                    let $arr5 = nameHashes;
                    while ($i5 < $arr5.length)
                    {
                        let hash = $arr5[$i5++];
                        bw.Write$11(hash);
                    }
                    $.$$.SD.Debug.Assert$4((bw.BaseStream.Position & 3n) === 0n, "ResourceWriter: Name positions array won't be 4 byte aligned!  Ack!");
                    let $i6 = 0;
                    let $arr6 = namePositions;
                    while ($i6 < $arr6.length)
                    {
                        let pos = $arr6[$i6++];
                        bw.Write$11(pos);
                    }
                    bw.Flush();
                    names.Flush();
                    data.Flush();
                    /*int*/ let startOfDataSection = $.$cast((BigInt.asIntN(64, bw.Seek(0, 1/*SeekOrigin.Current*/) + nameSection.Length)), $.$$.S.Int32);
                    startOfDataSection += 4;
                    bw.Write$11(startOfDataSection);
                    if (nameSection.Length > 0n)
                    {
                        nameSection.Seek(0n, 0/*SeekOrigin.Begin*/);
                        nameSection.CopyTo(bw.BaseStream, $.$cast(nameSection.Length, $.$$.S.Int32));
                    }
                    names.Dispose();
                    $.$$.SD.Debug.Assert$4(BigInt(startOfDataSection) === bw.Seek(0, 1/*SeekOrigin.Current*/), "ResourceWriter::Generate - start of data section is wrong!");
                    dataSection.Position = 0n;
                    dataSection.CopyTo$1(bw.BaseStream);
                    data.Dispose();
                }
                finally
                {
                    $disposable1?.S$IDisposable$Dispose();
                }
                bw.Flush();
                this._resourceList = null;
            }
            //--TRIMMABLE-BOUNDARY-END(90194575386)
            
            //--TRIMMABLE-BOUNDARY-START(85899608090)
            static /*ResourceTypeCode */ FindTypeCode(/*object?*/ value, /*List<string>*/ types)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899608090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return 0/*ResourceTypeCode.Null*/;
                }
                /*Type*/ let type = $.$$.S.Object.GetType.call(value);
                if (type === $.$$.S.String.$type)
                {
                    return 1/*ResourceTypeCode.String*/;
                }
                else if (type === $.$$.S.Int32.$type)
                {
                    return 8/*ResourceTypeCode.Int32*/;
                }
                else if (type === $.$$.S.Boolean.$type)
                {
                    return 2/*ResourceTypeCode.Boolean*/;
                }
                else if (type === $.$$.S.Char.$type)
                {
                    return 3/*ResourceTypeCode.Char*/;
                }
                else if (type === $.$$.S.Byte.$type)
                {
                    return 4/*ResourceTypeCode.Byte*/;
                }
                else if (type === $.$$.S.SByte.$type)
                {
                    return 5/*ResourceTypeCode.SByte*/;
                }
                else if (type === $.$$.S.Int16.$type)
                {
                    return 6/*ResourceTypeCode.Int16*/;
                }
                else if (type === $.$$.S.Int64.$type)
                {
                    return 10/*ResourceTypeCode.Int64*/;
                }
                else if (type === $.$$.S.UInt16.$type)
                {
                    return 7/*ResourceTypeCode.UInt16*/;
                }
                else if (type === $.$$.S.UInt32.$type)
                {
                    return 9/*ResourceTypeCode.UInt32*/;
                }
                else if (type === $.$$.S.UInt64.$type)
                {
                    return 11/*ResourceTypeCode.UInt64*/;
                }
                else if (type === $.$$.S.Single.$type)
                {
                    return 12/*ResourceTypeCode.Single*/;
                }
                else if (type === $.$$.S.Double.$type)
                {
                    return 13/*ResourceTypeCode.Double*/;
                }
                else if (type === $.$$.S.Decimal.$type)
                {
                    return 14/*ResourceTypeCode.Decimal*/;
                }
                else if (type === $.$$.S.DateTime.$type)
                {
                    return 15/*ResourceTypeCode.DateTime*/;
                }
                else if (type === $.$$.S.TimeSpan.$type)
                {
                    return 16/*ResourceTypeCode.TimeSpan*/;
                }
                else if (type === $.$typeArray($.$$.S.Byte).$type)
                {
                    return 32/*ResourceTypeCode.ByteArray*/;
                }
                else if (type === $.$srw.SR.ResourceWriter.StreamWrapper.$type)
                {
                    return 33/*ResourceTypeCode.Stream*/;
                }
                /*string*/ let typeName;
                if (type === $.$srw.SR.ResourceWriter.PrecannedResource.$type)
                {
                    typeName = ($.$cast(value, $.$srw.SR.ResourceWriter.PrecannedResource)).TypeName;
                    if ($.$$.S.String.StartsWith$2.call(typeName, "ResourceTypeCode.", 4/*StringComparison.Ordinal*/))
                    {
                        typeName = typeName.slice(17);
                        /*ResourceTypeCode*/ let typeCode = $.$$.S.Enum.Parse$7($.$srw.SR.ResourceTypeCode, typeName);
                        return typeCode;
                    }
                }
                else 
                {
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$16($.$srw.S.SR.NotSupported_BinarySerializedResources);
                }
                /*int*/ let typeIndex = types.IndexOf$2(typeName);
                if (typeIndex === -1)
                {
                    typeIndex = types.Count;
                    types.Add(typeName);
                }
                return (typeIndex + 64/*ResourceTypeCode.StartOfUserTypes*/);
            }
            //--TRIMMABLE-BOUNDARY-END(85899608090)
            
            //--TRIMMABLE-BOUNDARY-START(158914052122)
            static /*void */ WriteValue(/*ResourceTypeCode*/ typeCode, /*object?*/ value, /*BinaryWriter*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914052122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(writer !== null, "writer != null");
                var data;
                switch(typeCode)
                {
                    case 0/*ResourceTypeCode.Null*/:
                    break;
                    case 1/*ResourceTypeCode.String*/:
                    writer.Write$17($.$cast(value, $.$$.S.String));
                    break;
                    case 2/*ResourceTypeCode.Boolean*/:
                    writer.Write($.$cast(value, $.$$.S.Boolean));
                    break;
                    case 3/*ResourceTypeCode.Char*/:
                    writer.Write$18($.$cast(value, $.$$.S.Char));
                    break;
                    case 4/*ResourceTypeCode.Byte*/:
                    writer.Write$1($.$cast(value, $.$$.S.Byte));
                    break;
                    case 5/*ResourceTypeCode.SByte*/:
                    writer.Write$15($.$cast(value, $.$$.S.SByte));
                    break;
                    case 6/*ResourceTypeCode.Int16*/:
                    writer.Write$10($.$cast(value, $.$$.S.Int16));
                    break;
                    case 7/*ResourceTypeCode.UInt16*/:
                    writer.Write$18($.$cast(value, $.$$.S.UInt16));
                    break;
                    case 8/*ResourceTypeCode.Int32*/:
                    writer.Write$11($.$cast(value, $.$$.S.Int32));
                    break;
                    case 9/*ResourceTypeCode.UInt32*/:
                    writer.Write$19($.$cast(value, $.$$.S.UInt32));
                    break;
                    case 10/*ResourceTypeCode.Int64*/:
                    writer.Write$12($.$cast(value, $.$$.S.Int64));
                    break;
                    case 11/*ResourceTypeCode.UInt64*/:
                    writer.Write$20($.$cast(value, $.$$.S.UInt64));
                    break;
                    case 12/*ResourceTypeCode.Single*/:
                    writer.Write$16($.$cast(value, $.$$.S.Single));
                    break;
                    case 13/*ResourceTypeCode.Double*/:
                    writer.Write$8($.$cast(value, $.$$.S.Double));
                    break;
                    case 14/*ResourceTypeCode.Decimal*/:
                    writer.Write$7($.$cast(value, $.$$.S.Decimal));
                    break;
                    case 15/*ResourceTypeCode.DateTime*/:
                    data = ($.$cast(value, $.$$.S.DateTime)).ToBinary();
                    writer.Write$12(data);
                    break;
                    case 16/*ResourceTypeCode.TimeSpan*/:
                    writer.Write$12(($.$cast(value, $.$$.S.TimeSpan)).Ticks);
                    break;
                    case 32/*ResourceTypeCode.ByteArray*/:
                    {
                        /*byte[]*/ let bytes = $.$cast(value, $.$typeArray($.$$.S.Byte));
                        writer.Write$11(bytes.length);
                        writer.Write$2(bytes, 0, bytes.length);
                        break;
                    }
                    case 33/*ResourceTypeCode.Stream*/:
                    {
                        /*StreamWrapper*/ let sw = $.$cast(value, $.$srw.SR.ResourceWriter.StreamWrapper);
                        if ($.$$.S.Object.GetType.call(sw.Stream) === $.$$.SI.MemoryStream.$type)
                        {
                            /*MemoryStream*/ let ms = $.$cast(sw.Stream, $.$$.SI.MemoryStream);
                            if (ms.Length > BigInt(2147483647/*int.MaxValue*/))
                            {
                                throw new $.$$.S.ArgumentException().$ctor$14($.$srw.S.SR.ArgumentOutOfRange_StreamLength);
                            }
                            /*byte[]*/ let arr = ms.ToArray();
                            writer.Write$11(arr.length);
                            writer.Write$2(arr, 0, arr.length);
                        }
                        else 
                        {
                            /*Stream*/ let s = sw.Stream;
                            if (s.Length > BigInt(2147483647/*int.MaxValue*/))
                            {
                                throw new $.$$.S.ArgumentException().$ctor$14($.$srw.S.SR.ArgumentOutOfRange_StreamLength);
                            }
                            s.Position = 0n;
                            writer.Write$11($.$cast(s.Length, $.$$.S.Int32));
                            /*byte[]*/ let buffer = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [4096], null);
                            /*int*/ let read;
                            while((read = s.Read(buffer, 0, buffer.length)) !== 0)
                            {
                                writer.Write$2(buffer, 0, read);
                            }
                            if (sw.CloseAfterWrite)
                            {
                                s.Close();
                            }
                        }
                        break;
                    }
                    default:
                    $.$$.SD.Debug.Assert$1(typeCode >= 64/*ResourceTypeCode.StartOfUserTypes*/, `ResourceReader: Unsupported ResourceTypeCode in .resources file!  ${$.$strNN($.$$.S.Enum.ToStringT($.$srw.SR.ResourceTypeCode, $.$$.S.UInt32, typeCode))}`);
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$16($.$srw.S.SR.NotSupported_BinarySerializedResources);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914052122)
            
            //--TRIMMABLE-BOUNDARY-START(12885032986)
            //Generated interface implemetation for System.Resources.IResourceWriter.AddResource(string, string?)
            SR$IResourceWriter$AddResource$2()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885032986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddResource$4(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885032986)
            
            //--TRIMMABLE-BOUNDARY-START(8590065690)
            //Generated interface implemetation for System.Resources.IResourceWriter.AddResource(string, object?)
            SR$IResourceWriter$AddResource$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddResource$3(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590065690)
            
            //--TRIMMABLE-BOUNDARY-START(4295098394)
            //Generated interface implemetation for System.Resources.IResourceWriter.AddResource(string, byte[]?)
            SR$IResourceWriter$AddResource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddResource(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098394)
            
            //--TRIMMABLE-BOUNDARY-START(17180000282)
            //Generated interface implemetation for System.Resources.IResourceWriter.Close()
            SR$IResourceWriter$Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Close(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180000282)
            
            //--TRIMMABLE-BOUNDARY-START(21474967578)
            //Generated interface implemetation for System.Resources.IResourceWriter.Generate()
            SR$IResourceWriter$Generate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Generate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21474967578)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(120259346458)
                    this.ResourceReaderFullyQualifiedName = "System.Resources.ResourceReader, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089";
                    //--TRIMMABLE-BOUNDARY-END(120259346458)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144248346)
                    this.ResSetTypeName = "System.Resources.RuntimeResourceSet";
                    //--TRIMMABLE-BOUNDARY-END(133144248346)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 262170;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(150324117530),
    {
      "p": $.$$.S.Func$$$($.$$.S.Type, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964379162,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029150234,
        "f": 83886081
      },
      "n": "TypeNameConverter",
      "d": 262170,
      "h": 150324117530,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150324117530),
//--TRIMMABLE-BOUNDARY-START(124554313754),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784509978,
        "f": 50331682
      },
      "n": "ResourceReaderTypeName",
      "d": 262170,
      "h": 124554313754,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(124554313754),
//--TRIMMABLE-BOUNDARY-START(128849281050),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374444570,
        "f": 50331682
      },
      "n": "ResourceSetTypeName",
      "d": 262170,
      "h": 128849281050,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(128849281050)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42949935130),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 95748097
        }
      ],
      "n": "AddResource",
      "o": "@$2",
      "d": 262170,
      "h": 42949935130,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949935130),
//--TRIMMABLE-BOUNDARY-START(55834837018),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "typeName",
          "p": 1310721
        },
        {
          "n": "serializedData",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "AddResourceData",
      "d": 262170,
      "h": 55834837018,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834837018),
//--TRIMMABLE-BOUNDARY-START(154619084826),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 92078081
        },
        {
          "n": "dataContext",
          "p": 131073
        }
      ],
      "n": "WriteData",
      "d": 262170,
      "h": 154619084826,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(154619084826),
//--TRIMMABLE-BOUNDARY-START(51539869722),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddResource",
      "o": "@$4",
      "d": 262170,
      "h": 51539869722,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539869722),
//--TRIMMABLE-BOUNDARY-START(47244902426),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "AddResource",
      "o": "@$3",
      "d": 262170,
      "h": 47244902426,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244902426),
//--TRIMMABLE-BOUNDARY-START(38654967834),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 95748097
        },
        {
          "n": "closeAfterWrite",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "AddResource",
      "o": "@$1",
      "d": 262170,
      "h": 38654967834,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654967834),
//--TRIMMABLE-BOUNDARY-START(64424771610),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 95748097
        },
        {
          "n": "closeAfterWrite",
          "p": 262145
        }
      ],
      "n": "AddResourceInternal",
      "d": 262170,
      "h": 64424771610,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64424771610),
//--TRIMMABLE-BOUNDARY-START(34360000538),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "AddResource",
      "d": 262170,
      "h": 34360000538,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360000538),
//--TRIMMABLE-BOUNDARY-START(60129804314),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "typeName",
          "p": 1310721
        },
        {
          "n": "data",
          "p": 131073
        }
      ],
      "n": "AddResourceData",
      "o": "@$1",
      "d": 262170,
      "h": 60129804314,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60129804314),
//--TRIMMABLE-BOUNDARY-START(73014706202),
    {
      "r": 65537,
      "n": "Close",
      "d": 262170,
      "h": 73014706202,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014706202),
//--TRIMMABLE-BOUNDARY-START(81604640794),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 262170,
      "h": 81604640794,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81604640794),
//--TRIMMABLE-BOUNDARY-START(77309673498),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 262170,
      "h": 77309673498,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309673498),
//--TRIMMABLE-BOUNDARY-START(90194575386),
    {
      "r": 65537,
      "n": "Generate",
      "d": 262170,
      "h": 90194575386,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194575386),
//--TRIMMABLE-BOUNDARY-START(85899608090),
    {
      "r": 196634,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "types",
          "p": $.$$.SCG.List$$($.$$.S.String).$h
        }
      ],
      "n": "FindTypeCode",
      "d": 262170,
      "h": 85899608090,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85899608090),
//--TRIMMABLE-BOUNDARY-START(158914052122),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeCode",
          "p": 196634
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "writer",
          "p": 92078081
        }
      ],
      "n": "WriteValue",
      "d": 262170,
      "h": 158914052122,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(158914052122)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(68719738906),
    {
      "t": 655361,
      "n": "AverageNameSize",
      "d": 262170,
      "h": 68719738906,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68719738906),
//--TRIMMABLE-BOUNDARY-START(120259346458),
    {
      "t": 1310721,
      "n": "ResourceReaderFullyQualifiedName",
      "d": 262170,
      "h": 120259346458,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259346458),
//--TRIMMABLE-BOUNDARY-START(133144248346),
    {
      "t": 1310721,
      "n": "ResSetTypeName",
      "d": 262170,
      "h": 133144248346,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(133144248346),
//--TRIMMABLE-BOUNDARY-START(137439215642),
    {
      "t": 655361,
      "n": "ResSetVersion",
      "d": 262170,
      "h": 137439215642,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(137439215642),
//--TRIMMABLE-BOUNDARY-START(17180131354),
    {
      "t": $.$sc.SCG.SortedDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "n": "_resourceList",
      "d": 262170,
      "h": 17180131354,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180131354),
//--TRIMMABLE-BOUNDARY-START(8590196762),
    {
      "t": 95748097,
      "n": "_output",
      "d": 262170,
      "h": 8590196762,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196762),
//--TRIMMABLE-BOUNDARY-START(4295229466),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "n": "_caseInsensitiveDups",
      "d": 262170,
      "h": 4295229466,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229466),
//--TRIMMABLE-BOUNDARY-START(12885164058),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$srw.SR.ResourceWriter.PrecannedResource).$h,
      "n": "_preserializedData",
      "d": 262170,
      "h": 12885164058,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885164058)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065033242),
    {
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262170,
      "h": 30065033242,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065033242),
//--TRIMMABLE-BOUNDARY-START(25770065946),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262170,
      "h": 25770065946,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770065946)
  ],
  "h": 262170
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srw.SR.IResourceWriter, $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$srw.SR.ResourceWriter.PrecannedResource, $.$srw.SR.ResourceWriter.StreamWrapper ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Resources.ResourceWriter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Resources${separator}ResourceWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262170)
        
        

        //--TRIMMABLE-BOUNDARY-START(196634)
        $asm.$str(`$srw.SR.ResourceTypeCode`, ($self) => class ResourceTypeCode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Null = 0;
            static String = 1;
            static Boolean = 2;
            static Char = 3;
            static Byte = 4;
            static SByte = 5;
            static Int16 = 6;
            static UInt16 = 7;
            static Int32 = 8;
            static UInt32 = 9;
            static Int64 = 10;
            static UInt64 = 11;
            static Single = 12;
            static Double = 13;
            static Decimal = 14;
            static DateTime = 15;
            static TimeSpan = 16;
            static LastPrimitive = 16;
            static ByteArray = 32;
            static Stream = 33;
            static StartOfUserTypes = 64;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Null": 0n,
                    "String": 1n,
                    "Boolean": 2n,
                    "Char": 3n,
                    "Byte": 4n,
                    "SByte": 5n,
                    "Int16": 6n,
                    "UInt16": 7n,
                    "Int32": 8n,
                    "UInt32": 9n,
                    "Int64": 10n,
                    "UInt64": 11n,
                    "Single": 12n,
                    "Double": 13n,
                    "Decimal": 14n,
                    "DateTime": 15n,
                    "TimeSpan": 16n,
                    "LastPrimitive": 16n,
                    "ByteArray": 32n,
                    "Stream": 33n,
                    "StartOfUserTypes": 64n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295163930)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295163930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163930)
            
            //--TRIMMABLE-BOUNDARY-START(4295163930)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295163930)
            
            static $h = 196634;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(55834771482),
    {
      "t": 196634,
      "n": "Null",
      "d": 196634,
      "h": 55834771482,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834771482),
//--TRIMMABLE-BOUNDARY-START(77309607962),
    {
      "t": 196634,
      "n": "String",
      "d": 196634,
      "h": 77309607962,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77309607962),
//--TRIMMABLE-BOUNDARY-START(8590131226),
    {
      "t": 196634,
      "n": "Boolean",
      "d": 196634,
      "h": 8590131226,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590131226),
//--TRIMMABLE-BOUNDARY-START(21475033114),
    {
      "t": 196634,
      "n": "Char",
      "d": 196634,
      "h": 21475033114,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475033114),
//--TRIMMABLE-BOUNDARY-START(12885098522),
    {
      "t": 196634,
      "n": "Byte",
      "d": 196634,
      "h": 12885098522,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885098522),
//--TRIMMABLE-BOUNDARY-START(60129738778),
    {
      "t": 196634,
      "n": "SByte",
      "d": 196634,
      "h": 60129738778,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60129738778),
//--TRIMMABLE-BOUNDARY-START(38654902298),
    {
      "t": 196634,
      "n": "Int16",
      "d": 196634,
      "h": 38654902298,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654902298),
//--TRIMMABLE-BOUNDARY-START(85899542554),
    {
      "t": 196634,
      "n": "UInt16",
      "d": 196634,
      "h": 85899542554,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899542554),
//--TRIMMABLE-BOUNDARY-START(42949869594),
    {
      "t": 196634,
      "n": "Int32",
      "d": 196634,
      "h": 42949869594,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949869594),
//--TRIMMABLE-BOUNDARY-START(90194509850),
    {
      "t": 196634,
      "n": "UInt32",
      "d": 196634,
      "h": 90194509850,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90194509850),
//--TRIMMABLE-BOUNDARY-START(47244836890),
    {
      "t": 196634,
      "n": "Int64",
      "d": 196634,
      "h": 47244836890,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47244836890),
//--TRIMMABLE-BOUNDARY-START(94489477146),
    {
      "t": 196634,
      "n": "UInt64",
      "d": 196634,
      "h": 94489477146,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489477146),
//--TRIMMABLE-BOUNDARY-START(64424706074),
    {
      "t": 196634,
      "n": "Single",
      "d": 196634,
      "h": 64424706074,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424706074),
//--TRIMMABLE-BOUNDARY-START(34359935002),
    {
      "t": 196634,
      "n": "Double",
      "d": 196634,
      "h": 34359935002,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34359935002),
//--TRIMMABLE-BOUNDARY-START(30064967706),
    {
      "t": 196634,
      "n": "Decimal",
      "d": 196634,
      "h": 30064967706,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064967706),
//--TRIMMABLE-BOUNDARY-START(25770000410),
    {
      "t": 196634,
      "n": "DateTime",
      "d": 196634,
      "h": 25770000410,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770000410),
//--TRIMMABLE-BOUNDARY-START(81604575258),
    {
      "t": 196634,
      "n": "TimeSpan",
      "d": 196634,
      "h": 81604575258,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604575258),
//--TRIMMABLE-BOUNDARY-START(51539804186),
    {
      "t": 196634,
      "n": "LastPrimitive",
      "d": 196634,
      "h": 51539804186,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539804186),
//--TRIMMABLE-BOUNDARY-START(17180065818),
    {
      "t": 196634,
      "n": "ByteArray",
      "d": 196634,
      "h": 17180065818,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180065818),
//--TRIMMABLE-BOUNDARY-START(73014640666),
    {
      "t": 196634,
      "n": "Stream",
      "d": 196634,
      "h": 73014640666,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73014640666),
//--TRIMMABLE-BOUNDARY-START(68719673370),
    {
      "t": 196634,
      "n": "StartOfUserTypes",
      "d": 196634,
      "h": 68719673370,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68719673370)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163930),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196634,
      "h": 4295163930,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163930)
  ],
  "h": 196634
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Resources.ResourceTypeCode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Resources${separator}ResourceTypeCode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196634)
        
        

        //--TRIMMABLE-BOUNDARY-START(65562)
        $asm.$cls(`$srw.SR.FastResourceComparer`, ($self) => class FastResourceComparer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17179934746)
            /*FastResourceComparer*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(17179934746)
            
            //--TRIMMABLE-BOUNDARY-START(25769869338)
            /*int */ GetHashCode$1(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srw.SR.FastResourceComparer.HashFunction(key);
            }
            //--TRIMMABLE-BOUNDARY-END(25769869338)
            
            //--TRIMMABLE-BOUNDARY-START(30064836634)
            static /*int */ HashFunction(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let hash = 5381;
                for(/*int*/ let i = 0; i < key.length; i++)
                {
                    hash = ((((hash << 5) >>> 0) + hash) >>> 0) ^ $.$$.S.String.get_Chars.call(key, i);
                }
                return (hash | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(30064836634)
            
            //--TRIMMABLE-BOUNDARY-START(12884967450)
            /*int */ Compare(/*string?*/ a, /*string?*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.CompareOrdinal$2(a, b);
            }
            //--TRIMMABLE-BOUNDARY-END(12884967450)
            
            //--TRIMMABLE-BOUNDARY-START(21474902042)
            /*bool */ Equals$2(/*string?*/ a, /*string?*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Equals$4(a, b);
            }
            //--TRIMMABLE-BOUNDARY-END(21474902042)
            
            //--TRIMMABLE-BOUNDARY-START(4355129345)
            //Generated interface implemetation for System.Collections.Generic.IComparer<string>.Compare(string?, string?)
            SCG$IComparer$System$String$Compare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355129345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Compare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355129345)
            
            //--TRIMMABLE-BOUNDARY-START(4355457025)
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<string>.Equals(string?, string?)
            SCG$IEqualityComparer$System$String$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355457025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355457025)
            
            //--TRIMMABLE-BOUNDARY-START(8650424321)
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<string>.GetHashCode(string)
            SCG$IEqualityComparer$System$String$GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8650424321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetHashCode$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8650424321)
            
            //--TRIMMABLE-BOUNDARY-START(8590000154)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000154)
            
            //--TRIMMABLE-BOUNDARY-START(8590000154)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590000154)
            
            //--TRIMMABLE-BOUNDARY-START(4295032858)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17179934746)
                    this.Default = new $.$srw.SR.FastResourceComparer().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(17179934746)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295032858)
            
            static $h = 65562;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769869338),
    {
      "r": 655361,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetHashCode",
      "o": "@$1",
      "d": 65562,
      "h": 25769869338,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769869338),
//--TRIMMABLE-BOUNDARY-START(30064836634),
    {
      "r": 655361,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "HashFunction",
      "d": 65562,
      "h": 30064836634,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30064836634),
//--TRIMMABLE-BOUNDARY-START(12884967450),
    {
      "r": 655361,
      "p": [
        {
          "n": "a",
          "p": 1310721
        },
        {
          "n": "b",
          "p": 1310721
        }
      ],
      "n": "Compare",
      "d": 65562,
      "h": 12884967450,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12884967450),
//--TRIMMABLE-BOUNDARY-START(21474902042),
    {
      "r": 262145,
      "p": [
        {
          "n": "a",
          "p": 1310721
        },
        {
          "n": "b",
          "p": 1310721
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 65562,
      "h": 21474902042,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474902042)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17179934746),
    {
      "t": 65562,
      "n": "Default",
      "d": 65562,
      "h": 17179934746,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17179934746)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590000154),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65562,
      "h": 8590000154,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000154)
  ],
  "h": 65562
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IComparer$$($.$$.S.String), $.$$.SCG.IEqualityComparer$$($.$$.S.String) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Resources.FastResourceComparer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Resources${separator}FastResourceComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65562)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime"));
})();
//--TRIMMABLE-BOUNDARY-END(26)
