
(function ($global, $, $$, $sc, $sm, $spu, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Resources.Writer", 
    {"h":41525,"f":"System.Resources.Writer","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Resources.Writer","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Resources.Writer","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srw.System.Resources.IResourceWriter", ($self) => class IResourceWriter
        {
            static $h = 172597;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":1310721}],"n":"AddResource","o":"System$Resources$IResourceWriter$AddResource$2","d":172597,"h":4295139893,"f":16777473},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":131073}],"n":"AddResource","o":"System$Resources$IResourceWriter$AddResource$1","d":172597,"h":8590107189,"f":16777473},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":$.$typeArray($.$$.System.Byte).$h}],"n":"AddResource","o":"System$Resources$IResourceWriter$AddResource","d":172597,"h":12885074485,"f":16777473},{"r":65537,"n":"Close","o":"System$Resources$IResourceWriter$Close","d":172597,"h":17180041781,"f":16777473},{"r":65537,"n":"Generate","o":"System$Resources$IResourceWriter$Generate","d":172597,"h":21475009077,"f":16777473}],"i":[57540609],"h":172597}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Resources.IResourceWriter`; }
        });
        
        $asm.$cls("$srw.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$srw.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Resources.Writer", $.$srw.System.SR.$type.Assembly);
                    $.$srw.System.SR.s_resourceManager = temp;
                }
                return $.$srw.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srw.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srw.System.SR.resourceCulture = value;
            }
            static /*string */ get InvalidOperation_ResourceWriterSaved()
            {
                return "The resource writer has already been closed and cannot be edited.";
            }
            static /*string */ get Argument_StreamNotWritable()
            {
                return "Stream was not writable.";
            }
            static /*string */ get NotSupported_UnseekableStream()
            {
                return "Stream does not support seeking.";
            }
            static /*string */ get NotSupported_BinarySerializedResources()
            {
                return "This platform does not support binary serialized resources.";
            }
            static /*string */ get ArgumentOutOfRange_StreamLength()
            {
                return "Stream length must be non-negative and less than 2^31 - 1 - origin.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srw.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srw.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srw.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srw.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srw.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srw.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 500277;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":500277}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srw.System.Resources.ResourceWriter", ($self) => class ResourceWriter extends $.$$.System.Object
        {
            /*Func<Type, string>?*/ TypeNameConverter = null;
            /*void */ AddResource$2(/*string*/ name, /*Stream?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this.AddResourceInternal(name, value, false);
            }
            /*void */ AddResourceData(/*string*/ name, /*string*/ typeName, /*byte[]*/ serializedData)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(typeName, "typeName");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serializedData, "serializedData");
                this.AddResourceData$1(name, typeName, $.$cast(serializedData, $.$$.System.Object));
            }
            static /*string */ get ResourceReaderTypeName()
            {
                return "System.Resources.ResourceReader, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"/*ResourceReaderFullyQualifiedName*/;
            }
            static /*string */ get ResourceSetTypeName()
            {
                return "System.Resources.RuntimeResourceSet"/*ResSetTypeName*/;
            }
            static /*void */ WriteData(/*BinaryWriter*/ writer, /*object*/ dataContext)
            {
                /*byte[]?*/ let data = $.$as(dataContext, $.$typeArray($.$$.System.Byte));
                $.$$.System.Diagnostics.Debug.Assert$2(data !== null, "data != null");
                writer.Write$3(data);
            }
            /*int*/ static AverageNameSize = 40;
            /*string*/ static ResourceReaderFullyQualifiedName = null;
            /*string*/ static ResSetTypeName = null;
            /*int*/ static ResSetVersion = 2;
            /*SortedDictionary<string, object?>?*/ _resourceList = null;
            /*Stream*/ _output = null;
            /*Dictionary<string, object?>*/ _caseInsensitiveDups = null;
            /*Dictionary<string, PrecannedResource>?*/ _preserializedData = null;
            $ctor$2(/*string*/ fileName)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(fileName, "fileName");
                    this._output = new $.$$.System.IO.FileStream().$ctor$14(fileName, 2/*FileMode.Create*/, 2/*FileAccess.Write*/, 0/*FileShare.None*/);
                    this._resourceList = new ($.$sc.System.Collections.Generic.SortedDictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$2($.$srw.System.Resources.FastResourceComparer.Default);
                    this._caseInsensitiveDups = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                }
                return this;
            }
            $ctor$1(/*Stream*/ stream)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                    if (!stream.CanWrite)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$srw.System.SR.Argument_StreamNotWritable);
                    }
                    this._output = stream;
                    this._resourceList = new ($.$sc.System.Collections.Generic.SortedDictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$2($.$srw.System.Resources.FastResourceComparer.Default);
                    this._caseInsensitiveDups = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                }
                return this;
            }
            /*void */ AddResource$4(/*string*/ name, /*string?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this._caseInsensitiveDups.Add(name, null);
                this._resourceList.Add(name, value);
            }
            /*void */ AddResource$3(/*string*/ name, /*object?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                if (value !== null && $.$is(value, $.$$.System.IO.Stream))
                {
                    this.AddResourceInternal(name, $.$cast(value, $.$$.System.IO.Stream), false);
                }
                else 
                {
                    this._caseInsensitiveDups.Add(name, null);
                    this._resourceList.Add(name, value);
                }
            }
            /*void */ AddResource$1(/*string*/ name, /*Stream?*/ value, /*bool*/ closeAfterWrite)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this.AddResourceInternal(name, value, closeAfterWrite);
            }
            /*void */ AddResourceInternal(/*string*/ name, /*Stream?*/ value, /*bool*/ closeAfterWrite)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._resourceList !== null, "_resourceList != null");
                if (value === null)
                {
                    this._caseInsensitiveDups.Add(name, null);
                    this._resourceList.Add(name, value);
                }
                else 
                {
                    if (!value.CanSeek)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$srw.System.SR.NotSupported_UnseekableStream);
                    }
                    this._caseInsensitiveDups.Add(name, null);
                    this._resourceList.Add(name, new $.$srw.System.Resources.ResourceWriter.StreamWrapper().$ctor$1(value, closeAfterWrite));
                }
            }
            /*void */ AddResource(/*string*/ name, /*byte[]?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this._caseInsensitiveDups.Add(name, null);
                this._resourceList.Add(name, value);
            }
            /*void */ AddResourceData$1(/*string*/ name, /*string*/ typeName, /*object*/ data)
            {
                if (this._resourceList === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this._caseInsensitiveDups.Add(name, null);
                this._preserializedData ??= new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$srw.System.Resources.ResourceWriter.PrecannedResource))().$ctor$6($.$srw.System.Resources.FastResourceComparer.Default);
                this._preserializedData.Add(name, new $.$srw.System.Resources.ResourceWriter.PrecannedResource().$ctor$1(typeName, data));
            }
            static $_PrecannedResource;
            static get PrecannedResource()
            {
                let $cls = $.$srw.System.Resources.ResourceWriter;
                return $cls.$_PrecannedResource ??= $asm.$ncls("$srw.System.Resources.ResourceWriter.PrecannedResource", ($self) => class PrecannedResource extends $.$$.System.Object
                {
                    /*string*/ TypeName = null;
                    /*object*/ Data = null;
                    $ctor$1(/*string*/ typeName, /*object*/ data)
                    {
                        super.$ctor();
                        {
                            this.TypeName = typeName;
                            this.Data = data;
                        }
                        return this;
                    }
                    static $h = 369205;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"TypeName","d":369205,"h":4295336501,"f":4194312},{"t":131073,"n":"Data","d":369205,"h":8590303797,"f":4194312}],"c":[{"p":[{"n":"typeName","p":1310721},{"n":"data","p":131073}],"n":".ctor","o":"$ctor$1","d":369205,"h":12885271093,"f":16777224}],"d":303669,"h":369205}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Resources.ResourceWriter.PrecannedResource`; }
                }, $cls, ($v) => $cls.$_PrecannedResource = $v);
            }
            static $_StreamWrapper;
            static get StreamWrapper()
            {
                let $cls = $.$srw.System.Resources.ResourceWriter;
                return $cls.$_StreamWrapper ??= $asm.$ncls("$srw.System.Resources.ResourceWriter.StreamWrapper", ($self) => class StreamWrapper extends $.$$.System.Object
                {
                    /*Stream*/ Stream = null;
                    /*bool*/ CloseAfterWrite = false;
                    $ctor$1(/*Stream*/ s, /*bool*/ closeAfterWrite)
                    {
                        super.$ctor();
                        {
                            this.Stream = s;
                            this.CloseAfterWrite = closeAfterWrite;
                        }
                        return this;
                    }
                    static $h = 434741;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":62193665,"n":"Stream","d":434741,"h":4295402037,"f":4194312},{"t":262145,"n":"CloseAfterWrite","d":434741,"h":8590369333,"f":4194312}],"c":[{"p":[{"n":"s","p":62193665},{"n":"closeAfterWrite","p":262145}],"n":".ctor","o":"$ctor$1","d":434741,"h":12885336629,"f":16777224}],"d":303669,"h":434741}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Resources.ResourceWriter.StreamWrapper`; }
                }, $cls, ($v) => $cls.$_StreamWrapper = $v);
            }
            /*void */ Close()
            {
                this.Dispose$1(true);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing)
                {
                    if (this._resourceList !== null)
                    {
                        this.Generate();
                    }
                    this._output?.Dispose();
                }
                this._output = null;
                this._caseInsensitiveDups = null;
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
            }
            /*void */ Generate()
            {
                if (this._resourceList === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                /*BinaryWriter*/ let bw = new $.$$.System.IO.BinaryWriter().$ctor$3(this._output, $.$$.System.Text.Encoding.UTF8);
                /*List<string>*/ let typeNames = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                bw.Write$11($.$$.System.Resources.ResourceManager.MagicNumber);
                bw.Write$11($.$$.System.Resources.ResourceManager.HeaderVersionNumber);
                /*MemoryStream*/ let resMgrHeaderBlob = new $.$$.System.IO.MemoryStream().$ctor$9(240);
                /*BinaryWriter*/ let resMgrHeaderPart = new $.$$.System.IO.BinaryWriter().$ctor$4(resMgrHeaderBlob);
                resMgrHeaderPart.Write$17($.$srw.System.Resources.ResourceWriter.ResourceReaderTypeName);
                resMgrHeaderPart.Write$17($.$srw.System.Resources.ResourceWriter.ResourceSetTypeName);
                resMgrHeaderPart.Flush();
                bw.Write$11($.$cast(resMgrHeaderBlob.Length, $.$$.System.Int32));
                $.$$.System.Diagnostics.Debug.Assert$2(resMgrHeaderBlob.Length > 0n, "ResourceWriter: Expected non empty header");
                resMgrHeaderBlob.Seek(0n, 0/*SeekOrigin.Begin*/);
                resMgrHeaderBlob.CopyTo(bw.BaseStream, $.$cast(resMgrHeaderBlob.Length, $.$$.System.Int32));
                bw.Write$11(2/*ResSetVersion*/);
                /*int*/ let numResources = this._resourceList.Count;
                if (this._preserializedData !== null)
                {
                    numResources += this._preserializedData.Count;
                }
                bw.Write$11(numResources);
                /*int[]*/ let nameHashes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [numResources], null);
                /*int[]*/ let namePositions = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [numResources], null);
                /*int*/ let curNameNumber = 0;
                /*MemoryStream*/ let nameSection = new $.$$.System.IO.MemoryStream().$ctor$9(((numResources * 40/*AverageNameSize*/) | 0));
                /*BinaryWriter*/ let names = new $.$$.System.IO.BinaryWriter().$ctor$3(nameSection, $.$$.System.Text.Encoding.Unicode);
                /*Stream*/ let dataSection = new $.$$.System.IO.MemoryStream().$ctor$3();
                let $disposable1 = null;
                try
                {
                    $disposable1 = dataSection;
                    /*BinaryWriter*/ let data = new $.$$.System.IO.BinaryWriter().$ctor$3(dataSection, $.$$.System.Text.Encoding.UTF8);
                    if (this._preserializedData !== null)
                    {
                        var $en4 = this._preserializedData.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var entry = $en4.Current;
                            {
                                this._resourceList.Add(entry.Key, entry.Value);
                            }
                        }
                    }
                    var $en3 = this._resourceList.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var item = $en3.Current;
                        {
                            $.$$.System.Array.$WriteT1.call(nameHashes, $.$srw.System.Resources.FastResourceComparer.HashFunction(item.Key), curNameNumber);
                            $.$$.System.Array.$WriteT1.call(namePositions, $.$cast(names.Seek(0, 1/*SeekOrigin.Current*/), $.$$.System.Int32), curNameNumber++);
                            names.Write$17(item.Key);
                            names.Write$11($.$cast(data.Seek(0, 1/*SeekOrigin.Current*/), $.$$.System.Int32));
                            /*object?*/ let value = item.Value;
                            /*ResourceTypeCode*/ let typeCode = $.$srw.System.Resources.ResourceWriter.FindTypeCode(value, typeNames);
                            data.Write7BitEncodedInt(typeCode);
                            /*var*/ let userProvidedResource = $.$as(value, $.$srw.System.Resources.ResourceWriter.PrecannedResource);
                            if (userProvidedResource !== null)
                            {
                                $.$srw.System.Resources.ResourceWriter.WriteData(data, userProvidedResource.Data);
                            }
                            else 
                            {
                                $.$srw.System.Resources.ResourceWriter.WriteValue(typeCode, value, data);
                            }
                        }
                    }
                    bw.Write$11(typeNames.Count);
                    var $en3 = typeNames.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var typeName = $en3.Current;
                        {
                            bw.Write$17(typeName);
                        }
                    }
                    $.$$.System.Array.Sort$16($.$$.System.Int32, $.$$.System.Int32, nameHashes, namePositions);
                    bw.Flush();
                    /*int*/ let alignBytes = ($.$cast(bw.BaseStream.Position, $.$$.System.Int32)) & 7;
                    if (alignBytes > 0)
                    {
                        for(/*int*/ let i = 0; i < ((8 - alignBytes) | 0); i++)
                        {
                            bw.Write$4($.$$.System.String.get_Chars.call("PAD", i % 3));
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2((bw.BaseStream.Position & 7n) === 0n, "ResourceWriter: Name hashes array won't be 8 byte aligned!  Ack!");
                    let $i2 = 0;
                    let $arr2 = nameHashes;
                    while ($i2 < $arr2.length)
                    {
                        let hash = $arr2[$i2++];
                        bw.Write$11(hash);
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2((bw.BaseStream.Position & 3n) === 0n, "ResourceWriter: Name positions array won't be 4 byte aligned!  Ack!");
                    let $i3 = 0;
                    let $arr3 = namePositions;
                    while ($i3 < $arr3.length)
                    {
                        let pos = $arr3[$i3++];
                        bw.Write$11(pos);
                    }
                    bw.Flush();
                    names.Flush();
                    data.Flush();
                    /*int*/ let startOfDataSection = $.$cast((bw.Seek(0, 1/*SeekOrigin.Current*/) + nameSection.Length), $.$$.System.Int32);
                    startOfDataSection += 4;
                    bw.Write$11(startOfDataSection);
                    if (nameSection.Length > 0n)
                    {
                        nameSection.Seek(0n, 0/*SeekOrigin.Begin*/);
                        nameSection.CopyTo(bw.BaseStream, $.$cast(nameSection.Length, $.$$.System.Int32));
                    }
                    names.Dispose();
                    $.$$.System.Diagnostics.Debug.Assert$2(BigInt(startOfDataSection) === bw.Seek(0, 1/*SeekOrigin.Current*/), "ResourceWriter::Generate - start of data section is wrong!");
                    dataSection.Position = 0n;
                    dataSection.CopyTo$1(bw.BaseStream);
                    data.Dispose();
                }
                finally
                {
                    $disposable1?.System$IDisposable$Dispose();
                }
                bw.Flush();
                this._resourceList = null;
            }
            static /*ResourceTypeCode */ FindTypeCode(/*object?*/ value, /*List<string>*/ types)
            {
                if (value === null)
                {
                    return 0/*ResourceTypeCode.Null*/;
                }
                /*Type*/ let type = $.$$.System.Object.GetType.call(value);
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.String.$type))
                {
                    return 1/*ResourceTypeCode.String*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Int32.$type))
                {
                    return 8/*ResourceTypeCode.Int32*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Boolean.$type))
                {
                    return 2/*ResourceTypeCode.Boolean*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Char.$type))
                {
                    return 3/*ResourceTypeCode.Char*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Byte.$type))
                {
                    return 4/*ResourceTypeCode.Byte*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.SByte.$type))
                {
                    return 5/*ResourceTypeCode.SByte*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Int16.$type))
                {
                    return 6/*ResourceTypeCode.Int16*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Int64.$type))
                {
                    return 10/*ResourceTypeCode.Int64*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.UInt16.$type))
                {
                    return 7/*ResourceTypeCode.UInt16*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.UInt32.$type))
                {
                    return 9/*ResourceTypeCode.UInt32*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.UInt64.$type))
                {
                    return 11/*ResourceTypeCode.UInt64*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Single.$type))
                {
                    return 12/*ResourceTypeCode.Single*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Double.$type))
                {
                    return 13/*ResourceTypeCode.Double*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Decimal.$type))
                {
                    return 14/*ResourceTypeCode.Decimal*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.DateTime.$type))
                {
                    return 15/*ResourceTypeCode.DateTime*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$$.System.TimeSpan.$type))
                {
                    return 16/*ResourceTypeCode.TimeSpan*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$typeArray($.$$.System.Byte).$type))
                {
                    return 32/*ResourceTypeCode.ByteArray*/;
                }
                else if ($.$$.System.Type.op_Equality$1(type, $.$srw.System.Resources.ResourceWriter.StreamWrapper.$type))
                {
                    return 33/*ResourceTypeCode.Stream*/;
                }
                /*string*/ let typeName;
                if ($.$$.System.Type.op_Equality$1(type, $.$srw.System.Resources.ResourceWriter.PrecannedResource.$type))
                {
                    typeName = ($.$cast(value, $.$srw.System.Resources.ResourceWriter.PrecannedResource)).TypeName;
                    if ($.$$.System.String.StartsWith$2.call(typeName, "ResourceTypeCode.", 4/*StringComparison.Ordinal*/))
                    {
                        typeName = $.$$.System.String.Substring$1.call(typeName, 17);
                        /*ResourceTypeCode*/ let typeCode = $.$$.System.Enum.Parse$7($.$srw.System.Resources.ResourceTypeCode, typeName);
                        return typeCode;
                    }
                }
                else 
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$16($.$srw.System.SR.NotSupported_BinarySerializedResources);
                }
                /*int*/ let typeIndex = types.IndexOf$2(typeName);
                if (typeIndex === -1)
                {
                    typeIndex = types.Count;
                    types.Add(typeName);
                }
                return (typeIndex + 64/*ResourceTypeCode.StartOfUserTypes*/);
            }
            static /*void */ WriteValue(/*ResourceTypeCode*/ typeCode, /*object?*/ value, /*BinaryWriter*/ writer)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(writer !== null, "writer != null");
                switch(typeCode)
                {
                    case 0/*ResourceTypeCode.Null*/:
                    break;
                    case 1/*ResourceTypeCode.String*/:
                    writer.Write$17($.$cast(value, $.$$.System.String));
                    break;
                    case 2/*ResourceTypeCode.Boolean*/:
                    writer.Write($.$cast(value, $.$$.System.Boolean));
                    break;
                    case 3/*ResourceTypeCode.Char*/:
                    writer.Write$18($.$cast(value, $.$$.System.Char));
                    break;
                    case 4/*ResourceTypeCode.Byte*/:
                    writer.Write$1($.$cast(value, $.$$.System.Byte));
                    break;
                    case 5/*ResourceTypeCode.SByte*/:
                    writer.Write$15($.$cast(value, $.$$.System.SByte));
                    break;
                    case 6/*ResourceTypeCode.Int16*/:
                    writer.Write$10($.$cast(value, $.$$.System.Int16));
                    break;
                    case 7/*ResourceTypeCode.UInt16*/:
                    writer.Write$18($.$cast(value, $.$$.System.UInt16));
                    break;
                    case 8/*ResourceTypeCode.Int32*/:
                    writer.Write$11($.$cast(value, $.$$.System.Int32));
                    break;
                    case 9/*ResourceTypeCode.UInt32*/:
                    writer.Write$19($.$cast(value, $.$$.System.UInt32));
                    break;
                    case 10/*ResourceTypeCode.Int64*/:
                    writer.Write$12($.$cast(value, $.$$.System.Int64));
                    break;
                    case 11/*ResourceTypeCode.UInt64*/:
                    writer.Write$20($.$cast(value, $.$$.System.UInt64));
                    break;
                    case 12/*ResourceTypeCode.Single*/:
                    writer.Write$16($.$cast(value, $.$$.System.Single));
                    break;
                    case 13/*ResourceTypeCode.Double*/:
                    writer.Write$8($.$cast(value, $.$$.System.Double));
                    break;
                    case 14/*ResourceTypeCode.Decimal*/:
                    writer.Write$7($.$cast(value, $.$$.System.Decimal));
                    break;
                    case 15/*ResourceTypeCode.DateTime*/:
                    /*long*/ let data = ($.$cast(value, $.$$.System.DateTime)).ToBinary();
                    writer.Write$12(data);
                    break;
                    case 16/*ResourceTypeCode.TimeSpan*/:
                    writer.Write$12(($.$cast(value, $.$$.System.TimeSpan)).Ticks);
                    break;
                    case 32/*ResourceTypeCode.ByteArray*/:
                    {
                        /*byte[]*/ let bytes = $.$cast(value, $.$typeArray($.$$.System.Byte));
                        writer.Write$11(bytes.length);
                        writer.Write$2(bytes, 0, bytes.length);
                        break;
                    }
                    case 33/*ResourceTypeCode.Stream*/:
                    {
                        /*StreamWrapper*/ let sw = $.$cast(value, $.$srw.System.Resources.ResourceWriter.StreamWrapper);
                        if ($.$$.System.Type.op_Equality$1($.$$.System.Object.GetType.call(sw.Stream), $.$$.System.IO.MemoryStream.$type))
                        {
                            /*MemoryStream*/ let ms = $.$cast(sw.Stream, $.$$.System.IO.MemoryStream);
                            if (ms.Length > BigInt(2147483647/*int.MaxValue*/))
                            {
                                throw new $.$$.System.ArgumentException().$ctor$14($.$srw.System.SR.ArgumentOutOfRange_StreamLength);
                            }
                            /*byte[]*/ let arr = ms.ToArray();
                            writer.Write$11(arr.length);
                            writer.Write$2(arr, 0, arr.length);
                        }
                        else 
                        {
                            /*Stream*/ let s = sw.Stream;
                            if (s.Length > BigInt(2147483647/*int.MaxValue*/))
                            {
                                throw new $.$$.System.ArgumentException().$ctor$14($.$srw.System.SR.ArgumentOutOfRange_StreamLength);
                            }
                            s.Position = 0n;
                            writer.Write$11($.$cast(s.Length, $.$$.System.Int32));
                            /*byte[]*/ let buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [4096], null);
                            /*int*/ let read;
                            while((read = s.Read(buffer, 0, buffer.length)) !== 0)
                            {
                                writer.Write$2(buffer, 0, read);
                            }
                            if (sw.CloseAfterWrite)
                            {
                                s.Close();
                            }
                        }
                        break;
                    }
                    default:
                    $.$$.System.Diagnostics.Debug.Assert$4(typeCode >= 64/*ResourceTypeCode.StartOfUserTypes*/, `ResourceReader: Unsupported ResourceTypeCode in .resources file!  ${typeCode}`);
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$16($.$srw.System.SR.NotSupported_BinarySerializedResources);
                }
            }
            //Generated interface implemetation for System.Resources.IResourceWriter.AddResource(string, string?)
            System$Resources$IResourceWriter$AddResource$2()
            {
                return this.AddResource$4(...arguments);
            }
            //Generated interface implemetation for System.Resources.IResourceWriter.AddResource(string, object?)
            System$Resources$IResourceWriter$AddResource$1()
            {
                return this.AddResource$3(...arguments);
            }
            //Generated interface implemetation for System.Resources.IResourceWriter.AddResource(string, byte[]?)
            System$Resources$IResourceWriter$AddResource()
            {
                return this.AddResource(...arguments);
            }
            //Generated interface implemetation for System.Resources.IResourceWriter.Close()
            System$Resources$IResourceWriter$Close()
            {
                return this.Close(...arguments);
            }
            //Generated interface implemetation for System.Resources.IResourceWriter.Generate()
            System$Resources$IResourceWriter$Generate()
            {
                return this.Generate(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ResourceReaderFullyQualifiedName = "System.Resources.ResourceReader, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089";
                }
                {
                    this.ResSetTypeName = "System.Resources.RuntimeResourceSet";
                }
            }
            static $h = 303669;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Func$$$($.$$.System.Type, $.$$.System.String).$h,"g":{"r":0,"d":0,"h":12885205557,"f":50331649},"s":{"r":0,"d":0,"h":17180172853,"f":83886081},"n":"TypeNameConverter","d":303669,"h":8590238261,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":34360042037,"f":50331682},"n":"ResourceReaderTypeName","d":303669,"h":30065074741,"f":2097186},{"p":1310721,"g":{"r":0,"d":0,"h":42949976629,"f":50331682},"n":"ResourceSetTypeName","d":303669,"h":38655009333,"f":2097186}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":62193665}],"n":"AddResource","o":"@$2","d":303669,"h":21475140149,"f":16777217},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"typeName","p":1310721},{"n":"serializedData","p":$.$typeArray($.$$.System.Byte).$h}],"n":"AddResourceData","d":303669,"h":25770107445,"f":16777217},{"r":65537,"p":[{"n":"writer","p":58523649},{"n":"dataContext","p":131073}],"n":"WriteData","d":303669,"h":47244943925,"f":16777250},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":1310721}],"n":"AddResource","o":"@$4","d":303669,"h":94489584181,"f":16777217},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":131073}],"n":"AddResource","o":"@$3","d":303669,"h":98784551477,"f":16777217},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":62193665},{"n":"closeAfterWrite","p":262145,"f":65,"v":false}],"n":"AddResource","o":"@$1","d":303669,"h":103079518773,"f":16777217},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":62193665},{"n":"closeAfterWrite","p":262145}],"n":"AddResourceInternal","d":303669,"h":107374486069,"f":16777218},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":$.$typeArray($.$$.System.Byte).$h}],"n":"AddResource","d":303669,"h":111669453365,"f":16777217},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"typeName","p":1310721},{"n":"data","p":131073}],"n":"AddResourceData","o":"@$1","d":303669,"h":115964420661,"f":16777218},{"r":65537,"n":"Close","d":303669,"h":128849322549,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":303669,"h":133144289845,"f":16777218},{"r":65537,"n":"Dispose","d":303669,"h":137439257141,"f":16777217},{"r":65537,"n":"Generate","d":303669,"h":141734224437,"f":16777217},{"r":238133,"p":[{"n":"value","p":131073},{"n":"types","p":$.$$.System.Collections.Generic.List$$($.$$.System.String).$h}],"n":"FindTypeCode","d":303669,"h":146029191733,"f":16777250},{"r":65537,"p":[{"n":"typeCode","p":238133},{"n":"value","p":131073},{"n":"writer","p":58523649}],"n":"WriteValue","d":303669,"h":150324159029,"f":16777250}],"l":[{"t":655361,"n":"AverageNameSize","d":303669,"h":51539911221,"f":4194338},{"t":1310721,"n":"ResourceReaderFullyQualifiedName","d":303669,"h":55834878517,"f":4194344},{"t":1310721,"n":"ResSetTypeName","d":303669,"h":60129845813,"f":4194338},{"t":655361,"n":"ResSetVersion","d":303669,"h":64424813109,"f":4194338},{"t":$.$sc.System.Collections.Generic.SortedDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"n":"_resourceList","d":303669,"h":68719780405,"f":4194306},{"t":62193665,"n":"_output","d":303669,"h":73014747701,"f":4194306},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object).$h,"n":"_caseInsensitiveDups","d":303669,"h":77309714997,"f":4194306},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$srw.System.Resources.ResourceWriter.PrecannedResource).$h,"n":"_preserializedData","d":303669,"h":81604682293,"f":4194306}],"c":[{"p":[{"n":"fileName","p":1310721}],"n":".ctor","o":"$ctor$2","d":303669,"h":85899649589,"f":16777217},{"p":[{"n":"stream","p":62193665}],"n":".ctor","o":"$ctor$1","d":303669,"h":90194616885,"f":16777217}],"i":[172597,57540609],"j":[369205,434741],"h":303669}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srw.System.Resources.IResourceWriter, $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Resources.ResourceWriter`; }
        });
        
        $asm.$str("$srw.System.Resources.ResourceTypeCode", ($self) => class ResourceTypeCode extends $.$$.System.Enum
        {
            static Null = 0;
            static String = 1;
            static Boolean = 2;
            static Char = 3;
            static Byte = 4;
            static SByte = 5;
            static Int16 = 6;
            static UInt16 = 7;
            static Int32 = 8;
            static UInt32 = 9;
            static Int64 = 10;
            static UInt64 = 11;
            static Single = 12;
            static Double = 13;
            static Decimal = 14;
            static DateTime = 15;
            static TimeSpan = 16;
            static LastPrimitive = 16;
            static ByteArray = 32;
            static Stream = 33;
            static StartOfUserTypes = 64;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Null": 0n,
                    "String": 1n,
                    "Boolean": 2n,
                    "Char": 3n,
                    "Byte": 4n,
                    "SByte": 5n,
                    "Int16": 6n,
                    "UInt16": 7n,
                    "Int32": 8n,
                    "UInt32": 9n,
                    "Int64": 10n,
                    "UInt64": 11n,
                    "Single": 12n,
                    "Double": 13n,
                    "Decimal": 14n,
                    "DateTime": 15n,
                    "TimeSpan": 16n,
                    "LastPrimitive": 16n,
                    "ByteArray": 32n,
                    "Stream": 33n,
                    "StartOfUserTypes": 64n
                };
            }
            static $h = 238133;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":238133,"n":"Null","d":238133,"h":4295205429,"f":4194337},{"t":238133,"n":"String","d":238133,"h":8590172725,"f":4194337},{"t":238133,"n":"Boolean","d":238133,"h":12885140021,"f":4194337},{"t":238133,"n":"Char","d":238133,"h":17180107317,"f":4194337},{"t":238133,"n":"Byte","d":238133,"h":21475074613,"f":4194337},{"t":238133,"n":"SByte","d":238133,"h":25770041909,"f":4194337},{"t":238133,"n":"Int16","d":238133,"h":30065009205,"f":4194337},{"t":238133,"n":"UInt16","d":238133,"h":34359976501,"f":4194337},{"t":238133,"n":"Int32","d":238133,"h":38654943797,"f":4194337},{"t":238133,"n":"UInt32","d":238133,"h":42949911093,"f":4194337},{"t":238133,"n":"Int64","d":238133,"h":47244878389,"f":4194337},{"t":238133,"n":"UInt64","d":238133,"h":51539845685,"f":4194337},{"t":238133,"n":"Single","d":238133,"h":55834812981,"f":4194337},{"t":238133,"n":"Double","d":238133,"h":60129780277,"f":4194337},{"t":238133,"n":"Decimal","d":238133,"h":64424747573,"f":4194337},{"t":238133,"n":"DateTime","d":238133,"h":68719714869,"f":4194337},{"t":238133,"n":"TimeSpan","d":238133,"h":73014682165,"f":4194337},{"t":238133,"n":"LastPrimitive","d":238133,"h":77309649461,"f":4194337},{"t":238133,"n":"ByteArray","d":238133,"h":81604616757,"f":4194337},{"t":238133,"n":"Stream","d":238133,"h":85899584053,"f":4194337},{"t":238133,"n":"StartOfUserTypes","d":238133,"h":90194551349,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":238133,"h":94489518645,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":238133}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Resources.ResourceTypeCode`; }
        });
        
        $asm.$cls("$srw.System.Resources.FastResourceComparer", ($self) => class FastResourceComparer extends $.$$.System.Object
        {
            /*FastResourceComparer*/ static Default = null;
            /*int */ GetHashCode$1(/*string*/ key)
            {
                return $.$srw.System.Resources.FastResourceComparer.HashFunction(key);
            }
            static /*int */ HashFunction(/*string*/ key)
            {
                /*uint*/ let hash = 5381;
                for(/*int*/ let i = 0; i < key.length; i++)
                {
                    hash = ((((hash << 5) >>> 0) + hash) >>> 0) ^ $.$$.System.String.get_Chars.call(key, i);
                }
                return (hash | 0);
            }
            /*int */ Compare(/*string?*/ a, /*string?*/ b)
            {
                return $.$$.System.String.CompareOrdinal$2(a, b);
            }
            /*bool */ Equals$2(/*string?*/ a, /*string?*/ b)
            {
                return $.$$.System.String.Equals$3(a, b);
            }
            //Generated interface implemetation for System.Collections.Generic.IComparer<string>.Compare(string?, string?)
            System$Collections$Generic$IComparer$$$Compare()
            {
                return this.Compare(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<string>.Equals(string?, string?)
            System$Collections$Generic$IEqualityComparer$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<string>.GetHashCode(string)
            System$Collections$Generic$IEqualityComparer$$$GetHashCode()
            {
                return this.GetHashCode$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$srw.System.Resources.FastResourceComparer().$ctor$1();
                }
            }
            static $h = 107061;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"key","p":1310721}],"n":"GetHashCode","o":"@$1","d":107061,"h":8590041653,"f":16777217},{"r":655361,"p":[{"n":"key","p":1310721}],"n":"HashFunction","d":107061,"h":12885008949,"f":16777256},{"r":655361,"p":[{"n":"a","p":1310721},{"n":"b","p":1310721}],"n":"Compare","d":107061,"h":17179976245,"f":16777217},{"r":262145,"p":[{"n":"a","p":1310721},{"n":"b","p":1310721}],"n":"Equals","o":"@$2","d":107061,"h":21474943541,"f":16777217}],"l":[{"t":107061,"n":"Default","d":107061,"h":4295074357,"f":4194344}],"c":[{"n":".ctor","o":"$ctor$1","d":107061,"h":25769910837,"f":16777217}],"i":[$.$$.System.Collections.Generic.IComparer$$($.$$.System.String).$h,$.$$.System.Collections.Generic.IEqualityComparer$$($.$$.System.String).$h],"h":107061}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IComparer$$($.$$.System.String), $.$$.System.Collections.Generic.IEqualityComparer$$($.$$.System.String) ]; }
            static get $fullName() { return `System.Resources.FastResourceComparer`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime"))