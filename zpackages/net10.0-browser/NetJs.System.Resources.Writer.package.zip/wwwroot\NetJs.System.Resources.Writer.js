
(function ($global, $, $spc, $sc, $sm, $spu, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Resources.Writer", 
    {"h":65482,"f":"System.Resources.Writer","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Resources.Writer","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Resources.Writer","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$srw.System.Resources.IResourceWriter", ($self) => class IResourceWriter
        {
            static $h = 196554;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":1310721}],"n":"AddResource","o":"System$Resources$IResourceWriter$AddResource","d":196554,"h":4295163850,"f":257},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":131073}],"n":"AddResource","o":"System$Resources$IResourceWriter$AddResource$1","d":196554,"h":8590131146,"f":257},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":0}],"n":"AddResource","o":"System$Resources$IResourceWriter$AddResource$2","d":196554,"h":12885098442,"f":257},{"r":65537,"n":"Close","o":"System$Resources$IResourceWriter$Close","d":196554,"h":17180065738,"f":257},{"r":65537,"n":"Generate","o":"System$Resources$IResourceWriter$Generate","d":196554,"h":21475033034,"f":257}],"i":[57475073],"h":196554}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Resources.IResourceWriter`; }
        });
        
        $asm.$cls("$srw.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$srw.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Resources.Writer", $.$srw.System.SR.$type.Assembly);
                    $.$srw.System.SR.s_resourceManager = temp;
                }
                return $.$srw.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$srw.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$srw.System.SR.resourceCulture = value;
            }
            static /*string */ get InvalidOperation_ResourceWriterSaved()
            {
                return "The resource writer has already been closed and cannot be edited.";
            }
            static /*string */ get Argument_StreamNotWritable()
            {
                return "Stream was not writable.";
            }
            static /*string */ get NotSupported_UnseekableStream()
            {
                return "Stream does not support seeking.";
            }
            static /*string */ get NotSupported_BinarySerializedResources()
            {
                return "This platform does not support binary serialized resources.";
            }
            static /*string */ get ArgumentOutOfRange_StreamLength()
            {
                return "Stream length must be non-negative and less than 2^31 - 1 - origin.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$srw.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srw.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$srw.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srw.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$srw.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$srw.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$srw.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 524234;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":524234}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$srw.System.Resources.ResourceWriter", ($self) => class ResourceWriter extends $.$spc.System.Object
        {
            /*Func<Type, string>?*/ TypeNameConverter = null;
            /*void */ AddResource(/*string*/ name, /*Stream?*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this.AddResourceInternal(name, value, false);
            }
            /*void */ AddResourceData(/*string*/ name, /*string*/ typeName, /*byte[]*/ serializedData)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                $.$spc.System.ArgumentNullException.ThrowIfNull(typeName, "typeName");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serializedData, "serializedData");
                this.AddResourceData$1(name, typeName, $.$cast(serializedData, $.$spc.System.Object));
            }
            static /*string */ get ResourceReaderTypeName()
            {
                return "System.Resources.ResourceReader, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"/*ResourceReaderFullyQualifiedName*/;
            }
            static /*string */ get ResourceSetTypeName()
            {
                return "System.Resources.RuntimeResourceSet"/*ResSetTypeName*/;
            }
            static /*void */ WriteData(/*BinaryWriter*/ writer, /*object*/ dataContext)
            {
                /*byte[]?*/ let data = $.$as(dataContext, $.$typeArray($.$spc.System.Byte));
                $.$spc.System.Diagnostics.Debug.Assert$1(data !== null, "data != null");
                writer.Write$3(data);
            }
            /*int*/ static AverageNameSize = 40;
            /*string*/ static ResourceReaderFullyQualifiedName = null;
            /*string*/ static ResSetTypeName = null;
            /*int*/ static ResSetVersion = 2;
            /*SortedDictionary<string, object?>?*/ _resourceList = null;
            /*Stream*/ _output = null;
            /*Dictionary<string, object?>*/ _caseInsensitiveDups = null;
            /*Dictionary<string, PrecannedResource>?*/ _preserializedData = null;
            $ctor$1(/*string*/ fileName)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(fileName, "fileName");
                    this._output = new $.$spc.System.IO.FileStream().$ctor$12(fileName, 2/*FileMode.Create*/, 2/*FileAccess.Write*/, 0/*FileShare.None*/);
                    this._resourceList = new ($.$sc.System.Collections.Generic.SortedDictionary$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$4($.$srw.System.Resources.FastResourceComparer.Default);
                    this._caseInsensitiveDups = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$3($.$spc.System.StringComparer.OrdinalIgnoreCase);
                }
                return this;
            }
            $ctor$2(/*Stream*/ stream)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                    if (!stream.CanWrite)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$srw.System.SR.Argument_StreamNotWritable);
                    }
                    this._output = stream;
                    this._resourceList = new ($.$sc.System.Collections.Generic.SortedDictionary$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$4($.$srw.System.Resources.FastResourceComparer.Default);
                    this._caseInsensitiveDups = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$3($.$spc.System.StringComparer.OrdinalIgnoreCase);
                }
                return this;
            }
            /*void */ AddResource$1(/*string*/ name, /*string?*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this._caseInsensitiveDups.Add(name, null);
                this._resourceList.Add(name, value);
            }
            /*void */ AddResource$2(/*string*/ name, /*object?*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                if (value !== null && $.$is(value, $.$spc.System.IO.Stream))
                {
                    this.AddResourceInternal(name, $.$cast(value, $.$spc.System.IO.Stream), false);
                }
                else 
                {
                    this._caseInsensitiveDups.Add(name, null);
                    this._resourceList.Add(name, value);
                }
            }
            /*void */ AddResource$3(/*string*/ name, /*Stream?*/ value, /*bool*/ closeAfterWrite)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this.AddResourceInternal(name, value, closeAfterWrite);
            }
            /*void */ AddResourceInternal(/*string*/ name, /*Stream?*/ value, /*bool*/ closeAfterWrite)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._resourceList !== null, "_resourceList != null");
                if (value === null)
                {
                    this._caseInsensitiveDups.Add(name, null);
                    this._resourceList.Add(name, value);
                }
                else 
                {
                    if (!value.CanSeek)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$srw.System.SR.NotSupported_UnseekableStream);
                    }
                    this._caseInsensitiveDups.Add(name, null);
                    this._resourceList.Add(name, new $.$srw.System.Resources.ResourceWriter.StreamWrapper().$ctor$1(value, closeAfterWrite));
                }
            }
            /*void */ AddResource$4(/*string*/ name, /*byte[]?*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(name, "name");
                if (this._resourceList === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this._caseInsensitiveDups.Add(name, null);
                this._resourceList.Add(name, value);
            }
            /*void */ AddResourceData$1(/*string*/ name, /*string*/ typeName, /*object*/ data)
            {
                if (this._resourceList === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                this._caseInsensitiveDups.Add(name, null);
                this._preserializedData ??= new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$srw.System.Resources.ResourceWriter.PrecannedResource))().$ctor$3($.$srw.System.Resources.FastResourceComparer.Default);
                this._preserializedData.Add(name, new $.$srw.System.Resources.ResourceWriter.PrecannedResource().$ctor$1(typeName, data));
            }
            static $_PrecannedResource;
            static get PrecannedResource()
            {
                let $cls = $.$srw.System.Resources.ResourceWriter;
                return $cls.$_PrecannedResource ??= $asm.$ncls("$srw.System.Resources.ResourceWriter.PrecannedResource", ($self) => class PrecannedResource extends $.$spc.System.Object
                {
                    /*string*/ TypeName = null;
                    /*object*/ Data = null;
                    $ctor$1(/*string*/ typeName, /*object*/ data)
                    {
                        super.$ctor();
                        {
                            this.TypeName = typeName;
                            this.Data = data;
                        }
                        return this;
                    }
                    static $h = 393162;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"TypeName","d":393162,"h":4295360458,"f":8},{"t":131073,"n":"Data","d":393162,"h":8590327754,"f":8}],"c":[{"p":[{"n":"typeName","p":1310721},{"n":"data","p":131073}],"n":".ctor","o":"$ctor$1","d":393162,"h":12885295050,"f":8}],"d":327626,"h":393162}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Resources.ResourceWriter.PrecannedResource`; }
                }, $cls, ($v) => $cls.$_PrecannedResource = $v);
            }
            static $_StreamWrapper;
            static get StreamWrapper()
            {
                let $cls = $.$srw.System.Resources.ResourceWriter;
                return $cls.$_StreamWrapper ??= $asm.$ncls("$srw.System.Resources.ResourceWriter.StreamWrapper", ($self) => class StreamWrapper extends $.$spc.System.Object
                {
                    /*Stream*/ Stream = null;
                    /*bool*/ CloseAfterWrite = false;
                    $ctor$1(/*Stream*/ s, /*bool*/ closeAfterWrite)
                    {
                        super.$ctor();
                        {
                            this.Stream = s;
                            this.CloseAfterWrite = closeAfterWrite;
                        }
                        return this;
                    }
                    static $h = 458698;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":62128129,"n":"Stream","d":458698,"h":4295425994,"f":8},{"t":262145,"n":"CloseAfterWrite","d":458698,"h":8590393290,"f":8}],"c":[{"p":[{"n":"s","p":62128129},{"n":"closeAfterWrite","p":262145}],"n":".ctor","o":"$ctor$1","d":458698,"h":12885360586,"f":8}],"d":327626,"h":458698}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Resources.ResourceWriter.StreamWrapper`; }
                }, $cls, ($v) => $cls.$_StreamWrapper = $v);
            }
            /*void */ Close()
            {
                this.Dispose(true);
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
                if (disposing)
                {
                    if (this._resourceList !== null)
                    {
                        this.Generate();
                    }
                    this._output?.Dispose();
                }
                this._output = null;
                this._caseInsensitiveDups = null;
            }
            /*void */ Dispose$1()
            {
                this.Dispose(true);
            }
            /*void */ Generate()
            {
                if (this._resourceList === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$srw.System.SR.InvalidOperation_ResourceWriterSaved);
                }
                /*BinaryWriter*/ let bw = new $.$spc.System.IO.BinaryWriter().$ctor$3(this._output, $.$spc.System.Text.Encoding.UTF8);
                /*List<string>*/ let typeNames = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$1();
                bw.Write$12($.$spc.System.Resources.ResourceManager.MagicNumber);
                bw.Write$12($.$spc.System.Resources.ResourceManager.HeaderVersionNumber);
                /*MemoryStream*/ let resMgrHeaderBlob = new $.$spc.System.IO.MemoryStream().$ctor$4(240);
                /*BinaryWriter*/ let resMgrHeaderPart = new $.$spc.System.IO.BinaryWriter().$ctor$2(resMgrHeaderBlob);
                resMgrHeaderPart.Write$18($.$srw.System.Resources.ResourceWriter.ResourceReaderTypeName);
                resMgrHeaderPart.Write$18($.$srw.System.Resources.ResourceWriter.ResourceSetTypeName);
                resMgrHeaderPart.Flush();
                bw.Write$12($.$cast(resMgrHeaderBlob.Length, $.$spc.System.Int32));
                $.$spc.System.Diagnostics.Debug.Assert$1(resMgrHeaderBlob.Length > 0n, "ResourceWriter: Expected non empty header");
                resMgrHeaderBlob.Seek(0n, 0/*SeekOrigin.Begin*/);
                resMgrHeaderBlob.CopyTo$1(bw.BaseStream, $.$cast(resMgrHeaderBlob.Length, $.$spc.System.Int32));
                bw.Write$12(2/*ResSetVersion*/);
                /*int*/ let numResources = this._resourceList.Count;
                if (this._preserializedData !== null)
                {
                    numResources += this._preserializedData.Count;
                }
                bw.Write$12(numResources);
                /*int[]*/ let nameHashes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [numResources], null);
                /*int[]*/ let namePositions = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [numResources], null);
                /*int*/ let curNameNumber = 0;
                /*MemoryStream*/ let nameSection = new $.$spc.System.IO.MemoryStream().$ctor$4(((numResources * 40/*AverageNameSize*/) | 0));
                /*BinaryWriter*/ let names = new $.$spc.System.IO.BinaryWriter().$ctor$3(nameSection, $.$spc.System.Text.Encoding.Unicode);
                /*Stream*/ let dataSection = new $.$spc.System.IO.MemoryStream().$ctor$3();
                let $disposable1 = null;
                try
                {
                    $disposable1 = dataSection;
                    /*BinaryWriter*/ let data = new $.$spc.System.IO.BinaryWriter().$ctor$3(dataSection, $.$spc.System.Text.Encoding.UTF8);
                    if (this._preserializedData !== null)
                    {
                        var $en4 = this._preserializedData.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var entry = $en4.Current;
                            {
                                this._resourceList.Add(entry.Key, entry.Value);
                            }
                        }
                    }
                    var $en3 = this._resourceList.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var item = $en3.Current;
                        {
                            $.$spc.System.Array.$WriteT1.call(nameHashes, $.$srw.System.Resources.FastResourceComparer.HashFunction(item.Key), curNameNumber);
                            $.$spc.System.Array.$WriteT1.call(namePositions, $.$cast(names.Seek(0, 1/*SeekOrigin.Current*/), $.$spc.System.Int32), curNameNumber++);
                            names.Write$18(item.Key);
                            names.Write$12($.$cast(data.Seek(0, 1/*SeekOrigin.Current*/), $.$spc.System.Int32));
                            /*object?*/ let value = item.Value;
                            /*ResourceTypeCode*/ let typeCode = $.$srw.System.Resources.ResourceWriter.FindTypeCode(value, typeNames);
                            data.Write7BitEncodedInt(typeCode);
                            /*var*/ let userProvidedResource = $.$as(value, $.$srw.System.Resources.ResourceWriter.PrecannedResource);
                            if (userProvidedResource !== null)
                            {
                                $.$srw.System.Resources.ResourceWriter.WriteData(data, userProvidedResource.Data);
                            }
                            else 
                            {
                                $.$srw.System.Resources.ResourceWriter.WriteValue(typeCode, value, data);
                            }
                        }
                    }
                    bw.Write$12(typeNames.Count);
                    var $en3 = typeNames.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var typeName = $en3.Current;
                        {
                            bw.Write$18(typeName);
                        }
                    }
                    $.$spc.System.Array.Sort$9($.$spc.System.Int32, $.$spc.System.Int32, nameHashes, namePositions);
                    bw.Flush();
                    /*int*/ let alignBytes = ($.$cast(bw.BaseStream.Position, $.$spc.System.Int32)) & 7;
                    if (alignBytes > 0)
                    {
                        for(/*int*/ let i = 0; i < ((8 - alignBytes) | 0); i++)
                        {
                            bw.Write$5($.$spc.System.String.get_Chars.call("PAD", i % 3));
                        }
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1((bw.BaseStream.Position & 7n) === 0n, "ResourceWriter: Name hashes array won't be 8 byte aligned!  Ack!");
                    let $i2 = 0;
                    let $arr2 = nameHashes;
                    while ($i2 < $arr2.length)
                    {
                        let hash = $arr2[$i2++];
                        bw.Write$12(hash);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1((bw.BaseStream.Position & 3n) === 0n, "ResourceWriter: Name positions array won't be 4 byte aligned!  Ack!");
                    let $i3 = 0;
                    let $arr3 = namePositions;
                    while ($i3 < $arr3.length)
                    {
                        let pos = $arr3[$i3++];
                        bw.Write$12(pos);
                    }
                    bw.Flush();
                    names.Flush();
                    data.Flush();
                    /*int*/ let startOfDataSection = $.$cast((bw.Seek(0, 1/*SeekOrigin.Current*/) + nameSection.Length), $.$spc.System.Int32);
                    startOfDataSection += 4;
                    bw.Write$12(startOfDataSection);
                    if (nameSection.Length > 0n)
                    {
                        nameSection.Seek(0n, 0/*SeekOrigin.Begin*/);
                        nameSection.CopyTo$1(bw.BaseStream, $.$cast(nameSection.Length, $.$spc.System.Int32));
                    }
                    names.Dispose$1();
                    $.$spc.System.Diagnostics.Debug.Assert$1(BigInt(startOfDataSection) === bw.Seek(0, 1/*SeekOrigin.Current*/), "ResourceWriter::Generate - start of data section is wrong!");
                    dataSection.Position = 0n;
                    dataSection.CopyTo(bw.BaseStream);
                    data.Dispose$1();
                }
                finally
                {
                    $disposable1?.System$IDisposable$Dispose();
                }
                bw.Flush();
                this._resourceList = null;
            }
            static /*ResourceTypeCode */ FindTypeCode(/*object?*/ value, /*List<string>*/ types)
            {
                if (value === null)
                {
                    return 0/*ResourceTypeCode.Null*/;
                }
                /*Type*/ let type = $.$spc.System.Object.GetType.call(value);
                if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.String.$type))
                {
                    return 1/*ResourceTypeCode.String*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Int32.$type))
                {
                    return 8/*ResourceTypeCode.Int32*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Boolean.$type))
                {
                    return 2/*ResourceTypeCode.Boolean*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Char.$type))
                {
                    return 3/*ResourceTypeCode.Char*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Byte.$type))
                {
                    return 4/*ResourceTypeCode.Byte*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.SByte.$type))
                {
                    return 5/*ResourceTypeCode.SByte*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Int16.$type))
                {
                    return 6/*ResourceTypeCode.Int16*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Int64.$type))
                {
                    return 10/*ResourceTypeCode.Int64*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.UInt16.$type))
                {
                    return 7/*ResourceTypeCode.UInt16*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.UInt32.$type))
                {
                    return 9/*ResourceTypeCode.UInt32*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.UInt64.$type))
                {
                    return 11/*ResourceTypeCode.UInt64*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Single.$type))
                {
                    return 12/*ResourceTypeCode.Single*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Double.$type))
                {
                    return 13/*ResourceTypeCode.Double*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Decimal.$type))
                {
                    return 14/*ResourceTypeCode.Decimal*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.DateTime.$type))
                {
                    return 15/*ResourceTypeCode.DateTime*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.TimeSpan.$type))
                {
                    return 16/*ResourceTypeCode.TimeSpan*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$typeArray($.$spc.System.Byte).$type))
                {
                    return 32/*ResourceTypeCode.ByteArray*/;
                }
                else if ($.$spc.System.Type.op_Equality$1(type, $.$srw.System.Resources.ResourceWriter.StreamWrapper.$type))
                {
                    return 33/*ResourceTypeCode.Stream*/;
                }
                /*string*/ let typeName;
                if ($.$spc.System.Type.op_Equality$1(type, $.$srw.System.Resources.ResourceWriter.PrecannedResource.$type))
                {
                    typeName = ($.$cast(value, $.$srw.System.Resources.ResourceWriter.PrecannedResource)).TypeName;
                    if ($.$spc.System.String.StartsWith$1.call(typeName, "ResourceTypeCode.", 4/*StringComparison.Ordinal*/))
                    {
                        typeName = $.$spc.System.String.Substring.call(typeName, 17);
                        /*ResourceTypeCode*/ let typeCode = $.$spc.System.Enum.Parse$4($.$srw.System.Resources.ResourceTypeCode, typeName);
                        return typeCode;
                    }
                }
                else 
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$srw.System.SR.NotSupported_BinarySerializedResources);
                }
                /*int*/ let typeIndex = types.IndexOf(typeName);
                if (typeIndex === -1)
                {
                    typeIndex = types.Count;
                    types.Add(typeName);
                }
                return (typeIndex + 64/*ResourceTypeCode.StartOfUserTypes*/);
            }
            static /*void */ WriteValue(/*ResourceTypeCode*/ typeCode, /*object?*/ value, /*BinaryWriter*/ writer)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(writer !== null, "writer != null");
                switch(typeCode)
                {
                    case 0/*ResourceTypeCode.Null*/:
                    break;
                    case 1/*ResourceTypeCode.String*/:
                    writer.Write$18($.$cast(value, $.$spc.System.String));
                    break;
                    case 2/*ResourceTypeCode.Boolean*/:
                    writer.Write($.$cast(value, $.$spc.System.Boolean));
                    break;
                    case 3/*ResourceTypeCode.Char*/:
                    writer.Write$11($.$cast(value, $.$spc.System.Char));
                    break;
                    case 4/*ResourceTypeCode.Byte*/:
                    writer.Write$1($.$cast(value, $.$spc.System.Byte));
                    break;
                    case 5/*ResourceTypeCode.SByte*/:
                    writer.Write$2($.$cast(value, $.$spc.System.SByte));
                    break;
                    case 6/*ResourceTypeCode.Int16*/:
                    writer.Write$10($.$cast(value, $.$spc.System.Int16));
                    break;
                    case 7/*ResourceTypeCode.UInt16*/:
                    writer.Write$11($.$cast(value, $.$spc.System.UInt16));
                    break;
                    case 8/*ResourceTypeCode.Int32*/:
                    writer.Write$12($.$cast(value, $.$spc.System.Int32));
                    break;
                    case 9/*ResourceTypeCode.UInt32*/:
                    writer.Write$13($.$cast(value, $.$spc.System.UInt32));
                    break;
                    case 10/*ResourceTypeCode.Int64*/:
                    writer.Write$14($.$cast(value, $.$spc.System.Int64));
                    break;
                    case 11/*ResourceTypeCode.UInt64*/:
                    writer.Write$15($.$cast(value, $.$spc.System.UInt64));
                    break;
                    case 12/*ResourceTypeCode.Single*/:
                    writer.Write$16($.$cast(value, $.$spc.System.Single));
                    break;
                    case 13/*ResourceTypeCode.Double*/:
                    writer.Write$8($.$cast(value, $.$spc.System.Double));
                    break;
                    case 14/*ResourceTypeCode.Decimal*/:
                    writer.Write$9($.$cast(value, $.$spc.System.Decimal));
                    break;
                    case 15/*ResourceTypeCode.DateTime*/:
                    /*long*/ let data = ($.$cast(value, $.$spc.System.DateTime)).ToBinary();
                    writer.Write$14(data);
                    break;
                    case 16/*ResourceTypeCode.TimeSpan*/:
                    writer.Write$14(($.$cast(value, $.$spc.System.TimeSpan)).Ticks);
                    break;
                    case 32/*ResourceTypeCode.ByteArray*/:
                    {
                        /*byte[]*/ let bytes = $.$cast(value, $.$typeArray($.$spc.System.Byte));
                        writer.Write$12(bytes.length);
                        writer.Write$4(bytes, 0, bytes.length);
                        break;
                    }
                    case 33/*ResourceTypeCode.Stream*/:
                    {
                        /*StreamWrapper*/ let sw = $.$cast(value, $.$srw.System.Resources.ResourceWriter.StreamWrapper);
                        if ($.$spc.System.Type.op_Equality$1($.$spc.System.Object.GetType.call(sw.Stream), $.$spc.System.IO.MemoryStream.$type))
                        {
                            /*MemoryStream*/ let ms = $.$cast(sw.Stream, $.$spc.System.IO.MemoryStream);
                            if (ms.Length > BigInt(2147483647/*int.MaxValue*/))
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$10($.$srw.System.SR.ArgumentOutOfRange_StreamLength);
                            }
                            /*byte[]*/ let arr = ms.ToArray();
                            writer.Write$12(arr.length);
                            writer.Write$4(arr, 0, arr.length);
                        }
                        else 
                        {
                            /*Stream*/ let s = sw.Stream;
                            if (s.Length > BigInt(2147483647/*int.MaxValue*/))
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$10($.$srw.System.SR.ArgumentOutOfRange_StreamLength);
                            }
                            s.Position = 0n;
                            writer.Write$12($.$cast(s.Length, $.$spc.System.Int32));
                            /*byte[]*/ let buffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [4096], null);
                            /*int*/ let read;
                            while((read = s.Read(buffer, 0, buffer.length)) !== 0)
                            {
                                writer.Write$4(buffer, 0, read);
                            }
                            if (sw.CloseAfterWrite)
                            {
                                s.Close();
                            }
                        }
                        break;
                    }
                    default:
                    $.$spc.System.Diagnostics.Debug.Assert$2(typeCode >= 64/*ResourceTypeCode.StartOfUserTypes*/, `ResourceReader: Unsupported ResourceTypeCode in .resources file!  ${typeCode}`);
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$srw.System.SR.NotSupported_BinarySerializedResources);
                }
            }
            //Generated interface implemetation for System.Resources.IResourceWriter.AddResource(string, string?)
            System$Resources$IResourceWriter$AddResource()
            {
                return this.AddResource$1(...arguments);
            }
            //Generated interface implemetation for System.Resources.IResourceWriter.AddResource(string, object?)
            System$Resources$IResourceWriter$AddResource$1()
            {
                return this.AddResource$2(...arguments);
            }
            //Generated interface implemetation for System.Resources.IResourceWriter.AddResource(string, byte[]?)
            System$Resources$IResourceWriter$AddResource$2()
            {
                return this.AddResource$4(...arguments);
            }
            //Generated interface implemetation for System.Resources.IResourceWriter.Close()
            System$Resources$IResourceWriter$Close()
            {
                return this.Close(...arguments);
            }
            //Generated interface implemetation for System.Resources.IResourceWriter.Generate()
            System$Resources$IResourceWriter$Generate()
            {
                return this.Generate(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose$1(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ResourceReaderFullyQualifiedName = "System.Resources.ResourceReader, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089";
                }
                {
                    this.ResSetTypeName = "System.Resources.RuntimeResourceSet";
                }
            }
            static $h = 327626;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Func$$$($.$spc.System.Type, $.$spc.System.String).$h,"g":{"r":0,"d":0,"h":12885229514,"f":1},"s":{"r":0,"d":0,"h":17180196810,"f":1},"n":"TypeNameConverter","d":327626,"h":8590262218,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360065994,"f":34},"n":"ResourceReaderTypeName","d":327626,"h":30065098698,"f":34},{"p":1310721,"g":{"r":0,"d":0,"h":42950000586,"f":34},"n":"ResourceSetTypeName","d":327626,"h":38655033290,"f":34}],"m":[{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":62128129}],"n":"AddResource","d":327626,"h":21475164106,"f":1},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"typeName","p":1310721},{"n":"serializedData","p":0}],"n":"AddResourceData","d":327626,"h":25770131402,"f":1},{"r":65537,"p":[{"n":"writer","p":58458113},{"n":"dataContext","p":131073}],"n":"WriteData","d":327626,"h":47244967882,"f":34},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":1310721}],"n":"AddResource","o":"@$1","d":327626,"h":94489608138,"f":1},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":131073}],"n":"AddResource","o":"@$2","d":327626,"h":98784575434,"f":1},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":62128129},{"n":"closeAfterWrite","p":262145,"f":65,"v":false}],"n":"AddResource","o":"@$3","d":327626,"h":103079542730,"f":1},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":62128129},{"n":"closeAfterWrite","p":262145}],"n":"AddResourceInternal","d":327626,"h":107374510026,"f":2},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":0}],"n":"AddResource","o":"@$4","d":327626,"h":111669477322,"f":1},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"typeName","p":1310721},{"n":"data","p":131073}],"n":"AddResourceData","o":"@$1","d":327626,"h":115964444618,"f":2},{"r":65537,"n":"Close","d":327626,"h":128849346506,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":327626,"h":133144313802,"f":2},{"r":65537,"n":"Dispose","o":"@$1","d":327626,"h":137439281098,"f":1},{"r":65537,"n":"Generate","d":327626,"h":141734248394,"f":1},{"r":262090,"p":[{"n":"value","p":131073},{"n":"types","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.String).$h}],"n":"FindTypeCode","d":327626,"h":146029215690,"f":34},{"r":65537,"p":[{"n":"typeCode","p":262090},{"n":"value","p":131073},{"n":"writer","p":58458113}],"n":"WriteValue","d":327626,"h":150324182986,"f":34}],"l":[{"t":655361,"n":"AverageNameSize","d":327626,"h":51539935178,"f":34},{"t":1310721,"n":"ResourceReaderFullyQualifiedName","d":327626,"h":55834902474,"f":40},{"t":1310721,"n":"ResSetTypeName","d":327626,"h":60129869770,"f":34},{"t":655361,"n":"ResSetVersion","d":327626,"h":64424837066,"f":34},{"t":$.$sc.System.Collections.Generic.SortedDictionary$$$($.$spc.System.String, $.$spc.System.Object).$h,"n":"_resourceList","d":327626,"h":68719804362,"f":2},{"t":62128129,"n":"_output","d":327626,"h":73014771658,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Object).$h,"n":"_caseInsensitiveDups","d":327626,"h":77309738954,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$srw.System.Resources.ResourceWriter.PrecannedResource).$h,"n":"_preserializedData","d":327626,"h":81604706250,"f":2}],"c":[{"p":[{"n":"fileName","p":1310721}],"n":".ctor","o":"$ctor$1","d":327626,"h":85899673546,"f":1},{"p":[{"n":"stream","p":62128129}],"n":".ctor","o":"$ctor$2","d":327626,"h":90194640842,"f":1}],"i":[196554,57475073],"j":[393162,458698],"h":327626}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$srw.System.Resources.IResourceWriter, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Resources.ResourceWriter`; }
        });
        
        $asm.$str("$srw.System.Resources.ResourceTypeCode", ($self) => class ResourceTypeCode extends $.$spc.System.Enum
        {
            static Null = 0;
            static String = 1;
            static Boolean = 2;
            static Char = 3;
            static Byte = 4;
            static SByte = 5;
            static Int16 = 6;
            static UInt16 = 7;
            static Int32 = 8;
            static UInt32 = 9;
            static Int64 = 10;
            static UInt64 = 11;
            static Single = 12;
            static Double = 13;
            static Decimal = 14;
            static DateTime = 15;
            static TimeSpan = 16;
            static LastPrimitive = 16;
            static ByteArray = 32;
            static Stream = 33;
            static StartOfUserTypes = 64;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Null": 0n,
                    "String": 1n,
                    "Boolean": 2n,
                    "Char": 3n,
                    "Byte": 4n,
                    "SByte": 5n,
                    "Int16": 6n,
                    "UInt16": 7n,
                    "Int32": 8n,
                    "UInt32": 9n,
                    "Int64": 10n,
                    "UInt64": 11n,
                    "Single": 12n,
                    "Double": 13n,
                    "Decimal": 14n,
                    "DateTime": 15n,
                    "TimeSpan": 16n,
                    "LastPrimitive": 16n,
                    "ByteArray": 32n,
                    "Stream": 33n,
                    "StartOfUserTypes": 64n
                };
            }
            static $h = 262090;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":262090,"n":"Null","d":262090,"h":4295229386,"f":33},{"t":262090,"n":"String","d":262090,"h":8590196682,"f":33},{"t":262090,"n":"Boolean","d":262090,"h":12885163978,"f":33},{"t":262090,"n":"Char","d":262090,"h":17180131274,"f":33},{"t":262090,"n":"Byte","d":262090,"h":21475098570,"f":33},{"t":262090,"n":"SByte","d":262090,"h":25770065866,"f":33},{"t":262090,"n":"Int16","d":262090,"h":30065033162,"f":33},{"t":262090,"n":"UInt16","d":262090,"h":34360000458,"f":33},{"t":262090,"n":"Int32","d":262090,"h":38654967754,"f":33},{"t":262090,"n":"UInt32","d":262090,"h":42949935050,"f":33},{"t":262090,"n":"Int64","d":262090,"h":47244902346,"f":33},{"t":262090,"n":"UInt64","d":262090,"h":51539869642,"f":33},{"t":262090,"n":"Single","d":262090,"h":55834836938,"f":33},{"t":262090,"n":"Double","d":262090,"h":60129804234,"f":33},{"t":262090,"n":"Decimal","d":262090,"h":64424771530,"f":33},{"t":262090,"n":"DateTime","d":262090,"h":68719738826,"f":33},{"t":262090,"n":"TimeSpan","d":262090,"h":73014706122,"f":33},{"t":262090,"n":"LastPrimitive","d":262090,"h":77309673418,"f":33},{"t":262090,"n":"ByteArray","d":262090,"h":81604640714,"f":33},{"t":262090,"n":"Stream","d":262090,"h":85899608010,"f":33},{"t":262090,"n":"StartOfUserTypes","d":262090,"h":90194575306,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":262090,"h":94489542602,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":262090}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Resources.ResourceTypeCode`; }
        });
        
        $asm.$cls("$srw.System.Resources.FastResourceComparer", ($self) => class FastResourceComparer extends $.$spc.System.Object
        {
            /*FastResourceComparer*/ static Default = null;
            /*int */ GetHashCode$1(/*string*/ key)
            {
                return $.$srw.System.Resources.FastResourceComparer.HashFunction(key);
            }
            static /*int */ HashFunction(/*string*/ key)
            {
                /*uint*/ let hash = 5381;
                for(/*int*/ let i = 0; i < key.length; i++)
                {
                    hash = ((((hash << 5) >>> 0) + hash) >>> 0) ^ $.$spc.System.String.get_Chars.call(key, i);
                }
                return (hash | 0);
            }
            /*int */ Compare(/*string?*/ a, /*string?*/ b)
            {
                return $.$spc.System.String.CompareOrdinal(a, b);
            }
            /*bool */ Equals$2(/*string?*/ a, /*string?*/ b)
            {
                return $.$spc.System.String.Equals$4(a, b);
            }
            //Generated interface implemetation for System.Collections.Generic.IComparer<string>.Compare(string?, string?)
            System$Collections$Generic$IComparer$$$Compare()
            {
                return this.Compare(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<string>.Equals(string?, string?)
            System$Collections$Generic$IEqualityComparer$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<string>.GetHashCode(string)
            System$Collections$Generic$IEqualityComparer$$$GetHashCode()
            {
                return this.GetHashCode$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$srw.System.Resources.FastResourceComparer().$ctor$1();
                }
            }
            static $h = 131018;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"key","p":1310721}],"n":"GetHashCode","o":"@$1","d":131018,"h":8590065610,"f":1},{"r":655361,"p":[{"n":"key","p":1310721}],"n":"HashFunction","d":131018,"h":12885032906,"f":40},{"r":655361,"p":[{"n":"a","p":1310721},{"n":"b","p":1310721}],"n":"Compare","d":131018,"h":17180000202,"f":1},{"r":262145,"p":[{"n":"a","p":1310721},{"n":"b","p":1310721}],"n":"Equals","o":"@$2","d":131018,"h":21474967498,"f":1}],"l":[{"t":131018,"n":"Default","d":131018,"h":4295098314,"f":40}],"c":[{"n":".ctor","o":"$ctor$1","d":131018,"h":25769934794,"f":1}],"i":[$.$spc.System.Collections.Generic.IComparer$$($.$spc.System.String).$h,$.$spc.System.Collections.Generic.IEqualityComparer$$($.$spc.System.String).$h],"h":131018}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IComparer$$($.$spc.System.String), $.$spc.System.Collections.Generic.IEqualityComparer$$($.$spc.System.String) ]; }
            static get $fullName() { return `System.Resources.FastResourceComparer`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime"))