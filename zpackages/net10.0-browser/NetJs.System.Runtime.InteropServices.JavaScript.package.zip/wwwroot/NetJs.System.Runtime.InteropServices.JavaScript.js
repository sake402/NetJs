
//--TRIMMABLE-BOUNDARY-START(11)
(async function () {
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sttp, $stc) {
    "use strict";
    let _;
    let $mSGVdi;
    let $GpsVta;
    let $pTeAnd;
    let $PklaRk;
    let $KwCNfa;
    let $hsLGmf;
    let $zUWcef;
    let $zchwcc;
    let $IiwDTc;
    let $eRYFKb;
    let $vhxGue;
    let $DvEaoe;
    let $vQEWWh;
    let $cFCYoa;
    let $zwvlIj;
    let $TWlmyd;
    let $RqJNrf;
    let $ZpFaBc;
    let $cibnUd;
    
    
    
	$.$asm(
    "NetJs.System.Runtime.InteropServices.JavaScript", 
    {
  "h": 11,
  "f": "System.Runtime.InteropServices.JavaScript",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Runtime.InteropServices.JavaScript",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Runtime.InteropServices.JavaScript",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2359307)
        $asm.$cls(`$srij.SRIJ.JSType`, ($self) => class JSType extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297326603)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297326603);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297326603)
            
            //--TRIMMABLE-BOUNDARY-START(3604491)
            static $_Void;
            static get Void()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3604491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return $cls.$_Void ??= $asm.$ncls(`$srij.SRIJ.JSType.Void`, ($self) => class Void extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298571787)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298571787);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298571787)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298571787)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298571787)
                    
                    static $h = 3604491;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298571787),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3604491,
      "h": 4298571787,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298571787)
  ],
  "d": 2359307,
  "h": 3604491
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Void`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Void`; }
                }, $cls, ($v) => $cls.$_Void = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3604491)
            
            //--TRIMMABLE-BOUNDARY-START(2752523)
            static $_Discard;
            static get Discard()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2752523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return $cls.$_Discard ??= $asm.$ncls(`$srij.SRIJ.JSType.Discard`, ($self) => class Discard extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297719819)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297719819);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297719819)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297719819)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297719819)
                    
                    static $h = 2752523;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297719819),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2752523,
      "h": 4297719819,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297719819)
  ],
  "d": 2359307,
  "h": 2752523
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Discard`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Discard`; }
                }, $cls, ($v) => $cls.$_Discard = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2752523)
            
            //--TRIMMABLE-BOUNDARY-START(2818059)
            static $_DiscardNoWait;
            static get DiscardNoWait()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2818059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return $cls.$_DiscardNoWait ??= $asm.$ncls(`$srij.SRIJ.JSType.DiscardNoWait`, ($self) => class DiscardNoWait extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297785355)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297785355);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297785355)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297785355)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297785355)
                    
                    static $h = 2818059;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297785355),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2818059,
      "h": 4297785355,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297785355)
  ],
  "d": 2359307,
  "h": 2818059
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+DiscardNoWait`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}DiscardNoWait`; }
                }, $cls, ($v) => $cls.$_DiscardNoWait = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2818059)
            
            //--TRIMMABLE-BOUNDARY-START(2621451)
            static $_Boolean;
            static get Boolean()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2621451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return $cls.$_Boolean ??= $asm.$ncls(`$srij.SRIJ.JSType.Boolean`, ($self) => class Boolean extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297588747)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297588747);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297588747)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297588747)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297588747)
                    
                    static $h = 2621451;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297588747),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2621451,
      "h": 4297588747,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297588747)
  ],
  "d": 2359307,
  "h": 2621451
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Boolean`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Boolean`; }
                }, $cls, ($v) => $cls.$_Boolean = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2621451)
            
            //--TRIMMABLE-BOUNDARY-START(3342347)
            static $_Number;
            static get Number()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3342347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return $cls.$_Number ??= $asm.$ncls(`$srij.SRIJ.JSType.Number`, ($self) => class Number extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298309643)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298309643);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298309643)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298309643)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298309643)
                    
                    static $h = 3342347;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298309643),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3342347,
      "h": 4298309643,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298309643)
  ],
  "d": 2359307,
  "h": 3342347
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Number`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Number`; }
                }, $cls, ($v) => $cls.$_Number = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3342347)
            
            //--TRIMMABLE-BOUNDARY-START(2555915)
            static $_BigInt;
            static get BigInt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2555915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return $cls.$_BigInt ??= $asm.$ncls(`$srij.SRIJ.JSType.BigInt`, ($self) => class BigInt extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297523211)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297523211);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297523211)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297523211)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297523211)
                    
                    static $h = 2555915;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297523211),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2555915,
      "h": 4297523211,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297523211)
  ],
  "d": 2359307,
  "h": 2555915
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+BigInt`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}BigInt`; }
                }, $cls, ($v) => $cls.$_BigInt = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2555915)
            
            //--TRIMMABLE-BOUNDARY-START(2686987)
            static $_Date;
            static get Date()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2686987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return $cls.$_Date ??= $asm.$ncls(`$srij.SRIJ.JSType.Date`, ($self) => class Date extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297654283)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297654283);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297654283)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297654283)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297654283)
                    
                    static $h = 2686987;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297654283),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2686987,
      "h": 4297654283,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297654283)
  ],
  "d": 2359307,
  "h": 2686987
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Date`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Date`; }
                }, $cls, ($v) => $cls.$_Date = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2686987)
            
            //--TRIMMABLE-BOUNDARY-START(3538955)
            static $_String;
            static get String()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3538955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return $cls.$_String ??= $asm.$ncls(`$srij.SRIJ.JSType.String`, ($self) => class String extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298506251)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298506251);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298506251)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298506251)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298506251)
                    
                    static $h = 3538955;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298506251),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3538955,
      "h": 4298506251,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298506251)
  ],
  "d": 2359307,
  "h": 3538955
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+String`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}String`; }
                }, $cls, ($v) => $cls.$_String = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3538955)
            
            //--TRIMMABLE-BOUNDARY-START(3407883)
            static $_Object;
            static get Object()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3407883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return $cls.$_Object ??= $asm.$ncls(`$srij.SRIJ.JSType.Object`, ($self) => class Object extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298375179)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298375179);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298375179)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298375179)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298375179)
                    
                    static $h = 3407883;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298375179),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3407883,
      "h": 4298375179,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298375179)
  ],
  "d": 2359307,
  "h": 3407883
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Object`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Object`; }
                }, $cls, ($v) => $cls.$_Object = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3407883)
            
            //--TRIMMABLE-BOUNDARY-START(2883595)
            static $_Error;
            static get Error()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2883595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return $cls.$_Error ??= $asm.$ncls(`$srij.SRIJ.JSType.Error`, ($self) => class Error extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297850891)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297850891);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297850891)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297850891)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297850891)
                    
                    static $h = 2883595;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297850891),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2883595,
      "h": 4297850891,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297850891)
  ],
  "d": 2359307,
  "h": 2883595
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Error`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Error`; }
                }, $cls, ($v) => $cls.$_Error = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2883595)
            
            //--TRIMMABLE-BOUNDARY-START(3276811)
            static $_MemoryView;
            static get MemoryView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3276811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return $cls.$_MemoryView ??= $asm.$ncls(`$srij.SRIJ.JSType.MemoryView`, ($self) => class MemoryView extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298244107)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298244107);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298244107)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298244107)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298244107)
                    
                    static $h = 3276811;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298244107),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3276811,
      "h": 4298244107,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298244107)
  ],
  "d": 2359307,
  "h": 3276811
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+MemoryView`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}MemoryView`; }
                }, $cls, ($v) => $cls.$_MemoryView = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3276811)
            
            //--TRIMMABLE-BOUNDARY-START(2490379)
            static $_Array$$;
            static Array$$(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2490379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return ($cls.$_Array$$ ??= $asm.$ncls(`$srij.SRIJ.JSType.Array<>`, (T) => $asm.$gt(`$srij.SRIJ.JSType.Array<>`, [T], ($self) => class Array$$ extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297457675)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297457675);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297457675)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297457675)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297457675)
                    
                    static $H = 2490379;
                    static $h = 2490379;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297457675),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4297457675,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297457675)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "c": [2359307
      ]
    }
  ],
  "r": 1,
  "d": 2359307,
  "H": 2490379,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Array<${T?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Array$${T?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_Array$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(2490379)
            
            //--TRIMMABLE-BOUNDARY-START(3473419)
            static $_Promise$$;
            static Promise$$(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3473419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return ($cls.$_Promise$$ ??= $asm.$ncls(`$srij.SRIJ.JSType.Promise<>`, (T) => $asm.$gt(`$srij.SRIJ.JSType.Promise<>`, [T], ($self) => class Promise$$ extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298440715)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298440715);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298440715)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298440715)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298440715)
                    
                    static $H = 3473419;
                    static $h = 3473419;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298440715),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4298440715,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298440715)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "c": [2359307
      ]
    }
  ],
  "r": 1,
  "d": 2359307,
  "H": 3473419,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Promise<${T?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Promise$${T?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_Promise$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(3473419)
            
            //--TRIMMABLE-BOUNDARY-START(2949131)
            static $_Function;
            static get Function()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2949131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return $cls.$_Function ??= $asm.$ncls(`$srij.SRIJ.JSType.Function`, ($self) => class Function extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297916427)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297916427);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297916427)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297916427)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297916427)
                    
                    static $h = 2949131;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297916427),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2949131,
      "h": 4297916427,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297916427)
  ],
  "d": 2359307,
  "h": 2949131
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Function`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Function`; }
                }, $cls, ($v) => $cls.$_Function = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2949131)
            
            //--TRIMMABLE-BOUNDARY-START(3211275)
            static $_Function$$;
            static Function$$(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3211275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return ($cls.$_Function$$ ??= $asm.$ncls(`$srij.SRIJ.JSType.Function<>`, (T) => $asm.$gt(`$srij.SRIJ.JSType.Function<>`, [T], ($self) => class Function$$ extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298178571)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298178571);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298178571)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298178571)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298178571)
                    
                    static $H = 3211275;
                    static $h = 3211275;
                    static $g = 1;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298178571),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4298178571,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298178571)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "c": [2359307
      ]
    }
  ],
  "r": 1,
  "d": 2359307,
  "H": 3211275,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Function<${T?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Function$${T?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_Function$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(3211275)
            
            //--TRIMMABLE-BOUNDARY-START(3145739)
            static $_Function$$$;
            static Function$$$(T1, T2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3145739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return ($cls.$_Function$$$ ??= $asm.$ncls(`$srij.SRIJ.JSType.Function<,>`, (T1, T2) => $asm.$gt(`$srij.SRIJ.JSType.Function<,>`, [T1, T2], ($self) => class Function$$$ extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298113035)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298113035);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298113035)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298113035)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298113035)
                    
                    static $H = 3145739;
                    static $h = 3145739;
                    static $g = 2;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298113035),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4298113035,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298113035)
  ],
  "s": [
    {
      "h": T1?.$h??1572864,
      "n": "T1",
      "c": [2359307
      ]
    },
    {
      "h": T2?.$h??1638400,
      "n": "T2",
      "c": [2359307
      ]
    }
  ],
  "r": 2,
  "d": 2359307,
  "H": 3145739,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Function<${T1?.$fullName},${T2?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Function$${T1?.$getFullName(separator)}$${T2?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_Function$$$ = $v))(T1, T2);
            }
            //--TRIMMABLE-BOUNDARY-END(3145739)
            
            //--TRIMMABLE-BOUNDARY-START(3080203)
            static $_Function$$$$;
            static Function$$$$(T1, T2, T3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3080203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return ($cls.$_Function$$$$ ??= $asm.$ncls(`$srij.SRIJ.JSType.Function<,,>`, (T1, T2, T3) => $asm.$gt(`$srij.SRIJ.JSType.Function<,,>`, [T1, T2, T3], ($self) => class Function$$$$ extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4298047499)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298047499);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298047499)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298047499)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298047499)
                    
                    static $H = 3080203;
                    static $h = 3080203;
                    static $g = 3;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298047499),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4298047499,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4298047499)
  ],
  "s": [
    {
      "h": T1?.$h??1572864,
      "n": "T1",
      "c": [2359307
      ]
    },
    {
      "h": T2?.$h??1638400,
      "n": "T2",
      "c": [2359307
      ]
    },
    {
      "h": T3?.$h??1703936,
      "n": "T3",
      "c": [2359307
      ]
    }
  ],
  "r": 3,
  "d": 2359307,
  "H": 3080203,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Function<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Function$${T1?.$getFullName(separator)}$${T2?.$getFullName(separator)}$${T3?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_Function$$$$ = $v))(T1, T2, T3);
            }
            //--TRIMMABLE-BOUNDARY-END(3080203)
            
            //--TRIMMABLE-BOUNDARY-START(3014667)
            static $_Function$$$$$;
            static Function$$$$$(T1, T2, T3, T4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3014667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return ($cls.$_Function$$$$$ ??= $asm.$ncls(`$srij.SRIJ.JSType.Function<,,,>`, (T1, T2, T3, T4) => $asm.$gt(`$srij.SRIJ.JSType.Function<,,,>`, [T1, T2, T3, T4], ($self) => class Function$$$$$ extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297981963)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297981963);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297981963)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297981963)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297981963)
                    
                    static $H = 3014667;
                    static $h = 3014667;
                    static $g = 4;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297981963),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4297981963,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297981963)
  ],
  "s": [
    {
      "h": T1?.$h??1572864,
      "n": "T1",
      "c": [2359307
      ]
    },
    {
      "h": T2?.$h??1638400,
      "n": "T2",
      "c": [2359307
      ]
    },
    {
      "h": T3?.$h??1703936,
      "n": "T3",
      "c": [2359307
      ]
    },
    {
      "h": T4?.$h??1769472,
      "n": "T4",
      "c": [2359307
      ]
    }
  ],
  "r": 4,
  "d": 2359307,
  "H": 3014667,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Function<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${T4?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Function$${T1?.$getFullName(separator)}$${T2?.$getFullName(separator)}$${T3?.$getFullName(separator)}$${T4?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_Function$$$$$ = $v))(T1, T2, T3, T4);
            }
            //--TRIMMABLE-BOUNDARY-END(3014667)
            
            //--TRIMMABLE-BOUNDARY-START(2424843)
            static $_Any;
            static get Any()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2424843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSType;
                return $cls.$_Any ??= $asm.$ncls(`$srij.SRIJ.JSType.Any`, ($self) => class Any extends $.$srij.SRIJ.JSType
                {
                    //--TRIMMABLE-BOUNDARY-START(4297392139)
                    $ctor$2()
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297392139);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297392139)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297392139)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297392139)
                    
                    static $h = 2424843;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$srij.SRIJ.JSType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297392139),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2424843,
      "h": 4297392139,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297392139)
  ],
  "d": 2359307,
  "h": 2424843
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType+Any`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType${separator}Any`; }
                }, $cls, ($v) => $cls.$_Any = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2424843)
            
            //--TRIMMABLE-BOUNDARY-START(4297326603)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297326603)
            
            static $h = 2359307;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297326603),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2359307,
      "h": 4297326603,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297326603)
  ],
  "h": 2359307,
  "a": [
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$srij.SRIJ.JSType.Void, $.$srij.SRIJ.JSType.Discard, $.$srij.SRIJ.JSType.DiscardNoWait, $.$srij.SRIJ.JSType.Boolean, $.$srij.SRIJ.JSType.Number, $.$srij.SRIJ.JSType.BigInt, $.$srij.SRIJ.JSType.Date, $.$srij.SRIJ.JSType.String, $.$srij.SRIJ.JSType.Object, $.$srij.SRIJ.JSType.Error, $.$srij.SRIJ.JSType.MemoryView, $.$srij.SRIJ.JSType.Array$$(T), $.$srij.SRIJ.JSType.Promise$$(T), $.$srij.SRIJ.JSType.Function, $.$srij.SRIJ.JSType.Function$$(T), $.$srij.SRIJ.JSType.Function$$$(T1, T2), $.$srij.SRIJ.JSType.Function$$$$(T1, T2, T3), $.$srij.SRIJ.JSType.Function$$$$$(T1, T2, T3, T4), $.$srij.SRIJ.JSType.Any ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359307)
        
        

        //--TRIMMABLE-BOUNDARY-START(65547)
        $asm.$cls(`$srij.Interop`, ($self) => class Interop
        {
            //--TRIMMABLE-BOUNDARY-START(131083)
            static $_Runtime;
            static get Runtime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(131083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.Interop;
                return $cls.$_Runtime ??= $asm.$ncls(`$srij.Interop.Runtime`, ($self) => class Runtime
                {
                    //--TRIMMABLE-BOUNDARY-START(42949804043)
                    static /*void */ ReleaseCSOwnedObject(/*nint*/ jsHandle)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42949804043);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(42949804043)
                    
                    static $h = 131083;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(42949804043),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsHandle",
          "p": 786433
        }
      ],
      "n": "ReleaseCSOwnedObject",
      "d": 131083,
      "h": 42949804043,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42949804043)
  ],
  "d": 65547,
  "h": 131083
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Interop+Runtime`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Interop${separator}Runtime`; }
                }, $cls, ($v) => $cls.$_Runtime = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(131083)
            
            static $h = 65547;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 65547
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$srij.Interop.Runtime ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Interop`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Interop`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65547)
        
        

        //--TRIMMABLE-BOUNDARY-START(196619)
        $asm.$cls(`$srij.SRIJ.CancelablePromise`, ($self) => class CancelablePromise
        {
            //--TRIMMABLE-BOUNDARY-START(4295163915)
            static /*void */ CancelPromise(/*Task*/ promise)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295163915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (promise.IsCompleted)
                {
                    return;
                }
                /*JSHostImplementation.PromiseHolder?*/ let holder = $.$as(promise.AsyncState, $.$srij.SRIJ.JSHostImplementation.PromiseHolder);
                if (holder === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Expected Task converted from JS Promise");
                }
                if (holder.IsDisposed)
                {
                    return;
                }
                $.$srij.Interop.Runtime.CancelPromise(holder.GCHandle);
            }
            //--TRIMMABLE-BOUNDARY-END(4295163915)
            
            static $h = 196619;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295163915),
    {
      "r": 65537,
      "p": [
        {
          "n": "promise",
          "p": 178454529
        }
      ],
      "n": "CancelPromise",
      "d": 196619,
      "h": 4295163915,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295163915)
  ],
  "h": 196619
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.CancelablePromise`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}CancelablePromise`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196619)
        
        

        //--TRIMMABLE-BOUNDARY-START(786443)
        $asm.$cls(`$srij.SRIJ.JSHostImplementation`, ($self) => class JSHostImplementation
        {
            //--TRIMMABLE-BOUNDARY-START(1114123)
            static $_ToManagedCallback;
            static get ToManagedCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1114123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSHostImplementation;
                return $cls.$_ToManagedCallback ??= $asm.$ncls(`$srij.SRIJ.JSHostImplementation.ToManagedCallback`, ($self) => class ToManagedCallback extends $.$$.S.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arguments_buffer)
                    {
                        return this.$nativeFunction.call(this.$target, arguments_buffer);
                    }
                    static $h = 1114123;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180983307),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "Invoke",
      "d": 1114123,
      "h": 17180983307,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180983307),
//--TRIMMABLE-BOUNDARY-START(8591048715),
    {
      "r": 90570753,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 1114123,
      "h": 8591048715,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591048715),
//--TRIMMABLE-BOUNDARY-START(12886016011),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 1114123,
      "h": 12886016011,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886016011)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081419),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1114123,
      "h": 4296081419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296081419)
  ],
  "d": 786443,
  "h": 1114123
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSHostImplementation+ToManagedCallback`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSHostImplementation${separator}ToManagedCallback`; }
                }, $cls, ($v) => $cls.$_ToManagedCallback = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1114123)
            
            //--TRIMMABLE-BOUNDARY-START(983051)
            static $_PromiseHolder;
            static get PromiseHolder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(983051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSHostImplementation;
                return $cls.$_PromiseHolder ??= $asm.$ncls(`$srij.SRIJ.JSHostImplementation.PromiseHolder`, ($self) => class PromiseHolder extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(21475819531)
                    /*bool*/ IsDisposed = false;
                    //--TRIMMABLE-BOUNDARY-END(21475819531)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180852235)
                    /*nint*/ GCHandle = 0;
                    //--TRIMMABLE-BOUNDARY-END(17180852235)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885884939)
                    /*ToManagedCallback?*/ Callback = null;
                    //--TRIMMABLE-BOUNDARY-END(12885884939)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770786827)
                    /*JSProxyContext*/ ProxyContext = null;
                    //--TRIMMABLE-BOUNDARY-END(25770786827)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590917643)
                    $ctor$2(/*JSProxyContext*/ targetContext)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590917643);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.GCHandle = $.$$.SRI.GCHandle.op_Explicit($.$$.SRI.GCHandle.Alloc(this, 2/*GCHandleType.Normal*/));
                            this.ProxyContext = targetContext;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590917643)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295950347)
                    $ctor$1(/*JSProxyContext*/ targetContext, /*nint*/ gcvHandle)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295950347);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.GCHandle = gcvHandle;
                            this.ProxyContext = targetContext;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295950347)
                    
                    static $h = 983051;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475819531),
    {
      "t": 262145,
      "n": "IsDisposed",
      "d": 983051,
      "h": 21475819531,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(21475819531),
//--TRIMMABLE-BOUNDARY-START(17180852235),
    {
      "t": 786433,
      "n": "GCHandle",
      "d": 983051,
      "h": 17180852235,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17180852235),
//--TRIMMABLE-BOUNDARY-START(12885884939),
    {
      "t": 1114123,
      "n": "Callback",
      "d": 983051,
      "h": 12885884939,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12885884939),
//--TRIMMABLE-BOUNDARY-START(25770786827),
    {
      "t": 2293771,
      "n": "ProxyContext",
      "d": 983051,
      "h": 25770786827,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(25770786827)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917643),
    {
      "p": [
        {
          "n": "targetContext",
          "p": 2293771
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983051,
      "h": 8590917643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590917643),
//--TRIMMABLE-BOUNDARY-START(4295950347),
    {
      "p": [
        {
          "n": "targetContext",
          "p": 2293771
        },
        {
          "n": "gcvHandle",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983051,
      "h": 4295950347,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950347)
  ],
  "d": 786443,
  "h": 983051
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSHostImplementation+PromiseHolder`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSHostImplementation${separator}PromiseHolder`; }
                }, $cls, ($v) => $cls.$_PromiseHolder = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(983051)
            
            //--TRIMMABLE-BOUNDARY-START(1048587)
            static $_PromiseHolderState;
            static get PromiseHolderState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1048587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSHostImplementation;
                return $cls.$_PromiseHolderState ??= $asm.$nstr(`$srij.SRIJ.JSHostImplementation.PromiseHolderState`, ($self) => class PromiseHolderState extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(8590983179)
                    /*int*/  get IsResolving() { return this.$getField(0, $.$$.S.Int32); }
                    /*int*/  set IsResolving(value) { this.$setField(0, $.$$.S.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590983179)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296015883)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296015883);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296015883)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296015883)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296015883)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.IsResolving = this.IsResolving;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590983179)
                        this.IsResolving = 0;
                        //--TRIMMABLE-BOUNDARY-END(8590983179)
                        
                    }
                    static $h = 1048587;
                    static $z = 4;
                    static $f = 0b10100010000001010000001;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590983179),
    {
      "t": 655361,
      "n": "IsResolving",
      "d": 1048587,
      "h": 8590983179,
      "f": 4194305,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590983179)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015883),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048587,
      "h": 4296015883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015883)
  ],
  "d": 786443,
  "h": 1048587,
  "a": [
    {
      "t": 148176897,
      "c": 13033078785,
      "a": [
        {
          "v": 2,
          "t": 143654913
        }
      ]
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSHostImplementation+PromiseHolderState`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSHostImplementation${separator}PromiseHolderState`; }
                }, $cls, ($v) => $cls.$_PromiseHolderState = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1048587)
            
            //--TRIMMABLE-BOUNDARY-START(851979)
            static $_IntPtrAndHandle;
            static get IntPtrAndHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(851979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSHostImplementation;
                return $cls.$_IntPtrAndHandle ??= $asm.$nstr(`$srij.SRIJ.JSHostImplementation.IntPtrAndHandle`, ($self) => class IntPtrAndHandle extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12885753867)
                    /*IntPtr*/  get ptr() { return this.$getField(0, $.$$.S.IntPtr); }
                    /*IntPtr*/  set ptr(value) { this.$setField(0, $.$$.S.IntPtr, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885753867)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590786571)
                    /*RuntimeMethodHandle*/  get methodHandle() { return this.$getField(0, $.$$.S.RuntimeMethodHandle); }
                    /*RuntimeMethodHandle*/  set methodHandle(value) { this.$setField(0, $.$$.S.RuntimeMethodHandle, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590786571)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180721163)
                    /*RuntimeTypeHandle*/  get typeHandle() { return this.$getField(0, $.$$.S.RuntimeTypeHandle); }
                    /*RuntimeTypeHandle*/  set typeHandle(value) { this.$setField(0, $.$$.S.RuntimeTypeHandle, value); }
                    //--TRIMMABLE-BOUNDARY-END(17180721163)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295819275)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295819275);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295819275)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295819275)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295819275)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ptr = this.ptr;
                        copy.methodHandle = this.methodHandle.$clone();
                        copy.typeHandle = this.typeHandle.$clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(12885753867)
                        this.ptr = 0;
                        //--TRIMMABLE-BOUNDARY-END(12885753867)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590786571)
                        this.methodHandle = $.$default($.$$.S.RuntimeMethodHandle);
                        //--TRIMMABLE-BOUNDARY-END(8590786571)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180721163)
                        this.typeHandle = $.$default($.$$.S.RuntimeTypeHandle);
                        //--TRIMMABLE-BOUNDARY-END(17180721163)
                        
                    }
                    static $h = 851979;
                    static $z = 4;
                    static $f = 0b100010000001010000001;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885753867),
    {
      "t": 786433,
      "n": "ptr",
      "d": 851979,
      "h": 12885753867,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885753867),
//--TRIMMABLE-BOUNDARY-START(8590786571),
    {
      "t": 160497665,
      "n": "methodHandle",
      "d": 851979,
      "h": 8590786571,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590786571),
//--TRIMMABLE-BOUNDARY-START(17180721163),
    {
      "t": 160956417,
      "n": "typeHandle",
      "d": 851979,
      "h": 17180721163,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180721163)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819275),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 851979,
      "h": 4295819275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819275)
  ],
  "d": 786443,
  "h": 851979,
  "a": [
    {
      "t": 148176897,
      "c": 13033078785,
      "a": [
        {
          "v": 2,
          "t": 143654913
        }
      ]
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSHostImplementation+IntPtrAndHandle`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSHostImplementation${separator}IntPtrAndHandle`; }
                }, $cls, ($v) => $cls.$_IntPtrAndHandle = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(851979)
            
            //--TRIMMABLE-BOUNDARY-START(917515)
            static $_JSThreadBlockingMode;
            static get JSThreadBlockingMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(917515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSHostImplementation;
                return $cls.$_JSThreadBlockingMode ??= $asm.$nstr(`$srij.SRIJ.JSHostImplementation.JSThreadBlockingMode`, ($self) => class JSThreadBlockingMode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static PreventSynchronousJSExport = 0;
                    static ThrowWhenBlockingWait = 1;
                    static WarnWhenBlockingWait = 2;
                    static DangerousAllowBlockingWait = 100;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(917515);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "PreventSynchronousJSExport": 0n,
                            "ThrowWhenBlockingWait": 1n,
                            "WarnWhenBlockingWait": 2n,
                            "DangerousAllowBlockingWait": 100n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4295884811)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295884811);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295884811)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295884811)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295884811)
                    
                    static $h = 917515;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885819403),
    {
      "t": 917515,
      "n": "PreventSynchronousJSExport",
      "d": 917515,
      "h": 12885819403,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885819403),
//--TRIMMABLE-BOUNDARY-START(17180786699),
    {
      "t": 917515,
      "n": "ThrowWhenBlockingWait",
      "d": 917515,
      "h": 17180786699,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180786699),
//--TRIMMABLE-BOUNDARY-START(21475753995),
    {
      "t": 917515,
      "n": "WarnWhenBlockingWait",
      "d": 917515,
      "h": 21475753995,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475753995),
//--TRIMMABLE-BOUNDARY-START(8590852107),
    {
      "t": 917515,
      "n": "DangerousAllowBlockingWait",
      "d": 917515,
      "h": 8590852107,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590852107)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884811),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917515,
      "h": 4295884811,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295884811)
  ],
  "d": 786443,
  "h": 917515
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSHostImplementation+JSThreadBlockingMode`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSHostImplementation${separator}JSThreadBlockingMode`; }
                }, $cls, ($v) => $cls.$_JSThreadBlockingMode = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917515)
            
            //--TRIMMABLE-BOUNDARY-START(73015230475)
            /*string*/ static TaskGetResultName = null;
            //--TRIMMABLE-BOUNDARY-END(73015230475)
            
            //--TRIMMABLE-BOUNDARY-START(60130328587)
            /*MethodInfo?*/ static s_taskGetResultMethodInfo = null;
            //--TRIMMABLE-BOUNDARY-END(60130328587)
            
            //--TRIMMABLE-BOUNDARY-START(34360524811)
            static /*bool */ GetTaskResultDynamic(/*Task*/ task, /*out object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let type = $.$$.S.Object.GetType.call(task);
                if (type === $.$$.STT.Task.$type)
                {
                    value.$v = null;
                    return false;
                }
                /*MethodInfo*/ let method = $.$srij.SRIJ.JSHostImplementation.GetTaskResultMethodInfo(type);
                if ($.$$.SR.MethodInfo.op_Inequality$2(method, null))
                {
                    value.$v = method.Invoke(task, null);
                    return true;
                }
                throw new $.$$.S.InvalidOperationException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(34360524811)
            
            //--TRIMMABLE-BOUNDARY-START(38655492107)
            static /*MethodInfo */ GetTaskResultMethodInfo(/*Type*/ taskType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655492107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (taskType !== null)
                {
                    if ($.$$.SR.MethodInfo.op_Equality$2($.$srij.SRIJ.JSHostImplementation.s_taskGetResultMethodInfo, null))
                    {
                        $.$srij.SRIJ.JSHostImplementation.s_taskGetResultMethodInfo = $.$$.STT.Task$$().$type.GetMethod$12("get_Result"/*TaskGetResultName*/);
                    }
                    /*MethodInfo?*/ let getter = taskType.GetMethod$12("get_Result"/*TaskGetResultName*/);
                    if ($.$$.SR.MethodInfo.op_Inequality$2(getter, null) && getter.HasSameMetadataDefinitionAs($.$srij.SRIJ.JSHostImplementation.s_taskGetResultMethodInfo))
                    {
                        return getter;
                    }
                }
                throw new $.$$.S.InvalidOperationException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(38655492107)
            
            //--TRIMMABLE-BOUNDARY-START(77310197771)
            static /*void */ ThrowException(/*ref JSMarshalerArgument*/ arg)
            {
                /*Exception?*/ let ex;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310197771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                arg.$v.ToManaged$12($.$ref(() => ex, ($v) => ex = $v, $.$$.S.Exception));
                if (ex !== null)
                {
                    throw ex;
                }
                throw new $.$$.S.InvalidOperationException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(77310197771)
            
            //--TRIMMABLE-BOUNDARY-START(42950459403)
            static /*Task<JSObject> *//*async*/  ImportAsync(/*string*/ moduleName, /*string*/ moduleUrl, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$srij.SRIJ.JSObject), $.$srij.SRIJ.JSObject, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950459403);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*Task<JSObject>*/ let modulePromise = {};
                    /*var*/ let wrappedTask = $.$srij.SRIJ.JSHostImplementation.CancellationHelper(modulePromise, cancellationToken);
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t2 = wrappedTask.ConfigureAwait$3(1/*ConfigureAwaitOptions.ContinueOnCapturedContext*/ | 4/*ConfigureAwaitOptions.ForceYielding*/), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42950459403)
            
            //--TRIMMABLE-BOUNDARY-START(17180655627)
            static /*Task<JSObject> *//*async*/  CancellationHelper(/*Task<JSObject>*/ jsTask, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$srij.SRIJ.JSObject), $.$srij.SRIJ.JSObject, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180655627);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (jsTask.IsCompletedSuccessfully)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, jsTask.Result);
                    }
                    let receiveRegistration = null;
                    try
                    {
                        let $t3, $r3;
                        receiveRegistration = cancellationToken.Register$4(new ($.$$.S.Action$$($.$$.S.Object))().$ctor($.$srij.SRIJ.JSHostImplementation, /*static*/ (/**/ s) =>
                        {
                            $.$srij.SRIJ.CancelablePromise.CancelPromise($.$cast(s, $.$$.STT.Task$$($.$srij.SRIJ.JSObject)));
                        }, $mSGVdi ??= {"r":65537,"p":[{"n":"s","p":131073}],"n":"","d":786443,"h":0,"f":17825826}), jsTask);
                        return $.$$.N.AsyncResolver.Result($asnycContext, ($t3 = jsTask.ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))));
                    }
                    finally
                    {
                        receiveRegistration?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17180655627)
            
            //--TRIMMABLE-BOUNDARY-START(30065557515)
            static /*JSFunctionBinding */ GetMethodSignature(/*ReadOnlySpan<JSMarshalerType>*/ types, /*string?*/ functionName, /*string?*/ moduleName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065557515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let argsCount = ((types.Length - 1) | 0);
                /*int*/ let size = ((32/*JSFunctionBinding.JSBindingHeader.JSMarshalerSignatureHeaderSize*/ + ((((((argsCount + 2) | 0)) * 32) | 0))) | 0);
                /*int*/ let functionNameBytes = 0;
                /*int*/ let functionNameOffset = 0;
                if (functionName !== null)
                {
                    functionNameOffset = size;
                    size += 4;
                    functionNameBytes = ((functionName.length * 2) | 0);
                    size += functionNameBytes;
                }
                /*int*/ let moduleNameBytes = 0;
                /*int*/ let moduleNameOffset = 0;
                if (moduleName !== null)
                {
                    moduleNameOffset = size;
                    size += 4;
                    moduleNameBytes = ((moduleName.length * 2) | 0);
                    size += moduleNameBytes;
                }
                /*IntPtr*/ let buffer = $.$$.SRI.Marshal.AllocHGlobal(size);
                /*var*/ let signature = (() =>
                {
                    //new $.$srij.SRIJ.JSFunctionBinding()
                    const $t4 = $.$srij.SRIJ.JSFunctionBinding;
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.Header = $.$$.$interop.$addr2Ptr(buffer, null);
                    $i4.Sigs = $.$$.$interop.$addr2Ptr((((((buffer + 32/*JSFunctionBinding.JSBindingHeader.JSMarshalerSignatureHeaderSize*/) | 0) + (((2 * 32) | 0))) | 0)), null);
                    return $i4;
                })();
                signature.Version = 2;
                signature.ArgumentCount = argsCount;
                signature.Exception = $.$srij.SRIJ.JSMarshalerType.Exception._signatureType;
                signature.Result = types._reference.GetAt(0)._signatureType;
                signature.ImportHandle = ($.$srij.SRIJ.JSFunctionBinding.nextImportHandle++ | 0);
                signature.FunctionName = functionName;
                for(/*int*/ let i = 0; i < argsCount; i++)
                {
                    /*var*/ let type = signature.Sigs.SetAt(types._reference.GetAt(((i + 1) | 0))._signatureType, i);
                }
                signature.IsAsync = types._reference.GetAt(0)._signatureType.Type === 20/*MarshalerType.Task*/;
                signature.IsDiscardNoWait = types._reference.GetAt(0)._signatureType.Type === 26/*MarshalerType.DiscardNoWait*/;
                signature.Header.GetAt(0).ImportHandle = signature.ImportHandle;
                signature.Header.GetAt(0).FunctionNameLength = functionNameBytes;
                signature.Header.GetAt(0).FunctionNameOffset = functionNameOffset;
                signature.Header.GetAt(0).ModuleNameLength = moduleNameBytes;
                signature.Header.GetAt(0).ModuleNameOffset = moduleNameOffset;
                if (functionNameBytes !== 0)
                {
                    /*fixed*/ 
                    {
                        /*void**/ let fn = $.$$.S.String.GetPinnableReference.call(functionName);
                        $.$$.SRC.Unsafe.CopyBlock$1($.$$.$interop.$addr2Ptr(buffer, null).Add(functionNameOffset), fn, (functionNameBytes >>> 0));
                    }
                }
                if (moduleNameBytes !== 0)
                {
                    /*fixed*/ 
                    {
                        /*void**/ let mn = $.$$.S.String.GetPinnableReference.call(moduleName);
                        $.$$.SRC.Unsafe.CopyBlock$1($.$$.$interop.$addr2Ptr(buffer, null).Add(moduleNameOffset), mn, (moduleNameBytes >>> 0));
                    }
                }
                return signature;
            }
            //--TRIMMABLE-BOUNDARY-END(30065557515)
            
            //--TRIMMABLE-BOUNDARY-START(21475622923)
            static /*void */ FreeMethodSignatureBuffer(/*JSFunctionBinding*/ signature)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475622923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SRI.Marshal.FreeHGlobal($.$$.$interop.$ptr2Addr(signature.Header));
                signature.Header = null;
                signature.Sigs = null;
            }
            //--TRIMMABLE-BOUNDARY-END(21475622923)
            
            //--TRIMMABLE-BOUNDARY-START(47245426699)
            static /*void */ LoadLazyAssembly(/*byte[]*/ dllBytes, /*byte[]?*/ pdbBytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245426699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (pdbBytes === null)
                {
                    $.$$.SRL.AssemblyLoadContext.Default.LoadFromStream$1(new $.$$.SI.MemoryStream().$ctor$8(dllBytes));
                }
                else 
                {
                    $.$$.SRL.AssemblyLoadContext.Default.LoadFromStream(new $.$$.SI.MemoryStream().$ctor$8(dllBytes), new $.$$.SI.MemoryStream().$ctor$8(pdbBytes));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245426699)
            
            //--TRIMMABLE-BOUNDARY-START(51540393995)
            static /*void */ LoadSatelliteAssembly(/*byte[]*/ dllBytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540393995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SRL.AssemblyLoadContext.Default.LoadFromStream$1(new $.$$.SI.MemoryStream().$ctor$8(dllBytes));
            }
            //--TRIMMABLE-BOUNDARY-END(51540393995)
            
            //--TRIMMABLE-BOUNDARY-START(12885688331)
            static /*Task<int>? */ CallEntrypoint(/*IntPtr*/ assemblyNamePtr, /*string?[]?*/ args, /*bool*/ waitForDebugger)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    /*void**/ let ptr;
                    $.$srij.Interop.Runtime.AssemblyGetEntryPoint(assemblyNamePtr, waitForDebugger ? 1 : 0, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typePointer($.$$.S.Void), () => ptr, ($v) => ptr = $v, null, true));
                    /*RuntimeMethodHandle*/ let methodHandle = $.$srij.SRIJ.JSHostImplementation.GetMethodHandleFromIntPtr($.$$.$interop.$ptr2Addr(ptr));
                    /*MethodInfo?*/ let method = $.$as($.$$.SR.MethodBase.GetMethodFromHandle$1(methodHandle), $.$$.SR.MethodInfo);
                    if ($.$$.SR.MethodInfo.op_Equality$2(method, null))
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$srij.S.SR.CannotResolveManagedEntrypointHandle);
                    }
                    /*object[]*/ let argsToPass = $.$$.S.Array.Empty($.$$.S.Object);
                    /*Task<int>?*/ let result = null;
                    /*var*/ let parameterInfos = method.GetParameters();
                    if (parameterInfos.length > 0 && $.$$.System.Array.$ReadT1.call(parameterInfos, 0).ParameterType === $.$typeArray($.$$.S.String).$type)
                    {
                        argsToPass = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [args ?? $.$$.S.Array.Empty($.$$.S.String)], [-1], null);
                    }
                    if (method.ReturnType === $.$$.S.Void.$type)
                    {
                        method.Invoke(null, argsToPass);
                    }
                    else if (method.ReturnType === $.$$.S.Int32.$type)
                    {
                        /*int*/ let intResult = $.$cast(method.Invoke(null, argsToPass), $.$$.S.Int32);
                        result = $.$$.STT.Task.FromResult($.$$.S.Int32, intResult);
                    }
                    else if (method.ReturnType === $.$$.STT.Task.$type)
                    {
                        /*Task*/ let methodResult = $.$cast(method.Invoke(null, argsToPass), $.$$.STT.Task);
                        /*TaskCompletionSource<int>*/ let tcs = new ($.$$.STT.TaskCompletionSource$$($.$$.S.Int32))().$ctor$1();
                        result = tcs.Task;
                        methodResult.ContinueWith$10(new ($.$$.S.Action$$($.$$.STT.Task))().$ctor(this,  (/*t*/ t) =>
                        {
                            if (t.IsFaulted)
                            {
                                tcs.SetException$1(t.Exception);
                            }
                            else 
                            {
                                tcs.SetResult(0);
                            }
                        }, $GpsVta ??= {"r":65537,"p":[{"n":"t","p":178454529}],"n":"","d":786443,"h":0,"f":17825794}), $.$$.STT.TaskScheduler.Default);
                    }
                    else if (method.ReturnType === $.$$.STT.Task$$($.$$.S.Int32).$type)
                    {
                        result = $.$cast(method.Invoke(null, argsToPass), $.$$.STT.Task$$($.$$.S.Int32));
                    }
                    else 
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$srij.S.SR.Format$6($.$srij.S.SR.ReturnTypeNotSupportedForMain, method.ReturnType.FullName));
                    }
                    return result;
                }
                catch(ex)
                {
                    let refEx;
                    if ($.$is(ex, $.$$.SR.TargetInvocationException, { set $v($v){ refEx = $v; } }) && refEx.InnerException !== null)
                    {
                        ex = refEx.InnerException;
                    }
                    return $.$$.STT.Task.FromException$1($.$$.S.Int32, ex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885688331)
            
            //--TRIMMABLE-BOUNDARY-START(4295753739)
            static /*Task */ BindAssemblyExports(/*string?*/ assemblyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295753739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.Interop.Runtime.BindAssemblyExports($.$$.SRI.Marshal.StringToCoTaskMemUTF8(assemblyName));
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(4295753739)
            
            //--TRIMMABLE-BOUNDARY-START(8590721035)
            static /*JSFunctionBinding */ BindManagedFunction(/*string*/ fullyQualifiedName, /*int*/ signatureHash, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590721035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let  [ assemblyName, nameSpace, shortClassName, methodName ] = $.$destructure($.$srij.SRIJ.JSHostImplementation.ParseFQN(fullyQualifiedName), 4);
                /*IntPtr*/ let monoMethod;
                $.$srij.Interop.Runtime.GetAssemblyExport($.$$.SRI.Marshal.StringToCoTaskMemUTF8(assemblyName), $.$$.SRI.Marshal.StringToCoTaskMemUTF8(nameSpace), $.$$.SRI.Marshal.StringToCoTaskMemUTF8(shortClassName), $.$$.SRI.Marshal.StringToCoTaskMemUTF8(methodName), signatureHash, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.IntPtr, () => monoMethod, ($v) => monoMethod = $v, null, true));
                if (monoMethod === $.$$.S.IntPtr.Zero)
                {
                    $.$$.S.Environment.FailFast$2(`Can't find ${$.$strNN(nameSpace)}${$.$strNN(shortClassName)}${$.$strNN(methodName)} in ${$.$strNN(assemblyName)}.dll`);
                }
                /*var*/ let signature = $.$srij.SRIJ.JSHostImplementation.GetMethodSignature(signatures, null, null);
                ;
                $.$srij.SRIJ.JSHostImplementation.FreeMethodSignatureBuffer(signature);
                return signature;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721035)
            
            //--TRIMMABLE-BOUNDARY-START(25770590219)
            static /*RuntimeMethodHandle */ GetMethodHandleFromIntPtr(/*IntPtr*/ ptr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let temp = (() =>
                {
                    //new $.$srij.SRIJ.JSHostImplementation.IntPtrAndHandle()
                    const $t5 = $.$srij.SRIJ.JSHostImplementation.IntPtrAndHandle;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.ptr = ptr;
                    return $i5;
                })();
                return temp.methodHandle;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590219)
            
            //--TRIMMABLE-BOUNDARY-START(64425295883)
            static /*int */ SmallIndexOf(/*string*/ s, /*char*/ ch, /*int*/ direction)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425295883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (s.length < 1)
                {
                    return -1;
                }
                /*int*/ let start_index = (direction > 0) ? 0 : ((s.length - 1) | 0), end_index = (direction > 0) ? ((s.length - 1) | 0) : 0;
                for(/*int*/ let i = start_index; i !== end_index; i += direction)
                {
                    if ($.$$.S.String.get_Chars.call(s, i) === ch)
                    {
                        return i;
                    }
                }
                return -1;
            }
            //--TRIMMABLE-BOUNDARY-END(64425295883)
            
            //--TRIMMABLE-BOUNDARY-START(68720263179)
            static /*string */ SmallTrim(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720263179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (s.length < 1)
                {
                    return s;
                }
                /*int*/ let head = 0, tail = ((s.length - 1) | 0);
                while(head < s.length)
                {
                    if ($.$$.S.String.get_Chars.call(s, head) === /* */ 32)
                    {
                        head++;
                    }
                    else 
                    {
                        break;
                    }
                }
                while(tail >= 0)
                {
                    if ($.$$.S.String.get_Chars.call(s, tail) === /* */ 32)
                    {
                        tail--;
                    }
                    else 
                    {
                        break;
                    }
                }
                if ((head > 0) || (tail < ((s.length - 1) | 0)))
                {
                    return s.substr(head, ((((tail - head) | 0) + 1) | 0));
                }
                else 
                {
                    return s;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720263179)
            
            //--TRIMMABLE-BOUNDARY-START(55835361291)
            static /*(string assemblyName, string nameSpace, string shortClassName, string methodName) */ ParseFQN(/*string*/ fqn)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835361291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let assembly = fqn.substr((($.$srij.SRIJ.JSHostImplementation.SmallIndexOf(fqn, /*[*/ 91, 1) + 1) | 0), (($.$srij.SRIJ.JSHostImplementation.SmallIndexOf(fqn, /*]*/ 93, 1) - 1) | 0));
                fqn = $.$srij.SRIJ.JSHostImplementation.SmallTrim(fqn);
                fqn = fqn.slice((($.$srij.SRIJ.JSHostImplementation.SmallIndexOf(fqn, /*]*/ 93, 1) + 1) | 0));
                fqn = $.$srij.SRIJ.JSHostImplementation.SmallTrim(fqn);
                /*var*/ let methodName = fqn.slice((($.$srij.SRIJ.JSHostImplementation.SmallIndexOf(fqn, /*:*/ 58, 1) + 1) | 0));
                /*var*/ let className = fqn.substr(0, $.$srij.SRIJ.JSHostImplementation.SmallIndexOf(fqn, /*:*/ 58, 1));
                className = $.$srij.SRIJ.JSHostImplementation.SmallTrim(className);
                /*var*/ let nameSpace = "";
                /*var*/ let shortClassName = className;
                /*var*/ let idx = $.$srij.SRIJ.JSHostImplementation.SmallIndexOf(fqn, /*.*/ 46, -1);
                if (idx !== -1)
                {
                    nameSpace = fqn.substr(0, idx);
                    shortClassName = className.slice(((idx + 1) | 0));
                }
                if ($.$$.S.String.IsNullOrEmpty(assembly))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("No assembly name specified " + $.$strNN(fqn));
                }
                if ($.$$.S.String.IsNullOrEmpty(className))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("No class name specified " + $.$strNN(fqn));
                }
                if ($.$$.S.String.IsNullOrEmpty(methodName))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("No method name specified " + $.$strNN(fqn));
                }
                return new ($.$$.S.ValueTuple$$$$$($.$$.S.String, $.$$.S.String, $.$$.S.String, $.$$.S.String))().$ctor$3(assembly, nameSpace, shortClassName, methodName);
            }
            //--TRIMMABLE-BOUNDARY-END(55835361291)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(73015230475)
                    this.TaskGetResultName = "get_Result";
                    //--TRIMMABLE-BOUNDARY-END(73015230475)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 786443;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360524811),
    {
      "r": 262145,
      "p": [
        {
          "n": "task",
          "p": 178454529
        },
        {
          "n": "value",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "GetTaskResultDynamic",
      "d": 786443,
      "h": 34360524811,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360524811),
//--TRIMMABLE-BOUNDARY-START(38655492107),
    {
      "r": 117571585,
      "p": [
        {
          "n": "taskType",
          "p": 188547073
        }
      ],
      "n": "GetTaskResultMethodInfo",
      "d": 786443,
      "h": 38655492107,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655492107),
//--TRIMMABLE-BOUNDARY-START(77310197771),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg",
          "p": 1310731,
          "f": 4
        }
      ],
      "n": "ThrowException",
      "d": 786443,
      "h": 77310197771,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77310197771),
//--TRIMMABLE-BOUNDARY-START(42950459403),
    {
      "r": $.$$.STT.Task$$($.$srij.SRIJ.JSObject).$h,
      "p": [
        {
          "n": "moduleName",
          "p": 1310721
        },
        {
          "n": "moduleUrl",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ImportAsync",
      "d": 786443,
      "h": 42950459403,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(42950459403),
//--TRIMMABLE-BOUNDARY-START(17180655627),
    {
      "r": $.$$.STT.Task$$($.$srij.SRIJ.JSObject).$h,
      "p": [
        {
          "n": "jsTask",
          "p": $.$$.STT.Task$$($.$srij.SRIJ.JSObject).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CancellationHelper",
      "d": 786443,
      "h": 17180655627,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(17180655627),
//--TRIMMABLE-BOUNDARY-START(30065557515),
    {
      "r": 524299,
      "p": [
        {
          "n": "types",
          "p": $.$$.S.ReadOnlySpan$$($.$srij.SRIJ.JSMarshalerType).$h
        },
        {
          "n": "functionName",
          "p": 1310721
        },
        {
          "n": "moduleName",
          "p": 1310721
        }
      ],
      "n": "GetMethodSignature",
      "d": 786443,
      "h": 30065557515,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065557515),
//--TRIMMABLE-BOUNDARY-START(21475622923),
    {
      "r": 65537,
      "p": [
        {
          "n": "signature",
          "p": 524299
        }
      ],
      "n": "FreeMethodSignatureBuffer",
      "d": 786443,
      "h": 21475622923,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475622923),
//--TRIMMABLE-BOUNDARY-START(47245426699),
    {
      "r": 65537,
      "p": [
        {
          "n": "dllBytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "pdbBytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "LoadLazyAssembly",
      "d": 786443,
      "h": 47245426699,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245426699),
//--TRIMMABLE-BOUNDARY-START(51540393995),
    {
      "r": 65537,
      "p": [
        {
          "n": "dllBytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "LoadSatelliteAssembly",
      "d": 786443,
      "h": 51540393995,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540393995),
//--TRIMMABLE-BOUNDARY-START(12885688331),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "assemblyNamePtr",
          "p": 786433
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "waitForDebugger",
          "p": 262145
        }
      ],
      "n": "CallEntrypoint",
      "d": 786443,
      "h": 12885688331,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885688331),
//--TRIMMABLE-BOUNDARY-START(4295753739),
    {
      "r": 178454529,
      "p": [
        {
          "n": "assemblyName",
          "p": 1310721
        }
      ],
      "n": "BindAssemblyExports",
      "d": 786443,
      "h": 4295753739,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295753739),
//--TRIMMABLE-BOUNDARY-START(8590721035),
    {
      "r": 524299,
      "p": [
        {
          "n": "fullyQualifiedName",
          "p": 1310721
        },
        {
          "n": "signatureHash",
          "p": 655361
        },
        {
          "n": "signatures",
          "p": $.$$.S.ReadOnlySpan$$($.$srij.SRIJ.JSMarshalerType).$h
        }
      ],
      "n": "BindManagedFunction",
      "d": 786443,
      "h": 8590721035,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590721035),
//--TRIMMABLE-BOUNDARY-START(25770590219),
    {
      "r": 160497665,
      "p": [
        {
          "n": "ptr",
          "p": 786433
        }
      ],
      "n": "GetMethodHandleFromIntPtr",
      "d": 786443,
      "h": 25770590219,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770590219),
//--TRIMMABLE-BOUNDARY-START(64425295883),
    {
      "r": 655361,
      "p": [
        {
          "n": "s",
          "p": 1310721
        },
        {
          "n": "ch",
          "p": 458753
        },
        {
          "n": "direction",
          "p": 655361,
          "f": 65,
          "v": 1
        }
      ],
      "n": "SmallIndexOf",
      "d": 786443,
      "h": 64425295883,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64425295883),
//--TRIMMABLE-BOUNDARY-START(68720263179),
    {
      "r": 1310721,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "SmallTrim",
      "d": 786443,
      "h": 68720263179,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68720263179),
//--TRIMMABLE-BOUNDARY-START(55835361291),
    {
      "r": $.$$.S.ValueTuple$$$$$($.$$.S.String, $.$$.S.String, $.$$.S.String, $.$$.S.String).$h,
      "p": [
        {
          "n": "fqn",
          "p": 1310721
        }
      ],
      "n": "ParseFQN",
      "d": 786443,
      "h": 55835361291,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835361291)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015230475),
    {
      "t": 1310721,
      "n": "TaskGetResultName",
      "d": 786443,
      "h": 73015230475,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73015230475),
//--TRIMMABLE-BOUNDARY-START(60130328587),
    {
      "t": 117571585,
      "n": "s_taskGetResultMethodInfo",
      "d": 786443,
      "h": 60130328587,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60130328587)
  ],
  "h": 786443
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$srij.SRIJ.JSHostImplementation.ToManagedCallback, $.$srij.SRIJ.JSHostImplementation.PromiseHolder, $.$srij.SRIJ.JSHostImplementation.PromiseHolderState, $.$srij.SRIJ.JSHostImplementation.IntPtrAndHandle, $.$srij.SRIJ.JSHostImplementation.JSThreadBlockingMode ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSHostImplementation`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSHostImplementation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786443)
        
        

        //--TRIMMABLE-BOUNDARY-START(327691)
        $asm.$cls(`$srij.SRIJ.JavaScriptImports`, ($self) => class JavaScriptImports
        {
            static $h = 327691;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 327691
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JavaScriptImports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JavaScriptImports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327691)
        
        

        //--TRIMMABLE-BOUNDARY-START(720907)
        $asm.$cls(`$srij.SRIJ.JSHost`, ($self) => class JSHost
        {
            //--TRIMMABLE-BOUNDARY-START(25770524683)
            static /*JSObject */ get GlobalThis()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475557387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return globalThis;
            }
            //--TRIMMABLE-BOUNDARY-END(25770524683)
            
            //--TRIMMABLE-BOUNDARY-START(4295688203)
            static /*JSObject */ get DotnetInstance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885622795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return {};
            }
            //--TRIMMABLE-BOUNDARY-END(4295688203)
            
            //--TRIMMABLE-BOUNDARY-START(30065491979)
            static /*Task<JSObject> */ ImportAsync(/*string*/ moduleName, /*string*/ moduleUrl, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065491979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.SRIJ.JSHostImplementation.ImportAsync(moduleName, moduleUrl, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(30065491979)
            
            static $h = 720907;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770524683),
    {
      "p": 2228235,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475557387,
        "f": 50331681
      },
      "n": "GlobalThis",
      "d": 720907,
      "h": 25770524683,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25770524683),
//--TRIMMABLE-BOUNDARY-START(4295688203),
    {
      "p": 2228235,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885622795,
        "f": 50331681
      },
      "n": "DotnetInstance",
      "d": 720907,
      "h": 4295688203,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(4295688203)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065491979),
    {
      "r": $.$$.STT.Task$$($.$srij.SRIJ.JSObject).$h,
      "p": [
        {
          "n": "moduleName",
          "p": 1310721
        },
        {
          "n": "moduleUrl",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ImportAsync",
      "d": 720907,
      "h": 30065491979,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065491979)
  ],
  "h": 720907,
  "a": [
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSHost`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSHost`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720907)
        
        

        //--TRIMMABLE-BOUNDARY-START(3735563)
        $asm.$cls(`$srij.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(468155170827)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(468155170827)
            
            //--TRIMMABLE-BOUNDARY-START(429500465163)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(429500465163);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(429500465163)
            
            //--TRIMMABLE-BOUNDARY-START(545464582155)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(545464582155);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$srij.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(545464582155)
            
            //--TRIMMABLE-BOUNDARY-START(425205497867)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425205497867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$srij.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(425205497867)
            
            //--TRIMMABLE-BOUNDARY-START(420910530571)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420910530571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$srij.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(420910530571)
            
            //--TRIMMABLE-BOUNDARY-START(73018179595)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73018179595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(73018179595)
            
            //--TRIMMABLE-BOUNDARY-START(68723212299)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68723212299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(68723212299)
            
            //--TRIMMABLE-BOUNDARY-START(64428245003)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64428245003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(64428245003)
            
            //--TRIMMABLE-BOUNDARY-START(77313146891)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77313146891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$srij.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(77313146891)
            
            //--TRIMMABLE-BOUNDARY-START(55838310411)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55838310411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(55838310411)
            
            //--TRIMMABLE-BOUNDARY-START(51543343115)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51543343115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(51543343115)
            
            //--TRIMMABLE-BOUNDARY-START(47248375819)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47248375819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$srij.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(47248375819)
            
            //--TRIMMABLE-BOUNDARY-START(60133277707)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60133277707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$srij.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(60133277707)
            
            //--TRIMMABLE-BOUNDARY-START(463860203531)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(463860203531)
            
            //--TRIMMABLE-BOUNDARY-START(450975301643)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(450975301643)
            
            //--TRIMMABLE-BOUNDARY-START(455270268939)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270586675211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$srij.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.Runtime.InteropServices.JavaScript", $.$srij.S.SR.$type.Assembly);
                    $.$srij.S.SR.s_resourceManager = temp;
                }
                return $.$srij.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(455270268939)
            
            //--TRIMMABLE-BOUNDARY-START(21478572043)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184687329291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476745105419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21478572043)
            
            //--TRIMMABLE-BOUNDARY-START(8593670155)
            static /*string */ get ArgumentCannotBeNull()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158917525515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid argument: {0} can not be null.";
            }
            //--TRIMMABLE-BOUNDARY-END(8593670155)
            
            //--TRIMMABLE-BOUNDARY-START(81608114187)
            static /*string */ FormatArgumentCannotBeNull(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81608114187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Invalid argument: {0} can not be null.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81608114187)
            
            //--TRIMMABLE-BOUNDARY-START(12888637451)
            static /*string */ get ArgumentCannotBeNullWithLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167507460107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid argument: {0} can not be null and must have a length.";
            }
            //--TRIMMABLE-BOUNDARY-END(12888637451)
            
            //--TRIMMABLE-BOUNDARY-START(85903081483)
            static /*string */ FormatArgumentCannotBeNullWithLength(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85903081483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Invalid argument: {0} can not be null and must have a length.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(85903081483)
            
            //--TRIMMABLE-BOUNDARY-START(481040072715)
            static /*string */ get SystemRuntimeInteropServicesJavaScript_PlatformNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287766544395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "System.Runtime.InteropServices.JavaScript is not supported on this platform.";
            }
            //--TRIMMABLE-BOUNDARY-END(481040072715)
            
            //--TRIMMABLE-BOUNDARY-START(493924974603)
            static /*string */ get TypedArrayNotCorrectType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313536348171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "TypedArray is not of correct type.";
            }
            //--TRIMMABLE-BOUNDARY-END(493924974603)
            
            //--TRIMMABLE-BOUNDARY-START(498219941899)
            static /*string */ get UnableCastNullToType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322126282763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to cast null to type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(498219941899)
            
            //--TRIMMABLE-BOUNDARY-START(115967852555)
            static /*string */ FormatUnableCastNullToType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115967852555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Unable to cast null to type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(115967852555)
            
            //--TRIMMABLE-BOUNDARY-START(502514909195)
            static /*string */ get UnableCastObjectToType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330716217355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to cast object of type {0} to type {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(502514909195)
            
            //--TRIMMABLE-BOUNDARY-START(120262819851)
            static /*string */ FormatUnableCastObjectToType(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120262819851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Unable to cast object of type {0} to type {1}.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(120262819851)
            
            //--TRIMMABLE-BOUNDARY-START(438090399755)
            static /*string */ get MissingManagedEntrypointHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244816871435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Managed entrypoint handle is not set.";
            }
            //--TRIMMABLE-BOUNDARY-END(438090399755)
            
            //--TRIMMABLE-BOUNDARY-START(17183604747)
            static /*string */ get CannotResolveManagedEntrypointHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176097394699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot resolve managed entrypoint handle.";
            }
            //--TRIMMABLE-BOUNDARY-END(17183604747)
            
            //--TRIMMABLE-BOUNDARY-START(459565236235)
            static /*string */ get ReturnTypeNotSupportedForMain()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279176609803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Return type '{0}' from main method in not supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(459565236235)
            
            //--TRIMMABLE-BOUNDARY-START(103082950667)
            static /*string */ FormatReturnTypeNotSupportedForMain(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082950667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Return type '{0}' from main method in not supported.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(103082950667)
            
            //--TRIMMABLE-BOUNDARY-START(446680334347)
            static /*string */ get NullToManagedCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261996740619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "ToManagedCallback is null.";
            }
            //--TRIMMABLE-BOUNDARY-END(446680334347)
            
            //--TRIMMABLE-BOUNDARY-START(442385367051)
            static /*string */ get NullPromiseHolder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253406806027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "PromiseHolder is null.";
            }
            //--TRIMMABLE-BOUNDARY-END(442385367051)
            
            //--TRIMMABLE-BOUNDARY-START(25773539339)
            static /*string */ get EmptyProfileData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193277263883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Empty profile data.";
            }
            //--TRIMMABLE-BOUNDARY-END(25773539339)
            
            //--TRIMMABLE-BOUNDARY-START(30068506635)
            static /*string */ get ErrorLegacySettingProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201867198475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Error setting {0} on (js-obj js '{1}'): {2}.";
            }
            //--TRIMMABLE-BOUNDARY-END(30068506635)
            
            //--TRIMMABLE-BOUNDARY-START(90198048779)
            static /*string */ FormatErrorLegacySettingProperty(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90198048779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$7("Error setting {0} on (js-obj js '{1}'): {2}.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(90198048779)
            
            //--TRIMMABLE-BOUNDARY-START(34363473931)
            static /*string */ get ErrorResolvingFromGlobalThis()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210457133067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Error resolving property {0} from globalThis.";
            }
            //--TRIMMABLE-BOUNDARY-END(34363473931)
            
            //--TRIMMABLE-BOUNDARY-START(94493016075)
            static /*string */ FormatErrorResolvingFromGlobalThis(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94493016075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Error resolving property {0} from globalThis.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(94493016075)
            
            //--TRIMMABLE-BOUNDARY-START(38658441227)
            static /*string */ get FailedToMarshalException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219047067659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Failed to marshal exception.";
            }
            //--TRIMMABLE-BOUNDARY-END(38658441227)
            
            //--TRIMMABLE-BOUNDARY-START(42953408523)
            static /*string */ get FailedToMarshalPromiseHolder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227637002251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Failed to marshal Promise callback.";
            }
            //--TRIMMABLE-BOUNDARY-END(42953408523)
            
            //--TRIMMABLE-BOUNDARY-START(433795432459)
            static /*string */ get InvalidInFlightCounter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236226936843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid InFlightCounter for JSObject {0}, expected: {1}, actual: {2}.";
            }
            //--TRIMMABLE-BOUNDARY-END(433795432459)
            
            //--TRIMMABLE-BOUNDARY-START(98787983371)
            static /*string */ FormatInvalidInFlightCounter(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787983371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$7("Invalid InFlightCounter for JSObject {0}, expected: {1}, actual: {2}.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(98787983371)
            
            //--TRIMMABLE-BOUNDARY-START(485335040011)
            static /*string */ get ToJSNotImplemented()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296356478987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "ToJS for {0} is not implemented.";
            }
            //--TRIMMABLE-BOUNDARY-END(485335040011)
            
            //--TRIMMABLE-BOUNDARY-START(107377917963)
            static /*string */ FormatToJSNotImplemented(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107377917963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("ToJS for {0} is not implemented.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(107377917963)
            
            //--TRIMMABLE-BOUNDARY-START(489630007307)
            static /*string */ get ToManagedNotImplemented()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304946413579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "ToManaged for {0} is not implemented.";
            }
            //--TRIMMABLE-BOUNDARY-END(489630007307)
            
            //--TRIMMABLE-BOUNDARY-START(111672885259)
            static /*string */ FormatToManagedNotImplemented(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111672885259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("ToManaged for {0} is not implemented.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(111672885259)
            
            //--TRIMMABLE-BOUNDARY-START(506809876491)
            static /*string */ get UnableToResolveHandleAsException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339306151947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to resolve the handle as an Exception.";
            }
            //--TRIMMABLE-BOUNDARY-END(506809876491)
            
            //--TRIMMABLE-BOUNDARY-START(511104843787)
            static /*string */ get UnsupportedArrayType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347896086539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported array type {0}. Only single-dimensional arrays with a zero lower bound can be marshaled to JS.";
            }
            //--TRIMMABLE-BOUNDARY-END(511104843787)
            
            //--TRIMMABLE-BOUNDARY-START(124557787147)
            static /*string */ FormatUnsupportedArrayType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124557787147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Unsupported array type {0}. Only single-dimensional arrays with a zero lower bound can be marshaled to JS.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(124557787147)
            
            //--TRIMMABLE-BOUNDARY-START(515399811083)
            static /*string */ get UnsupportedElementType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356486021131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported element type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(515399811083)
            
            //--TRIMMABLE-BOUNDARY-START(128852754443)
            static /*string */ FormatUnsupportedElementType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128852754443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Unsupported element type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(128852754443)
            
            //--TRIMMABLE-BOUNDARY-START(519694778379)
            static /*string */ get UnsupportedEnumType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365075955723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported enum type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(519694778379)
            
            //--TRIMMABLE-BOUNDARY-START(133147721739)
            static /*string */ FormatUnsupportedEnumType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133147721739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Unsupported enum type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(133147721739)
            
            //--TRIMMABLE-BOUNDARY-START(523989745675)
            static /*string */ get UnsupportedLegacyMarshlerType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373665890315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported marshal type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(523989745675)
            
            //--TRIMMABLE-BOUNDARY-START(137442689035)
            static /*string */ FormatUnsupportedLegacyMarshlerType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137442689035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Unsupported marshal type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(137442689035)
            
            //--TRIMMABLE-BOUNDARY-START(528284712971)
            static /*string */ get UnsupportedNullableType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382255824907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported nullable type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(528284712971)
            
            //--TRIMMABLE-BOUNDARY-START(141737656331)
            static /*string */ FormatUnsupportedNullableType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141737656331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Unsupported nullable type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(141737656331)
            
            //--TRIMMABLE-BOUNDARY-START(532579680267)
            static /*string */ get UnsupportedTaskResultType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390845759499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported task result type {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(532579680267)
            
            //--TRIMMABLE-BOUNDARY-START(146032623627)
            static /*string */ FormatUnsupportedTaskResultType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146032623627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Unsupported task result type {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(146032623627)
            
            //--TRIMMABLE-BOUNDARY-START(536874647563)
            static /*string */ get UriConstructorMissing()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399435694091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Constructor on type 'System.Uri' not found. Please consider to protect it's constructor from trimming.";
            }
            //--TRIMMABLE-BOUNDARY-END(536874647563)
            
            //--TRIMMABLE-BOUNDARY-START(541169614859)
            static /*string */ get UriTypeMissing()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408025628683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The type System.Uri could not be found. Please consider to protect the class and it's constructor from trimming.";
            }
            //--TRIMMABLE-BOUNDARY-END(541169614859)
            
            //--TRIMMABLE-BOUNDARY-START(549759549451)
            static /*string */ get ValueOutOf52BitRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416615563275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Overflow: value {0} is out of {1} {2} range.";
            }
            //--TRIMMABLE-BOUNDARY-END(549759549451)
            
            //--TRIMMABLE-BOUNDARY-START(150327590923)
            static /*string */ FormatValueOutOf52BitRange(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150327590923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$7("Overflow: value {0} is out of {1} {2} range.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(150327590923)
            
            //--TRIMMABLE-BOUNDARY-START(4298702859)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298702859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(468155170827)
                    this.s_usingResourceKeys = $.$srij.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(468155170827)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298702859)
            
            static $h = 3735563;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3735563
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3735563)
        
        

        //--TRIMMABLE-BOUNDARY-START(524299)
        $asm.$cls(`$srij.SRIJ.JSFunctionBinding`, ($self) => class JSFunctionBinding extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590458891)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590458891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590458891)
            
            //--TRIMMABLE-BOUNDARY-START(81604902923)
            /*JSBindingHeader**/ Header;
            //--TRIMMABLE-BOUNDARY-END(81604902923)
            
            //--TRIMMABLE-BOUNDARY-START(167504248843)
            /*JSBindingType**/ Sigs;
            //--TRIMMABLE-BOUNDARY-END(167504248843)
            
            //--TRIMMABLE-BOUNDARY-START(120259608587)
            /*uint*/ static nextImportHandle = 1;
            //--TRIMMABLE-BOUNDARY-END(120259608587)
            
            //--TRIMMABLE-BOUNDARY-START(85899870219)
            /*int*/ ImportHandle = 0;
            //--TRIMMABLE-BOUNDARY-END(85899870219)
            
            //--TRIMMABLE-BOUNDARY-START(111669673995)
            /*bool*/ IsAsync = false;
            //--TRIMMABLE-BOUNDARY-END(111669673995)
            
            //--TRIMMABLE-BOUNDARY-START(115964641291)
            /*bool*/ IsDiscardNoWait = false;
            //--TRIMMABLE-BOUNDARY-END(115964641291)
            
            //--TRIMMABLE-BOUNDARY-START(34360262667)
            /*string?*/ FunctionName = null;
            //--TRIMMABLE-BOUNDARY-END(34360262667)
            
            //--TRIMMABLE-BOUNDARY-START(589835)
            static $_JSBindingHeader;
            static get JSBindingHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(589835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSFunctionBinding;
                return $cls.$_JSBindingHeader ??= $asm.$nstr(`$srij.SRIJ.JSFunctionBinding.JSBindingHeader`, ($self) => class JSBindingHeader extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(30065360907)
                    /*int*/ static JSMarshalerSignatureHeaderSize = 32;
                    //--TRIMMABLE-BOUNDARY-END(30065360907)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245230091)
                    /*int*/  get Version() { return this.$getField(0, $.$$.S.Int32); }
                    /*int*/  set Version(value) { this.$setField(0, $.$$.S.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(47245230091)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590524427)
                    /*int*/  get ArgumentCount() { return this.$getField(4, $.$$.S.Int32); }
                    /*int*/  set ArgumentCount(value) { this.$setField(4, $.$$.S.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590524427)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770393611)
                    /*int*/  get ImportHandle() { return this.$getField(8, $.$$.S.Int32); }
                    /*int*/  set ImportHandle(value) { this.$setField(8, $.$$.S.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(25770393611)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475426315)
                    /*int*/  get FunctionNameOffset() { return this.$getField(16, $.$$.S.Int32); }
                    /*int*/  set FunctionNameOffset(value) { this.$setField(16, $.$$.S.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(21475426315)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180459019)
                    /*int*/  get FunctionNameLength() { return this.$getField(20, $.$$.S.Int32); }
                    /*int*/  set FunctionNameLength(value) { this.$setField(20, $.$$.S.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(17180459019)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655295499)
                    /*int*/  get ModuleNameOffset() { return this.$getField(24, $.$$.S.Int32); }
                    /*int*/  set ModuleNameOffset(value) { this.$setField(24, $.$$.S.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(38655295499)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360328203)
                    /*int*/  get ModuleNameLength() { return this.$getField(28, $.$$.S.Int32); }
                    /*int*/  set ModuleNameLength(value) { this.$setField(28, $.$$.S.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(34360328203)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885491723)
                    /*JSBindingType*/  get Exception() { return this.$getField(32, $.$srij.SRIJ.JSFunctionBinding.JSBindingType); }
                    /*JSBindingType*/  set Exception(value) { this.$setField(32, $.$srij.SRIJ.JSFunctionBinding.JSBindingType, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885491723)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950262795)
                    /*JSBindingType*/  get Result() { return this.$getField(64, $.$srij.SRIJ.JSFunctionBinding.JSBindingType); }
                    /*JSBindingType*/  set Result(value) { this.$setField(64, $.$srij.SRIJ.JSFunctionBinding.JSBindingType, value); }
                    //--TRIMMABLE-BOUNDARY-END(42950262795)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295557131)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295557131);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295557131)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295557131)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295557131)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Version = this.Version;
                        copy.ArgumentCount = this.ArgumentCount;
                        copy.ImportHandle = this.ImportHandle;
                        copy.FunctionNameOffset = this.FunctionNameOffset;
                        copy.FunctionNameLength = this.FunctionNameLength;
                        copy.ModuleNameOffset = this.ModuleNameOffset;
                        copy.ModuleNameLength = this.ModuleNameLength;
                        copy.Exception = this.Exception.$clone();
                        copy.Result = this.Result.$clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(47245230091)
                        this.Version = 0;
                        //--TRIMMABLE-BOUNDARY-END(47245230091)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590524427)
                        this.ArgumentCount = 0;
                        //--TRIMMABLE-BOUNDARY-END(8590524427)
                        
                        //--TRIMMABLE-BOUNDARY-START(25770393611)
                        this.ImportHandle = 0;
                        //--TRIMMABLE-BOUNDARY-END(25770393611)
                        
                        //--TRIMMABLE-BOUNDARY-START(21475426315)
                        this.FunctionNameOffset = 0;
                        //--TRIMMABLE-BOUNDARY-END(21475426315)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180459019)
                        this.FunctionNameLength = 0;
                        //--TRIMMABLE-BOUNDARY-END(17180459019)
                        
                        //--TRIMMABLE-BOUNDARY-START(38655295499)
                        this.ModuleNameOffset = 0;
                        //--TRIMMABLE-BOUNDARY-END(38655295499)
                        
                        //--TRIMMABLE-BOUNDARY-START(34360328203)
                        this.ModuleNameLength = 0;
                        //--TRIMMABLE-BOUNDARY-END(34360328203)
                        
                        //--TRIMMABLE-BOUNDARY-START(12885491723)
                        this.Exception = $.$default($.$srij.SRIJ.JSFunctionBinding.JSBindingType);
                        //--TRIMMABLE-BOUNDARY-END(12885491723)
                        
                        //--TRIMMABLE-BOUNDARY-START(42950262795)
                        this.Result = $.$default($.$srij.SRIJ.JSFunctionBinding.JSBindingType);
                        //--TRIMMABLE-BOUNDARY-END(42950262795)
                        
                    }
                    //--TRIMMABLE-BOUNDARY-START(SINIT)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(30065360907)
                            this.JSMarshalerSignatureHeaderSize = 32;
                            //--TRIMMABLE-BOUNDARY-END(30065360907)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(SINIT)
                    
                    static $h = 589835;
                    static $z = 96;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065360907),
    {
      "t": 655361,
      "n": "JSMarshalerSignatureHeaderSize",
      "d": 589835,
      "h": 30065360907,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065360907),
//--TRIMMABLE-BOUNDARY-START(47245230091),
    {
      "t": 655361,
      "n": "Version",
      "d": 589835,
      "h": 47245230091,
      "f": 4194305,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245230091),
//--TRIMMABLE-BOUNDARY-START(8590524427),
    {
      "t": 655361,
      "n": "ArgumentCount",
      "d": 589835,
      "h": 8590524427,
      "f": 4194305,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590524427),
//--TRIMMABLE-BOUNDARY-START(25770393611),
    {
      "t": 655361,
      "n": "ImportHandle",
      "d": 589835,
      "h": 25770393611,
      "f": 4194305,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 8,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770393611),
//--TRIMMABLE-BOUNDARY-START(21475426315),
    {
      "t": 655361,
      "n": "FunctionNameOffset",
      "d": 589835,
      "h": 21475426315,
      "f": 4194305,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 16,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475426315),
//--TRIMMABLE-BOUNDARY-START(17180459019),
    {
      "t": 655361,
      "n": "FunctionNameLength",
      "d": 589835,
      "h": 17180459019,
      "f": 4194305,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180459019),
//--TRIMMABLE-BOUNDARY-START(38655295499),
    {
      "t": 655361,
      "n": "ModuleNameOffset",
      "d": 589835,
      "h": 38655295499,
      "f": 4194305,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 24,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655295499),
//--TRIMMABLE-BOUNDARY-START(34360328203),
    {
      "t": 655361,
      "n": "ModuleNameLength",
      "d": 589835,
      "h": 34360328203,
      "f": 4194305,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 28,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360328203),
//--TRIMMABLE-BOUNDARY-START(42950262795),
    {
      "t": 655371,
      "n": "Result",
      "d": 589835,
      "h": 42950262795,
      "f": 4194305,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 64,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950262795)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557131),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589835,
      "h": 4295557131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557131)
  ],
  "d": 524299,
  "h": 589835,
  "a": [
    {
      "t": 148176897,
      "c": 13033078785,
      "a": [
        {
          "v": 2,
          "t": 143654913
        }
      ],
      "n": [
        {
          "n": "Pack",
          "v": 4,
          "t": 655361
        }
      ]
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSFunctionBinding+JSBindingHeader`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSFunctionBinding${separator}JSBindingHeader`; }
                }, $cls, ($v) => $cls.$_JSBindingHeader = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(589835)
            
            //--TRIMMABLE-BOUNDARY-START(655371)
            static $_JSBindingType;
            static get JSBindingType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSFunctionBinding;
                return $cls.$_JSBindingType ??= $asm.$nstr(`$srij.SRIJ.JSFunctionBinding.JSBindingType`, ($self) => class JSBindingType extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(25770459147)
                    /*MarshalerType*/  get Type() { return this.$getField(0, $.$srij.SRIJ.MarshalerType); }
                    /*MarshalerType*/  set Type(value) { this.$setField(0, $.$srij.SRIJ.MarshalerType, value); }
                    //--TRIMMABLE-BOUNDARY-END(25770459147)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475491851)
                    /*MarshalerType*/  get ResultMarshalerType() { return this.$getField(16, $.$srij.SRIJ.MarshalerType); }
                    /*MarshalerType*/  set ResultMarshalerType(value) { this.$setField(16, $.$srij.SRIJ.MarshalerType, value); }
                    //--TRIMMABLE-BOUNDARY-END(21475491851)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590589963)
                    /*MarshalerType*/  get Arg1MarshalerType() { return this.$getField(20, $.$srij.SRIJ.MarshalerType); }
                    /*MarshalerType*/  set Arg1MarshalerType(value) { this.$setField(20, $.$srij.SRIJ.MarshalerType, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590589963)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557259)
                    /*MarshalerType*/  get Arg2MarshalerType() { return this.$getField(24, $.$srij.SRIJ.MarshalerType); }
                    /*MarshalerType*/  set Arg2MarshalerType(value) { this.$setField(24, $.$srij.SRIJ.MarshalerType, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885557259)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180524555)
                    /*MarshalerType*/  get Arg3MarshalerType() { return this.$getField(28, $.$srij.SRIJ.MarshalerType); }
                    /*MarshalerType*/  set Arg3MarshalerType(value) { this.$setField(28, $.$srij.SRIJ.MarshalerType, value); }
                    //--TRIMMABLE-BOUNDARY-END(17180524555)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295622667)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295622667);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295622667)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295622667)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295622667)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Type = this.Type;
                        copy.ResultMarshalerType = this.ResultMarshalerType;
                        copy.Arg1MarshalerType = this.Arg1MarshalerType;
                        copy.Arg2MarshalerType = this.Arg2MarshalerType;
                        copy.Arg3MarshalerType = this.Arg3MarshalerType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(25770459147)
                        this.Type = 0;
                        //--TRIMMABLE-BOUNDARY-END(25770459147)
                        
                        //--TRIMMABLE-BOUNDARY-START(21475491851)
                        this.ResultMarshalerType = 0;
                        //--TRIMMABLE-BOUNDARY-END(21475491851)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590589963)
                        this.Arg1MarshalerType = 0;
                        //--TRIMMABLE-BOUNDARY-END(8590589963)
                        
                        //--TRIMMABLE-BOUNDARY-START(12885557259)
                        this.Arg2MarshalerType = 0;
                        //--TRIMMABLE-BOUNDARY-END(12885557259)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180524555)
                        this.Arg3MarshalerType = 0;
                        //--TRIMMABLE-BOUNDARY-END(17180524555)
                        
                    }
                    static $h = 655371;
                    static $z = 32;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770459147),
    {
      "t": 3670027,
      "n": "Type",
      "d": 655371,
      "h": 25770459147,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770459147),
//--TRIMMABLE-BOUNDARY-START(21475491851),
    {
      "t": 3670027,
      "n": "ResultMarshalerType",
      "d": 655371,
      "h": 21475491851,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 16,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475491851),
//--TRIMMABLE-BOUNDARY-START(8590589963),
    {
      "t": 3670027,
      "n": "Arg1MarshalerType",
      "d": 655371,
      "h": 8590589963,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590589963),
//--TRIMMABLE-BOUNDARY-START(12885557259),
    {
      "t": 3670027,
      "n": "Arg2MarshalerType",
      "d": 655371,
      "h": 12885557259,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 24,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885557259),
//--TRIMMABLE-BOUNDARY-START(17180524555),
    {
      "t": 3670027,
      "n": "Arg3MarshalerType",
      "d": 655371,
      "h": 17180524555,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 28,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180524555)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622667),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655371,
      "h": 4295622667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622667)
  ],
  "d": 524299,
  "h": 655371,
  "a": [
    {
      "t": 148176897,
      "c": 13033078785,
      "a": [
        {
          "v": 2,
          "t": 143654913
        }
      ],
      "n": [
        {
          "n": "Pack",
          "v": 4,
          "t": 655361
        },
        {
          "n": "Size",
          "v": 32,
          "t": 655361
        }
      ]
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSFunctionBinding+JSBindingType`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSFunctionBinding${separator}JSBindingType`; }
                }, $cls, ($v) => $cls.$_JSBindingType = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655371)
            
            //--TRIMMABLE-BOUNDARY-START(12885426187)
            /*int */ get ArgumentCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950197259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.GetAt(0).ArgumentCount;
            }
            /*int */ set ArgumentCount(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439477771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Header.GetAt(0).ArgumentCount = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426187)
            
            //--TRIMMABLE-BOUNDARY-START(176094183435)
            /*int */ get Version()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309935627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.GetAt(0).Version;
            }
            /*int */ set Version(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209281547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Header.GetAt(0).Version = value;
            }
            //--TRIMMABLE-BOUNDARY-END(176094183435)
            
            //--TRIMMABLE-BOUNDARY-START(128849543179)
            /*JSBindingType */ get Result()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720001035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.GetAt(0).Result;
            }
            /*JSBindingType */ set Result(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619346955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Header.GetAt(0).Result = $.$clone(value);
            }
            //--TRIMMABLE-BOUNDARY-END(128849543179)
            
            //--TRIMMABLE-BOUNDARY-START(30065295371)
            /*JSBindingType */ get Exception()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540131851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.GetAt(0).Exception;
            }
            /*JSBindingType */ set Exception(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029412363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Header.GetAt(0).Exception = $.$clone(value);
            }
            //--TRIMMABLE-BOUNDARY-END(30065295371)
            
            //--TRIMMABLE-BOUNDARY-START(171799216139)
            /*JSBindingType*/ get_Item$1(/*int*/ position)
            {
                return this.Sigs.GetAt(((position - 1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(171799216139)
            
            //--TRIMMABLE-BOUNDARY-START(90194837515)
            static /*void */ InvokeJS(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194837515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.SRIJ.JSFunctionBinding.InvokeJSImportImpl(signature, $arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(90194837515)
            
            //--TRIMMABLE-BOUNDARY-START(17180393483)
            static /*JSFunctionBinding */ BindJSFunction(/*string*/ functionName, /*string*/ moduleName, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180393483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.SRI.RuntimeInformation.OSArchitecture !== 4/*Architecture.Wasm*/)
                {
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
                }
                return $.$srij.SRIJ.JSFunctionBinding.BindJSImportImpl(functionName, moduleName, signatures);
            }
            //--TRIMMABLE-BOUNDARY-END(17180393483)
            
            //--TRIMMABLE-BOUNDARY-START(25770328075)
            static /*JSFunctionBinding */ BindManagedFunction(/*string*/ fullyQualifiedName, /*int*/ signatureHash, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770328075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.SRI.RuntimeInformation.OSArchitecture !== 4/*Architecture.Wasm*/)
                {
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
                }
                return $.$srij.SRIJ.JSHostImplementation.BindManagedFunction(fullyQualifiedName, signatureHash, signatures);
            }
            //--TRIMMABLE-BOUNDARY-END(25770328075)
            
            //--TRIMMABLE-BOUNDARY-START(94489804811)
            static /*void */ InvokeJSFunction(/*JSObject*/ jsFunction, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489804811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                jsFunction.AssertNotDisposed();
                $.$srij.SRIJ.JSFunctionBinding.InvokeJSFunctionCurrent(jsFunction, $arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(94489804811)
            
            //--TRIMMABLE-BOUNDARY-START(98784772107)
            static /*void */ InvokeJSFunctionCurrent(/*JSObject*/ jsFunction, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784772107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let functionHandle = jsFunction.JSHandle;
                /*fixed*/ 
                {
                    /*JSMarshalerArgument**/ let ptr = $arguments.GetPinnableReference();
                    $.$srij.Interop.Runtime.InvokeJSFunction(functionHandle, $.$$.$interop.$ptr2Addr(ptr));
                    /*ref JSMarshalerArgument*/ let exceptionArg = $arguments.get_Item(0);
                    if (exceptionArg.$v.slot.Type !== 0/*MarshalerType.None*/)
                    {
                        $.$srij.SRIJ.JSHostImplementation.ThrowException(exceptionArg);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784772107)
            
            //--TRIMMABLE-BOUNDARY-START(107374706699)
            static /*void */ InvokeJSImportImpl(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374706699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let exc = $arguments.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = $arguments.get_Item(1);
                /*var*/ let targetContext = $.$srij.SRIJ.JSProxyContext.MainThreadContext;
                if (signature.IsAsync)
                {
                    /*var*/ let holder = targetContext.CreatePromiseHolder();
                    res.$v.slot.Type = 30/*MarshalerType.TaskPreCreated*/;
                    res.$v.slot.GCHandle = holder.GCHandle;
                }
                if (signature.IsDiscardNoWait)
                {
                    $arguments._reference.GetAt(1).slot.Type = 26/*MarshalerType.DiscardNoWait*/;
                }
                $.$srij.SRIJ.JSFunctionBinding.InvokeJSImportCurrent(signature, $arguments);
                if (signature.IsAsync)
                {
                    if ($arguments._reference.GetAt(1).slot.Type === 0/*MarshalerType.None*/)
                    {
                        /*var*/ let holderHandle = $.$$.SRI.GCHandle.op_Explicit$1($arguments._reference.GetAt(1).slot.GCHandle);
                        holderHandle.Free();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374706699)
            
            //--TRIMMABLE-BOUNDARY-START(103079739403)
            static /*void */ InvokeJSImportCurrent(/*JSFunctionBinding*/ signature, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079739403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*fixed*/ 
                {
                    /*JSMarshalerArgument**/ let args = $arguments.GetPinnableReference();
                    $.$srij.Interop.Runtime.InvokeJSImportST(signature.ImportHandle, $.$$.$interop.$ptr2Addr(args));
                }
                /*ref JSMarshalerArgument*/ let exceptionArg = $arguments.get_Item(0);
                if (exceptionArg.$v.slot.Type !== 0/*MarshalerType.None*/)
                {
                    $.$srij.SRIJ.JSHostImplementation.ThrowException(exceptionArg);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079739403)
            
            //--TRIMMABLE-BOUNDARY-START(21475360779)
            static /*JSFunctionBinding */ BindJSImportImpl(/*string*/ functionName, /*string*/ moduleName, /*ReadOnlySpan<JSMarshalerType>*/ signatures)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let signature = $.$srij.SRIJ.JSHostImplementation.GetMethodSignature(signatures, functionName, moduleName);
                /*nint*/ let exceptionPtr = $.$srij.Interop.Runtime.BindJSImportST(signature.Header);
                if (exceptionPtr !== $.$$.S.IntPtr.Zero)
                {
                    /*var*/ let message = $.$$.SRI.Marshal.PtrToStringUni$1(exceptionPtr);
                    $.$$.SRI.Marshal.FreeHGlobal(exceptionPtr);
                    throw new $.$srij.SRIJ.JSException().$ctor$6(message);
                }
                $.$srij.SRIJ.JSHostImplementation.FreeMethodSignatureBuffer(signature);
                return signature;
            }
            //--TRIMMABLE-BOUNDARY-END(21475360779)
            
            //--TRIMMABLE-BOUNDARY-START(124554575883)
            static /*void */ ResolveOrRejectPromise(/*JSProxyContext*/ targetContext, /*Span<JSMarshalerArgument>*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554575883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let exc = $arguments.get_Item(0);
                {
                    /*fixed*/ 
                    {
                        /*JSMarshalerArgument**/ let ptr = $arguments.GetPinnableReference();
                        $.$srij.Interop.Runtime.ResolveOrRejectPromise($.$$.$interop.$ptr2Addr(ptr));
                        if (exc.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            $.$srij.SRIJ.JSHostImplementation.ThrowException(exc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554575883)
            
            //--TRIMMABLE-BOUNDARY-START(8590458891)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590458891)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(81604902923)
                this.Header = $.$default($.$typePointer($.$srij.SRIJ.JSFunctionBinding.JSBindingHeader));
                //--TRIMMABLE-BOUNDARY-END(81604902923)
                
                //--TRIMMABLE-BOUNDARY-START(167504248843)
                this.Sigs = $.$default($.$typePointer($.$srij.SRIJ.JSFunctionBinding.JSBindingType));
                //--TRIMMABLE-BOUNDARY-END(167504248843)
                
            }
            static $h = 524299;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885426187),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950197259,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439477771,
        "f": 83886088
      },
      "n": "ArgumentCount",
      "d": 524299,
      "h": 12885426187,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(12885426187),
//--TRIMMABLE-BOUNDARY-START(176094183435),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309935627,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209281547,
        "f": 83886088
      },
      "n": "Version",
      "d": 524299,
      "h": 176094183435,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(176094183435),
//--TRIMMABLE-BOUNDARY-START(128849543179),
    {
      "p": 655371,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720001035,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619346955,
        "f": 83886088
      },
      "n": "Result",
      "d": 524299,
      "h": 128849543179,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(128849543179),
//--TRIMMABLE-BOUNDARY-START(171799216139),
    {
      "p": 655371,
      "i": [
        {
          "n": "position",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130066443,
        "f": 50331656
      },
      "n": "Item",
      "o": "@$1",
      "d": 524299,
      "h": 171799216139,
      "f": 538968072
    },
//--TRIMMABLE-BOUNDARY-END(171799216139)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90194837515),
    {
      "r": 65537,
      "p": [
        {
          "n": "signature",
          "p": 524299
        },
        {
          "n": "arguments",
          "p": $.$$.S.Span$$($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "InvokeJS",
      "d": 524299,
      "h": 90194837515,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90194837515),
//--TRIMMABLE-BOUNDARY-START(17180393483),
    {
      "r": 524299,
      "p": [
        {
          "n": "functionName",
          "p": 1310721
        },
        {
          "n": "moduleName",
          "p": 1310721
        },
        {
          "n": "signatures",
          "p": $.$$.S.ReadOnlySpan$$($.$srij.SRIJ.JSMarshalerType).$h
        }
      ],
      "n": "BindJSFunction",
      "d": 524299,
      "h": 17180393483,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180393483),
//--TRIMMABLE-BOUNDARY-START(25770328075),
    {
      "r": 524299,
      "p": [
        {
          "n": "fullyQualifiedName",
          "p": 1310721
        },
        {
          "n": "signatureHash",
          "p": 655361
        },
        {
          "n": "signatures",
          "p": $.$$.S.ReadOnlySpan$$($.$srij.SRIJ.JSMarshalerType).$h
        }
      ],
      "n": "BindManagedFunction",
      "d": 524299,
      "h": 25770328075,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770328075),
//--TRIMMABLE-BOUNDARY-START(94489804811),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsFunction",
          "p": 2228235
        },
        {
          "n": "arguments",
          "p": $.$$.S.Span$$($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "InvokeJSFunction",
      "d": 524299,
      "h": 94489804811,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(94489804811),
//--TRIMMABLE-BOUNDARY-START(98784772107),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsFunction",
          "p": 2228235
        },
        {
          "n": "arguments",
          "p": $.$$.S.Span$$($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "InvokeJSFunctionCurrent",
      "d": 524299,
      "h": 98784772107,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(98784772107),
//--TRIMMABLE-BOUNDARY-START(107374706699),
    {
      "r": 65537,
      "p": [
        {
          "n": "signature",
          "p": 524299
        },
        {
          "n": "arguments",
          "p": $.$$.S.Span$$($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "InvokeJSImportImpl",
      "d": 524299,
      "h": 107374706699,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(107374706699),
//--TRIMMABLE-BOUNDARY-START(103079739403),
    {
      "r": 65537,
      "p": [
        {
          "n": "signature",
          "p": 524299
        },
        {
          "n": "arguments",
          "p": $.$$.S.Span$$($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "InvokeJSImportCurrent",
      "d": 524299,
      "h": 103079739403,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(103079739403),
//--TRIMMABLE-BOUNDARY-START(21475360779),
    {
      "r": 524299,
      "p": [
        {
          "n": "functionName",
          "p": 1310721
        },
        {
          "n": "moduleName",
          "p": 1310721
        },
        {
          "n": "signatures",
          "p": $.$$.S.ReadOnlySpan$$($.$srij.SRIJ.JSMarshalerType).$h
        }
      ],
      "n": "BindJSImportImpl",
      "d": 524299,
      "h": 21475360779,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21475360779),
//--TRIMMABLE-BOUNDARY-START(124554575883),
    {
      "r": 65537,
      "p": [
        {
          "n": "targetContext",
          "p": 2293771
        },
        {
          "n": "arguments",
          "p": $.$$.S.Span$$($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "ResolveOrRejectPromise",
      "d": 524299,
      "h": 124554575883,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(124554575883)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81604902923),
    {
      "t": $.$typePointer($.$srij.SRIJ.JSFunctionBinding.JSBindingHeader).$h,
      "n": "Header",
      "d": 524299,
      "h": 81604902923,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(81604902923),
//--TRIMMABLE-BOUNDARY-START(167504248843),
    {
      "t": $.$typePointer($.$srij.SRIJ.JSFunctionBinding.JSBindingType).$h,
      "n": "Sigs",
      "d": 524299,
      "h": 167504248843,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(167504248843),
//--TRIMMABLE-BOUNDARY-START(120259608587),
    {
      "t": 720897,
      "n": "nextImportHandle",
      "d": 524299,
      "h": 120259608587,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259608587),
//--TRIMMABLE-BOUNDARY-START(85899870219),
    {
      "t": 655361,
      "n": "ImportHandle",
      "d": 524299,
      "h": 85899870219,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(85899870219),
//--TRIMMABLE-BOUNDARY-START(111669673995),
    {
      "t": 262145,
      "n": "IsAsync",
      "d": 524299,
      "h": 111669673995,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(111669673995),
//--TRIMMABLE-BOUNDARY-START(115964641291),
    {
      "t": 262145,
      "n": "IsDiscardNoWait",
      "d": 524299,
      "h": 115964641291,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(115964641291),
//--TRIMMABLE-BOUNDARY-START(34360262667),
    {
      "t": 1310721,
      "n": "FunctionName",
      "d": 524299,
      "h": 34360262667,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(34360262667)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590458891),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524299,
      "h": 8590458891,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8590458891)
  ],
  "h": 524299,
  "a": [
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    }
  ]
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$srij.SRIJ.JSFunctionBinding.JSBindingHeader, $.$srij.SRIJ.JSFunctionBinding.JSBindingType ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSFunctionBinding`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSFunctionBinding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524299)
        
        

        //--TRIMMABLE-BOUNDARY-START(2162699)
        $asm.$cls(`$srij.SRIJ.JSMarshalerType`, ($self) => class JSMarshalerType extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592097291)
            /*JSFunctionBinding.JSBindingType*/ _signatureType;
            //--TRIMMABLE-BOUNDARY-END(8592097291)
            
            //--TRIMMABLE-BOUNDARY-START(111671312395)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111671312395);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._signatureType = $.$srij.SRIJ.JSMarshalerType.Void._signatureType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(111671312395)
            
            //--TRIMMABLE-BOUNDARY-START(115966279691)
            $ctor$2(/*JSFunctionBinding.JSBindingType*/ signatureType)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115966279691);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._signatureType = $.$clone(signatureType);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(115966279691)
            
            //--TRIMMABLE-BOUNDARY-START(455268696075)
            /*JSMarshalerType*/ static Void = null;
            //--TRIMMABLE-BOUNDARY-END(455268696075)
            
            //--TRIMMABLE-BOUNDARY-START(188980723723)
            /*JSMarshalerType*/ static Discard = null;
            //--TRIMMABLE-BOUNDARY-END(188980723723)
            
            //--TRIMMABLE-BOUNDARY-START(193275691019)
            /*JSMarshalerType*/ static DiscardNoWait = null;
            //--TRIMMABLE-BOUNDARY-END(193275691019)
            
            //--TRIMMABLE-BOUNDARY-START(150326018059)
            /*JSMarshalerType*/ static Boolean = null;
            //--TRIMMABLE-BOUNDARY-END(150326018059)
            
            //--TRIMMABLE-BOUNDARY-START(154620985355)
            /*JSMarshalerType*/ static Byte = null;
            //--TRIMMABLE-BOUNDARY-END(154620985355)
            
            //--TRIMMABLE-BOUNDARY-START(158915952651)
            /*JSMarshalerType*/ static Char = null;
            //--TRIMMABLE-BOUNDARY-END(158915952651)
            
            //--TRIMMABLE-BOUNDARY-START(403729088523)
            /*JSMarshalerType*/ static Int16 = null;
            //--TRIMMABLE-BOUNDARY-END(403729088523)
            
            //--TRIMMABLE-BOUNDARY-START(408024055819)
            /*JSMarshalerType*/ static Int32 = null;
            //--TRIMMABLE-BOUNDARY-END(408024055819)
            
            //--TRIMMABLE-BOUNDARY-START(412319023115)
            /*JSMarshalerType*/ static Int52 = null;
            //--TRIMMABLE-BOUNDARY-END(412319023115)
            
            //--TRIMMABLE-BOUNDARY-START(146031050763)
            /*JSMarshalerType*/ static BigInt64 = null;
            //--TRIMMABLE-BOUNDARY-END(146031050763)
            
            //--TRIMMABLE-BOUNDARY-START(197570658315)
            /*JSMarshalerType*/ static Double = null;
            //--TRIMMABLE-BOUNDARY-END(197570658315)
            
            //--TRIMMABLE-BOUNDARY-START(433793859595)
            /*JSMarshalerType*/ static Single = null;
            //--TRIMMABLE-BOUNDARY-END(433793859595)
            
            //--TRIMMABLE-BOUNDARY-START(416613990411)
            /*JSMarshalerType*/ static IntPtr = null;
            //--TRIMMABLE-BOUNDARY-END(416613990411)
            
            //--TRIMMABLE-BOUNDARY-START(420908957707)
            /*JSMarshalerType*/ static JSObject = null;
            //--TRIMMABLE-BOUNDARY-END(420908957707)
            
            //--TRIMMABLE-BOUNDARY-START(429498892299)
            /*JSMarshalerType*/ static Object = null;
            //--TRIMMABLE-BOUNDARY-END(429498892299)
            
            //--TRIMMABLE-BOUNDARY-START(442383794187)
            /*JSMarshalerType*/ static String = null;
            //--TRIMMABLE-BOUNDARY-END(442383794187)
            
            //--TRIMMABLE-BOUNDARY-START(201865625611)
            /*JSMarshalerType*/ static Exception = null;
            //--TRIMMABLE-BOUNDARY-END(201865625611)
            
            //--TRIMMABLE-BOUNDARY-START(180390789131)
            /*JSMarshalerType*/ static DateTime = null;
            //--TRIMMABLE-BOUNDARY-END(180390789131)
            
            //--TRIMMABLE-BOUNDARY-START(184685756427)
            /*JSMarshalerType*/ static DateTimeOffset = null;
            //--TRIMMABLE-BOUNDARY-END(184685756427)
            
            //--TRIMMABLE-BOUNDARY-START(425203925003)
            static /*JSMarshalerType */ Nullable(/*JSMarshalerType*/ primitive)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425203925003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.SRIJ.JSMarshalerType.CheckNullable(primitive);
                return new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                    const $t1 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Type = 19/*MarshalerType.Nullable*/;
                    $i1.ResultMarshalerType = primitive._signatureType.Type;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(425203925003)
            
            //--TRIMMABLE-BOUNDARY-START(12887064587)
            /*JSMarshalerType*/ static _task = null;
            //--TRIMMABLE-BOUNDARY-END(12887064587)
            
            //--TRIMMABLE-BOUNDARY-START(446678761483)
            static /*JSMarshalerType */ Task()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446678761483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.SRIJ.JSMarshalerType._task;
            }
            //--TRIMMABLE-BOUNDARY-END(446678761483)
            
            //--TRIMMABLE-BOUNDARY-START(450973728779)
            static /*JSMarshalerType */ Task$1(/*JSMarshalerType*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450973728779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.SRIJ.JSMarshalerType.CheckTask(result);
                return new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                    const $t2 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Type = 20/*MarshalerType.Task*/;
                    $i2.ResultMarshalerType = result._signatureType.Type;
                    return $i2;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(450973728779)
            
            //--TRIMMABLE-BOUNDARY-START(137441116171)
            static /*JSMarshalerType */ Array(/*JSMarshalerType*/ element)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441116171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.SRIJ.JSMarshalerType.CheckArray(element);
                return new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                    const $t3 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Type = 21/*MarshalerType.Array*/;
                    $i3.Arg1MarshalerType = element._signatureType.Type;
                    return $i3;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(137441116171)
            
            //--TRIMMABLE-BOUNDARY-START(141736083467)
            static /*JSMarshalerType */ ArraySegment(/*JSMarshalerType*/ element)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736083467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.SRIJ.JSMarshalerType.CheckArraySegment(element);
                return new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                    const $t4 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Type = 22/*MarshalerType.ArraySegment*/;
                    $i4.Arg1MarshalerType = element._signatureType.Type;
                    return $i4;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(141736083467)
            
            //--TRIMMABLE-BOUNDARY-START(438088826891)
            static /*JSMarshalerType */ Span(/*JSMarshalerType*/ element)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438088826891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.SRIJ.JSMarshalerType.CheckArraySegment(element);
                return new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                    const $t5 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Type = 23/*MarshalerType.Span*/;
                    $i5.Arg1MarshalerType = element._signatureType.Type;
                    return $i5;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(438088826891)
            
            //--TRIMMABLE-BOUNDARY-START(4297129995)
            /*JSMarshalerType*/ static _action = null;
            //--TRIMMABLE-BOUNDARY-END(4297129995)
            
            //--TRIMMABLE-BOUNDARY-START(120261246987)
            static /*JSMarshalerType */ Action()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261246987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.SRIJ.JSMarshalerType._action;
            }
            //--TRIMMABLE-BOUNDARY-END(120261246987)
            
            //--TRIMMABLE-BOUNDARY-START(133146148875)
            static /*JSMarshalerType */ Action$3(/*JSMarshalerType*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146148875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.SRIJ.JSMarshalerType.CheckTask(arg1);
                return new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                    const $t6 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Type = 24/*MarshalerType.Action*/;
                    $i6.Arg1MarshalerType = arg1._signatureType.Type;
                    return $i6;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(133146148875)
            
            //--TRIMMABLE-BOUNDARY-START(128851181579)
            static /*JSMarshalerType */ Action$2(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851181579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.SRIJ.JSMarshalerType.CheckTask(arg1);
                $.$srij.SRIJ.JSMarshalerType.CheckTask(arg2);
                return new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                    const $t7 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Type = 24/*MarshalerType.Action*/;
                    $i7.Arg1MarshalerType = arg1._signatureType.Type;
                    $i7.Arg2MarshalerType = arg2._signatureType.Type;
                    return $i7;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(128851181579)
            
            //--TRIMMABLE-BOUNDARY-START(124556214283)
            static /*JSMarshalerType */ Action$1(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556214283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.SRIJ.JSMarshalerType.CheckTask(arg1);
                $.$srij.SRIJ.JSMarshalerType.CheckTask(arg2);
                $.$srij.SRIJ.JSMarshalerType.CheckTask(arg3);
                return new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                    const $t8 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Type = 24/*MarshalerType.Action*/;
                    $i8.Arg1MarshalerType = arg1._signatureType.Type;
                    $i8.Arg2MarshalerType = arg2._signatureType.Type;
                    $i8.Arg3MarshalerType = arg3._signatureType.Type;
                    return $i8;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(124556214283)
            
            //--TRIMMABLE-BOUNDARY-START(219045494795)
            static /*JSMarshalerType */ Function$3(/*JSMarshalerType*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045494795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.SRIJ.JSMarshalerType.CheckTask(result);
                return new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                    const $t9 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                    const $i9 = new $t9();
                    $i9.$ctor$2();
                    $i9.Type = 25/*MarshalerType.Function*/;
                    $i9.ResultMarshalerType = result._signatureType.Type;
                    return $i9;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(219045494795)
            
            //--TRIMMABLE-BOUNDARY-START(214750527499)
            static /*JSMarshalerType */ Function$2(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750527499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.SRIJ.JSMarshalerType.CheckTask(arg1);
                $.$srij.SRIJ.JSMarshalerType.CheckTask(result);
                return new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                    const $t10 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                    const $i10 = new $t10();
                    $i10.$ctor$2();
                    $i10.Type = 25/*MarshalerType.Function*/;
                    $i10.Arg1MarshalerType = arg1._signatureType.Type;
                    $i10.ResultMarshalerType = result._signatureType.Type;
                    return $i10;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(214750527499)
            
            //--TRIMMABLE-BOUNDARY-START(210455560203)
            static /*JSMarshalerType */ Function$1(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455560203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.SRIJ.JSMarshalerType.CheckTask(arg1);
                $.$srij.SRIJ.JSMarshalerType.CheckTask(arg2);
                $.$srij.SRIJ.JSMarshalerType.CheckTask(result);
                return new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                    const $t11 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                    const $i11 = new $t11();
                    $i11.$ctor$2();
                    $i11.Type = 25/*MarshalerType.Function*/;
                    $i11.Arg1MarshalerType = arg1._signatureType.Type;
                    $i11.Arg2MarshalerType = arg2._signatureType.Type;
                    $i11.ResultMarshalerType = result._signatureType.Type;
                    return $i11;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(210455560203)
            
            //--TRIMMABLE-BOUNDARY-START(206160592907)
            static /*JSMarshalerType */ Function(/*JSMarshalerType*/ arg1, /*JSMarshalerType*/ arg2, /*JSMarshalerType*/ arg3, /*JSMarshalerType*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160592907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$srij.SRIJ.JSMarshalerType.CheckTask(arg1);
                $.$srij.SRIJ.JSMarshalerType.CheckTask(arg2);
                $.$srij.SRIJ.JSMarshalerType.CheckTask(arg3);
                $.$srij.SRIJ.JSMarshalerType.CheckTask(result);
                return new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                {
                    //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                    const $t12 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                    const $i12 = new $t12();
                    $i12.$ctor$2();
                    $i12.Type = 25/*MarshalerType.Function*/;
                    $i12.Arg1MarshalerType = arg1._signatureType.Type;
                    $i12.Arg2MarshalerType = arg2._signatureType.Type;
                    $i12.Arg3MarshalerType = arg3._signatureType.Type;
                    $i12.ResultMarshalerType = result._signatureType.Type;
                    return $i12;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(206160592907)
            
            //--TRIMMABLE-BOUNDARY-START(171800854539)
            static /*void */ CheckNullable(/*JSMarshalerType*/ underlyingType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800854539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 3/*MarshalerType.Boolean*/ || underlying === 4/*MarshalerType.Byte*/ || underlying === 6/*MarshalerType.Int16*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 9/*MarshalerType.BigInt64*/ || underlying === 8/*MarshalerType.Int52*/ || underlying === 12/*MarshalerType.IntPtr*/ || underlying === 10/*MarshalerType.Double*/ || underlying === 11/*MarshalerType.Single*/ || underlying === 5/*MarshalerType.Char*/ || underlying === 17/*MarshalerType.DateTime*/ || underlying === 18/*MarshalerType.DateTimeOffset*/)
                {
                    return;
                }
                throw new $.$$.S.ArgumentException().$ctor$13($.$srij.S.SR.Format$6($.$srij.S.SR.UnsupportedNullableType, $.$box(underlying, $.$srij.SRIJ.MarshalerType)), "underlyingType");
            }
            //--TRIMMABLE-BOUNDARY-END(171800854539)
            
            //--TRIMMABLE-BOUNDARY-START(163210919947)
            static /*void */ CheckArray(/*JSMarshalerType*/ underlyingType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210919947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 4/*MarshalerType.Byte*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 10/*MarshalerType.Double*/ || underlying === 15/*MarshalerType.String*/ || underlying === 14/*MarshalerType.Object*/ || underlying === 13/*MarshalerType.JSObject*/)
                {
                    return;
                }
                throw new $.$$.S.ArgumentException().$ctor$13($.$srij.S.SR.Format$6($.$srij.S.SR.UnsupportedElementType, $.$box(underlying, $.$srij.SRIJ.MarshalerType)), "underlyingType");
            }
            //--TRIMMABLE-BOUNDARY-END(163210919947)
            
            //--TRIMMABLE-BOUNDARY-START(167505887243)
            static /*void */ CheckArraySegment(/*JSMarshalerType*/ underlyingType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505887243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 4/*MarshalerType.Byte*/ || underlying === 7/*MarshalerType.Int32*/ || underlying === 10/*MarshalerType.Double*/)
                {
                    return;
                }
                throw new $.$$.S.ArgumentException().$ctor$13($.$srij.S.SR.Format$6($.$srij.S.SR.UnsupportedElementType, $.$box(underlying, $.$srij.SRIJ.MarshalerType)), "underlyingType");
            }
            //--TRIMMABLE-BOUNDARY-END(167505887243)
            
            //--TRIMMABLE-BOUNDARY-START(176095821835)
            static /*void */ CheckTask(/*JSMarshalerType*/ underlyingType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095821835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*MarshalerType*/ let underlying = underlyingType._signatureType.Type;
                if (underlying === 21/*MarshalerType.Array*/ || underlying === 22/*MarshalerType.ArraySegment*/ || underlying === 23/*MarshalerType.Span*/ || underlying === 20/*MarshalerType.Task*/ || underlying === 24/*MarshalerType.Action*/ || underlying === 25/*MarshalerType.Function*/)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$srij.S.SR.Format$6($.$srij.S.SR.UnsupportedTaskResultType, $.$box(underlying, $.$srij.SRIJ.MarshalerType)), "underlyingType");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176095821835)
            
            //--TRIMMABLE-BOUNDARY-START(111671312395)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(111671312395)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8592097291)
                this._signatureType = $.$default($.$srij.SRIJ.JSFunctionBinding.JSBindingType);
                //--TRIMMABLE-BOUNDARY-END(8592097291)
                
            }
            //--TRIMMABLE-BOUNDARY-START(107376345099)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376345099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(455268696075)
                    this.Void = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t13 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Type = 1/*MarshalerType.Void*/;
                        return $i13;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(455268696075)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188980723723)
                    this.Discard = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t14 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i14 = new $t14();
                        $i14.$ctor$2();
                        $i14.Type = 2/*MarshalerType.Discard*/;
                        return $i14;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(188980723723)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193275691019)
                    this.DiscardNoWait = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t15 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Type = 26/*MarshalerType.DiscardNoWait*/;
                        return $i15;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(193275691019)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150326018059)
                    this.Boolean = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t16 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i16 = new $t16();
                        $i16.$ctor$2();
                        $i16.Type = 3/*MarshalerType.Boolean*/;
                        return $i16;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(150326018059)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154620985355)
                    this.Byte = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t17 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Type = 4/*MarshalerType.Byte*/;
                        return $i17;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(154620985355)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158915952651)
                    this.Char = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t18 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i18 = new $t18();
                        $i18.$ctor$2();
                        $i18.Type = 5/*MarshalerType.Char*/;
                        return $i18;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(158915952651)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403729088523)
                    this.Int16 = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t19 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Type = 6/*MarshalerType.Int16*/;
                        return $i19;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(403729088523)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408024055819)
                    this.Int32 = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t20 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i20 = new $t20();
                        $i20.$ctor$2();
                        $i20.Type = 7/*MarshalerType.Int32*/;
                        return $i20;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(408024055819)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412319023115)
                    this.Int52 = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t21 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Type = 8/*MarshalerType.Int52*/;
                        return $i21;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(412319023115)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146031050763)
                    this.BigInt64 = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t22 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i22 = new $t22();
                        $i22.$ctor$2();
                        $i22.Type = 9/*MarshalerType.BigInt64*/;
                        return $i22;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(146031050763)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197570658315)
                    this.Double = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t23 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Type = 10/*MarshalerType.Double*/;
                        return $i23;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(197570658315)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433793859595)
                    this.Single = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t24 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i24 = new $t24();
                        $i24.$ctor$2();
                        $i24.Type = 11/*MarshalerType.Single*/;
                        return $i24;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(433793859595)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416613990411)
                    this.IntPtr = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t25 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Type = 12/*MarshalerType.IntPtr*/;
                        return $i25;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(416613990411)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420908957707)
                    this.JSObject = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t26 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i26 = new $t26();
                        $i26.$ctor$2();
                        $i26.Type = 13/*MarshalerType.JSObject*/;
                        return $i26;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(420908957707)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429498892299)
                    this.Object = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t27 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i27 = new $t27();
                        $i27.$ctor$2();
                        $i27.Type = 14/*MarshalerType.Object*/;
                        return $i27;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(429498892299)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442383794187)
                    this.String = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t28 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i28 = new $t28();
                        $i28.$ctor$2();
                        $i28.Type = 15/*MarshalerType.String*/;
                        return $i28;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(442383794187)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201865625611)
                    this.Exception = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t29 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i29 = new $t29();
                        $i29.$ctor$2();
                        $i29.Type = 16/*MarshalerType.Exception*/;
                        return $i29;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(201865625611)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180390789131)
                    this.DateTime = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t30 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i30 = new $t30();
                        $i30.$ctor$2();
                        $i30.Type = 17/*MarshalerType.DateTime*/;
                        return $i30;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(180390789131)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184685756427)
                    this.DateTimeOffset = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t31 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i31 = new $t31();
                        $i31.$ctor$2();
                        $i31.Type = 18/*MarshalerType.DateTimeOffset*/;
                        return $i31;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(184685756427)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12887064587)
                    this._task = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t32 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i32 = new $t32();
                        $i32.$ctor$2();
                        $i32.Type = 20/*MarshalerType.Task*/;
                        return $i32;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(12887064587)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4297129995)
                    this._action = new $.$srij.SRIJ.JSMarshalerType().$ctor$2((() =>
                    {
                        //new $.$srij.SRIJ.JSFunctionBinding.JSBindingType()
                        const $t33 = $.$srij.SRIJ.JSFunctionBinding.JSBindingType;
                        const $i33 = new $t33();
                        $i33.$ctor$2();
                        $i33.Type = 24/*MarshalerType.Action*/;
                        return $i33;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(4297129995)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107376345099)
            
            static $h = 2162699;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(455268696075),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 399434121227,
        "f": 50331681
      },
      "n": "Void",
      "d": 2162699,
      "h": 455268696075,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(455268696075),
//--TRIMMABLE-BOUNDARY-START(188980723723),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296354906123,
        "f": 50331681
      },
      "n": "Discard",
      "d": 2162699,
      "h": 188980723723,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(188980723723),
//--TRIMMABLE-BOUNDARY-START(193275691019),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304944840715,
        "f": 50331681
      },
      "n": "DiscardNoWait",
      "d": 2162699,
      "h": 193275691019,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(193275691019),
//--TRIMMABLE-BOUNDARY-START(150326018059),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253405233163,
        "f": 50331681
      },
      "n": "Boolean",
      "d": 2162699,
      "h": 150326018059,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(150326018059),
//--TRIMMABLE-BOUNDARY-START(154620985355),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261995167755,
        "f": 50331681
      },
      "n": "Byte",
      "d": 2162699,
      "h": 154620985355,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(154620985355),
//--TRIMMABLE-BOUNDARY-START(158915952651),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270585102347,
        "f": 50331681
      },
      "n": "Char",
      "d": 2162699,
      "h": 158915952651,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(158915952651),
//--TRIMMABLE-BOUNDARY-START(403729088523),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 330714644491,
        "f": 50331681
      },
      "n": "Int16",
      "d": 2162699,
      "h": 403729088523,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(403729088523),
//--TRIMMABLE-BOUNDARY-START(408024055819),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 339304579083,
        "f": 50331681
      },
      "n": "Int32",
      "d": 2162699,
      "h": 408024055819,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(408024055819),
//--TRIMMABLE-BOUNDARY-START(412319023115),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 347894513675,
        "f": 50331681
      },
      "n": "Int52",
      "d": 2162699,
      "h": 412319023115,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(412319023115),
//--TRIMMABLE-BOUNDARY-START(146031050763),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244815298571,
        "f": 50331681
      },
      "n": "BigInt64",
      "d": 2162699,
      "h": 146031050763,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(146031050763),
//--TRIMMABLE-BOUNDARY-START(197570658315),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313534775307,
        "f": 50331681
      },
      "n": "Double",
      "d": 2162699,
      "h": 197570658315,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(197570658315),
//--TRIMMABLE-BOUNDARY-START(433793859595),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 382254252043,
        "f": 50331681
      },
      "n": "Single",
      "d": 2162699,
      "h": 433793859595,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(433793859595),
//--TRIMMABLE-BOUNDARY-START(416613990411),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 356484448267,
        "f": 50331681
      },
      "n": "IntPtr",
      "d": 2162699,
      "h": 416613990411,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(416613990411),
//--TRIMMABLE-BOUNDARY-START(420908957707),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 365074382859,
        "f": 50331681
      },
      "n": "JSObject",
      "d": 2162699,
      "h": 420908957707,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(420908957707),
//--TRIMMABLE-BOUNDARY-START(429498892299),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 373664317451,
        "f": 50331681
      },
      "n": "Object",
      "d": 2162699,
      "h": 429498892299,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(429498892299),
//--TRIMMABLE-BOUNDARY-START(442383794187),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 390844186635,
        "f": 50331681
      },
      "n": "String",
      "d": 2162699,
      "h": 442383794187,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(442383794187),
//--TRIMMABLE-BOUNDARY-START(180390789131),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279175036939,
        "f": 50331681
      },
      "n": "DateTime",
      "d": 2162699,
      "h": 180390789131,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(180390789131),
//--TRIMMABLE-BOUNDARY-START(184685756427),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287764971531,
        "f": 50331681
      },
      "n": "DateTimeOffset",
      "d": 2162699,
      "h": 184685756427,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(184685756427),
//--TRIMMABLE-BOUNDARY-START(12887064587),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236225363979,
        "f": 50331682
      },
      "n": "_task",
      "d": 2162699,
      "h": 12887064587,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(12887064587),
//--TRIMMABLE-BOUNDARY-START(4297129995),
    {
      "p": 2162699,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227635429387,
        "f": 50331682
      },
      "n": "_action",
      "d": 2162699,
      "h": 4297129995,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(4297129995)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(425203925003),
    {
      "r": 2162699,
      "p": [
        {
          "n": "primitive",
          "p": 2162699
        }
      ],
      "n": "Nullable",
      "d": 2162699,
      "h": 425203925003,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(425203925003),
//--TRIMMABLE-BOUNDARY-START(446678761483),
    {
      "r": 2162699,
      "n": "Task",
      "d": 2162699,
      "h": 446678761483,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(446678761483),
//--TRIMMABLE-BOUNDARY-START(450973728779),
    {
      "r": 2162699,
      "p": [
        {
          "n": "result",
          "p": 2162699
        }
      ],
      "n": "Task",
      "o": "@$1",
      "d": 2162699,
      "h": 450973728779,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(450973728779),
//--TRIMMABLE-BOUNDARY-START(137441116171),
    {
      "r": 2162699,
      "p": [
        {
          "n": "element",
          "p": 2162699
        }
      ],
      "n": "Array",
      "d": 2162699,
      "h": 137441116171,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(137441116171),
//--TRIMMABLE-BOUNDARY-START(141736083467),
    {
      "r": 2162699,
      "p": [
        {
          "n": "element",
          "p": 2162699
        }
      ],
      "n": "ArraySegment",
      "d": 2162699,
      "h": 141736083467,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(141736083467),
//--TRIMMABLE-BOUNDARY-START(438088826891),
    {
      "r": 2162699,
      "p": [
        {
          "n": "element",
          "p": 2162699
        }
      ],
      "n": "Span",
      "d": 2162699,
      "h": 438088826891,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(438088826891),
//--TRIMMABLE-BOUNDARY-START(120261246987),
    {
      "r": 2162699,
      "n": "Action",
      "d": 2162699,
      "h": 120261246987,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120261246987),
//--TRIMMABLE-BOUNDARY-START(133146148875),
    {
      "r": 2162699,
      "p": [
        {
          "n": "arg1",
          "p": 2162699
        }
      ],
      "n": "Action",
      "o": "@$3",
      "d": 2162699,
      "h": 133146148875,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(133146148875),
//--TRIMMABLE-BOUNDARY-START(128851181579),
    {
      "r": 2162699,
      "p": [
        {
          "n": "arg1",
          "p": 2162699
        },
        {
          "n": "arg2",
          "p": 2162699
        }
      ],
      "n": "Action",
      "o": "@$2",
      "d": 2162699,
      "h": 128851181579,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(128851181579),
//--TRIMMABLE-BOUNDARY-START(124556214283),
    {
      "r": 2162699,
      "p": [
        {
          "n": "arg1",
          "p": 2162699
        },
        {
          "n": "arg2",
          "p": 2162699
        },
        {
          "n": "arg3",
          "p": 2162699
        }
      ],
      "n": "Action",
      "o": "@$1",
      "d": 2162699,
      "h": 124556214283,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124556214283),
//--TRIMMABLE-BOUNDARY-START(219045494795),
    {
      "r": 2162699,
      "p": [
        {
          "n": "result",
          "p": 2162699
        }
      ],
      "n": "Function",
      "o": "@$3",
      "d": 2162699,
      "h": 219045494795,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(219045494795),
//--TRIMMABLE-BOUNDARY-START(214750527499),
    {
      "r": 2162699,
      "p": [
        {
          "n": "arg1",
          "p": 2162699
        },
        {
          "n": "result",
          "p": 2162699
        }
      ],
      "n": "Function",
      "o": "@$2",
      "d": 2162699,
      "h": 214750527499,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(214750527499),
//--TRIMMABLE-BOUNDARY-START(210455560203),
    {
      "r": 2162699,
      "p": [
        {
          "n": "arg1",
          "p": 2162699
        },
        {
          "n": "arg2",
          "p": 2162699
        },
        {
          "n": "result",
          "p": 2162699
        }
      ],
      "n": "Function",
      "o": "@$1",
      "d": 2162699,
      "h": 210455560203,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(210455560203),
//--TRIMMABLE-BOUNDARY-START(206160592907),
    {
      "r": 2162699,
      "p": [
        {
          "n": "arg1",
          "p": 2162699
        },
        {
          "n": "arg2",
          "p": 2162699
        },
        {
          "n": "arg3",
          "p": 2162699
        },
        {
          "n": "result",
          "p": 2162699
        }
      ],
      "n": "Function",
      "d": 2162699,
      "h": 206160592907,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(206160592907),
//--TRIMMABLE-BOUNDARY-START(171800854539),
    {
      "r": 65537,
      "p": [
        {
          "n": "underlyingType",
          "p": 2162699
        }
      ],
      "n": "CheckNullable",
      "d": 2162699,
      "h": 171800854539,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(171800854539),
//--TRIMMABLE-BOUNDARY-START(163210919947),
    {
      "r": 65537,
      "p": [
        {
          "n": "underlyingType",
          "p": 2162699
        }
      ],
      "n": "CheckArray",
      "d": 2162699,
      "h": 163210919947,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(163210919947),
//--TRIMMABLE-BOUNDARY-START(167505887243),
    {
      "r": 65537,
      "p": [
        {
          "n": "underlyingType",
          "p": 2162699
        }
      ],
      "n": "CheckArraySegment",
      "d": 2162699,
      "h": 167505887243,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(167505887243),
//--TRIMMABLE-BOUNDARY-START(176095821835),
    {
      "r": 65537,
      "p": [
        {
          "n": "underlyingType",
          "p": 2162699
        }
      ],
      "n": "CheckTask",
      "d": 2162699,
      "h": 176095821835,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(176095821835)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592097291),
    {
      "t": 655371,
      "n": "_signatureType",
      "d": 2162699,
      "h": 8592097291,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8592097291)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(111671312395),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162699,
      "h": 111671312395,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(111671312395),
//--TRIMMABLE-BOUNDARY-START(115966279691),
    {
      "p": [
        {
          "n": "signatureType",
          "p": 655371
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2162699,
      "h": 115966279691,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115966279691)
  ],
  "h": 2162699,
  "a": [
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalerType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalerType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162699)
        
        

        //--TRIMMABLE-BOUNDARY-START(262155)
        $asm.$cls(`$srij.SRIJ.JavaScriptExports`, ($self) => class JavaScriptExports
        {
            //--TRIMMABLE-BOUNDARY-START(12885164043)
            static /*void */ CallEntrypoint(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                /*ref JSMarshalerArgument*/ let arg_3 = arguments_buffer.Add(4);
                try
                {
                    /*IntPtr*/ let assemblyNamePtr;
                    /*string?[]?*/ let args;
                    /*bool*/ let waitForDebugger;
                    arg_1.$v.ToManaged$17($.$ref(() => assemblyNamePtr, ($v) => assemblyNamePtr = $v, $.$$.S.IntPtr));
                    arg_2.$v.ToManaged$38($.$ref(() => args, ($v) => args = $v, $.$typeArray($.$$.S.String)));
                    arg_3.$v.ToManaged$4($.$ref(() => waitForDebugger, ($v) => waitForDebugger = $v, $.$$.S.Boolean));
                    /*Task<int>?*/ let result = $.$srij.SRIJ.JSHostImplementation.CallEntrypoint(assemblyNamePtr, args, waitForDebugger);
                    arg_res.$v.ToJS$43($.$$.S.Int32, result, new ($.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$($.$$.S.Int32))().$ctor(this,  (/*JSMarshalerArgument*/ arg, /*int*/ value) =>
                    {
                        arg.$v.ToJS$14(value);
                    }, $pTeAnd ??= {"r":65537,"p":[{"n":"arg","p":1310731,"f":4},{"n":"value","p":655361}],"n":"","d":262155,"h":0,"f":17825794}));
                }
                catch(ex)
                {
                    $.$$.S.Environment.FailFast$2(`CallEntrypoint: Unexpected synchronous failure (ManagedThreadId ${$.$strNN($.$$.S.Environment.CurrentManagedThreadId)}): ` + $.$strNN(ex.ToString()));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885164043)
            
            //--TRIMMABLE-BOUNDARY-START(30065033227)
            static /*void */ LoadLazyAssembly(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                try
                {
                    /*byte[]?*/ let dllBytes;
                    /*byte[]?*/ let pdbBytes;
                    arg_1.$v.ToManaged$6($.$ref(() => dllBytes, ($v) => dllBytes = $v, $.$typeArray($.$$.S.Byte)));
                    arg_2.$v.ToManaged$6($.$ref(() => pdbBytes, ($v) => pdbBytes = $v, $.$typeArray($.$$.S.Byte)));
                    if (dllBytes !== null)
                    {
                        $.$srij.SRIJ.JSHostImplementation.LoadLazyAssembly(dllBytes, pdbBytes);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$12(ex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065033227)
            
            //--TRIMMABLE-BOUNDARY-START(34360000523)
            static /*void */ LoadSatelliteAssembly(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*byte[]?*/ let dllBytes;
                    arg_1.$v.ToManaged$6($.$ref(() => dllBytes, ($v) => dllBytes = $v, $.$typeArray($.$$.S.Byte)));
                    if (dllBytes !== null)
                    {
                        $.$srij.SRIJ.JSHostImplementation.LoadSatelliteAssembly(dllBytes);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$12(ex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360000523)
            
            //--TRIMMABLE-BOUNDARY-START(38654967819)
            static /*void */ ReleaseJSOwnedObjectByGCHandle(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*var*/ let ctx = arg_exc.$v.ToManagedContext;
                    ctx.ReleaseJSOwnedObjectByGCHandle(arg_1.$v.slot.GCHandle);
                }
                catch(ex)
                {
                    $.$$.S.Environment.FailFast$2(`ReleaseJSOwnedObjectByGCHandle: Unexpected synchronous failure (ManagedThreadId ${$.$strNN($.$$.S.Environment.CurrentManagedThreadId)}): ` + $.$strNN(ex.ToString()));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654967819)
            
            //--TRIMMABLE-BOUNDARY-START(8590196747)
            static /*void */ CallDelegate(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*GCHandle*/ let callback_gc_handle = $.$$.SRI.GCHandle.op_Explicit$1(arg_1.$v.slot.GCHandle);
                    let callback;
                    if ($.$is(callback_gc_handle.Target, $.$srij.SRIJ.JSHostImplementation.ToManagedCallback, { set $v($v){ callback = $v; } }))
                    {
                        callback.Invoke(arguments_buffer);
                    }
                    else 
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$srij.S.SR.NullToManagedCallback);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$12(ex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590196747)
            
            //--TRIMMABLE-BOUNDARY-START(17180131339)
            static /*void */ CompleteTask(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*var*/ let ctx = arg_exc.$v.ToManagedContext;
                    /*var*/ let holder = ctx.GetPromiseHolder(arg_1.$v.slot.GCHandle);
                    /*JSHostImplementation.ToManagedCallback*/ let callback;
                    callback = holder.Callback;
                    ctx.ReleasePromiseHolder(arg_1.$v.slot.GCHandle);
                    callback.Invoke(arguments_buffer);
                }
                catch(ex)
                {
                    $.$$.S.Environment.FailFast$2(`CompleteTask: Unexpected synchronous failure (ManagedThreadId ${$.$strNN($.$$.S.Environment.CurrentManagedThreadId)}): ` + $.$strNN(ex.ToString()));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180131339)
            
            //--TRIMMABLE-BOUNDARY-START(25770065931)
            static /*void */ GetManagedStackTrace(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770065931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    arg_exc.$v.AssertCurrentThreadContext();
                    /*GCHandle*/ let exception_gc_handle = $.$$.SRI.GCHandle.op_Explicit$1(arg_1.$v.slot.GCHandle);
                    let exception;
                    if ($.$is(exception_gc_handle.Target, $.$$.S.Exception, { set $v($v){ exception = $v; } }))
                    {
                        arg_res.$v.ToJS$37(exception.StackTrace);
                    }
                    else 
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$srij.S.SR.UnableToResolveHandleAsException);
                    }
                }
                catch(ex)
                {
                    arg_exc.$v.ToJS$12(ex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770065931)
            
            //--TRIMMABLE-BOUNDARY-START(4295229451)
            static /*void */ BindAssemblyExports(/*JSMarshalerArgument**/ arguments_buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref JSMarshalerArgument*/ let arg_exc = arguments_buffer.Add(0);
                /*ref JSMarshalerArgument*/ let arg_res = arguments_buffer.Add(1);
                /*ref JSMarshalerArgument*/ let arg_1 = arguments_buffer.Add(2);
                try
                {
                    /*string?*/ let assemblyName;
                    arg_exc.$v.AssertCurrentThreadContext();
                    arg_1.$v.ToManaged$37($.$ref(() => assemblyName, ($v) => assemblyName = $v, $.$$.S.String));
                    /*var*/ let result = $.$srij.SRIJ.JSHostImplementation.BindAssemblyExports(assemblyName);
                    arg_res.$v.ToJS$39(result);
                }
                catch(ex)
                {
                    $.$$.S.Environment.FailFast$2(`BindAssemblyExports: Unexpected synchronous failure (ManagedThreadId ${$.$strNN($.$$.S.Environment.CurrentManagedThreadId)}): ` + $.$strNN(ex.ToString()));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295229451)
            
            //--TRIMMABLE-BOUNDARY-START(42949935115)
            static /*void */ StopProfile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949935115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42949935115)
            
            //--TRIMMABLE-BOUNDARY-START(21475098635)
            static /*void */ DumpAotProfileData(/*ref byte*/ buf, /*int*/ len, /*string*/ extraArg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (len === 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$srij.S.SR.EmptyProfileData);
                }
                /*fixed*/ 
                {
                    /*void**/ let p = buf;
                    /*var*/ let span = new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$4(p, len);
                    /*var*/ let module = $.$srij.SRIJ.JSHost.DotnetInstance.GetPropertyAsJSObject("INTERNAL");
                    if (module === null)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$9();
                    }
                    module.SetProperty$1("aotProfileData", span.ToArray());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475098635)
            
            static $h = 262155;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885164043),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "CallEntrypoint",
      "d": 262155,
      "h": 12885164043,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885164043),
//--TRIMMABLE-BOUNDARY-START(30065033227),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "LoadLazyAssembly",
      "d": 262155,
      "h": 30065033227,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065033227),
//--TRIMMABLE-BOUNDARY-START(34360000523),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "LoadSatelliteAssembly",
      "d": 262155,
      "h": 34360000523,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360000523),
//--TRIMMABLE-BOUNDARY-START(38654967819),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "ReleaseJSOwnedObjectByGCHandle",
      "d": 262155,
      "h": 38654967819,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654967819),
//--TRIMMABLE-BOUNDARY-START(8590196747),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "CallDelegate",
      "d": 262155,
      "h": 8590196747,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590196747),
//--TRIMMABLE-BOUNDARY-START(17180131339),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "CompleteTask",
      "d": 262155,
      "h": 17180131339,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180131339),
//--TRIMMABLE-BOUNDARY-START(25770065931),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "GetManagedStackTrace",
      "d": 262155,
      "h": 25770065931,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770065931),
//--TRIMMABLE-BOUNDARY-START(4295229451),
    {
      "r": 65537,
      "p": [
        {
          "n": "arguments_buffer",
          "p": $.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h
        }
      ],
      "n": "BindAssemblyExports",
      "d": 262155,
      "h": 4295229451,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295229451),
//--TRIMMABLE-BOUNDARY-START(42949935115),
    {
      "r": 65537,
      "n": "StopProfile",
      "d": 262155,
      "h": 42949935115,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949935115),
//--TRIMMABLE-BOUNDARY-START(21475098635),
    {
      "r": 65537,
      "p": [
        {
          "n": "buf",
          "p": 393217,
          "f": 4
        },
        {
          "n": "len",
          "p": 655361
        },
        {
          "n": "extraArg",
          "p": 1310721
        }
      ],
      "n": "DumpAotProfileData",
      "d": 262155,
      "h": 21475098635,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475098635)
  ],
  "h": 262155
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JavaScriptExports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JavaScriptExports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262155)
        
        

        //--TRIMMABLE-BOUNDARY-START(2228235)
        $asm.$cls(`$srij.SRIJ.JSObject`, ($self) => class JSObject extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592162827)
            $ctor$1()
            {
                this.$ctor$2($.$$.S.IntPtr.Zero, $.$srij.SRIJ.JSProxyContext.MainThreadContext);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592162827);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592162827)
            
            //--TRIMMABLE-BOUNDARY-START(98786476043)
            /*nint*/ JSHandle = 0;
            //--TRIMMABLE-BOUNDARY-END(98786476043)
            
            //--TRIMMABLE-BOUNDARY-START(103081443339)
            /*JSProxyContext*/ ProxyContext = null;
            //--TRIMMABLE-BOUNDARY-END(103081443339)
            
            //--TRIMMABLE-BOUNDARY-START(133146214411)
            /*SynchronizationContext */ get SynchronizationContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541835787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(133146214411)
            
            //--TRIMMABLE-BOUNDARY-START(4297195531)
            /*bool*/ _isDisposed = false;
            //--TRIMMABLE-BOUNDARY-END(4297195531)
            
            //--TRIMMABLE-BOUNDARY-START(12887130123)
            $ctor$2(/*IntPtr*/ jsHandle, /*JSProxyContext*/ ctx)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887130123);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ProxyContext = ctx;
                    this.JSHandle = jsHandle;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887130123)
            
            //--TRIMMABLE-BOUNDARY-START(30066999307)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066999307);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$srij.SRIJ.JSObject, { set $v($v){ other = $v; } }) && this.JSHandle === other.JSHandle;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066999307)
            
            //--TRIMMABLE-BOUNDARY-START(55836803083)
            /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836803083);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.JSHandle;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55836803083)
            
            //--TRIMMABLE-BOUNDARY-START(137441181707)
            /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137441181707);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return `(js-obj js '${$.$strNN(this.JSHandle)}')`;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137441181707)
            
            //--TRIMMABLE-BOUNDARY-START(17182097419)
            /*void */ AssertNotDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182097419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    $.$$.S.ObjectDisposedException.ThrowIf(this.IsDisposed, this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182097419)
            
            //--TRIMMABLE-BOUNDARY-START(25772032011)
            /*void */ DisposeImpl(/*bool*/ skipJsCleanup)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772032011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._isDisposed)
                {
                    $.$srij.SRIJ.JSProxyContext.ReleaseCSOwnedObject(this, skipJsCleanup);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772032011)
            
            $dtor()
            {
                this.DisposeImpl(false);
            }
            //--TRIMMABLE-BOUNDARY-START(21477064715)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477064715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.DisposeImpl(false);
            }
            //--TRIMMABLE-BOUNDARY-END(21477064715)
            
            //--TRIMMABLE-BOUNDARY-START(94491508747)
            /*bool */ get IsDisposed()
            {
                return this._isDisposed;
            }
            //--TRIMMABLE-BOUNDARY-END(94491508747)
            
            //--TRIMMABLE-BOUNDARY-START(90196541451)
            /*bool */ HasProperty(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196541451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return propertyName in this;
            }
            //--TRIMMABLE-BOUNDARY-END(90196541451)
            
            //--TRIMMABLE-BOUNDARY-START(85901574155)
            /*string */ GetTypeOfProperty(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901574155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return typeof this[propertyName];
            }
            //--TRIMMABLE-BOUNDARY-END(85901574155)
            
            //--TRIMMABLE-BOUNDARY-START(60131770379)
            /*bool */ GetPropertyAsBoolean(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131770379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return this[propertyName];
            }
            //--TRIMMABLE-BOUNDARY-END(60131770379)
            
            //--TRIMMABLE-BOUNDARY-START(73016672267)
            /*int */ GetPropertyAsInt32(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016672267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return this[propertyName];
            }
            //--TRIMMABLE-BOUNDARY-END(73016672267)
            
            //--TRIMMABLE-BOUNDARY-START(68721704971)
            /*double */ GetPropertyAsDouble(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721704971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return this[propertyName];
            }
            //--TRIMMABLE-BOUNDARY-END(68721704971)
            
            //--TRIMMABLE-BOUNDARY-START(81606606859)
            /*string? */ GetPropertyAsString(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606606859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return this[propertyName];
            }
            //--TRIMMABLE-BOUNDARY-END(81606606859)
            
            //--TRIMMABLE-BOUNDARY-START(77311639563)
            /*JSObject? */ GetPropertyAsJSObject(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311639563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return this[propertyName];
            }
            //--TRIMMABLE-BOUNDARY-END(77311639563)
            
            //--TRIMMABLE-BOUNDARY-START(64426737675)
            /*byte[]? */ GetPropertyAsByteArray(/*string*/ propertyName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426737675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                return this[propertyName];
            }
            //--TRIMMABLE-BOUNDARY-END(64426737675)
            
            //--TRIMMABLE-BOUNDARY-START(107376410635)
            /*void */ SetProperty(/*string*/ propertyName, /*bool*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376410635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                this[propertyName] = value;
            }
            //--TRIMMABLE-BOUNDARY-END(107376410635)
            
            //--TRIMMABLE-BOUNDARY-START(120261312523)
            /*void */ SetProperty$3(/*string*/ propertyName, /*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261312523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                this[propertyName] = value;
            }
            //--TRIMMABLE-BOUNDARY-END(120261312523)
            
            //--TRIMMABLE-BOUNDARY-START(115966345227)
            /*void */ SetProperty$2(/*string*/ propertyName, /*double*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966345227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                this[propertyName] = value;
            }
            //--TRIMMABLE-BOUNDARY-END(115966345227)
            
            //--TRIMMABLE-BOUNDARY-START(124556279819)
            /*void */ SetProperty$4(/*string*/ propertyName, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556279819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                this[propertyName] = value;
            }
            //--TRIMMABLE-BOUNDARY-END(124556279819)
            
            //--TRIMMABLE-BOUNDARY-START(128851247115)
            /*void */ SetProperty$5(/*string*/ propertyName, /*JSObject?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851247115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                this[propertyName] = value;
            }
            //--TRIMMABLE-BOUNDARY-END(128851247115)
            
            //--TRIMMABLE-BOUNDARY-START(111671377931)
            /*void */ SetProperty$1(/*string*/ propertyName, /*byte[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671377931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AssertNotDisposed();
                this[propertyName] = value;
            }
            //--TRIMMABLE-BOUNDARY-END(111671377931)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(8592162827)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8592162827)
            
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 2228235;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133146214411),
    {
      "p": 176095233,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541835787,
        "f": 50331649
      },
      "n": "SynchronizationContext",
      "d": 2228235,
      "h": 133146214411,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133146214411),
//--TRIMMABLE-BOUNDARY-START(94491508747),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951901195,
        "f": 50331649
      },
      "n": "IsDisposed",
      "d": 2228235,
      "h": 94491508747,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94491508747)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066999307),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2228235,
      "h": 30066999307,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066999307),
//--TRIMMABLE-BOUNDARY-START(55836803083),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2228235,
      "h": 55836803083,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55836803083),
//--TRIMMABLE-BOUNDARY-START(137441181707),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2228235,
      "h": 137441181707,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(137441181707),
//--TRIMMABLE-BOUNDARY-START(17182097419),
    {
      "r": 65537,
      "n": "AssertNotDisposed",
      "d": 2228235,
      "h": 17182097419,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17182097419),
//--TRIMMABLE-BOUNDARY-START(25772032011),
    {
      "r": 65537,
      "p": [
        {
          "n": "skipJsCleanup",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "DisposeImpl",
      "d": 2228235,
      "h": 25772032011,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25772032011),
//--TRIMMABLE-BOUNDARY-START(21477064715),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2228235,
      "h": 21477064715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477064715),
//--TRIMMABLE-BOUNDARY-START(90196541451),
    {
      "r": 262145,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "HasProperty",
      "d": 2228235,
      "h": 90196541451,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90196541451),
//--TRIMMABLE-BOUNDARY-START(85901574155),
    {
      "r": 1310721,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetTypeOfProperty",
      "d": 2228235,
      "h": 85901574155,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85901574155),
//--TRIMMABLE-BOUNDARY-START(60131770379),
    {
      "r": 262145,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsBoolean",
      "d": 2228235,
      "h": 60131770379,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131770379),
//--TRIMMABLE-BOUNDARY-START(73016672267),
    {
      "r": 655361,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsInt32",
      "d": 2228235,
      "h": 73016672267,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016672267),
//--TRIMMABLE-BOUNDARY-START(68721704971),
    {
      "r": 1179649,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsDouble",
      "d": 2228235,
      "h": 68721704971,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721704971),
//--TRIMMABLE-BOUNDARY-START(81606606859),
    {
      "r": 1310721,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsString",
      "d": 2228235,
      "h": 81606606859,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81606606859),
//--TRIMMABLE-BOUNDARY-START(77311639563),
    {
      "r": 2228235,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsJSObject",
      "d": 2228235,
      "h": 77311639563,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311639563),
//--TRIMMABLE-BOUNDARY-START(64426737675),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyAsByteArray",
      "d": 2228235,
      "h": 64426737675,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426737675),
//--TRIMMABLE-BOUNDARY-START(107376410635),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "SetProperty",
      "d": 2228235,
      "h": 107376410635,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107376410635),
//--TRIMMABLE-BOUNDARY-START(120261312523),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "SetProperty",
      "o": "@$3",
      "d": 2228235,
      "h": 120261312523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120261312523),
//--TRIMMABLE-BOUNDARY-START(115966345227),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "SetProperty",
      "o": "@$2",
      "d": 2228235,
      "h": 115966345227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115966345227),
//--TRIMMABLE-BOUNDARY-START(124556279819),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "SetProperty",
      "o": "@$4",
      "d": 2228235,
      "h": 124556279819,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124556279819),
//--TRIMMABLE-BOUNDARY-START(128851247115),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 2228235
        }
      ],
      "n": "SetProperty",
      "o": "@$5",
      "d": 2228235,
      "h": 128851247115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128851247115),
//--TRIMMABLE-BOUNDARY-START(111671377931),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "SetProperty",
      "o": "@$1",
      "d": 2228235,
      "h": 111671377931,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111671377931)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(98786476043),
    {
      "t": 786433,
      "n": "JSHandle",
      "d": 2228235,
      "h": 98786476043,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(98786476043),
//--TRIMMABLE-BOUNDARY-START(103081443339),
    {
      "t": 2293771,
      "n": "ProxyContext",
      "d": 2228235,
      "h": 103081443339,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(103081443339),
//--TRIMMABLE-BOUNDARY-START(4297195531),
    {
      "t": 262145,
      "n": "_isDisposed",
      "d": 2228235,
      "h": 4297195531,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4297195531)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592162827),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2228235,
      "h": 8592162827,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592162827),
//--TRIMMABLE-BOUNDARY-START(12887130123),
    {
      "p": [
        {
          "n": "jsHandle",
          "p": 786433
        },
        {
          "n": "ctx",
          "p": 2293771
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2228235,
      "h": 12887130123,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12887130123)
  ],
  "h": 2228235,
  "a": [
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSObject`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSObject`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228235)
        
        

        //--TRIMMABLE-BOUNDARY-START(2293771)
        $asm.$cls(`$srij.SRIJ.JSProxyContext`, ($self) => class JSProxyContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297261067)
            /*bool*/ _isDisposed = false;
            //--TRIMMABLE-BOUNDARY-END(4297261067)
            
            //--TRIMMABLE-BOUNDARY-START(128851312651)
            /*Dictionary<nint, WeakReference<JSObject>>*/ ThreadCsOwnedObjects = null;
            //--TRIMMABLE-BOUNDARY-END(128851312651)
            
            //--TRIMMABLE-BOUNDARY-START(137441247243)
            /*Dictionary<object, nint>*/ ThreadJsOwnedObjects = null;
            //--TRIMMABLE-BOUNDARY-END(137441247243)
            
            //--TRIMMABLE-BOUNDARY-START(133146279947)
            /*Dictionary<nint, PromiseHolder>*/ ThreadJsOwnedHolders = null;
            //--TRIMMABLE-BOUNDARY-END(133146279947)
            
            //--TRIMMABLE-BOUNDARY-START(107376476171)
            /*nint*/ NextJSVHandle = -2;
            //--TRIMMABLE-BOUNDARY-END(107376476171)
            
            //--TRIMMABLE-BOUNDARY-START(98786541579)
            /*List<nint>*/ JSVHandleFreeList = null;
            //--TRIMMABLE-BOUNDARY-END(98786541579)
            
            //--TRIMMABLE-BOUNDARY-START(12887195659)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887195659);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887195659)
            
            //--TRIMMABLE-BOUNDARY-START(85901639691)
            /*bool */ IsCurrentThread()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85901639691);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85901639691)
            
            //--TRIMMABLE-BOUNDARY-START(103081508875)
            /*JSProxyContext*/ static MainThreadContext = null;
            //--TRIMMABLE-BOUNDARY-END(103081508875)
            
            //--TRIMMABLE-BOUNDARY-START(38656999435)
            static /*JSProxyContext */ get CurrentThreadContext()
            {
                return $.$srij.SRIJ.JSProxyContext.MainThreadContext;
            }
            //--TRIMMABLE-BOUNDARY-END(38656999435)
            
            //--TRIMMABLE-BOUNDARY-START(34362032139)
            static /*JSProxyContext */ get CurrentOperationContext()
            {
                return $.$srij.SRIJ.JSProxyContext.MainThreadContext;
            }
            //--TRIMMABLE-BOUNDARY-END(34362032139)
            
            //--TRIMMABLE-BOUNDARY-START(111671443467)
            static /*JSProxyContext */ PushOperationWithCurrentThreadContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671443467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.SRIJ.JSProxyContext.MainThreadContext;
            }
            //--TRIMMABLE-BOUNDARY-END(111671443467)
            
            //--TRIMMABLE-BOUNDARY-START(21477130251)
            static /*JSProxyContext */ AssertIsInteropThread()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477130251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.SRIJ.JSProxyContext.MainThreadContext;
            }
            //--TRIMMABLE-BOUNDARY-END(21477130251)
            
            //--TRIMMABLE-BOUNDARY-START(94491574283)
            static /*bool */ IsJSVHandle(/*nint*/ jsHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491574283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return jsHandle < -1;
            }
            //--TRIMMABLE-BOUNDARY-END(94491574283)
            
            //--TRIMMABLE-BOUNDARY-START(90196606987)
            static /*bool */ IsGCVHandle(/*nint*/ gcHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196606987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return gcHandle < -1;
            }
            //--TRIMMABLE-BOUNDARY-END(90196606987)
            
            //--TRIMMABLE-BOUNDARY-START(17182162955)
            /*nint */ AllocJSVHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182162955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    $.$$.S.ObjectDisposedException.ThrowIf(this._isDisposed, this);
                    if (this.JSVHandleFreeList.Count > 0)
                    {
                        /*var*/ let jsvHandle = this.JSVHandleFreeList.get_Item(((this.JSVHandleFreeList.Count - 1) | 0));
                        this.JSVHandleFreeList.RemoveAt(((this.JSVHandleFreeList.Count - 1) | 0));
                        return jsvHandle;
                    }
                    return this.NextJSVHandle--;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182162955)
            
            //--TRIMMABLE-BOUNDARY-START(55836868619)
            /*void */ FreeJSVHandle(/*nint*/ jsvHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836868619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    this.JSVHandleFreeList.Add(jsvHandle);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55836868619)
            
            //--TRIMMABLE-BOUNDARY-START(77311705099)
            /*IntPtr */ GetJSOwnedObjectGCHandle(/*object*/ obj, /*GCHandleType*/ handleType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311705099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (obj === null)
                {
                    return $.$$.S.IntPtr.Zero;
                }
                {
                    /*IntPtr*/ let gcHandle;
                    if (this.ThreadJsOwnedObjects.TryGetValue(obj, $.$ref(() => gcHandle, ($v) => gcHandle = $v, $.$$.S.IntPtr)))
                    {
                        return gcHandle;
                    }
                    /*IntPtr*/ let result = $.$$.SRI.GCHandle.op_Explicit($.$$.SRI.GCHandle.Alloc(obj, handleType));
                    this.ThreadJsOwnedObjects.set_Item(obj, result);
                    return result;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77311705099)
            
            //--TRIMMABLE-BOUNDARY-START(30067064843)
            /*PromiseHolder */ CreatePromiseHolder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067064843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    return new $.$srij.SRIJ.JSHostImplementation.PromiseHolder().$ctor$2(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30067064843)
            
            //--TRIMMABLE-BOUNDARY-START(81606672395)
            /*PromiseHolder */ GetPromiseHolder(/*nint*/ gcHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606672395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    /*PromiseHolder?*/ let holder;
                    if ($.$srij.SRIJ.JSProxyContext.IsGCVHandle(gcHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.TryGetValue(gcHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.SRIJ.JSHostImplementation.PromiseHolder)))
                        {
                            holder = new $.$srij.SRIJ.JSHostImplementation.PromiseHolder().$ctor$1(this, gcHandle);
                            this.ThreadJsOwnedHolders.Add(gcHandle, holder);
                        }
                    }
                    else 
                    {
                        holder = $.$cast(($.$$.SRI.GCHandle.op_Explicit$1(gcHandle)).Target, $.$srij.SRIJ.JSHostImplementation.PromiseHolder);
                    }
                    return holder;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81606672395)
            
            //--TRIMMABLE-BOUNDARY-START(124556345355)
            /*void */ ReleasePromiseHolder(/*nint*/ holderGCHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556345355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    /*PromiseHolder?*/ let holder;
                    if ($.$srij.SRIJ.JSProxyContext.IsGCVHandle(holderGCHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.Remove(holderGCHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.SRIJ.JSHostImplementation.PromiseHolder)))
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12("ReleasePromiseHolder expected PromiseHolder " + holderGCHandle);
                        }
                        holder.IsDisposed = true;
                    }
                    else 
                    {
                        /*GCHandle*/ let handle = $.$$.SRI.GCHandle.op_Explicit$1(holderGCHandle);
                        /*var*/ let target = handle.Target;
                        let holder2;
                        if ($.$is(target, $.$srij.SRIJ.JSHostImplementation.PromiseHolder, { set $v($v){ holder2 = $v; } }))
                        {
                            holder = holder2;
                        }
                        else 
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12("ReleasePromiseHolder expected PromiseHolder" + holderGCHandle);
                        }
                        holder.IsDisposed = true;
                        handle.Free();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124556345355)
            
            //--TRIMMABLE-BOUNDARY-START(120261378059)
            /*void */ ReleaseJSOwnedObjectByGCHandle(/*nint*/ gcHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261378059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ToManagedCallback?*/ let holderCallback = null;
                {
                    /*PromiseHolder?*/ let holder = null;
                    if ($.$srij.SRIJ.JSProxyContext.IsGCVHandle(gcHandle))
                    {
                        if (!this.ThreadJsOwnedHolders.Remove(gcHandle, $.$ref(() => holder, ($v) => holder = $v, $.$srij.SRIJ.JSHostImplementation.PromiseHolder)))
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12("ReleaseJSOwnedObjectByGCHandle expected in ThreadJsOwnedHolders");
                        }
                    }
                    else 
                    {
                        /*GCHandle*/ let handle = $.$$.SRI.GCHandle.op_Explicit$1(gcHandle);
                        /*var*/ let target = handle.Target;
                        let holder2;
                        if ($.$is(target, $.$srij.SRIJ.JSHostImplementation.PromiseHolder, { set $v($v){ holder2 = $v; } }))
                        {
                            holder = holder2;
                        }
                        else 
                        {
                            if (!this.ThreadJsOwnedObjects.Remove$1(target))
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$12("ReleaseJSOwnedObjectByGCHandle expected in ThreadJsOwnedObjects");
                            }
                        }
                        handle.Free();
                    }
                    if (holder !== null)
                    {
                        holderCallback = holder.Callback;
                        holder.IsDisposed = true;
                    }
                }
                holderCallback?.Invoke(null);
            }
            //--TRIMMABLE-BOUNDARY-END(120261378059)
            
            //--TRIMMABLE-BOUNDARY-START(25772097547)
            /*JSObject */ CreateCSOwnedProxy(/*nint*/ jsHandle)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772097547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    /*WeakReference<JSObject>?*/ let reference;
                    /*JSObject?*/ let res;
                    if (!this.ThreadCsOwnedObjects.TryGetValue(jsHandle, $.$ref(() => reference, ($v) => reference = $v, $.$$.S.WeakReference$$($.$srij.SRIJ.JSObject))) || !reference.TryGetTarget($.$ref(() => res, ($v) => res = $v, $.$srij.SRIJ.JSObject)) || res.IsDisposed)
                    {
                        res = new $.$srij.SRIJ.JSObject().$ctor$2(jsHandle, this);
                        this.ThreadCsOwnedObjects.set_Item(jsHandle, new ($.$$.S.WeakReference$$($.$srij.SRIJ.JSObject))().$ctor$2(res, true));
                    }
                    return res;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772097547)
            
            //--TRIMMABLE-BOUNDARY-START(115966410763)
            static /*void */ ReleaseCSOwnedObject(/*JSObject*/ jso, /*bool*/ skipJS)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966410763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jso.IsDisposed)
                {
                    return;
                }
                /*var*/ let ctx = jso.ProxyContext;
                {
                    if (jso.IsDisposed || ctx._isDisposed)
                    {
                        return;
                    }
                    /*var*/ let jsHandle = jso.JSHandle;
                    jso._isDisposed = true;
                    jso.JSHandle = $.$$.S.IntPtr.Zero;
                    $.$$.S.GC.SuppressFinalize(jso);
                    if (!ctx.ThreadCsOwnedObjects.Remove$1(jsHandle))
                    {
                        $.$$.S.Environment.FailFast$2(`ReleaseCSOwnedObject expected to find registration for JSHandle: ${$.$strNN(jsHandle)}, ManagedThreadId: ${$.$strNN($.$$.S.Environment.CurrentManagedThreadId)}. ${$.$strNN($.$$.S.Environment.NewLine)} ${$.$strNN($.$$.S.Environment.StackTrace)}`);
                    }
                    if (!skipJS)
                    {
                        $.$srij.Interop.Runtime.ReleaseCSOwnedObject(jsHandle);
                    }
                    if ($.$srij.SRIJ.JSProxyContext.IsJSVHandle(jsHandle))
                    {
                        ctx.FreeJSVHandle(jsHandle);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115966410763)
            
            //--TRIMMABLE-BOUNDARY-START(47246934027)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246934027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    if (!this._isDisposed)
                    {
                        /*List<WeakReference<JSObject>>*/ let copy = new ($.$$.SCG.List$$($.$$.S.WeakReference$$($.$srij.SRIJ.JSObject)))().$ctor$2(this.ThreadCsOwnedObjects.Values);
                        let $en7 = copy.GetEnumerator();
                        while ($en7.MoveNext())
                        {
                            let jsObjectWeak = $en7.Current;
                            {
                                /*var*/ let jso;
                                if (jsObjectWeak.TryGetTarget($.$ref(() => jso, ($v) => jso = $v, $.$srij.SRIJ.JSObject)))
                                {
                                    jso.Dispose();
                                }
                            }
                        }
                        let $en9 = this.ThreadJsOwnedObjects.Values.GetEnumerator();
                        while ($en9.MoveNext())
                        {
                            let gch = $en9.Current;
                            {
                                /*GCHandle*/ let gcHandle = $.$$.SRI.GCHandle.op_Explicit$1(gch);
                                gcHandle.Free();
                            }
                        }
                        let $en10 = this.ThreadJsOwnedHolders.Values.GetEnumerator();
                        while ($en10.MoveNext())
                        {
                            let holder = $en10.Current;
                            {
                                {
                                    holder.Callback.Invoke(null);
                                }
                                ($.$$.SRI.GCHandle.op_Explicit$1(holder.GCHandle)).Free();
                            }
                        }
                        this.ThreadCsOwnedObjects.Clear();
                        this.ThreadJsOwnedObjects.Clear();
                        this.JSVHandleFreeList.Clear();
                        this.NextJSVHandle = $.$$.S.IntPtr.Zero;
                        if (disposing)
                        {
                        }
                        this._isDisposed = true;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246934027)
            
            $dtor()
            {
                this.Dispose$1(false);
            }
            //--TRIMMABLE-BOUNDARY-START(42951966731)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951966731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
                $.$$.S.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(42951966731)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(12887195659)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12887195659)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(128851312651)
                this.ThreadCsOwnedObjects = new ($.$$.SCG.Dictionary$$$($.$$.S.IntPtr, $.$$.S.WeakReference$$($.$srij.SRIJ.JSObject)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(128851312651)
                
                //--TRIMMABLE-BOUNDARY-START(137441247243)
                this.ThreadJsOwnedObjects = new ($.$$.SCG.Dictionary$$$($.$$.S.Object, $.$$.S.IntPtr))().$ctor$6($.$$.SCG.ReferenceEqualityComparer.Instance);
                //--TRIMMABLE-BOUNDARY-END(137441247243)
                
                //--TRIMMABLE-BOUNDARY-START(133146279947)
                this.ThreadJsOwnedHolders = new ($.$$.SCG.Dictionary$$$($.$$.S.IntPtr, $.$srij.SRIJ.JSHostImplementation.PromiseHolder))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(133146279947)
                
                //--TRIMMABLE-BOUNDARY-START(98786541579)
                this.JSVHandleFreeList = new ($.$$.SCG.List$$($.$$.S.IntPtr))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(98786541579)
                
                $.$finalizer(this);
            }
            //--TRIMMABLE-BOUNDARY-START(8592228363)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592228363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(103081508875)
                    this.MainThreadContext = new $.$srij.SRIJ.JSProxyContext().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(103081508875)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592228363)
            
            static $h = 2293771;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656999435),
    {
      "p": 2293771,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016737803,
        "f": 50331681
      },
      "n": "CurrentThreadContext",
      "d": 2293771,
      "h": 38656999435,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(38656999435),
//--TRIMMABLE-BOUNDARY-START(34362032139),
    {
      "p": 2293771,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426803211,
        "f": 50331681
      },
      "n": "CurrentOperationContext",
      "d": 2293771,
      "h": 34362032139,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34362032139)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85901639691),
    {
      "r": 262145,
      "n": "IsCurrentThread",
      "d": 2293771,
      "h": 85901639691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85901639691),
//--TRIMMABLE-BOUNDARY-START(111671443467),
    {
      "r": 2293771,
      "n": "PushOperationWithCurrentThreadContext",
      "d": 2293771,
      "h": 111671443467,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111671443467),
//--TRIMMABLE-BOUNDARY-START(21477130251),
    {
      "r": 2293771,
      "n": "AssertIsInteropThread",
      "d": 2293771,
      "h": 21477130251,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477130251),
//--TRIMMABLE-BOUNDARY-START(94491574283),
    {
      "r": 262145,
      "p": [
        {
          "n": "jsHandle",
          "p": 786433
        }
      ],
      "n": "IsJSVHandle",
      "d": 2293771,
      "h": 94491574283,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94491574283),
//--TRIMMABLE-BOUNDARY-START(90196606987),
    {
      "r": 262145,
      "p": [
        {
          "n": "gcHandle",
          "p": 786433
        }
      ],
      "n": "IsGCVHandle",
      "d": 2293771,
      "h": 90196606987,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90196606987),
//--TRIMMABLE-BOUNDARY-START(17182162955),
    {
      "r": 786433,
      "n": "AllocJSVHandle",
      "d": 2293771,
      "h": 17182162955,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182162955),
//--TRIMMABLE-BOUNDARY-START(55836868619),
    {
      "r": 65537,
      "p": [
        {
          "n": "jsvHandle",
          "p": 786433
        }
      ],
      "n": "FreeJSVHandle",
      "d": 2293771,
      "h": 55836868619,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836868619),
//--TRIMMABLE-BOUNDARY-START(77311705099),
    {
      "r": 786433,
      "p": [
        {
          "n": "obj",
          "p": 131073
        },
        {
          "n": "handleType",
          "p": 142606337,
          "f": 65,
          "v": 2
        }
      ],
      "n": "GetJSOwnedObjectGCHandle",
      "d": 2293771,
      "h": 77311705099,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311705099),
//--TRIMMABLE-BOUNDARY-START(30067064843),
    {
      "r": 983051,
      "n": "CreatePromiseHolder",
      "d": 2293771,
      "h": 30067064843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067064843),
//--TRIMMABLE-BOUNDARY-START(81606672395),
    {
      "r": 983051,
      "p": [
        {
          "n": "gcHandle",
          "p": 786433
        }
      ],
      "n": "GetPromiseHolder",
      "d": 2293771,
      "h": 81606672395,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81606672395),
//--TRIMMABLE-BOUNDARY-START(124556345355),
    {
      "r": 65537,
      "p": [
        {
          "n": "holderGCHandle",
          "p": 786433
        }
      ],
      "n": "ReleasePromiseHolder",
      "d": 2293771,
      "h": 124556345355,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124556345355),
//--TRIMMABLE-BOUNDARY-START(120261378059),
    {
      "r": 65537,
      "p": [
        {
          "n": "gcHandle",
          "p": 786433
        }
      ],
      "n": "ReleaseJSOwnedObjectByGCHandle",
      "d": 2293771,
      "h": 120261378059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120261378059),
//--TRIMMABLE-BOUNDARY-START(25772097547),
    {
      "r": 2228235,
      "p": [
        {
          "n": "jsHandle",
          "p": 786433
        }
      ],
      "n": "CreateCSOwnedProxy",
      "d": 2293771,
      "h": 25772097547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772097547),
//--TRIMMABLE-BOUNDARY-START(115966410763),
    {
      "r": 65537,
      "p": [
        {
          "n": "jso",
          "p": 2228235
        },
        {
          "n": "skipJS",
          "p": 262145
        }
      ],
      "n": "ReleaseCSOwnedObject",
      "d": 2293771,
      "h": 115966410763,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115966410763),
//--TRIMMABLE-BOUNDARY-START(47246934027),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 2293771,
      "h": 47246934027,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47246934027),
//--TRIMMABLE-BOUNDARY-START(42951966731),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2293771,
      "h": 42951966731,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951966731)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297261067),
    {
      "t": 262145,
      "n": "_isDisposed",
      "d": 2293771,
      "h": 4297261067,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4297261067),
//--TRIMMABLE-BOUNDARY-START(128851312651),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.IntPtr, $.$$.S.WeakReference$$($.$srij.SRIJ.JSObject)).$h,
      "n": "ThreadCsOwnedObjects",
      "d": 2293771,
      "h": 128851312651,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(128851312651),
//--TRIMMABLE-BOUNDARY-START(137441247243),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.Object, $.$$.S.IntPtr).$h,
      "n": "ThreadJsOwnedObjects",
      "d": 2293771,
      "h": 137441247243,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(137441247243),
//--TRIMMABLE-BOUNDARY-START(133146279947),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.IntPtr, $.$srij.SRIJ.JSHostImplementation.PromiseHolder).$h,
      "n": "ThreadJsOwnedHolders",
      "d": 2293771,
      "h": 133146279947,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(133146279947),
//--TRIMMABLE-BOUNDARY-START(107376476171),
    {
      "t": 786433,
      "n": "NextJSVHandle",
      "d": 2293771,
      "h": 107376476171,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(107376476171),
//--TRIMMABLE-BOUNDARY-START(98786541579),
    {
      "t": $.$$.SCG.List$$($.$$.S.IntPtr).$h,
      "n": "JSVHandleFreeList",
      "d": 2293771,
      "h": 98786541579,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98786541579),
//--TRIMMABLE-BOUNDARY-START(103081508875),
    {
      "t": 2293771,
      "n": "MainThreadContext",
      "d": 2293771,
      "h": 103081508875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103081508875)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887195659),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2293771,
      "h": 12887195659,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12887195659)
  ],
  "h": 2293771
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSProxyContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSProxyContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293771)
        
        

        //--TRIMMABLE-BOUNDARY-START(458763)
        $asm.$cls(`$srij.SRIJ.JSExportAttribute`, ($self) => class JSExportAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295426059)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426059);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426059)
            
            //--TRIMMABLE-BOUNDARY-START(4295426059)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295426059)
            
            static $h = 458763;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426059),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458763,
      "h": 4295426059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426059)
  ],
  "h": 458763,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 64,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSExportAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSExportAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458763)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179659)
        $asm.$cls(`$srij.SRIJ.JSImportAttribute`, ($self) => class JSImportAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(21476016139)
            /*string*/ FunctionName = null;
            //--TRIMMABLE-BOUNDARY-END(21476016139)
            
            //--TRIMMABLE-BOUNDARY-START(42950852619)
            /*string?*/ ModuleName = null;
            //--TRIMMABLE-BOUNDARY-END(42950852619)
            
            //--TRIMMABLE-BOUNDARY-START(17181048843)
            $ctor$3(/*string*/ functionName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181048843);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.FunctionName = functionName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181048843)
            
            //--TRIMMABLE-BOUNDARY-START(12886081547)
            $ctor$2(/*string*/ functionName, /*string*/ moduleName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886081547);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.FunctionName = functionName;
                    this.ModuleName = moduleName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081547)
            
            static $h = 1179659;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476016139),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065950731,
        "f": 50331649
      },
      "n": "FunctionName",
      "d": 1179659,
      "h": 21476016139,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476016139),
//--TRIMMABLE-BOUNDARY-START(42950852619),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655885323,
        "f": 50331649
      },
      "n": "ModuleName",
      "d": 1179659,
      "h": 42950852619,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950852619)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181048843),
    {
      "p": [
        {
          "n": "functionName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1179659,
      "h": 17181048843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048843),
//--TRIMMABLE-BOUNDARY-START(12886081547),
    {
      "p": [
        {
          "n": "functionName",
          "p": 1310721
        },
        {
          "n": "moduleName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179659,
      "h": 12886081547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886081547)
  ],
  "h": 1179659,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 64,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSImportAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSImportAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179659)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310731)
        $asm.$str(`$srij.SRIJ.JSMarshalerArgument`, ($self) => class JSMarshalerArgument extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(60130852875)
            /*JSMarshalerArgumentImpl*/ slot;
            //--TRIMMABLE-BOUNDARY-END(60130852875)
            
            //--TRIMMABLE-BOUNDARY-START(2097163)
            static $_JSMarshalerArgumentImpl;
            static get JSMarshalerArgumentImpl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2097163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSMarshalerArgument;
                return $cls.$_JSMarshalerArgumentImpl ??= $asm.$nstr(`$srij.SRIJ.JSMarshalerArgument.JSMarshalerArgumentImpl`, ($self) => class JSMarshalerArgumentImpl extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(8592031755)
                    /*bool*/  get BooleanValue() { return this.$getField(0, $.$$.S.Boolean); }
                    /*bool*/  set BooleanValue(value) { this.$setField(0, $.$$.S.Boolean, value); }
                    //--TRIMMABLE-BOUNDARY-END(8592031755)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886999051)
                    /*byte*/  get ByteValue() { return this.$getField(0, $.$$.S.Byte); }
                    /*byte*/  set ByteValue(value) { this.$setField(0, $.$$.S.Byte, value); }
                    //--TRIMMABLE-BOUNDARY-END(12886999051)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181966347)
                    /*char*/  get CharValue() { return this.$getField(0, $.$$.S.Char); }
                    /*char*/  set CharValue(value) { this.$setField(0, $.$$.S.Char, value); }
                    //--TRIMMABLE-BOUNDARY-END(17181966347)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361835531)
                    /*short*/  get Int16Value() { return this.$getField(0, $.$$.S.Int16); }
                    /*short*/  set Int16Value(value) { this.$setField(0, $.$$.S.Int16, value); }
                    //--TRIMMABLE-BOUNDARY-END(34361835531)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656802827)
                    /*int*/  get Int32Value() { return this.$getField(0, $.$$.S.Int32); }
                    /*int*/  set Int32Value(value) { this.$setField(0, $.$$.S.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(38656802827)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951770123)
                    /*long*/  get Int64Value() { return this.$getField(0, $.$$.S.Int64); }
                    /*long*/  set Int64Value(value) { this.$setField(0, $.$$.S.Int64, value); }
                    //--TRIMMABLE-BOUNDARY-END(42951770123)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131639307)
                    /*float*/  get SingleValue() { return this.$getField(0, $.$$.S.Single); }
                    /*float*/  set SingleValue(value) { this.$setField(0, $.$$.S.Single, value); }
                    //--TRIMMABLE-BOUNDARY-END(60131639307)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476933643)
                    /*double*/  get DoubleValue() { return this.$getField(0, $.$$.S.Double); }
                    /*double*/  set DoubleValue(value) { this.$setField(0, $.$$.S.Double, value); }
                    //--TRIMMABLE-BOUNDARY-END(21476933643)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246737419)
                    /*IntPtr*/  get IntPtrValue() { return this.$getField(0, $.$$.S.IntPtr); }
                    /*IntPtr*/  set IntPtrValue(value) { this.$setField(0, $.$$.S.IntPtr, value); }
                    //--TRIMMABLE-BOUNDARY-END(47246737419)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541704715)
                    /*IntPtr*/  get JSHandle() { return this.$getField(4, $.$$.S.IntPtr); }
                    /*IntPtr*/  set JSHandle(value) { this.$setField(4, $.$$.S.IntPtr, value); }
                    //--TRIMMABLE-BOUNDARY-END(51541704715)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066868235)
                    /*IntPtr*/  get GCHandle() { return this.$getField(4, $.$$.S.IntPtr); }
                    /*IntPtr*/  set GCHandle(value) { this.$setField(4, $.$$.S.IntPtr, value); }
                    //--TRIMMABLE-BOUNDARY-END(30066868235)
                    
                    //--TRIMMABLE-BOUNDARY-START(55836672011)
                    /*int*/  get Length() { return this.$getField(8, $.$$.S.Int32); }
                    /*int*/  set Length(value) { this.$setField(8, $.$$.S.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(55836672011)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426606603)
                    /*MarshalerType*/  get Type() { return this.$getField(12, $.$srij.SRIJ.MarshalerType); }
                    /*MarshalerType*/  set Type(value) { this.$setField(12, $.$srij.SRIJ.MarshalerType, value); }
                    //--TRIMMABLE-BOUNDARY-END(64426606603)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771900939)
                    /*MarshalerType*/  get ElementType() { return this.$getField(13, $.$srij.SRIJ.MarshalerType); }
                    /*MarshalerType*/  set ElementType(value) { this.$setField(13, $.$srij.SRIJ.MarshalerType, value); }
                    //--TRIMMABLE-BOUNDARY-END(25771900939)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297064459)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4297064459);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297064459)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297064459)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297064459)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.BooleanValue = this.BooleanValue;
                        copy.ByteValue = this.ByteValue;
                        copy.CharValue = this.CharValue;
                        copy.Int16Value = this.Int16Value;
                        copy.Int32Value = this.Int32Value;
                        copy.Int64Value = this.Int64Value;
                        copy.SingleValue = this.SingleValue;
                        copy.DoubleValue = this.DoubleValue;
                        copy.IntPtrValue = this.IntPtrValue;
                        copy.JSHandle = this.JSHandle;
                        copy.GCHandle = this.GCHandle;
                        copy.Length = this.Length;
                        copy.Type = this.Type;
                        copy.ElementType = this.ElementType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8592031755)
                        this.BooleanValue = false;
                        //--TRIMMABLE-BOUNDARY-END(8592031755)
                        
                        //--TRIMMABLE-BOUNDARY-START(12886999051)
                        this.ByteValue = 0;
                        //--TRIMMABLE-BOUNDARY-END(12886999051)
                        
                        //--TRIMMABLE-BOUNDARY-START(17181966347)
                        this.CharValue = 0;
                        //--TRIMMABLE-BOUNDARY-END(17181966347)
                        
                        //--TRIMMABLE-BOUNDARY-START(34361835531)
                        this.Int16Value = 0;
                        //--TRIMMABLE-BOUNDARY-END(34361835531)
                        
                        //--TRIMMABLE-BOUNDARY-START(38656802827)
                        this.Int32Value = 0;
                        //--TRIMMABLE-BOUNDARY-END(38656802827)
                        
                        //--TRIMMABLE-BOUNDARY-START(42951770123)
                        this.Int64Value = 0n;
                        //--TRIMMABLE-BOUNDARY-END(42951770123)
                        
                        //--TRIMMABLE-BOUNDARY-START(60131639307)
                        this.SingleValue = 0;
                        //--TRIMMABLE-BOUNDARY-END(60131639307)
                        
                        //--TRIMMABLE-BOUNDARY-START(21476933643)
                        this.DoubleValue = 0;
                        //--TRIMMABLE-BOUNDARY-END(21476933643)
                        
                        //--TRIMMABLE-BOUNDARY-START(47246737419)
                        this.IntPtrValue = 0;
                        //--TRIMMABLE-BOUNDARY-END(47246737419)
                        
                        //--TRIMMABLE-BOUNDARY-START(51541704715)
                        this.JSHandle = 0;
                        //--TRIMMABLE-BOUNDARY-END(51541704715)
                        
                        //--TRIMMABLE-BOUNDARY-START(30066868235)
                        this.GCHandle = 0;
                        //--TRIMMABLE-BOUNDARY-END(30066868235)
                        
                        //--TRIMMABLE-BOUNDARY-START(55836672011)
                        this.Length = 0;
                        //--TRIMMABLE-BOUNDARY-END(55836672011)
                        
                        //--TRIMMABLE-BOUNDARY-START(64426606603)
                        this.Type = 0;
                        //--TRIMMABLE-BOUNDARY-END(64426606603)
                        
                        //--TRIMMABLE-BOUNDARY-START(25771900939)
                        this.ElementType = 0;
                        //--TRIMMABLE-BOUNDARY-END(25771900939)
                        
                    }
                    static $h = 2097163;
                    static $z = 32;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592031755),
    {
      "t": 262145,
      "n": "BooleanValue",
      "d": 2097163,
      "h": 8592031755,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592031755),
//--TRIMMABLE-BOUNDARY-START(12886999051),
    {
      "t": 393217,
      "n": "ByteValue",
      "d": 2097163,
      "h": 12886999051,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886999051),
//--TRIMMABLE-BOUNDARY-START(17181966347),
    {
      "t": 458753,
      "n": "CharValue",
      "d": 2097163,
      "h": 17181966347,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181966347),
//--TRIMMABLE-BOUNDARY-START(34361835531),
    {
      "t": 524289,
      "n": "Int16Value",
      "d": 2097163,
      "h": 34361835531,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361835531),
//--TRIMMABLE-BOUNDARY-START(38656802827),
    {
      "t": 655361,
      "n": "Int32Value",
      "d": 2097163,
      "h": 38656802827,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656802827),
//--TRIMMABLE-BOUNDARY-START(42951770123),
    {
      "t": 917505,
      "n": "Int64Value",
      "d": 2097163,
      "h": 42951770123,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42951770123),
//--TRIMMABLE-BOUNDARY-START(60131639307),
    {
      "t": 1114113,
      "n": "SingleValue",
      "d": 2097163,
      "h": 60131639307,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60131639307),
//--TRIMMABLE-BOUNDARY-START(21476933643),
    {
      "t": 1179649,
      "n": "DoubleValue",
      "d": 2097163,
      "h": 21476933643,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476933643),
//--TRIMMABLE-BOUNDARY-START(47246737419),
    {
      "t": 786433,
      "n": "IntPtrValue",
      "d": 2097163,
      "h": 47246737419,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 0,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246737419),
//--TRIMMABLE-BOUNDARY-START(51541704715),
    {
      "t": 786433,
      "n": "JSHandle",
      "d": 2097163,
      "h": 51541704715,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541704715),
//--TRIMMABLE-BOUNDARY-START(30066868235),
    {
      "t": 786433,
      "n": "GCHandle",
      "d": 2097163,
      "h": 30066868235,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066868235),
//--TRIMMABLE-BOUNDARY-START(55836672011),
    {
      "t": 655361,
      "n": "Length",
      "d": 2097163,
      "h": 55836672011,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 8,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836672011),
//--TRIMMABLE-BOUNDARY-START(64426606603),
    {
      "t": 3670027,
      "n": "Type",
      "d": 2097163,
      "h": 64426606603,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 12,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64426606603),
//--TRIMMABLE-BOUNDARY-START(25771900939),
    {
      "t": 3670027,
      "n": "ElementType",
      "d": 2097163,
      "h": 25771900939,
      "f": 4194312,
      "a": [
        {
          "t": 142344193,
          "c": 8732278785,
          "a": [
            {
              "v": 13,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771900939)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297064459),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2097163,
      "h": 4297064459,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297064459)
  ],
  "d": 1310731,
  "h": 2097163,
  "a": [
    {
      "t": 148176897,
      "c": 13033078785,
      "a": [
        {
          "v": 2,
          "t": 143654913
        }
      ],
      "n": [
        {
          "n": "Pack",
          "v": 32,
          "t": 655361
        },
        {
          "n": "Size",
          "v": 32,
          "t": 655361
        }
      ]
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument+JSMarshalerArgumentImpl`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalerArgument${separator}JSMarshalerArgumentImpl`; }
                }, $cls, ($v) => $cls.$_JSMarshalerArgumentImpl = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2097163)
            
            //--TRIMMABLE-BOUNDARY-START(42950983691)
            /*void */ Initialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950983691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 0/*MarshalerType.None*/;
            }
            //--TRIMMABLE-BOUNDARY-END(42950983691)
            
            //--TRIMMABLE-BOUNDARY-START(511102418955)
            /*JSProxyContext */ get ToManagedContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066081803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.SRIJ.JSProxyContext.MainThreadContext;
            }
            //--TRIMMABLE-BOUNDARY-END(511102418955)
            
            //--TRIMMABLE-BOUNDARY-START(283469152267)
            /*JSProxyContext */ get ToJSContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476147211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.SRIJ.JSProxyContext.MainThreadContext;
            }
            //--TRIMMABLE-BOUNDARY-END(283469152267)
            
            //--TRIMMABLE-BOUNDARY-START(8591245323)
            /*JSProxyContext */ AssertCurrentThreadContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591245323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$srij.SRIJ.JSProxyContext.MainThreadContext;
            }
            //--TRIMMABLE-BOUNDARY-END(8591245323)
            
            //--TRIMMABLE-BOUNDARY-START(502512484363)
            /*void */ ToManagedBig(/*out long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502512484363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0n;
                    return;
                }
                value.$v = this.slot.Int64Value;
            }
            //--TRIMMABLE-BOUNDARY-END(502512484363)
            
            //--TRIMMABLE-BOUNDARY-START(274879217675)
            /*void */ ToJSBig(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879217675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 9/*MarshalerType.BigInt64*/;
                this.slot.Int64Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(274879217675)
            
            //--TRIMMABLE-BOUNDARY-START(506807451659)
            /*void */ ToManagedBig$1(/*out long?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506807451659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int64Value;
            }
            //--TRIMMABLE-BOUNDARY-END(506807451659)
            
            //--TRIMMABLE-BOUNDARY-START(279174184971)
            /*void */ ToJSBig$1(/*long?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174184971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(value))
                {
                    this.slot.Type = 9/*MarshalerType.BigInt64*/;
                    this.slot.Int64Value = $.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(279174184971)
            
            //--TRIMMABLE-BOUNDARY-START(322123857931)
            /*void */ ToManaged$7(/*out char*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123857931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.CharValue;
            }
            //--TRIMMABLE-BOUNDARY-END(322123857931)
            
            //--TRIMMABLE-BOUNDARY-START(94490591243)
            /*void */ ToJS$7(/*char*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490591243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 5/*MarshalerType.Char*/;
                this.slot.CharValue = value;
            }
            //--TRIMMABLE-BOUNDARY-END(94490591243)
            
            //--TRIMMABLE-BOUNDARY-START(377958432779)
            /*void */ ToManaged$20(/*out char?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377958432779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.CharValue;
            }
            //--TRIMMABLE-BOUNDARY-END(377958432779)
            
            //--TRIMMABLE-BOUNDARY-START(150325166091)
            /*void */ ToJS$20(/*char?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325166091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.Char).HasValue$get.call(value))
                {
                    this.slot.Type = 5/*MarshalerType.Char*/;
                    this.slot.CharValue = $.$$.S.Nullable$$($.$$.S.Char).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150325166091)
            
            //--TRIMMABLE-BOUNDARY-START(433793007627)
            /*void */ ToManaged$33(/*out float*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433793007627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.SingleValue;
            }
            //--TRIMMABLE-BOUNDARY-END(433793007627)
            
            //--TRIMMABLE-BOUNDARY-START(206159740939)
            /*void */ ToJS$33(/*float*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159740939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 11/*MarshalerType.Single*/;
                this.slot.SingleValue = value;
            }
            //--TRIMMABLE-BOUNDARY-END(206159740939)
            
            //--TRIMMABLE-BOUNDARY-START(412318171147)
            /*void */ ToManaged$28(/*out float?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412318171147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.SingleValue;
            }
            //--TRIMMABLE-BOUNDARY-END(412318171147)
            
            //--TRIMMABLE-BOUNDARY-START(184684904459)
            /*void */ ToJS$28(/*float?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684904459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.Single).HasValue$get.call(value))
                {
                    this.slot.Type = 11/*MarshalerType.Single*/;
                    this.slot.SingleValue = $.$$.S.Nullable$$($.$$.S.Single).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684904459)
            
            //--TRIMMABLE-BOUNDARY-START(347893661707)
            /*void */ ToManaged$13(/*out short*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893661707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.Int16Value;
            }
            //--TRIMMABLE-BOUNDARY-END(347893661707)
            
            //--TRIMMABLE-BOUNDARY-START(120260395019)
            /*void */ ToJS$13(/*short*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260395019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 6/*MarshalerType.Int16*/;
                this.slot.Int16Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(120260395019)
            
            //--TRIMMABLE-BOUNDARY-START(395138301963)
            /*void */ ToManaged$24(/*out short?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395138301963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int16Value;
            }
            //--TRIMMABLE-BOUNDARY-END(395138301963)
            
            //--TRIMMABLE-BOUNDARY-START(167505035275)
            /*void */ ToJS$24(/*short?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505035275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.Int16).HasValue$get.call(value))
                {
                    this.slot.Type = 6/*MarshalerType.Int16*/;
                    this.slot.Int16Value = $.$$.S.Nullable$$($.$$.S.Int16).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167505035275)
            
            //--TRIMMABLE-BOUNDARY-START(365073530891)
            /*void */ ToManaged$17(/*out IntPtr*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365073530891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.IntPtrValue;
            }
            //--TRIMMABLE-BOUNDARY-END(365073530891)
            
            //--TRIMMABLE-BOUNDARY-START(137440264203)
            /*void */ ToJS$17(/*IntPtr*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440264203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 12/*MarshalerType.IntPtr*/;
                this.slot.IntPtrValue = value;
            }
            //--TRIMMABLE-BOUNDARY-END(137440264203)
            
            //--TRIMMABLE-BOUNDARY-START(408023203851)
            /*void */ ToManaged$27(/*out IntPtr?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408023203851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.IntPtrValue;
            }
            //--TRIMMABLE-BOUNDARY-END(408023203851)
            
            //--TRIMMABLE-BOUNDARY-START(180389937163)
            /*void */ ToJS$27(/*IntPtr?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389937163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.IntPtr).HasValue$get.call(value))
                {
                    this.slot.Type = 12/*MarshalerType.IntPtr*/;
                    this.slot.IntPtrValue = $.$$.S.Nullable$$($.$$.S.IntPtr).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180389937163)
            
            //--TRIMMABLE-BOUNDARY-START(463857778699)
            /*void */ ToManaged$40(/*out void**/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463857778699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$typePointer($.$$.S.Void)();
                    return;
                }
                value.$v = $.$$.$interop.$addr2Ptr(this.slot.IntPtrValue, null);
            }
            //--TRIMMABLE-BOUNDARY-END(463857778699)
            
            //--TRIMMABLE-BOUNDARY-START(236224512011)
            /*void */ ToJS$40(/*void**/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224512011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 12/*MarshalerType.IntPtr*/;
                this.slot.IntPtrValue = $.$$.$interop.$ptr2Addr(value);
            }
            //--TRIMMABLE-BOUNDARY-END(236224512011)
            
            //--TRIMMABLE-BOUNDARY-START(34361049099)
            /*long*/ static I52_MAX_VALUE = 9007199254740991n;
            //--TRIMMABLE-BOUNDARY-END(34361049099)
            
            //--TRIMMABLE-BOUNDARY-START(38656016395)
            /*long*/ static I52_MIN_VALUE = -9007199254740991n;
            //--TRIMMABLE-BOUNDARY-END(38656016395)
            
            //--TRIMMABLE-BOUNDARY-START(360778563595)
            /*void */ ToManaged$16(/*out long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778563595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0n;
                    return;
                }
                value.$v = $.$cast(this.slot.DoubleValue, $.$$.S.Int64);
            }
            //--TRIMMABLE-BOUNDARY-END(360778563595)
            
            //--TRIMMABLE-BOUNDARY-START(133145296907)
            /*void */ ToJS$16(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145296907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < -9007199254740991n || value > 9007199254740991n)
                {
                    throw new $.$$.S.OverflowException().$ctor$16($.$srij.S.SR.Format$4($.$srij.S.SR.ValueOutOf52BitRange, $.$box(value, $.$$.S.Int64), $.$box(-9007199254740991n, $.$$.S.Int64), $.$box(9007199254740991n, $.$$.S.Int64)));
                }
                this.slot.Type = 8/*MarshalerType.Int52*/;
                this.slot.DoubleValue = Number(value);
            }
            //--TRIMMABLE-BOUNDARY-END(133145296907)
            
            //--TRIMMABLE-BOUNDARY-START(403728236555)
            /*void */ ToManaged$26(/*out long?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403728236555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$cast(this.slot.DoubleValue, $.$$.S.Int64);
            }
            //--TRIMMABLE-BOUNDARY-END(403728236555)
            
            //--TRIMMABLE-BOUNDARY-START(176094969867)
            /*void */ ToJS$26(/*long?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094969867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(value))
                {
                    if ($.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(value) < -9007199254740991n || $.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(value) > 9007199254740991n)
                    {
                        throw new $.$$.S.OverflowException().$ctor$16($.$srij.S.SR.Format$4($.$srij.S.SR.ValueOutOf52BitRange, $.$box(value, $.$$.S.Int64), $.$box(-9007199254740991n, $.$$.S.Int64), $.$box(9007199254740991n, $.$$.S.Int64)));
                    }
                    this.slot.Type = 8/*MarshalerType.Int52*/;
                    this.slot.DoubleValue = Number($.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(value));
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176094969867)
            
            //--TRIMMABLE-BOUNDARY-START(309238956043)
            /*void */ ToManaged$4(/*out bool*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238956043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = false;
                    return;
                }
                value.$v = this.slot.BooleanValue;
            }
            //--TRIMMABLE-BOUNDARY-END(309238956043)
            
            //--TRIMMABLE-BOUNDARY-START(81605689355)
            /*void */ ToJS$4(/*bool*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605689355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 3/*MarshalerType.Boolean*/;
                this.slot.BooleanValue = value;
            }
            //--TRIMMABLE-BOUNDARY-END(81605689355)
            
            //--TRIMMABLE-BOUNDARY-START(369368498187)
            /*void */ ToManaged$18(/*out bool?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369368498187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.BooleanValue;
            }
            //--TRIMMABLE-BOUNDARY-END(369368498187)
            
            //--TRIMMABLE-BOUNDARY-START(141735231499)
            /*void */ ToJS$18(/*bool?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735231499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.Boolean).HasValue$get.call(value))
                {
                    this.slot.Type = 3/*MarshalerType.Boolean*/;
                    this.slot.BooleanValue = $.$$.S.Nullable$$($.$$.S.Boolean).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141735231499)
            
            //--TRIMMABLE-BOUNDARY-START(335008759819)
            /*void */ ToManaged$10(/*out double*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335008759819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.DoubleValue;
            }
            //--TRIMMABLE-BOUNDARY-END(335008759819)
            
            //--TRIMMABLE-BOUNDARY-START(107375493131)
            /*void */ ToJS$10(/*double*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375493131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 10/*MarshalerType.Double*/;
                this.slot.DoubleValue = value;
            }
            //--TRIMMABLE-BOUNDARY-END(107375493131)
            
            //--TRIMMABLE-BOUNDARY-START(390843334667)
            /*void */ ToManaged$23(/*out double?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390843334667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.DoubleValue;
            }
            //--TRIMMABLE-BOUNDARY-END(390843334667)
            
            //--TRIMMABLE-BOUNDARY-START(163210067979)
            /*void */ ToJS$23(/*double?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210067979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.Double).HasValue$get.call(value))
                {
                    this.slot.Type = 10/*MarshalerType.Double*/;
                    this.slot.DoubleValue = $.$$.S.Nullable$$($.$$.S.Double).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163210067979)
            
            //--TRIMMABLE-BOUNDARY-START(339303727115)
            /*void */ ToManaged$11(/*out double[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303727115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Double), null, [this.slot.Length], null);
                $.$$.SRI.Marshal.Copy$8(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$$.SRI.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            //--TRIMMABLE-BOUNDARY-END(339303727115)
            
            //--TRIMMABLE-BOUNDARY-START(111670460427)
            /*void */ ToJS$11(/*double[]*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670460427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$$.SRI.Marshal.AllocHGlobal(((value.length * 8) | 0));
                this.slot.Length = value.length;
                this.slot.ElementType = 10/*MarshalerType.Double*/;
                $.$$.SRI.Marshal.Copy$2(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(111670460427)
            
            //--TRIMMABLE-BOUNDARY-START(300649021451)
            /*void */ ToManaged$2(/*out ArraySegment<double>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300649021451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let array = $.$cast(($.$$.SRI.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target, $.$typeArray($.$$.S.Double));
                /*var*/ let refPtr = $.$$.$interop.$ptr2Addr($.$$.SRC.Unsafe.AsPointer($.$$.S.Double, $.$$.SRI.MemoryMarshal.GetArrayDataReference$1($.$$.S.Double, array)));
                /*int*/ let byteOffset = (((this.slot.IntPtrValue - refPtr) | 0));
                value.$v = new ($.$$.S.ArraySegment$$($.$$.S.Double))().$ctor$3(array, $.trunc(byteOffset / 8), this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(300649021451)
            
            //--TRIMMABLE-BOUNDARY-START(73015754763)
            /*void */ ToJS$2(/*ArraySegment<double>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015754763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$$.$interop.$ptr2Addr($.$$.SRC.Unsafe.AsPointer($.$$.S.Double, $.$$.SRI.MemoryMarshal.GetArrayDataReference$1($.$$.S.Double, value.Array)));
                this.slot.IntPtrValue = ((refPtr + (((value.Offset * 8) | 0))) | 0);
                this.slot.Length = value.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(73015754763)
            
            //--TRIMMABLE-BOUNDARY-START(442382942219)
            /*void */ ToManaged$35(/*out Span<double>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442382942219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value.$v = new ($.$$.S.Span$$($.$$.S.Double))().$ctor$5($.$$.$interop.$addr2Ptr(this.slot.IntPtrValue, null), this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(442382942219)
            
            //--TRIMMABLE-BOUNDARY-START(214749675531)
            /*void */ ToJS$35(/*Span<double>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749675531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$$.$interop.$ptr2Addr($.$$.SRC.Unsafe.AsPointer($.$$.S.Double, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            //--TRIMMABLE-BOUNDARY-END(214749675531)
            
            //--TRIMMABLE-BOUNDARY-START(343598694411)
            /*void */ ToManaged$12(/*out Exception?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343598694411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                if (this.slot.Type === 16/*MarshalerType.Exception*/)
                {
                    value.$v = $.$cast(($.$$.SRI.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target, $.$$.S.Exception);
                    return;
                }
                /*JSObject?*/ let jsException = null;
                if (this.slot.JSHandle !== $.$$.S.IntPtr.Zero)
                {
                    /*var*/ let ctx = this.ToManagedContext;
                    jsException = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                }
                /*string?*/ let message;
                this.ToManaged$37($.$ref(() => message, ($v) => message = $v, $.$$.S.String));
                value.$v = new $.$srij.SRIJ.JSException().$ctor$5(message, jsException);
            }
            //--TRIMMABLE-BOUNDARY-END(343598694411)
            
            //--TRIMMABLE-BOUNDARY-START(115965427723)
            /*void */ ToJS$12(/*Exception?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965427723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    /*Exception*/ let cpy = value;
                    let ae;
                    if ($.$is(cpy, $.$$.S.AggregateException, { set $v($v){ ae = $v; } }) && ae.InnerExceptions.Count === 1)
                    {
                        cpy = ae.InnerExceptions.get_Item(0);
                    }
                    /*var*/ let jse = $.$as(cpy, $.$srij.SRIJ.JSException);
                    if (jse !== null && jse.jsException !== null)
                    {
                        /*var*/ let jsException = jse.jsException;
                        jsException.AssertNotDisposed();
                        this.slot.Type = 27/*MarshalerType.JSException*/;
                        this.slot.JSHandle = jsException.JSHandle;
                    }
                    else 
                    {
                        this.ToJS$37(cpy.Message);
                        this.slot.Type = 16/*MarshalerType.Exception*/;
                        /*var*/ let ctx = this.ToJSContext;
                        this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cpy, 2);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115965427723)
            
            //--TRIMMABLE-BOUNDARY-START(425203073035)
            /*void */ ToManaged$31(/*out JSObject?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425203073035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                value.$v = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
            }
            //--TRIMMABLE-BOUNDARY-END(425203073035)
            
            //--TRIMMABLE-BOUNDARY-START(197569806347)
            /*void */ ToJS$31(/*JSObject?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569806347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    value.AssertNotDisposed();
                    this.slot.Type = 13/*MarshalerType.JSObject*/;
                    this.slot.JSHandle = value.JSHandle;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197569806347)
            
            //--TRIMMABLE-BOUNDARY-START(429498040331)
            /*void */ ToManaged$32(/*out JSObject?[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429498040331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSObject), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$$.$interop.$addr2Ptr(this.slot.IntPtrValue, null);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*JSObject?*/ let val;
                    arg.$v.ToManaged$31($.$ref(() => val, ($v) => val = $v, $.$srij.SRIJ.JSObject));
                    $.$$.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$$.SRI.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            //--TRIMMABLE-BOUNDARY-END(429498040331)
            
            //--TRIMMABLE-BOUNDARY-START(201864773643)
            /*void */ ToJS$32(/*JSObject?[]*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864773643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * 32) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.ElementType = 13/*MarshalerType.JSObject*/;
                /*JSMarshalerArgument**/ let payload = $.$$.$interop.$addr2Ptr($.$$.SRI.Marshal.AllocHGlobal(bytes), null);
                $.$$.SRC.Unsafe.InitBlock$1(payload, 0, (bytes >>> 0));
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*JSObject?*/ let val = $.$$.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$31(val);
                    $.$$.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.IntPtrValue = $.$$.$interop.$ptr2Addr(payload);
            }
            //--TRIMMABLE-BOUNDARY-END(201864773643)
            
            //--TRIMMABLE-BOUNDARY-START(450972876811)
            /*void */ ToManaged$37(/*out string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450972876811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*fixed*/ 
                {
                    /*void**/ let argAsRoot = $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.IntPtr, () => this.slot.IntPtrValue, ($v) => this.slot.IntPtrValue = $v, null, true);
                    value.$v = $.$$.SRC.Unsafe.AsRef($.$$.S.String, argAsRoot).$v;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(450972876811)
            
            //--TRIMMABLE-BOUNDARY-START(223339610123)
            /*void */ ToJS$37(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339610123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
                else 
                {
                    this.slot.Type = 15/*MarshalerType.String*/;
                    /*fixed*/ 
                    {
                        /*IntPtr**/ let argAsRoot = $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.IntPtr, () => this.slot.IntPtrValue, ($v) => this.slot.IntPtrValue = $v, null, true);
                        /*string*/ let cpy = value;
                        /*var*/ let currentRoot = $.$cast($.$$.SRC.Unsafe.AsPointer($.$$.S.String, $.$ref(() => cpy, ($v) => cpy = $v, $.$$.S.String)), $.$typePointer($.$$.S.IntPtr));
                        argAsRoot.SetAt(currentRoot.GetAt(0), 0);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223339610123)
            
            //--TRIMMABLE-BOUNDARY-START(455267844107)
            /*void */ ToManaged$38(/*out string?[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455267844107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$$.$interop.$addr2Ptr(this.slot.IntPtrValue, null);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*string?*/ let val;
                    arg.$v.ToManaged$37($.$ref(() => val, ($v) => val = $v, $.$$.S.String));
                    $.$$.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$srij.Interop.Runtime.DeregisterGCRoot(this.slot.IntPtrValue);
                $.$$.SRI.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            //--TRIMMABLE-BOUNDARY-END(455267844107)
            
            //--TRIMMABLE-BOUNDARY-START(227634577419)
            /*void */ ToJS$38(/*string?[]*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634577419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * 32) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                /*JSMarshalerArgument**/ let payload = $.$$.$interop.$addr2Ptr($.$$.SRI.Marshal.AllocHGlobal(bytes), null);
                $.$$.SRC.Unsafe.InitBlock$1(payload, 0, (bytes >>> 0));
                $.$srij.Interop.Runtime.RegisterGCRoot(payload, bytes, $.$$.S.IntPtr.Zero);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*string?*/ let val = $.$$.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$37(val);
                    $.$$.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.IntPtrValue = $.$$.$interop.$ptr2Addr(payload);
                this.slot.ElementType = 15/*MarshalerType.String*/;
            }
            //--TRIMMABLE-BOUNDARY-END(227634577419)
            
            //--TRIMMABLE-BOUNDARY-START(330713792523)
            /*void */ ToManaged$9(/*out DateTimeOffset*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713792523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$$.S.DateTimeOffset();
                    return;
                }
                value.$v = $.$$.S.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$$.S.Int64));
            }
            //--TRIMMABLE-BOUNDARY-END(330713792523)
            
            //--TRIMMABLE-BOUNDARY-START(103080525835)
            /*void */ ToJS$9(/*DateTimeOffset*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080525835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 18/*MarshalerType.DateTimeOffset*/;
                this.slot.DoubleValue = $.$cast(value.ToUnixTimeMilliseconds(), $.$$.S.Double);
            }
            //--TRIMMABLE-BOUNDARY-END(103080525835)
            
            //--TRIMMABLE-BOUNDARY-START(386548367371)
            /*void */ ToManaged$22(/*out DateTimeOffset?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548367371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.S.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$$.S.Int64));
            }
            //--TRIMMABLE-BOUNDARY-END(386548367371)
            
            //--TRIMMABLE-BOUNDARY-START(158915100683)
            /*void */ ToJS$22(/*DateTimeOffset?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915100683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.DateTimeOffset).HasValue$get.call(value))
                {
                    this.slot.Type = 18/*MarshalerType.DateTimeOffset*/;
                    this.slot.DoubleValue = Number($.$$.S.Nullable$$($.$$.S.DateTimeOffset).Value$get.call(value).ToUnixTimeMilliseconds());
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158915100683)
            
            //--TRIMMABLE-BOUNDARY-START(326418825227)
            /*void */ ToManaged$8(/*out DateTime*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418825227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = new $.$$.S.DateTime();
                    return;
                }
                value.$v = $.$$.S.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$$.S.Int64)).UtcDateTime;
            }
            //--TRIMMABLE-BOUNDARY-END(326418825227)
            
            //--TRIMMABLE-BOUNDARY-START(98785558539)
            /*void */ ToJS$8(/*DateTime*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785558539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 17/*MarshalerType.DateTime*/;
                this.slot.DoubleValue = Number(new $.$$.S.DateTimeOffset().$ctor$5(value).ToUnixTimeMilliseconds());
            }
            //--TRIMMABLE-BOUNDARY-END(98785558539)
            
            //--TRIMMABLE-BOUNDARY-START(382253400075)
            /*void */ ToManaged$21(/*out DateTime?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382253400075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.S.DateTimeOffset.FromUnixTimeMilliseconds($.$cast(this.slot.DoubleValue, $.$$.S.Int64)).UtcDateTime;
            }
            //--TRIMMABLE-BOUNDARY-END(382253400075)
            
            //--TRIMMABLE-BOUNDARY-START(154620133387)
            /*void */ ToJS$21(/*DateTime?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620133387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(value))
                {
                    this.slot.Type = 17/*MarshalerType.DateTime*/;
                    this.slot.DoubleValue = Number(new $.$$.S.DateTimeOffset().$ctor$5($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(value)).ToUnixTimeMilliseconds());
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154620133387)
            
            //--TRIMMABLE-BOUNDARY-START(352188629003)
            /*void */ ToManaged$14(/*out int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352188629003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.Int32Value;
            }
            //--TRIMMABLE-BOUNDARY-END(352188629003)
            
            //--TRIMMABLE-BOUNDARY-START(124555362315)
            /*void */ ToJS$14(/*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555362315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 7/*MarshalerType.Int32*/;
                this.slot.Int32Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(124555362315)
            
            //--TRIMMABLE-BOUNDARY-START(399433269259)
            /*void */ ToManaged$25(/*out int?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399433269259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.Int32Value;
            }
            //--TRIMMABLE-BOUNDARY-END(399433269259)
            
            //--TRIMMABLE-BOUNDARY-START(171800002571)
            /*void */ ToJS$25(/*int?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800002571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.Int32).HasValue$get.call(value))
                {
                    this.slot.Type = 7/*MarshalerType.Int32*/;
                    this.slot.Int32Value = $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171800002571)
            
            //--TRIMMABLE-BOUNDARY-START(356483596299)
            /*void */ ToManaged$15(/*out int[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483596299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [this.slot.Length], null);
                $.$$.SRI.Marshal.Copy$10(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$$.SRI.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            //--TRIMMABLE-BOUNDARY-END(356483596299)
            
            //--TRIMMABLE-BOUNDARY-START(128850329611)
            /*void */ ToJS$15(/*int[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850329611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$$.SRI.Marshal.AllocHGlobal(((value.length * 4) | 0));
                this.slot.Length = value.length;
                this.slot.ElementType = 7/*MarshalerType.Int32*/;
                $.$$.SRI.Marshal.Copy$4(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(128850329611)
            
            //--TRIMMABLE-BOUNDARY-START(304943988747)
            /*void */ ToManaged$3(/*out ArraySegment<int>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943988747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let array = $.$cast(($.$$.SRI.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target, $.$typeArray($.$$.S.Int32));
                /*var*/ let refPtr = $.$$.$interop.$ptr2Addr($.$$.SRC.Unsafe.AsPointer($.$$.S.Int32, $.$$.SRI.MemoryMarshal.GetArrayDataReference$1($.$$.S.Int32, array)));
                /*int*/ let byteOffset = (((this.slot.IntPtrValue - refPtr) | 0));
                value.$v = new ($.$$.S.ArraySegment$$($.$$.S.Int32))().$ctor$3(array, $.trunc(byteOffset / 4), this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(304943988747)
            
            //--TRIMMABLE-BOUNDARY-START(77310722059)
            /*void */ ToJS$3(/*ArraySegment<int>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310722059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                /*var*/ let ctx = this.ToJSContext;
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$$.$interop.$ptr2Addr($.$$.SRC.Unsafe.AsPointer($.$$.S.Int32, $.$$.SRI.MemoryMarshal.GetArrayDataReference$1($.$$.S.Int32, value.Array)));
                this.slot.IntPtrValue = ((refPtr + (((value.Offset * 4) | 0))) | 0);
                this.slot.Length = value.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(77310722059)
            
            //--TRIMMABLE-BOUNDARY-START(446677909515)
            /*void */ ToManaged$36(/*out Span<int>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446677909515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value.$v = new ($.$$.S.Span$$($.$$.S.Int32))().$ctor$5($.$$.$interop.$addr2Ptr(this.slot.IntPtrValue, null), this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(446677909515)
            
            //--TRIMMABLE-BOUNDARY-START(219044642827)
            /*void */ ToJS$36(/*Span<int>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044642827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$$.$interop.$ptr2Addr($.$$.SRC.Unsafe.AsPointer($.$$.S.Int32, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            //--TRIMMABLE-BOUNDARY-END(219044642827)
            
            //--TRIMMABLE-BOUNDARY-START(313533923339)
            /*void */ ToManaged$5(/*out byte*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533923339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = 0;
                    return;
                }
                value.$v = this.slot.ByteValue;
            }
            //--TRIMMABLE-BOUNDARY-END(313533923339)
            
            //--TRIMMABLE-BOUNDARY-START(85900656651)
            /*void */ ToJS$5(/*byte*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900656651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Type = 4/*MarshalerType.Byte*/;
                this.slot.ByteValue = value;
            }
            //--TRIMMABLE-BOUNDARY-END(85900656651)
            
            //--TRIMMABLE-BOUNDARY-START(373663465483)
            /*void */ ToManaged$19(/*out byte?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373663465483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = this.slot.ByteValue;
            }
            //--TRIMMABLE-BOUNDARY-END(373663465483)
            
            //--TRIMMABLE-BOUNDARY-START(146030198795)
            /*void */ ToJS$19(/*byte?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030198795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.Byte).HasValue$get.call(value))
                {
                    this.slot.Type = 4/*MarshalerType.Byte*/;
                    this.slot.ByteValue = $.$$.S.Nullable$$($.$$.S.Byte).Value$get.call(value);
                }
                else 
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146030198795)
            
            //--TRIMMABLE-BOUNDARY-START(317828890635)
            /*void */ ToManaged$6(/*out byte[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828890635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [this.slot.Length], null);
                $.$$.SRI.Marshal.Copy$6(this.slot.IntPtrValue, value.$v, 0, this.slot.Length);
                $.$$.SRI.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            //--TRIMMABLE-BOUNDARY-END(317828890635)
            
            //--TRIMMABLE-BOUNDARY-START(90195623947)
            /*void */ ToJS$6(/*byte[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195623947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                this.slot.Type = 21/*MarshalerType.Array*/;
                this.slot.IntPtrValue = $.$$.SRI.Marshal.AllocHGlobal(((value.length * 1) | 0));
                this.slot.ElementType = 4/*MarshalerType.Byte*/;
                $.$$.SRI.Marshal.Copy(value, 0, this.slot.IntPtrValue, this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(90195623947)
            
            //--TRIMMABLE-BOUNDARY-START(296354054155)
            /*void */ ToManaged$1(/*out ArraySegment<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354054155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let array = $.$cast(($.$$.SRI.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target, $.$typeArray($.$$.S.Byte));
                /*var*/ let refPtr = $.$$.$interop.$ptr2Addr($.$$.SRC.Unsafe.AsPointer($.$$.S.Byte, $.$$.SRI.MemoryMarshal.GetArrayDataReference$1($.$$.S.Byte, array)));
                /*int*/ let byteOffset = (((this.slot.IntPtrValue - refPtr) | 0));
                value.$v = new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$3(array, byteOffset, this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(296354054155)
            
            //--TRIMMABLE-BOUNDARY-START(68720787467)
            /*void */ ToJS$1(/*ArraySegment<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720787467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.Array === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Type = 22/*MarshalerType.ArraySegment*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value.Array, 3/*GCHandleType.Pinned*/);
                /*var*/ let refPtr = $.$$.$interop.$ptr2Addr($.$$.SRC.Unsafe.AsPointer($.$$.S.Byte, $.$$.SRI.MemoryMarshal.GetArrayDataReference$1($.$$.S.Byte, value.Array)));
                this.slot.IntPtrValue = ((refPtr + value.Offset) | 0);
                this.slot.Length = value.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(68720787467)
            
            //--TRIMMABLE-BOUNDARY-START(438087974923)
            /*void */ ToManaged$34(/*out Span<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438087974923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value.$v = new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$5($.$$.$interop.$addr2Ptr(this.slot.IntPtrValue, null), this.slot.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(438087974923)
            
            //--TRIMMABLE-BOUNDARY-START(210454708235)
            /*void */ ToJS$34(/*Span<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454708235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.slot.Length = value.Length;
                this.slot.IntPtrValue = $.$$.$interop.$ptr2Addr($.$$.SRC.Unsafe.AsPointer($.$$.S.Byte, value.GetPinnableReference()));
                this.slot.Type = 23/*MarshalerType.Span*/;
            }
            //--TRIMMABLE-BOUNDARY-END(210454708235)
            
            //--TRIMMABLE-BOUNDARY-START(1703947)
            static $_ArgumentToManagedCallback$$;
            static ArgumentToManagedCallback$$(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1703947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSMarshalerArgument;
                return ($cls.$_ArgumentToManagedCallback$$ ??= $asm.$ncls(`$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback<>`, (T) => $asm.$gt(`$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback<>`, [T], ($self) => class ArgumentToManagedCallback$$ extends $.$$.S.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arg, /**/ value)
                    {
                        return this.$nativeFunction.call(this.$target, arg, value);
                    }
                    static $H = 1703947;
                    static $h = 1703947;
                    static $g = 1;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181573131),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg",
          "p": 1310731,
          "f": 4
        },
        {
          "n": "value",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "H": 17181573131,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181573131),
//--TRIMMABLE-BOUNDARY-START(8591638539),
    {
      "r": 90570753,
      "p": [
        {
          "n": "arg",
          "p": 1310731,
          "f": 4
        },
        {
          "n": "value",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": this.$h,
      "H": 8591638539,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591638539),
//--TRIMMABLE-BOUNDARY-START(12886605835),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg",
          "p": 1310731,
          "f": 4
        },
        {
          "n": "value",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": this.$h,
      "H": 12886605835,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886605835)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671243),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4296671243,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296671243)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "d": 1310731,
  "H": 1703947,
  "h": this.$h,
  "a": [
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    }
  ]
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument+ArgumentToManagedCallback<${T?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalerArgument${separator}ArgumentToManagedCallback$${T?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_ArgumentToManagedCallback$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(1703947)
            
            //--TRIMMABLE-BOUNDARY-START(1638411)
            static $_ArgumentToJSCallback$$;
            static ArgumentToJSCallback$$(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1638411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSMarshalerArgument;
                return ($cls.$_ArgumentToJSCallback$$ ??= $asm.$ncls(`$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback<>`, (T) => $asm.$gt(`$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback<>`, [T], ($self) => class ArgumentToJSCallback$$ extends $.$$.S.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ arg, /**/ value)
                    {
                        return this.$nativeFunction.call(this.$target, arg, value);
                    }
                    static $H = 1638411;
                    static $h = 1638411;
                    static $g = 1;
                    static $f = 0b10000000011000001;
                    static $k = 5;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181507595),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg",
          "p": 1310731,
          "f": 4
        },
        {
          "n": "value",
          "p": T?.$h??1572864
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "H": 17181507595,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181507595),
//--TRIMMABLE-BOUNDARY-START(8591573003),
    {
      "r": 90570753,
      "p": [
        {
          "n": "arg",
          "p": 1310731,
          "f": 4
        },
        {
          "n": "value",
          "p": T?.$h??1572864
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": this.$h,
      "H": 8591573003,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591573003),
//--TRIMMABLE-BOUNDARY-START(12886540299),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg",
          "p": 1310731,
          "f": 4
        },
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": this.$h,
      "H": 12886540299,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886540299)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605707),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4296605707,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605707)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "d": 1310731,
  "H": 1638411,
  "h": this.$h,
  "a": [
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    }
  ]
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument+ArgumentToJSCallback<${T?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalerArgument${separator}ArgumentToJSCallback$${T?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_ArgumentToJSCallback$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(1638411)
            
            //--TRIMMABLE-BOUNDARY-START(459562811403)
            /*void */ ToManaged$39(/*out Task?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459562811403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                {
                    /*PromiseHolder*/ let holder = ctx.GetPromiseHolder(this.slot.GCHandle);
                    /*TaskCompletionSource*/ let tcs = new $.$$.STT.TaskCompletionSource().$ctor$2(holder, 64/*TaskCreationOptions.RunContinuationsAsynchronously*/);
                    /*ToManagedCallback*/ let callback = new $.$srij.SRIJ.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ arguments_buffer) =>
                    {
                        if (arguments_buffer === null)
                        {
                            if (!tcs.TrySetException$1(new $.$$.STT.TaskCanceledException().$ctor$20("WebWorker which is origin of the Promise is being terminated.")))
                            {
                                $.$$.S.Environment.FailFast$2("Failed to set exception to TaskCompletionSource (arguments buffer is null)");
                            }
                            return;
                        }
                        /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                        if (arg_2.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            /*Exception?*/ let fail;
                            arg_2.$v.ToManaged$12($.$ref(() => fail, ($v) => fail = $v, $.$$.S.Exception));
                            if (!tcs.TrySetException$1(fail))
                            {
                                $.$$.S.Environment.FailFast$2("Failed to set exception to TaskCompletionSource (exception raised)");
                            }
                        }
                        else 
                        {
                            if (!tcs.TrySetResult())
                            {
                                $.$$.S.Environment.FailFast$2("Failed to set result to TaskCompletionSource (marshaler type is none)");
                            }
                        }
                    }, $PklaRk ??= {"r":65537,"p":[{"n":"arguments_buffer","p":$.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h}],"n":"","d":1310731,"h":0,"f":17825794});
                    holder.Callback = callback;
                    value.$v = tcs.Task;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(459562811403)
            
            //--TRIMMABLE-BOUNDARY-START(476742680587)
            /*void */ ToManaged$43(T, /*out Task<T>?*/ value, /*ArgumentToManagedCallback<T>*/ marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476742680587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                {
                    /*var*/ let holder = ctx.GetPromiseHolder(this.slot.GCHandle);
                    /*TaskCompletionSource<T>*/ let tcs = new ($.$$.STT.TaskCompletionSource$$(T))().$ctor$2(holder, 64/*TaskCreationOptions.RunContinuationsAsynchronously*/);
                    /*ToManagedCallback*/ let callback = new $.$srij.SRIJ.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ arguments_buffer) =>
                    {
                        if (arguments_buffer === null)
                        {
                            if (!tcs.TrySetException$1(new $.$$.STT.TaskCanceledException().$ctor$20("WebWorker which is origin of the Promise is being terminated.")))
                            {
                                $.$$.S.Environment.FailFast$2("Failed to set exception to TaskCompletionSource (arguments buffer is null)");
                            }
                            return;
                        }
                        /*ref JSMarshalerArgument*/ let arg_2 = arguments_buffer.Add(3);
                        /*ref JSMarshalerArgument*/ let arg_3 = arguments_buffer.Add(4);
                        if (arg_2.$v.slot.Type !== 0/*MarshalerType.None*/)
                        {
                            /*Exception?*/ let fail;
                            arg_2.$v.ToManaged$12($.$ref(() => fail, ($v) => fail = $v, $.$$.S.Exception));
                            if (fail === null)
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$12($.$srij.S.SR.FailedToMarshalException);
                            }
                            if (!tcs.TrySetException$1(fail))
                            {
                                $.$$.S.Environment.FailFast$2("Failed to set exception to TaskCompletionSource (exception raised)");
                            }
                        }
                        else 
                        {
                            /*T*/ let result;
                            marshaler.Invoke(arg_3, $.$ref(() => result, ($v) => result = $v, T));
                            if (!tcs.TrySetResult(result))
                            {
                                $.$$.S.Environment.FailFast$2("Failed to set result to TaskCompletionSource (marshaler type is none)");
                            }
                        }
                    }, $KwCNfa ??= {"r":65537,"p":[{"n":"arguments_buffer","p":$.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h}],"n":"","d":1310731,"h":0,"f":17825794});
                    holder.Callback = callback;
                    value.$v = tcs.Task;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(476742680587)
            
            //--TRIMMABLE-BOUNDARY-START(287764119563)
            /*void */ ToJSDynamic(/*Task?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764119563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Task?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$$.S.Environment.FailFast$2("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$12(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        /*object?*/ let result;
                        if ($.$srij.SRIJ.JSHostImplementation.GetTaskResultDynamic(task, $.$ref(() => result, ($v) => result = $v, $.$$.S.Object)))
                        {
                            this.ToJS$29(result);
                            this.slot.ElementType = this.slot.Type;
                        }
                        else 
                        {
                            this.slot.ElementType = 1/*MarshalerType.Void*/;
                        }
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$4(new ($.$$.S.Action$$$($.$$.STT.Task, $.$$.S.Object))().$ctor($.$srij.SRIJ.JSMarshalerArgument, Complete, $hsLGmf ??= {"r":65537,"p":[{"n":"task","p":178454529},{"n":"th","p":131073}],"n":"Complete","o":"@$1","d":1310731,"h":0,"f":16777250}), taskHolder, $.$$.STT.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task*/ task, /*object?*/ th)
                {
                    /*var*/ let taskHolderArg = $.$cast(th, $.$srij.SRIJ.JSObject);
                    if (task.Exception !== null)
                    {
                        $.$srij.SRIJ.JSMarshalerArgument.RejectPromise(taskHolderArg, task.Exception);
                    }
                    else 
                    {
                        /*object?*/ let result;
                        if ($.$srij.SRIJ.JSHostImplementation.GetTaskResultDynamic(task, $.$ref(() => result, ($v) => result = $v, $.$$.S.Object)))
                        {
                            $.$srij.SRIJ.JSMarshalerArgument.ResolvePromise($.$$.S.Object, taskHolderArg, result, new ($.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$($.$$.S.Object))().$ctor($.$srij.SRIJ.JSMarshalerArgument, MarshalResult, $zUWcef ??= {"r":65537,"p":[{"n":"arg","p":1310731,"f":4},{"n":"taskResult","p":131073}],"n":"MarshalResult","d":1310731,"h":0,"f":16777250}));
                        }
                        else 
                        {
                            $.$srij.SRIJ.JSMarshalerArgument.ResolveVoidPromise(taskHolderArg);
                        }
                    }
                }
                /*static void*/  function MarshalResult(/*ref JSMarshalerArgument*/ arg, /*object?*/ taskResult)
                {
                    arg.$v.ToJS$29(taskResult);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(287764119563)
            
            //--TRIMMABLE-BOUNDARY-START(231929544715)
            /*void */ ToJS$39(/*Task?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929544715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Task?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$$.S.Environment.FailFast$2("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$12(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        this.slot.ElementType = 1/*MarshalerType.Void*/;
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$4(new ($.$$.S.Action$$$($.$$.STT.Task, $.$$.S.Object))().$ctor($.$srij.SRIJ.JSMarshalerArgument, Complete, $zchwcc ??= {"r":65537,"p":[{"n":"task","p":178454529},{"n":"th","p":131073}],"n":"Complete","d":1310731,"h":0,"f":16777250}), taskHolder, $.$$.STT.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task*/ task, /*object?*/ th)
                {
                    /*JSObject*/ let taskHolderArg = $.$cast(th, $.$srij.SRIJ.JSObject);
                    if (task.Exception !== null)
                    {
                        $.$srij.SRIJ.JSMarshalerArgument.RejectPromise(taskHolderArg, task.Exception);
                    }
                    else 
                    {
                        $.$srij.SRIJ.JSMarshalerArgument.ResolveVoidPromise(taskHolderArg);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231929544715)
            
            //--TRIMMABLE-BOUNDARY-START(249109413899)
            /*void */ ToJS$43(T, /*Task<T>?*/ value, /*ArgumentToJSCallback<T>*/ marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109413899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Task<T>?*/ let task = value;
                /*var*/ let ctx = this.ToJSContext;
                /*var*/ let canMarshalTaskResultOnSameCall = this.CanMarshalTaskResultOnSameCall(ctx);
                if (task === null)
                {
                    if (!canMarshalTaskResultOnSameCall)
                    {
                        $.$$.S.Environment.FailFast$2("Marshalling null return Task to JS is not supported in MT");
                    }
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                if (canMarshalTaskResultOnSameCall && task.IsCompleted)
                {
                    if (task.Exception !== null)
                    {
                        /*Exception*/ let ex = task.Exception;
                        this.ToJS$12(ex);
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 29/*MarshalerType.TaskRejected*/;
                        return;
                    }
                    else 
                    {
                        /*T*/ let result = task.Result;
                        this.ToJS$29($.$box(result, T));
                        this.slot.ElementType = this.slot.Type;
                        this.slot.Type = 28/*MarshalerType.TaskResolved*/;
                        return;
                    }
                }
                if (this.slot.Type !== 30/*MarshalerType.TaskPreCreated*/)
                {
                    this.slot.JSHandle = ctx.AllocJSVHandle();
                    this.slot.Type = 20/*MarshalerType.Task*/;
                }
                else 
                {
                }
                /*var*/ let taskHolder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                task.ContinueWith$28(new ($.$$.S.Action$$$($.$$.STT.Task$$(T), $.$$.S.Object))().$ctor($.$srij.SRIJ.JSMarshalerArgument, Complete, $IiwDTc ??= {"r":65537,"p":[{"n":"task","p":(T) => $.$$.STT.Task$$(T).$h},{"n":"thm","p":131073}],"n":"Complete","o":"@$2","d":1310731,"h":0,"f":16777250}), new ($.$srij.SRIJ.JSMarshalerArgument.HolderAndMarshaler$$(T))().$ctor$1(taskHolder, marshaler), $.$$.STT.TaskScheduler.Current);
                /*static void*/  function Complete(/*Task<T>*/ task, /*object?*/ thm)
                {
                    /*var*/ let hm = $.$cast(thm, $.$srij.SRIJ.JSMarshalerArgument.HolderAndMarshaler$$(T));
                    if (task.Exception !== null)
                    {
                        $.$srij.SRIJ.JSMarshalerArgument.RejectPromise(hm.TaskHolder, task.Exception);
                    }
                    else 
                    {
                        /*T*/ let result = task.Result;
                        $.$srij.SRIJ.JSMarshalerArgument.ResolvePromise(T, hm.TaskHolder, result, hm.Marshaler);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249109413899)
            
            //--TRIMMABLE-BOUNDARY-START(12886212619)
            /*bool */ CanMarshalTaskResultOnSameCall(/*JSProxyContext*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886212619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(12886212619)
            
            //--TRIMMABLE-BOUNDARY-START(2031627)
            static $_HolderAndMarshaler$$;
            static HolderAndMarshaler$$(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2031627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSMarshalerArgument;
                return ($cls.$_HolderAndMarshaler$$ ??= $asm.$ncls(`$srij.SRIJ.JSMarshalerArgument.HolderAndMarshaler<>`, (T) => $asm.$gt(`$srij.SRIJ.JSMarshalerArgument.HolderAndMarshaler<>`, [T], ($self) => class HolderAndMarshaler$$ extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4386127873)
                    //Generated interface implemetation for System.IEquatable<System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<T>>.Equals(System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.HolderAndMarshaler<T>?)
                    [`S$IEquatable$System$Runtime$InteropServices$JavaScript$JSMarshalerArgument$HolderAndMarshaler$${T.$getFullName('$')}$$Equals`]()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386127873);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Equals$2(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386127873)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.TaskHolder = this.TaskHolder;
                        copy.Marshaler = this.Marshaler;
                        return copy;
                    }
                    //Begin primary constructor
                    /*JSObject*/ TaskHolder = null;
                    /*ArgumentToJSCallback<T>*/ Marshaler = null;
                    $ctor$1(/*JSObject*/TaskHolder, /*ArgumentToJSCallback<T>*/Marshaler)
                    {
                        this.TaskHolder = TaskHolder;
                        this.Marshaler = Marshaler;
                        super.$ctor();
                        return this
                    }
                    //End primary constructor
                    //Begin generated record members
                    /*Type*/ get EqualityContract() { return $.$typeOf($.$srij.SRIJ.JSMarshalerArgument.HolderAndMarshaler$$(T)); }
                    /*string*/ ToString()
                    {
                        let stringBuilder = new $.$$.ST.StringBuilder().$ctor$1();
                        stringBuilder.Append$21("HolderAndMarshaler");
                        stringBuilder.Append$21("{");
                        if (this.PrintMembers(stringBuilder))
                        {
                            stringBuilder.Append$21(" ");
                        }
                        stringBuilder.Append$21("}");
                        return stringBuilder.ToString();
                    }
                    /*bool*/ PrintMembers(/*StringBuilder*/ stringBuilder)
                    {
                        stringBuilder.Append$21("TaskHolder = ");
                        stringBuilder.Append$21(this.TaskHolder.ToString());
                        stringBuilder.Append$21(", ");
                        stringBuilder.Append$21("Marshaler = ");
                        stringBuilder.Append$21($.$dsp(this.Marshaler, $.$$.S.Object, ($t) => $t.ToString));
                        return true;
                    }
                    /*bool*/ Equals$2(/*HolderAndMarshaler*/ other)
                    {
                        return this === other || (other !== null && this.EqualityContract == other.EqualityContract && $.$$.SCG.EqualityComparer$$($.$srij.SRIJ.JSObject).Default.Equals$2(this.TaskHolder, other.TaskHolder) && $.$$.SCG.EqualityComparer$$($.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T)).Default.Equals$2(this.Marshaler, other.Marshaler));
                    }
                    /*int*/ GetHashCode()
                    {
                        return $.$$.SCG.EqualityComparer$$($.$$.S.Type).Default.GetHashCode$1(this.EqualityContract) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$srij.SRIJ.JSObject).Default.GetHashCode$1(this.TaskHolder) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T)).Default.GetHashCode$1(this.Marshaler) * -1521134295;
                    }
                    static /*bool*/ op_Inequality(/*HolderAndMarshaler*/ left, /*HolderAndMarshaler*/ right)
                    {
                        return !(this.op_Equality(left, right));
                    }
                    static /*bool*/ op_Equality(/*HolderAndMarshaler*/ left, /*HolderAndMarshaler*/ right)
                    {
                        return left === right || (left !== null && left.Equals$2(right));
                    }
                    Deconstruct(/*out System.Runtime.InteropServices.JavaScript.JSObject*/ $TaskHolder, /*out System.Runtime.InteropServices.JavaScript.JSMarshalerArgument.ArgumentToJSCallback<T>*/ $Marshaler)
                    {
                        $TaskHolder.$v = this.TaskHolder;
                        $Marshaler.$v = this.Marshaler;
                    }
                    //End generated record member3s
                    static $H = 2031627;
                    static $h = 2031627;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066802699),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47246671883,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331650
      },
      "n": "EqualityContract",
      "d": this.$h,
      "H": 30066802699,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(30066802699),
//--TRIMMABLE-BOUNDARY-START(107376214027),
    {
      "p": 2228235,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64426541067,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 103081246731,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 83886081
      },
      "n": "TaskHolder",
      "d": this.$h,
      "H": 107376214027,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107376214027),
//--TRIMMABLE-BOUNDARY-START(73016475659),
    {
      "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55836606475,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 94491312139,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 83886081
      },
      "n": "Marshaler",
      "d": this.$h,
      "H": 73016475659,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016475659)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111671181323),
    {
      "r": 1310721,
      "n": "ToString",
      "d": this.$h,
      "H": 111671181323,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111671181323),
//--TRIMMABLE-BOUNDARY-START(85901377547),
    {
      "r": 262145,
      "p": [
        {
          "n": "builder",
          "p": 167837697
        }
      ],
      "n": "PrintMembers",
      "d": this.$h,
      "H": 85901377547,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85901377547),
//--TRIMMABLE-BOUNDARY-START(68721508363),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": this.$h,
      "H": 68721508363,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68721508363),
//--TRIMMABLE-BOUNDARY-START(34361769995),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": this.$h,
      "H": 34361769995,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361769995),
//--TRIMMABLE-BOUNDARY-START(38656737291),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": this.$h
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": this.$h,
      "H": 38656737291,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656737291),
//--TRIMMABLE-BOUNDARY-START(4296998923),
    {
      "r": this.$h,
      "n": "\u003CClone\u003E$",
      "o": "$$$",
      "d": this.$h,
      "H": 4296998923,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296998923),
//--TRIMMABLE-BOUNDARY-START(25771835403),
    {
      "r": 65537,
      "p": [
        {
          "n": "TaskHolder",
          "p": 2228235,
          "f": 2
        },
        {
          "n": "Marshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,
          "f": 2
        }
      ],
      "n": "Deconstruct",
      "d": this.$h,
      "H": 25771835403,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771835403)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181900811),
    {
      "p": [
        {
          "n": "TaskHolder",
          "p": 2228235
        },
        {
          "n": "Marshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 17181900811,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181900811),
//--TRIMMABLE-BOUNDARY-START(21476868107),
    {
      "p": [
        {
          "n": "original",
          "p": this.$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 21476868107,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21476868107)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "d": 1310731,
  "H": 2031627,
  "h": this.$h
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$srij.SRIJ.JSMarshalerArgument.HolderAndMarshaler$$(T)) ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument+HolderAndMarshaler<${T?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalerArgument${separator}HolderAndMarshaler$${T?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_HolderAndMarshaler$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(2031627)
            
            //--TRIMMABLE-BOUNDARY-START(47245950987)
            static /*void */ RejectPromise(/*JSObject*/ holder, /*Exception*/ ex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245950987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$srij.SRIJ.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 29/*MarshalerType.TaskRejected*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                arg_value.$v.ToJS$12(ex);
                holder.DisposeImpl(true);
                $.$srij.SRIJ.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            //--TRIMMABLE-BOUNDARY-END(47245950987)
            
            //--TRIMMABLE-BOUNDARY-START(55835885579)
            static /*void */ ResolveVoidPromise(/*JSObject*/ holder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835885579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$srij.SRIJ.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 28/*MarshalerType.TaskResolved*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                arg_value.$v.slot.Type = 1/*MarshalerType.Void*/;
                holder.DisposeImpl(true);
                $.$srij.SRIJ.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            //--TRIMMABLE-BOUNDARY-END(55835885579)
            
            //--TRIMMABLE-BOUNDARY-START(51540918283)
            static /*void */ ResolvePromise(T, /*JSObject*/ holder, /*T*/ value, /*ArgumentToJSCallback<T>*/ marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540918283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                holder.AssertNotDisposed();
                /*Span<JSMarshalerArgument>*/ let args = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$srij.SRIJ.JSMarshalerArgument, 4, null);
                /*ref JSMarshalerArgument*/ let exc = args.get_Item(0);
                /*ref JSMarshalerArgument*/ let res = args.get_Item(1);
                /*ref JSMarshalerArgument*/ let arg_handle = args.get_Item(2);
                /*ref JSMarshalerArgument*/ let arg_value = args.get_Item(3);
                exc.$v.Initialize();
                res.$v.Initialize();
                arg_handle.$v.slot.Type = 28/*MarshalerType.TaskResolved*/;
                arg_handle.$v.slot.JSHandle = holder.JSHandle;
                marshaler.Invoke(arg_value, value);
                holder.DisposeImpl(true);
                $.$srij.SRIJ.JSFunctionBinding.ResolveOrRejectPromise(holder.ProxyContext, args);
            }
            //--TRIMMABLE-BOUNDARY-END(51540918283)
            
            //--TRIMMABLE-BOUNDARY-START(1376267)
            static $_ActionJS;
            static get ActionJS()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1376267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSMarshalerArgument;
                return $cls.$_ActionJS ??= $asm.$ncls(`$srij.SRIJ.JSMarshalerArgument.ActionJS`, ($self) => class ActionJS extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12886278155)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(12886278155)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296343563)
                    $ctor$1(/*JSObject*/ holder)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296343563);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296343563)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591310859)
                    /*void */ InvokeJS()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8591310859);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$srij.SRIJ.JSMarshalerArgument, 2, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        $.$srij.SRIJ.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591310859)
                    
                    static $h = 1376267;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591310859),
    {
      "r": 65537,
      "n": "InvokeJS",
      "d": 1376267,
      "h": 8591310859,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591310859)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886278155),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": 1376267,
      "h": 12886278155,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886278155)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343563),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376267,
      "h": 4296343563,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343563)
  ],
  "d": 1310731,
  "h": 1376267
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument+ActionJS`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalerArgument${separator}ActionJS`; }
                }, $cls, ($v) => $cls.$_ActionJS = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1376267)
            
            //--TRIMMABLE-BOUNDARY-START(1572875)
            static $_ActionJS$$;
            static ActionJS$$(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1572875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSMarshalerArgument;
                return ($cls.$_ActionJS$$ ??= $asm.$ncls(`$srij.SRIJ.JSMarshalerArgument.ActionJS<>`, (T) => $asm.$gt(`$srij.SRIJ.JSMarshalerArgument.ActionJS<>`, [T], ($self) => class ActionJS$$ extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591507467)
                    /*ArgumentToJSCallback<T>*/ Arg1Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(8591507467)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181442059)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(17181442059)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296540171)
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T>*/ arg1Marshaler)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296540171);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296540171)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886474763)
                    /*void */ InvokeJS(/*T*/ arg1)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886474763);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$srij.SRIJ.JSMarshalerArgument, 3, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        $.$srij.SRIJ.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886474763)
                    
                    static $H = 1572875;
                    static $h = 1572875;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886474763),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg1",
          "p": T?.$h??1572864
        }
      ],
      "n": "InvokeJS",
      "d": this.$h,
      "H": 12886474763,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886474763)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591507467),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,
      "n": "Arg1Marshaler",
      "d": this.$h,
      "H": 8591507467,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591507467),
//--TRIMMABLE-BOUNDARY-START(17181442059),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": this.$h,
      "H": 17181442059,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181442059)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540171),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "arg1Marshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296540171,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540171)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "d": 1310731,
  "H": 1572875,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument+ActionJS<${T?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalerArgument${separator}ActionJS$${T?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_ActionJS$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(1572875)
            
            //--TRIMMABLE-BOUNDARY-START(1507339)
            static $_ActionJS$$$;
            static ActionJS$$$(T1, T2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1507339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSMarshalerArgument;
                return ($cls.$_ActionJS$$$ ??= $asm.$ncls(`$srij.SRIJ.JSMarshalerArgument.ActionJS<,>`, (T1, T2) => $asm.$gt(`$srij.SRIJ.JSMarshalerArgument.ActionJS<,>`, [T1, T2], ($self) => class ActionJS$$$ extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591441931)
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(8591441931)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886409227)
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(12886409227)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476343819)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(21476343819)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296474635)
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296474635);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296474635)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181376523)
                    /*void */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181376523);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$srij.SRIJ.JSMarshalerArgument, 4, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        $.$srij.SRIJ.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181376523)
                    
                    static $H = 1507339;
                    static $h = 1507339;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181376523),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg1",
          "p": T1?.$h??1572864
        },
        {
          "n": "arg2",
          "p": T2?.$h??1638400
        }
      ],
      "n": "InvokeJS",
      "d": this.$h,
      "H": 17181376523,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181376523)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591441931),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,
      "n": "Arg1Marshaler",
      "d": this.$h,
      "H": 8591441931,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591441931),
//--TRIMMABLE-BOUNDARY-START(12886409227),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,
      "n": "Arg2Marshaler",
      "d": this.$h,
      "H": 12886409227,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886409227),
//--TRIMMABLE-BOUNDARY-START(21476343819),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": this.$h,
      "H": 21476343819,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476343819)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296474635),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "arg1Marshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296474635,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296474635)
  ],
  "s": [
    {
      "h": T1?.$h??1572864,
      "n": "T1"
    },
    {
      "h": T2?.$h??1638400,
      "n": "T2"
    }
  ],
  "r": 2,
  "d": 1310731,
  "H": 1507339,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument+ActionJS<${T1?.$fullName},${T2?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalerArgument${separator}ActionJS$${T1?.$getFullName(separator)}$${T2?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_ActionJS$$$ = $v))(T1, T2);
            }
            //--TRIMMABLE-BOUNDARY-END(1507339)
            
            //--TRIMMABLE-BOUNDARY-START(1441803)
            static $_ActionJS$$$$;
            static ActionJS$$$$(T1, T2, T3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1441803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSMarshalerArgument;
                return ($cls.$_ActionJS$$$$ ??= $asm.$ncls(`$srij.SRIJ.JSMarshalerArgument.ActionJS<,,>`, (T1, T2, T3) => $asm.$gt(`$srij.SRIJ.JSMarshalerArgument.ActionJS<,,>`, [T1, T2, T3], ($self) => class ActionJS$$$$ extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591376395)
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(8591376395)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886343691)
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(12886343691)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181310987)
                    /*ArgumentToJSCallback<T3>*/ Arg3Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(17181310987)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771245579)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(25771245579)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296409099)
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296409099);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.Arg3Marshaler = arg3Marshaler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296409099)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476278283)
                    /*void */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476278283);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$srij.SRIJ.JSMarshalerArgument, 5, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        /*ref JSMarshalerArgument*/ let args_arg3 = $arguments.get_Item(4);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        this.Arg3Marshaler.Invoke(args_arg3, arg3);
                        $.$srij.SRIJ.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476278283)
                    
                    static $H = 1441803;
                    static $h = 1441803;
                    static $g = 3;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476278283),
    {
      "r": 65537,
      "p": [
        {
          "n": "arg1",
          "p": T1?.$h??1572864
        },
        {
          "n": "arg2",
          "p": T2?.$h??1638400
        },
        {
          "n": "arg3",
          "p": T3?.$h??1703936
        }
      ],
      "n": "InvokeJS",
      "d": this.$h,
      "H": 21476278283,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476278283)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591376395),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,
      "n": "Arg1Marshaler",
      "d": this.$h,
      "H": 8591376395,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591376395),
//--TRIMMABLE-BOUNDARY-START(12886343691),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,
      "n": "Arg2Marshaler",
      "d": this.$h,
      "H": 12886343691,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886343691),
//--TRIMMABLE-BOUNDARY-START(17181310987),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h,
      "n": "Arg3Marshaler",
      "d": this.$h,
      "H": 17181310987,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181310987),
//--TRIMMABLE-BOUNDARY-START(25771245579),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": this.$h,
      "H": 25771245579,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771245579)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409099),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "arg1Marshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        },
        {
          "n": "arg3Marshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296409099,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296409099)
  ],
  "s": [
    {
      "h": T1?.$h??1572864,
      "n": "T1"
    },
    {
      "h": T2?.$h??1638400,
      "n": "T2"
    },
    {
      "h": T3?.$h??1703936,
      "n": "T3"
    }
  ],
  "r": 3,
  "d": 1310731,
  "H": 1441803,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument+ActionJS<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalerArgument${separator}ActionJS$${T1?.$getFullName(separator)}$${T2?.$getFullName(separator)}$${T3?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_ActionJS$$$$ = $v))(T1, T2, T3);
            }
            //--TRIMMABLE-BOUNDARY-END(1441803)
            
            //--TRIMMABLE-BOUNDARY-START(292059086859)
            /*void */ ToManaged(/*out Action?*/ value)
            {
                let $t27 = new $.$srij.SRIJ.JSMarshalerArgument.ActionJS().$ctor$1(holder);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292059086859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new $.$$.S.Action().$ctor($t27, $t27.InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(292059086859)
            
            //--TRIMMABLE-BOUNDARY-START(472447713291)
            /*void */ ToManaged$42(T, /*out Action<T>?*/ value, /*ArgumentToJSCallback<T>*/ arg1Marshaler)
            {
                let $t28 = new ($.$srij.SRIJ.JSMarshalerArgument.ActionJS$$(T))().$ctor$1(holder, arg1Marshaler);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472447713291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.S.Action$$(T))().$ctor($t28, $t28.InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(472447713291)
            
            //--TRIMMABLE-BOUNDARY-START(493922549771)
            /*void */ ToManaged$47(T1, T2, /*out Action<T1, T2>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler)
            {
                let $t29 = new ($.$srij.SRIJ.JSMarshalerArgument.ActionJS$$$(T1, T2))().$ctor$1(holder, arg1Marshaler, arg2Marshaler);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493922549771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.S.Action$$$(T1, T2))().$ctor($t29, $t29.InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(493922549771)
            
            //--TRIMMABLE-BOUNDARY-START(485332615179)
            /*void */ ToManaged$45(T1, T2, T3, /*out Action<T1, T2, T3>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler)
            {
                let $t30 = new ($.$srij.SRIJ.JSMarshalerArgument.ActionJS$$$$(T1, T2, T3))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485332615179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.S.Action$$$$(T1, T2, T3))().$ctor($t30, $t30.InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(485332615179)
            
            //--TRIMMABLE-BOUNDARY-START(1966091)
            static $_FuncJS$$;
            static FuncJS$$(TResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1966091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSMarshalerArgument;
                return ($cls.$_FuncJS$$ ??= $asm.$ncls(`$srij.SRIJ.JSMarshalerArgument.FuncJS<>`, (TResult) => $asm.$gt(`$srij.SRIJ.JSMarshalerArgument.FuncJS<>`, [TResult], ($self) => class FuncJS$$ extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12886867979)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(12886867979)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181835275)
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(17181835275)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296933387)
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296933387);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296933387)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591900683)
                    /*TResult */ InvokeJS()
                    {
                        /*TResult*/ let res;
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8591900683);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$srij.SRIJ.JSMarshalerArgument, 2, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        $.$srij.SRIJ.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591900683)
                    
                    static $H = 1966091;
                    static $h = 1966091;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591900683),
    {
      "r": TResult?.$h??1572864,
      "n": "InvokeJS",
      "d": this.$h,
      "H": 8591900683,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591900683)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886867979),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": this.$h,
      "H": 12886867979,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886867979),
//--TRIMMABLE-BOUNDARY-START(17181835275),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,
      "n": "ResMarshaler",
      "d": this.$h,
      "H": 17181835275,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181835275)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296933387),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "resMarshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296933387,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296933387)
  ],
  "s": [
    {
      "h": TResult?.$h??1572864,
      "n": "TResult"
    }
  ],
  "r": 1,
  "d": 1310731,
  "H": 1966091,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument+FuncJS<${TResult?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalerArgument${separator}FuncJS$${TResult?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_FuncJS$$ = $v))(TResult);
            }
            //--TRIMMABLE-BOUNDARY-END(1966091)
            
            //--TRIMMABLE-BOUNDARY-START(1900555)
            static $_FuncJS$$$;
            static FuncJS$$$(T, TResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1900555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$ ??= $asm.$ncls(`$srij.SRIJ.JSMarshalerArgument.FuncJS<,>`, (T, TResult) => $asm.$gt(`$srij.SRIJ.JSMarshalerArgument.FuncJS<,>`, [T, TResult], ($self) => class FuncJS$$$ extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591835147)
                    /*ArgumentToJSCallback<T>*/ Arg1Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(8591835147)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476737035)
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(21476737035)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181769739)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(17181769739)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296867851)
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T>*/ arg1Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296867851);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296867851)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886802443)
                    /*TResult */ InvokeJS(/*T*/ arg1)
                    {
                        /*TResult*/ let res;
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886802443);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$srij.SRIJ.JSMarshalerArgument, 3, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        $.$srij.SRIJ.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886802443)
                    
                    static $H = 1900555;
                    static $h = 1900555;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886802443),
    {
      "r": TResult?.$h??1638400,
      "p": [
        {
          "n": "arg1",
          "p": T?.$h??1572864
        }
      ],
      "n": "InvokeJS",
      "d": this.$h,
      "H": 12886802443,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886802443)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591835147),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h,
      "n": "Arg1Marshaler",
      "d": this.$h,
      "H": 8591835147,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591835147),
//--TRIMMABLE-BOUNDARY-START(21476737035),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,
      "n": "ResMarshaler",
      "d": this.$h,
      "H": 21476737035,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476737035),
//--TRIMMABLE-BOUNDARY-START(17181769739),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": this.$h,
      "H": 17181769739,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181769739)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296867851),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "arg1Marshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h
        },
        {
          "n": "resMarshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296867851,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296867851)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    },
    {
      "h": TResult?.$h??1638400,
      "n": "TResult"
    }
  ],
  "r": 2,
  "d": 1310731,
  "H": 1900555,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument+FuncJS<${T?.$fullName},${TResult?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalerArgument${separator}FuncJS$${T?.$getFullName(separator)}$${TResult?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$ = $v))(T, TResult);
            }
            //--TRIMMABLE-BOUNDARY-END(1900555)
            
            //--TRIMMABLE-BOUNDARY-START(1835019)
            static $_FuncJS$$$$;
            static FuncJS$$$$(T1, T2, TResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1835019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$$ ??= $asm.$ncls(`$srij.SRIJ.JSMarshalerArgument.FuncJS<,,>`, (T1, T2, TResult) => $asm.$gt(`$srij.SRIJ.JSMarshalerArgument.FuncJS<,,>`, [T1, T2, TResult], ($self) => class FuncJS$$$$ extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591769611)
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(8591769611)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886736907)
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(12886736907)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771638795)
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(25771638795)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476671499)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(21476671499)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296802315)
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296802315);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296802315)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181704203)
                    /*TResult */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2)
                    {
                        /*TResult*/ let res;
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181704203);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$srij.SRIJ.JSMarshalerArgument, 4, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        $.$srij.SRIJ.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181704203)
                    
                    static $H = 1835019;
                    static $h = 1835019;
                    static $g = 3;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181704203),
    {
      "r": TResult?.$h??1703936,
      "p": [
        {
          "n": "arg1",
          "p": T1?.$h??1572864
        },
        {
          "n": "arg2",
          "p": T2?.$h??1638400
        }
      ],
      "n": "InvokeJS",
      "d": this.$h,
      "H": 17181704203,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181704203)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591769611),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,
      "n": "Arg1Marshaler",
      "d": this.$h,
      "H": 8591769611,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591769611),
//--TRIMMABLE-BOUNDARY-START(12886736907),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,
      "n": "Arg2Marshaler",
      "d": this.$h,
      "H": 12886736907,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886736907),
//--TRIMMABLE-BOUNDARY-START(25771638795),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,
      "n": "ResMarshaler",
      "d": this.$h,
      "H": 25771638795,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771638795),
//--TRIMMABLE-BOUNDARY-START(21476671499),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": this.$h,
      "H": 21476671499,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476671499)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802315),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "arg1Marshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        },
        {
          "n": "resMarshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296802315,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296802315)
  ],
  "s": [
    {
      "h": T1?.$h??1572864,
      "n": "T1"
    },
    {
      "h": T2?.$h??1638400,
      "n": "T2"
    },
    {
      "h": TResult?.$h??1703936,
      "n": "TResult"
    }
  ],
  "r": 3,
  "d": 1310731,
  "H": 1835019,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument+FuncJS<${T1?.$fullName},${T2?.$fullName},${TResult?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalerArgument${separator}FuncJS$${T1?.$getFullName(separator)}$${T2?.$getFullName(separator)}$${TResult?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$$ = $v))(T1, T2, TResult);
            }
            //--TRIMMABLE-BOUNDARY-END(1835019)
            
            //--TRIMMABLE-BOUNDARY-START(1769483)
            static $_FuncJS$$$$$;
            static FuncJS$$$$$(T1, T2, T3, TResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1769483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$srij.SRIJ.JSMarshalerArgument;
                return ($cls.$_FuncJS$$$$$ ??= $asm.$ncls(`$srij.SRIJ.JSMarshalerArgument.FuncJS<,,,>`, (T1, T2, T3, TResult) => $asm.$gt(`$srij.SRIJ.JSMarshalerArgument.FuncJS<,,,>`, [T1, T2, T3, TResult], ($self) => class FuncJS$$$$$ extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591704075)
                    /*ArgumentToJSCallback<T1>*/ Arg1Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(8591704075)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886671371)
                    /*ArgumentToJSCallback<T2>*/ Arg2Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(12886671371)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181638667)
                    /*ArgumentToJSCallback<T3>*/ Arg3Marshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(17181638667)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066540555)
                    /*ArgumentToManagedCallback<TResult>*/ ResMarshaler = null;
                    //--TRIMMABLE-BOUNDARY-END(30066540555)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771573259)
                    /*JSObject*/ JSObject = null;
                    //--TRIMMABLE-BOUNDARY-END(25771573259)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296736779)
                    $ctor$1(/*JSObject*/ holder, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296736779);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.JSObject = holder;
                            this.Arg1Marshaler = arg1Marshaler;
                            this.Arg2Marshaler = arg2Marshaler;
                            this.Arg3Marshaler = arg3Marshaler;
                            this.ResMarshaler = resMarshaler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296736779)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476605963)
                    /*TResult */ InvokeJS(/*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3)
                    {
                        /*TResult*/ let res;
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476605963);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Span<JSMarshalerArgument>*/ let $arguments = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$srij.SRIJ.JSMarshalerArgument, 5, null);
                        /*ref JSMarshalerArgument*/ let args_exception = $arguments.get_Item(0);
                        /*ref JSMarshalerArgument*/ let args_return = $arguments.get_Item(1);
                        /*ref JSMarshalerArgument*/ let args_arg1 = $arguments.get_Item(2);
                        /*ref JSMarshalerArgument*/ let args_arg2 = $arguments.get_Item(3);
                        /*ref JSMarshalerArgument*/ let args_arg3 = $arguments.get_Item(4);
                        args_exception.$v.Initialize();
                        args_return.$v.Initialize();
                        this.Arg1Marshaler.Invoke(args_arg1, arg1);
                        this.Arg2Marshaler.Invoke(args_arg2, arg2);
                        this.Arg3Marshaler.Invoke(args_arg3, arg3);
                        $.$srij.SRIJ.JSFunctionBinding.InvokeJSFunction(this.JSObject, $arguments);
                        this.ResMarshaler.Invoke(args_return, $.$ref(() => res, ($v) => res = $v, TResult));
                        return res;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476605963)
                    
                    static $H = 1769483;
                    static $h = 1769483;
                    static $g = 4;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476605963),
    {
      "r": TResult?.$h??1769472,
      "p": [
        {
          "n": "arg1",
          "p": T1?.$h??1572864
        },
        {
          "n": "arg2",
          "p": T2?.$h??1638400
        },
        {
          "n": "arg3",
          "p": T3?.$h??1703936
        }
      ],
      "n": "InvokeJS",
      "d": this.$h,
      "H": 21476605963,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476605963)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591704075),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h,
      "n": "Arg1Marshaler",
      "d": this.$h,
      "H": 8591704075,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591704075),
//--TRIMMABLE-BOUNDARY-START(12886671371),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h,
      "n": "Arg2Marshaler",
      "d": this.$h,
      "H": 12886671371,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886671371),
//--TRIMMABLE-BOUNDARY-START(17181638667),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h,
      "n": "Arg3Marshaler",
      "d": this.$h,
      "H": 17181638667,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181638667),
//--TRIMMABLE-BOUNDARY-START(30066540555),
    {
      "t": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h,
      "n": "ResMarshaler",
      "d": this.$h,
      "H": 30066540555,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066540555),
//--TRIMMABLE-BOUNDARY-START(25771573259),
    {
      "t": 2228235,
      "n": "JSObject",
      "d": this.$h,
      "H": 25771573259,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771573259)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296736779),
    {
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "arg1Marshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        },
        {
          "n": "arg3Marshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h
        },
        {
          "n": "resMarshaler",
          "p": $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296736779,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296736779)
  ],
  "s": [
    {
      "h": T1?.$h??1572864,
      "n": "T1"
    },
    {
      "h": T2?.$h??1638400,
      "n": "T2"
    },
    {
      "h": T3?.$h??1703936,
      "n": "T3"
    },
    {
      "h": TResult?.$h??1769472,
      "n": "TResult"
    }
  ],
  "r": 4,
  "d": 1310731,
  "H": 1769483,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument+FuncJS<${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${TResult?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalerArgument${separator}FuncJS$${T1?.$getFullName(separator)}$${T2?.$getFullName(separator)}$${T3?.$getFullName(separator)}$${TResult?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_FuncJS$$$$$ = $v))(T1, T2, T3, TResult);
            }
            //--TRIMMABLE-BOUNDARY-END(1769483)
            
            //--TRIMMABLE-BOUNDARY-START(498217517067)
            /*void */ ToManaged$48(TResult, /*out Func<TResult>?*/ value, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                let $t45 = new ($.$srij.SRIJ.JSMarshalerArgument.FuncJS$$(TResult))().$ctor$1(holder, resMarshaler);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498217517067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.S.Func$$(TResult))().$ctor($t45, $t45.InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(498217517067)
            
            //--TRIMMABLE-BOUNDARY-START(468152745995)
            /*void */ ToManaged$41(T, TResult, /*out Func<T, TResult>?*/ value, /*ArgumentToJSCallback<T>*/ arg1Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                let $t46 = new ($.$srij.SRIJ.JSMarshalerArgument.FuncJS$$$(T, TResult))().$ctor$1(holder, arg1Marshaler, resMarshaler);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468152745995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.S.Func$$$(T, TResult))().$ctor($t46, $t46.InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(468152745995)
            
            //--TRIMMABLE-BOUNDARY-START(489627582475)
            /*void */ ToManaged$46(T1, T2, TResult, /*out Func<T1, T2, TResult>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                let $t47 = new ($.$srij.SRIJ.JSMarshalerArgument.FuncJS$$$$(T1, T2, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, resMarshaler);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489627582475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.S.Func$$$$(T1, T2, TResult))().$ctor($t47, $t47.InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(489627582475)
            
            //--TRIMMABLE-BOUNDARY-START(481037647883)
            /*void */ ToManaged$44(T1, T2, T3, TResult, /*out Func<T1, T2, T3, TResult>?*/ value, /*ArgumentToJSCallback<T1>*/ arg1Marshaler, /*ArgumentToJSCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<T3>*/ arg3Marshaler, /*ArgumentToManagedCallback<TResult>*/ resMarshaler)
            {
                let $t48 = new ($.$srij.SRIJ.JSMarshalerArgument.FuncJS$$$$$(T1, T2, T3, TResult))().$ctor$1(holder, arg1Marshaler, arg2Marshaler, arg3Marshaler, resMarshaler);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481037647883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                /*var*/ let ctx = this.ToManagedContext;
                /*var*/ let holder = ctx.CreateCSOwnedProxy(this.slot.JSHandle);
                value.$v = new ($.$$.S.Func$$$$$(T1, T2, T3, TResult))().$ctor($t48, $t48.InvokeJS);
            }
            //--TRIMMABLE-BOUNDARY-END(481037647883)
            
            //--TRIMMABLE-BOUNDARY-START(64425820171)
            /*void */ ToJS(/*Action*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425820171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Action*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.SRIJ.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    cpy.Invoke();
                }, $eRYFKb ??= {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h}],"n":"","d":1310731,"h":0,"f":17825794});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(64425820171)
            
            //--TRIMMABLE-BOUNDARY-START(244814446603)
            /*void */ ToJS$42(T, /*Action<T>*/ value, /*ArgumentToManagedCallback<T>*/ arg1Marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814446603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Action<T>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.SRIJ.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*T*/ let arg1cs;
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T));
                    cpy.Invoke(arg1cs);
                }, $vhxGue ??= {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h}],"n":"","d":1310731,"h":0,"f":17825794});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(244814446603)
            
            //--TRIMMABLE-BOUNDARY-START(266289283083)
            /*void */ ToJS$47(T1, T2, /*Action<T1, T2>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289283083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Action<T1, T2>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.SRIJ.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*T1*/ let arg1cs;
                    /*T2*/ let arg2cs;
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    cpy.Invoke(arg1cs, arg2cs);
                }, $DvEaoe ??= {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h}],"n":"","d":1310731,"h":0,"f":17825794});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(266289283083)
            
            //--TRIMMABLE-BOUNDARY-START(257699348491)
            /*void */ ToJS$45(T1, T2, T3, /*Action<T1, T2, T3>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<T3>*/ arg3Marshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699348491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Action<T1, T2, T3>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.SRIJ.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*T1*/ let arg1cs;
                    /*T2*/ let arg2cs;
                    /*T3*/ let arg3cs;
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*ref JSMarshalerArgument*/ let arg4 = $arguments.Add(5);
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    arg3Marshaler.Invoke(arg4, $.$ref(() => arg3cs, ($v) => arg3cs = $v, T3));
                    cpy.Invoke(arg1cs, arg2cs, arg3cs);
                }, $vQEWWh ??= {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h}],"n":"","d":1310731,"h":0,"f":17825794});
                this.slot.Type = 24/*MarshalerType.Action*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(257699348491)
            
            //--TRIMMABLE-BOUNDARY-START(270584250379)
            /*void */ ToJS$48(TResult, /*Func<TResult>*/ value, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584250379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Func<TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.SRIJ.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*TResult*/ let resCs = cpy.Invoke();
                    resMarshaler.Invoke(res, resCs);
                }, $cFCYoa ??= {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h}],"n":"","d":1310731,"h":0,"f":17825794});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(270584250379)
            
            //--TRIMMABLE-BOUNDARY-START(240519479307)
            /*void */ ToJS$41(T, TResult, /*Func<T, TResult>*/ value, /*ArgumentToManagedCallback<T>*/ arg1Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519479307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Func<T, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.SRIJ.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*T*/ let arg1cs;
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs);
                    resMarshaler.Invoke(res, resCs);
                }, $zwvlIj ??= {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h}],"n":"","d":1310731,"h":0,"f":17825794});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(240519479307)
            
            //--TRIMMABLE-BOUNDARY-START(261994315787)
            /*void */ ToJS$46(T1, T2, TResult, /*Func<T1, T2, TResult>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994315787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Func<T1, T2, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.SRIJ.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*T1*/ let arg1cs;
                    /*T2*/ let arg2cs;
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs, arg2cs);
                    resMarshaler.Invoke(res, resCs);
                }, $TWlmyd ??= {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h}],"n":"","d":1310731,"h":0,"f":17825794});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(261994315787)
            
            //--TRIMMABLE-BOUNDARY-START(253404381195)
            /*void */ ToJS$44(T1, T2, T3, TResult, /*Func<T1, T2, T3, TResult>*/ value, /*ArgumentToManagedCallback<T1>*/ arg1Marshaler, /*ArgumentToManagedCallback<T2>*/ arg2Marshaler, /*ArgumentToManagedCallback<T3>*/ arg3Marshaler, /*ArgumentToJSCallback<TResult>*/ resMarshaler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404381195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Func<T1, T2, T3, TResult>*/ let cpy = value;
                /*JSHostImplementation.ToManagedCallback*/ let cb = new $.$srij.SRIJ.JSHostImplementation.ToManagedCallback().$ctor(this,  (/*JSMarshalerArgument**/ $arguments) =>
                {
                    /*T1*/ let arg1cs;
                    /*T2*/ let arg2cs;
                    /*T3*/ let arg3cs;
                    /*ref JSMarshalerArgument*/ let res = $arguments.Add(1);
                    /*ref JSMarshalerArgument*/ let arg2 = $arguments.Add(3);
                    /*ref JSMarshalerArgument*/ let arg3 = $arguments.Add(4);
                    /*ref JSMarshalerArgument*/ let arg4 = $arguments.Add(5);
                    arg1Marshaler.Invoke(arg2, $.$ref(() => arg1cs, ($v) => arg1cs = $v, T1));
                    arg2Marshaler.Invoke(arg3, $.$ref(() => arg2cs, ($v) => arg2cs = $v, T2));
                    arg3Marshaler.Invoke(arg4, $.$ref(() => arg3cs, ($v) => arg3cs = $v, T3));
                    /*TResult*/ let resCs = cpy.Invoke(arg1cs, arg2cs, arg3cs);
                    resMarshaler.Invoke(res, resCs);
                }, $RqJNrf ??= {"r":65537,"p":[{"n":"arguments","p":$.$typePointer($.$srij.SRIJ.JSMarshalerArgument).$h}],"n":"","d":1310731,"h":0,"f":17825794});
                this.slot.Type = 25/*MarshalerType.Function*/;
                /*var*/ let ctx = this.ToJSContext;
                this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(cb, 2);
            }
            //--TRIMMABLE-BOUNDARY-END(253404381195)
            
            //--TRIMMABLE-BOUNDARY-START(416613138443)
            /*void */ ToManaged$29(/*out object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416613138443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                }
                else if (this.slot.Type === 14/*MarshalerType.Object*/)
                {
                    value.$v = ($.$$.SRI.GCHandle.op_Explicit$1(this.slot.GCHandle)).Target;
                }
                else if (this.slot.Type === 3/*MarshalerType.Boolean*/)
                {
                    /*bool*/ let v;
                    this.ToManaged$4($.$ref(() => v, ($v) => v = $v, $.$$.S.Boolean));
                    value.$v = $.$box(v, $.$$.S.Boolean);
                }
                else if (this.slot.Type === 10/*MarshalerType.Double*/)
                {
                    /*double*/ let v;
                    this.ToManaged$10($.$ref(() => v, ($v) => v = $v, $.$$.S.Double));
                    value.$v = $.$box(v, $.$$.S.Double);
                }
                else if (this.slot.Type === 13/*MarshalerType.JSObject*/)
                {
                    /*JSObject?*/ let val;
                    this.ToManaged$31($.$ref(() => val, ($v) => val = $v, $.$srij.SRIJ.JSObject));
                    value.$v = val;
                }
                else if (this.slot.Type === 15/*MarshalerType.String*/)
                {
                    /*string?*/ let val;
                    this.ToManaged$37($.$ref(() => val, ($v) => val = $v, $.$$.S.String));
                    value.$v = val;
                }
                else if (this.slot.Type === 16/*MarshalerType.Exception*/)
                {
                    /*Exception?*/ let val;
                    this.ToManaged$12($.$ref(() => val, ($v) => val = $v, $.$$.S.Exception));
                    value.$v = val;
                }
                else if (this.slot.Type === 17/*MarshalerType.DateTime*/)
                {
                    /*DateTime?*/ let val;
                    this.ToManaged$21($.$ref(() => val, ($v) => val = $v, $.$typeNullable($.$$.S.DateTime)));
                    value.$v = $.$clone(val);
                }
                else if (this.slot.Type === 27/*MarshalerType.JSException*/)
                {
                    /*Exception?*/ let val;
                    this.ToManaged$12($.$ref(() => val, ($v) => val = $v, $.$$.S.Exception));
                    value.$v = val;
                }
                else if (this.slot.Type === 21/*MarshalerType.Array*/)
                {
                    if (this.slot.ElementType === 4/*MarshalerType.Byte*/)
                    {
                        /*byte[]?*/ let val;
                        this.ToManaged$6($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$$.S.Byte)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 10/*MarshalerType.Double*/)
                    {
                        /*double[]?*/ let val;
                        this.ToManaged$11($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$$.S.Double)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 7/*MarshalerType.Int32*/)
                    {
                        /*int[]?*/ let val;
                        this.ToManaged$15($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$$.S.Int32)));
                        value.$v = val;
                    }
                    else if (this.slot.ElementType === 14/*MarshalerType.Object*/)
                    {
                        /*object?[]?*/ let val;
                        this.ToManaged$30($.$ref(() => val, ($v) => val = $v, $.$typeArray($.$$.S.Object)));
                        value.$v = val;
                    }
                    else 
                    {
                        throw new $.$$.S.NotSupportedException().$ctor$12($.$srij.S.SR.Format$6($.$srij.S.SR.ToManagedNotImplemented, $.$$.S.Enum.ToStringT($.$srij.SRIJ.MarshalerType, $.$$.S.Byte, this.slot.ElementType) + "[]"));
                    }
                }
                else if (this.slot.Type === 20/*MarshalerType.Task*/ || this.slot.Type === 28/*MarshalerType.TaskResolved*/ || this.slot.Type === 29/*MarshalerType.TaskRejected*/)
                {
                    /*Task<object?>?*/ let val;
                    this.ToManaged$43($.$$.S.Object, $.$ref(() => val, ($v) => val = $v, $.$$.STT.Task$$($.$$.S.Object)), new ($.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$($.$$.S.Object))().$ctor($.$srij.SRIJ.JSMarshalerArgument, /*static*/ (/*JSMarshalerArgument*/ arg, /*object?*/ value) =>
                    {
                        arg.$v.ToManaged$29(value);
                    }, $ZpFaBc ??= {"r":65537,"p":[{"n":"arg","p":1310731,"f":4},{"n":"value","p":131073,"f":2}],"n":"","d":1310731,"h":0,"f":17825826}));
                    value.$v = val;
                }
                else 
                {
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$srij.S.SR.Format$6($.$srij.S.SR.ToManagedNotImplemented, $.$box(this.slot.Type, $.$srij.SRIJ.MarshalerType)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(416613138443)
            
            //--TRIMMABLE-BOUNDARY-START(188979871755)
            /*void */ ToJS$29(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979871755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                /*Type*/ let type = $.$$.S.Object.GetType.call(value);
                let ut;
                if (type.IsPrimitive)
                {
                    if ($.$$.S.Int64.$type === type)
                    {
                        throw new $.$$.S.NotSupportedException().$ctor$12($.$srij.S.SR.Format$6($.$srij.S.SR.ToJSNotImplemented, type.FullName));
                    }
                    else if ($.$$.S.Int32.$type === type)
                    {
                        /*var*/ let v = $.$cast(value, $.$$.S.Int32);
                        this.ToJS$14(v);
                    }
                    else if ($.$$.S.Int16.$type === type)
                    {
                        /*var*/ let v = $.$cast(value, $.$$.S.Int16);
                        this.ToJS$13(v);
                    }
                    else if ($.$$.S.Byte.$type === type)
                    {
                        /*var*/ let v = $.$cast(value, $.$$.S.Byte);
                        this.ToJS$5(v);
                    }
                    else if ($.$$.S.Char.$type === type)
                    {
                        /*var*/ let v = $.$cast(value, $.$$.S.Char);
                        this.ToJS$7(v);
                    }
                    else if ($.$$.S.Boolean.$type === type)
                    {
                        /*var*/ let v = $.$cast(value, $.$$.S.Boolean);
                        this.ToJS$4(v);
                    }
                    else if ($.$$.S.Double.$type === type)
                    {
                        /*var*/ let v = $.$cast(value, $.$$.S.Double);
                        this.ToJS$10(v);
                    }
                    else if ($.$$.S.Single.$type === type)
                    {
                        /*var*/ let v = $.$cast(value, $.$$.S.Single);
                        this.ToJS$33(v);
                    }
                    else if ($.$$.S.IntPtr.$type === type)
                    {
                        /*var*/ let v = $.$cast(value, $.$$.S.IntPtr);
                        this.ToJS$17(v);
                    }
                    else 
                    {
                        throw new $.$$.S.NotSupportedException().$ctor$12($.$srij.S.SR.Format$6($.$srij.S.SR.ToJSNotImplemented, type.FullName));
                    }
                }
                else if ($.$$.S.String.$type === type)
                {
                    /*string?*/ let str = $.$as(value, $.$$.S.String);
                    this.ToJS$37(str);
                }
                else if ($.$$.S.DateTimeOffset.$type === type)
                {
                    /*var*/ let v = $.$cast(value, $.$$.S.DateTimeOffset);
                    this.ToJS$9(v);
                }
                else if ($.$$.S.DateTime.$type === type)
                {
                    /*var*/ let v = $.$cast(value, $.$$.S.DateTime);
                    this.ToJS$8(v);
                }
                else if ($.$is($.$$.S.Nullable.GetUnderlyingType(type), $.$$.S.Type, { set $v($v){ ut = $v; } }) && ut !== null)
                {
                    if ($.$$.S.Int64.$type === ut)
                    {
                        throw new $.$$.S.NotSupportedException().$ctor$12($.$srij.S.SR.Format$6($.$srij.S.SR.ToJSNotImplemented, type.FullName));
                    }
                    else if ($.$$.S.Int32.$type === ut)
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.S.Int32));
                        this.ToJS$25(nv);
                    }
                    else if ($.$$.S.Int16.$type === ut)
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.S.Int16));
                        this.ToJS$24(nv);
                    }
                    else if ($.$$.S.Byte.$type === ut)
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.S.Byte));
                        this.ToJS$19(nv);
                    }
                    else if ($.$$.S.Char.$type === ut)
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.S.Char));
                        this.ToJS$20(nv);
                    }
                    else if ($.$$.S.Boolean.$type === ut)
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.S.Boolean));
                        this.ToJS$18(nv);
                    }
                    else if ($.$$.S.Double.$type === ut)
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.S.Double));
                        this.ToJS$23(nv);
                    }
                    else if ($.$$.S.Single.$type === ut)
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.S.Single));
                        this.ToJS$28(nv);
                    }
                    else if ($.$$.S.IntPtr.$type === ut)
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.S.IntPtr));
                        this.ToJS$27(nv);
                    }
                    else if ($.$$.S.DateTimeOffset.$type === ut)
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.S.DateTimeOffset));
                        this.ToJS$22($.$clone(nv));
                    }
                    else if ($.$$.S.DateTime.$type === ut)
                    {
                        /*var*/ let nv = $.$as(value, $.$typeNullable($.$$.S.DateTime));
                        this.ToJS$21($.$clone(nv));
                    }
                    else 
                    {
                        throw new $.$$.S.NotSupportedException().$ctor$12($.$srij.S.SR.Format$6($.$srij.S.SR.ToJSNotImplemented, type.FullName));
                    }
                }
                else if ($.$srij.SRIJ.JSObject.$type.IsAssignableFrom(type))
                {
                    /*JSObject?*/ let val = $.$as(value, $.$srij.SRIJ.JSObject);
                    this.ToJS$31(val);
                }
                else if ($.$$.S.Exception.$type.IsAssignableFrom(type))
                {
                    /*Exception?*/ let val = $.$as(value, $.$$.S.Exception);
                    this.ToJS$12(val);
                }
                else if ($.$$.STT.Task$$($.$$.S.Object).$type === type)
                {
                    /*Task<object>?*/ let val = $.$as(value, $.$$.STT.Task$$($.$$.S.Object));
                    this.ToJS$43($.$$.S.Object, val, new ($.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$($.$$.S.Object))().$ctor(this,  (/*JSMarshalerArgument*/ arg, /*object*/ value) =>
                    {
                        /*object?*/ let valueRef = value;
                        arg.$v.ToJS$29(valueRef);
                    }, $cibnUd ??= {"r":65537,"p":[{"n":"arg","p":1310731,"f":4},{"n":"value","p":131073}],"n":"","d":1310731,"h":0,"f":17825794}));
                }
                else if ($.$$.STT.Task.$type.IsAssignableFrom(type))
                {
                    /*Task?*/ let val = $.$as(value, $.$$.STT.Task);
                    this.ToJSDynamic(val);
                }
                else if ($.$typeArray($.$$.S.Byte).$type === type)
                {
                    /*byte[]*/ let val = $.$cast(value, $.$typeArray($.$$.S.Byte));
                    this.ToJS$6(val);
                }
                else if ($.$typeArray($.$$.S.Int32).$type === type)
                {
                    /*int[]*/ let val = $.$cast(value, $.$typeArray($.$$.S.Int32));
                    this.ToJS$15(val);
                }
                else if ($.$typeArray($.$$.S.Double).$type === type)
                {
                    /*double[]*/ let val = $.$cast(value, $.$typeArray($.$$.S.Double));
                    this.ToJS$11(val);
                }
                else if ($.$typeArray($.$$.S.String).$type === type)
                {
                    /*string[]*/ let val = $.$cast(value, $.$typeArray($.$$.S.String));
                    this.ToJS$38(val);
                }
                else if ($.$typeArray($.$$.S.Object).$type === type)
                {
                    /*object[]*/ let val = $.$cast(value, $.$typeArray($.$$.S.Object));
                    this.ToJS$30(val);
                }
                else if (type.IsArray)
                {
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$srij.S.SR.Format$6($.$srij.S.SR.ToJSNotImplemented, type.FullName));
                }
                else if ($.$$.S.MulticastDelegate.$type.IsAssignableFrom(type.BaseType))
                {
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$srij.S.SR.Format$6($.$srij.S.SR.ToJSNotImplemented, type.FullName));
                }
                else if (type.IsGenericType && type.GetGenericTypeDefinition() === $.$$.S.ArraySegment$$().$type)
                {
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$srij.S.SR.Format$6($.$srij.S.SR.ToJSNotImplemented, type.FullName));
                }
                else if (type.IsGenericType && type.GetGenericTypeDefinition() === $.$$.S.Span$$().$type)
                {
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$srij.S.SR.Format$6($.$srij.S.SR.ToJSNotImplemented, type.FullName));
                }
                else 
                {
                    this.slot.Type = 14/*MarshalerType.Object*/;
                    /*var*/ let ctx = this.ToJSContext;
                    this.slot.GCHandle = ctx.GetJSOwnedObjectGCHandle(value, 2);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979871755)
            
            //--TRIMMABLE-BOUNDARY-START(420908105739)
            /*void */ ToManaged$30(/*out object?[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420908105739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.slot.Type === 0/*MarshalerType.None*/)
                {
                    value.$v = null;
                    return;
                }
                value.$v = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [this.slot.Length], null);
                /*JSMarshalerArgument**/ let payload = $.$$.$interop.$addr2Ptr(this.slot.IntPtrValue, null);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*object?*/ let val;
                    arg.$v.ToManaged$29($.$ref(() => val, ($v) => val = $v, $.$$.S.Object));
                    $.$$.System.Array.$WriteT1.call(value.$v, val, i);
                }
                $.$srij.Interop.Runtime.DeregisterGCRoot(this.slot.IntPtrValue);
                $.$$.SRI.Marshal.FreeHGlobal(this.slot.IntPtrValue);
            }
            //--TRIMMABLE-BOUNDARY-END(420908105739)
            
            //--TRIMMABLE-BOUNDARY-START(193274839051)
            /*void */ ToJS$30(/*object?[]*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274839051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this.slot.Type = 0/*MarshalerType.None*/;
                    return;
                }
                this.slot.Length = value.length;
                /*int*/ let bytes = ((value.length * 32) | 0);
                this.slot.Type = 21/*MarshalerType.Array*/;
                /*JSMarshalerArgument**/ let payload = $.$$.$interop.$addr2Ptr($.$$.SRI.Marshal.AllocHGlobal(bytes), null);
                $.$$.SRC.Unsafe.InitBlock$1(payload, 0, (bytes >>> 0));
                $.$srij.Interop.Runtime.RegisterGCRoot(payload, bytes, $.$$.S.IntPtr.Zero);
                for(/*int*/ let i = 0; i < this.slot.Length; i++)
                {
                    /*ref JSMarshalerArgument*/ let arg = payload.Add(i);
                    /*object?*/ let val = $.$$.System.Array.$ReadT1.call(value, i);
                    arg.$v.ToJS$29(val);
                    $.$$.System.Array.$WriteT1.call(value, val, i);
                }
                this.slot.ElementType = 14/*MarshalerType.Object*/;
                this.slot.IntPtrValue = $.$$.$interop.$ptr2Addr(payload);
            }
            //--TRIMMABLE-BOUNDARY-END(193274839051)
            
            //--TRIMMABLE-BOUNDARY-START(4296278027)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296278027)
            
            //--TRIMMABLE-BOUNDARY-START(4296278027)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296278027)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.slot = this.slot.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60130852875)
                this.slot = $.$default($.$srij.SRIJ.JSMarshalerArgument.JSMarshalerArgumentImpl);
                //--TRIMMABLE-BOUNDARY-END(60130852875)
                
            }
            static $h = 1310731;
            static $z = 32;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(511102418955),
    {
      "p": 2293771,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066081803,
        "f": 50331656
      },
      "n": "ToManagedContext",
      "d": 1310731,
      "h": 511102418955,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(511102418955),
//--TRIMMABLE-BOUNDARY-START(283469152267),
    {
      "p": 2293771,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476147211,
        "f": 50331656
      },
      "n": "ToJSContext",
      "d": 1310731,
      "h": 283469152267,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(283469152267)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950983691),
    {
      "r": 65537,
      "n": "Initialize",
      "d": 1310731,
      "h": 42950983691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950983691),
//--TRIMMABLE-BOUNDARY-START(8591245323),
    {
      "r": 2293771,
      "n": "AssertCurrentThreadContext",
      "d": 1310731,
      "h": 8591245323,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591245323),
//--TRIMMABLE-BOUNDARY-START(502512484363),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "ToManagedBig",
      "d": 1310731,
      "h": 502512484363,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(502512484363),
//--TRIMMABLE-BOUNDARY-START(274879217675),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "ToJSBig",
      "d": 1310731,
      "h": 274879217675,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(274879217675),
//--TRIMMABLE-BOUNDARY-START(506807451659),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Int64).$h,
          "f": 2
        }
      ],
      "n": "ToManagedBig",
      "o": "@$1",
      "d": 1310731,
      "h": 506807451659,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(506807451659),
//--TRIMMABLE-BOUNDARY-START(279174184971),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Int64).$h
        }
      ],
      "n": "ToJSBig",
      "o": "@$1",
      "d": 1310731,
      "h": 279174184971,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(279174184971),
//--TRIMMABLE-BOUNDARY-START(322123857931),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 458753,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$7",
      "d": 1310731,
      "h": 322123857931,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(322123857931),
//--TRIMMABLE-BOUNDARY-START(94490591243),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "ToJS",
      "o": "@$7",
      "d": 1310731,
      "h": 94490591243,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490591243),
//--TRIMMABLE-BOUNDARY-START(377958432779),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Char).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$20",
      "d": 1310731,
      "h": 377958432779,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(377958432779),
//--TRIMMABLE-BOUNDARY-START(150325166091),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Char).$h
        }
      ],
      "n": "ToJS",
      "o": "@$20",
      "d": 1310731,
      "h": 150325166091,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150325166091),
//--TRIMMABLE-BOUNDARY-START(433793007627),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1114113,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$33",
      "d": 1310731,
      "h": 433793007627,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(433793007627),
//--TRIMMABLE-BOUNDARY-START(206159740939),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1114113
        }
      ],
      "n": "ToJS",
      "o": "@$33",
      "d": 1310731,
      "h": 206159740939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(206159740939),
//--TRIMMABLE-BOUNDARY-START(412318171147),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Single).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$28",
      "d": 1310731,
      "h": 412318171147,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(412318171147),
//--TRIMMABLE-BOUNDARY-START(184684904459),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Single).$h
        }
      ],
      "n": "ToJS",
      "o": "@$28",
      "d": 1310731,
      "h": 184684904459,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684904459),
//--TRIMMABLE-BOUNDARY-START(347893661707),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 524289,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$13",
      "d": 1310731,
      "h": 347893661707,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(347893661707),
//--TRIMMABLE-BOUNDARY-START(120260395019),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 524289
        }
      ],
      "n": "ToJS",
      "o": "@$13",
      "d": 1310731,
      "h": 120260395019,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120260395019),
//--TRIMMABLE-BOUNDARY-START(395138301963),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Int16).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$24",
      "d": 1310731,
      "h": 395138301963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(395138301963),
//--TRIMMABLE-BOUNDARY-START(167505035275),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Int16).$h
        }
      ],
      "n": "ToJS",
      "o": "@$24",
      "d": 1310731,
      "h": 167505035275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167505035275),
//--TRIMMABLE-BOUNDARY-START(365073530891),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 786433,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$17",
      "d": 1310731,
      "h": 365073530891,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(365073530891),
//--TRIMMABLE-BOUNDARY-START(137440264203),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 786433
        }
      ],
      "n": "ToJS",
      "o": "@$17",
      "d": 1310731,
      "h": 137440264203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137440264203),
//--TRIMMABLE-BOUNDARY-START(408023203851),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.IntPtr).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$27",
      "d": 1310731,
      "h": 408023203851,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(408023203851),
//--TRIMMABLE-BOUNDARY-START(180389937163),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.IntPtr).$h
        }
      ],
      "n": "ToJS",
      "o": "@$27",
      "d": 1310731,
      "h": 180389937163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180389937163),
//--TRIMMABLE-BOUNDARY-START(463857778699),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typePointer($.$$.S.Void).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$40",
      "d": 1310731,
      "h": 463857778699,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(463857778699),
//--TRIMMABLE-BOUNDARY-START(236224512011),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typePointer($.$$.S.Void).$h
        }
      ],
      "n": "ToJS",
      "o": "@$40",
      "d": 1310731,
      "h": 236224512011,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(236224512011),
//--TRIMMABLE-BOUNDARY-START(360778563595),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$16",
      "d": 1310731,
      "h": 360778563595,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(360778563595),
//--TRIMMABLE-BOUNDARY-START(133145296907),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "ToJS",
      "o": "@$16",
      "d": 1310731,
      "h": 133145296907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133145296907),
//--TRIMMABLE-BOUNDARY-START(403728236555),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Int64).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$26",
      "d": 1310731,
      "h": 403728236555,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(403728236555),
//--TRIMMABLE-BOUNDARY-START(176094969867),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Int64).$h
        }
      ],
      "n": "ToJS",
      "o": "@$26",
      "d": 1310731,
      "h": 176094969867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094969867),
//--TRIMMABLE-BOUNDARY-START(309238956043),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$4",
      "d": 1310731,
      "h": 309238956043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(309238956043),
//--TRIMMABLE-BOUNDARY-START(81605689355),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "ToJS",
      "o": "@$4",
      "d": 1310731,
      "h": 81605689355,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605689355),
//--TRIMMABLE-BOUNDARY-START(369368498187),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Boolean).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$18",
      "d": 1310731,
      "h": 369368498187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(369368498187),
//--TRIMMABLE-BOUNDARY-START(141735231499),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Boolean).$h
        }
      ],
      "n": "ToJS",
      "o": "@$18",
      "d": 1310731,
      "h": 141735231499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141735231499),
//--TRIMMABLE-BOUNDARY-START(335008759819),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1179649,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$10",
      "d": 1310731,
      "h": 335008759819,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(335008759819),
//--TRIMMABLE-BOUNDARY-START(107375493131),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "ToJS",
      "o": "@$10",
      "d": 1310731,
      "h": 107375493131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107375493131),
//--TRIMMABLE-BOUNDARY-START(390843334667),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Double).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$23",
      "d": 1310731,
      "h": 390843334667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(390843334667),
//--TRIMMABLE-BOUNDARY-START(163210067979),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Double).$h
        }
      ],
      "n": "ToJS",
      "o": "@$23",
      "d": 1310731,
      "h": 163210067979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163210067979),
//--TRIMMABLE-BOUNDARY-START(339303727115),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Double).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$11",
      "d": 1310731,
      "h": 339303727115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(339303727115),
//--TRIMMABLE-BOUNDARY-START(111670460427),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Double).$h
        }
      ],
      "n": "ToJS",
      "o": "@$11",
      "d": 1310731,
      "h": 111670460427,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670460427),
//--TRIMMABLE-BOUNDARY-START(300649021451),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ArraySegment$$($.$$.S.Double).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$2",
      "d": 1310731,
      "h": 300649021451,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(300649021451),
//--TRIMMABLE-BOUNDARY-START(73015754763),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ArraySegment$$($.$$.S.Double).$h
        }
      ],
      "n": "ToJS",
      "o": "@$2",
      "d": 1310731,
      "h": 73015754763,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015754763),
//--TRIMMABLE-BOUNDARY-START(442382942219),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.Span$$($.$$.S.Double).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$35",
      "d": 1310731,
      "h": 442382942219,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(442382942219),
//--TRIMMABLE-BOUNDARY-START(214749675531),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.Span$$($.$$.S.Double).$h
        }
      ],
      "n": "ToJS",
      "o": "@$35",
      "d": 1310731,
      "h": 214749675531,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214749675531),
//--TRIMMABLE-BOUNDARY-START(343598694411),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 80805889,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$12",
      "d": 1310731,
      "h": 343598694411,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(343598694411),
//--TRIMMABLE-BOUNDARY-START(115965427723),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 80805889
        }
      ],
      "n": "ToJS",
      "o": "@$12",
      "d": 1310731,
      "h": 115965427723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115965427723),
//--TRIMMABLE-BOUNDARY-START(425203073035),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 2228235,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$31",
      "d": 1310731,
      "h": 425203073035,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(425203073035),
//--TRIMMABLE-BOUNDARY-START(197569806347),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 2228235
        }
      ],
      "n": "ToJS",
      "o": "@$31",
      "d": 1310731,
      "h": 197569806347,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197569806347),
//--TRIMMABLE-BOUNDARY-START(429498040331),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$srij.SRIJ.JSObject).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$32",
      "d": 1310731,
      "h": 429498040331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(429498040331),
//--TRIMMABLE-BOUNDARY-START(201864773643),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$srij.SRIJ.JSObject).$h
        }
      ],
      "n": "ToJS",
      "o": "@$32",
      "d": 1310731,
      "h": 201864773643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201864773643),
//--TRIMMABLE-BOUNDARY-START(450972876811),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$37",
      "d": 1310731,
      "h": 450972876811,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(450972876811),
//--TRIMMABLE-BOUNDARY-START(223339610123),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "ToJS",
      "o": "@$37",
      "d": 1310731,
      "h": 223339610123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223339610123),
//--TRIMMABLE-BOUNDARY-START(455267844107),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$38",
      "d": 1310731,
      "h": 455267844107,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(455267844107),
//--TRIMMABLE-BOUNDARY-START(227634577419),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.String).$h
        }
      ],
      "n": "ToJS",
      "o": "@$38",
      "d": 1310731,
      "h": 227634577419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(227634577419),
//--TRIMMABLE-BOUNDARY-START(330713792523),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 66191361,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$9",
      "d": 1310731,
      "h": 330713792523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(330713792523),
//--TRIMMABLE-BOUNDARY-START(103080525835),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 66191361
        }
      ],
      "n": "ToJS",
      "o": "@$9",
      "d": 1310731,
      "h": 103080525835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103080525835),
//--TRIMMABLE-BOUNDARY-START(386548367371),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.DateTimeOffset).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$22",
      "d": 1310731,
      "h": 386548367371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(386548367371),
//--TRIMMABLE-BOUNDARY-START(158915100683),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.DateTimeOffset).$h
        }
      ],
      "n": "ToJS",
      "o": "@$22",
      "d": 1310731,
      "h": 158915100683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158915100683),
//--TRIMMABLE-BOUNDARY-START(326418825227),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 65994753,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$8",
      "d": 1310731,
      "h": 326418825227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(326418825227),
//--TRIMMABLE-BOUNDARY-START(98785558539),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 65994753
        }
      ],
      "n": "ToJS",
      "o": "@$8",
      "d": 1310731,
      "h": 98785558539,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98785558539),
//--TRIMMABLE-BOUNDARY-START(382253400075),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.DateTime).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$21",
      "d": 1310731,
      "h": 382253400075,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(382253400075),
//--TRIMMABLE-BOUNDARY-START(154620133387),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        }
      ],
      "n": "ToJS",
      "o": "@$21",
      "d": 1310731,
      "h": 154620133387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154620133387),
//--TRIMMABLE-BOUNDARY-START(352188629003),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$14",
      "d": 1310731,
      "h": 352188629003,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(352188629003),
//--TRIMMABLE-BOUNDARY-START(124555362315),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "ToJS",
      "o": "@$14",
      "d": 1310731,
      "h": 124555362315,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124555362315),
//--TRIMMABLE-BOUNDARY-START(399433269259),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Int32).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$25",
      "d": 1310731,
      "h": 399433269259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(399433269259),
//--TRIMMABLE-BOUNDARY-START(171800002571),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Int32).$h
        }
      ],
      "n": "ToJS",
      "o": "@$25",
      "d": 1310731,
      "h": 171800002571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171800002571),
//--TRIMMABLE-BOUNDARY-START(356483596299),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Int32).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$15",
      "d": 1310731,
      "h": 356483596299,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(356483596299),
//--TRIMMABLE-BOUNDARY-START(128850329611),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Int32).$h
        }
      ],
      "n": "ToJS",
      "o": "@$15",
      "d": 1310731,
      "h": 128850329611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128850329611),
//--TRIMMABLE-BOUNDARY-START(304943988747),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ArraySegment$$($.$$.S.Int32).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$3",
      "d": 1310731,
      "h": 304943988747,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(304943988747),
//--TRIMMABLE-BOUNDARY-START(77310722059),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ArraySegment$$($.$$.S.Int32).$h
        }
      ],
      "n": "ToJS",
      "o": "@$3",
      "d": 1310731,
      "h": 77310722059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310722059),
//--TRIMMABLE-BOUNDARY-START(446677909515),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.Span$$($.$$.S.Int32).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$36",
      "d": 1310731,
      "h": 446677909515,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(446677909515),
//--TRIMMABLE-BOUNDARY-START(219044642827),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.Span$$($.$$.S.Int32).$h
        }
      ],
      "n": "ToJS",
      "o": "@$36",
      "d": 1310731,
      "h": 219044642827,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(219044642827),
//--TRIMMABLE-BOUNDARY-START(313533923339),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$5",
      "d": 1310731,
      "h": 313533923339,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(313533923339),
//--TRIMMABLE-BOUNDARY-START(85900656651),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        }
      ],
      "n": "ToJS",
      "o": "@$5",
      "d": 1310731,
      "h": 85900656651,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900656651),
//--TRIMMABLE-BOUNDARY-START(373663465483),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Byte).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$19",
      "d": 1310731,
      "h": 373663465483,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(373663465483),
//--TRIMMABLE-BOUNDARY-START(146030198795),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeNullable($.$$.S.Byte).$h
        }
      ],
      "n": "ToJS",
      "o": "@$19",
      "d": 1310731,
      "h": 146030198795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146030198795),
//--TRIMMABLE-BOUNDARY-START(317828890635),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Byte).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$6",
      "d": 1310731,
      "h": 317828890635,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(317828890635),
//--TRIMMABLE-BOUNDARY-START(90195623947),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "ToJS",
      "o": "@$6",
      "d": 1310731,
      "h": 90195623947,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195623947),
//--TRIMMABLE-BOUNDARY-START(296354054155),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$1",
      "d": 1310731,
      "h": 296354054155,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(296354054155),
//--TRIMMABLE-BOUNDARY-START(68720787467),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        }
      ],
      "n": "ToJS",
      "o": "@$1",
      "d": 1310731,
      "h": 68720787467,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720787467),
//--TRIMMABLE-BOUNDARY-START(438087974923),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$34",
      "d": 1310731,
      "h": 438087974923,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(438087974923),
//--TRIMMABLE-BOUNDARY-START(210454708235),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "ToJS",
      "o": "@$34",
      "d": 1310731,
      "h": 210454708235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210454708235),
//--TRIMMABLE-BOUNDARY-START(459562811403),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 178454529,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$39",
      "d": 1310731,
      "h": 459562811403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(459562811403),
//--TRIMMABLE-BOUNDARY-START(476742680587),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => $.$$.STT.Task$$(T).$h,
          "f": 2
        },
        {
          "n": "marshaler",
          "p": (T) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ToManaged",
      "o": "@$43",
      "d": 1310731,
      "h": 476742680587,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(476742680587),
//--TRIMMABLE-BOUNDARY-START(287764119563),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 178454529
        }
      ],
      "n": "ToJSDynamic",
      "d": 1310731,
      "h": 287764119563,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(287764119563),
//--TRIMMABLE-BOUNDARY-START(231929544715),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 178454529
        }
      ],
      "n": "ToJS",
      "o": "@$39",
      "d": 1310731,
      "h": 231929544715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231929544715),
//--TRIMMABLE-BOUNDARY-START(249109413899),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => $.$$.STT.Task$$(T).$h
        },
        {
          "n": "marshaler",
          "p": (T) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ToJS",
      "o": "@$43",
      "d": 1310731,
      "h": 249109413899,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(249109413899),
//--TRIMMABLE-BOUNDARY-START(12886212619),
    {
      "r": 262145,
      "p": [
        {
          "n": "_",
          "p": 2293771
        }
      ],
      "n": "CanMarshalTaskResultOnSameCall",
      "d": 1310731,
      "h": 12886212619,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12886212619),
//--TRIMMABLE-BOUNDARY-START(47245950987),
    {
      "r": 65537,
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "ex",
          "p": 80805889
        }
      ],
      "n": "RejectPromise",
      "d": 1310731,
      "h": 47245950987,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47245950987),
//--TRIMMABLE-BOUNDARY-START(55835885579),
    {
      "r": 65537,
      "p": [
        {
          "n": "holder",
          "p": 2228235
        }
      ],
      "n": "ResolveVoidPromise",
      "d": 1310731,
      "h": 55835885579,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55835885579),
//--TRIMMABLE-BOUNDARY-START(51540918283),
    {
      "r": 65537,
      "p": [
        {
          "n": "holder",
          "p": 2228235
        },
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "marshaler",
          "p": (T) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ResolvePromise",
      "d": 1310731,
      "h": 51540918283,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(51540918283),
//--TRIMMABLE-BOUNDARY-START(292059086859),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 43122689,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "d": 1310731,
      "h": 292059086859,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(292059086859),
//--TRIMMABLE-BOUNDARY-START(472447713291),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => $.$$.S.Action$$(T).$h,
          "f": 2
        },
        {
          "n": "arg1Marshaler",
          "p": (T) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ToManaged",
      "o": "@$42",
      "d": 1310731,
      "h": 472447713291,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(472447713291),
//--TRIMMABLE-BOUNDARY-START(493922549771),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2) => $.$$.S.Action$$$(T1, T2).$h,
          "f": 2
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        }
      ],
      "g": [
        "T1",
        "T2"
      ],
      "n": "ToManaged",
      "o": "@$47",
      "d": 1310731,
      "h": 493922549771,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(493922549771),
//--TRIMMABLE-BOUNDARY-START(485332615179),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2, T3) => $.$$.S.Action$$$$(T1, T2, T3).$h,
          "f": 2
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2, T3) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2, T3) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        },
        {
          "n": "arg3Marshaler",
          "p": (T1, T2, T3) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3"
      ],
      "n": "ToManaged",
      "o": "@$45",
      "d": 1310731,
      "h": 485332615179,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(485332615179),
//--TRIMMABLE-BOUNDARY-START(498217517067),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (TResult) => $.$$.S.Func$$(TResult).$h,
          "f": 2
        },
        {
          "n": "resMarshaler",
          "p": (TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "ToManaged",
      "o": "@$48",
      "d": 1310731,
      "h": 498217517067,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(498217517067),
//--TRIMMABLE-BOUNDARY-START(468152745995),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T, TResult) => $.$$.S.Func$$$(T, TResult).$h,
          "f": 2
        },
        {
          "n": "arg1Marshaler",
          "p": (T, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T).$h
        },
        {
          "n": "resMarshaler",
          "p": (T, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "g": [
        "T",
        "TResult"
      ],
      "n": "ToManaged",
      "o": "@$41",
      "d": 1310731,
      "h": 468152745995,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(468152745995),
//--TRIMMABLE-BOUNDARY-START(489627582475),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2, TResult) => $.$$.S.Func$$$$(T1, T2, TResult).$h,
          "f": 2
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        },
        {
          "n": "resMarshaler",
          "p": (T1, T2, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "TResult"
      ],
      "n": "ToManaged",
      "o": "@$46",
      "d": 1310731,
      "h": 489627582475,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(489627582475),
//--TRIMMABLE-BOUNDARY-START(481037647883),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2, T3, TResult) => $.$$.S.Func$$$$$(T1, T2, T3, TResult).$h,
          "f": 2
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T2).$h
        },
        {
          "n": "arg3Marshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T3).$h
        },
        {
          "n": "resMarshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(TResult).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "TResult"
      ],
      "n": "ToManaged",
      "o": "@$44",
      "d": 1310731,
      "h": 481037647883,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(481037647883),
//--TRIMMABLE-BOUNDARY-START(64425820171),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 43122689
        }
      ],
      "n": "ToJS",
      "d": 1310731,
      "h": 64425820171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425820171),
//--TRIMMABLE-BOUNDARY-START(244814446603),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => $.$$.S.Action$$(T).$h
        },
        {
          "n": "arg1Marshaler",
          "p": (T) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ToJS",
      "o": "@$42",
      "d": 1310731,
      "h": 244814446603,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(244814446603),
//--TRIMMABLE-BOUNDARY-START(266289283083),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2) => $.$$.S.Action$$$(T1, T2).$h
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h
        }
      ],
      "g": [
        "T1",
        "T2"
      ],
      "n": "ToJS",
      "o": "@$47",
      "d": 1310731,
      "h": 266289283083,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(266289283083),
//--TRIMMABLE-BOUNDARY-START(257699348491),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2, T3) => $.$$.S.Action$$$$(T1, T2, T3).$h
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2, T3) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2, T3) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h
        },
        {
          "n": "arg3Marshaler",
          "p": (T1, T2, T3) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(T3).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3"
      ],
      "n": "ToJS",
      "o": "@$45",
      "d": 1310731,
      "h": 257699348491,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(257699348491),
//--TRIMMABLE-BOUNDARY-START(270584250379),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (TResult) => $.$$.S.Func$$(TResult).$h
        },
        {
          "n": "resMarshaler",
          "p": (TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "ToJS",
      "o": "@$48",
      "d": 1310731,
      "h": 270584250379,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(270584250379),
//--TRIMMABLE-BOUNDARY-START(240519479307),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T, TResult) => $.$$.S.Func$$$(T, TResult).$h
        },
        {
          "n": "arg1Marshaler",
          "p": (T, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(T).$h
        },
        {
          "n": "resMarshaler",
          "p": (T, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h
        }
      ],
      "g": [
        "T",
        "TResult"
      ],
      "n": "ToJS",
      "o": "@$41",
      "d": 1310731,
      "h": 240519479307,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(240519479307),
//--TRIMMABLE-BOUNDARY-START(261994315787),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2, TResult) => $.$$.S.Func$$$$(T1, T2, TResult).$h
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h
        },
        {
          "n": "resMarshaler",
          "p": (T1, T2, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "TResult"
      ],
      "n": "ToJS",
      "o": "@$46",
      "d": 1310731,
      "h": 261994315787,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(261994315787),
//--TRIMMABLE-BOUNDARY-START(253404381195),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T1, T2, T3, TResult) => $.$$.S.Func$$$$$(T1, T2, T3, TResult).$h
        },
        {
          "n": "arg1Marshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(T1).$h
        },
        {
          "n": "arg2Marshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(T2).$h
        },
        {
          "n": "arg3Marshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(T3).$h
        },
        {
          "n": "resMarshaler",
          "p": (T1, T2, T3, TResult) => $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(TResult).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "TResult"
      ],
      "n": "ToJS",
      "o": "@$44",
      "d": 1310731,
      "h": 253404381195,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(253404381195),
//--TRIMMABLE-BOUNDARY-START(416613138443),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$29",
      "d": 1310731,
      "h": 416613138443,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(416613138443),
//--TRIMMABLE-BOUNDARY-START(188979871755),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ToJS",
      "o": "@$29",
      "d": 1310731,
      "h": 188979871755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188979871755),
//--TRIMMABLE-BOUNDARY-START(420908105739),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 2
        }
      ],
      "n": "ToManaged",
      "o": "@$30",
      "d": 1310731,
      "h": 420908105739,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(420908105739),
//--TRIMMABLE-BOUNDARY-START(193274839051),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "ToJS",
      "o": "@$30",
      "d": 1310731,
      "h": 193274839051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193274839051)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60130852875),
    {
      "t": 2097163,
      "n": "slot",
      "d": 1310731,
      "h": 60130852875,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(60130852875),
//--TRIMMABLE-BOUNDARY-START(34361049099),
    {
      "t": 917505,
      "n": "I52_MAX_VALUE",
      "d": 1310731,
      "h": 34361049099,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34361049099),
//--TRIMMABLE-BOUNDARY-START(38656016395),
    {
      "t": 917505,
      "n": "I52_MIN_VALUE",
      "d": 1310731,
      "h": 38656016395,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38656016395)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278027),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310731,
      "h": 4296278027,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278027)
  ],
  "h": 1310731,
  "a": [
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    }
  ]
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$srij.SRIJ.JSMarshalerArgument.JSMarshalerArgumentImpl, $.$srij.SRIJ.JSMarshalerArgument.ArgumentToManagedCallback$$(T), $.$srij.SRIJ.JSMarshalerArgument.ArgumentToJSCallback$$(T), $.$srij.SRIJ.JSMarshalerArgument.HolderAndMarshaler$$(T), $.$srij.SRIJ.JSMarshalerArgument.ActionJS, $.$srij.SRIJ.JSMarshalerArgument.ActionJS$$(T), $.$srij.SRIJ.JSMarshalerArgument.ActionJS$$$(T1, T2), $.$srij.SRIJ.JSMarshalerArgument.ActionJS$$$$(T1, T2, T3), $.$srij.SRIJ.JSMarshalerArgument.FuncJS$$(TResult), $.$srij.SRIJ.JSMarshalerArgument.FuncJS$$$(T, TResult), $.$srij.SRIJ.JSMarshalerArgument.FuncJS$$$$(T1, T2, TResult), $.$srij.SRIJ.JSMarshalerArgument.FuncJS$$$$$(T1, T2, T3, TResult) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalerArgument`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalerArgument`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310731)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245195)
        $asm.$cls(`$srij.SRIJ.JSMarshalAsAttribute<>`, (T) => $asm.$gt(`$srij.SRIJ.JSMarshalAsAttribute<>`, [T], ($self) => class JSMarshalAsAttribute$$ extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296212491)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296212491);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296212491)
            
            //--TRIMMABLE-BOUNDARY-START(4296212491)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296212491)
            
            static $H = 1245195;
            static $h = 1245195;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212491),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4296212491,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212491)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "c": [2359307
      ]
    }
  ],
  "r": 1,
  "H": 1245195,
  "h": this.$h,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 10240,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSMarshalAsAttribute$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1245195)
        
        

        //--TRIMMABLE-BOUNDARY-START(3670027)
        $asm.$str(`$srij.SRIJ.MarshalerType`, ($self) => class MarshalerType extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static None = 0;
            static Void = 1;
            static Discard = 2;
            static Boolean = 3;
            static Byte = 4;
            static Char = 5;
            static Int16 = 6;
            static Int32 = 7;
            static Int52 = 8;
            static BigInt64 = 9;
            static Double = 10;
            static Single = 11;
            static IntPtr = 12;
            static JSObject = 13;
            static Object = 14;
            static String = 15;
            static Exception = 16;
            static DateTime = 17;
            static DateTimeOffset = 18;
            static Nullable = 19;
            static Task = 20;
            static Array = 21;
            static ArraySegment = 22;
            static Span = 23;
            static Action = 24;
            static Function = 25;
            static DiscardNoWait = 26;
            static JSException = 27;
            static TaskResolved = 28;
            static TaskRejected = 29;
            static TaskPreCreated = 30;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3670027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Void": 1n,
                    "Discard": 2n,
                    "Boolean": 3n,
                    "Byte": 4n,
                    "Char": 5n,
                    "Int16": 6n,
                    "Int32": 7n,
                    "Int52": 8n,
                    "BigInt64": 9n,
                    "Double": 10n,
                    "Single": 11n,
                    "IntPtr": 12n,
                    "JSObject": 13n,
                    "Object": 14n,
                    "String": 15n,
                    "Exception": 16n,
                    "DateTime": 17n,
                    "DateTimeOffset": 18n,
                    "Nullable": 19n,
                    "Task": 20n,
                    "Array": 21n,
                    "ArraySegment": 22n,
                    "Span": 23n,
                    "Action": 24n,
                    "Function": 25n,
                    "DiscardNoWait": 26n,
                    "JSException": 27n,
                    "TaskResolved": 28n,
                    "TaskRejected": 29n,
                    "TaskPreCreated": 30n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298637323)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298637323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298637323)
            
            //--TRIMMABLE-BOUNDARY-START(4298637323)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298637323)
            
            static $h = 3670027;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(94492950539),
    {
      "t": 3670027,
      "n": "None",
      "d": 3670027,
      "h": 94492950539,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94492950539),
//--TRIMMABLE-BOUNDARY-START(137442623499),
    {
      "t": 3670027,
      "n": "Void",
      "d": 3670027,
      "h": 137442623499,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137442623499),
//--TRIMMABLE-BOUNDARY-START(47248310283),
    {
      "t": 3670027,
      "n": "Discard",
      "d": 3670027,
      "h": 47248310283,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47248310283),
//--TRIMMABLE-BOUNDARY-START(25773473803),
    {
      "t": 3670027,
      "n": "Boolean",
      "d": 3670027,
      "h": 25773473803,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25773473803),
//--TRIMMABLE-BOUNDARY-START(30068441099),
    {
      "t": 3670027,
      "n": "Byte",
      "d": 3670027,
      "h": 30068441099,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30068441099),
//--TRIMMABLE-BOUNDARY-START(34363408395),
    {
      "t": 3670027,
      "n": "Char",
      "d": 3670027,
      "h": 34363408395,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34363408395),
//--TRIMMABLE-BOUNDARY-START(68723146763),
    {
      "t": 3670027,
      "n": "Int16",
      "d": 3670027,
      "h": 68723146763,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68723146763),
//--TRIMMABLE-BOUNDARY-START(73018114059),
    {
      "t": 3670027,
      "n": "Int32",
      "d": 3670027,
      "h": 73018114059,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73018114059),
//--TRIMMABLE-BOUNDARY-START(77313081355),
    {
      "t": 3670027,
      "n": "Int52",
      "d": 3670027,
      "h": 77313081355,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77313081355),
//--TRIMMABLE-BOUNDARY-START(21478506507),
    {
      "t": 3670027,
      "n": "BigInt64",
      "d": 3670027,
      "h": 21478506507,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478506507),
//--TRIMMABLE-BOUNDARY-START(55838244875),
    {
      "t": 3670027,
      "n": "Double",
      "d": 3670027,
      "h": 55838244875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55838244875),
//--TRIMMABLE-BOUNDARY-START(107377852427),
    {
      "t": 3670027,
      "n": "Single",
      "d": 3670027,
      "h": 107377852427,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107377852427),
//--TRIMMABLE-BOUNDARY-START(81608048651),
    {
      "t": 3670027,
      "n": "IntPtr",
      "d": 3670027,
      "h": 81608048651,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81608048651),
//--TRIMMABLE-BOUNDARY-START(90197983243),
    {
      "t": 3670027,
      "n": "JSObject",
      "d": 3670027,
      "h": 90197983243,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90197983243),
//--TRIMMABLE-BOUNDARY-START(103082885131),
    {
      "t": 3670027,
      "n": "Object",
      "d": 3670027,
      "h": 103082885131,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103082885131),
//--TRIMMABLE-BOUNDARY-START(115967787019),
    {
      "t": 3670027,
      "n": "String",
      "d": 3670027,
      "h": 115967787019,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115967787019),
//--TRIMMABLE-BOUNDARY-START(38658375691),
    {
      "t": 3670027,
      "n": "DateTime",
      "d": 3670027,
      "h": 38658375691,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38658375691),
//--TRIMMABLE-BOUNDARY-START(42953342987),
    {
      "t": 3670027,
      "n": "DateTimeOffset",
      "d": 3670027,
      "h": 42953342987,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42953342987),
//--TRIMMABLE-BOUNDARY-START(98787917835),
    {
      "t": 3670027,
      "n": "Nullable",
      "d": 3670027,
      "h": 98787917835,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98787917835),
//--TRIMMABLE-BOUNDARY-START(120262754315),
    {
      "t": 3670027,
      "n": "Task",
      "d": 3670027,
      "h": 120262754315,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120262754315),
//--TRIMMABLE-BOUNDARY-START(12888571915),
    {
      "t": 3670027,
      "n": "Array",
      "d": 3670027,
      "h": 12888571915,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888571915),
//--TRIMMABLE-BOUNDARY-START(17183539211),
    {
      "t": 3670027,
      "n": "ArraySegment",
      "d": 3670027,
      "h": 17183539211,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183539211),
//--TRIMMABLE-BOUNDARY-START(111672819723),
    {
      "t": 3670027,
      "n": "Span",
      "d": 3670027,
      "h": 111672819723,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111672819723),
//--TRIMMABLE-BOUNDARY-START(8593604619),
    {
      "t": 3670027,
      "n": "Action",
      "d": 3670027,
      "h": 8593604619,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593604619),
//--TRIMMABLE-BOUNDARY-START(64428179467),
    {
      "t": 3670027,
      "n": "Function",
      "d": 3670027,
      "h": 64428179467,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64428179467),
//--TRIMMABLE-BOUNDARY-START(51543277579),
    {
      "t": 3670027,
      "n": "DiscardNoWait",
      "d": 3670027,
      "h": 51543277579,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51543277579),
//--TRIMMABLE-BOUNDARY-START(133147656203),
    {
      "t": 3670027,
      "n": "TaskResolved",
      "d": 3670027,
      "h": 133147656203,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133147656203),
//--TRIMMABLE-BOUNDARY-START(128852688907),
    {
      "t": 3670027,
      "n": "TaskRejected",
      "d": 3670027,
      "h": 128852688907,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128852688907),
//--TRIMMABLE-BOUNDARY-START(124557721611),
    {
      "t": 3670027,
      "n": "TaskPreCreated",
      "d": 3670027,
      "h": 124557721611,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124557721611)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298637323),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3670027,
      "h": 4298637323,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298637323)
  ],
  "h": 3670027
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.MarshalerType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}MarshalerType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3670027)
        
        

        //--TRIMMABLE-BOUNDARY-START(393227)
        $asm.$cls(`$srij.SRIJ.JSException`, ($self) => class JSException extends $.$$.S.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(34360131595)
            /*JSObject?*/ jsException = null;
            //--TRIMMABLE-BOUNDARY-END(34360131595)
            
            //--TRIMMABLE-BOUNDARY-START(12885295115)
            /*string?*/ combinedStackTrace = null;
            //--TRIMMABLE-BOUNDARY-END(12885295115)
            
            //--TRIMMABLE-BOUNDARY-START(8590327819)
            $ctor$6(/*string*/ msg)
            {
                super.$ctor$4(msg);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327819);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.jsException = null;
                    this.combinedStackTrace = null;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327819)
            
            //--TRIMMABLE-BOUNDARY-START(4295360523)
            $ctor$5(/*string*/ msg, /*JSObject?*/ jsException)
            {
                super.$ctor$4(msg);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360523);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.jsException = jsException;
                    this.combinedStackTrace = null;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360523)
            
            //--TRIMMABLE-BOUNDARY-START(38655098891)
            /*string? */ get StackTrace()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770197003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.combinedStackTrace !== null)
                {
                    return this.combinedStackTrace;
                }
                /*var*/ let bs = super.StackTrace;
                if (this.jsException === null)
                {
                    return bs;
                }
                /*string?*/ let jsStackTrace = this.jsException.GetPropertyAsString("stack");
                this.jsException.Dispose();
                this.jsException = null;
                if (jsStackTrace === null)
                {
                    this.combinedStackTrace = bs;
                    return this.combinedStackTrace;
                }
                else if (jsStackTrace.startsWith($.$strNN(this.Message) + "\n"))
                {
                    jsStackTrace = jsStackTrace.slice(((this.Message.length + 1) | 0));
                }
                if (bs === null)
                {
                    this.combinedStackTrace = jsStackTrace;
                }
                this.combinedStackTrace = bs !== null ? $.$strNN($.$strNN(bs) + $.$strNN($.$$.S.Environment.NewLine)) + $.$strNN(jsStackTrace) : jsStackTrace;
                return this.combinedStackTrace;
            }
            //--TRIMMABLE-BOUNDARY-END(38655098891)
            
            //--TRIMMABLE-BOUNDARY-START(17180262411)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let other;
                return $.$is(obj, $.$srij.SRIJ.JSException, { set $v($v){ other = $v; } }) && other.jsException === this.jsException;
            }
            //--TRIMMABLE-BOUNDARY-END(17180262411)
            
            //--TRIMMABLE-BOUNDARY-START(30065164299)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.jsException === null ? $.$$.S.Object.GetHashCode.call(this) : (($.$$.S.Object.GetHashCode.call(this) * this.jsException.GetHashCode()) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(30065164299)
            
            //--TRIMMABLE-BOUNDARY-START(42950066187)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950066187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Message;
            }
            //--TRIMMABLE-BOUNDARY-END(42950066187)
            
            static $h = 393227;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Exception; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 393227
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.JavaScript.JSException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}JavaScript${separator}JSException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393227)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading.ThreadPool", "NetJs.System.Threading.Channels"));
})();
//--TRIMMABLE-BOUNDARY-END(11)
